NAME          jssp_search_n9_m7_bimodal_pt1-99_s2
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_0_5
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_1_5
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_2_5
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_3_5
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_4_5
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_5_5
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  prec_6_5
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_7_4
 G  prec_7_5
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_8_4
 G  prec_8_5
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_0_7_5
 G  disj2_0_7_5
 G  disj1_0_8_5
 G  disj2_0_8_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_1_7_5
 G  disj2_1_7_5
 G  disj1_1_8_5
 G  disj2_1_8_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_2_7_5
 G  disj2_2_7_5
 G  disj1_2_8_5
 G  disj2_2_8_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_3_7_5
 G  disj2_3_7_5
 G  disj1_3_8_5
 G  disj2_3_8_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_4_7_5
 G  disj2_4_7_5
 G  disj1_4_8_5
 G  disj2_4_8_5
 G  disj1_5_6_5
 G  disj2_5_6_5
 G  disj1_5_7_5
 G  disj2_5_7_5
 G  disj1_5_8_5
 G  disj2_5_8_5
 G  disj1_6_7_5
 G  disj2_6_7_5
 G  disj1_6_8_5
 G  disj2_6_8_5
 G  disj1_7_8_5
 G  disj2_7_8_5
 G  disj1_0_1_6
 G  disj2_0_1_6
 G  disj1_0_2_6
 G  disj2_0_2_6
 G  disj1_0_3_6
 G  disj2_0_3_6
 G  disj1_0_4_6
 G  disj2_0_4_6
 G  disj1_0_5_6
 G  disj2_0_5_6
 G  disj1_0_6_6
 G  disj2_0_6_6
 G  disj1_0_7_6
 G  disj2_0_7_6
 G  disj1_0_8_6
 G  disj2_0_8_6
 G  disj1_1_2_6
 G  disj2_1_2_6
 G  disj1_1_3_6
 G  disj2_1_3_6
 G  disj1_1_4_6
 G  disj2_1_4_6
 G  disj1_1_5_6
 G  disj2_1_5_6
 G  disj1_1_6_6
 G  disj2_1_6_6
 G  disj1_1_7_6
 G  disj2_1_7_6
 G  disj1_1_8_6
 G  disj2_1_8_6
 G  disj1_2_3_6
 G  disj2_2_3_6
 G  disj1_2_4_6
 G  disj2_2_4_6
 G  disj1_2_5_6
 G  disj2_2_5_6
 G  disj1_2_6_6
 G  disj2_2_6_6
 G  disj1_2_7_6
 G  disj2_2_7_6
 G  disj1_2_8_6
 G  disj2_2_8_6
 G  disj1_3_4_6
 G  disj2_3_4_6
 G  disj1_3_5_6
 G  disj2_3_5_6
 G  disj1_3_6_6
 G  disj2_3_6_6
 G  disj1_3_7_6
 G  disj2_3_7_6
 G  disj1_3_8_6
 G  disj2_3_8_6
 G  disj1_4_5_6
 G  disj2_4_5_6
 G  disj1_4_6_6
 G  disj2_4_6_6
 G  disj1_4_7_6
 G  disj2_4_7_6
 G  disj1_4_8_6
 G  disj2_4_8_6
 G  disj1_5_6_6
 G  disj2_5_6_6
 G  disj1_5_7_6
 G  disj2_5_7_6
 G  disj1_5_8_6
 G  disj2_5_8_6
 G  disj1_6_7_6
 G  disj2_6_7_6
 G  disj1_6_8_6
 G  disj2_6_8_6
 G  disj1_7_8_6
 G  disj2_7_8_6
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_2  -1.0
    x_0_0     disj2_0_1_2  1.0
    x_0_0     disj1_0_2_2  -1.0
    x_0_0     disj2_0_2_2  1.0
    x_0_0     disj1_0_3_2  -1.0
    x_0_0     disj2_0_3_2  1.0
    x_0_0     disj1_0_4_2  -1.0
    x_0_0     disj2_0_4_2  1.0
    x_0_0     disj1_0_5_2  -1.0
    x_0_0     disj2_0_5_2  1.0
    x_0_0     disj1_0_6_2  -1.0
    x_0_0     disj2_0_6_2  1.0
    x_0_0     disj1_0_7_2  -1.0
    x_0_0     disj2_0_7_2  1.0
    x_0_0     disj1_0_8_2  -1.0
    x_0_0     disj2_0_8_2  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_3  -1.0
    x_0_1     disj2_0_1_3  1.0
    x_0_1     disj1_0_2_3  -1.0
    x_0_1     disj2_0_2_3  1.0
    x_0_1     disj1_0_3_3  -1.0
    x_0_1     disj2_0_3_3  1.0
    x_0_1     disj1_0_4_3  -1.0
    x_0_1     disj2_0_4_3  1.0
    x_0_1     disj1_0_5_3  -1.0
    x_0_1     disj2_0_5_3  1.0
    x_0_1     disj1_0_6_3  -1.0
    x_0_1     disj2_0_6_3  1.0
    x_0_1     disj1_0_7_3  -1.0
    x_0_1     disj2_0_7_3  1.0
    x_0_1     disj1_0_8_3  -1.0
    x_0_1     disj2_0_8_3  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_1  -1.0
    x_0_2     disj2_0_1_1  1.0
    x_0_2     disj1_0_2_1  -1.0
    x_0_2     disj2_0_2_1  1.0
    x_0_2     disj1_0_3_1  -1.0
    x_0_2     disj2_0_3_1  1.0
    x_0_2     disj1_0_4_1  -1.0
    x_0_2     disj2_0_4_1  1.0
    x_0_2     disj1_0_5_1  -1.0
    x_0_2     disj2_0_5_1  1.0
    x_0_2     disj1_0_6_1  -1.0
    x_0_2     disj2_0_6_1  1.0
    x_0_2     disj1_0_7_1  -1.0
    x_0_2     disj2_0_7_1  1.0
    x_0_2     disj1_0_8_1  -1.0
    x_0_2     disj2_0_8_1  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_4  -1.0
    x_0_3     disj2_0_1_4  1.0
    x_0_3     disj1_0_2_4  -1.0
    x_0_3     disj2_0_2_4  1.0
    x_0_3     disj1_0_3_4  -1.0
    x_0_3     disj2_0_3_4  1.0
    x_0_3     disj1_0_4_4  -1.0
    x_0_3     disj2_0_4_4  1.0
    x_0_3     disj1_0_5_4  -1.0
    x_0_3     disj2_0_5_4  1.0
    x_0_3     disj1_0_6_4  -1.0
    x_0_3     disj2_0_6_4  1.0
    x_0_3     disj1_0_7_4  -1.0
    x_0_3     disj2_0_7_4  1.0
    x_0_3     disj1_0_8_4  -1.0
    x_0_3     disj2_0_8_4  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_5  -1.0
    x_0_4     disj2_0_1_5  1.0
    x_0_4     disj1_0_2_5  -1.0
    x_0_4     disj2_0_2_5  1.0
    x_0_4     disj1_0_3_5  -1.0
    x_0_4     disj2_0_3_5  1.0
    x_0_4     disj1_0_4_5  -1.0
    x_0_4     disj2_0_4_5  1.0
    x_0_4     disj1_0_5_5  -1.0
    x_0_4     disj2_0_5_5  1.0
    x_0_4     disj1_0_6_5  -1.0
    x_0_4     disj2_0_6_5  1.0
    x_0_4     disj1_0_7_5  -1.0
    x_0_4     disj2_0_7_5  1.0
    x_0_4     disj1_0_8_5  -1.0
    x_0_4     disj2_0_8_5  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     prec_0_5  -1.0
    x_0_5     disj1_0_1_0  -1.0
    x_0_5     disj2_0_1_0  1.0
    x_0_5     disj1_0_2_0  -1.0
    x_0_5     disj2_0_2_0  1.0
    x_0_5     disj1_0_3_0  -1.0
    x_0_5     disj2_0_3_0  1.0
    x_0_5     disj1_0_4_0  -1.0
    x_0_5     disj2_0_4_0  1.0
    x_0_5     disj1_0_5_0  -1.0
    x_0_5     disj2_0_5_0  1.0
    x_0_5     disj1_0_6_0  -1.0
    x_0_5     disj2_0_6_0  1.0
    x_0_5     disj1_0_7_0  -1.0
    x_0_5     disj2_0_7_0  1.0
    x_0_5     disj1_0_8_0  -1.0
    x_0_5     disj2_0_8_0  1.0
    x_0_6     prec_0_5  1.0
    x_0_6     mksp_0    -1.0
    x_0_6     disj1_0_1_6  -1.0
    x_0_6     disj2_0_1_6  1.0
    x_0_6     disj1_0_2_6  -1.0
    x_0_6     disj2_0_2_6  1.0
    x_0_6     disj1_0_3_6  -1.0
    x_0_6     disj2_0_3_6  1.0
    x_0_6     disj1_0_4_6  -1.0
    x_0_6     disj2_0_4_6  1.0
    x_0_6     disj1_0_5_6  -1.0
    x_0_6     disj2_0_5_6  1.0
    x_0_6     disj1_0_6_6  -1.0
    x_0_6     disj2_0_6_6  1.0
    x_0_6     disj1_0_7_6  -1.0
    x_0_6     disj2_0_7_6  1.0
    x_0_6     disj1_0_8_6  -1.0
    x_0_6     disj2_0_8_6  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_0     disj1_1_7_1  -1.0
    x_1_0     disj2_1_7_1  1.0
    x_1_0     disj1_1_8_1  -1.0
    x_1_0     disj2_1_8_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_0  1.0
    x_1_1     disj2_0_1_0  -1.0
    x_1_1     disj1_1_2_0  -1.0
    x_1_1     disj2_1_2_0  1.0
    x_1_1     disj1_1_3_0  -1.0
    x_1_1     disj2_1_3_0  1.0
    x_1_1     disj1_1_4_0  -1.0
    x_1_1     disj2_1_4_0  1.0
    x_1_1     disj1_1_5_0  -1.0
    x_1_1     disj2_1_5_0  1.0
    x_1_1     disj1_1_6_0  -1.0
    x_1_1     disj2_1_6_0  1.0
    x_1_1     disj1_1_7_0  -1.0
    x_1_1     disj2_1_7_0  1.0
    x_1_1     disj1_1_8_0  -1.0
    x_1_1     disj2_1_8_0  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_5  1.0
    x_1_2     disj2_0_1_5  -1.0
    x_1_2     disj1_1_2_5  -1.0
    x_1_2     disj2_1_2_5  1.0
    x_1_2     disj1_1_3_5  -1.0
    x_1_2     disj2_1_3_5  1.0
    x_1_2     disj1_1_4_5  -1.0
    x_1_2     disj2_1_4_5  1.0
    x_1_2     disj1_1_5_5  -1.0
    x_1_2     disj2_1_5_5  1.0
    x_1_2     disj1_1_6_5  -1.0
    x_1_2     disj2_1_6_5  1.0
    x_1_2     disj1_1_7_5  -1.0
    x_1_2     disj2_1_7_5  1.0
    x_1_2     disj1_1_8_5  -1.0
    x_1_2     disj2_1_8_5  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_4  1.0
    x_1_3     disj2_0_1_4  -1.0
    x_1_3     disj1_1_2_4  -1.0
    x_1_3     disj2_1_2_4  1.0
    x_1_3     disj1_1_3_4  -1.0
    x_1_3     disj2_1_3_4  1.0
    x_1_3     disj1_1_4_4  -1.0
    x_1_3     disj2_1_4_4  1.0
    x_1_3     disj1_1_5_4  -1.0
    x_1_3     disj2_1_5_4  1.0
    x_1_3     disj1_1_6_4  -1.0
    x_1_3     disj2_1_6_4  1.0
    x_1_3     disj1_1_7_4  -1.0
    x_1_3     disj2_1_7_4  1.0
    x_1_3     disj1_1_8_4  -1.0
    x_1_3     disj2_1_8_4  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_6  1.0
    x_1_4     disj2_0_1_6  -1.0
    x_1_4     disj1_1_2_6  -1.0
    x_1_4     disj2_1_2_6  1.0
    x_1_4     disj1_1_3_6  -1.0
    x_1_4     disj2_1_3_6  1.0
    x_1_4     disj1_1_4_6  -1.0
    x_1_4     disj2_1_4_6  1.0
    x_1_4     disj1_1_5_6  -1.0
    x_1_4     disj2_1_5_6  1.0
    x_1_4     disj1_1_6_6  -1.0
    x_1_4     disj2_1_6_6  1.0
    x_1_4     disj1_1_7_6  -1.0
    x_1_4     disj2_1_7_6  1.0
    x_1_4     disj1_1_8_6  -1.0
    x_1_4     disj2_1_8_6  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     prec_1_5  -1.0
    x_1_5     disj1_0_1_2  1.0
    x_1_5     disj2_0_1_2  -1.0
    x_1_5     disj1_1_2_2  -1.0
    x_1_5     disj2_1_2_2  1.0
    x_1_5     disj1_1_3_2  -1.0
    x_1_5     disj2_1_3_2  1.0
    x_1_5     disj1_1_4_2  -1.0
    x_1_5     disj2_1_4_2  1.0
    x_1_5     disj1_1_5_2  -1.0
    x_1_5     disj2_1_5_2  1.0
    x_1_5     disj1_1_6_2  -1.0
    x_1_5     disj2_1_6_2  1.0
    x_1_5     disj1_1_7_2  -1.0
    x_1_5     disj2_1_7_2  1.0
    x_1_5     disj1_1_8_2  -1.0
    x_1_5     disj2_1_8_2  1.0
    x_1_6     prec_1_5  1.0
    x_1_6     mksp_1    -1.0
    x_1_6     disj1_0_1_3  1.0
    x_1_6     disj2_0_1_3  -1.0
    x_1_6     disj1_1_2_3  -1.0
    x_1_6     disj2_1_2_3  1.0
    x_1_6     disj1_1_3_3  -1.0
    x_1_6     disj2_1_3_3  1.0
    x_1_6     disj1_1_4_3  -1.0
    x_1_6     disj2_1_4_3  1.0
    x_1_6     disj1_1_5_3  -1.0
    x_1_6     disj2_1_5_3  1.0
    x_1_6     disj1_1_6_3  -1.0
    x_1_6     disj2_1_6_3  1.0
    x_1_6     disj1_1_7_3  -1.0
    x_1_6     disj2_1_7_3  1.0
    x_1_6     disj1_1_8_3  -1.0
    x_1_6     disj2_1_8_3  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_0  1.0
    x_2_0     disj2_0_2_0  -1.0
    x_2_0     disj1_1_2_0  1.0
    x_2_0     disj2_1_2_0  -1.0
    x_2_0     disj1_2_3_0  -1.0
    x_2_0     disj2_2_3_0  1.0
    x_2_0     disj1_2_4_0  -1.0
    x_2_0     disj2_2_4_0  1.0
    x_2_0     disj1_2_5_0  -1.0
    x_2_0     disj2_2_5_0  1.0
    x_2_0     disj1_2_6_0  -1.0
    x_2_0     disj2_2_6_0  1.0
    x_2_0     disj1_2_7_0  -1.0
    x_2_0     disj2_2_7_0  1.0
    x_2_0     disj1_2_8_0  -1.0
    x_2_0     disj2_2_8_0  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_4  1.0
    x_2_1     disj2_0_2_4  -1.0
    x_2_1     disj1_1_2_4  1.0
    x_2_1     disj2_1_2_4  -1.0
    x_2_1     disj1_2_3_4  -1.0
    x_2_1     disj2_2_3_4  1.0
    x_2_1     disj1_2_4_4  -1.0
    x_2_1     disj2_2_4_4  1.0
    x_2_1     disj1_2_5_4  -1.0
    x_2_1     disj2_2_5_4  1.0
    x_2_1     disj1_2_6_4  -1.0
    x_2_1     disj2_2_6_4  1.0
    x_2_1     disj1_2_7_4  -1.0
    x_2_1     disj2_2_7_4  1.0
    x_2_1     disj1_2_8_4  -1.0
    x_2_1     disj2_2_8_4  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_2  1.0
    x_2_2     disj2_0_2_2  -1.0
    x_2_2     disj1_1_2_2  1.0
    x_2_2     disj2_1_2_2  -1.0
    x_2_2     disj1_2_3_2  -1.0
    x_2_2     disj2_2_3_2  1.0
    x_2_2     disj1_2_4_2  -1.0
    x_2_2     disj2_2_4_2  1.0
    x_2_2     disj1_2_5_2  -1.0
    x_2_2     disj2_2_5_2  1.0
    x_2_2     disj1_2_6_2  -1.0
    x_2_2     disj2_2_6_2  1.0
    x_2_2     disj1_2_7_2  -1.0
    x_2_2     disj2_2_7_2  1.0
    x_2_2     disj1_2_8_2  -1.0
    x_2_2     disj2_2_8_2  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_5  1.0
    x_2_3     disj2_0_2_5  -1.0
    x_2_3     disj1_1_2_5  1.0
    x_2_3     disj2_1_2_5  -1.0
    x_2_3     disj1_2_3_5  -1.0
    x_2_3     disj2_2_3_5  1.0
    x_2_3     disj1_2_4_5  -1.0
    x_2_3     disj2_2_4_5  1.0
    x_2_3     disj1_2_5_5  -1.0
    x_2_3     disj2_2_5_5  1.0
    x_2_3     disj1_2_6_5  -1.0
    x_2_3     disj2_2_6_5  1.0
    x_2_3     disj1_2_7_5  -1.0
    x_2_3     disj2_2_7_5  1.0
    x_2_3     disj1_2_8_5  -1.0
    x_2_3     disj2_2_8_5  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_1  1.0
    x_2_4     disj2_0_2_1  -1.0
    x_2_4     disj1_1_2_1  1.0
    x_2_4     disj2_1_2_1  -1.0
    x_2_4     disj1_2_3_1  -1.0
    x_2_4     disj2_2_3_1  1.0
    x_2_4     disj1_2_4_1  -1.0
    x_2_4     disj2_2_4_1  1.0
    x_2_4     disj1_2_5_1  -1.0
    x_2_4     disj2_2_5_1  1.0
    x_2_4     disj1_2_6_1  -1.0
    x_2_4     disj2_2_6_1  1.0
    x_2_4     disj1_2_7_1  -1.0
    x_2_4     disj2_2_7_1  1.0
    x_2_4     disj1_2_8_1  -1.0
    x_2_4     disj2_2_8_1  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     prec_2_5  -1.0
    x_2_5     disj1_0_2_3  1.0
    x_2_5     disj2_0_2_3  -1.0
    x_2_5     disj1_1_2_3  1.0
    x_2_5     disj2_1_2_3  -1.0
    x_2_5     disj1_2_3_3  -1.0
    x_2_5     disj2_2_3_3  1.0
    x_2_5     disj1_2_4_3  -1.0
    x_2_5     disj2_2_4_3  1.0
    x_2_5     disj1_2_5_3  -1.0
    x_2_5     disj2_2_5_3  1.0
    x_2_5     disj1_2_6_3  -1.0
    x_2_5     disj2_2_6_3  1.0
    x_2_5     disj1_2_7_3  -1.0
    x_2_5     disj2_2_7_3  1.0
    x_2_5     disj1_2_8_3  -1.0
    x_2_5     disj2_2_8_3  1.0
    x_2_6     prec_2_5  1.0
    x_2_6     mksp_2    -1.0
    x_2_6     disj1_0_2_6  1.0
    x_2_6     disj2_0_2_6  -1.0
    x_2_6     disj1_1_2_6  1.0
    x_2_6     disj2_1_2_6  -1.0
    x_2_6     disj1_2_3_6  -1.0
    x_2_6     disj2_2_3_6  1.0
    x_2_6     disj1_2_4_6  -1.0
    x_2_6     disj2_2_4_6  1.0
    x_2_6     disj1_2_5_6  -1.0
    x_2_6     disj2_2_5_6  1.0
    x_2_6     disj1_2_6_6  -1.0
    x_2_6     disj2_2_6_6  1.0
    x_2_6     disj1_2_7_6  -1.0
    x_2_6     disj2_2_7_6  1.0
    x_2_6     disj1_2_8_6  -1.0
    x_2_6     disj2_2_8_6  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_0  1.0
    x_3_0     disj2_0_3_0  -1.0
    x_3_0     disj1_1_3_0  1.0
    x_3_0     disj2_1_3_0  -1.0
    x_3_0     disj1_2_3_0  1.0
    x_3_0     disj2_2_3_0  -1.0
    x_3_0     disj1_3_4_0  -1.0
    x_3_0     disj2_3_4_0  1.0
    x_3_0     disj1_3_5_0  -1.0
    x_3_0     disj2_3_5_0  1.0
    x_3_0     disj1_3_6_0  -1.0
    x_3_0     disj2_3_6_0  1.0
    x_3_0     disj1_3_7_0  -1.0
    x_3_0     disj2_3_7_0  1.0
    x_3_0     disj1_3_8_0  -1.0
    x_3_0     disj2_3_8_0  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_6  1.0
    x_3_1     disj2_0_3_6  -1.0
    x_3_1     disj1_1_3_6  1.0
    x_3_1     disj2_1_3_6  -1.0
    x_3_1     disj1_2_3_6  1.0
    x_3_1     disj2_2_3_6  -1.0
    x_3_1     disj1_3_4_6  -1.0
    x_3_1     disj2_3_4_6  1.0
    x_3_1     disj1_3_5_6  -1.0
    x_3_1     disj2_3_5_6  1.0
    x_3_1     disj1_3_6_6  -1.0
    x_3_1     disj2_3_6_6  1.0
    x_3_1     disj1_3_7_6  -1.0
    x_3_1     disj2_3_7_6  1.0
    x_3_1     disj1_3_8_6  -1.0
    x_3_1     disj2_3_8_6  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_1  1.0
    x_3_2     disj2_0_3_1  -1.0
    x_3_2     disj1_1_3_1  1.0
    x_3_2     disj2_1_3_1  -1.0
    x_3_2     disj1_2_3_1  1.0
    x_3_2     disj2_2_3_1  -1.0
    x_3_2     disj1_3_4_1  -1.0
    x_3_2     disj2_3_4_1  1.0
    x_3_2     disj1_3_5_1  -1.0
    x_3_2     disj2_3_5_1  1.0
    x_3_2     disj1_3_6_1  -1.0
    x_3_2     disj2_3_6_1  1.0
    x_3_2     disj1_3_7_1  -1.0
    x_3_2     disj2_3_7_1  1.0
    x_3_2     disj1_3_8_1  -1.0
    x_3_2     disj2_3_8_1  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_5  1.0
    x_3_3     disj2_0_3_5  -1.0
    x_3_3     disj1_1_3_5  1.0
    x_3_3     disj2_1_3_5  -1.0
    x_3_3     disj1_2_3_5  1.0
    x_3_3     disj2_2_3_5  -1.0
    x_3_3     disj1_3_4_5  -1.0
    x_3_3     disj2_3_4_5  1.0
    x_3_3     disj1_3_5_5  -1.0
    x_3_3     disj2_3_5_5  1.0
    x_3_3     disj1_3_6_5  -1.0
    x_3_3     disj2_3_6_5  1.0
    x_3_3     disj1_3_7_5  -1.0
    x_3_3     disj2_3_7_5  1.0
    x_3_3     disj1_3_8_5  -1.0
    x_3_3     disj2_3_8_5  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_3  1.0
    x_3_4     disj2_0_3_3  -1.0
    x_3_4     disj1_1_3_3  1.0
    x_3_4     disj2_1_3_3  -1.0
    x_3_4     disj1_2_3_3  1.0
    x_3_4     disj2_2_3_3  -1.0
    x_3_4     disj1_3_4_3  -1.0
    x_3_4     disj2_3_4_3  1.0
    x_3_4     disj1_3_5_3  -1.0
    x_3_4     disj2_3_5_3  1.0
    x_3_4     disj1_3_6_3  -1.0
    x_3_4     disj2_3_6_3  1.0
    x_3_4     disj1_3_7_3  -1.0
    x_3_4     disj2_3_7_3  1.0
    x_3_4     disj1_3_8_3  -1.0
    x_3_4     disj2_3_8_3  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     prec_3_5  -1.0
    x_3_5     disj1_0_3_2  1.0
    x_3_5     disj2_0_3_2  -1.0
    x_3_5     disj1_1_3_2  1.0
    x_3_5     disj2_1_3_2  -1.0
    x_3_5     disj1_2_3_2  1.0
    x_3_5     disj2_2_3_2  -1.0
    x_3_5     disj1_3_4_2  -1.0
    x_3_5     disj2_3_4_2  1.0
    x_3_5     disj1_3_5_2  -1.0
    x_3_5     disj2_3_5_2  1.0
    x_3_5     disj1_3_6_2  -1.0
    x_3_5     disj2_3_6_2  1.0
    x_3_5     disj1_3_7_2  -1.0
    x_3_5     disj2_3_7_2  1.0
    x_3_5     disj1_3_8_2  -1.0
    x_3_5     disj2_3_8_2  1.0
    x_3_6     prec_3_5  1.0
    x_3_6     mksp_3    -1.0
    x_3_6     disj1_0_3_4  1.0
    x_3_6     disj2_0_3_4  -1.0
    x_3_6     disj1_1_3_4  1.0
    x_3_6     disj2_1_3_4  -1.0
    x_3_6     disj1_2_3_4  1.0
    x_3_6     disj2_2_3_4  -1.0
    x_3_6     disj1_3_4_4  -1.0
    x_3_6     disj2_3_4_4  1.0
    x_3_6     disj1_3_5_4  -1.0
    x_3_6     disj2_3_5_4  1.0
    x_3_6     disj1_3_6_4  -1.0
    x_3_6     disj2_3_6_4  1.0
    x_3_6     disj1_3_7_4  -1.0
    x_3_6     disj2_3_7_4  1.0
    x_3_6     disj1_3_8_4  -1.0
    x_3_6     disj2_3_8_4  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_2  1.0
    x_4_0     disj2_0_4_2  -1.0
    x_4_0     disj1_1_4_2  1.0
    x_4_0     disj2_1_4_2  -1.0
    x_4_0     disj1_2_4_2  1.0
    x_4_0     disj2_2_4_2  -1.0
    x_4_0     disj1_3_4_2  1.0
    x_4_0     disj2_3_4_2  -1.0
    x_4_0     disj1_4_5_2  -1.0
    x_4_0     disj2_4_5_2  1.0
    x_4_0     disj1_4_6_2  -1.0
    x_4_0     disj2_4_6_2  1.0
    x_4_0     disj1_4_7_2  -1.0
    x_4_0     disj2_4_7_2  1.0
    x_4_0     disj1_4_8_2  -1.0
    x_4_0     disj2_4_8_2  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_6  1.0
    x_4_1     disj2_0_4_6  -1.0
    x_4_1     disj1_1_4_6  1.0
    x_4_1     disj2_1_4_6  -1.0
    x_4_1     disj1_2_4_6  1.0
    x_4_1     disj2_2_4_6  -1.0
    x_4_1     disj1_3_4_6  1.0
    x_4_1     disj2_3_4_6  -1.0
    x_4_1     disj1_4_5_6  -1.0
    x_4_1     disj2_4_5_6  1.0
    x_4_1     disj1_4_6_6  -1.0
    x_4_1     disj2_4_6_6  1.0
    x_4_1     disj1_4_7_6  -1.0
    x_4_1     disj2_4_7_6  1.0
    x_4_1     disj1_4_8_6  -1.0
    x_4_1     disj2_4_8_6  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_3  1.0
    x_4_2     disj2_0_4_3  -1.0
    x_4_2     disj1_1_4_3  1.0
    x_4_2     disj2_1_4_3  -1.0
    x_4_2     disj1_2_4_3  1.0
    x_4_2     disj2_2_4_3  -1.0
    x_4_2     disj1_3_4_3  1.0
    x_4_2     disj2_3_4_3  -1.0
    x_4_2     disj1_4_5_3  -1.0
    x_4_2     disj2_4_5_3  1.0
    x_4_2     disj1_4_6_3  -1.0
    x_4_2     disj2_4_6_3  1.0
    x_4_2     disj1_4_7_3  -1.0
    x_4_2     disj2_4_7_3  1.0
    x_4_2     disj1_4_8_3  -1.0
    x_4_2     disj2_4_8_3  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_3     disj1_4_7_1  -1.0
    x_4_3     disj2_4_7_1  1.0
    x_4_3     disj1_4_8_1  -1.0
    x_4_3     disj2_4_8_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_4  1.0
    x_4_4     disj2_0_4_4  -1.0
    x_4_4     disj1_1_4_4  1.0
    x_4_4     disj2_1_4_4  -1.0
    x_4_4     disj1_2_4_4  1.0
    x_4_4     disj2_2_4_4  -1.0
    x_4_4     disj1_3_4_4  1.0
    x_4_4     disj2_3_4_4  -1.0
    x_4_4     disj1_4_5_4  -1.0
    x_4_4     disj2_4_5_4  1.0
    x_4_4     disj1_4_6_4  -1.0
    x_4_4     disj2_4_6_4  1.0
    x_4_4     disj1_4_7_4  -1.0
    x_4_4     disj2_4_7_4  1.0
    x_4_4     disj1_4_8_4  -1.0
    x_4_4     disj2_4_8_4  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     prec_4_5  -1.0
    x_4_5     disj1_0_4_0  1.0
    x_4_5     disj2_0_4_0  -1.0
    x_4_5     disj1_1_4_0  1.0
    x_4_5     disj2_1_4_0  -1.0
    x_4_5     disj1_2_4_0  1.0
    x_4_5     disj2_2_4_0  -1.0
    x_4_5     disj1_3_4_0  1.0
    x_4_5     disj2_3_4_0  -1.0
    x_4_5     disj1_4_5_0  -1.0
    x_4_5     disj2_4_5_0  1.0
    x_4_5     disj1_4_6_0  -1.0
    x_4_5     disj2_4_6_0  1.0
    x_4_5     disj1_4_7_0  -1.0
    x_4_5     disj2_4_7_0  1.0
    x_4_5     disj1_4_8_0  -1.0
    x_4_5     disj2_4_8_0  1.0
    x_4_6     prec_4_5  1.0
    x_4_6     mksp_4    -1.0
    x_4_6     disj1_0_4_5  1.0
    x_4_6     disj2_0_4_5  -1.0
    x_4_6     disj1_1_4_5  1.0
    x_4_6     disj2_1_4_5  -1.0
    x_4_6     disj1_2_4_5  1.0
    x_4_6     disj2_2_4_5  -1.0
    x_4_6     disj1_3_4_5  1.0
    x_4_6     disj2_3_4_5  -1.0
    x_4_6     disj1_4_5_5  -1.0
    x_4_6     disj2_4_5_5  1.0
    x_4_6     disj1_4_6_5  -1.0
    x_4_6     disj2_4_6_5  1.0
    x_4_6     disj1_4_7_5  -1.0
    x_4_6     disj2_4_7_5  1.0
    x_4_6     disj1_4_8_5  -1.0
    x_4_6     disj2_4_8_5  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_2  1.0
    x_5_0     disj2_0_5_2  -1.0
    x_5_0     disj1_1_5_2  1.0
    x_5_0     disj2_1_5_2  -1.0
    x_5_0     disj1_2_5_2  1.0
    x_5_0     disj2_2_5_2  -1.0
    x_5_0     disj1_3_5_2  1.0
    x_5_0     disj2_3_5_2  -1.0
    x_5_0     disj1_4_5_2  1.0
    x_5_0     disj2_4_5_2  -1.0
    x_5_0     disj1_5_6_2  -1.0
    x_5_0     disj2_5_6_2  1.0
    x_5_0     disj1_5_7_2  -1.0
    x_5_0     disj2_5_7_2  1.0
    x_5_0     disj1_5_8_2  -1.0
    x_5_0     disj2_5_8_2  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_3  1.0
    x_5_1     disj2_0_5_3  -1.0
    x_5_1     disj1_1_5_3  1.0
    x_5_1     disj2_1_5_3  -1.0
    x_5_1     disj1_2_5_3  1.0
    x_5_1     disj2_2_5_3  -1.0
    x_5_1     disj1_3_5_3  1.0
    x_5_1     disj2_3_5_3  -1.0
    x_5_1     disj1_4_5_3  1.0
    x_5_1     disj2_4_5_3  -1.0
    x_5_1     disj1_5_6_3  -1.0
    x_5_1     disj2_5_6_3  1.0
    x_5_1     disj1_5_7_3  -1.0
    x_5_1     disj2_5_7_3  1.0
    x_5_1     disj1_5_8_3  -1.0
    x_5_1     disj2_5_8_3  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_4  1.0
    x_5_2     disj2_0_5_4  -1.0
    x_5_2     disj1_1_5_4  1.0
    x_5_2     disj2_1_5_4  -1.0
    x_5_2     disj1_2_5_4  1.0
    x_5_2     disj2_2_5_4  -1.0
    x_5_2     disj1_3_5_4  1.0
    x_5_2     disj2_3_5_4  -1.0
    x_5_2     disj1_4_5_4  1.0
    x_5_2     disj2_4_5_4  -1.0
    x_5_2     disj1_5_6_4  -1.0
    x_5_2     disj2_5_6_4  1.0
    x_5_2     disj1_5_7_4  -1.0
    x_5_2     disj2_5_7_4  1.0
    x_5_2     disj1_5_8_4  -1.0
    x_5_2     disj2_5_8_4  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_0  1.0
    x_5_3     disj2_0_5_0  -1.0
    x_5_3     disj1_1_5_0  1.0
    x_5_3     disj2_1_5_0  -1.0
    x_5_3     disj1_2_5_0  1.0
    x_5_3     disj2_2_5_0  -1.0
    x_5_3     disj1_3_5_0  1.0
    x_5_3     disj2_3_5_0  -1.0
    x_5_3     disj1_4_5_0  1.0
    x_5_3     disj2_4_5_0  -1.0
    x_5_3     disj1_5_6_0  -1.0
    x_5_3     disj2_5_6_0  1.0
    x_5_3     disj1_5_7_0  -1.0
    x_5_3     disj2_5_7_0  1.0
    x_5_3     disj1_5_8_0  -1.0
    x_5_3     disj2_5_8_0  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_5  1.0
    x_5_4     disj2_0_5_5  -1.0
    x_5_4     disj1_1_5_5  1.0
    x_5_4     disj2_1_5_5  -1.0
    x_5_4     disj1_2_5_5  1.0
    x_5_4     disj2_2_5_5  -1.0
    x_5_4     disj1_3_5_5  1.0
    x_5_4     disj2_3_5_5  -1.0
    x_5_4     disj1_4_5_5  1.0
    x_5_4     disj2_4_5_5  -1.0
    x_5_4     disj1_5_6_5  -1.0
    x_5_4     disj2_5_6_5  1.0
    x_5_4     disj1_5_7_5  -1.0
    x_5_4     disj2_5_7_5  1.0
    x_5_4     disj1_5_8_5  -1.0
    x_5_4     disj2_5_8_5  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     prec_5_5  -1.0
    x_5_5     disj1_0_5_1  1.0
    x_5_5     disj2_0_5_1  -1.0
    x_5_5     disj1_1_5_1  1.0
    x_5_5     disj2_1_5_1  -1.0
    x_5_5     disj1_2_5_1  1.0
    x_5_5     disj2_2_5_1  -1.0
    x_5_5     disj1_3_5_1  1.0
    x_5_5     disj2_3_5_1  -1.0
    x_5_5     disj1_4_5_1  1.0
    x_5_5     disj2_4_5_1  -1.0
    x_5_5     disj1_5_6_1  -1.0
    x_5_5     disj2_5_6_1  1.0
    x_5_5     disj1_5_7_1  -1.0
    x_5_5     disj2_5_7_1  1.0
    x_5_5     disj1_5_8_1  -1.0
    x_5_5     disj2_5_8_1  1.0
    x_5_6     prec_5_5  1.0
    x_5_6     mksp_5    -1.0
    x_5_6     disj1_0_5_6  1.0
    x_5_6     disj2_0_5_6  -1.0
    x_5_6     disj1_1_5_6  1.0
    x_5_6     disj2_1_5_6  -1.0
    x_5_6     disj1_2_5_6  1.0
    x_5_6     disj2_2_5_6  -1.0
    x_5_6     disj1_3_5_6  1.0
    x_5_6     disj2_3_5_6  -1.0
    x_5_6     disj1_4_5_6  1.0
    x_5_6     disj2_4_5_6  -1.0
    x_5_6     disj1_5_6_6  -1.0
    x_5_6     disj2_5_6_6  1.0
    x_5_6     disj1_5_7_6  -1.0
    x_5_6     disj2_5_7_6  1.0
    x_5_6     disj1_5_8_6  -1.0
    x_5_6     disj2_5_8_6  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_4  1.0
    x_6_0     disj2_0_6_4  -1.0
    x_6_0     disj1_1_6_4  1.0
    x_6_0     disj2_1_6_4  -1.0
    x_6_0     disj1_2_6_4  1.0
    x_6_0     disj2_2_6_4  -1.0
    x_6_0     disj1_3_6_4  1.0
    x_6_0     disj2_3_6_4  -1.0
    x_6_0     disj1_4_6_4  1.0
    x_6_0     disj2_4_6_4  -1.0
    x_6_0     disj1_5_6_4  1.0
    x_6_0     disj2_5_6_4  -1.0
    x_6_0     disj1_6_7_4  -1.0
    x_6_0     disj2_6_7_4  1.0
    x_6_0     disj1_6_8_4  -1.0
    x_6_0     disj2_6_8_4  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_1  1.0
    x_6_1     disj2_0_6_1  -1.0
    x_6_1     disj1_1_6_1  1.0
    x_6_1     disj2_1_6_1  -1.0
    x_6_1     disj1_2_6_1  1.0
    x_6_1     disj2_2_6_1  -1.0
    x_6_1     disj1_3_6_1  1.0
    x_6_1     disj2_3_6_1  -1.0
    x_6_1     disj1_4_6_1  1.0
    x_6_1     disj2_4_6_1  -1.0
    x_6_1     disj1_5_6_1  1.0
    x_6_1     disj2_5_6_1  -1.0
    x_6_1     disj1_6_7_1  -1.0
    x_6_1     disj2_6_7_1  1.0
    x_6_1     disj1_6_8_1  -1.0
    x_6_1     disj2_6_8_1  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_3  1.0
    x_6_2     disj2_0_6_3  -1.0
    x_6_2     disj1_1_6_3  1.0
    x_6_2     disj2_1_6_3  -1.0
    x_6_2     disj1_2_6_3  1.0
    x_6_2     disj2_2_6_3  -1.0
    x_6_2     disj1_3_6_3  1.0
    x_6_2     disj2_3_6_3  -1.0
    x_6_2     disj1_4_6_3  1.0
    x_6_2     disj2_4_6_3  -1.0
    x_6_2     disj1_5_6_3  1.0
    x_6_2     disj2_5_6_3  -1.0
    x_6_2     disj1_6_7_3  -1.0
    x_6_2     disj2_6_7_3  1.0
    x_6_2     disj1_6_8_3  -1.0
    x_6_2     disj2_6_8_3  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_0  1.0
    x_6_3     disj2_0_6_0  -1.0
    x_6_3     disj1_1_6_0  1.0
    x_6_3     disj2_1_6_0  -1.0
    x_6_3     disj1_2_6_0  1.0
    x_6_3     disj2_2_6_0  -1.0
    x_6_3     disj1_3_6_0  1.0
    x_6_3     disj2_3_6_0  -1.0
    x_6_3     disj1_4_6_0  1.0
    x_6_3     disj2_4_6_0  -1.0
    x_6_3     disj1_5_6_0  1.0
    x_6_3     disj2_5_6_0  -1.0
    x_6_3     disj1_6_7_0  -1.0
    x_6_3     disj2_6_7_0  1.0
    x_6_3     disj1_6_8_0  -1.0
    x_6_3     disj2_6_8_0  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_2  1.0
    x_6_4     disj2_0_6_2  -1.0
    x_6_4     disj1_1_6_2  1.0
    x_6_4     disj2_1_6_2  -1.0
    x_6_4     disj1_2_6_2  1.0
    x_6_4     disj2_2_6_2  -1.0
    x_6_4     disj1_3_6_2  1.0
    x_6_4     disj2_3_6_2  -1.0
    x_6_4     disj1_4_6_2  1.0
    x_6_4     disj2_4_6_2  -1.0
    x_6_4     disj1_5_6_2  1.0
    x_6_4     disj2_5_6_2  -1.0
    x_6_4     disj1_6_7_2  -1.0
    x_6_4     disj2_6_7_2  1.0
    x_6_4     disj1_6_8_2  -1.0
    x_6_4     disj2_6_8_2  1.0
    x_6_5     prec_6_4  1.0
    x_6_5     prec_6_5  -1.0
    x_6_5     disj1_0_6_6  1.0
    x_6_5     disj2_0_6_6  -1.0
    x_6_5     disj1_1_6_6  1.0
    x_6_5     disj2_1_6_6  -1.0
    x_6_5     disj1_2_6_6  1.0
    x_6_5     disj2_2_6_6  -1.0
    x_6_5     disj1_3_6_6  1.0
    x_6_5     disj2_3_6_6  -1.0
    x_6_5     disj1_4_6_6  1.0
    x_6_5     disj2_4_6_6  -1.0
    x_6_5     disj1_5_6_6  1.0
    x_6_5     disj2_5_6_6  -1.0
    x_6_5     disj1_6_7_6  -1.0
    x_6_5     disj2_6_7_6  1.0
    x_6_5     disj1_6_8_6  -1.0
    x_6_5     disj2_6_8_6  1.0
    x_6_6     prec_6_5  1.0
    x_6_6     mksp_6    -1.0
    x_6_6     disj1_0_6_5  1.0
    x_6_6     disj2_0_6_5  -1.0
    x_6_6     disj1_1_6_5  1.0
    x_6_6     disj2_1_6_5  -1.0
    x_6_6     disj1_2_6_5  1.0
    x_6_6     disj2_2_6_5  -1.0
    x_6_6     disj1_3_6_5  1.0
    x_6_6     disj2_3_6_5  -1.0
    x_6_6     disj1_4_6_5  1.0
    x_6_6     disj2_4_6_5  -1.0
    x_6_6     disj1_5_6_5  1.0
    x_6_6     disj2_5_6_5  -1.0
    x_6_6     disj1_6_7_5  -1.0
    x_6_6     disj2_6_7_5  1.0
    x_6_6     disj1_6_8_5  -1.0
    x_6_6     disj2_6_8_5  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_4  1.0
    x_7_0     disj2_0_7_4  -1.0
    x_7_0     disj1_1_7_4  1.0
    x_7_0     disj2_1_7_4  -1.0
    x_7_0     disj1_2_7_4  1.0
    x_7_0     disj2_2_7_4  -1.0
    x_7_0     disj1_3_7_4  1.0
    x_7_0     disj2_3_7_4  -1.0
    x_7_0     disj1_4_7_4  1.0
    x_7_0     disj2_4_7_4  -1.0
    x_7_0     disj1_5_7_4  1.0
    x_7_0     disj2_5_7_4  -1.0
    x_7_0     disj1_6_7_4  1.0
    x_7_0     disj2_6_7_4  -1.0
    x_7_0     disj1_7_8_4  -1.0
    x_7_0     disj2_7_8_4  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_5  1.0
    x_7_1     disj2_0_7_5  -1.0
    x_7_1     disj1_1_7_5  1.0
    x_7_1     disj2_1_7_5  -1.0
    x_7_1     disj1_2_7_5  1.0
    x_7_1     disj2_2_7_5  -1.0
    x_7_1     disj1_3_7_5  1.0
    x_7_1     disj2_3_7_5  -1.0
    x_7_1     disj1_4_7_5  1.0
    x_7_1     disj2_4_7_5  -1.0
    x_7_1     disj1_5_7_5  1.0
    x_7_1     disj2_5_7_5  -1.0
    x_7_1     disj1_6_7_5  1.0
    x_7_1     disj2_6_7_5  -1.0
    x_7_1     disj1_7_8_5  -1.0
    x_7_1     disj2_7_8_5  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_2  1.0
    x_7_2     disj2_0_7_2  -1.0
    x_7_2     disj1_1_7_2  1.0
    x_7_2     disj2_1_7_2  -1.0
    x_7_2     disj1_2_7_2  1.0
    x_7_2     disj2_2_7_2  -1.0
    x_7_2     disj1_3_7_2  1.0
    x_7_2     disj2_3_7_2  -1.0
    x_7_2     disj1_4_7_2  1.0
    x_7_2     disj2_4_7_2  -1.0
    x_7_2     disj1_5_7_2  1.0
    x_7_2     disj2_5_7_2  -1.0
    x_7_2     disj1_6_7_2  1.0
    x_7_2     disj2_6_7_2  -1.0
    x_7_2     disj1_7_8_2  -1.0
    x_7_2     disj2_7_8_2  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_6  1.0
    x_7_3     disj2_0_7_6  -1.0
    x_7_3     disj1_1_7_6  1.0
    x_7_3     disj2_1_7_6  -1.0
    x_7_3     disj1_2_7_6  1.0
    x_7_3     disj2_2_7_6  -1.0
    x_7_3     disj1_3_7_6  1.0
    x_7_3     disj2_3_7_6  -1.0
    x_7_3     disj1_4_7_6  1.0
    x_7_3     disj2_4_7_6  -1.0
    x_7_3     disj1_5_7_6  1.0
    x_7_3     disj2_5_7_6  -1.0
    x_7_3     disj1_6_7_6  1.0
    x_7_3     disj2_6_7_6  -1.0
    x_7_3     disj1_7_8_6  -1.0
    x_7_3     disj2_7_8_6  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     prec_7_4  -1.0
    x_7_4     disj1_0_7_3  1.0
    x_7_4     disj2_0_7_3  -1.0
    x_7_4     disj1_1_7_3  1.0
    x_7_4     disj2_1_7_3  -1.0
    x_7_4     disj1_2_7_3  1.0
    x_7_4     disj2_2_7_3  -1.0
    x_7_4     disj1_3_7_3  1.0
    x_7_4     disj2_3_7_3  -1.0
    x_7_4     disj1_4_7_3  1.0
    x_7_4     disj2_4_7_3  -1.0
    x_7_4     disj1_5_7_3  1.0
    x_7_4     disj2_5_7_3  -1.0
    x_7_4     disj1_6_7_3  1.0
    x_7_4     disj2_6_7_3  -1.0
    x_7_4     disj1_7_8_3  -1.0
    x_7_4     disj2_7_8_3  1.0
    x_7_5     prec_7_4  1.0
    x_7_5     prec_7_5  -1.0
    x_7_5     disj1_0_7_0  1.0
    x_7_5     disj2_0_7_0  -1.0
    x_7_5     disj1_1_7_0  1.0
    x_7_5     disj2_1_7_0  -1.0
    x_7_5     disj1_2_7_0  1.0
    x_7_5     disj2_2_7_0  -1.0
    x_7_5     disj1_3_7_0  1.0
    x_7_5     disj2_3_7_0  -1.0
    x_7_5     disj1_4_7_0  1.0
    x_7_5     disj2_4_7_0  -1.0
    x_7_5     disj1_5_7_0  1.0
    x_7_5     disj2_5_7_0  -1.0
    x_7_5     disj1_6_7_0  1.0
    x_7_5     disj2_6_7_0  -1.0
    x_7_5     disj1_7_8_0  -1.0
    x_7_5     disj2_7_8_0  1.0
    x_7_6     prec_7_5  1.0
    x_7_6     mksp_7    -1.0
    x_7_6     disj1_0_7_1  1.0
    x_7_6     disj2_0_7_1  -1.0
    x_7_6     disj1_1_7_1  1.0
    x_7_6     disj2_1_7_1  -1.0
    x_7_6     disj1_2_7_1  1.0
    x_7_6     disj2_2_7_1  -1.0
    x_7_6     disj1_3_7_1  1.0
    x_7_6     disj2_3_7_1  -1.0
    x_7_6     disj1_4_7_1  1.0
    x_7_6     disj2_4_7_1  -1.0
    x_7_6     disj1_5_7_1  1.0
    x_7_6     disj2_5_7_1  -1.0
    x_7_6     disj1_6_7_1  1.0
    x_7_6     disj2_6_7_1  -1.0
    x_7_6     disj1_7_8_1  -1.0
    x_7_6     disj2_7_8_1  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_3  1.0
    x_8_0     disj2_0_8_3  -1.0
    x_8_0     disj1_1_8_3  1.0
    x_8_0     disj2_1_8_3  -1.0
    x_8_0     disj1_2_8_3  1.0
    x_8_0     disj2_2_8_3  -1.0
    x_8_0     disj1_3_8_3  1.0
    x_8_0     disj2_3_8_3  -1.0
    x_8_0     disj1_4_8_3  1.0
    x_8_0     disj2_4_8_3  -1.0
    x_8_0     disj1_5_8_3  1.0
    x_8_0     disj2_5_8_3  -1.0
    x_8_0     disj1_6_8_3  1.0
    x_8_0     disj2_6_8_3  -1.0
    x_8_0     disj1_7_8_3  1.0
    x_8_0     disj2_7_8_3  -1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_2  1.0
    x_8_1     disj2_0_8_2  -1.0
    x_8_1     disj1_1_8_2  1.0
    x_8_1     disj2_1_8_2  -1.0
    x_8_1     disj1_2_8_2  1.0
    x_8_1     disj2_2_8_2  -1.0
    x_8_1     disj1_3_8_2  1.0
    x_8_1     disj2_3_8_2  -1.0
    x_8_1     disj1_4_8_2  1.0
    x_8_1     disj2_4_8_2  -1.0
    x_8_1     disj1_5_8_2  1.0
    x_8_1     disj2_5_8_2  -1.0
    x_8_1     disj1_6_8_2  1.0
    x_8_1     disj2_6_8_2  -1.0
    x_8_1     disj1_7_8_2  1.0
    x_8_1     disj2_7_8_2  -1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_6  1.0
    x_8_2     disj2_0_8_6  -1.0
    x_8_2     disj1_1_8_6  1.0
    x_8_2     disj2_1_8_6  -1.0
    x_8_2     disj1_2_8_6  1.0
    x_8_2     disj2_2_8_6  -1.0
    x_8_2     disj1_3_8_6  1.0
    x_8_2     disj2_3_8_6  -1.0
    x_8_2     disj1_4_8_6  1.0
    x_8_2     disj2_4_8_6  -1.0
    x_8_2     disj1_5_8_6  1.0
    x_8_2     disj2_5_8_6  -1.0
    x_8_2     disj1_6_8_6  1.0
    x_8_2     disj2_6_8_6  -1.0
    x_8_2     disj1_7_8_6  1.0
    x_8_2     disj2_7_8_6  -1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_1  1.0
    x_8_3     disj2_0_8_1  -1.0
    x_8_3     disj1_1_8_1  1.0
    x_8_3     disj2_1_8_1  -1.0
    x_8_3     disj1_2_8_1  1.0
    x_8_3     disj2_2_8_1  -1.0
    x_8_3     disj1_3_8_1  1.0
    x_8_3     disj2_3_8_1  -1.0
    x_8_3     disj1_4_8_1  1.0
    x_8_3     disj2_4_8_1  -1.0
    x_8_3     disj1_5_8_1  1.0
    x_8_3     disj2_5_8_1  -1.0
    x_8_3     disj1_6_8_1  1.0
    x_8_3     disj2_6_8_1  -1.0
    x_8_3     disj1_7_8_1  1.0
    x_8_3     disj2_7_8_1  -1.0
    x_8_4     prec_8_3  1.0
    x_8_4     prec_8_4  -1.0
    x_8_4     disj1_0_8_0  1.0
    x_8_4     disj2_0_8_0  -1.0
    x_8_4     disj1_1_8_0  1.0
    x_8_4     disj2_1_8_0  -1.0
    x_8_4     disj1_2_8_0  1.0
    x_8_4     disj2_2_8_0  -1.0
    x_8_4     disj1_3_8_0  1.0
    x_8_4     disj2_3_8_0  -1.0
    x_8_4     disj1_4_8_0  1.0
    x_8_4     disj2_4_8_0  -1.0
    x_8_4     disj1_5_8_0  1.0
    x_8_4     disj2_5_8_0  -1.0
    x_8_4     disj1_6_8_0  1.0
    x_8_4     disj2_6_8_0  -1.0
    x_8_4     disj1_7_8_0  1.0
    x_8_4     disj2_7_8_0  -1.0
    x_8_5     prec_8_4  1.0
    x_8_5     prec_8_5  -1.0
    x_8_5     disj1_0_8_5  1.0
    x_8_5     disj2_0_8_5  -1.0
    x_8_5     disj1_1_8_5  1.0
    x_8_5     disj2_1_8_5  -1.0
    x_8_5     disj1_2_8_5  1.0
    x_8_5     disj2_2_8_5  -1.0
    x_8_5     disj1_3_8_5  1.0
    x_8_5     disj2_3_8_5  -1.0
    x_8_5     disj1_4_8_5  1.0
    x_8_5     disj2_4_8_5  -1.0
    x_8_5     disj1_5_8_5  1.0
    x_8_5     disj2_5_8_5  -1.0
    x_8_5     disj1_6_8_5  1.0
    x_8_5     disj2_6_8_5  -1.0
    x_8_5     disj1_7_8_5  1.0
    x_8_5     disj2_7_8_5  -1.0
    x_8_6     prec_8_5  1.0
    x_8_6     mksp_8    -1.0
    x_8_6     disj1_0_8_4  1.0
    x_8_6     disj2_0_8_4  -1.0
    x_8_6     disj1_1_8_4  1.0
    x_8_6     disj2_1_8_4  -1.0
    x_8_6     disj1_2_8_4  1.0
    x_8_6     disj2_2_8_4  -1.0
    x_8_6     disj1_3_8_4  1.0
    x_8_6     disj2_3_8_4  -1.0
    x_8_6     disj1_4_8_4  1.0
    x_8_6     disj2_4_8_4  -1.0
    x_8_6     disj1_5_8_4  1.0
    x_8_6     disj2_5_8_4  -1.0
    x_8_6     disj1_6_8_4  1.0
    x_8_6     disj2_6_8_4  -1.0
    x_8_6     disj1_7_8_4  1.0
    x_8_6     disj2_7_8_4  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  2819
    y_0_1_0   disj2_0_1_0  -2819
    y_0_1_1   disj1_0_1_1  2819
    y_0_1_1   disj2_0_1_1  -2819
    y_0_1_2   disj1_0_1_2  2819
    y_0_1_2   disj2_0_1_2  -2819
    y_0_1_3   disj1_0_1_3  2819
    y_0_1_3   disj2_0_1_3  -2819
    y_0_1_4   disj1_0_1_4  2819
    y_0_1_4   disj2_0_1_4  -2819
    y_0_1_5   disj1_0_1_5  2819
    y_0_1_5   disj2_0_1_5  -2819
    y_0_1_6   disj1_0_1_6  2819
    y_0_1_6   disj2_0_1_6  -2819
    y_0_2_0   disj1_0_2_0  2819
    y_0_2_0   disj2_0_2_0  -2819
    y_0_2_1   disj1_0_2_1  2819
    y_0_2_1   disj2_0_2_1  -2819
    y_0_2_2   disj1_0_2_2  2819
    y_0_2_2   disj2_0_2_2  -2819
    y_0_2_3   disj1_0_2_3  2819
    y_0_2_3   disj2_0_2_3  -2819
    y_0_2_4   disj1_0_2_4  2819
    y_0_2_4   disj2_0_2_4  -2819
    y_0_2_5   disj1_0_2_5  2819
    y_0_2_5   disj2_0_2_5  -2819
    y_0_2_6   disj1_0_2_6  2819
    y_0_2_6   disj2_0_2_6  -2819
    y_0_3_0   disj1_0_3_0  2819
    y_0_3_0   disj2_0_3_0  -2819
    y_0_3_1   disj1_0_3_1  2819
    y_0_3_1   disj2_0_3_1  -2819
    y_0_3_2   disj1_0_3_2  2819
    y_0_3_2   disj2_0_3_2  -2819
    y_0_3_3   disj1_0_3_3  2819
    y_0_3_3   disj2_0_3_3  -2819
    y_0_3_4   disj1_0_3_4  2819
    y_0_3_4   disj2_0_3_4  -2819
    y_0_3_5   disj1_0_3_5  2819
    y_0_3_5   disj2_0_3_5  -2819
    y_0_3_6   disj1_0_3_6  2819
    y_0_3_6   disj2_0_3_6  -2819
    y_0_4_0   disj1_0_4_0  2819
    y_0_4_0   disj2_0_4_0  -2819
    y_0_4_1   disj1_0_4_1  2819
    y_0_4_1   disj2_0_4_1  -2819
    y_0_4_2   disj1_0_4_2  2819
    y_0_4_2   disj2_0_4_2  -2819
    y_0_4_3   disj1_0_4_3  2819
    y_0_4_3   disj2_0_4_3  -2819
    y_0_4_4   disj1_0_4_4  2819
    y_0_4_4   disj2_0_4_4  -2819
    y_0_4_5   disj1_0_4_5  2819
    y_0_4_5   disj2_0_4_5  -2819
    y_0_4_6   disj1_0_4_6  2819
    y_0_4_6   disj2_0_4_6  -2819
    y_0_5_0   disj1_0_5_0  2819
    y_0_5_0   disj2_0_5_0  -2819
    y_0_5_1   disj1_0_5_1  2819
    y_0_5_1   disj2_0_5_1  -2819
    y_0_5_2   disj1_0_5_2  2819
    y_0_5_2   disj2_0_5_2  -2819
    y_0_5_3   disj1_0_5_3  2819
    y_0_5_3   disj2_0_5_3  -2819
    y_0_5_4   disj1_0_5_4  2819
    y_0_5_4   disj2_0_5_4  -2819
    y_0_5_5   disj1_0_5_5  2819
    y_0_5_5   disj2_0_5_5  -2819
    y_0_5_6   disj1_0_5_6  2819
    y_0_5_6   disj2_0_5_6  -2819
    y_0_6_0   disj1_0_6_0  2819
    y_0_6_0   disj2_0_6_0  -2819
    y_0_6_1   disj1_0_6_1  2819
    y_0_6_1   disj2_0_6_1  -2819
    y_0_6_2   disj1_0_6_2  2819
    y_0_6_2   disj2_0_6_2  -2819
    y_0_6_3   disj1_0_6_3  2819
    y_0_6_3   disj2_0_6_3  -2819
    y_0_6_4   disj1_0_6_4  2819
    y_0_6_4   disj2_0_6_4  -2819
    y_0_6_5   disj1_0_6_5  2819
    y_0_6_5   disj2_0_6_5  -2819
    y_0_6_6   disj1_0_6_6  2819
    y_0_6_6   disj2_0_6_6  -2819
    y_0_7_0   disj1_0_7_0  2819
    y_0_7_0   disj2_0_7_0  -2819
    y_0_7_1   disj1_0_7_1  2819
    y_0_7_1   disj2_0_7_1  -2819
    y_0_7_2   disj1_0_7_2  2819
    y_0_7_2   disj2_0_7_2  -2819
    y_0_7_3   disj1_0_7_3  2819
    y_0_7_3   disj2_0_7_3  -2819
    y_0_7_4   disj1_0_7_4  2819
    y_0_7_4   disj2_0_7_4  -2819
    y_0_7_5   disj1_0_7_5  2819
    y_0_7_5   disj2_0_7_5  -2819
    y_0_7_6   disj1_0_7_6  2819
    y_0_7_6   disj2_0_7_6  -2819
    y_0_8_0   disj1_0_8_0  2819
    y_0_8_0   disj2_0_8_0  -2819
    y_0_8_1   disj1_0_8_1  2819
    y_0_8_1   disj2_0_8_1  -2819
    y_0_8_2   disj1_0_8_2  2819
    y_0_8_2   disj2_0_8_2  -2819
    y_0_8_3   disj1_0_8_3  2819
    y_0_8_3   disj2_0_8_3  -2819
    y_0_8_4   disj1_0_8_4  2819
    y_0_8_4   disj2_0_8_4  -2819
    y_0_8_5   disj1_0_8_5  2819
    y_0_8_5   disj2_0_8_5  -2819
    y_0_8_6   disj1_0_8_6  2819
    y_0_8_6   disj2_0_8_6  -2819
    y_1_2_0   disj1_1_2_0  2819
    y_1_2_0   disj2_1_2_0  -2819
    y_1_2_1   disj1_1_2_1  2819
    y_1_2_1   disj2_1_2_1  -2819
    y_1_2_2   disj1_1_2_2  2819
    y_1_2_2   disj2_1_2_2  -2819
    y_1_2_3   disj1_1_2_3  2819
    y_1_2_3   disj2_1_2_3  -2819
    y_1_2_4   disj1_1_2_4  2819
    y_1_2_4   disj2_1_2_4  -2819
    y_1_2_5   disj1_1_2_5  2819
    y_1_2_5   disj2_1_2_5  -2819
    y_1_2_6   disj1_1_2_6  2819
    y_1_2_6   disj2_1_2_6  -2819
    y_1_3_0   disj1_1_3_0  2819
    y_1_3_0   disj2_1_3_0  -2819
    y_1_3_1   disj1_1_3_1  2819
    y_1_3_1   disj2_1_3_1  -2819
    y_1_3_2   disj1_1_3_2  2819
    y_1_3_2   disj2_1_3_2  -2819
    y_1_3_3   disj1_1_3_3  2819
    y_1_3_3   disj2_1_3_3  -2819
    y_1_3_4   disj1_1_3_4  2819
    y_1_3_4   disj2_1_3_4  -2819
    y_1_3_5   disj1_1_3_5  2819
    y_1_3_5   disj2_1_3_5  -2819
    y_1_3_6   disj1_1_3_6  2819
    y_1_3_6   disj2_1_3_6  -2819
    y_1_4_0   disj1_1_4_0  2819
    y_1_4_0   disj2_1_4_0  -2819
    y_1_4_1   disj1_1_4_1  2819
    y_1_4_1   disj2_1_4_1  -2819
    y_1_4_2   disj1_1_4_2  2819
    y_1_4_2   disj2_1_4_2  -2819
    y_1_4_3   disj1_1_4_3  2819
    y_1_4_3   disj2_1_4_3  -2819
    y_1_4_4   disj1_1_4_4  2819
    y_1_4_4   disj2_1_4_4  -2819
    y_1_4_5   disj1_1_4_5  2819
    y_1_4_5   disj2_1_4_5  -2819
    y_1_4_6   disj1_1_4_6  2819
    y_1_4_6   disj2_1_4_6  -2819
    y_1_5_0   disj1_1_5_0  2819
    y_1_5_0   disj2_1_5_0  -2819
    y_1_5_1   disj1_1_5_1  2819
    y_1_5_1   disj2_1_5_1  -2819
    y_1_5_2   disj1_1_5_2  2819
    y_1_5_2   disj2_1_5_2  -2819
    y_1_5_3   disj1_1_5_3  2819
    y_1_5_3   disj2_1_5_3  -2819
    y_1_5_4   disj1_1_5_4  2819
    y_1_5_4   disj2_1_5_4  -2819
    y_1_5_5   disj1_1_5_5  2819
    y_1_5_5   disj2_1_5_5  -2819
    y_1_5_6   disj1_1_5_6  2819
    y_1_5_6   disj2_1_5_6  -2819
    y_1_6_0   disj1_1_6_0  2819
    y_1_6_0   disj2_1_6_0  -2819
    y_1_6_1   disj1_1_6_1  2819
    y_1_6_1   disj2_1_6_1  -2819
    y_1_6_2   disj1_1_6_2  2819
    y_1_6_2   disj2_1_6_2  -2819
    y_1_6_3   disj1_1_6_3  2819
    y_1_6_3   disj2_1_6_3  -2819
    y_1_6_4   disj1_1_6_4  2819
    y_1_6_4   disj2_1_6_4  -2819
    y_1_6_5   disj1_1_6_5  2819
    y_1_6_5   disj2_1_6_5  -2819
    y_1_6_6   disj1_1_6_6  2819
    y_1_6_6   disj2_1_6_6  -2819
    y_1_7_0   disj1_1_7_0  2819
    y_1_7_0   disj2_1_7_0  -2819
    y_1_7_1   disj1_1_7_1  2819
    y_1_7_1   disj2_1_7_1  -2819
    y_1_7_2   disj1_1_7_2  2819
    y_1_7_2   disj2_1_7_2  -2819
    y_1_7_3   disj1_1_7_3  2819
    y_1_7_3   disj2_1_7_3  -2819
    y_1_7_4   disj1_1_7_4  2819
    y_1_7_4   disj2_1_7_4  -2819
    y_1_7_5   disj1_1_7_5  2819
    y_1_7_5   disj2_1_7_5  -2819
    y_1_7_6   disj1_1_7_6  2819
    y_1_7_6   disj2_1_7_6  -2819
    y_1_8_0   disj1_1_8_0  2819
    y_1_8_0   disj2_1_8_0  -2819
    y_1_8_1   disj1_1_8_1  2819
    y_1_8_1   disj2_1_8_1  -2819
    y_1_8_2   disj1_1_8_2  2819
    y_1_8_2   disj2_1_8_2  -2819
    y_1_8_3   disj1_1_8_3  2819
    y_1_8_3   disj2_1_8_3  -2819
    y_1_8_4   disj1_1_8_4  2819
    y_1_8_4   disj2_1_8_4  -2819
    y_1_8_5   disj1_1_8_5  2819
    y_1_8_5   disj2_1_8_5  -2819
    y_1_8_6   disj1_1_8_6  2819
    y_1_8_6   disj2_1_8_6  -2819
    y_2_3_0   disj1_2_3_0  2819
    y_2_3_0   disj2_2_3_0  -2819
    y_2_3_1   disj1_2_3_1  2819
    y_2_3_1   disj2_2_3_1  -2819
    y_2_3_2   disj1_2_3_2  2819
    y_2_3_2   disj2_2_3_2  -2819
    y_2_3_3   disj1_2_3_3  2819
    y_2_3_3   disj2_2_3_3  -2819
    y_2_3_4   disj1_2_3_4  2819
    y_2_3_4   disj2_2_3_4  -2819
    y_2_3_5   disj1_2_3_5  2819
    y_2_3_5   disj2_2_3_5  -2819
    y_2_3_6   disj1_2_3_6  2819
    y_2_3_6   disj2_2_3_6  -2819
    y_2_4_0   disj1_2_4_0  2819
    y_2_4_0   disj2_2_4_0  -2819
    y_2_4_1   disj1_2_4_1  2819
    y_2_4_1   disj2_2_4_1  -2819
    y_2_4_2   disj1_2_4_2  2819
    y_2_4_2   disj2_2_4_2  -2819
    y_2_4_3   disj1_2_4_3  2819
    y_2_4_3   disj2_2_4_3  -2819
    y_2_4_4   disj1_2_4_4  2819
    y_2_4_4   disj2_2_4_4  -2819
    y_2_4_5   disj1_2_4_5  2819
    y_2_4_5   disj2_2_4_5  -2819
    y_2_4_6   disj1_2_4_6  2819
    y_2_4_6   disj2_2_4_6  -2819
    y_2_5_0   disj1_2_5_0  2819
    y_2_5_0   disj2_2_5_0  -2819
    y_2_5_1   disj1_2_5_1  2819
    y_2_5_1   disj2_2_5_1  -2819
    y_2_5_2   disj1_2_5_2  2819
    y_2_5_2   disj2_2_5_2  -2819
    y_2_5_3   disj1_2_5_3  2819
    y_2_5_3   disj2_2_5_3  -2819
    y_2_5_4   disj1_2_5_4  2819
    y_2_5_4   disj2_2_5_4  -2819
    y_2_5_5   disj1_2_5_5  2819
    y_2_5_5   disj2_2_5_5  -2819
    y_2_5_6   disj1_2_5_6  2819
    y_2_5_6   disj2_2_5_6  -2819
    y_2_6_0   disj1_2_6_0  2819
    y_2_6_0   disj2_2_6_0  -2819
    y_2_6_1   disj1_2_6_1  2819
    y_2_6_1   disj2_2_6_1  -2819
    y_2_6_2   disj1_2_6_2  2819
    y_2_6_2   disj2_2_6_2  -2819
    y_2_6_3   disj1_2_6_3  2819
    y_2_6_3   disj2_2_6_3  -2819
    y_2_6_4   disj1_2_6_4  2819
    y_2_6_4   disj2_2_6_4  -2819
    y_2_6_5   disj1_2_6_5  2819
    y_2_6_5   disj2_2_6_5  -2819
    y_2_6_6   disj1_2_6_6  2819
    y_2_6_6   disj2_2_6_6  -2819
    y_2_7_0   disj1_2_7_0  2819
    y_2_7_0   disj2_2_7_0  -2819
    y_2_7_1   disj1_2_7_1  2819
    y_2_7_1   disj2_2_7_1  -2819
    y_2_7_2   disj1_2_7_2  2819
    y_2_7_2   disj2_2_7_2  -2819
    y_2_7_3   disj1_2_7_3  2819
    y_2_7_3   disj2_2_7_3  -2819
    y_2_7_4   disj1_2_7_4  2819
    y_2_7_4   disj2_2_7_4  -2819
    y_2_7_5   disj1_2_7_5  2819
    y_2_7_5   disj2_2_7_5  -2819
    y_2_7_6   disj1_2_7_6  2819
    y_2_7_6   disj2_2_7_6  -2819
    y_2_8_0   disj1_2_8_0  2819
    y_2_8_0   disj2_2_8_0  -2819
    y_2_8_1   disj1_2_8_1  2819
    y_2_8_1   disj2_2_8_1  -2819
    y_2_8_2   disj1_2_8_2  2819
    y_2_8_2   disj2_2_8_2  -2819
    y_2_8_3   disj1_2_8_3  2819
    y_2_8_3   disj2_2_8_3  -2819
    y_2_8_4   disj1_2_8_4  2819
    y_2_8_4   disj2_2_8_4  -2819
    y_2_8_5   disj1_2_8_5  2819
    y_2_8_5   disj2_2_8_5  -2819
    y_2_8_6   disj1_2_8_6  2819
    y_2_8_6   disj2_2_8_6  -2819
    y_3_4_0   disj1_3_4_0  2819
    y_3_4_0   disj2_3_4_0  -2819
    y_3_4_1   disj1_3_4_1  2819
    y_3_4_1   disj2_3_4_1  -2819
    y_3_4_2   disj1_3_4_2  2819
    y_3_4_2   disj2_3_4_2  -2819
    y_3_4_3   disj1_3_4_3  2819
    y_3_4_3   disj2_3_4_3  -2819
    y_3_4_4   disj1_3_4_4  2819
    y_3_4_4   disj2_3_4_4  -2819
    y_3_4_5   disj1_3_4_5  2819
    y_3_4_5   disj2_3_4_5  -2819
    y_3_4_6   disj1_3_4_6  2819
    y_3_4_6   disj2_3_4_6  -2819
    y_3_5_0   disj1_3_5_0  2819
    y_3_5_0   disj2_3_5_0  -2819
    y_3_5_1   disj1_3_5_1  2819
    y_3_5_1   disj2_3_5_1  -2819
    y_3_5_2   disj1_3_5_2  2819
    y_3_5_2   disj2_3_5_2  -2819
    y_3_5_3   disj1_3_5_3  2819
    y_3_5_3   disj2_3_5_3  -2819
    y_3_5_4   disj1_3_5_4  2819
    y_3_5_4   disj2_3_5_4  -2819
    y_3_5_5   disj1_3_5_5  2819
    y_3_5_5   disj2_3_5_5  -2819
    y_3_5_6   disj1_3_5_6  2819
    y_3_5_6   disj2_3_5_6  -2819
    y_3_6_0   disj1_3_6_0  2819
    y_3_6_0   disj2_3_6_0  -2819
    y_3_6_1   disj1_3_6_1  2819
    y_3_6_1   disj2_3_6_1  -2819
    y_3_6_2   disj1_3_6_2  2819
    y_3_6_2   disj2_3_6_2  -2819
    y_3_6_3   disj1_3_6_3  2819
    y_3_6_3   disj2_3_6_3  -2819
    y_3_6_4   disj1_3_6_4  2819
    y_3_6_4   disj2_3_6_4  -2819
    y_3_6_5   disj1_3_6_5  2819
    y_3_6_5   disj2_3_6_5  -2819
    y_3_6_6   disj1_3_6_6  2819
    y_3_6_6   disj2_3_6_6  -2819
    y_3_7_0   disj1_3_7_0  2819
    y_3_7_0   disj2_3_7_0  -2819
    y_3_7_1   disj1_3_7_1  2819
    y_3_7_1   disj2_3_7_1  -2819
    y_3_7_2   disj1_3_7_2  2819
    y_3_7_2   disj2_3_7_2  -2819
    y_3_7_3   disj1_3_7_3  2819
    y_3_7_3   disj2_3_7_3  -2819
    y_3_7_4   disj1_3_7_4  2819
    y_3_7_4   disj2_3_7_4  -2819
    y_3_7_5   disj1_3_7_5  2819
    y_3_7_5   disj2_3_7_5  -2819
    y_3_7_6   disj1_3_7_6  2819
    y_3_7_6   disj2_3_7_6  -2819
    y_3_8_0   disj1_3_8_0  2819
    y_3_8_0   disj2_3_8_0  -2819
    y_3_8_1   disj1_3_8_1  2819
    y_3_8_1   disj2_3_8_1  -2819
    y_3_8_2   disj1_3_8_2  2819
    y_3_8_2   disj2_3_8_2  -2819
    y_3_8_3   disj1_3_8_3  2819
    y_3_8_3   disj2_3_8_3  -2819
    y_3_8_4   disj1_3_8_4  2819
    y_3_8_4   disj2_3_8_4  -2819
    y_3_8_5   disj1_3_8_5  2819
    y_3_8_5   disj2_3_8_5  -2819
    y_3_8_6   disj1_3_8_6  2819
    y_3_8_6   disj2_3_8_6  -2819
    y_4_5_0   disj1_4_5_0  2819
    y_4_5_0   disj2_4_5_0  -2819
    y_4_5_1   disj1_4_5_1  2819
    y_4_5_1   disj2_4_5_1  -2819
    y_4_5_2   disj1_4_5_2  2819
    y_4_5_2   disj2_4_5_2  -2819
    y_4_5_3   disj1_4_5_3  2819
    y_4_5_3   disj2_4_5_3  -2819
    y_4_5_4   disj1_4_5_4  2819
    y_4_5_4   disj2_4_5_4  -2819
    y_4_5_5   disj1_4_5_5  2819
    y_4_5_5   disj2_4_5_5  -2819
    y_4_5_6   disj1_4_5_6  2819
    y_4_5_6   disj2_4_5_6  -2819
    y_4_6_0   disj1_4_6_0  2819
    y_4_6_0   disj2_4_6_0  -2819
    y_4_6_1   disj1_4_6_1  2819
    y_4_6_1   disj2_4_6_1  -2819
    y_4_6_2   disj1_4_6_2  2819
    y_4_6_2   disj2_4_6_2  -2819
    y_4_6_3   disj1_4_6_3  2819
    y_4_6_3   disj2_4_6_3  -2819
    y_4_6_4   disj1_4_6_4  2819
    y_4_6_4   disj2_4_6_4  -2819
    y_4_6_5   disj1_4_6_5  2819
    y_4_6_5   disj2_4_6_5  -2819
    y_4_6_6   disj1_4_6_6  2819
    y_4_6_6   disj2_4_6_6  -2819
    y_4_7_0   disj1_4_7_0  2819
    y_4_7_0   disj2_4_7_0  -2819
    y_4_7_1   disj1_4_7_1  2819
    y_4_7_1   disj2_4_7_1  -2819
    y_4_7_2   disj1_4_7_2  2819
    y_4_7_2   disj2_4_7_2  -2819
    y_4_7_3   disj1_4_7_3  2819
    y_4_7_3   disj2_4_7_3  -2819
    y_4_7_4   disj1_4_7_4  2819
    y_4_7_4   disj2_4_7_4  -2819
    y_4_7_5   disj1_4_7_5  2819
    y_4_7_5   disj2_4_7_5  -2819
    y_4_7_6   disj1_4_7_6  2819
    y_4_7_6   disj2_4_7_6  -2819
    y_4_8_0   disj1_4_8_0  2819
    y_4_8_0   disj2_4_8_0  -2819
    y_4_8_1   disj1_4_8_1  2819
    y_4_8_1   disj2_4_8_1  -2819
    y_4_8_2   disj1_4_8_2  2819
    y_4_8_2   disj2_4_8_2  -2819
    y_4_8_3   disj1_4_8_3  2819
    y_4_8_3   disj2_4_8_3  -2819
    y_4_8_4   disj1_4_8_4  2819
    y_4_8_4   disj2_4_8_4  -2819
    y_4_8_5   disj1_4_8_5  2819
    y_4_8_5   disj2_4_8_5  -2819
    y_4_8_6   disj1_4_8_6  2819
    y_4_8_6   disj2_4_8_6  -2819
    y_5_6_0   disj1_5_6_0  2819
    y_5_6_0   disj2_5_6_0  -2819
    y_5_6_1   disj1_5_6_1  2819
    y_5_6_1   disj2_5_6_1  -2819
    y_5_6_2   disj1_5_6_2  2819
    y_5_6_2   disj2_5_6_2  -2819
    y_5_6_3   disj1_5_6_3  2819
    y_5_6_3   disj2_5_6_3  -2819
    y_5_6_4   disj1_5_6_4  2819
    y_5_6_4   disj2_5_6_4  -2819
    y_5_6_5   disj1_5_6_5  2819
    y_5_6_5   disj2_5_6_5  -2819
    y_5_6_6   disj1_5_6_6  2819
    y_5_6_6   disj2_5_6_6  -2819
    y_5_7_0   disj1_5_7_0  2819
    y_5_7_0   disj2_5_7_0  -2819
    y_5_7_1   disj1_5_7_1  2819
    y_5_7_1   disj2_5_7_1  -2819
    y_5_7_2   disj1_5_7_2  2819
    y_5_7_2   disj2_5_7_2  -2819
    y_5_7_3   disj1_5_7_3  2819
    y_5_7_3   disj2_5_7_3  -2819
    y_5_7_4   disj1_5_7_4  2819
    y_5_7_4   disj2_5_7_4  -2819
    y_5_7_5   disj1_5_7_5  2819
    y_5_7_5   disj2_5_7_5  -2819
    y_5_7_6   disj1_5_7_6  2819
    y_5_7_6   disj2_5_7_6  -2819
    y_5_8_0   disj1_5_8_0  2819
    y_5_8_0   disj2_5_8_0  -2819
    y_5_8_1   disj1_5_8_1  2819
    y_5_8_1   disj2_5_8_1  -2819
    y_5_8_2   disj1_5_8_2  2819
    y_5_8_2   disj2_5_8_2  -2819
    y_5_8_3   disj1_5_8_3  2819
    y_5_8_3   disj2_5_8_3  -2819
    y_5_8_4   disj1_5_8_4  2819
    y_5_8_4   disj2_5_8_4  -2819
    y_5_8_5   disj1_5_8_5  2819
    y_5_8_5   disj2_5_8_5  -2819
    y_5_8_6   disj1_5_8_6  2819
    y_5_8_6   disj2_5_8_6  -2819
    y_6_7_0   disj1_6_7_0  2819
    y_6_7_0   disj2_6_7_0  -2819
    y_6_7_1   disj1_6_7_1  2819
    y_6_7_1   disj2_6_7_1  -2819
    y_6_7_2   disj1_6_7_2  2819
    y_6_7_2   disj2_6_7_2  -2819
    y_6_7_3   disj1_6_7_3  2819
    y_6_7_3   disj2_6_7_3  -2819
    y_6_7_4   disj1_6_7_4  2819
    y_6_7_4   disj2_6_7_4  -2819
    y_6_7_5   disj1_6_7_5  2819
    y_6_7_5   disj2_6_7_5  -2819
    y_6_7_6   disj1_6_7_6  2819
    y_6_7_6   disj2_6_7_6  -2819
    y_6_8_0   disj1_6_8_0  2819
    y_6_8_0   disj2_6_8_0  -2819
    y_6_8_1   disj1_6_8_1  2819
    y_6_8_1   disj2_6_8_1  -2819
    y_6_8_2   disj1_6_8_2  2819
    y_6_8_2   disj2_6_8_2  -2819
    y_6_8_3   disj1_6_8_3  2819
    y_6_8_3   disj2_6_8_3  -2819
    y_6_8_4   disj1_6_8_4  2819
    y_6_8_4   disj2_6_8_4  -2819
    y_6_8_5   disj1_6_8_5  2819
    y_6_8_5   disj2_6_8_5  -2819
    y_6_8_6   disj1_6_8_6  2819
    y_6_8_6   disj2_6_8_6  -2819
    y_7_8_0   disj1_7_8_0  2819
    y_7_8_0   disj2_7_8_0  -2819
    y_7_8_1   disj1_7_8_1  2819
    y_7_8_1   disj2_7_8_1  -2819
    y_7_8_2   disj1_7_8_2  2819
    y_7_8_2   disj2_7_8_2  -2819
    y_7_8_3   disj1_7_8_3  2819
    y_7_8_3   disj2_7_8_3  -2819
    y_7_8_4   disj1_7_8_4  2819
    y_7_8_4   disj2_7_8_4  -2819
    y_7_8_5   disj1_7_8_5  2819
    y_7_8_5   disj2_7_8_5  -2819
    y_7_8_6   disj1_7_8_6  2819
    y_7_8_6   disj2_7_8_6  -2819
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  99
    RHS       prec_0_1  3
    RHS       prec_0_2  5
    RHS       prec_0_3  99
    RHS       prec_0_4  98
    RHS       prec_0_5  97
    RHS       prec_1_0  5
    RHS       prec_1_1  2
    RHS       prec_1_2  3
    RHS       prec_1_3  98
    RHS       prec_1_4  5
    RHS       prec_1_5  97
    RHS       prec_2_0  6
    RHS       prec_2_1  96
    RHS       prec_2_2  98
    RHS       prec_2_3  97
    RHS       prec_2_4  98
    RHS       prec_2_5  4
    RHS       prec_3_0  3
    RHS       prec_3_1  98
    RHS       prec_3_2  6
    RHS       prec_3_3  3
    RHS       prec_3_4  2
    RHS       prec_3_5  1
    RHS       prec_4_0  94
    RHS       prec_4_1  6
    RHS       prec_4_2  3
    RHS       prec_4_3  2
    RHS       prec_4_4  1
    RHS       prec_4_5  1
    RHS       prec_5_0  2
    RHS       prec_5_1  1
    RHS       prec_5_2  96
    RHS       prec_5_3  96
    RHS       prec_5_4  5
    RHS       prec_5_5  3
    RHS       prec_6_0  98
    RHS       prec_6_1  98
    RHS       prec_6_2  96
    RHS       prec_6_3  98
    RHS       prec_6_4  6
    RHS       prec_6_5  94
    RHS       prec_7_0  95
    RHS       prec_7_1  1
    RHS       prec_7_2  95
    RHS       prec_7_3  99
    RHS       prec_7_4  3
    RHS       prec_7_5  94
    RHS       prec_8_0  1
    RHS       prec_8_1  1
    RHS       prec_8_2  99
    RHS       prec_8_3  96
    RHS       prec_8_4  2
    RHS       prec_8_5  97
    RHS       mksp_0    94
    RHS       mksp_1    96
    RHS       mksp_2    3
    RHS       mksp_3    3
    RHS       mksp_4    3
    RHS       mksp_5    4
    RHS       mksp_6    1
    RHS       mksp_7    4
    RHS       mksp_8    5
    RHS       disj1_0_1_0  97
    RHS       disj2_0_1_0  -2817
    RHS       disj1_0_2_0  97
    RHS       disj2_0_2_0  -2813
    RHS       disj1_0_3_0  97
    RHS       disj2_0_3_0  -2816
    RHS       disj1_0_4_0  97
    RHS       disj2_0_4_0  -2818
    RHS       disj1_0_5_0  97
    RHS       disj2_0_5_0  -2723
    RHS       disj1_0_6_0  97
    RHS       disj2_0_6_0  -2721
    RHS       disj1_0_7_0  97
    RHS       disj2_0_7_0  -2725
    RHS       disj1_0_8_0  97
    RHS       disj2_0_8_0  -2817
    RHS       disj1_1_2_0  2
    RHS       disj2_1_2_0  -2813
    RHS       disj1_1_3_0  2
    RHS       disj2_1_3_0  -2816
    RHS       disj1_1_4_0  2
    RHS       disj2_1_4_0  -2818
    RHS       disj1_1_5_0  2
    RHS       disj2_1_5_0  -2723
    RHS       disj1_1_6_0  2
    RHS       disj2_1_6_0  -2721
    RHS       disj1_1_7_0  2
    RHS       disj2_1_7_0  -2725
    RHS       disj1_1_8_0  2
    RHS       disj2_1_8_0  -2817
    RHS       disj1_2_3_0  6
    RHS       disj2_2_3_0  -2816
    RHS       disj1_2_4_0  6
    RHS       disj2_2_4_0  -2818
    RHS       disj1_2_5_0  6
    RHS       disj2_2_5_0  -2723
    RHS       disj1_2_6_0  6
    RHS       disj2_2_6_0  -2721
    RHS       disj1_2_7_0  6
    RHS       disj2_2_7_0  -2725
    RHS       disj1_2_8_0  6
    RHS       disj2_2_8_0  -2817
    RHS       disj1_3_4_0  3
    RHS       disj2_3_4_0  -2818
    RHS       disj1_3_5_0  3
    RHS       disj2_3_5_0  -2723
    RHS       disj1_3_6_0  3
    RHS       disj2_3_6_0  -2721
    RHS       disj1_3_7_0  3
    RHS       disj2_3_7_0  -2725
    RHS       disj1_3_8_0  3
    RHS       disj2_3_8_0  -2817
    RHS       disj1_4_5_0  1
    RHS       disj2_4_5_0  -2723
    RHS       disj1_4_6_0  1
    RHS       disj2_4_6_0  -2721
    RHS       disj1_4_7_0  1
    RHS       disj2_4_7_0  -2725
    RHS       disj1_4_8_0  1
    RHS       disj2_4_8_0  -2817
    RHS       disj1_5_6_0  96
    RHS       disj2_5_6_0  -2721
    RHS       disj1_5_7_0  96
    RHS       disj2_5_7_0  -2725
    RHS       disj1_5_8_0  96
    RHS       disj2_5_8_0  -2817
    RHS       disj1_6_7_0  98
    RHS       disj2_6_7_0  -2725
    RHS       disj1_6_8_0  98
    RHS       disj2_6_8_0  -2817
    RHS       disj1_7_8_0  94
    RHS       disj2_7_8_0  -2817
    RHS       disj1_0_1_1  5
    RHS       disj2_0_1_1  -2814
    RHS       disj1_0_2_1  5
    RHS       disj2_0_2_1  -2721
    RHS       disj1_0_3_1  5
    RHS       disj2_0_3_1  -2813
    RHS       disj1_0_4_1  5
    RHS       disj2_0_4_1  -2817
    RHS       disj1_0_5_1  5
    RHS       disj2_0_5_1  -2816
    RHS       disj1_0_6_1  5
    RHS       disj2_0_6_1  -2721
    RHS       disj1_0_7_1  5
    RHS       disj2_0_7_1  -2815
    RHS       disj1_0_8_1  5
    RHS       disj2_0_8_1  -2723
    RHS       disj1_1_2_1  5
    RHS       disj2_1_2_1  -2721
    RHS       disj1_1_3_1  5
    RHS       disj2_1_3_1  -2813
    RHS       disj1_1_4_1  5
    RHS       disj2_1_4_1  -2817
    RHS       disj1_1_5_1  5
    RHS       disj2_1_5_1  -2816
    RHS       disj1_1_6_1  5
    RHS       disj2_1_6_1  -2721
    RHS       disj1_1_7_1  5
    RHS       disj2_1_7_1  -2815
    RHS       disj1_1_8_1  5
    RHS       disj2_1_8_1  -2723
    RHS       disj1_2_3_1  98
    RHS       disj2_2_3_1  -2813
    RHS       disj1_2_4_1  98
    RHS       disj2_2_4_1  -2817
    RHS       disj1_2_5_1  98
    RHS       disj2_2_5_1  -2816
    RHS       disj1_2_6_1  98
    RHS       disj2_2_6_1  -2721
    RHS       disj1_2_7_1  98
    RHS       disj2_2_7_1  -2815
    RHS       disj1_2_8_1  98
    RHS       disj2_2_8_1  -2723
    RHS       disj1_3_4_1  6
    RHS       disj2_3_4_1  -2817
    RHS       disj1_3_5_1  6
    RHS       disj2_3_5_1  -2816
    RHS       disj1_3_6_1  6
    RHS       disj2_3_6_1  -2721
    RHS       disj1_3_7_1  6
    RHS       disj2_3_7_1  -2815
    RHS       disj1_3_8_1  6
    RHS       disj2_3_8_1  -2723
    RHS       disj1_4_5_1  2
    RHS       disj2_4_5_1  -2816
    RHS       disj1_4_6_1  2
    RHS       disj2_4_6_1  -2721
    RHS       disj1_4_7_1  2
    RHS       disj2_4_7_1  -2815
    RHS       disj1_4_8_1  2
    RHS       disj2_4_8_1  -2723
    RHS       disj1_5_6_1  3
    RHS       disj2_5_6_1  -2721
    RHS       disj1_5_7_1  3
    RHS       disj2_5_7_1  -2815
    RHS       disj1_5_8_1  3
    RHS       disj2_5_8_1  -2723
    RHS       disj1_6_7_1  98
    RHS       disj2_6_7_1  -2815
    RHS       disj1_6_8_1  98
    RHS       disj2_6_8_1  -2723
    RHS       disj1_7_8_1  4
    RHS       disj2_7_8_1  -2723
    RHS       disj1_0_1_2  99
    RHS       disj2_0_1_2  -2722
    RHS       disj1_0_2_2  99
    RHS       disj2_0_2_2  -2721
    RHS       disj1_0_3_2  99
    RHS       disj2_0_3_2  -2818
    RHS       disj1_0_4_2  99
    RHS       disj2_0_4_2  -2725
    RHS       disj1_0_5_2  99
    RHS       disj2_0_5_2  -2817
    RHS       disj1_0_6_2  99
    RHS       disj2_0_6_2  -2813
    RHS       disj1_0_7_2  99
    RHS       disj2_0_7_2  -2724
    RHS       disj1_0_8_2  99
    RHS       disj2_0_8_2  -2818
    RHS       disj1_1_2_2  97
    RHS       disj2_1_2_2  -2721
    RHS       disj1_1_3_2  97
    RHS       disj2_1_3_2  -2818
    RHS       disj1_1_4_2  97
    RHS       disj2_1_4_2  -2725
    RHS       disj1_1_5_2  97
    RHS       disj2_1_5_2  -2817
    RHS       disj1_1_6_2  97
    RHS       disj2_1_6_2  -2813
    RHS       disj1_1_7_2  97
    RHS       disj2_1_7_2  -2724
    RHS       disj1_1_8_2  97
    RHS       disj2_1_8_2  -2818
    RHS       disj1_2_3_2  98
    RHS       disj2_2_3_2  -2818
    RHS       disj1_2_4_2  98
    RHS       disj2_2_4_2  -2725
    RHS       disj1_2_5_2  98
    RHS       disj2_2_5_2  -2817
    RHS       disj1_2_6_2  98
    RHS       disj2_2_6_2  -2813
    RHS       disj1_2_7_2  98
    RHS       disj2_2_7_2  -2724
    RHS       disj1_2_8_2  98
    RHS       disj2_2_8_2  -2818
    RHS       disj1_3_4_2  1
    RHS       disj2_3_4_2  -2725
    RHS       disj1_3_5_2  1
    RHS       disj2_3_5_2  -2817
    RHS       disj1_3_6_2  1
    RHS       disj2_3_6_2  -2813
    RHS       disj1_3_7_2  1
    RHS       disj2_3_7_2  -2724
    RHS       disj1_3_8_2  1
    RHS       disj2_3_8_2  -2818
    RHS       disj1_4_5_2  94
    RHS       disj2_4_5_2  -2817
    RHS       disj1_4_6_2  94
    RHS       disj2_4_6_2  -2813
    RHS       disj1_4_7_2  94
    RHS       disj2_4_7_2  -2724
    RHS       disj1_4_8_2  94
    RHS       disj2_4_8_2  -2818
    RHS       disj1_5_6_2  2
    RHS       disj2_5_6_2  -2813
    RHS       disj1_5_7_2  2
    RHS       disj2_5_7_2  -2724
    RHS       disj1_5_8_2  2
    RHS       disj2_5_8_2  -2818
    RHS       disj1_6_7_2  6
    RHS       disj2_6_7_2  -2724
    RHS       disj1_6_8_2  6
    RHS       disj2_6_8_2  -2818
    RHS       disj1_7_8_2  95
    RHS       disj2_7_8_2  -2818
    RHS       disj1_0_1_3  3
    RHS       disj2_0_1_3  -2723
    RHS       disj1_0_2_3  3
    RHS       disj2_0_2_3  -2815
    RHS       disj1_0_3_3  3
    RHS       disj2_0_3_3  -2817
    RHS       disj1_0_4_3  3
    RHS       disj2_0_4_3  -2816
    RHS       disj1_0_5_3  3
    RHS       disj2_0_5_3  -2818
    RHS       disj1_0_6_3  3
    RHS       disj2_0_6_3  -2723
    RHS       disj1_0_7_3  3
    RHS       disj2_0_7_3  -2816
    RHS       disj1_0_8_3  3
    RHS       disj2_0_8_3  -2818
    RHS       disj1_1_2_3  96
    RHS       disj2_1_2_3  -2815
    RHS       disj1_1_3_3  96
    RHS       disj2_1_3_3  -2817
    RHS       disj1_1_4_3  96
    RHS       disj2_1_4_3  -2816
    RHS       disj1_1_5_3  96
    RHS       disj2_1_5_3  -2818
    RHS       disj1_1_6_3  96
    RHS       disj2_1_6_3  -2723
    RHS       disj1_1_7_3  96
    RHS       disj2_1_7_3  -2816
    RHS       disj1_1_8_3  96
    RHS       disj2_1_8_3  -2818
    RHS       disj1_2_3_3  4
    RHS       disj2_2_3_3  -2817
    RHS       disj1_2_4_3  4
    RHS       disj2_2_4_3  -2816
    RHS       disj1_2_5_3  4
    RHS       disj2_2_5_3  -2818
    RHS       disj1_2_6_3  4
    RHS       disj2_2_6_3  -2723
    RHS       disj1_2_7_3  4
    RHS       disj2_2_7_3  -2816
    RHS       disj1_2_8_3  4
    RHS       disj2_2_8_3  -2818
    RHS       disj1_3_4_3  2
    RHS       disj2_3_4_3  -2816
    RHS       disj1_3_5_3  2
    RHS       disj2_3_5_3  -2818
    RHS       disj1_3_6_3  2
    RHS       disj2_3_6_3  -2723
    RHS       disj1_3_7_3  2
    RHS       disj2_3_7_3  -2816
    RHS       disj1_3_8_3  2
    RHS       disj2_3_8_3  -2818
    RHS       disj1_4_5_3  3
    RHS       disj2_4_5_3  -2818
    RHS       disj1_4_6_3  3
    RHS       disj2_4_6_3  -2723
    RHS       disj1_4_7_3  3
    RHS       disj2_4_7_3  -2816
    RHS       disj1_4_8_3  3
    RHS       disj2_4_8_3  -2818
    RHS       disj1_5_6_3  1
    RHS       disj2_5_6_3  -2723
    RHS       disj1_5_7_3  1
    RHS       disj2_5_7_3  -2816
    RHS       disj1_5_8_3  1
    RHS       disj2_5_8_3  -2818
    RHS       disj1_6_7_3  96
    RHS       disj2_6_7_3  -2816
    RHS       disj1_6_8_3  96
    RHS       disj2_6_8_3  -2818
    RHS       disj1_7_8_3  3
    RHS       disj2_7_8_3  -2818
    RHS       disj1_0_1_4  99
    RHS       disj2_0_1_4  -2721
    RHS       disj1_0_2_4  99
    RHS       disj2_0_2_4  -2723
    RHS       disj1_0_3_4  99
    RHS       disj2_0_3_4  -2816
    RHS       disj1_0_4_4  99
    RHS       disj2_0_4_4  -2818
    RHS       disj1_0_5_4  99
    RHS       disj2_0_5_4  -2723
    RHS       disj1_0_6_4  99
    RHS       disj2_0_6_4  -2721
    RHS       disj1_0_7_4  99
    RHS       disj2_0_7_4  -2724
    RHS       disj1_0_8_4  99
    RHS       disj2_0_8_4  -2814
    RHS       disj1_1_2_4  98
    RHS       disj2_1_2_4  -2723
    RHS       disj1_1_3_4  98
    RHS       disj2_1_3_4  -2816
    RHS       disj1_1_4_4  98
    RHS       disj2_1_4_4  -2818
    RHS       disj1_1_5_4  98
    RHS       disj2_1_5_4  -2723
    RHS       disj1_1_6_4  98
    RHS       disj2_1_6_4  -2721
    RHS       disj1_1_7_4  98
    RHS       disj2_1_7_4  -2724
    RHS       disj1_1_8_4  98
    RHS       disj2_1_8_4  -2814
    RHS       disj1_2_3_4  96
    RHS       disj2_2_3_4  -2816
    RHS       disj1_2_4_4  96
    RHS       disj2_2_4_4  -2818
    RHS       disj1_2_5_4  96
    RHS       disj2_2_5_4  -2723
    RHS       disj1_2_6_4  96
    RHS       disj2_2_6_4  -2721
    RHS       disj1_2_7_4  96
    RHS       disj2_2_7_4  -2724
    RHS       disj1_2_8_4  96
    RHS       disj2_2_8_4  -2814
    RHS       disj1_3_4_4  3
    RHS       disj2_3_4_4  -2818
    RHS       disj1_3_5_4  3
    RHS       disj2_3_5_4  -2723
    RHS       disj1_3_6_4  3
    RHS       disj2_3_6_4  -2721
    RHS       disj1_3_7_4  3
    RHS       disj2_3_7_4  -2724
    RHS       disj1_3_8_4  3
    RHS       disj2_3_8_4  -2814
    RHS       disj1_4_5_4  1
    RHS       disj2_4_5_4  -2723
    RHS       disj1_4_6_4  1
    RHS       disj2_4_6_4  -2721
    RHS       disj1_4_7_4  1
    RHS       disj2_4_7_4  -2724
    RHS       disj1_4_8_4  1
    RHS       disj2_4_8_4  -2814
    RHS       disj1_5_6_4  96
    RHS       disj2_5_6_4  -2721
    RHS       disj1_5_7_4  96
    RHS       disj2_5_7_4  -2724
    RHS       disj1_5_8_4  96
    RHS       disj2_5_8_4  -2814
    RHS       disj1_6_7_4  98
    RHS       disj2_6_7_4  -2724
    RHS       disj1_6_8_4  98
    RHS       disj2_6_8_4  -2814
    RHS       disj1_7_8_4  95
    RHS       disj2_7_8_4  -2814
    RHS       disj1_0_1_5  98
    RHS       disj2_0_1_5  -2816
    RHS       disj1_0_2_5  98
    RHS       disj2_0_2_5  -2722
    RHS       disj1_0_3_5  98
    RHS       disj2_0_3_5  -2816
    RHS       disj1_0_4_5  98
    RHS       disj2_0_4_5  -2816
    RHS       disj1_0_5_5  98
    RHS       disj2_0_5_5  -2814
    RHS       disj1_0_6_5  98
    RHS       disj2_0_6_5  -2818
    RHS       disj1_0_7_5  98
    RHS       disj2_0_7_5  -2818
    RHS       disj1_0_8_5  98
    RHS       disj2_0_8_5  -2722
    RHS       disj1_1_2_5  3
    RHS       disj2_1_2_5  -2722
    RHS       disj1_1_3_5  3
    RHS       disj2_1_3_5  -2816
    RHS       disj1_1_4_5  3
    RHS       disj2_1_4_5  -2816
    RHS       disj1_1_5_5  3
    RHS       disj2_1_5_5  -2814
    RHS       disj1_1_6_5  3
    RHS       disj2_1_6_5  -2818
    RHS       disj1_1_7_5  3
    RHS       disj2_1_7_5  -2818
    RHS       disj1_1_8_5  3
    RHS       disj2_1_8_5  -2722
    RHS       disj1_2_3_5  97
    RHS       disj2_2_3_5  -2816
    RHS       disj1_2_4_5  97
    RHS       disj2_2_4_5  -2816
    RHS       disj1_2_5_5  97
    RHS       disj2_2_5_5  -2814
    RHS       disj1_2_6_5  97
    RHS       disj2_2_6_5  -2818
    RHS       disj1_2_7_5  97
    RHS       disj2_2_7_5  -2818
    RHS       disj1_2_8_5  97
    RHS       disj2_2_8_5  -2722
    RHS       disj1_3_4_5  3
    RHS       disj2_3_4_5  -2816
    RHS       disj1_3_5_5  3
    RHS       disj2_3_5_5  -2814
    RHS       disj1_3_6_5  3
    RHS       disj2_3_6_5  -2818
    RHS       disj1_3_7_5  3
    RHS       disj2_3_7_5  -2818
    RHS       disj1_3_8_5  3
    RHS       disj2_3_8_5  -2722
    RHS       disj1_4_5_5  3
    RHS       disj2_4_5_5  -2814
    RHS       disj1_4_6_5  3
    RHS       disj2_4_6_5  -2818
    RHS       disj1_4_7_5  3
    RHS       disj2_4_7_5  -2818
    RHS       disj1_4_8_5  3
    RHS       disj2_4_8_5  -2722
    RHS       disj1_5_6_5  5
    RHS       disj2_5_6_5  -2818
    RHS       disj1_5_7_5  5
    RHS       disj2_5_7_5  -2818
    RHS       disj1_5_8_5  5
    RHS       disj2_5_8_5  -2722
    RHS       disj1_6_7_5  1
    RHS       disj2_6_7_5  -2818
    RHS       disj1_6_8_5  1
    RHS       disj2_6_8_5  -2722
    RHS       disj1_7_8_5  1
    RHS       disj2_7_8_5  -2722
    RHS       disj1_0_1_6  94
    RHS       disj2_0_1_6  -2814
    RHS       disj1_0_2_6  94
    RHS       disj2_0_2_6  -2816
    RHS       disj1_0_3_6  94
    RHS       disj2_0_3_6  -2721
    RHS       disj1_0_4_6  94
    RHS       disj2_0_4_6  -2813
    RHS       disj1_0_5_6  94
    RHS       disj2_0_5_6  -2815
    RHS       disj1_0_6_6  94
    RHS       disj2_0_6_6  -2725
    RHS       disj1_0_7_6  94
    RHS       disj2_0_7_6  -2720
    RHS       disj1_0_8_6  94
    RHS       disj2_0_8_6  -2720
    RHS       disj1_1_2_6  5
    RHS       disj2_1_2_6  -2816
    RHS       disj1_1_3_6  5
    RHS       disj2_1_3_6  -2721
    RHS       disj1_1_4_6  5
    RHS       disj2_1_4_6  -2813
    RHS       disj1_1_5_6  5
    RHS       disj2_1_5_6  -2815
    RHS       disj1_1_6_6  5
    RHS       disj2_1_6_6  -2725
    RHS       disj1_1_7_6  5
    RHS       disj2_1_7_6  -2720
    RHS       disj1_1_8_6  5
    RHS       disj2_1_8_6  -2720
    RHS       disj1_2_3_6  3
    RHS       disj2_2_3_6  -2721
    RHS       disj1_2_4_6  3
    RHS       disj2_2_4_6  -2813
    RHS       disj1_2_5_6  3
    RHS       disj2_2_5_6  -2815
    RHS       disj1_2_6_6  3
    RHS       disj2_2_6_6  -2725
    RHS       disj1_2_7_6  3
    RHS       disj2_2_7_6  -2720
    RHS       disj1_2_8_6  3
    RHS       disj2_2_8_6  -2720
    RHS       disj1_3_4_6  98
    RHS       disj2_3_4_6  -2813
    RHS       disj1_3_5_6  98
    RHS       disj2_3_5_6  -2815
    RHS       disj1_3_6_6  98
    RHS       disj2_3_6_6  -2725
    RHS       disj1_3_7_6  98
    RHS       disj2_3_7_6  -2720
    RHS       disj1_3_8_6  98
    RHS       disj2_3_8_6  -2720
    RHS       disj1_4_5_6  6
    RHS       disj2_4_5_6  -2815
    RHS       disj1_4_6_6  6
    RHS       disj2_4_6_6  -2725
    RHS       disj1_4_7_6  6
    RHS       disj2_4_7_6  -2720
    RHS       disj1_4_8_6  6
    RHS       disj2_4_8_6  -2720
    RHS       disj1_5_6_6  4
    RHS       disj2_5_6_6  -2725
    RHS       disj1_5_7_6  4
    RHS       disj2_5_7_6  -2720
    RHS       disj1_5_8_6  4
    RHS       disj2_5_8_6  -2720
    RHS       disj1_6_7_6  94
    RHS       disj2_6_7_6  -2720
    RHS       disj1_6_8_6  94
    RHS       disj2_6_8_6  -2720
    RHS       disj1_7_8_6  99
    RHS       disj2_7_8_6  -2720
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_1_6
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_2_6
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_3_6
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_4_6
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_5_6
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_0_6_6
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_7_5
 BV BOUND     y_0_7_6
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_8_5
 BV BOUND     y_0_8_6
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_2_6
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_3_6
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_4_6
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_5_6
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_1_6_6
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_7_5
 BV BOUND     y_1_7_6
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_8_5
 BV BOUND     y_1_8_6
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_3_6
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_4_6
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_5_6
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_2_6_6
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_7_5
 BV BOUND     y_2_7_6
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_8_5
 BV BOUND     y_2_8_6
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_4_6
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_5_6
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_3_6_6
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_7_5
 BV BOUND     y_3_7_6
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_8_5
 BV BOUND     y_3_8_6
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_5_6
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_4_6_6
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_7_5
 BV BOUND     y_4_7_6
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_8_5
 BV BOUND     y_4_8_6
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
 BV BOUND     y_5_6_6
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_7_5
 BV BOUND     y_5_7_6
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_8_5
 BV BOUND     y_5_8_6
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_7_5
 BV BOUND     y_6_7_6
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_8_5
 BV BOUND     y_6_8_6
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_8_5
 BV BOUND     y_7_8_6
ENDATA
