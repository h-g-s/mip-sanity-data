NAME          fcnf_search_n50_d9_s4_5_sl0.95_sd7
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 E  flow_25
 E  flow_26
 E  flow_27
 E  flow_28
 E  flow_29
 E  flow_30
 E  flow_31
 E  flow_32
 E  flow_33
 E  flow_34
 E  flow_35
 E  flow_36
 E  flow_37
 E  flow_38
 E  flow_39
 E  flow_40
 E  flow_41
 E  flow_42
 E  flow_43
 E  flow_44
 E  flow_45
 E  flow_46
 E  flow_47
 E  flow_48
 E  flow_49
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
 L  link_84
 L  link_85
 L  link_86
 L  link_87
 L  link_88
 L  link_89
 L  link_90
 L  link_91
 L  link_92
 L  link_93
 L  link_94
 L  link_95
 L  link_96
 L  link_97
 L  link_98
 L  link_99
 L  link_100
 L  link_101
 L  link_102
 L  link_103
 L  link_104
 L  link_105
 L  link_106
 L  link_107
 L  link_108
 L  link_109
 L  link_110
 L  link_111
 L  link_112
 L  link_113
 L  link_114
 L  link_115
 L  link_116
 L  link_117
 L  link_118
 L  link_119
 L  link_120
 L  link_121
 L  link_122
 L  link_123
 L  link_124
 L  link_125
 L  link_126
 L  link_127
 L  link_128
 L  link_129
 L  link_130
 L  link_131
 L  link_132
 L  link_133
 L  link_134
 L  link_135
 L  link_136
 L  link_137
 L  link_138
 L  link_139
 L  link_140
 L  link_141
 L  link_142
 L  link_143
 L  link_144
 L  link_145
 L  link_146
 L  link_147
 L  link_148
 L  link_149
 L  link_150
 L  link_151
 L  link_152
 L  link_153
 L  link_154
 L  link_155
 L  link_156
 L  link_157
 L  link_158
 L  link_159
 L  link_160
 L  link_161
 L  link_162
 L  link_163
 L  link_164
 L  link_165
 L  link_166
 L  link_167
 L  link_168
 L  link_169
 L  link_170
 L  link_171
 L  link_172
 L  link_173
 L  link_174
 L  link_175
 L  link_176
 L  link_177
 L  link_178
 L  link_179
 L  link_180
 L  link_181
 L  link_182
 L  link_183
 L  link_184
 L  link_185
 L  link_186
 L  link_187
 L  link_188
 L  link_189
 L  link_190
 L  link_191
 L  link_192
 L  link_193
 L  link_194
 L  link_195
 L  link_196
 L  link_197
 L  link_198
 L  link_199
 L  link_200
 L  link_201
 L  link_202
 L  link_203
 L  link_204
 L  link_205
 L  link_206
 L  link_207
 L  link_208
 L  link_209
 L  link_210
 L  link_211
 L  link_212
 L  link_213
 L  link_214
 L  link_215
 L  link_216
 L  link_217
 L  link_218
 L  link_219
 L  link_220
 L  link_221
 L  link_222
 L  link_223
 L  link_224
 L  link_225
 L  link_226
 L  link_227
 L  link_228
 L  link_229
 L  link_230
 L  link_231
 L  link_232
 L  link_233
 L  link_234
 L  link_235
 L  link_236
 L  link_237
 L  link_238
 L  link_239
 L  link_240
 L  link_241
 L  link_242
 L  link_243
 L  link_244
 L  link_245
 L  link_246
 L  link_247
 L  link_248
 L  link_249
 L  link_250
 L  link_251
 L  link_252
 L  link_253
 L  link_254
 L  link_255
 L  link_256
 L  link_257
 L  link_258
 L  link_259
 L  link_260
 L  link_261
 L  link_262
 L  link_263
 L  link_264
 L  link_265
 L  link_266
 L  link_267
 L  link_268
 L  link_269
 L  link_270
 L  link_271
 L  link_272
 L  link_273
 L  link_274
 L  link_275
 L  link_276
 L  link_277
 L  link_278
 L  link_279
 L  link_280
 L  link_281
 L  link_282
 L  link_283
 L  link_284
 L  link_285
 L  link_286
 L  link_287
 L  link_288
 L  link_289
 L  link_290
 L  link_291
 L  link_292
 L  link_293
 L  link_294
 L  link_295
 L  link_296
 L  link_297
 L  link_298
 L  link_299
 L  link_300
 L  link_301
 L  link_302
 L  link_303
 L  link_304
 L  link_305
 L  link_306
 L  link_307
 L  link_308
 L  link_309
 L  link_310
 L  link_311
 L  link_312
 L  link_313
 L  link_314
 L  link_315
 L  link_316
 L  link_317
 L  link_318
 L  link_319
 L  link_320
 L  link_321
 L  link_322
 L  link_323
 L  link_324
 L  link_325
 L  link_326
 L  link_327
 L  link_328
 L  link_329
 L  link_330
 L  link_331
 L  link_332
 L  link_333
 L  link_334
 L  link_335
 L  link_336
 L  link_337
 L  link_338
 L  link_339
 L  link_340
 L  link_341
 L  link_342
 L  link_343
 L  link_344
 L  link_345
 L  link_346
 L  link_347
 L  link_348
 L  link_349
 L  link_350
 L  link_351
 L  link_352
 L  link_353
 L  link_354
 L  link_355
 L  link_356
 L  link_357
 L  link_358
 L  link_359
 L  link_360
 L  link_361
 L  link_362
 L  link_363
 L  link_364
 L  link_365
 L  link_366
 L  link_367
 L  link_368
 L  link_369
 L  link_370
 L  link_371
 L  link_372
 L  link_373
 L  link_374
 L  link_375
 L  link_376
 L  link_377
 L  link_378
 L  link_379
 L  link_380
 L  link_381
 L  link_382
 L  link_383
 L  link_384
 L  link_385
 L  link_386
 L  link_387
 L  link_388
 L  link_389
 L  link_390
 L  link_391
 L  link_392
 L  link_393
 L  link_394
 L  link_395
 L  link_396
 L  link_397
 L  link_398
 L  link_399
 L  link_400
 L  link_401
 L  link_402
 L  link_403
 L  link_404
 L  link_405
 L  link_406
 L  link_407
 L  link_408
 L  link_409
 L  link_410
 L  link_411
 L  link_412
 L  link_413
 L  link_414
 L  link_415
 L  link_416
 L  link_417
 L  link_418
 L  link_419
 L  link_420
 L  link_421
 L  link_422
 L  link_423
 L  link_424
 L  link_425
 L  link_426
 L  link_427
 L  link_428
 L  link_429
 L  link_430
 L  link_431
 L  link_432
 L  link_433
 L  link_434
 L  link_435
 L  link_436
 L  link_437
 L  link_438
 L  link_439
 L  link_440
 L  link_441
 L  link_442
 L  link_443
 L  link_444
 L  link_445
 L  link_446
 L  link_447
 L  link_448
 L  link_449
COLUMNS
    x_0         OBJ       0.62
    x_0         flow_20     1.0
    x_0         flow_9      -1.0
    x_0         link_0      1.0
    x_1         OBJ       1.77
    x_1         flow_23     1.0
    x_1         flow_37     -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.88
    x_2         flow_26     1.0
    x_2         flow_4      -1.0
    x_2         link_2      1.0
    x_3         OBJ       54.98
    x_3         flow_7      1.0
    x_3         flow_14     -1.0
    x_3         link_3      1.0
    x_4         OBJ       22.79
    x_4         flow_25     1.0
    x_4         flow_3      -1.0
    x_4         link_4      1.0
    x_5         OBJ       54.25
    x_5         flow_26     1.0
    x_5         flow_9      -1.0
    x_5         link_5      1.0
    x_6         OBJ       58.33
    x_6         flow_11     1.0
    x_6         flow_6      -1.0
    x_6         link_6      1.0
    x_7         OBJ       57.14
    x_7         flow_45     1.0
    x_7         flow_4      -1.0
    x_7         link_7      1.0
    x_8         OBJ       1.96
    x_8         flow_27     1.0
    x_8         flow_49     -1.0
    x_8         link_8      1.0
    x_9         OBJ       34.65
    x_9         flow_15     1.0
    x_9         flow_11     -1.0
    x_9         link_9      1.0
    x_10        OBJ       37.28
    x_10        flow_31     1.0
    x_10        flow_21     -1.0
    x_10        link_10     1.0
    x_11        OBJ       1.36
    x_11        flow_32     1.0
    x_11        flow_26     -1.0
    x_11        link_11     1.0
    x_12        OBJ       1.9
    x_12        flow_2      1.0
    x_12        flow_42     -1.0
    x_12        link_12     1.0
    x_13        OBJ       55.66
    x_13        flow_20     1.0
    x_13        flow_21     -1.0
    x_13        link_13     1.0
    x_14        OBJ       48.45
    x_14        flow_4      1.0
    x_14        flow_5      -1.0
    x_14        link_14     1.0
    x_15        OBJ       1.94
    x_15        flow_46     1.0
    x_15        flow_44     -1.0
    x_15        link_15     1.0
    x_16        OBJ       2.17
    x_16        flow_18     1.0
    x_16        flow_45     -1.0
    x_16        link_16     1.0
    x_17        OBJ       49.62
    x_17        flow_22     1.0
    x_17        flow_10     -1.0
    x_17        link_17     1.0
    x_18        OBJ       1.48
    x_18        flow_8      1.0
    x_18        flow_47     -1.0
    x_18        link_18     1.0
    x_19        OBJ       1.19
    x_19        flow_10     1.0
    x_19        flow_28     -1.0
    x_19        link_19     1.0
    x_20        OBJ       79.19
    x_20        flow_35     1.0
    x_20        flow_17     -1.0
    x_20        link_20     1.0
    x_21        OBJ       0.88
    x_21        flow_14     1.0
    x_21        flow_9      -1.0
    x_21        link_21     1.0
    x_22        OBJ       1.2
    x_22        flow_31     1.0
    x_22        flow_37     -1.0
    x_22        link_22     1.0
    x_23        OBJ       77.19
    x_23        flow_23     1.0
    x_23        flow_39     -1.0
    x_23        link_23     1.0
    x_24        OBJ       23.24
    x_24        flow_39     1.0
    x_24        flow_41     -1.0
    x_24        link_24     1.0
    x_25        OBJ       1.5
    x_25        flow_43     1.0
    x_25        flow_35     -1.0
    x_25        link_25     1.0
    x_26        OBJ       46.44
    x_26        flow_12     1.0
    x_26        flow_4      -1.0
    x_26        link_26     1.0
    x_27        OBJ       0.88
    x_27        flow_3      1.0
    x_27        flow_6      -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.02
    x_28        flow_39     1.0
    x_28        flow_1      -1.0
    x_28        link_28     1.0
    x_29        OBJ       48.45
    x_29        flow_16     1.0
    x_29        flow_22     -1.0
    x_29        link_29     1.0
    x_30        OBJ       0.71
    x_30        flow_29     1.0
    x_30        flow_30     -1.0
    x_30        link_30     1.0
    x_31        OBJ       2.23
    x_31        flow_47     1.0
    x_31        flow_16     -1.0
    x_31        link_31     1.0
    x_32        OBJ       1.86
    x_32        flow_33     1.0
    x_32        flow_23     -1.0
    x_32        link_32     1.0
    x_33        OBJ       61.77
    x_33        flow_19     1.0
    x_33        flow_41     -1.0
    x_33        link_33     1.0
    x_34        OBJ       51.96
    x_34        flow_10     1.0
    x_34        flow_22     -1.0
    x_34        link_34     1.0
    x_35        OBJ       67.3
    x_35        flow_40     1.0
    x_35        flow_14     -1.0
    x_35        link_35     1.0
    x_36        OBJ       33.6
    x_36        flow_15     1.0
    x_36        flow_25     -1.0
    x_36        link_36     1.0
    x_37        OBJ       67.41
    x_37        flow_46     1.0
    x_37        flow_1      -1.0
    x_37        link_37     1.0
    x_38        OBJ       46.83
    x_38        flow_44     1.0
    x_38        flow_38     -1.0
    x_38        link_38     1.0
    x_39        OBJ       1.07
    x_39        flow_23     1.0
    x_39        flow_5      -1.0
    x_39        link_39     1.0
    x_40        OBJ       56.62
    x_40        flow_30     1.0
    x_40        flow_39     -1.0
    x_40        link_40     1.0
    x_41        OBJ       2.15
    x_41        flow_22     1.0
    x_41        flow_41     -1.0
    x_41        link_41     1.0
    x_42        OBJ       2.72
    x_42        flow_45     1.0
    x_42        flow_48     -1.0
    x_42        link_42     1.0
    x_43        OBJ       78.3
    x_43        flow_21     1.0
    x_43        flow_5      -1.0
    x_43        link_43     1.0
    x_44        OBJ       30.2
    x_44        flow_47     1.0
    x_44        flow_5      -1.0
    x_44        link_44     1.0
    x_45        OBJ       28.77
    x_45        flow_37     1.0
    x_45        flow_29     -1.0
    x_45        link_45     1.0
    x_46        OBJ       1.87
    x_46        flow_42     1.0
    x_46        flow_22     -1.0
    x_46        link_46     1.0
    x_47        OBJ       2.37
    x_47        flow_46     1.0
    x_47        flow_41     -1.0
    x_47        link_47     1.0
    x_48        OBJ       1.03
    x_48        flow_12     1.0
    x_48        flow_13     -1.0
    x_48        link_48     1.0
    x_49        OBJ       1.55
    x_49        flow_37     1.0
    x_49        flow_20     -1.0
    x_49        link_49     1.0
    x_50        OBJ       68.9
    x_50        flow_22     1.0
    x_50        flow_29     -1.0
    x_50        link_50     1.0
    x_51        OBJ       51.41
    x_51        flow_32     1.0
    x_51        flow_8      -1.0
    x_51        link_51     1.0
    x_52        OBJ       66.56
    x_52        flow_49     1.0
    x_52        flow_11     -1.0
    x_52        link_52     1.0
    x_53        OBJ       39.56
    x_53        flow_46     1.0
    x_53        flow_7      -1.0
    x_53        link_53     1.0
    x_54        OBJ       1.9
    x_54        flow_30     1.0
    x_54        flow_49     -1.0
    x_54        link_54     1.0
    x_55        OBJ       1.63
    x_55        flow_2      1.0
    x_55        flow_49     -1.0
    x_55        link_55     1.0
    x_56        OBJ       50.33
    x_56        flow_28     1.0
    x_56        flow_20     -1.0
    x_56        link_56     1.0
    x_57        OBJ       68.44
    x_57        flow_17     1.0
    x_57        flow_28     -1.0
    x_57        link_57     1.0
    x_58        OBJ       76.53
    x_58        flow_44     1.0
    x_58        flow_33     -1.0
    x_58        link_58     1.0
    x_59        OBJ       0.8
    x_59        flow_12     1.0
    x_59        flow_28     -1.0
    x_59        link_59     1.0
    x_60        OBJ       1.03
    x_60        flow_42     1.0
    x_60        flow_15     -1.0
    x_60        link_60     1.0
    x_61        OBJ       58.61
    x_61        flow_49     1.0
    x_61        flow_9      -1.0
    x_61        link_61     1.0
    x_62        OBJ       2.88
    x_62        flow_8      1.0
    x_62        flow_29     -1.0
    x_62        link_62     1.0
    x_63        OBJ       29.69
    x_63        flow_10     1.0
    x_63        flow_42     -1.0
    x_63        link_63     1.0
    x_64        OBJ       1.39
    x_64        flow_25     1.0
    x_64        flow_21     -1.0
    x_64        link_64     1.0
    x_65        OBJ       46.43
    x_65        flow_1      1.0
    x_65        flow_21     -1.0
    x_65        link_65     1.0
    x_66        OBJ       2.9
    x_66        flow_33     1.0
    x_66        flow_39     -1.0
    x_66        link_66     1.0
    x_67        OBJ       1.18
    x_67        flow_14     1.0
    x_67        flow_6      -1.0
    x_67        link_67     1.0
    x_68        OBJ       1.56
    x_68        flow_17     1.0
    x_68        flow_48     -1.0
    x_68        link_68     1.0
    x_69        OBJ       2.8
    x_69        flow_16     1.0
    x_69        flow_25     -1.0
    x_69        link_69     1.0
    x_70        OBJ       2.5
    x_70        flow_20     1.0
    x_70        flow_5      -1.0
    x_70        link_70     1.0
    x_71        OBJ       68.1
    x_71        flow_17     1.0
    x_71        flow_1      -1.0
    x_71        link_71     1.0
    x_72        OBJ       0.8
    x_72        flow_14     1.0
    x_72        flow_4      -1.0
    x_72        link_72     1.0
    x_73        OBJ       22.59
    x_73        flow_26     1.0
    x_73        flow_17     -1.0
    x_73        link_73     1.0
    x_74        OBJ       1.0
    x_74        flow_10     1.0
    x_74        flow_16     -1.0
    x_74        link_74     1.0
    x_75        OBJ       1.61
    x_75        flow_33     1.0
    x_75        flow_48     -1.0
    x_75        link_75     1.0
    x_76        OBJ       22.22
    x_76        flow_22     1.0
    x_76        flow_1      -1.0
    x_76        link_76     1.0
    x_77        OBJ       34.74
    x_77        flow_35     1.0
    x_77        flow_12     -1.0
    x_77        link_77     1.0
    x_78        OBJ       52.75
    x_78        flow_41     1.0
    x_78        flow_27     -1.0
    x_78        link_78     1.0
    x_79        OBJ       1.07
    x_79        flow_19     1.0
    x_79        flow_44     -1.0
    x_79        link_79     1.0
    x_80        OBJ       2.97
    x_80        flow_46     1.0
    x_80        flow_40     -1.0
    x_80        link_80     1.0
    x_81        OBJ       2.35
    x_81        flow_8      1.0
    x_81        flow_0      -1.0
    x_81        link_81     1.0
    x_82        OBJ       42.85
    x_82        flow_3      1.0
    x_82        flow_5      -1.0
    x_82        link_82     1.0
    x_83        OBJ       22.71
    x_83        flow_38     1.0
    x_83        flow_15     -1.0
    x_83        link_83     1.0
    x_84        OBJ       2.9
    x_84        flow_28     1.0
    x_84        flow_0      -1.0
    x_84        link_84     1.0
    x_85        OBJ       2.71
    x_85        flow_20     1.0
    x_85        flow_15     -1.0
    x_85        link_85     1.0
    x_86        OBJ       1.69
    x_86        flow_0      1.0
    x_86        flow_21     -1.0
    x_86        link_86     1.0
    x_87        OBJ       25.45
    x_87        flow_15     1.0
    x_87        flow_32     -1.0
    x_87        link_87     1.0
    x_88        OBJ       0.56
    x_88        flow_25     1.0
    x_88        flow_37     -1.0
    x_88        link_88     1.0
    x_89        OBJ       71.19
    x_89        flow_5      1.0
    x_89        flow_37     -1.0
    x_89        link_89     1.0
    x_90        OBJ       63.24
    x_90        flow_38     1.0
    x_90        flow_24     -1.0
    x_90        link_90     1.0
    x_91        OBJ       22.63
    x_91        flow_46     1.0
    x_91        flow_39     -1.0
    x_91        link_91     1.0
    x_92        OBJ       68.73
    x_92        flow_40     1.0
    x_92        flow_27     -1.0
    x_92        link_92     1.0
    x_93        OBJ       68.77
    x_93        flow_48     1.0
    x_93        flow_32     -1.0
    x_93        link_93     1.0
    x_94        OBJ       61.6
    x_94        flow_37     1.0
    x_94        flow_45     -1.0
    x_94        link_94     1.0
    x_95        OBJ       77.57
    x_95        flow_2      1.0
    x_95        flow_8      -1.0
    x_95        link_95     1.0
    x_96        OBJ       57.57
    x_96        flow_35     1.0
    x_96        flow_3      -1.0
    x_96        link_96     1.0
    x_97        OBJ       0.68
    x_97        flow_16     1.0
    x_97        flow_0      -1.0
    x_97        link_97     1.0
    x_98        OBJ       64.74
    x_98        flow_5      1.0
    x_98        flow_42     -1.0
    x_98        link_98     1.0
    x_99        OBJ       2.39
    x_99        flow_4      1.0
    x_99        flow_16     -1.0
    x_99        link_99     1.0
    x_100       OBJ       24.6
    x_100       flow_29     1.0
    x_100       flow_31     -1.0
    x_100       link_100    1.0
    x_101       OBJ       58.57
    x_101       flow_49     1.0
    x_101       flow_2      -1.0
    x_101       link_101    1.0
    x_102       OBJ       61.57
    x_102       flow_21     1.0
    x_102       flow_16     -1.0
    x_102       link_102    1.0
    x_103       OBJ       1.17
    x_103       flow_0      1.0
    x_103       flow_30     -1.0
    x_103       link_103    1.0
    x_104       OBJ       2.27
    x_104       flow_13     1.0
    x_104       flow_43     -1.0
    x_104       link_104    1.0
    x_105       OBJ       2.73
    x_105       flow_29     1.0
    x_105       flow_49     -1.0
    x_105       link_105    1.0
    x_106       OBJ       0.69
    x_106       flow_30     1.0
    x_106       flow_1      -1.0
    x_106       link_106    1.0
    x_107       OBJ       2.86
    x_107       flow_17     1.0
    x_107       flow_24     -1.0
    x_107       link_107    1.0
    x_108       OBJ       35.71
    x_108       flow_5      1.0
    x_108       flow_9      -1.0
    x_108       link_108    1.0
    x_109       OBJ       0.78
    x_109       flow_40     1.0
    x_109       flow_32     -1.0
    x_109       link_109    1.0
    x_110       OBJ       0.51
    x_110       flow_31     1.0
    x_110       flow_25     -1.0
    x_110       link_110    1.0
    x_111       OBJ       44.97
    x_111       flow_25     1.0
    x_111       flow_19     -1.0
    x_111       link_111    1.0
    x_112       OBJ       1.35
    x_112       flow_21     1.0
    x_112       flow_0      -1.0
    x_112       link_112    1.0
    x_113       OBJ       37.39
    x_113       flow_45     1.0
    x_113       flow_0      -1.0
    x_113       link_113    1.0
    x_114       OBJ       2.81
    x_114       flow_24     1.0
    x_114       flow_37     -1.0
    x_114       link_114    1.0
    x_115       OBJ       2.59
    x_115       flow_3      1.0
    x_115       flow_17     -1.0
    x_115       link_115    1.0
    x_116       OBJ       1.29
    x_116       flow_15     1.0
    x_116       flow_17     -1.0
    x_116       link_116    1.0
    x_117       OBJ       57.85
    x_117       flow_27     1.0
    x_117       flow_1      -1.0
    x_117       link_117    1.0
    x_118       OBJ       22.97
    x_118       flow_35     1.0
    x_118       flow_13     -1.0
    x_118       link_118    1.0
    x_119       OBJ       2.67
    x_119       flow_39     1.0
    x_119       flow_48     -1.0
    x_119       link_119    1.0
    x_120       OBJ       1.36
    x_120       flow_8      1.0
    x_120       flow_10     -1.0
    x_120       link_120    1.0
    x_121       OBJ       2.14
    x_121       flow_47     1.0
    x_121       flow_41     -1.0
    x_121       link_121    1.0
    x_122       OBJ       2.11
    x_122       flow_42     1.0
    x_122       flow_25     -1.0
    x_122       link_122    1.0
    x_123       OBJ       2.77
    x_123       flow_31     1.0
    x_123       flow_35     -1.0
    x_123       link_123    1.0
    x_124       OBJ       34.65
    x_124       flow_27     1.0
    x_124       flow_8      -1.0
    x_124       link_124    1.0
    x_125       OBJ       1.15
    x_125       flow_5      1.0
    x_125       flow_20     -1.0
    x_125       link_125    1.0
    x_126       OBJ       2.36
    x_126       flow_47     1.0
    x_126       flow_26     -1.0
    x_126       link_126    1.0
    x_127       OBJ       1.19
    x_127       flow_21     1.0
    x_127       flow_48     -1.0
    x_127       link_127    1.0
    x_128       OBJ       67.42
    x_128       flow_43     1.0
    x_128       flow_32     -1.0
    x_128       link_128    1.0
    x_129       OBJ       2.11
    x_129       flow_17     1.0
    x_129       flow_15     -1.0
    x_129       link_129    1.0
    x_130       OBJ       2.27
    x_130       flow_1      1.0
    x_130       flow_8      -1.0
    x_130       link_130    1.0
    x_131       OBJ       1.48
    x_131       flow_37     1.0
    x_131       flow_31     -1.0
    x_131       link_131    1.0
    x_132       OBJ       34.91
    x_132       flow_33     1.0
    x_132       flow_29     -1.0
    x_132       link_132    1.0
    x_133       OBJ       26.53
    x_133       flow_9      1.0
    x_133       flow_33     -1.0
    x_133       link_133    1.0
    x_134       OBJ       25.1
    x_134       flow_41     1.0
    x_134       flow_48     -1.0
    x_134       link_134    1.0
    x_135       OBJ       22.26
    x_135       flow_8      1.0
    x_135       flow_14     -1.0
    x_135       link_135    1.0
    x_136       OBJ       46.25
    x_136       flow_40     1.0
    x_136       flow_16     -1.0
    x_136       link_136    1.0
    x_137       OBJ       54.97
    x_137       flow_4      1.0
    x_137       flow_19     -1.0
    x_137       link_137    1.0
    x_138       OBJ       1.25
    x_138       flow_38     1.0
    x_138       flow_0      -1.0
    x_138       link_138    1.0
    x_139       OBJ       1.09
    x_139       flow_41     1.0
    x_139       flow_15     -1.0
    x_139       link_139    1.0
    x_140       OBJ       0.55
    x_140       flow_45     1.0
    x_140       flow_41     -1.0
    x_140       link_140    1.0
    x_141       OBJ       1.07
    x_141       flow_41     1.0
    x_141       flow_26     -1.0
    x_141       link_141    1.0
    x_142       OBJ       1.35
    x_142       flow_14     1.0
    x_142       flow_31     -1.0
    x_142       link_142    1.0
    x_143       OBJ       1.23
    x_143       flow_25     1.0
    x_143       flow_12     -1.0
    x_143       link_143    1.0
    x_144       OBJ       38.7
    x_144       flow_13     1.0
    x_144       flow_31     -1.0
    x_144       link_144    1.0
    x_145       OBJ       2.72
    x_145       flow_29     1.0
    x_145       flow_14     -1.0
    x_145       link_145    1.0
    x_146       OBJ       1.06
    x_146       flow_31     1.0
    x_146       flow_39     -1.0
    x_146       link_146    1.0
    x_147       OBJ       1.48
    x_147       flow_3      1.0
    x_147       flow_38     -1.0
    x_147       link_147    1.0
    x_148       OBJ       0.65
    x_148       flow_9      1.0
    x_148       flow_26     -1.0
    x_148       link_148    1.0
    x_149       OBJ       0.7
    x_149       flow_20     1.0
    x_149       flow_46     -1.0
    x_149       link_149    1.0
    x_150       OBJ       64.78
    x_150       flow_11     1.0
    x_150       flow_41     -1.0
    x_150       link_150    1.0
    x_151       OBJ       79.1
    x_151       flow_46     1.0
    x_151       flow_24     -1.0
    x_151       link_151    1.0
    x_152       OBJ       1.38
    x_152       flow_0      1.0
    x_152       flow_5      -1.0
    x_152       link_152    1.0
    x_153       OBJ       1.39
    x_153       flow_35     1.0
    x_153       flow_48     -1.0
    x_153       link_153    1.0
    x_154       OBJ       1.68
    x_154       flow_27     1.0
    x_154       flow_5      -1.0
    x_154       link_154    1.0
    x_155       OBJ       2.74
    x_155       flow_12     1.0
    x_155       flow_20     -1.0
    x_155       link_155    1.0
    x_156       OBJ       22.44
    x_156       flow_15     1.0
    x_156       flow_40     -1.0
    x_156       link_156    1.0
    x_157       OBJ       0.66
    x_157       flow_3      1.0
    x_157       flow_16     -1.0
    x_157       link_157    1.0
    x_158       OBJ       57.02
    x_158       flow_17     1.0
    x_158       flow_21     -1.0
    x_158       link_158    1.0
    x_159       OBJ       37.84
    x_159       flow_44     1.0
    x_159       flow_20     -1.0
    x_159       link_159    1.0
    x_160       OBJ       1.08
    x_160       flow_40     1.0
    x_160       flow_4      -1.0
    x_160       link_160    1.0
    x_161       OBJ       74.81
    x_161       flow_49     1.0
    x_161       flow_24     -1.0
    x_161       link_161    1.0
    x_162       OBJ       2.83
    x_162       flow_31     1.0
    x_162       flow_11     -1.0
    x_162       link_162    1.0
    x_163       OBJ       55.74
    x_163       flow_29     1.0
    x_163       flow_23     -1.0
    x_163       link_163    1.0
    x_164       OBJ       0.66
    x_164       flow_48     1.0
    x_164       flow_10     -1.0
    x_164       link_164    1.0
    x_165       OBJ       1.57
    x_165       flow_34     1.0
    x_165       flow_20     -1.0
    x_165       link_165    1.0
    x_166       OBJ       0.74
    x_166       flow_16     1.0
    x_166       flow_39     -1.0
    x_166       link_166    1.0
    x_167       OBJ       1.54
    x_167       flow_28     1.0
    x_167       flow_11     -1.0
    x_167       link_167    1.0
    x_168       OBJ       66.43
    x_168       flow_15     1.0
    x_168       flow_47     -1.0
    x_168       link_168    1.0
    x_169       OBJ       1.14
    x_169       flow_17     1.0
    x_169       flow_36     -1.0
    x_169       link_169    1.0
    x_170       OBJ       54.7
    x_170       flow_9      1.0
    x_170       flow_18     -1.0
    x_170       link_170    1.0
    x_171       OBJ       33.88
    x_171       flow_16     1.0
    x_171       flow_15     -1.0
    x_171       link_171    1.0
    x_172       OBJ       1.69
    x_172       flow_29     1.0
    x_172       flow_2      -1.0
    x_172       link_172    1.0
    x_173       OBJ       1.23
    x_173       flow_28     1.0
    x_173       flow_23     -1.0
    x_173       link_173    1.0
    x_174       OBJ       0.69
    x_174       flow_38     1.0
    x_174       flow_37     -1.0
    x_174       link_174    1.0
    x_175       OBJ       2.44
    x_175       flow_28     1.0
    x_175       flow_38     -1.0
    x_175       link_175    1.0
    x_176       OBJ       40.98
    x_176       flow_40     1.0
    x_176       flow_38     -1.0
    x_176       link_176    1.0
    x_177       OBJ       1.14
    x_177       flow_9      1.0
    x_177       flow_2      -1.0
    x_177       link_177    1.0
    x_178       OBJ       44.54
    x_178       flow_13     1.0
    x_178       flow_0      -1.0
    x_178       link_178    1.0
    x_179       OBJ       2.49
    x_179       flow_19     1.0
    x_179       flow_4      -1.0
    x_179       link_179    1.0
    x_180       OBJ       59.84
    x_180       flow_26     1.0
    x_180       flow_6      -1.0
    x_180       link_180    1.0
    x_181       OBJ       2.24
    x_181       flow_5      1.0
    x_181       flow_41     -1.0
    x_181       link_181    1.0
    x_182       OBJ       0.63
    x_182       flow_42     1.0
    x_182       flow_19     -1.0
    x_182       link_182    1.0
    x_183       OBJ       41.83
    x_183       flow_1      1.0
    x_183       flow_49     -1.0
    x_183       link_183    1.0
    x_184       OBJ       46.05
    x_184       flow_25     1.0
    x_184       flow_13     -1.0
    x_184       link_184    1.0
    x_185       OBJ       41.88
    x_185       flow_5      1.0
    x_185       flow_25     -1.0
    x_185       link_185    1.0
    x_186       OBJ       58.44
    x_186       flow_0      1.0
    x_186       flow_3      -1.0
    x_186       link_186    1.0
    x_187       OBJ       64.23
    x_187       flow_36     1.0
    x_187       flow_39     -1.0
    x_187       link_187    1.0
    x_188       OBJ       75.53
    x_188       flow_18     1.0
    x_188       flow_10     -1.0
    x_188       link_188    1.0
    x_189       OBJ       2.59
    x_189       flow_48     1.0
    x_189       flow_12     -1.0
    x_189       link_189    1.0
    x_190       OBJ       58.18
    x_190       flow_20     1.0
    x_190       flow_3      -1.0
    x_190       link_190    1.0
    x_191       OBJ       29.62
    x_191       flow_39     1.0
    x_191       flow_44     -1.0
    x_191       link_191    1.0
    x_192       OBJ       31.77
    x_192       flow_39     1.0
    x_192       flow_25     -1.0
    x_192       link_192    1.0
    x_193       OBJ       1.79
    x_193       flow_13     1.0
    x_193       flow_2      -1.0
    x_193       link_193    1.0
    x_194       OBJ       68.94
    x_194       flow_9      1.0
    x_194       flow_15     -1.0
    x_194       link_194    1.0
    x_195       OBJ       2.6
    x_195       flow_48     1.0
    x_195       flow_43     -1.0
    x_195       link_195    1.0
    x_196       OBJ       66.69
    x_196       flow_29     1.0
    x_196       flow_35     -1.0
    x_196       link_196    1.0
    x_197       OBJ       2.15
    x_197       flow_37     1.0
    x_197       flow_15     -1.0
    x_197       link_197    1.0
    x_198       OBJ       2.97
    x_198       flow_11     1.0
    x_198       flow_1      -1.0
    x_198       link_198    1.0
    x_199       OBJ       47.5
    x_199       flow_48     1.0
    x_199       flow_39     -1.0
    x_199       link_199    1.0
    x_200       OBJ       1.4
    x_200       flow_25     1.0
    x_200       flow_6      -1.0
    x_200       link_200    1.0
    x_201       OBJ       22.45
    x_201       flow_28     1.0
    x_201       flow_32     -1.0
    x_201       link_201    1.0
    x_202       OBJ       50.69
    x_202       flow_46     1.0
    x_202       flow_20     -1.0
    x_202       link_202    1.0
    x_203       OBJ       28.17
    x_203       flow_24     1.0
    x_203       flow_41     -1.0
    x_203       link_203    1.0
    x_204       OBJ       2.71
    x_204       flow_7      1.0
    x_204       flow_12     -1.0
    x_204       link_204    1.0
    x_205       OBJ       75.84
    x_205       flow_10     1.0
    x_205       flow_43     -1.0
    x_205       link_205    1.0
    x_206       OBJ       2.03
    x_206       flow_16     1.0
    x_206       flow_10     -1.0
    x_206       link_206    1.0
    x_207       OBJ       75.19
    x_207       flow_9      1.0
    x_207       flow_16     -1.0
    x_207       link_207    1.0
    x_208       OBJ       1.43
    x_208       flow_39     1.0
    x_208       flow_32     -1.0
    x_208       link_208    1.0
    x_209       OBJ       60.78
    x_209       flow_10     1.0
    x_209       flow_40     -1.0
    x_209       link_209    1.0
    x_210       OBJ       22.91
    x_210       flow_16     1.0
    x_210       flow_7      -1.0
    x_210       link_210    1.0
    x_211       OBJ       61.32
    x_211       flow_28     1.0
    x_211       flow_35     -1.0
    x_211       link_211    1.0
    x_212       OBJ       64.28
    x_212       flow_34     1.0
    x_212       flow_40     -1.0
    x_212       link_212    1.0
    x_213       OBJ       1.33
    x_213       flow_23     1.0
    x_213       flow_36     -1.0
    x_213       link_213    1.0
    x_214       OBJ       22.9
    x_214       flow_11     1.0
    x_214       flow_39     -1.0
    x_214       link_214    1.0
    x_215       OBJ       72.22
    x_215       flow_19     1.0
    x_215       flow_40     -1.0
    x_215       link_215    1.0
    x_216       OBJ       33.3
    x_216       flow_46     1.0
    x_216       flow_0      -1.0
    x_216       link_216    1.0
    x_217       OBJ       73.73
    x_217       flow_27     1.0
    x_217       flow_26     -1.0
    x_217       link_217    1.0
    x_218       OBJ       1.92
    x_218       flow_2      1.0
    x_218       flow_1      -1.0
    x_218       link_218    1.0
    x_219       OBJ       1.96
    x_219       flow_22     1.0
    x_219       flow_34     -1.0
    x_219       link_219    1.0
    x_220       OBJ       2.84
    x_220       flow_30     1.0
    x_220       flow_10     -1.0
    x_220       link_220    1.0
    x_221       OBJ       0.86
    x_221       flow_28     1.0
    x_221       flow_6      -1.0
    x_221       link_221    1.0
    x_222       OBJ       23.37
    x_222       flow_25     1.0
    x_222       flow_16     -1.0
    x_222       link_222    1.0
    x_223       OBJ       56.11
    x_223       flow_38     1.0
    x_223       flow_41     -1.0
    x_223       link_223    1.0
    x_224       OBJ       22.64
    x_224       flow_15     1.0
    x_224       flow_10     -1.0
    x_224       link_224    1.0
    x_225       OBJ       2.78
    x_225       flow_11     1.0
    x_225       flow_15     -1.0
    x_225       link_225    1.0
    x_226       OBJ       28.54
    x_226       flow_35     1.0
    x_226       flow_42     -1.0
    x_226       link_226    1.0
    x_227       OBJ       44.91
    x_227       flow_41     1.0
    x_227       flow_32     -1.0
    x_227       link_227    1.0
    x_228       OBJ       62.92
    x_228       flow_3      1.0
    x_228       flow_46     -1.0
    x_228       link_228    1.0
    x_229       OBJ       24.83
    x_229       flow_27     1.0
    x_229       flow_47     -1.0
    x_229       link_229    1.0
    x_230       OBJ       27.4
    x_230       flow_16     1.0
    x_230       flow_14     -1.0
    x_230       link_230    1.0
    x_231       OBJ       2.09
    x_231       flow_16     1.0
    x_231       flow_45     -1.0
    x_231       link_231    1.0
    x_232       OBJ       2.82
    x_232       flow_33     1.0
    x_232       flow_16     -1.0
    x_232       link_232    1.0
    x_233       OBJ       2.76
    x_233       flow_32     1.0
    x_233       flow_0      -1.0
    x_233       link_233    1.0
    x_234       OBJ       31.52
    x_234       flow_10     1.0
    x_234       flow_47     -1.0
    x_234       link_234    1.0
    x_235       OBJ       57.84
    x_235       flow_15     1.0
    x_235       flow_24     -1.0
    x_235       link_235    1.0
    x_236       OBJ       1.83
    x_236       flow_34     1.0
    x_236       flow_30     -1.0
    x_236       link_236    1.0
    x_237       OBJ       2.71
    x_237       flow_27     1.0
    x_237       flow_46     -1.0
    x_237       link_237    1.0
    x_238       OBJ       2.78
    x_238       flow_39     1.0
    x_238       flow_37     -1.0
    x_238       link_238    1.0
    x_239       OBJ       29.71
    x_239       flow_7      1.0
    x_239       flow_6      -1.0
    x_239       link_239    1.0
    x_240       OBJ       61.82
    x_240       flow_44     1.0
    x_240       flow_41     -1.0
    x_240       link_240    1.0
    x_241       OBJ       2.54
    x_241       flow_37     1.0
    x_241       flow_48     -1.0
    x_241       link_241    1.0
    x_242       OBJ       76.66
    x_242       flow_4      1.0
    x_242       flow_48     -1.0
    x_242       link_242    1.0
    x_243       OBJ       2.87
    x_243       flow_13     1.0
    x_243       flow_7      -1.0
    x_243       link_243    1.0
    x_244       OBJ       57.89
    x_244       flow_40     1.0
    x_244       flow_5      -1.0
    x_244       link_244    1.0
    x_245       OBJ       58.78
    x_245       flow_8      1.0
    x_245       flow_6      -1.0
    x_245       link_245    1.0
    x_246       OBJ       1.14
    x_246       flow_27     1.0
    x_246       flow_16     -1.0
    x_246       link_246    1.0
    x_247       OBJ       66.15
    x_247       flow_48     1.0
    x_247       flow_23     -1.0
    x_247       link_247    1.0
    x_248       OBJ       67.34
    x_248       flow_18     1.0
    x_248       flow_39     -1.0
    x_248       link_248    1.0
    x_249       OBJ       2.26
    x_249       flow_49     1.0
    x_249       flow_6      -1.0
    x_249       link_249    1.0
    x_250       OBJ       37.23
    x_250       flow_45     1.0
    x_250       flow_5      -1.0
    x_250       link_250    1.0
    x_251       OBJ       78.67
    x_251       flow_12     1.0
    x_251       flow_18     -1.0
    x_251       link_251    1.0
    x_252       OBJ       69.52
    x_252       flow_6      1.0
    x_252       flow_31     -1.0
    x_252       link_252    1.0
    x_253       OBJ       2.86
    x_253       flow_22     1.0
    x_253       flow_32     -1.0
    x_253       link_253    1.0
    x_254       OBJ       0.77
    x_254       flow_44     1.0
    x_254       flow_14     -1.0
    x_254       link_254    1.0
    x_255       OBJ       26.27
    x_255       flow_31     1.0
    x_255       flow_44     -1.0
    x_255       link_255    1.0
    x_256       OBJ       1.02
    x_256       flow_27     1.0
    x_256       flow_41     -1.0
    x_256       link_256    1.0
    x_257       OBJ       2.71
    x_257       flow_32     1.0
    x_257       flow_10     -1.0
    x_257       link_257    1.0
    x_258       OBJ       61.35
    x_258       flow_8      1.0
    x_258       flow_34     -1.0
    x_258       link_258    1.0
    x_259       OBJ       0.89
    x_259       flow_22     1.0
    x_259       flow_37     -1.0
    x_259       link_259    1.0
    x_260       OBJ       1.66
    x_260       flow_35     1.0
    x_260       flow_47     -1.0
    x_260       link_260    1.0
    x_261       OBJ       1.66
    x_261       flow_37     1.0
    x_261       flow_14     -1.0
    x_261       link_261    1.0
    x_262       OBJ       2.39
    x_262       flow_32     1.0
    x_262       flow_12     -1.0
    x_262       link_262    1.0
    x_263       OBJ       1.12
    x_263       flow_9      1.0
    x_263       flow_46     -1.0
    x_263       link_263    1.0
    x_264       OBJ       35.52
    x_264       flow_15     1.0
    x_264       flow_20     -1.0
    x_264       link_264    1.0
    x_265       OBJ       2.96
    x_265       flow_6      1.0
    x_265       flow_12     -1.0
    x_265       link_265    1.0
    x_266       OBJ       0.77
    x_266       flow_19     1.0
    x_266       flow_27     -1.0
    x_266       link_266    1.0
    x_267       OBJ       0.53
    x_267       flow_13     1.0
    x_267       flow_24     -1.0
    x_267       link_267    1.0
    x_268       OBJ       0.56
    x_268       flow_32     1.0
    x_268       flow_40     -1.0
    x_268       link_268    1.0
    x_269       OBJ       74.48
    x_269       flow_25     1.0
    x_269       flow_0      -1.0
    x_269       link_269    1.0
    x_270       OBJ       70.76
    x_270       flow_37     1.0
    x_270       flow_47     -1.0
    x_270       link_270    1.0
    x_271       OBJ       71.15
    x_271       flow_49     1.0
    x_271       flow_41     -1.0
    x_271       link_271    1.0
    x_272       OBJ       1.15
    x_272       flow_7      1.0
    x_272       flow_29     -1.0
    x_272       link_272    1.0
    x_273       OBJ       1.56
    x_273       flow_40     1.0
    x_273       flow_10     -1.0
    x_273       link_273    1.0
    x_274       OBJ       75.81
    x_274       flow_26     1.0
    x_274       flow_33     -1.0
    x_274       link_274    1.0
    x_275       OBJ       2.58
    x_275       flow_20     1.0
    x_275       flow_49     -1.0
    x_275       link_275    1.0
    x_276       OBJ       29.65
    x_276       flow_2      1.0
    x_276       flow_16     -1.0
    x_276       link_276    1.0
    x_277       OBJ       1.94
    x_277       flow_33     1.0
    x_277       flow_22     -1.0
    x_277       link_277    1.0
    x_278       OBJ       2.48
    x_278       flow_30     1.0
    x_278       flow_32     -1.0
    x_278       link_278    1.0
    x_279       OBJ       32.61
    x_279       flow_26     1.0
    x_279       flow_47     -1.0
    x_279       link_279    1.0
    x_280       OBJ       63.75
    x_280       flow_32     1.0
    x_280       flow_48     -1.0
    x_280       link_280    1.0
    x_281       OBJ       1.55
    x_281       flow_0      1.0
    x_281       flow_4      -1.0
    x_281       link_281    1.0
    x_282       OBJ       1.26
    x_282       flow_37     1.0
    x_282       flow_16     -1.0
    x_282       link_282    1.0
    x_283       OBJ       0.91
    x_283       flow_14     1.0
    x_283       flow_25     -1.0
    x_283       link_283    1.0
    x_284       OBJ       1.91
    x_284       flow_40     1.0
    x_284       flow_12     -1.0
    x_284       link_284    1.0
    x_285       OBJ       69.12
    x_285       flow_22     1.0
    x_285       flow_42     -1.0
    x_285       link_285    1.0
    x_286       OBJ       27.51
    x_286       flow_18     1.0
    x_286       flow_48     -1.0
    x_286       link_286    1.0
    x_287       OBJ       61.25
    x_287       flow_14     1.0
    x_287       flow_17     -1.0
    x_287       link_287    1.0
    x_288       OBJ       2.3
    x_288       flow_11     1.0
    x_288       flow_30     -1.0
    x_288       link_288    1.0
    x_289       OBJ       1.71
    x_289       flow_41     1.0
    x_289       flow_19     -1.0
    x_289       link_289    1.0
    x_290       OBJ       1.26
    x_290       flow_42     1.0
    x_290       flow_23     -1.0
    x_290       link_290    1.0
    x_291       OBJ       28.42
    x_291       flow_36     1.0
    x_291       flow_20     -1.0
    x_291       link_291    1.0
    x_292       OBJ       32.58
    x_292       flow_37     1.0
    x_292       flow_0      -1.0
    x_292       link_292    1.0
    x_293       OBJ       0.86
    x_293       flow_16     1.0
    x_293       flow_38     -1.0
    x_293       link_293    1.0
    x_294       OBJ       32.51
    x_294       flow_28     1.0
    x_294       flow_22     -1.0
    x_294       link_294    1.0
    x_295       OBJ       56.5
    x_295       flow_10     1.0
    x_295       flow_39     -1.0
    x_295       link_295    1.0
    x_296       OBJ       31.84
    x_296       flow_35     1.0
    x_296       flow_40     -1.0
    x_296       link_296    1.0
    x_297       OBJ       60.27
    x_297       flow_5      1.0
    x_297       flow_47     -1.0
    x_297       link_297    1.0
    x_298       OBJ       0.85
    x_298       flow_16     1.0
    x_298       flow_26     -1.0
    x_298       link_298    1.0
    x_299       OBJ       62.03
    x_299       flow_30     1.0
    x_299       flow_29     -1.0
    x_299       link_299    1.0
    x_300       OBJ       20.4
    x_300       flow_34     1.0
    x_300       flow_38     -1.0
    x_300       link_300    1.0
    x_301       OBJ       1.24
    x_301       flow_44     1.0
    x_301       flow_36     -1.0
    x_301       link_301    1.0
    x_302       OBJ       2.09
    x_302       flow_26     1.0
    x_302       flow_43     -1.0
    x_302       link_302    1.0
    x_303       OBJ       2.34
    x_303       flow_1      1.0
    x_303       flow_39     -1.0
    x_303       link_303    1.0
    x_304       OBJ       2.39
    x_304       flow_6      1.0
    x_304       flow_32     -1.0
    x_304       link_304    1.0
    x_305       OBJ       40.32
    x_305       flow_45     1.0
    x_305       flow_26     -1.0
    x_305       link_305    1.0
    x_306       OBJ       53.25
    x_306       flow_21     1.0
    x_306       flow_30     -1.0
    x_306       link_306    1.0
    x_307       OBJ       1.89
    x_307       flow_27     1.0
    x_307       flow_21     -1.0
    x_307       link_307    1.0
    x_308       OBJ       1.76
    x_308       flow_22     1.0
    x_308       flow_31     -1.0
    x_308       link_308    1.0
    x_309       OBJ       67.52
    x_309       flow_22     1.0
    x_309       flow_13     -1.0
    x_309       link_309    1.0
    x_310       OBJ       2.93
    x_310       flow_45     1.0
    x_310       flow_19     -1.0
    x_310       link_310    1.0
    x_311       OBJ       44.36
    x_311       flow_25     1.0
    x_311       flow_46     -1.0
    x_311       link_311    1.0
    x_312       OBJ       0.97
    x_312       flow_19     1.0
    x_312       flow_6      -1.0
    x_312       link_312    1.0
    x_313       OBJ       1.75
    x_313       flow_49     1.0
    x_313       flow_42     -1.0
    x_313       link_313    1.0
    x_314       OBJ       61.78
    x_314       flow_39     1.0
    x_314       flow_9      -1.0
    x_314       link_314    1.0
    x_315       OBJ       2.08
    x_315       flow_5      1.0
    x_315       flow_13     -1.0
    x_315       link_315    1.0
    x_316       OBJ       0.59
    x_316       flow_6      1.0
    x_316       flow_42     -1.0
    x_316       link_316    1.0
    x_317       OBJ       28.32
    x_317       flow_0      1.0
    x_317       flow_23     -1.0
    x_317       link_317    1.0
    x_318       OBJ       0.59
    x_318       flow_16     1.0
    x_318       flow_19     -1.0
    x_318       link_318    1.0
    x_319       OBJ       23.28
    x_319       flow_41     1.0
    x_319       flow_37     -1.0
    x_319       link_319    1.0
    x_320       OBJ       54.52
    x_320       flow_7      1.0
    x_320       flow_49     -1.0
    x_320       link_320    1.0
    x_321       OBJ       55.63
    x_321       flow_4      1.0
    x_321       flow_0      -1.0
    x_321       link_321    1.0
    x_322       OBJ       52.93
    x_322       flow_9      1.0
    x_322       flow_30     -1.0
    x_322       link_322    1.0
    x_323       OBJ       45.62
    x_323       flow_13     1.0
    x_323       flow_9      -1.0
    x_323       link_323    1.0
    x_324       OBJ       0.8
    x_324       flow_7      1.0
    x_324       flow_5      -1.0
    x_324       link_324    1.0
    x_325       OBJ       2.33
    x_325       flow_46     1.0
    x_325       flow_36     -1.0
    x_325       link_325    1.0
    x_326       OBJ       61.69
    x_326       flow_23     1.0
    x_326       flow_49     -1.0
    x_326       link_326    1.0
    x_327       OBJ       62.55
    x_327       flow_5      1.0
    x_327       flow_18     -1.0
    x_327       link_327    1.0
    x_328       OBJ       0.65
    x_328       flow_3      1.0
    x_328       flow_45     -1.0
    x_328       link_328    1.0
    x_329       OBJ       1.28
    x_329       flow_39     1.0
    x_329       flow_5      -1.0
    x_329       link_329    1.0
    x_330       OBJ       1.42
    x_330       flow_31     1.0
    x_330       flow_38     -1.0
    x_330       link_330    1.0
    x_331       OBJ       2.92
    x_331       flow_30     1.0
    x_331       flow_43     -1.0
    x_331       link_331    1.0
    x_332       OBJ       2.47
    x_332       flow_26     1.0
    x_332       flow_30     -1.0
    x_332       link_332    1.0
    x_333       OBJ       1.2
    x_333       flow_48     1.0
    x_333       flow_36     -1.0
    x_333       link_333    1.0
    x_334       OBJ       2.01
    x_334       flow_45     1.0
    x_334       flow_38     -1.0
    x_334       link_334    1.0
    x_335       OBJ       55.08
    x_335       flow_9      1.0
    x_335       flow_38     -1.0
    x_335       link_335    1.0
    x_336       OBJ       73.77
    x_336       flow_43     1.0
    x_336       flow_24     -1.0
    x_336       link_336    1.0
    x_337       OBJ       1.17
    x_337       flow_44     1.0
    x_337       flow_0      -1.0
    x_337       link_337    1.0
    x_338       OBJ       0.85
    x_338       flow_48     1.0
    x_338       flow_2      -1.0
    x_338       link_338    1.0
    x_339       OBJ       67.84
    x_339       flow_9      1.0
    x_339       flow_17     -1.0
    x_339       link_339    1.0
    x_340       OBJ       52.4
    x_340       flow_31     1.0
    x_340       flow_22     -1.0
    x_340       link_340    1.0
    x_341       OBJ       78.94
    x_341       flow_12     1.0
    x_341       flow_48     -1.0
    x_341       link_341    1.0
    x_342       OBJ       1.02
    x_342       flow_43     1.0
    x_342       flow_25     -1.0
    x_342       link_342    1.0
    x_343       OBJ       0.72
    x_343       flow_0      1.0
    x_343       flow_24     -1.0
    x_343       link_343    1.0
    x_344       OBJ       1.8
    x_344       flow_4      1.0
    x_344       flow_14     -1.0
    x_344       link_344    1.0
    x_345       OBJ       1.97
    x_345       flow_33     1.0
    x_345       flow_20     -1.0
    x_345       link_345    1.0
    x_346       OBJ       37.39
    x_346       flow_5      1.0
    x_346       flow_11     -1.0
    x_346       link_346    1.0
    x_347       OBJ       28.94
    x_347       flow_25     1.0
    x_347       flow_49     -1.0
    x_347       link_347    1.0
    x_348       OBJ       1.66
    x_348       flow_23     1.0
    x_348       flow_6      -1.0
    x_348       link_348    1.0
    x_349       OBJ       1.8
    x_349       flow_38     1.0
    x_349       flow_1      -1.0
    x_349       link_349    1.0
    x_350       OBJ       1.92
    x_350       flow_13     1.0
    x_350       flow_36     -1.0
    x_350       link_350    1.0
    x_351       OBJ       1.62
    x_351       flow_17     1.0
    x_351       flow_27     -1.0
    x_351       link_351    1.0
    x_352       OBJ       40.33
    x_352       flow_8      1.0
    x_352       flow_16     -1.0
    x_352       link_352    1.0
    x_353       OBJ       1.89
    x_353       flow_5      1.0
    x_353       flow_1      -1.0
    x_353       link_353    1.0
    x_354       OBJ       58.39
    x_354       flow_31     1.0
    x_354       flow_4      -1.0
    x_354       link_354    1.0
    x_355       OBJ       1.08
    x_355       flow_5      1.0
    x_355       flow_16     -1.0
    x_355       link_355    1.0
    x_356       OBJ       2.62
    x_356       flow_32     1.0
    x_356       flow_25     -1.0
    x_356       link_356    1.0
    x_357       OBJ       2.85
    x_357       flow_46     1.0
    x_357       flow_14     -1.0
    x_357       link_357    1.0
    x_358       OBJ       22.82
    x_358       flow_35     1.0
    x_358       flow_1      -1.0
    x_358       link_358    1.0
    x_359       OBJ       0.86
    x_359       flow_48     1.0
    x_359       flow_30     -1.0
    x_359       link_359    1.0
    x_360       OBJ       1.98
    x_360       flow_43     1.0
    x_360       flow_47     -1.0
    x_360       link_360    1.0
    x_361       OBJ       1.48
    x_361       flow_30     1.0
    x_361       flow_20     -1.0
    x_361       link_361    1.0
    x_362       OBJ       73.53
    x_362       flow_15     1.0
    x_362       flow_9      -1.0
    x_362       link_362    1.0
    x_363       OBJ       33.23
    x_363       flow_2      1.0
    x_363       flow_10     -1.0
    x_363       link_363    1.0
    x_364       OBJ       1.62
    x_364       flow_23     1.0
    x_364       flow_47     -1.0
    x_364       link_364    1.0
    x_365       OBJ       2.93
    x_365       flow_1      1.0
    x_365       flow_40     -1.0
    x_365       link_365    1.0
    x_366       OBJ       28.57
    x_366       flow_30     1.0
    x_366       flow_7      -1.0
    x_366       link_366    1.0
    x_367       OBJ       2.72
    x_367       flow_11     1.0
    x_367       flow_45     -1.0
    x_367       link_367    1.0
    x_368       OBJ       0.89
    x_368       flow_17     1.0
    x_368       flow_26     -1.0
    x_368       link_368    1.0
    x_369       OBJ       35.64
    x_369       flow_18     1.0
    x_369       flow_21     -1.0
    x_369       link_369    1.0
    x_370       OBJ       2.74
    x_370       flow_9      1.0
    x_370       flow_32     -1.0
    x_370       link_370    1.0
    x_371       OBJ       27.15
    x_371       flow_35     1.0
    x_371       flow_30     -1.0
    x_371       link_371    1.0
    x_372       OBJ       2.74
    x_372       flow_6      1.0
    x_372       flow_24     -1.0
    x_372       link_372    1.0
    x_373       OBJ       20.96
    x_373       flow_18     1.0
    x_373       flow_9      -1.0
    x_373       link_373    1.0
    x_374       OBJ       1.59
    x_374       flow_33     1.0
    x_374       flow_18     -1.0
    x_374       link_374    1.0
    x_375       OBJ       51.3
    x_375       flow_11     1.0
    x_375       flow_8      -1.0
    x_375       link_375    1.0
    x_376       OBJ       0.72
    x_376       flow_12     1.0
    x_376       flow_38     -1.0
    x_376       link_376    1.0
    x_377       OBJ       0.84
    x_377       flow_48     1.0
    x_377       flow_17     -1.0
    x_377       link_377    1.0
    x_378       OBJ       0.53
    x_378       flow_12     1.0
    x_378       flow_37     -1.0
    x_378       link_378    1.0
    x_379       OBJ       51.11
    x_379       flow_26     1.0
    x_379       flow_46     -1.0
    x_379       link_379    1.0
    x_380       OBJ       1.52
    x_380       flow_40     1.0
    x_380       flow_31     -1.0
    x_380       link_380    1.0
    x_381       OBJ       1.91
    x_381       flow_42     1.0
    x_381       flow_17     -1.0
    x_381       link_381    1.0
    x_382       OBJ       1.99
    x_382       flow_10     1.0
    x_382       flow_44     -1.0
    x_382       link_382    1.0
    x_383       OBJ       1.39
    x_383       flow_28     1.0
    x_383       flow_33     -1.0
    x_383       link_383    1.0
    x_384       OBJ       73.88
    x_384       flow_45     1.0
    x_384       flow_24     -1.0
    x_384       link_384    1.0
    x_385       OBJ       0.56
    x_385       flow_46     1.0
    x_385       flow_31     -1.0
    x_385       link_385    1.0
    x_386       OBJ       33.42
    x_386       flow_1      1.0
    x_386       flow_15     -1.0
    x_386       link_386    1.0
    x_387       OBJ       77.32
    x_387       flow_19     1.0
    x_387       flow_16     -1.0
    x_387       link_387    1.0
    x_388       OBJ       2.59
    x_388       flow_47     1.0
    x_388       flow_12     -1.0
    x_388       link_388    1.0
    x_389       OBJ       26.17
    x_389       flow_33     1.0
    x_389       flow_15     -1.0
    x_389       link_389    1.0
    x_390       OBJ       1.66
    x_390       flow_11     1.0
    x_390       flow_2      -1.0
    x_390       link_390    1.0
    x_391       OBJ       1.51
    x_391       flow_17     1.0
    x_391       flow_7      -1.0
    x_391       link_391    1.0
    x_392       OBJ       64.79
    x_392       flow_9      1.0
    x_392       flow_42     -1.0
    x_392       link_392    1.0
    x_393       OBJ       2.6
    x_393       flow_24     1.0
    x_393       flow_44     -1.0
    x_393       link_393    1.0
    x_394       OBJ       1.5
    x_394       flow_3      1.0
    x_394       flow_49     -1.0
    x_394       link_394    1.0
    x_395       OBJ       74.77
    x_395       flow_27     1.0
    x_395       flow_36     -1.0
    x_395       link_395    1.0
    x_396       OBJ       2.2
    x_396       flow_20     1.0
    x_396       flow_33     -1.0
    x_396       link_396    1.0
    x_397       OBJ       41.87
    x_397       flow_27     1.0
    x_397       flow_42     -1.0
    x_397       link_397    1.0
    x_398       OBJ       2.17
    x_398       flow_20     1.0
    x_398       flow_27     -1.0
    x_398       link_398    1.0
    x_399       OBJ       2.95
    x_399       flow_29     1.0
    x_399       flow_40     -1.0
    x_399       link_399    1.0
    x_400       OBJ       75.08
    x_400       flow_2      1.0
    x_400       flow_41     -1.0
    x_400       link_400    1.0
    x_401       OBJ       35.03
    x_401       flow_34     1.0
    x_401       flow_2      -1.0
    x_401       link_401    1.0
    x_402       OBJ       1.26
    x_402       flow_15     1.0
    x_402       flow_2      -1.0
    x_402       link_402    1.0
    x_403       OBJ       1.98
    x_403       flow_32     1.0
    x_403       flow_17     -1.0
    x_403       link_403    1.0
    x_404       OBJ       1.23
    x_404       flow_7      1.0
    x_404       flow_32     -1.0
    x_404       link_404    1.0
    x_405       OBJ       1.64
    x_405       flow_47     1.0
    x_405       flow_34     -1.0
    x_405       link_405    1.0
    x_406       OBJ       2.28
    x_406       flow_41     1.0
    x_406       flow_24     -1.0
    x_406       link_406    1.0
    x_407       OBJ       2.55
    x_407       flow_19     1.0
    x_407       flow_39     -1.0
    x_407       link_407    1.0
    x_408       OBJ       42.99
    x_408       flow_14     1.0
    x_408       flow_12     -1.0
    x_408       link_408    1.0
    x_409       OBJ       1.21
    x_409       flow_35     1.0
    x_409       flow_20     -1.0
    x_409       link_409    1.0
    x_410       OBJ       56.36
    x_410       flow_1      1.0
    x_410       flow_10     -1.0
    x_410       link_410    1.0
    x_411       OBJ       1.6
    x_411       flow_3      1.0
    x_411       flow_33     -1.0
    x_411       link_411    1.0
    x_412       OBJ       60.66
    x_412       flow_33     1.0
    x_412       flow_14     -1.0
    x_412       link_412    1.0
    x_413       OBJ       2.19
    x_413       flow_21     1.0
    x_413       flow_42     -1.0
    x_413       link_413    1.0
    x_414       OBJ       2.64
    x_414       flow_17     1.0
    x_414       flow_33     -1.0
    x_414       link_414    1.0
    x_415       OBJ       74.88
    x_415       flow_17     1.0
    x_415       flow_40     -1.0
    x_415       link_415    1.0
    x_416       OBJ       1.87
    x_416       flow_6      1.0
    x_416       flow_0      -1.0
    x_416       link_416    1.0
    x_417       OBJ       2.46
    x_417       flow_36     1.0
    x_417       flow_9      -1.0
    x_417       link_417    1.0
    x_418       OBJ       61.56
    x_418       flow_7      1.0
    x_418       flow_24     -1.0
    x_418       link_418    1.0
    x_419       OBJ       1.89
    x_419       flow_18     1.0
    x_419       flow_22     -1.0
    x_419       link_419    1.0
    x_420       OBJ       49.97
    x_420       flow_0      1.0
    x_420       flow_47     -1.0
    x_420       link_420    1.0
    x_421       OBJ       46.14
    x_421       flow_34     1.0
    x_421       flow_19     -1.0
    x_421       link_421    1.0
    x_422       OBJ       2.61
    x_422       flow_5      1.0
    x_422       flow_21     -1.0
    x_422       link_422    1.0
    x_423       OBJ       77.35
    x_423       flow_13     1.0
    x_423       flow_27     -1.0
    x_423       link_423    1.0
    x_424       OBJ       1.84
    x_424       flow_36     1.0
    x_424       flow_31     -1.0
    x_424       link_424    1.0
    x_425       OBJ       63.63
    x_425       flow_27     1.0
    x_425       flow_33     -1.0
    x_425       link_425    1.0
    x_426       OBJ       41.07
    x_426       flow_22     1.0
    x_426       flow_2      -1.0
    x_426       link_426    1.0
    x_427       OBJ       1.52
    x_427       flow_4      1.0
    x_427       flow_33     -1.0
    x_427       link_427    1.0
    x_428       OBJ       0.97
    x_428       flow_35     1.0
    x_428       flow_36     -1.0
    x_428       link_428    1.0
    x_429       OBJ       79.77
    x_429       flow_28     1.0
    x_429       flow_49     -1.0
    x_429       link_429    1.0
    x_430       OBJ       2.95
    x_430       flow_10     1.0
    x_430       flow_23     -1.0
    x_430       link_430    1.0
    x_431       OBJ       37.7
    x_431       flow_11     1.0
    x_431       flow_7      -1.0
    x_431       link_431    1.0
    x_432       OBJ       1.22
    x_432       flow_26     1.0
    x_432       flow_40     -1.0
    x_432       link_432    1.0
    x_433       OBJ       2.08
    x_433       flow_12     1.0
    x_433       flow_26     -1.0
    x_433       link_433    1.0
    x_434       OBJ       22.54
    x_434       flow_36     1.0
    x_434       flow_40     -1.0
    x_434       link_434    1.0
    x_435       OBJ       53.18
    x_435       flow_0      1.0
    x_435       flow_19     -1.0
    x_435       link_435    1.0
    x_436       OBJ       0.57
    x_436       flow_6      1.0
    x_436       flow_37     -1.0
    x_436       link_436    1.0
    x_437       OBJ       50.86
    x_437       flow_17     1.0
    x_437       flow_41     -1.0
    x_437       link_437    1.0
    x_438       OBJ       0.89
    x_438       flow_26     1.0
    x_438       flow_38     -1.0
    x_438       link_438    1.0
    x_439       OBJ       2.87
    x_439       flow_1      1.0
    x_439       flow_6      -1.0
    x_439       link_439    1.0
    x_440       OBJ       23.73
    x_440       flow_39     1.0
    x_440       flow_27     -1.0
    x_440       link_440    1.0
    x_441       OBJ       1.19
    x_441       flow_9      1.0
    x_441       flow_45     -1.0
    x_441       link_441    1.0
    x_442       OBJ       2.06
    x_442       flow_4      1.0
    x_442       flow_22     -1.0
    x_442       link_442    1.0
    x_443       OBJ       34.96
    x_443       flow_28     1.0
    x_443       flow_3      -1.0
    x_443       link_443    1.0
    x_444       OBJ       2.67
    x_444       flow_11     1.0
    x_444       flow_20     -1.0
    x_444       link_444    1.0
    x_445       OBJ       49.73
    x_445       flow_38     1.0
    x_445       flow_16     -1.0
    x_445       link_445    1.0
    x_446       OBJ       44.81
    x_446       flow_43     1.0
    x_446       flow_45     -1.0
    x_446       link_446    1.0
    x_447       OBJ       34.6
    x_447       flow_31     1.0
    x_447       flow_1      -1.0
    x_447       link_447    1.0
    x_448       OBJ       2.71
    x_448       flow_24     1.0
    x_448       flow_11     -1.0
    x_448       link_448    1.0
    x_449       OBJ       43.14
    x_449       flow_7      1.0
    x_449       flow_21     -1.0
    x_449       link_449    1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       173.19
    y_0         link_0      -2.0
    y_1         OBJ       55.62
    y_1         link_1      -5.0
    y_2         OBJ       58.87
    y_2         link_2      -6.0
    y_3         OBJ       1.25
    y_3         link_3      -6.0
    y_4         OBJ       4.43
    y_4         link_4      -4.0
    y_5         OBJ       3.24
    y_5         link_5      -7.0
    y_6         OBJ       2.49
    y_6         link_6      -6.0
    y_7         OBJ       2.99
    y_7         link_7      -6.0
    y_8         OBJ       117.98
    y_8         link_8      -4.0
    y_9         OBJ       3.3
    y_9         link_9      -6.0
    y_10        OBJ       4.92
    y_10        link_10     -2.0
    y_11        OBJ       189.99
    y_11        link_11     -5.0
    y_12        OBJ       168.36
    y_12        link_12     -8.0
    y_13        OBJ       3.32
    y_13        link_13     -5.0
    y_14        OBJ       3.66
    y_14        link_14     -2.0
    y_15        OBJ       152.19
    y_15        link_15     -5.0
    y_16        OBJ       53.38
    y_16        link_16     -5.0
    y_17        OBJ       1.87
    y_17        link_17     -4.0
    y_18        OBJ       180.71
    y_18        link_18     -2.0
    y_19        OBJ       70.54
    y_19        link_19     -5.0
    y_20        OBJ       3.73
    y_20        link_20     -5.0
    y_21        OBJ       148.78
    y_21        link_21     -2.0
    y_22        OBJ       71.85
    y_22        link_22     -6.0
    y_23        OBJ       3.76
    y_23        link_23     -6.0
    y_24        OBJ       4.6
    y_24        link_24     -8.0
    y_25        OBJ       65.53
    y_25        link_25     -7.0
    y_26        OBJ       1.44
    y_26        link_26     -6.0
    y_27        OBJ       65.22
    y_27        link_27     -4.0
    y_28        OBJ       106.43
    y_28        link_28     -7.0
    y_29        OBJ       1.46
    y_29        link_29     -5.0
    y_30        OBJ       65.33
    y_30        link_30     -4.0
    y_31        OBJ       127.45
    y_31        link_31     -3.0
    y_32        OBJ       54.06
    y_32        link_32     -6.0
    y_33        OBJ       2.04
    y_33        link_33     -4.0
    y_34        OBJ       4.12
    y_34        link_34     -4.0
    y_35        OBJ       4.03
    y_35        link_35     -3.0
    y_36        OBJ       3.07
    y_36        link_36     -4.0
    y_37        OBJ       2.89
    y_37        link_37     -3.0
    y_38        OBJ       4.75
    y_38        link_38     -4.0
    y_39        OBJ       79.51
    y_39        link_39     -3.0
    y_40        OBJ       1.01
    y_40        link_40     -7.0
    y_41        OBJ       186.47
    y_41        link_41     -8.0
    y_42        OBJ       115.09
    y_42        link_42     -7.0
    y_43        OBJ       2.58
    y_43        link_43     -5.0
    y_44        OBJ       1.51
    y_44        link_44     -3.0
    y_45        OBJ       4.31
    y_45        link_45     -5.0
    y_46        OBJ       53.21
    y_46        link_46     -8.0
    y_47        OBJ       70.89
    y_47        link_47     -8.0
    y_48        OBJ       125.17
    y_48        link_48     -8.0
    y_49        OBJ       69.66
    y_49        link_49     -7.0
    y_50        OBJ       3.07
    y_50        link_50     -8.0
    y_51        OBJ       1.07
    y_51        link_51     -5.0
    y_52        OBJ       1.6
    y_52        link_52     -3.0
    y_53        OBJ       3.07
    y_53        link_53     -6.0
    y_54        OBJ       87.27
    y_54        link_54     -4.0
    y_55        OBJ       54.18
    y_55        link_55     -2.0
    y_56        OBJ       3.05
    y_56        link_56     -7.0
    y_57        OBJ       3.03
    y_57        link_57     -3.0
    y_58        OBJ       2.04
    y_58        link_58     -6.0
    y_59        OBJ       116.32
    y_59        link_59     -2.0
    y_60        OBJ       95.42
    y_60        link_60     -2.0
    y_61        OBJ       2.46
    y_61        link_61     -4.0
    y_62        OBJ       109.74
    y_62        link_62     -5.0
    y_63        OBJ       2.73
    y_63        link_63     -6.0
    y_64        OBJ       63.83
    y_64        link_64     -4.0
    y_65        OBJ       1.07
    y_65        link_65     -4.0
    y_66        OBJ       66.93
    y_66        link_66     -8.0
    y_67        OBJ       185.88
    y_67        link_67     -3.0
    y_68        OBJ       186.71
    y_68        link_68     -8.0
    y_69        OBJ       135.59
    y_69        link_69     -7.0
    y_70        OBJ       77.5
    y_70        link_70     -2.0
    y_71        OBJ       1.33
    y_71        link_71     -8.0
    y_72        OBJ       51.73
    y_72        link_72     -6.0
    y_73        OBJ       3.84
    y_73        link_73     -2.0
    y_74        OBJ       96.8
    y_74        link_74     -4.0
    y_75        OBJ       150.82
    y_75        link_75     -4.0
    y_76        OBJ       1.07
    y_76        link_76     -6.0
    y_77        OBJ       2.79
    y_77        link_77     -7.0
    y_78        OBJ       4.55
    y_78        link_78     -6.0
    y_79        OBJ       79.79
    y_79        link_79     -7.0
    y_80        OBJ       197.28
    y_80        link_80     -8.0
    y_81        OBJ       88.34
    y_81        link_81     -3.0
    y_82        OBJ       3.02
    y_82        link_82     -4.0
    y_83        OBJ       1.74
    y_83        link_83     -4.0
    y_84        OBJ       195.89
    y_84        link_84     -6.0
    y_85        OBJ       82.68
    y_85        link_85     -3.0
    y_86        OBJ       125.41
    y_86        link_86     -3.0
    y_87        OBJ       4.27
    y_87        link_87     -3.0
    y_88        OBJ       95.64
    y_88        link_88     -3.0
    y_89        OBJ       1.62
    y_89        link_89     -7.0
    y_90        OBJ       2.98
    y_90        link_90     -4.0
    y_91        OBJ       4.34
    y_91        link_91     -6.0
    y_92        OBJ       1.56
    y_92        link_92     -6.0
    y_93        OBJ       1.06
    y_93        link_93     -7.0
    y_94        OBJ       1.92
    y_94        link_94     -2.0
    y_95        OBJ       2.51
    y_95        link_95     -5.0
    y_96        OBJ       3.72
    y_96        link_96     -5.0
    y_97        OBJ       189.88
    y_97        link_97     -6.0
    y_98        OBJ       2.9
    y_98        link_98     -8.0
    y_99        OBJ       84.61
    y_99        link_99     -7.0
    y_100       OBJ       4.64
    y_100       link_100    -4.0
    y_101       OBJ       1.31
    y_101       link_101    -3.0
    y_102       OBJ       3.48
    y_102       link_102    -3.0
    y_103       OBJ       150.8
    y_103       link_103    -7.0
    y_104       OBJ       92.83
    y_104       link_104    -5.0
    y_105       OBJ       79.89
    y_105       link_105    -2.0
    y_106       OBJ       125.99
    y_106       link_106    -5.0
    y_107       OBJ       81.61
    y_107       link_107    -6.0
    y_108       OBJ       2.44
    y_108       link_108    -6.0
    y_109       OBJ       104.78
    y_109       link_109    -5.0
    y_110       OBJ       123.75
    y_110       link_110    -5.0
    y_111       OBJ       2.5
    y_111       link_111    -2.0
    y_112       OBJ       109.74
    y_112       link_112    -3.0
    y_113       OBJ       2.49
    y_113       link_113    -5.0
    y_114       OBJ       163.35
    y_114       link_114    -8.0
    y_115       OBJ       92.84
    y_115       link_115    -3.0
    y_116       OBJ       165.98
    y_116       link_116    -8.0
    y_117       OBJ       4.65
    y_117       link_117    -6.0
    y_118       OBJ       3.93
    y_118       link_118    -5.0
    y_119       OBJ       122.84
    y_119       link_119    -6.0
    y_120       OBJ       94.67
    y_120       link_120    -7.0
    y_121       OBJ       95.13
    y_121       link_121    -6.0
    y_122       OBJ       61.28
    y_122       link_122    -6.0
    y_123       OBJ       199.47
    y_123       link_123    -5.0
    y_124       OBJ       1.7
    y_124       link_124    -6.0
    y_125       OBJ       135.44
    y_125       link_125    -2.0
    y_126       OBJ       81.5
    y_126       link_126    -4.0
    y_127       OBJ       195.15
    y_127       link_127    -3.0
    y_128       OBJ       4.39
    y_128       link_128    -2.0
    y_129       OBJ       114.78
    y_129       link_129    -4.0
    y_130       OBJ       184.35
    y_130       link_130    -5.0
    y_131       OBJ       189.02
    y_131       link_131    -8.0
    y_132       OBJ       1.44
    y_132       link_132    -3.0
    y_133       OBJ       4.3
    y_133       link_133    -7.0
    y_134       OBJ       4.11
    y_134       link_134    -2.0
    y_135       OBJ       3.86
    y_135       link_135    -3.0
    y_136       OBJ       4.06
    y_136       link_136    -2.0
    y_137       OBJ       2.55
    y_137       link_137    -3.0
    y_138       OBJ       119.1
    y_138       link_138    -4.0
    y_139       OBJ       87.06
    y_139       link_139    -5.0
    y_140       OBJ       124.75
    y_140       link_140    -7.0
    y_141       OBJ       113.65
    y_141       link_141    -4.0
    y_142       OBJ       113.08
    y_142       link_142    -7.0
    y_143       OBJ       176.77
    y_143       link_143    -2.0
    y_144       OBJ       4.28
    y_144       link_144    -3.0
    y_145       OBJ       66.35
    y_145       link_145    -6.0
    y_146       OBJ       112.55
    y_146       link_146    -7.0
    y_147       OBJ       81.94
    y_147       link_147    -6.0
    y_148       OBJ       109.0
    y_148       link_148    -7.0
    y_149       OBJ       74.85
    y_149       link_149    -3.0
    y_150       OBJ       1.13
    y_150       link_150    -7.0
    y_151       OBJ       2.77
    y_151       link_151    -2.0
    y_152       OBJ       193.33
    y_152       link_152    -2.0
    y_153       OBJ       173.24
    y_153       link_153    -8.0
    y_154       OBJ       105.91
    y_154       link_154    -5.0
    y_155       OBJ       54.54
    y_155       link_155    -5.0
    y_156       OBJ       1.14
    y_156       link_156    -2.0
    y_157       OBJ       140.84
    y_157       link_157    -4.0
    y_158       OBJ       2.05
    y_158       link_158    -7.0
    y_159       OBJ       3.89
    y_159       link_159    -6.0
    y_160       OBJ       121.28
    y_160       link_160    -5.0
    y_161       OBJ       4.26
    y_161       link_161    -3.0
    y_162       OBJ       95.5
    y_162       link_162    -7.0
    y_163       OBJ       3.05
    y_163       link_163    -5.0
    y_164       OBJ       55.08
    y_164       link_164    -6.0
    y_165       OBJ       65.78
    y_165       link_165    -2.0
    y_166       OBJ       124.77
    y_166       link_166    -7.0
    y_167       OBJ       143.05
    y_167       link_167    -7.0
    y_168       OBJ       4.04
    y_168       link_168    -8.0
    y_169       OBJ       89.05
    y_169       link_169    -5.0
    y_170       OBJ       2.31
    y_170       link_170    -5.0
    y_171       OBJ       4.23
    y_171       link_171    -7.0
    y_172       OBJ       172.87
    y_172       link_172    -8.0
    y_173       OBJ       67.88
    y_173       link_173    -3.0
    y_174       OBJ       126.9
    y_174       link_174    -3.0
    y_175       OBJ       191.86
    y_175       link_175    -2.0
    y_176       OBJ       1.15
    y_176       link_176    -4.0
    y_177       OBJ       139.91
    y_177       link_177    -7.0
    y_178       OBJ       2.49
    y_178       link_178    -6.0
    y_179       OBJ       132.21
    y_179       link_179    -2.0
    y_180       OBJ       1.62
    y_180       link_180    -6.0
    y_181       OBJ       111.47
    y_181       link_181    -4.0
    y_182       OBJ       161.8
    y_182       link_182    -4.0
    y_183       OBJ       1.79
    y_183       link_183    -7.0
    y_184       OBJ       1.63
    y_184       link_184    -2.0
    y_185       OBJ       4.09
    y_185       link_185    -3.0
    y_186       OBJ       4.64
    y_186       link_186    -2.0
    y_187       OBJ       1.69
    y_187       link_187    -4.0
    y_188       OBJ       1.44
    y_188       link_188    -5.0
    y_189       OBJ       56.52
    y_189       link_189    -5.0
    y_190       OBJ       1.35
    y_190       link_190    -7.0
    y_191       OBJ       4.14
    y_191       link_191    -3.0
    y_192       OBJ       2.89
    y_192       link_192    -6.0
    y_193       OBJ       107.54
    y_193       link_193    -2.0
    y_194       OBJ       1.77
    y_194       link_194    -6.0
    y_195       OBJ       67.66
    y_195       link_195    -6.0
    y_196       OBJ       3.6
    y_196       link_196    -4.0
    y_197       OBJ       117.02
    y_197       link_197    -5.0
    y_198       OBJ       119.79
    y_198       link_198    -5.0
    y_199       OBJ       1.72
    y_199       link_199    -5.0
    y_200       OBJ       104.8
    y_200       link_200    -8.0
    y_201       OBJ       3.55
    y_201       link_201    -2.0
    y_202       OBJ       1.22
    y_202       link_202    -6.0
    y_203       OBJ       4.43
    y_203       link_203    -6.0
    y_204       OBJ       93.18
    y_204       link_204    -8.0
    y_205       OBJ       1.26
    y_205       link_205    -4.0
    y_206       OBJ       185.76
    y_206       link_206    -5.0
    y_207       OBJ       1.83
    y_207       link_207    -4.0
    y_208       OBJ       79.84
    y_208       link_208    -5.0
    y_209       OBJ       4.58
    y_209       link_209    -3.0
    y_210       OBJ       4.43
    y_210       link_210    -8.0
    y_211       OBJ       4.58
    y_211       link_211    -4.0
    y_212       OBJ       2.49
    y_212       link_212    -5.0
    y_213       OBJ       62.21
    y_213       link_213    -3.0
    y_214       OBJ       4.28
    y_214       link_214    -4.0
    y_215       OBJ       4.71
    y_215       link_215    -4.0
    y_216       OBJ       2.16
    y_216       link_216    -7.0
    y_217       OBJ       1.53
    y_217       link_217    -3.0
    y_218       OBJ       95.56
    y_218       link_218    -6.0
    y_219       OBJ       138.36
    y_219       link_219    -3.0
    y_220       OBJ       86.54
    y_220       link_220    -3.0
    y_221       OBJ       149.82
    y_221       link_221    -4.0
    y_222       OBJ       4.28
    y_222       link_222    -4.0
    y_223       OBJ       3.07
    y_223       link_223    -5.0
    y_224       OBJ       3.13
    y_224       link_224    -5.0
    y_225       OBJ       65.74
    y_225       link_225    -6.0
    y_226       OBJ       1.8
    y_226       link_226    -6.0
    y_227       OBJ       3.45
    y_227       link_227    -6.0
    y_228       OBJ       1.03
    y_228       link_228    -8.0
    y_229       OBJ       3.62
    y_229       link_229    -3.0
    y_230       OBJ       4.57
    y_230       link_230    -7.0
    y_231       OBJ       151.89
    y_231       link_231    -7.0
    y_232       OBJ       184.13
    y_232       link_232    -2.0
    y_233       OBJ       176.26
    y_233       link_233    -3.0
    y_234       OBJ       2.55
    y_234       link_234    -6.0
    y_235       OBJ       3.77
    y_235       link_235    -7.0
    y_236       OBJ       50.96
    y_236       link_236    -2.0
    y_237       OBJ       168.38
    y_237       link_237    -5.0
    y_238       OBJ       71.69
    y_238       link_238    -2.0
    y_239       OBJ       4.91
    y_239       link_239    -7.0
    y_240       OBJ       3.95
    y_240       link_240    -2.0
    y_241       OBJ       172.93
    y_241       link_241    -7.0
    y_242       OBJ       1.43
    y_242       link_242    -3.0
    y_243       OBJ       186.67
    y_243       link_243    -8.0
    y_244       OBJ       2.15
    y_244       link_244    -2.0
    y_245       OBJ       2.18
    y_245       link_245    -4.0
    y_246       OBJ       92.39
    y_246       link_246    -7.0
    y_247       OBJ       3.41
    y_247       link_247    -5.0
    y_248       OBJ       1.12
    y_248       link_248    -6.0
    y_249       OBJ       130.68
    y_249       link_249    -3.0
    y_250       OBJ       2.74
    y_250       link_250    -6.0
    y_251       OBJ       1.02
    y_251       link_251    -5.0
    y_252       OBJ       4.87
    y_252       link_252    -6.0
    y_253       OBJ       92.56
    y_253       link_253    -3.0
    y_254       OBJ       145.48
    y_254       link_254    -2.0
    y_255       OBJ       2.31
    y_255       link_255    -2.0
    y_256       OBJ       89.48
    y_256       link_256    -6.0
    y_257       OBJ       85.04
    y_257       link_257    -5.0
    y_258       OBJ       3.42
    y_258       link_258    -2.0
    y_259       OBJ       176.47
    y_259       link_259    -7.0
    y_260       OBJ       153.36
    y_260       link_260    -4.0
    y_261       OBJ       182.77
    y_261       link_261    -3.0
    y_262       OBJ       173.98
    y_262       link_262    -6.0
    y_263       OBJ       98.98
    y_263       link_263    -6.0
    y_264       OBJ       4.82
    y_264       link_264    -2.0
    y_265       OBJ       169.23
    y_265       link_265    -7.0
    y_266       OBJ       186.71
    y_266       link_266    -4.0
    y_267       OBJ       178.15
    y_267       link_267    -5.0
    y_268       OBJ       88.58
    y_268       link_268    -7.0
    y_269       OBJ       2.72
    y_269       link_269    -6.0
    y_270       OBJ       3.67
    y_270       link_270    -7.0
    y_271       OBJ       3.72
    y_271       link_271    -7.0
    y_272       OBJ       155.1
    y_272       link_272    -5.0
    y_273       OBJ       118.28
    y_273       link_273    -6.0
    y_274       OBJ       1.73
    y_274       link_274    -7.0
    y_275       OBJ       186.23
    y_275       link_275    -2.0
    y_276       OBJ       4.13
    y_276       link_276    -3.0
    y_277       OBJ       131.16
    y_277       link_277    -7.0
    y_278       OBJ       105.49
    y_278       link_278    -4.0
    y_279       OBJ       3.74
    y_279       link_279    -5.0
    y_280       OBJ       3.46
    y_280       link_280    -7.0
    y_281       OBJ       154.74
    y_281       link_281    -4.0
    y_282       OBJ       110.07
    y_282       link_282    -6.0
    y_283       OBJ       189.41
    y_283       link_283    -2.0
    y_284       OBJ       83.9
    y_284       link_284    -3.0
    y_285       OBJ       4.26
    y_285       link_285    -5.0
    y_286       OBJ       4.33
    y_286       link_286    -4.0
    y_287       OBJ       4.93
    y_287       link_287    -7.0
    y_288       OBJ       92.18
    y_288       link_288    -3.0
    y_289       OBJ       143.5
    y_289       link_289    -2.0
    y_290       OBJ       107.77
    y_290       link_290    -2.0
    y_291       OBJ       4.33
    y_291       link_291    -7.0
    y_292       OBJ       1.29
    y_292       link_292    -4.0
    y_293       OBJ       85.05
    y_293       link_293    -8.0
    y_294       OBJ       2.61
    y_294       link_294    -6.0
    y_295       OBJ       4.13
    y_295       link_295    -7.0
    y_296       OBJ       3.77
    y_296       link_296    -6.0
    y_297       OBJ       1.47
    y_297       link_297    -2.0
    y_298       OBJ       123.96
    y_298       link_298    -2.0
    y_299       OBJ       1.99
    y_299       link_299    -3.0
    y_300       OBJ       4.36
    y_300       link_300    -5.0
    y_301       OBJ       119.86
    y_301       link_301    -5.0
    y_302       OBJ       145.42
    y_302       link_302    -2.0
    y_303       OBJ       199.85
    y_303       link_303    -8.0
    y_304       OBJ       71.67
    y_304       link_304    -3.0
    y_305       OBJ       4.45
    y_305       link_305    -4.0
    y_306       OBJ       4.65
    y_306       link_306    -4.0
    y_307       OBJ       174.01
    y_307       link_307    -4.0
    y_308       OBJ       90.75
    y_308       link_308    -6.0
    y_309       OBJ       2.32
    y_309       link_309    -4.0
    y_310       OBJ       63.14
    y_310       link_310    -2.0
    y_311       OBJ       3.3
    y_311       link_311    -5.0
    y_312       OBJ       188.21
    y_312       link_312    -6.0
    y_313       OBJ       131.55
    y_313       link_313    -5.0
    y_314       OBJ       3.39
    y_314       link_314    -7.0
    y_315       OBJ       143.79
    y_315       link_315    -3.0
    y_316       OBJ       166.18
    y_316       link_316    -7.0
    y_317       OBJ       2.24
    y_317       link_317    -7.0
    y_318       OBJ       53.06
    y_318       link_318    -6.0
    y_319       OBJ       3.27
    y_319       link_319    -2.0
    y_320       OBJ       4.67
    y_320       link_320    -5.0
    y_321       OBJ       4.97
    y_321       link_321    -7.0
    y_322       OBJ       1.33
    y_322       link_322    -5.0
    y_323       OBJ       1.04
    y_323       link_323    -7.0
    y_324       OBJ       120.85
    y_324       link_324    -4.0
    y_325       OBJ       78.11
    y_325       link_325    -2.0
    y_326       OBJ       1.58
    y_326       link_326    -8.0
    y_327       OBJ       2.84
    y_327       link_327    -4.0
    y_328       OBJ       182.5
    y_328       link_328    -7.0
    y_329       OBJ       140.02
    y_329       link_329    -8.0
    y_330       OBJ       136.24
    y_330       link_330    -5.0
    y_331       OBJ       67.51
    y_331       link_331    -7.0
    y_332       OBJ       191.74
    y_332       link_332    -8.0
    y_333       OBJ       143.28
    y_333       link_333    -7.0
    y_334       OBJ       196.62
    y_334       link_334    -8.0
    y_335       OBJ       4.91
    y_335       link_335    -3.0
    y_336       OBJ       4.23
    y_336       link_336    -4.0
    y_337       OBJ       73.59
    y_337       link_337    -8.0
    y_338       OBJ       183.59
    y_338       link_338    -6.0
    y_339       OBJ       3.19
    y_339       link_339    -8.0
    y_340       OBJ       2.94
    y_340       link_340    -5.0
    y_341       OBJ       2.24
    y_341       link_341    -2.0
    y_342       OBJ       88.21
    y_342       link_342    -8.0
    y_343       OBJ       170.99
    y_343       link_343    -8.0
    y_344       OBJ       88.93
    y_344       link_344    -8.0
    y_345       OBJ       78.37
    y_345       link_345    -3.0
    y_346       OBJ       3.31
    y_346       link_346    -4.0
    y_347       OBJ       1.18
    y_347       link_347    -5.0
    y_348       OBJ       62.26
    y_348       link_348    -4.0
    y_349       OBJ       53.09
    y_349       link_349    -2.0
    y_350       OBJ       89.24
    y_350       link_350    -8.0
    y_351       OBJ       138.97
    y_351       link_351    -6.0
    y_352       OBJ       4.98
    y_352       link_352    -5.0
    y_353       OBJ       180.6
    y_353       link_353    -5.0
    y_354       OBJ       4.69
    y_354       link_354    -7.0
    y_355       OBJ       63.47
    y_355       link_355    -7.0
    y_356       OBJ       105.64
    y_356       link_356    -3.0
    y_357       OBJ       191.18
    y_357       link_357    -2.0
    y_358       OBJ       4.15
    y_358       link_358    -7.0
    y_359       OBJ       163.24
    y_359       link_359    -3.0
    y_360       OBJ       163.68
    y_360       link_360    -2.0
    y_361       OBJ       106.25
    y_361       link_361    -5.0
    y_362       OBJ       2.87
    y_362       link_362    -3.0
    y_363       OBJ       4.74
    y_363       link_363    -8.0
    y_364       OBJ       64.55
    y_364       link_364    -5.0
    y_365       OBJ       98.38
    y_365       link_365    -3.0
    y_366       OBJ       1.89
    y_366       link_366    -2.0
    y_367       OBJ       115.85
    y_367       link_367    -3.0
    y_368       OBJ       90.67
    y_368       link_368    -8.0
    y_369       OBJ       1.44
    y_369       link_369    -5.0
    y_370       OBJ       150.24
    y_370       link_370    -3.0
    y_371       OBJ       4.02
    y_371       link_371    -4.0
    y_372       OBJ       58.62
    y_372       link_372    -7.0
    y_373       OBJ       4.23
    y_373       link_373    -4.0
    y_374       OBJ       186.8
    y_374       link_374    -3.0
    y_375       OBJ       1.92
    y_375       link_375    -3.0
    y_376       OBJ       141.28
    y_376       link_376    -5.0
    y_377       OBJ       150.48
    y_377       link_377    -7.0
    y_378       OBJ       153.84
    y_378       link_378    -6.0
    y_379       OBJ       2.39
    y_379       link_379    -4.0
    y_380       OBJ       164.45
    y_380       link_380    -3.0
    y_381       OBJ       197.86
    y_381       link_381    -2.0
    y_382       OBJ       50.7
    y_382       link_382    -6.0
    y_383       OBJ       86.71
    y_383       link_383    -8.0
    y_384       OBJ       2.17
    y_384       link_384    -2.0
    y_385       OBJ       170.68
    y_385       link_385    -3.0
    y_386       OBJ       1.73
    y_386       link_386    -2.0
    y_387       OBJ       1.08
    y_387       link_387    -7.0
    y_388       OBJ       145.53
    y_388       link_388    -5.0
    y_389       OBJ       4.48
    y_389       link_389    -7.0
    y_390       OBJ       137.89
    y_390       link_390    -8.0
    y_391       OBJ       70.54
    y_391       link_391    -6.0
    y_392       OBJ       1.66
    y_392       link_392    -8.0
    y_393       OBJ       128.84
    y_393       link_393    -5.0
    y_394       OBJ       175.79
    y_394       link_394    -7.0
    y_395       OBJ       4.26
    y_395       link_395    -8.0
    y_396       OBJ       103.01
    y_396       link_396    -8.0
    y_397       OBJ       3.12
    y_397       link_397    -2.0
    y_398       OBJ       83.82
    y_398       link_398    -5.0
    y_399       OBJ       195.99
    y_399       link_399    -2.0
    y_400       OBJ       3.49
    y_400       link_400    -7.0
    y_401       OBJ       3.08
    y_401       link_401    -5.0
    y_402       OBJ       147.13
    y_402       link_402    -2.0
    y_403       OBJ       189.79
    y_403       link_403    -5.0
    y_404       OBJ       110.98
    y_404       link_404    -4.0
    y_405       OBJ       154.23
    y_405       link_405    -3.0
    y_406       OBJ       119.13
    y_406       link_406    -6.0
    y_407       OBJ       54.64
    y_407       link_407    -4.0
    y_408       OBJ       3.34
    y_408       link_408    -2.0
    y_409       OBJ       198.13
    y_409       link_409    -4.0
    y_410       OBJ       2.39
    y_410       link_410    -7.0
    y_411       OBJ       160.31
    y_411       link_411    -2.0
    y_412       OBJ       4.74
    y_412       link_412    -5.0
    y_413       OBJ       142.44
    y_413       link_413    -8.0
    y_414       OBJ       188.31
    y_414       link_414    -5.0
    y_415       OBJ       1.51
    y_415       link_415    -8.0
    y_416       OBJ       67.62
    y_416       link_416    -5.0
    y_417       OBJ       180.91
    y_417       link_417    -6.0
    y_418       OBJ       2.15
    y_418       link_418    -4.0
    y_419       OBJ       107.68
    y_419       link_419    -4.0
    y_420       OBJ       2.78
    y_420       link_420    -3.0
    y_421       OBJ       2.51
    y_421       link_421    -3.0
    y_422       OBJ       175.72
    y_422       link_422    -4.0
    y_423       OBJ       1.1
    y_423       link_423    -4.0
    y_424       OBJ       96.86
    y_424       link_424    -6.0
    y_425       OBJ       2.72
    y_425       link_425    -5.0
    y_426       OBJ       4.79
    y_426       link_426    -7.0
    y_427       OBJ       125.14
    y_427       link_427    -7.0
    y_428       OBJ       113.18
    y_428       link_428    -5.0
    y_429       OBJ       2.37
    y_429       link_429    -6.0
    y_430       OBJ       173.9
    y_430       link_430    -6.0
    y_431       OBJ       2.37
    y_431       link_431    -6.0
    y_432       OBJ       126.74
    y_432       link_432    -6.0
    y_433       OBJ       140.47
    y_433       link_433    -4.0
    y_434       OBJ       2.65
    y_434       link_434    -8.0
    y_435       OBJ       4.67
    y_435       link_435    -5.0
    y_436       OBJ       76.28
    y_436       link_436    -8.0
    y_437       OBJ       1.57
    y_437       link_437    -3.0
    y_438       OBJ       163.92
    y_438       link_438    -2.0
    y_439       OBJ       123.56
    y_439       link_439    -5.0
    y_440       OBJ       1.05
    y_440       link_440    -8.0
    y_441       OBJ       54.93
    y_441       link_441    -7.0
    y_442       OBJ       52.93
    y_442       link_442    -3.0
    y_443       OBJ       1.18
    y_443       link_443    -6.0
    y_444       OBJ       118.32
    y_444       link_444    -5.0
    y_445       OBJ       4.8
    y_445       link_445    -3.0
    y_446       OBJ       2.59
    y_446       link_446    -7.0
    y_447       OBJ       1.69
    y_447       link_447    -4.0
    y_448       OBJ       109.4
    y_448       link_448    -4.0
    y_449       OBJ       2.61
    y_449       link_449    -2.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      12
    RHS       flow_13     10
    RHS       flow_19     9
    RHS       flow_23     -8
    RHS       flow_28     -8
    RHS       flow_30     9
    RHS       flow_32     -8
    RHS       flow_34     -8
    RHS       flow_46     -8
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
 BV BOUND     y_84
 BV BOUND     y_85
 BV BOUND     y_86
 BV BOUND     y_87
 BV BOUND     y_88
 BV BOUND     y_89
 BV BOUND     y_90
 BV BOUND     y_91
 BV BOUND     y_92
 BV BOUND     y_93
 BV BOUND     y_94
 BV BOUND     y_95
 BV BOUND     y_96
 BV BOUND     y_97
 BV BOUND     y_98
 BV BOUND     y_99
 BV BOUND     y_100
 BV BOUND     y_101
 BV BOUND     y_102
 BV BOUND     y_103
 BV BOUND     y_104
 BV BOUND     y_105
 BV BOUND     y_106
 BV BOUND     y_107
 BV BOUND     y_108
 BV BOUND     y_109
 BV BOUND     y_110
 BV BOUND     y_111
 BV BOUND     y_112
 BV BOUND     y_113
 BV BOUND     y_114
 BV BOUND     y_115
 BV BOUND     y_116
 BV BOUND     y_117
 BV BOUND     y_118
 BV BOUND     y_119
 BV BOUND     y_120
 BV BOUND     y_121
 BV BOUND     y_122
 BV BOUND     y_123
 BV BOUND     y_124
 BV BOUND     y_125
 BV BOUND     y_126
 BV BOUND     y_127
 BV BOUND     y_128
 BV BOUND     y_129
 BV BOUND     y_130
 BV BOUND     y_131
 BV BOUND     y_132
 BV BOUND     y_133
 BV BOUND     y_134
 BV BOUND     y_135
 BV BOUND     y_136
 BV BOUND     y_137
 BV BOUND     y_138
 BV BOUND     y_139
 BV BOUND     y_140
 BV BOUND     y_141
 BV BOUND     y_142
 BV BOUND     y_143
 BV BOUND     y_144
 BV BOUND     y_145
 BV BOUND     y_146
 BV BOUND     y_147
 BV BOUND     y_148
 BV BOUND     y_149
 BV BOUND     y_150
 BV BOUND     y_151
 BV BOUND     y_152
 BV BOUND     y_153
 BV BOUND     y_154
 BV BOUND     y_155
 BV BOUND     y_156
 BV BOUND     y_157
 BV BOUND     y_158
 BV BOUND     y_159
 BV BOUND     y_160
 BV BOUND     y_161
 BV BOUND     y_162
 BV BOUND     y_163
 BV BOUND     y_164
 BV BOUND     y_165
 BV BOUND     y_166
 BV BOUND     y_167
 BV BOUND     y_168
 BV BOUND     y_169
 BV BOUND     y_170
 BV BOUND     y_171
 BV BOUND     y_172
 BV BOUND     y_173
 BV BOUND     y_174
 BV BOUND     y_175
 BV BOUND     y_176
 BV BOUND     y_177
 BV BOUND     y_178
 BV BOUND     y_179
 BV BOUND     y_180
 BV BOUND     y_181
 BV BOUND     y_182
 BV BOUND     y_183
 BV BOUND     y_184
 BV BOUND     y_185
 BV BOUND     y_186
 BV BOUND     y_187
 BV BOUND     y_188
 BV BOUND     y_189
 BV BOUND     y_190
 BV BOUND     y_191
 BV BOUND     y_192
 BV BOUND     y_193
 BV BOUND     y_194
 BV BOUND     y_195
 BV BOUND     y_196
 BV BOUND     y_197
 BV BOUND     y_198
 BV BOUND     y_199
 BV BOUND     y_200
 BV BOUND     y_201
 BV BOUND     y_202
 BV BOUND     y_203
 BV BOUND     y_204
 BV BOUND     y_205
 BV BOUND     y_206
 BV BOUND     y_207
 BV BOUND     y_208
 BV BOUND     y_209
 BV BOUND     y_210
 BV BOUND     y_211
 BV BOUND     y_212
 BV BOUND     y_213
 BV BOUND     y_214
 BV BOUND     y_215
 BV BOUND     y_216
 BV BOUND     y_217
 BV BOUND     y_218
 BV BOUND     y_219
 BV BOUND     y_220
 BV BOUND     y_221
 BV BOUND     y_222
 BV BOUND     y_223
 BV BOUND     y_224
 BV BOUND     y_225
 BV BOUND     y_226
 BV BOUND     y_227
 BV BOUND     y_228
 BV BOUND     y_229
 BV BOUND     y_230
 BV BOUND     y_231
 BV BOUND     y_232
 BV BOUND     y_233
 BV BOUND     y_234
 BV BOUND     y_235
 BV BOUND     y_236
 BV BOUND     y_237
 BV BOUND     y_238
 BV BOUND     y_239
 BV BOUND     y_240
 BV BOUND     y_241
 BV BOUND     y_242
 BV BOUND     y_243
 BV BOUND     y_244
 BV BOUND     y_245
 BV BOUND     y_246
 BV BOUND     y_247
 BV BOUND     y_248
 BV BOUND     y_249
 BV BOUND     y_250
 BV BOUND     y_251
 BV BOUND     y_252
 BV BOUND     y_253
 BV BOUND     y_254
 BV BOUND     y_255
 BV BOUND     y_256
 BV BOUND     y_257
 BV BOUND     y_258
 BV BOUND     y_259
 BV BOUND     y_260
 BV BOUND     y_261
 BV BOUND     y_262
 BV BOUND     y_263
 BV BOUND     y_264
 BV BOUND     y_265
 BV BOUND     y_266
 BV BOUND     y_267
 BV BOUND     y_268
 BV BOUND     y_269
 BV BOUND     y_270
 BV BOUND     y_271
 BV BOUND     y_272
 BV BOUND     y_273
 BV BOUND     y_274
 BV BOUND     y_275
 BV BOUND     y_276
 BV BOUND     y_277
 BV BOUND     y_278
 BV BOUND     y_279
 BV BOUND     y_280
 BV BOUND     y_281
 BV BOUND     y_282
 BV BOUND     y_283
 BV BOUND     y_284
 BV BOUND     y_285
 BV BOUND     y_286
 BV BOUND     y_287
 BV BOUND     y_288
 BV BOUND     y_289
 BV BOUND     y_290
 BV BOUND     y_291
 BV BOUND     y_292
 BV BOUND     y_293
 BV BOUND     y_294
 BV BOUND     y_295
 BV BOUND     y_296
 BV BOUND     y_297
 BV BOUND     y_298
 BV BOUND     y_299
 BV BOUND     y_300
 BV BOUND     y_301
 BV BOUND     y_302
 BV BOUND     y_303
 BV BOUND     y_304
 BV BOUND     y_305
 BV BOUND     y_306
 BV BOUND     y_307
 BV BOUND     y_308
 BV BOUND     y_309
 BV BOUND     y_310
 BV BOUND     y_311
 BV BOUND     y_312
 BV BOUND     y_313
 BV BOUND     y_314
 BV BOUND     y_315
 BV BOUND     y_316
 BV BOUND     y_317
 BV BOUND     y_318
 BV BOUND     y_319
 BV BOUND     y_320
 BV BOUND     y_321
 BV BOUND     y_322
 BV BOUND     y_323
 BV BOUND     y_324
 BV BOUND     y_325
 BV BOUND     y_326
 BV BOUND     y_327
 BV BOUND     y_328
 BV BOUND     y_329
 BV BOUND     y_330
 BV BOUND     y_331
 BV BOUND     y_332
 BV BOUND     y_333
 BV BOUND     y_334
 BV BOUND     y_335
 BV BOUND     y_336
 BV BOUND     y_337
 BV BOUND     y_338
 BV BOUND     y_339
 BV BOUND     y_340
 BV BOUND     y_341
 BV BOUND     y_342
 BV BOUND     y_343
 BV BOUND     y_344
 BV BOUND     y_345
 BV BOUND     y_346
 BV BOUND     y_347
 BV BOUND     y_348
 BV BOUND     y_349
 BV BOUND     y_350
 BV BOUND     y_351
 BV BOUND     y_352
 BV BOUND     y_353
 BV BOUND     y_354
 BV BOUND     y_355
 BV BOUND     y_356
 BV BOUND     y_357
 BV BOUND     y_358
 BV BOUND     y_359
 BV BOUND     y_360
 BV BOUND     y_361
 BV BOUND     y_362
 BV BOUND     y_363
 BV BOUND     y_364
 BV BOUND     y_365
 BV BOUND     y_366
 BV BOUND     y_367
 BV BOUND     y_368
 BV BOUND     y_369
 BV BOUND     y_370
 BV BOUND     y_371
 BV BOUND     y_372
 BV BOUND     y_373
 BV BOUND     y_374
 BV BOUND     y_375
 BV BOUND     y_376
 BV BOUND     y_377
 BV BOUND     y_378
 BV BOUND     y_379
 BV BOUND     y_380
 BV BOUND     y_381
 BV BOUND     y_382
 BV BOUND     y_383
 BV BOUND     y_384
 BV BOUND     y_385
 BV BOUND     y_386
 BV BOUND     y_387
 BV BOUND     y_388
 BV BOUND     y_389
 BV BOUND     y_390
 BV BOUND     y_391
 BV BOUND     y_392
 BV BOUND     y_393
 BV BOUND     y_394
 BV BOUND     y_395
 BV BOUND     y_396
 BV BOUND     y_397
 BV BOUND     y_398
 BV BOUND     y_399
 BV BOUND     y_400
 BV BOUND     y_401
 BV BOUND     y_402
 BV BOUND     y_403
 BV BOUND     y_404
 BV BOUND     y_405
 BV BOUND     y_406
 BV BOUND     y_407
 BV BOUND     y_408
 BV BOUND     y_409
 BV BOUND     y_410
 BV BOUND     y_411
 BV BOUND     y_412
 BV BOUND     y_413
 BV BOUND     y_414
 BV BOUND     y_415
 BV BOUND     y_416
 BV BOUND     y_417
 BV BOUND     y_418
 BV BOUND     y_419
 BV BOUND     y_420
 BV BOUND     y_421
 BV BOUND     y_422
 BV BOUND     y_423
 BV BOUND     y_424
 BV BOUND     y_425
 BV BOUND     y_426
 BV BOUND     y_427
 BV BOUND     y_428
 BV BOUND     y_429
 BV BOUND     y_430
 BV BOUND     y_431
 BV BOUND     y_432
 BV BOUND     y_433
 BV BOUND     y_434
 BV BOUND     y_435
 BV BOUND     y_436
 BV BOUND     y_437
 BV BOUND     y_438
 BV BOUND     y_439
 BV BOUND     y_440
 BV BOUND     y_441
 BV BOUND     y_442
 BV BOUND     y_443
 BV BOUND     y_444
 BV BOUND     y_445
 BV BOUND     y_446
 BV BOUND     y_447
 BV BOUND     y_448
 BV BOUND     y_449
ENDATA
