NAME          fcnf_layered_3stage
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
COLUMNS
    x_0         OBJ       2.09
    x_0         flow_0      1.0
    x_0         flow_4      -1.0
    x_0         link_0      1.0
    x_1         OBJ       2.35
    x_1         flow_0      1.0
    x_1         flow_5      -1.0
    x_1         link_1      1.0
    x_2         OBJ       2.14
    x_2         flow_0      1.0
    x_2         flow_6      -1.0
    x_2         link_2      1.0
    x_3         OBJ       3.97
    x_3         flow_0      1.0
    x_3         flow_7      -1.0
    x_3         link_3      1.0
    x_4         OBJ       1.54
    x_4         flow_0      1.0
    x_4         flow_8      -1.0
    x_4         link_4      1.0
    x_5         OBJ       1.84
    x_5         flow_0      1.0
    x_5         flow_9      -1.0
    x_5         link_5      1.0
    x_6         OBJ       1.3
    x_6         flow_1      1.0
    x_6         flow_4      -1.0
    x_6         link_6      1.0
    x_7         OBJ       4.69
    x_7         flow_1      1.0
    x_7         flow_5      -1.0
    x_7         link_7      1.0
    x_8         OBJ       4.1
    x_8         flow_1      1.0
    x_8         flow_6      -1.0
    x_8         link_8      1.0
    x_9         OBJ       1.36
    x_9         flow_1      1.0
    x_9         flow_7      -1.0
    x_9         link_9      1.0
    x_10        OBJ       2.55
    x_10        flow_1      1.0
    x_10        flow_8      -1.0
    x_10        link_10     1.0
    x_11        OBJ       3.64
    x_11        flow_1      1.0
    x_11        flow_9      -1.0
    x_11        link_11     1.0
    x_12        OBJ       4.24
    x_12        flow_2      1.0
    x_12        flow_4      -1.0
    x_12        link_12     1.0
    x_13        OBJ       1.24
    x_13        flow_2      1.0
    x_13        flow_5      -1.0
    x_13        link_13     1.0
    x_14        OBJ       2.41
    x_14        flow_2      1.0
    x_14        flow_6      -1.0
    x_14        link_14     1.0
    x_15        OBJ       3.0
    x_15        flow_2      1.0
    x_15        flow_7      -1.0
    x_15        link_15     1.0
    x_16        OBJ       2.66
    x_16        flow_2      1.0
    x_16        flow_8      -1.0
    x_16        link_16     1.0
    x_17        OBJ       2.82
    x_17        flow_2      1.0
    x_17        flow_9      -1.0
    x_17        link_17     1.0
    x_18        OBJ       4.53
    x_18        flow_3      1.0
    x_18        flow_4      -1.0
    x_18        link_18     1.0
    x_19        OBJ       4.43
    x_19        flow_3      1.0
    x_19        flow_5      -1.0
    x_19        link_19     1.0
    x_20        OBJ       2.15
    x_20        flow_3      1.0
    x_20        flow_6      -1.0
    x_20        link_20     1.0
    x_21        OBJ       3.49
    x_21        flow_3      1.0
    x_21        flow_7      -1.0
    x_21        link_21     1.0
    x_22        OBJ       1.41
    x_22        flow_3      1.0
    x_22        flow_8      -1.0
    x_22        link_22     1.0
    x_23        OBJ       2.45
    x_23        flow_3      1.0
    x_23        flow_9      -1.0
    x_23        link_23     1.0
    x_24        OBJ       2.32
    x_24        flow_4      1.0
    x_24        flow_10     -1.0
    x_24        link_24     1.0
    x_25        OBJ       3.07
    x_25        flow_4      1.0
    x_25        flow_11     -1.0
    x_25        link_25     1.0
    x_26        OBJ       1.59
    x_26        flow_4      1.0
    x_26        flow_12     -1.0
    x_26        link_26     1.0
    x_27        OBJ       4.38
    x_27        flow_4      1.0
    x_27        flow_13     -1.0
    x_27        link_27     1.0
    x_28        OBJ       4.14
    x_28        flow_4      1.0
    x_28        flow_14     -1.0
    x_28        link_28     1.0
    x_29        OBJ       1.53
    x_29        flow_4      1.0
    x_29        flow_15     -1.0
    x_29        link_29     1.0
    x_30        OBJ       1.33
    x_30        flow_5      1.0
    x_30        flow_10     -1.0
    x_30        link_30     1.0
    x_31        OBJ       2.79
    x_31        flow_5      1.0
    x_31        flow_11     -1.0
    x_31        link_31     1.0
    x_32        OBJ       4.33
    x_32        flow_5      1.0
    x_32        flow_12     -1.0
    x_32        link_32     1.0
    x_33        OBJ       2.51
    x_33        flow_5      1.0
    x_33        flow_13     -1.0
    x_33        link_33     1.0
    x_34        OBJ       1.29
    x_34        flow_5      1.0
    x_34        flow_14     -1.0
    x_34        link_34     1.0
    x_35        OBJ       3.77
    x_35        flow_5      1.0
    x_35        flow_15     -1.0
    x_35        link_35     1.0
    x_36        OBJ       4.54
    x_36        flow_6      1.0
    x_36        flow_10     -1.0
    x_36        link_36     1.0
    x_37        OBJ       2.57
    x_37        flow_6      1.0
    x_37        flow_11     -1.0
    x_37        link_37     1.0
    x_38        OBJ       3.72
    x_38        flow_6      1.0
    x_38        flow_12     -1.0
    x_38        link_38     1.0
    x_39        OBJ       3.56
    x_39        flow_6      1.0
    x_39        flow_13     -1.0
    x_39        link_39     1.0
    x_40        OBJ       3.35
    x_40        flow_6      1.0
    x_40        flow_14     -1.0
    x_40        link_40     1.0
    x_41        OBJ       1.92
    x_41        flow_6      1.0
    x_41        flow_15     -1.0
    x_41        link_41     1.0
    x_42        OBJ       3.49
    x_42        flow_7      1.0
    x_42        flow_10     -1.0
    x_42        link_42     1.0
    x_43        OBJ       4.25
    x_43        flow_7      1.0
    x_43        flow_11     -1.0
    x_43        link_43     1.0
    x_44        OBJ       4.35
    x_44        flow_7      1.0
    x_44        flow_12     -1.0
    x_44        link_44     1.0
    x_45        OBJ       4.08
    x_45        flow_7      1.0
    x_45        flow_13     -1.0
    x_45        link_45     1.0
    x_46        OBJ       4.6
    x_46        flow_7      1.0
    x_46        flow_14     -1.0
    x_46        link_46     1.0
    x_47        OBJ       4.33
    x_47        flow_7      1.0
    x_47        flow_15     -1.0
    x_47        link_47     1.0
    x_48        OBJ       3.78
    x_48        flow_8      1.0
    x_48        flow_10     -1.0
    x_48        link_48     1.0
    x_49        OBJ       2.55
    x_49        flow_8      1.0
    x_49        flow_11     -1.0
    x_49        link_49     1.0
    x_50        OBJ       3.97
    x_50        flow_8      1.0
    x_50        flow_12     -1.0
    x_50        link_50     1.0
    x_51        OBJ       4.1
    x_51        flow_8      1.0
    x_51        flow_13     -1.0
    x_51        link_51     1.0
    x_52        OBJ       1.4
    x_52        flow_8      1.0
    x_52        flow_14     -1.0
    x_52        link_52     1.0
    x_53        OBJ       3.51
    x_53        flow_8      1.0
    x_53        flow_15     -1.0
    x_53        link_53     1.0
    x_54        OBJ       3.89
    x_54        flow_9      1.0
    x_54        flow_10     -1.0
    x_54        link_54     1.0
    x_55        OBJ       2.11
    x_55        flow_9      1.0
    x_55        flow_11     -1.0
    x_55        link_55     1.0
    x_56        OBJ       3.51
    x_56        flow_9      1.0
    x_56        flow_12     -1.0
    x_56        link_56     1.0
    x_57        OBJ       2.36
    x_57        flow_9      1.0
    x_57        flow_13     -1.0
    x_57        link_57     1.0
    x_58        OBJ       2.53
    x_58        flow_9      1.0
    x_58        flow_14     -1.0
    x_58        link_58     1.0
    x_59        OBJ       3.15
    x_59        flow_9      1.0
    x_59        flow_15     -1.0
    x_59        link_59     1.0
    x_60        OBJ       2.65
    x_60        flow_10     1.0
    x_60        flow_16     -1.0
    x_60        link_60     1.0
    x_61        OBJ       3.51
    x_61        flow_10     1.0
    x_61        flow_17     -1.0
    x_61        link_61     1.0
    x_62        OBJ       4.48
    x_62        flow_10     1.0
    x_62        flow_18     -1.0
    x_62        link_62     1.0
    x_63        OBJ       1.5
    x_63        flow_10     1.0
    x_63        flow_19     -1.0
    x_63        link_63     1.0
    x_64        OBJ       1.39
    x_64        flow_11     1.0
    x_64        flow_16     -1.0
    x_64        link_64     1.0
    x_65        OBJ       2.83
    x_65        flow_11     1.0
    x_65        flow_17     -1.0
    x_65        link_65     1.0
    x_66        OBJ       2.86
    x_66        flow_11     1.0
    x_66        flow_18     -1.0
    x_66        link_66     1.0
    x_67        OBJ       3.03
    x_67        flow_11     1.0
    x_67        flow_19     -1.0
    x_67        link_67     1.0
    x_68        OBJ       3.08
    x_68        flow_12     1.0
    x_68        flow_16     -1.0
    x_68        link_68     1.0
    x_69        OBJ       1.56
    x_69        flow_12     1.0
    x_69        flow_17     -1.0
    x_69        link_69     1.0
    x_70        OBJ       3.09
    x_70        flow_12     1.0
    x_70        flow_18     -1.0
    x_70        link_70     1.0
    x_71        OBJ       2.65
    x_71        flow_12     1.0
    x_71        flow_19     -1.0
    x_71        link_71     1.0
    x_72        OBJ       3.49
    x_72        flow_13     1.0
    x_72        flow_16     -1.0
    x_72        link_72     1.0
    x_73        OBJ       4.35
    x_73        flow_13     1.0
    x_73        flow_17     -1.0
    x_73        link_73     1.0
    x_74        OBJ       3.0
    x_74        flow_13     1.0
    x_74        flow_18     -1.0
    x_74        link_74     1.0
    x_75        OBJ       2.46
    x_75        flow_13     1.0
    x_75        flow_19     -1.0
    x_75        link_75     1.0
    x_76        OBJ       4.79
    x_76        flow_14     1.0
    x_76        flow_16     -1.0
    x_76        link_76     1.0
    x_77        OBJ       1.17
    x_77        flow_14     1.0
    x_77        flow_17     -1.0
    x_77        link_77     1.0
    x_78        OBJ       3.55
    x_78        flow_14     1.0
    x_78        flow_18     -1.0
    x_78        link_78     1.0
    x_79        OBJ       3.43
    x_79        flow_14     1.0
    x_79        flow_19     -1.0
    x_79        link_79     1.0
    x_80        OBJ       2.69
    x_80        flow_15     1.0
    x_80        flow_16     -1.0
    x_80        link_80     1.0
    x_81        OBJ       1.43
    x_81        flow_15     1.0
    x_81        flow_17     -1.0
    x_81        link_81     1.0
    x_82        OBJ       4.95
    x_82        flow_15     1.0
    x_82        flow_18     -1.0
    x_82        link_82     1.0
    x_83        OBJ       1.41
    x_83        flow_15     1.0
    x_83        flow_19     -1.0
    x_83        link_83     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       5.44
    y_0         link_0      -2.82
    y_1         OBJ       3.36
    y_1         link_1      -2.11
    y_2         OBJ       3.59
    y_2         link_2      -5.11
    y_3         OBJ       3.18
    y_3         link_3      -8.25
    y_4         OBJ       6.98
    y_4         link_4      -9.37
    y_5         OBJ       7.24
    y_5         link_5      -9.17
    y_6         OBJ       5.04
    y_6         link_6      -9.0
    y_7         OBJ       3.86
    y_7         link_7      -4.52
    y_8         OBJ       7.81
    y_8         link_8      -2.94
    y_9         OBJ       6.76
    y_9         link_9      -5.17
    y_10        OBJ       7.38
    y_10        link_10     -9.46
    y_11        OBJ       7.34
    y_11        link_11     -9.32
    y_12        OBJ       6.22
    y_12        link_12     -7.93
    y_13        OBJ       7.55
    y_13        link_13     -11.12
    y_14        OBJ       6.13
    y_14        link_14     -2.17
    y_15        OBJ       6.12
    y_15        link_15     -4.94
    y_16        OBJ       7.18
    y_16        link_16     -3.43
    y_17        OBJ       3.43
    y_17        link_17     -5.84
    y_18        OBJ       6.06
    y_18        link_18     -2.29
    y_19        OBJ       6.29
    y_19        link_19     -7.21
    y_20        OBJ       4.5
    y_20        link_20     -3.83
    y_21        OBJ       3.25
    y_21        link_21     -11.45
    y_22        OBJ       6.12
    y_22        link_22     -7.76
    y_23        OBJ       4.39
    y_23        link_23     -6.39
    y_24        OBJ       7.86
    y_24        link_24     -8.45
    y_25        OBJ       6.32
    y_25        link_25     -6.94
    y_26        OBJ       3.11
    y_26        link_26     -11.7
    y_27        OBJ       3.48
    y_27        link_27     -8.11
    y_28        OBJ       7.47
    y_28        link_28     -2.65
    y_29        OBJ       4.96
    y_29        link_29     -8.03
    y_30        OBJ       6.48
    y_30        link_30     -9.55
    y_31        OBJ       7.25
    y_31        link_31     -5.89
    y_32        OBJ       4.91
    y_32        link_32     -6.02
    y_33        OBJ       6.55
    y_33        link_33     -10.83
    y_34        OBJ       5.95
    y_34        link_34     -10.36
    y_35        OBJ       4.17
    y_35        link_35     -5.64
    y_36        OBJ       4.08
    y_36        link_36     -11.54
    y_37        OBJ       5.6
    y_37        link_37     -9.08
    y_38        OBJ       5.95
    y_38        link_38     -10.68
    y_39        OBJ       7.58
    y_39        link_39     -8.52
    y_40        OBJ       3.28
    y_40        link_40     -11.09
    y_41        OBJ       4.13
    y_41        link_41     -2.49
    y_42        OBJ       4.85
    y_42        link_42     -8.53
    y_43        OBJ       7.71
    y_43        link_43     -10.03
    y_44        OBJ       4.91
    y_44        link_44     -2.53
    y_45        OBJ       7.98
    y_45        link_45     -6.63
    y_46        OBJ       5.83
    y_46        link_46     -5.85
    y_47        OBJ       3.31
    y_47        link_47     -5.63
    y_48        OBJ       3.41
    y_48        link_48     -7.54
    y_49        OBJ       4.1
    y_49        link_49     -6.06
    y_50        OBJ       6.35
    y_50        link_50     -7.91
    y_51        OBJ       5.05
    y_51        link_51     -7.8
    y_52        OBJ       6.3
    y_52        link_52     -8.67
    y_53        OBJ       6.99
    y_53        link_53     -11.85
    y_54        OBJ       7.87
    y_54        link_54     -8.54
    y_55        OBJ       7.33
    y_55        link_55     -8.69
    y_56        OBJ       3.73
    y_56        link_56     -7.65
    y_57        OBJ       5.88
    y_57        link_57     -11.24
    y_58        OBJ       3.1
    y_58        link_58     -3.22
    y_59        OBJ       7.22
    y_59        link_59     -2.49
    y_60        OBJ       4.69
    y_60        link_60     -6.41
    y_61        OBJ       5.51
    y_61        link_61     -4.72
    y_62        OBJ       7.05
    y_62        link_62     -10.97
    y_63        OBJ       5.68
    y_63        link_63     -4.36
    y_64        OBJ       7.64
    y_64        link_64     -8.6
    y_65        OBJ       6.83
    y_65        link_65     -10.49
    y_66        OBJ       3.54
    y_66        link_66     -11.01
    y_67        OBJ       5.09
    y_67        link_67     -3.94
    y_68        OBJ       7.34
    y_68        link_68     -11.32
    y_69        OBJ       3.6
    y_69        link_69     -11.92
    y_70        OBJ       6.17
    y_70        link_70     -8.95
    y_71        OBJ       4.97
    y_71        link_71     -10.71
    y_72        OBJ       3.11
    y_72        link_72     -2.38
    y_73        OBJ       5.97
    y_73        link_73     -9.46
    y_74        OBJ       6.55
    y_74        link_74     -5.47
    y_75        OBJ       4.71
    y_75        link_75     -4.94
    y_76        OBJ       7.38
    y_76        link_76     -7.45
    y_77        OBJ       7.63
    y_77        link_77     -10.09
    y_78        OBJ       7.82
    y_78        link_78     -9.55
    y_79        OBJ       4.69
    y_79        link_79     -8.23
    y_80        OBJ       3.87
    y_80        link_80     -3.62
    y_81        OBJ       6.42
    y_81        link_81     -5.75
    y_82        OBJ       7.58
    y_82        link_82     -4.85
    y_83        OBJ       7.16
    y_83        link_83     -10.49
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_1      10
    RHS       flow_3      10
    RHS       flow_16     -10
    RHS       flow_18     -10
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
ENDATA
