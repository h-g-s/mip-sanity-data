NAME          MIS
ROWS
 N  OBJ
 L  EDGE_16_93
 L  EDGE_29_32
 L  EDGE_47_80
 L  EDGE_40_41
 L  EDGE_29_68
 L  EDGE_21_64
 L  EDGE_27_107
 L  EDGE_73_74
 L  EDGE_25_34
 L  EDGE_3_15
 L  EDGE_20_104
 L  EDGE_106_107
 L  EDGE_16_70
 L  EDGE_36_48
 L  EDGE_55_61
 L  EDGE_16_106
 L  EDGE_17_71
 L  EDGE_57_107
 L  EDGE_9_67
 L  EDGE_69_81
 L  EDGE_48_58
 L  EDGE_21_41
 L  EDGE_40_54
 L  EDGE_42_100
 L  EDGE_81_91
 L  EDGE_54_74
 L  EDGE_73_87
 L  EDGE_39_94
 L  EDGE_12_77
 L  EDGE_87_107
 L  EDGE_32_91
 L  EDGE_16_83
 L  EDGE_36_61
 L  EDGE_76_97
 L  EDGE_5_73
 L  EDGE_58_85
 L  EDGE_69_94
 L  EDGE_30_102
 L  EDGE_3_5
 L  EDGE_54_87
 L  EDGE_12_90
 L  EDGE_31_103
 L  EDGE_32_68
 L  EDGE_23_99
 L  EDGE_43_77
 L  EDGE_46_88
 L  EDGE_65_101
 L  EDGE_61_67
 L  EDGE_7_96
 L  EDGE_6_51
 L  EDGE_50_94
 L  EDGE_10_21
 L  EDGE_91_95
 L  EDGE_42_90
 L  EDGE_61_103
 L  EDGE_8_97
 L  EDGE_94_100
 L  EDGE_73_77
 L  EDGE_60_107
 L  EDGE_11_102
 L  EDGE_13_32
 L  EDGE_31_80
 L  EDGE_4_63
 L  EDGE_32_45
 L  EDGE_84_92
 L  EDGE_87_97
 L  EDGE_65_78
 L  EDGE_57_74
 L  EDGE_9_34
 L  EDGE_28_47
 L  EDGE_68_83
 L  EDGE_88_98
 L  EDGE_5_63
 L  EDGE_38_97
 L  EDGE_39_61
 L  EDGE_31_57
 L  EDGE_12_80
 L  EDGE_13_45
 L  EDGE_53_81
 L  EDGE_72_94
 L  EDGE_23_89
 L  EDGE_64_90
 L  EDGE_84_105
 L  EDGE_56_86
 L  EDGE_35_63
 L  EDGE_22_93
 L  EDGE_5_40
 L  EDGE_65_91
 L  EDGE_49_83
 L  EDGE_31_34
 L  EDGE_10_11
 L  EDGE_2_7
 L  EDGE_19_96
 L  EDGE_11_92
 L  EDGE_31_70
 L  EDGE_32_35
 L  EDGE_23_66
 L  EDGE_24_31
 L  EDGE_1_47
 L  EDGE_45_90
 L  EDGE_65_68
 L  EDGE_76_77
 L  EDGE_14_102
 L  EDGE_6_18
 L  EDGE_50_61
 L  EDGE_90_97
 L  EDGE_82_93
 L  EDGE_15_103
 L  EDGE_61_70
 L  EDGE_19_73
 L  EDGE_31_47
 L  EDGE_1_24
 L  EDGE_13_35
 L  EDGE_25_89
 L  EDGE_64_80
 L  EDGE_56_76
 L  EDGE_26_53
 L  EDGE_5_30
 L  EDGE_49_73
 L  EDGE_26_89
 L  EDGE_19_50
 L  EDGE_82_106
 L  EDGE_21_96
 L  EDGE_0_73
 L  EDGE_33_70
 L  EDGE_52_83
 L  EDGE_16_17
 L  EDGE_1_37
 L  EDGE_33_106
 L  EDGE_25_102
 L  EDGE_53_84
 L  EDGE_22_96
 L  EDGE_26_66
 L  EDGE_67_104
 L  EDGE_59_100
 L  EDGE_70_109
 L  EDGE_63_70
 L  EDGE_48_90
 L  EDGE_40_86
 L  EDGE_20_28
 L  EDGE_60_64
 L  EDGE_6_93
 L  EDGE_39_41
 L  EDGE_52_60
 L  EDGE_31_37
 L  EDGE_23_33
 L  EDGE_104_107
 L  EDGE_83_84
 L  EDGE_75_80
 L  EDGE_33_83
 L  EDGE_52_96
 L  EDGE_25_79
 L  EDGE_64_70
 L  EDGE_16_30
 L  EDGE_3_60
 L  EDGE_26_43
 L  EDGE_86_94
 L  EDGE_38_54
 L  EDGE_89_99
 L  EDGE_7_66
 L  EDGE_8_31
 L  EDGE_0_27
 L  EDGE_18_75
 L  EDGE_11_36
 L  EDGE_63_83
 L  EDGE_82_96
 L  EDGE_29_90
 L  EDGE_21_86
 L  EDGE_40_99
 L  EDGE_41_64
 L  EDGE_60_77
 L  EDGE_14_46
 L  EDGE_34_61
 L  EDGE_15_47
 L  EDGE_55_83
 L  EDGE_47_79
 L  EDGE_18_52
 L  EDGE_70_99
 L  EDGE_17_93
 L  EDGE_36_106
 L  EDGE_28_102
 L  EDGE_21_63
 L  EDGE_0_40
 L  EDGE_33_73
 L  EDGE_51_90
 L  EDGE_43_86
 L  EDGE_14_59
 L  EDGE_67_71
 L  EDGE_16_105
 L  EDGE_17_70
 L  EDGE_55_96
 L  EDGE_7_56
 L  EDGE_0_17
 L  EDGE_5_95
 L  EDGE_58_107
 L  EDGE_50_103
 L  EDGE_21_76
 L  EDGE_73_86
 L  EDGE_3_27
 L  EDGE_54_109
 L  EDGE_16_82
 L  EDGE_35_95
 L  EDGE_36_60
 L  EDGE_55_73
 L  EDGE_1_102
 L  EDGE_26_46
 L  EDGE_67_84
 L  EDGE_17_83
 L  EDGE_28_92
 L  EDGE_69_93
 L  EDGE_5_108
 L  EDGE_54_86
 L  EDGE_33_63
 L  EDGE_73_99
 L  EDGE_31_102
 L  EDGE_66_96
 L  EDGE_55_86
 L  EDGE_6_50
 L  EDGE_50_93
 L  EDGE_21_66
 L  EDGE_61_102
 L  EDGE_27_109
 L  EDGE_25_36
 L  EDGE_2_52
 L  EDGE_3_17
 L  EDGE_95_100
 L  EDGE_106_109
 L  EDGE_13_67
 L  EDGE_35_85
 L  EDGE_28_46
 L  EDGE_88_97
 L  EDGE_38_96
 L  EDGE_58_74
 L  EDGE_49_105
 L  EDGE_29_47
 L  EDGE_40_56
 L  EDGE_10_33
 L  EDGE_32_57
 L  EDGE_51_70
 L  EDGE_24_53
 L  EDGE_37_108
 L  EDGE_65_90
 L  EDGE_2_6
 L  EDGE_11_91
 L  EDGE_39_73
 L  EDGE_4_88
 L  EDGE_72_106
 L  EDGE_24_66
 L  EDGE_35_75
 L  EDGE_36_40
 L  EDGE_29_37
 L  EDGE_15_102
 L  EDGE_18_107
 L  EDGE_39_50
 L  EDGE_10_23
 L  EDGE_42_92
 L  EDGE_83_93
 L  EDGE_102_106
 L  EDGE_94_102
 L  EDGE_19_108
 L  EDGE_60_109
 L  EDGE_39_86
 L  EDGE_52_105
 L  EDGE_12_69
 L  EDGE_4_65
 L  EDGE_23_78
 L  EDGE_24_43
 L  EDGE_51_60
 L  EDGE_16_39
 L  EDGE_103_107
 L  EDGE_95_103
 L  EDGE_87_99
 L  EDGE_34_93
 L  EDGE_45_102
 L  EDGE_37_98
 L  EDGE_17_40
 L  EDGE_76_89
 L  EDGE_9_36
 L  EDGE_49_72
 L  EDGE_79_100
 L  EDGE_90_109
 L  EDGE_8_76
 L  EDGE_27_89
 L  EDGE_0_72
 L  EDGE_4_42
 L  EDGE_1_36
 L  EDGE_25_101
 L  EDGE_4_78
 L  EDGE_14_91
 L  EDGE_34_106
 L  EDGE_46_80
 L  EDGE_42_46
 L  EDGE_15_92
 L  EDGE_7_88
 L  EDGE_19_62
 L  EDGE_20_27
 L  EDGE_39_40
 L  EDGE_2_9
 L  EDGE_21_108
 L  EDGE_12_59
 L  EDGE_72_73
 L  EDGE_24_33
 L  EDGE_43_46
 L  EDGE_53_96
 L  EDGE_45_92
 L  EDGE_37_88
 L  EDGE_17_30
 L  EDGE_57_66
 L  EDGE_97_102
 L  EDGE_26_78
 L  EDGE_27_43
 L  EDGE_18_74
 L  EDGE_90_99
 L  EDGE_82_95
 L  EDGE_40_98
 L  EDGE_20_40
 L  EDGE_6_105
 L  EDGE_39_53
 L  EDGE_4_32
 L  EDGE_75_92
 L  EDGE_94_105
 L  EDGE_41_99
 L  EDGE_25_91
 L  EDGE_53_73
 L  EDGE_45_69
 L  EDGE_2_107
 L  EDGE_15_46
 L  EDGE_18_51
 L  EDGE_37_101
 L  EDGE_38_66
 L  EDGE_36_105
 L  EDGE_26_91
 L  EDGE_19_52
 L  EDGE_11_48
 L  EDGE_71_99
 L  EDGE_63_95
 L  EDGE_21_98
 L  EDGE_41_76
 L  EDGE_52_85
 L  EDGE_22_62
 L  EDGE_14_58
 L  EDGE_3_85
 L  EDGE_9_16
 L  EDGE_22_98
 L  EDGE_55_95
 L  EDGE_11_25
 L  EDGE_52_62
 L  EDGE_104_109
 L  EDGE_1_16
 L  EDGE_25_81
 L  EDGE_64_72
 L  EDGE_14_71
 L  EDGE_26_45
 L  EDGE_40_65
 L  EDGE_5_107
 L  EDGE_21_88
 L  EDGE_41_66
 L  EDGE_52_75
 L  EDGE_4_35
 L  EDGE_3_39
 L  EDGE_14_48
 L  EDGE_34_63
 L  EDGE_85_108
 L  EDGE_37_68
 L  EDGE_35_107
 L  EDGE_36_72
 L  EDGE_26_58
 L  EDGE_18_54
 L  EDGE_70_101
 L  EDGE_36_108
 L  EDGE_41_43
 L  EDGE_44_48
 L  EDGE_1_6
 L  EDGE_54_98
 L  EDGE_33_75
 L  EDGE_34_40
 L  EDGE_45_49
 L  EDGE_37_45
 L  EDGE_2_87
 L  EDGE_22_65
 L  EDGE_15_26
 L  EDGE_26_35
 L  EDGE_18_31
 L  EDGE_78_82
 L  EDGE_55_98
 L  EDGE_29_46
 L  EDGE_48_59
 L  EDGE_9_104
 L  EDGE_50_105
 L  EDGE_21_78
 L  EDGE_73_88
 L  EDGE_25_48
 L  EDGE_31_91
 L  EDGE_2_64
 L  EDGE_3_29
 L  EDGE_22_42
 L  EDGE_13_79
 L  EDGE_15_39
 L  EDGE_29_59
 L  EDGE_61_91
 L  EDGE_6_75
 L  EDGE_3_6
 L  EDGE_62_92
 L  EDGE_81_105
 L  EDGE_14_51
 L  EDGE_7_12
 L  EDGE_13_92
 L  EDGE_24_101
 L  EDGE_47_84
 L  EDGE_0_9
 L  EDGE_42_91
 L  EDGE_21_68
 L  EDGE_61_104
 L  EDGE_62_69
 L  EDGE_8_98
 L  EDGE_81_82
 L  EDGE_39_85
 L  EDGE_2_54
 L  EDGE_43_55
 L  EDGE_84_93
 L  EDGE_103_106
 L  EDGE_95_102
 L  EDGE_24_78
 L  EDGE_43_91
 L  EDGE_16_74
 L  EDGE_17_39
 L  EDGE_35_87
 L  EDGE_36_52
 L  EDGE_96_103
 L  EDGE_6_29
 L  EDGE_17_75
 L  EDGE_77_89
 L  EDGE_30_93
 L  EDGE_10_35
 L  EDGE_91_109
 L  EDGE_73_91
 L  EDGE_13_46
 L  EDGE_31_94
 L  EDGE_23_90
 L  EDGE_43_68
 L  EDGE_84_106
 L  EDGE_34_105
 L  EDGE_13_82
 L  EDGE_16_87
 L  EDGE_9_48
 L  EDGE_49_84
 L  EDGE_26_100
 L  EDGE_6_42
 L  EDGE_61_94
 L  EDGE_0_84
 L  EDGE_19_97
 L  EDGE_20_62
 L  EDGE_11_93
 L  EDGE_39_75
 L  EDGE_30_106
 L  EDGE_45_91
 L  EDGE_56_100
 L  EDGE_17_29
 L  EDGE_22_107
 L  EDGE_14_103
 L  EDGE_6_19
 L  EDGE_50_62
 L  EDGE_7_100
 L  EDGE_11_70
 L  EDGE_83_95
 L  EDGE_8_101
 L  EDGE_95_105
 L  EDGE_1_61
 L  EDGE_45_104
 L  EDGE_46_69
 L  EDGE_37_100
 L  EDGE_65_82
 L  EDGE_17_42
 L  EDGE_3_107
 L  EDGE_15_81
 L  EDGE_38_101
 L  EDGE_58_79
 L  EDGE_30_60
 L  EDGE_20_52
 L  EDGE_31_61
 L  EDGE_75_104
 L  EDGE_34_72
 L  EDGE_56_90
 L  EDGE_17_19
 L  EDGE_3_84
 L  EDGE_67_105
 L  EDGE_57_91
 L  EDGE_50_52
 L  EDGE_42_48
 L  EDGE_8_55
 L  EDGE_11_60
 L  EDGE_39_42
 L  EDGE_63_107
 L  EDGE_44_93
 L  EDGE_16_31
 L  EDGE_1_51
 L  EDGE_87_91
 L  EDGE_34_85
 L  EDGE_53_98
 L  EDGE_38_55
 L  EDGE_97_104
 L  EDGE_9_28
 L  EDGE_55_107
 L  EDGE_26_80
 L  EDGE_79_92
 L  EDGE_82_97
 L  EDGE_29_91
 L  EDGE_40_100
 L  EDGE_20_42
 L  EDGE_6_107
 L  EDGE_52_74
 L  EDGE_83_98
 L  EDGE_75_94
 L  EDGE_45_71
 L  EDGE_85_107
 L  EDGE_64_84
 L  EDGE_2_109
 L  EDGE_3_74
 L  EDGE_14_83
 L  EDGE_67_95
 L  EDGE_59_91
 L  EDGE_7_80
 L  EDGE_48_81
 L  EDGE_27_58
 L  EDGE_18_89
 L  EDGE_21_100
 L  EDGE_41_78
 L  EDGE_1_5
 L  EDGE_33_74
 L  EDGE_45_48
 L  EDGE_24_25
 L  EDGE_37_44
 L  EDGE_34_75
 L  EDGE_25_106
 L  EDGE_37_80
 L  EDGE_55_97
 L  EDGE_27_35
 L  EDGE_59_104
 L  EDGE_17_107
 L  EDGE_90_91
 L  EDGE_48_94
 L  EDGE_40_90
 L  EDGE_52_64
 L  EDGE_23_37
 L  EDGE_1_18
 L  EDGE_74_88
 L  EDGE_53_65
 L  EDGE_56_70
 L  EDGE_43_100
 L  EDGE_22_77
 L  EDGE_15_38
 L  EDGE_67_85
 L  EDGE_59_81
 L  EDGE_70_90
 L  EDGE_36_97
 L  EDGE_29_58
 L  EDGE_8_35
 L  EDGE_0_31
 L  EDGE_25_60
 L  EDGE_44_73
 L  EDGE_10_80
 L  EDGE_14_50
 L  EDGE_66_97
 L  EDGE_13_91
 L  EDGE_16_96
 L  EDGE_18_56
 L  EDGE_17_97
 L  EDGE_28_106
 L  EDGE_2_53
 L  EDGE_62_104
 L  EDGE_25_73
 L  EDGE_45_51
 L  EDGE_32_81
 L  EDGE_51_94
 L  EDGE_24_77
 L  EDGE_15_28
 L  EDGE_96_102
 L  EDGE_18_33
 L  EDGE_0_21
 L  EDGE_5_99
 L  EDGE_50_107
 L  EDGE_10_34
 L  EDGE_2_66
 L  EDGE_16_86
 L  EDGE_17_51
 L  EDGE_6_41
 L  EDGE_9_83
 L  EDGE_50_84
 L  EDGE_77_101
 L  EDGE_29_61
 L  EDGE_69_97
 L  EDGE_80_106
 L  EDGE_2_43
 L  EDGE_4_89
 L  EDGE_51_84
 L  EDGE_47_50
 L  EDGE_18_23
 L  EDGE_69_74
 L  EDGE_48_51
 L  EDGE_21_34
 L  EDGE_92_94
 L  EDGE_2_20
 L  EDGE_8_100
 L  EDGE_20_74
 L  EDGE_39_87
 L  EDGE_2_56
 L  EDGE_103_108
 L  EDGE_14_30
 L  EDGE_4_102
 L  EDGE_32_84
 L  EDGE_24_80
 L  EDGE_35_89
 L  EDGE_28_50
 L  EDGE_1_96
 L  EDGE_9_73
 L  EDGE_49_109
 L  EDGE_61_83
 L  EDGE_27_90
 L  EDGE_11_82
 L  EDGE_31_60
 L  EDGE_2_33
 L  EDGE_23_92
 L  EDGE_24_57
 L  EDGE_34_107
 L  EDGE_57_90
 L  EDGE_76_103
 L  EDGE_7_89
 L  EDGE_26_102
 L  EDGE_6_44
 L  EDGE_10_14
 L  EDGE_42_83
 L  EDGE_19_99
 L  EDGE_20_64
 L  EDGE_39_77
 L  EDGE_32_38
 L  EDGE_43_47
 L  EDGE_34_84
 L  EDGE_13_61
 L  EDGE_24_70
 L  EDGE_37_89
 L  EDGE_28_40
 L  EDGE_14_105
 L  EDGE_26_79
 L  EDGE_15_106
 L  EDGE_7_102
 L  EDGE_27_80
 L  EDGE_11_72
 L  EDGE_39_54
 L  EDGE_2_23
 L  EDGE_54_70
 L  EDGE_1_27
 L  EDGE_32_51
 L  EDGE_84_98
 L  EDGE_16_43
 L  EDGE_2_108
 L  EDGE_34_97
 L  EDGE_42_73
 L  EDGE_29_103
 L  EDGE_8_80
 L  EDGE_60_90
 L  EDGE_52_86
 L  EDGE_13_15
 L  EDGE_31_63
 L  EDGE_4_46
 L  EDGE_16_20
 L  EDGE_1_40
 L  EDGE_34_74
 L  EDGE_38_44
 L  EDGE_56_92
 L  EDGE_17_21
 L  EDGE_14_95
 L  EDGE_18_65
 L  EDGE_49_89
 L  EDGE_42_50
 L  EDGE_15_96
 L  EDGE_7_92
 L  EDGE_83_87
 L  EDGE_1_17
 L  EDGE_25_82
 L  EDGE_10_102
 L  EDGE_56_69
 L  EDGE_46_61
 L  EDGE_89_102
 L  EDGE_14_108
 L  EDGE_8_34
 L  EDGE_26_82
 L  EDGE_18_78
 L  EDGE_11_39
 L  EDGE_48_106
 L  EDGE_60_80
 L  EDGE_6_109
 L  EDGE_44_72
 L  EDGE_23_49
 L  EDGE_34_64
 L  EDGE_74_100
 L  EDGE_25_95
 L  EDGE_53_77
 L  EDGE_44_108
 L  EDGE_56_82
 L  EDGE_22_89
 L  EDGE_26_59
 L  EDGE_18_55
 L  EDGE_70_102
 L  EDGE_48_83
 L  EDGE_0_43
 L  EDGE_20_21
 L  EDGE_71_103
 L  EDGE_21_102
 L  EDGE_1_7
 L  EDGE_52_89
 L  EDGE_45_50
 L  EDGE_10_92
 L  EDGE_56_59
 L  EDGE_2_88
 L  EDGE_3_53
 L  EDGE_22_66
 L  EDGE_26_36
 L  EDGE_18_32
 L  EDGE_16_108
 L  EDGE_49_56
 L  EDGE_55_99
 L  EDGE_47_95
 L  EDGE_0_20
 L  EDGE_17_109
 L  EDGE_9_105
 L  EDGE_29_83
 L  EDGE_21_79
 L  EDGE_40_92
 L  EDGE_52_66
 L  EDGE_1_20
 L  EDGE_34_54
 L  EDGE_93_103
 L  EDGE_3_66
 L  EDGE_43_102
 L  EDGE_14_75
 L  EDGE_7_36
 L  EDGE_78_96
 L  EDGE_48_73
 L  EDGE_21_56
 L  EDGE_0_33
 L  EDGE_41_70
 L  EDGE_73_102
 L  EDGE_44_75
 L  EDGE_31_105
 L  EDGE_51_83
 L  EDGE_2_78
 L  EDGE_3_43
 L  EDGE_18_22
 L  EDGE_0_10
 L  EDGE_6_53
 L  EDGE_58_100
 L  EDGE_29_73
 L  EDGE_69_109
 L  EDGE_40_82
 L  EDGE_41_47
 L  EDGE_33_43
 L  EDGE_4_16
 L  EDGE_44_52
 L  EDGE_12_105
 L  EDGE_37_49
 L  EDGE_51_96
 L  EDGE_43_92
 L  EDGE_15_30
 L  EDGE_26_39
 L  EDGE_5_65
 L  EDGE_36_89
 L  EDGE_29_50
 L  EDGE_25_52
 L  EDGE_23_91
 L  EDGE_43_69
 L  EDGE_84_107
 L  EDGE_35_65
 L  EDGE_1_72
 L  EDGE_24_92
 L  EDGE_16_88
 L  EDGE_55_79
 L  EDGE_58_90
 L  EDGE_69_99
 L  EDGE_80_108
 L  EDGE_30_107
 L  EDGE_31_72
 L  EDGE_2_45
 L  EDGE_62_96
 L  EDGE_14_19
 L  EDGE_12_95
 L  EDGE_72_109
 L  EDGE_23_104
 L  EDGE_36_43
 L  EDGE_1_85
 L  EDGE_9_62
 L  EDGE_48_53
 L  EDGE_40_49
 L  EDGE_27_79
 L  EDGE_6_56
 L  EDGE_2_22
 L  EDGE_62_73
 L  EDGE_25_42
 L  EDGE_51_63
 L  EDGE_35_55
 L  EDGE_14_32
 L  EDGE_16_78
 L  EDGE_36_56
 L  EDGE_9_39
 L  EDGE_28_52
 L  EDGE_21_49
 L  EDGE_8_79
 L  EDGE_10_39
 L  EDGE_23_58
 L  EDGE_83_109
 L  EDGE_75_105
 L  EDGE_54_82
 L  EDGE_32_63
 L  EDGE_34_109
 L  EDGE_65_96
 L  EDGE_17_56
 L  EDGE_57_92
 L  EDGE_9_52
 L  EDGE_29_30
 L  EDGE_6_46
 L  EDGE_50_89
 L  EDGE_83_86
 L  EDGE_94_95
 L  EDGE_12_62
 L  EDGE_52_98
 L  EDGE_32_40
 L  EDGE_23_71
 L  EDGE_87_92
 L  EDGE_13_63
 L  EDGE_53_99
 L  EDGE_64_108
 L  EDGE_65_73
 L  EDGE_56_104
 L  EDGE_68_78
 L  EDGE_14_107
 L  EDGE_6_23
 L  EDGE_38_92
 L  EDGE_79_93
 L  EDGE_49_101
 L  EDGE_69_79
 L  EDGE_61_75
 L  EDGE_19_78
 L  EDGE_39_56
 L  EDGE_91_103
 L  EDGE_23_48
 L  EDGE_41_102
 L  EDGE_12_75
 L  EDGE_53_76
 L  EDGE_4_71
 L  EDGE_35_58
 L  EDGE_46_73
 L  EDGE_7_81
 L  EDGE_18_90
 L  EDGE_71_102
 L  EDGE_0_78
 L  EDGE_41_79
 L  EDGE_60_92
 L  EDGE_52_88
 L  EDGE_53_89
 L  EDGE_46_50
 L  EDGE_3_88
 L  EDGE_22_101
 L  EDGE_67_109
 L  EDGE_82_88
 L  EDGE_19_68
 L  EDGE_6_98
 L  EDGE_39_46
 L  EDGE_30_77
 L  EDGE_41_92
 L  EDGE_33_88
 L  EDGE_34_53
 L  EDGE_38_59
 L  EDGE_57_72
 L  EDGE_97_108
 L  EDGE_89_104
 L  EDGE_36_98
 L  EDGE_0_32
 L  EDGE_63_88
 L  EDGE_21_91
 L  EDGE_12_42
 L  EDGE_2_77
 L  EDGE_22_55
 L  EDGE_34_66
 L  EDGE_74_102
 L  EDGE_53_79
 L  EDGE_45_75
 L  EDGE_14_87
 L  EDGE_26_61
 L  EDGE_11_18
 L  EDGE_28_107
 L  EDGE_29_72
 L  EDGE_6_88
 L  EDGE_31_32
 L  EDGE_62_105
 L  EDGE_34_43
 L  EDGE_45_52
 L  EDGE_64_65
 L  EDGE_37_48
 L  EDGE_56_61
 L  EDGE_7_25
 L  EDGE_38_49
 L  EDGE_48_62
 L  EDGE_30_44
 L  EDGE_71_82
 L  EDGE_40_94
 L  EDGE_41_59
 L  EDGE_33_55
 L  EDGE_6_101
 L  EDGE_25_51
 L  EDGE_44_64
 L  EDGE_2_67
 L  EDGE_22_45
 L  EDGE_34_56
 L  EDGE_66_88
 L  EDGE_24_91
 L  EDGE_55_78
 L  EDGE_26_51
 L  EDGE_67_89
 L  EDGE_36_101
 L  EDGE_6_78
 L  EDGE_73_104
 L  EDGE_43_81
 L  EDGE_15_19
 L  EDGE_26_28
 L  EDGE_13_95
 L  EDGE_55_91
 L  EDGE_28_74
 L  EDGE_48_52
 L  EDGE_5_90
 L  EDGE_6_55
 L  EDGE_92_95
 L  EDGE_9_97
 L  EDGE_50_98
 L  EDGE_29_75
 L  EDGE_21_71
 L  EDGE_52_58
 L  EDGE_25_41
 L  EDGE_10_61
 L  EDGE_3_22
 L  EDGE_62_108
 L  EDGE_22_35
 L  EDGE_13_72
 L  EDGE_16_77
 L  EDGE_35_90
 L  EDGE_36_55
 L  EDGE_15_32
 L  EDGE_55_68
 L  EDGE_1_97
 L  EDGE_88_102
 L  EDGE_18_37
 L  EDGE_59_75
 L  EDGE_17_78
 L  EDGE_28_87
 L  EDGE_5_103
 L  EDGE_6_68
 L  EDGE_2_34
 L  EDGE_81_98
 L  EDGE_54_81
 L  EDGE_51_75
 L  EDGE_43_71
 L  EDGE_1_74
 L  EDGE_35_103
 L  EDGE_47_77
 L  EDGE_5_80
 L  EDGE_10_15
 L  EDGE_69_101
 L  EDGE_42_84
 L  EDGE_30_109
 L  EDGE_51_52
 L  EDGE_3_12
 L  EDGE_20_101
 L  EDGE_12_97
 L  EDGE_23_106
 L  EDGE_17_32
 L  EDGE_76_81
 L  EDGE_88_92
 L  EDGE_5_57
 L  EDGE_65_108
 L  EDGE_80_87
 L  EDGE_10_28
 L  EDGE_2_24
 L  EDGE_54_71
 L  EDGE_73_84
 L  EDGE_11_109
 L  EDGE_12_74
 L  EDGE_39_91
 L  EDGE_32_52
 L  EDGE_72_88
 L  EDGE_24_48
 L  EDGE_84_99
 L  EDGE_35_57
 L  EDGE_4_106
 L  EDGE_45_107
 L  EDGE_5_34
 L  EDGE_36_58
 L  EDGE_76_94
 L  EDGE_61_87
 L  EDGE_19_90
 L  EDGE_39_68
 L  EDGE_30_99
 L  EDGE_17_22
 L  EDGE_5_47
 L  EDGE_6_12
 L  EDGE_46_85
 L  EDGE_38_81
 L  EDGE_65_98
 L  EDGE_26_106
 L  EDGE_39_45
 L  EDGE_94_97
 L  EDGE_20_68
 L  EDGE_13_29
 L  EDGE_72_78
 L  EDGE_23_73
 L  EDGE_84_89
 L  EDGE_17_35
 L  EDGE_57_71
 L  EDGE_28_44
 L  EDGE_18_79
 L  EDGE_98_108
 L  EDGE_30_53
 L  EDGE_50_68
 L  EDGE_90_104
 L  EDGE_48_107
 L  EDGE_4_37
 L  EDGE_53_78
 L  EDGE_45_74
 L  EDGE_64_87
 L  EDGE_37_70
 L  EDGE_56_83
 L  EDGE_3_77
 L  EDGE_26_60
 L  EDGE_37_106
 L  EDGE_38_71
 L  EDGE_57_84
 L  EDGE_26_96
 L  EDGE_12_18
 L  EDGE_30_66
 L  EDGE_71_104
 L  EDGE_2_4
 L  EDGE_29_107
 L  EDGE_20_58
 L  EDGE_53_55
 L  EDGE_44_86
 L  EDGE_22_67
 L  EDGE_1_44
 L  EDGE_45_87
 L  EDGE_55_100
 L  EDGE_19_34
 L  EDGE_71_81
 L  EDGE_0_57
 L  EDGE_19_70
 L  EDGE_11_66
 L  EDGE_4_27
 L  EDGE_83_91
 L  EDGE_41_94
 L  EDGE_1_21
 L  EDGE_44_99
 L  EDGE_72_81
 L  EDGE_3_67
 L  EDGE_46_65
 L  EDGE_59_84
 L  EDGE_28_96
 L  EDGE_47_109
 L  EDGE_48_74
 L  EDGE_40_106
 L  EDGE_25_63
 L  EDGE_4_40
 L  EDGE_10_83
 L  EDGE_26_27
 L  EDGE_45_77
 L  EDGE_24_103
 L  EDGE_15_54
 L  EDGE_26_63
 L  EDGE_59_97
 L  EDGE_11_20
 L  EDGE_70_106
 L  EDGE_9_96
 L  EDGE_21_70
 L  EDGE_41_48
 L  EDGE_21_106
 L  EDGE_22_34
 L  EDGE_33_80
 L  EDGE_10_96
 L  EDGE_3_57
 L  EDGE_22_70
 L  EDGE_26_40
 L  EDGE_18_36
 L  EDGE_47_99
 L  EDGE_8_28
 L  EDGE_48_64
 L  EDGE_40_60
 L  EDGE_5_102
 L  EDGE_6_67
 L  EDGE_63_80
 L  EDGE_9_109
 L  EDGE_21_83
 L  EDGE_25_53
 L  EDGE_16_89
 L  EDGE_55_80
 L  EDGE_0_1
 L  EDGE_77_104
 L  EDGE_28_99
 L  EDGE_40_73
 L  EDGE_33_34
 L  EDGE_4_7
 L  EDGE_2_46
 L  EDGE_20_100
 L  EDGE_66_67
 L  EDGE_37_40
 L  EDGE_43_83
 L  EDGE_35_79
 L  EDGE_15_21
 L  EDGE_55_57
 L  EDGE_66_103
 L  EDGE_67_68
 L  EDGE_16_102
 L  EDGE_36_80
 L  EDGE_48_54
 L  EDGE_0_14
 L  EDGE_6_57
 L  EDGE_11_23
 L  EDGE_58_104
 L  EDGE_9_99
 L  EDGE_10_27
 L  EDGE_42_96
 L  EDGE_61_109
 L  EDGE_81_87
 L  EDGE_44_56
 L  EDGE_31_86
 L  EDGE_10_63
 L  EDGE_51_64
 L  EDGE_22_37
 L  EDGE_12_109
 L  EDGE_13_74
 L  EDGE_43_96
 L  EDGE_16_79
 L  EDGE_96_108
 L  EDGE_5_69
 L  EDGE_61_86
 L  EDGE_40_63
 L  EDGE_27_93
 L  EDGE_30_98
 L  EDGE_54_83
 L  EDGE_39_103
 L  EDGE_12_86
 L  EDGE_31_99
 L  EDGE_3_37
 L  EDGE_13_87
 L  EDGE_24_96
 L  EDGE_17_57
 L  EDGE_36_70
 L  EDGE_68_102
 L  EDGE_26_105
 L  EDGE_5_82
 L  EDGE_69_103
 L  EDGE_61_99
 L  EDGE_54_60
 L  EDGE_33_37
 L  EDGE_20_67
 L  EDGE_11_98
 L  EDGE_2_49
 L  EDGE_84_88
 L  EDGE_22_27
 L  EDGE_66_70
 L  EDGE_53_100
 L  EDGE_64_109
 L  EDGE_65_74
 L  EDGE_55_60
 L  EDGE_1_89
 L  EDGE_9_66
 L  EDGE_50_67
 L  EDGE_77_84
 L  EDGE_42_63
 L  EDGE_80_89
 L  EDGE_10_30
 L  EDGE_83_100
 L  EDGE_62_77
 L  EDGE_13_41
 L  EDGE_31_89
 L  EDGE_72_90
 L  EDGE_43_63
 L  EDGE_45_109
 L  EDGE_38_70
 L  EDGE_26_95
 L  EDGE_79_107
 L  EDGE_11_88
 L  EDGE_1_43
 L  EDGE_53_90
 L  EDGE_72_103
 L  EDGE_45_86
 L  EDGE_64_99
 L  EDGE_16_59
 L  EDGE_36_37
 L  EDGE_9_20
 L  EDGE_28_33
 L  EDGE_6_14
 L  EDGE_38_83
 L  EDGE_58_61
 L  EDGE_90_93
 L  EDGE_21_30
 L  EDGE_61_66
 L  EDGE_26_108
 L  EDGE_18_104
 L  EDGE_20_34
 L  EDGE_30_78
 L  EDGE_31_43
 L  EDGE_54_63
 L  EDGE_0_92
 L  EDGE_20_70
 L  EDGE_44_98
 L  EDGE_84_91
 L  EDGE_16_36
 L  EDGE_34_90
 L  EDGE_45_99
 L  EDGE_86_100
 L  EDGE_65_77
 L  EDGE_97_109
 L  EDGE_3_102
 L  EDGE_68_82
 L  EDGE_19_46
 L  EDGE_90_106
 L  EDGE_40_105
 L  EDGE_19_82
 L  EDGE_20_47
 L  EDGE_12_43
 L  EDGE_4_39
 L  EDGE_83_103
 L  EDGE_1_33
 L  EDGE_13_44
 L  EDGE_37_72
 L  EDGE_18_58
 L  EDGE_70_105
 L  EDGE_7_85
 L  EDGE_48_86
 L  EDGE_18_94
 L  EDGE_19_59
 L  EDGE_20_24
 L  EDGE_75_76
 L  EDGE_41_83
 L  EDGE_12_56
 L  EDGE_108_109
 L  EDGE_34_80
 L  EDGE_49_59
 L  EDGE_89_95
 L  EDGE_14_101
 L  EDGE_18_71
 L  EDGE_19_36
 L  EDGE_98_100
 L  EDGE_42_56
 L  EDGE_12_33
 L  EDGE_52_69
 L  EDGE_4_29
 L  EDGE_10_72
 L  EDGE_75_89
 L  EDGE_33_92
 L  EDGE_34_57
 L  EDGE_7_39
 L  EDGE_67_90
 L  EDGE_38_63
 L  EDGE_28_98
 L  EDGE_0_36
 L  EDGE_63_92
 L  EDGE_40_108
 L  EDGE_60_86
 L  EDGE_37_39
 L  EDGE_10_85
 L  EDGE_66_102
 L  EDGE_26_29
 L  EDGE_37_75
 L  EDGE_38_40
 L  EDGE_16_101
 L  EDGE_55_92
 L  EDGE_7_52
 L  EDGE_26_65
 L  EDGE_5_91
 L  EDGE_11_22
 L  EDGE_71_73
 L  EDGE_41_50
 L  EDGE_6_92
 L  EDGE_22_36
 L  EDGE_54_105
 L  EDGE_34_47
 L  EDGE_25_78
 L  EDGE_66_79
 L  EDGE_3_59
 L  EDGE_14_68
 L  EDGE_96_107
 L  EDGE_78_89
 L  EDGE_17_79
 L  EDGE_28_88
 L  EDGE_48_66
 L  EDGE_5_104
 L  EDGE_29_89
 L  EDGE_42_108
 L  EDGE_39_102
 L  EDGE_31_98
 L  EDGE_14_45
 L  EDGE_66_92
 L  EDGE_85_105
 L  EDGE_32_99
 L  EDGE_28_65
 L  EDGE_7_42
 L  EDGE_47_78
 L  EDGE_17_92
 L  EDGE_77_106
 L  EDGE_28_101
 L  EDGE_40_75
 L  EDGE_4_9
 L  EDGE_2_48
 L  EDGE_20_102
 L  EDGE_66_69
 L  EDGE_12_98
 L  EDGE_51_89
 L  EDGE_55_59
 L  EDGE_15_23
 L  EDGE_1_88
 L  EDGE_67_70
 L  EDGE_18_28
 L  EDGE_99_102
 L  EDGE_24_108
 L  EDGE_17_69
 L  EDGE_77_83
 L  EDGE_100_103
 L  EDGE_50_102
 L  EDGE_62_76
 L  EDGE_0_101
 L  EDGE_25_45
 L  EDGE_31_88
 L  EDGE_84_100
 L  EDGE_54_108
 L  EDGE_87_105
 L  EDGE_35_94
 L  EDGE_76_95
 L  EDGE_55_72
 L  EDGE_88_106
 L  EDGE_58_83
 L  EDGE_9_78
 L  EDGE_50_79
 L  EDGE_61_88
 L  EDGE_80_101
 L  EDGE_27_95
 L  EDGE_39_69
 L  EDGE_54_85
 L  EDGE_12_88
 L  EDGE_23_97
 L  EDGE_51_79
 L  EDGE_1_78
 L  EDGE_5_48
 L  EDGE_65_99
 L  EDGE_16_94
 L  EDGE_28_68
 L  EDGE_42_88
 L  EDGE_27_108
 L  EDGE_20_69
 L  EDGE_39_82
 L  EDGE_1_55
 L  EDGE_13_66
 L  EDGE_16_71
 L  EDGE_36_49
 L  EDGE_76_85
 L  EDGE_46_99
 L  EDGE_77_86
 L  EDGE_50_69
 L  EDGE_42_65
 L  EDGE_21_42
 L  EDGE_20_46
 L  EDGE_91_106
 L  EDGE_8_108
 L  EDGE_0_104
 L  EDGE_20_82
 L  EDGE_32_56
 L  EDGE_72_92
 L  EDGE_16_48
 L  EDGE_35_61
 L  EDGE_34_102
 L  EDGE_65_89
 L  EDGE_38_72
 L  EDGE_68_94
 L  EDGE_27_62
 L  EDGE_6_39
 L  EDGE_18_93
 L  EDGE_50_82
 L  EDGE_20_59
 L  EDGE_60_95
 L  EDGE_11_90
 L  EDGE_32_33
 L  EDGE_1_45
 L  EDGE_37_84
 L  EDGE_65_66
 L  EDGE_16_61
 L  EDGE_28_35
 L  EDGE_26_74
 L  EDGE_5_51
 L  EDGE_46_89
 L  EDGE_49_94
 L  EDGE_50_59
 L  EDGE_15_101
 L  EDGE_61_68
 L  EDGE_101_104
 L  EDGE_7_97
 L  EDGE_0_58
 L  EDGE_19_71
 L  EDGE_20_36
 L  EDGE_39_49
 L  EDGE_94_101
 L  EDGE_60_108
 L  EDGE_33_91
 L  EDGE_13_33
 L  EDGE_16_38
 L  EDGE_56_74
 L  EDGE_3_104
 L  EDGE_89_107
 L  EDGE_15_78
 L  EDGE_52_81
 L  EDGE_31_58
 L  EDGE_33_104
 L  EDGE_25_100
 L  EDGE_37_74
 L  EDGE_56_87
 L  EDGE_22_94
 L  EDGE_67_102
 L  EDGE_27_29
 L  EDGE_38_75
 L  EDGE_70_107
 L  EDGE_71_72
 L  EDGE_42_45
 L  EDGE_48_88
 L  EDGE_27_65
 L  EDGE_11_57
 L  EDGE_12_22
 L  EDGE_33_81
 L  EDGE_13_23
 L  EDGE_25_77
 L  EDGE_45_55
 L  EDGE_56_64
 L  EDGE_22_71
 L  EDGE_14_67
 L  EDGE_67_79
 L  EDGE_46_56
 L  EDGE_38_52
 L  EDGE_78_88
 L  EDGE_97_101
 L  EDGE_0_25
 L  EDGE_19_38
 L  EDGE_79_89
 L  EDGE_11_34
 L  EDGE_71_85
 L  EDGE_63_81
 L  EDGE_82_94
 L  EDGE_0_61
 L  EDGE_12_35
 L  EDGE_44_67
 L  EDGE_1_25
 L  EDGE_34_59
 L  EDGE_25_90
 L  EDGE_53_72
 L  EDGE_93_108
 L  EDGE_45_68
 L  EDGE_32_98
 L  EDGE_37_64
 L  EDGE_2_106
 L  EDGE_43_107
 L  EDGE_15_45
 L  EDGE_26_54
 L  EDGE_67_92
 L  EDGE_78_101
 L  EDGE_70_97
 L  EDGE_9_87
 L  EDGE_63_94
 L  EDGE_29_101
 L  EDGE_34_36
 L  EDGE_52_84
 L  EDGE_10_87
 L  EDGE_7_18
 L  EDGE_8_19
 L  EDGE_27_32
 L  EDGE_59_101
 L  EDGE_18_63
 L  EDGE_100_102
 L  EDGE_11_24
 L  EDGE_10_64
 L  EDGE_93_98
 L  EDGE_66_81
 L  EDGE_85_94
 L  EDGE_32_88
 L  EDGE_37_54
 L  EDGE_96_109
 L  EDGE_59_78
 L  EDGE_17_81
 L  EDGE_29_55
 L  EDGE_21_51
 L  EDGE_0_28
 L  EDGE_80_100
 L  EDGE_54_84
 L  EDGE_33_61
 L  EDGE_44_70
 L  EDGE_23_96
 L  EDGE_2_73
 L  EDGE_7_8
COLUMNS
    x_0         OBJ       -18
    x_0         EDGE_0_73  1.0
    x_0         EDGE_0_27  1.0
    x_0         EDGE_0_40  1.0
    x_0         EDGE_0_17  1.0
    x_0         EDGE_0_72  1.0
    x_0         EDGE_0_9  1.0
    x_0         EDGE_0_84  1.0
    x_0         EDGE_0_31  1.0
    x_0         EDGE_0_21  1.0
    x_0         EDGE_0_43  1.0
    x_0         EDGE_0_20  1.0
    x_0         EDGE_0_33  1.0
    x_0         EDGE_0_10  1.0
    x_0         EDGE_0_78  1.0
    x_0         EDGE_0_32  1.0
    x_0         EDGE_0_57  1.0
    x_0         EDGE_0_1  1.0
    x_0         EDGE_0_14  1.0
    x_0         EDGE_0_92  1.0
    x_0         EDGE_0_36  1.0
    x_0         EDGE_0_101  1.0
    x_0         EDGE_0_104  1.0
    x_0         EDGE_0_58  1.0
    x_0         EDGE_0_25  1.0
    x_0         EDGE_0_61  1.0
    x_0         EDGE_0_28  1.0
    x_1         OBJ       -73
    x_1         EDGE_1_47  1.0
    x_1         EDGE_1_24  1.0
    x_1         EDGE_1_37  1.0
    x_1         EDGE_1_102  1.0
    x_1         EDGE_1_36  1.0
    x_1         EDGE_1_16  1.0
    x_1         EDGE_1_6  1.0
    x_1         EDGE_1_61  1.0
    x_1         EDGE_1_51  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_18  1.0
    x_1         EDGE_1_96  1.0
    x_1         EDGE_1_27  1.0
    x_1         EDGE_1_40  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_7  1.0
    x_1         EDGE_1_20  1.0
    x_1         EDGE_1_72  1.0
    x_1         EDGE_1_85  1.0
    x_1         EDGE_1_97  1.0
    x_1         EDGE_1_74  1.0
    x_1         EDGE_1_44  1.0
    x_1         EDGE_1_21  1.0
    x_1         EDGE_0_1  1.0
    x_1         EDGE_1_89  1.0
    x_1         EDGE_1_43  1.0
    x_1         EDGE_1_33  1.0
    x_1         EDGE_1_88  1.0
    x_1         EDGE_1_78  1.0
    x_1         EDGE_1_55  1.0
    x_1         EDGE_1_45  1.0
    x_1         EDGE_1_25  1.0
    x_2         OBJ       -98
    x_2         EDGE_2_7  1.0
    x_2         EDGE_2_52  1.0
    x_2         EDGE_2_6  1.0
    x_2         EDGE_2_9  1.0
    x_2         EDGE_2_107  1.0
    x_2         EDGE_2_87  1.0
    x_2         EDGE_2_64  1.0
    x_2         EDGE_2_54  1.0
    x_2         EDGE_2_109  1.0
    x_2         EDGE_2_53  1.0
    x_2         EDGE_2_66  1.0
    x_2         EDGE_2_43  1.0
    x_2         EDGE_2_20  1.0
    x_2         EDGE_2_56  1.0
    x_2         EDGE_2_33  1.0
    x_2         EDGE_2_23  1.0
    x_2         EDGE_2_108  1.0
    x_2         EDGE_2_88  1.0
    x_2         EDGE_2_78  1.0
    x_2         EDGE_2_45  1.0
    x_2         EDGE_2_22  1.0
    x_2         EDGE_2_77  1.0
    x_2         EDGE_2_67  1.0
    x_2         EDGE_2_34  1.0
    x_2         EDGE_2_24  1.0
    x_2         EDGE_2_4  1.0
    x_2         EDGE_2_46  1.0
    x_2         EDGE_2_49  1.0
    x_2         EDGE_2_48  1.0
    x_2         EDGE_2_106  1.0
    x_2         EDGE_2_73  1.0
    x_3         OBJ       -9
    x_3         EDGE_3_15  1.0
    x_3         EDGE_3_5  1.0
    x_3         EDGE_3_60  1.0
    x_3         EDGE_3_27  1.0
    x_3         EDGE_3_17  1.0
    x_3         EDGE_3_85  1.0
    x_3         EDGE_3_39  1.0
    x_3         EDGE_3_29  1.0
    x_3         EDGE_3_6  1.0
    x_3         EDGE_3_107  1.0
    x_3         EDGE_3_84  1.0
    x_3         EDGE_3_74  1.0
    x_3         EDGE_3_53  1.0
    x_3         EDGE_3_66  1.0
    x_3         EDGE_3_43  1.0
    x_3         EDGE_3_88  1.0
    x_3         EDGE_3_22  1.0
    x_3         EDGE_3_12  1.0
    x_3         EDGE_3_77  1.0
    x_3         EDGE_3_67  1.0
    x_3         EDGE_3_57  1.0
    x_3         EDGE_3_37  1.0
    x_3         EDGE_3_102  1.0
    x_3         EDGE_3_59  1.0
    x_3         EDGE_3_104  1.0
    x_4         OBJ       -33
    x_4         EDGE_4_63  1.0
    x_4         EDGE_4_88  1.0
    x_4         EDGE_4_65  1.0
    x_4         EDGE_4_42  1.0
    x_4         EDGE_4_78  1.0
    x_4         EDGE_4_32  1.0
    x_4         EDGE_4_35  1.0
    x_4         EDGE_4_89  1.0
    x_4         EDGE_4_102  1.0
    x_4         EDGE_4_46  1.0
    x_4         EDGE_4_16  1.0
    x_4         EDGE_4_71  1.0
    x_4         EDGE_4_106  1.0
    x_4         EDGE_4_37  1.0
    x_4         EDGE_2_4  1.0
    x_4         EDGE_4_27  1.0
    x_4         EDGE_4_40  1.0
    x_4         EDGE_4_7  1.0
    x_4         EDGE_4_39  1.0
    x_4         EDGE_4_29  1.0
    x_4         EDGE_4_9  1.0
    x_5         OBJ       -16
    x_5         EDGE_5_73  1.0
    x_5         EDGE_3_5  1.0
    x_5         EDGE_5_63  1.0
    x_5         EDGE_5_40  1.0
    x_5         EDGE_5_30  1.0
    x_5         EDGE_5_95  1.0
    x_5         EDGE_5_108  1.0
    x_5         EDGE_5_107  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_99  1.0
    x_5         EDGE_5_65  1.0
    x_5         EDGE_5_90  1.0
    x_5         EDGE_5_103  1.0
    x_5         EDGE_5_80  1.0
    x_5         EDGE_5_57  1.0
    x_5         EDGE_5_34  1.0
    x_5         EDGE_5_47  1.0
    x_5         EDGE_5_102  1.0
    x_5         EDGE_5_69  1.0
    x_5         EDGE_5_82  1.0
    x_5         EDGE_5_91  1.0
    x_5         EDGE_5_104  1.0
    x_5         EDGE_5_48  1.0
    x_5         EDGE_5_51  1.0
    x_6         OBJ       -64
    x_6         EDGE_6_51  1.0
    x_6         EDGE_6_18  1.0
    x_6         EDGE_6_93  1.0
    x_6         EDGE_6_50  1.0
    x_6         EDGE_2_6  1.0
    x_6         EDGE_6_105  1.0
    x_6         EDGE_1_6  1.0
    x_6         EDGE_6_75  1.0
    x_6         EDGE_3_6  1.0
    x_6         EDGE_6_29  1.0
    x_6         EDGE_6_42  1.0
    x_6         EDGE_6_19  1.0
    x_6         EDGE_6_107  1.0
    x_6         EDGE_6_41  1.0
    x_6         EDGE_6_44  1.0
    x_6         EDGE_6_109  1.0
    x_6         EDGE_6_53  1.0
    x_6         EDGE_6_56  1.0
    x_6         EDGE_6_46  1.0
    x_6         EDGE_6_23  1.0
    x_6         EDGE_6_98  1.0
    x_6         EDGE_6_88  1.0
    x_6         EDGE_6_101  1.0
    x_6         EDGE_6_78  1.0
    x_6         EDGE_6_55  1.0
    x_6         EDGE_6_68  1.0
    x_6         EDGE_6_12  1.0
    x_6         EDGE_6_67  1.0
    x_6         EDGE_6_57  1.0
    x_6         EDGE_6_14  1.0
    x_6         EDGE_6_92  1.0
    x_6         EDGE_6_39  1.0
    x_7         OBJ       -98
    x_7         EDGE_7_96  1.0
    x_7         EDGE_2_7  1.0
    x_7         EDGE_7_66  1.0
    x_7         EDGE_7_56  1.0
    x_7         EDGE_7_88  1.0
    x_7         EDGE_7_12  1.0
    x_7         EDGE_7_100  1.0
    x_7         EDGE_7_80  1.0
    x_7         EDGE_7_89  1.0
    x_7         EDGE_7_102  1.0
    x_7         EDGE_7_92  1.0
    x_7         EDGE_1_7  1.0
    x_7         EDGE_7_36  1.0
    x_7         EDGE_7_81  1.0
    x_7         EDGE_7_25  1.0
    x_7         EDGE_4_7  1.0
    x_7         EDGE_7_85  1.0
    x_7         EDGE_7_39  1.0
    x_7         EDGE_7_52  1.0
    x_7         EDGE_7_42  1.0
    x_7         EDGE_7_97  1.0
    x_7         EDGE_7_18  1.0
    x_7         EDGE_7_8  1.0
    x_8         OBJ       -58
    x_8         EDGE_8_97  1.0
    x_8         EDGE_8_31  1.0
    x_8         EDGE_8_76  1.0
    x_8         EDGE_8_98  1.0
    x_8         EDGE_8_101  1.0
    x_8         EDGE_8_55  1.0
    x_8         EDGE_8_35  1.0
    x_8         EDGE_8_100  1.0
    x_8         EDGE_8_80  1.0
    x_8         EDGE_8_34  1.0
    x_8         EDGE_8_79  1.0
    x_8         EDGE_8_28  1.0
    x_8         EDGE_8_108  1.0
    x_8         EDGE_8_19  1.0
    x_8         EDGE_7_8  1.0
    x_9         OBJ       -61
    x_9         EDGE_9_67  1.0
    x_9         EDGE_9_34  1.0
    x_9         EDGE_9_36  1.0
    x_9         EDGE_2_9  1.0
    x_9         EDGE_9_16  1.0
    x_9         EDGE_9_104  1.0
    x_9         EDGE_0_9  1.0
    x_9         EDGE_9_48  1.0
    x_9         EDGE_9_28  1.0
    x_9         EDGE_9_83  1.0
    x_9         EDGE_9_73  1.0
    x_9         EDGE_9_105  1.0
    x_9         EDGE_9_62  1.0
    x_9         EDGE_9_39  1.0
    x_9         EDGE_9_52  1.0
    x_9         EDGE_9_97  1.0
    x_9         EDGE_9_96  1.0
    x_9         EDGE_9_109  1.0
    x_9         EDGE_9_99  1.0
    x_9         EDGE_9_66  1.0
    x_9         EDGE_9_20  1.0
    x_9         EDGE_4_9  1.0
    x_9         EDGE_9_78  1.0
    x_9         EDGE_9_87  1.0
    x_10        OBJ       -84
    x_10        EDGE_10_21  1.0
    x_10        EDGE_10_11  1.0
    x_10        EDGE_10_33  1.0
    x_10        EDGE_10_23  1.0
    x_10        EDGE_10_35  1.0
    x_10        EDGE_10_80  1.0
    x_10        EDGE_10_34  1.0
    x_10        EDGE_10_14  1.0
    x_10        EDGE_10_102  1.0
    x_10        EDGE_10_92  1.0
    x_10        EDGE_0_10  1.0
    x_10        EDGE_10_39  1.0
    x_10        EDGE_10_61  1.0
    x_10        EDGE_10_15  1.0
    x_10        EDGE_10_28  1.0
    x_10        EDGE_10_83  1.0
    x_10        EDGE_10_96  1.0
    x_10        EDGE_10_27  1.0
    x_10        EDGE_10_63  1.0
    x_10        EDGE_10_30  1.0
    x_10        EDGE_10_72  1.0
    x_10        EDGE_10_85  1.0
    x_10        EDGE_10_87  1.0
    x_10        EDGE_10_64  1.0
    x_11        OBJ       -49
    x_11        EDGE_11_102  1.0
    x_11        EDGE_10_11  1.0
    x_11        EDGE_11_92  1.0
    x_11        EDGE_11_36  1.0
    x_11        EDGE_11_91  1.0
    x_11        EDGE_11_48  1.0
    x_11        EDGE_11_25  1.0
    x_11        EDGE_11_93  1.0
    x_11        EDGE_11_70  1.0
    x_11        EDGE_11_60  1.0
    x_11        EDGE_11_82  1.0
    x_11        EDGE_11_72  1.0
    x_11        EDGE_11_39  1.0
    x_11        EDGE_11_18  1.0
    x_11        EDGE_11_109  1.0
    x_11        EDGE_11_66  1.0
    x_11        EDGE_11_20  1.0
    x_11        EDGE_11_23  1.0
    x_11        EDGE_11_98  1.0
    x_11        EDGE_11_88  1.0
    x_11        EDGE_11_22  1.0
    x_11        EDGE_11_90  1.0
    x_11        EDGE_11_57  1.0
    x_11        EDGE_11_34  1.0
    x_11        EDGE_11_24  1.0
    x_12        OBJ       -27
    x_12        EDGE_12_77  1.0
    x_12        EDGE_12_90  1.0
    x_12        EDGE_12_80  1.0
    x_12        EDGE_12_69  1.0
    x_12        EDGE_12_59  1.0
    x_12        EDGE_7_12  1.0
    x_12        EDGE_12_105  1.0
    x_12        EDGE_12_95  1.0
    x_12        EDGE_12_62  1.0
    x_12        EDGE_12_75  1.0
    x_12        EDGE_12_42  1.0
    x_12        EDGE_3_12  1.0
    x_12        EDGE_12_97  1.0
    x_12        EDGE_12_74  1.0
    x_12        EDGE_6_12  1.0
    x_12        EDGE_12_18  1.0
    x_12        EDGE_12_109  1.0
    x_12        EDGE_12_86  1.0
    x_12        EDGE_12_43  1.0
    x_12        EDGE_12_56  1.0
    x_12        EDGE_12_33  1.0
    x_12        EDGE_12_98  1.0
    x_12        EDGE_12_88  1.0
    x_12        EDGE_12_22  1.0
    x_12        EDGE_12_35  1.0
    x_13        OBJ       -13
    x_13        EDGE_13_32  1.0
    x_13        EDGE_13_45  1.0
    x_13        EDGE_13_35  1.0
    x_13        EDGE_13_67  1.0
    x_13        EDGE_13_79  1.0
    x_13        EDGE_13_92  1.0
    x_13        EDGE_13_46  1.0
    x_13        EDGE_13_82  1.0
    x_13        EDGE_13_91  1.0
    x_13        EDGE_13_61  1.0
    x_13        EDGE_13_15  1.0
    x_13        EDGE_13_63  1.0
    x_13        EDGE_13_95  1.0
    x_13        EDGE_13_72  1.0
    x_13        EDGE_13_29  1.0
    x_13        EDGE_13_74  1.0
    x_13        EDGE_13_87  1.0
    x_13        EDGE_13_41  1.0
    x_13        EDGE_13_44  1.0
    x_13        EDGE_13_66  1.0
    x_13        EDGE_13_33  1.0
    x_13        EDGE_13_23  1.0
    x_14        OBJ       -63
    x_14        EDGE_14_102  1.0
    x_14        EDGE_14_46  1.0
    x_14        EDGE_14_59  1.0
    x_14        EDGE_14_91  1.0
    x_14        EDGE_14_58  1.0
    x_14        EDGE_14_71  1.0
    x_14        EDGE_14_48  1.0
    x_14        EDGE_14_51  1.0
    x_14        EDGE_14_103  1.0
    x_14        EDGE_14_83  1.0
    x_14        EDGE_14_50  1.0
    x_14        EDGE_14_30  1.0
    x_14        EDGE_10_14  1.0
    x_14        EDGE_14_105  1.0
    x_14        EDGE_14_95  1.0
    x_14        EDGE_14_108  1.0
    x_14        EDGE_14_75  1.0
    x_14        EDGE_14_19  1.0
    x_14        EDGE_14_32  1.0
    x_14        EDGE_14_107  1.0
    x_14        EDGE_14_87  1.0
    x_14        EDGE_0_14  1.0
    x_14        EDGE_6_14  1.0
    x_14        EDGE_14_101  1.0
    x_14        EDGE_14_68  1.0
    x_14        EDGE_14_45  1.0
    x_14        EDGE_14_67  1.0
    x_15        OBJ       -4
    x_15        EDGE_3_15  1.0
    x_15        EDGE_15_103  1.0
    x_15        EDGE_15_47  1.0
    x_15        EDGE_15_102  1.0
    x_15        EDGE_15_92  1.0
    x_15        EDGE_15_46  1.0
    x_15        EDGE_15_26  1.0
    x_15        EDGE_15_39  1.0
    x_15        EDGE_15_81  1.0
    x_15        EDGE_15_38  1.0
    x_15        EDGE_15_28  1.0
    x_15        EDGE_15_106  1.0
    x_15        EDGE_13_15  1.0
    x_15        EDGE_15_96  1.0
    x_15        EDGE_15_30  1.0
    x_15        EDGE_15_19  1.0
    x_15        EDGE_15_32  1.0
    x_15        EDGE_10_15  1.0
    x_15        EDGE_15_54  1.0
    x_15        EDGE_15_21  1.0
    x_15        EDGE_15_23  1.0
    x_15        EDGE_15_101  1.0
    x_15        EDGE_15_78  1.0
    x_15        EDGE_15_45  1.0
    x_16        OBJ       -50
    x_16        EDGE_16_93  1.0
    x_16        EDGE_16_70  1.0
    x_16        EDGE_16_106  1.0
    x_16        EDGE_16_83  1.0
    x_16        EDGE_16_17  1.0
    x_16        EDGE_16_30  1.0
    x_16        EDGE_16_105  1.0
    x_16        EDGE_16_82  1.0
    x_16        EDGE_16_39  1.0
    x_16        EDGE_9_16  1.0
    x_16        EDGE_1_16  1.0
    x_16        EDGE_16_74  1.0
    x_16        EDGE_16_87  1.0
    x_16        EDGE_16_31  1.0
    x_16        EDGE_16_96  1.0
    x_16        EDGE_16_86  1.0
    x_16        EDGE_16_43  1.0
    x_16        EDGE_16_20  1.0
    x_16        EDGE_16_108  1.0
    x_16        EDGE_4_16  1.0
    x_16        EDGE_16_88  1.0
    x_16        EDGE_16_78  1.0
    x_16        EDGE_16_77  1.0
    x_16        EDGE_16_89  1.0
    x_16        EDGE_16_102  1.0
    x_16        EDGE_16_79  1.0
    x_16        EDGE_16_59  1.0
    x_16        EDGE_16_36  1.0
    x_16        EDGE_16_101  1.0
    x_16        EDGE_16_94  1.0
    x_16        EDGE_16_71  1.0
    x_16        EDGE_16_48  1.0
    x_16        EDGE_16_61  1.0
    x_16        EDGE_16_38  1.0
    x_17        OBJ       -56
    x_17        EDGE_17_71  1.0
    x_17        EDGE_16_17  1.0
    x_17        EDGE_17_93  1.0
    x_17        EDGE_17_70  1.0
    x_17        EDGE_0_17  1.0
    x_17        EDGE_17_83  1.0
    x_17        EDGE_3_17  1.0
    x_17        EDGE_17_40  1.0
    x_17        EDGE_17_30  1.0
    x_17        EDGE_17_39  1.0
    x_17        EDGE_17_75  1.0
    x_17        EDGE_17_29  1.0
    x_17        EDGE_17_42  1.0
    x_17        EDGE_17_19  1.0
    x_17        EDGE_17_107  1.0
    x_17        EDGE_17_97  1.0
    x_17        EDGE_17_51  1.0
    x_17        EDGE_17_21  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_17_109  1.0
    x_17        EDGE_17_56  1.0
    x_17        EDGE_17_78  1.0
    x_17        EDGE_17_32  1.0
    x_17        EDGE_17_22  1.0
    x_17        EDGE_17_35  1.0
    x_17        EDGE_17_57  1.0
    x_17        EDGE_17_79  1.0
    x_17        EDGE_17_92  1.0
    x_17        EDGE_17_69  1.0
    x_17        EDGE_17_81  1.0
    x_18        OBJ       -78
    x_18        EDGE_6_18  1.0
    x_18        EDGE_18_75  1.0
    x_18        EDGE_18_52  1.0
    x_18        EDGE_18_107  1.0
    x_18        EDGE_18_74  1.0
    x_18        EDGE_18_51  1.0
    x_18        EDGE_18_54  1.0
    x_18        EDGE_18_31  1.0
    x_18        EDGE_18_89  1.0
    x_18        EDGE_1_18  1.0
    x_18        EDGE_18_56  1.0
    x_18        EDGE_18_33  1.0
    x_18        EDGE_18_23  1.0
    x_18        EDGE_18_65  1.0
    x_18        EDGE_18_78  1.0
    x_18        EDGE_18_55  1.0
    x_18        EDGE_18_32  1.0
    x_18        EDGE_18_22  1.0
    x_18        EDGE_18_90  1.0
    x_18        EDGE_11_18  1.0
    x_18        EDGE_18_37  1.0
    x_18        EDGE_18_79  1.0
    x_18        EDGE_12_18  1.0
    x_18        EDGE_18_36  1.0
    x_18        EDGE_18_104  1.0
    x_18        EDGE_18_58  1.0
    x_18        EDGE_18_94  1.0
    x_18        EDGE_18_71  1.0
    x_18        EDGE_18_28  1.0
    x_18        EDGE_18_93  1.0
    x_18        EDGE_7_18  1.0
    x_18        EDGE_18_63  1.0
    x_19        OBJ       -98
    x_19        EDGE_19_96  1.0
    x_19        EDGE_19_73  1.0
    x_19        EDGE_19_50  1.0
    x_19        EDGE_19_108  1.0
    x_19        EDGE_19_62  1.0
    x_19        EDGE_19_52  1.0
    x_19        EDGE_19_97  1.0
    x_19        EDGE_6_19  1.0
    x_19        EDGE_17_19  1.0
    x_19        EDGE_19_99  1.0
    x_19        EDGE_14_19  1.0
    x_19        EDGE_19_78  1.0
    x_19        EDGE_19_68  1.0
    x_19        EDGE_15_19  1.0
    x_19        EDGE_19_90  1.0
    x_19        EDGE_19_34  1.0
    x_19        EDGE_19_70  1.0
    x_19        EDGE_19_46  1.0
    x_19        EDGE_19_82  1.0
    x_19        EDGE_19_59  1.0
    x_19        EDGE_19_36  1.0
    x_19        EDGE_19_71  1.0
    x_19        EDGE_19_38  1.0
    x_19        EDGE_8_19  1.0
    x_20        OBJ       -99
    x_20        EDGE_20_104  1.0
    x_20        EDGE_20_28  1.0
    x_20        EDGE_20_27  1.0
    x_20        EDGE_20_40  1.0
    x_20        EDGE_20_62  1.0
    x_20        EDGE_20_52  1.0
    x_20        EDGE_20_42  1.0
    x_20        EDGE_2_20  1.0
    x_20        EDGE_20_74  1.0
    x_20        EDGE_20_64  1.0
    x_20        EDGE_16_20  1.0
    x_20        EDGE_20_21  1.0
    x_20        EDGE_0_20  1.0
    x_20        EDGE_1_20  1.0
    x_20        EDGE_20_101  1.0
    x_20        EDGE_20_68  1.0
    x_20        EDGE_20_58  1.0
    x_20        EDGE_11_20  1.0
    x_20        EDGE_20_100  1.0
    x_20        EDGE_20_67  1.0
    x_20        EDGE_9_20  1.0
    x_20        EDGE_20_34  1.0
    x_20        EDGE_20_70  1.0
    x_20        EDGE_20_47  1.0
    x_20        EDGE_20_24  1.0
    x_20        EDGE_20_102  1.0
    x_20        EDGE_20_69  1.0
    x_20        EDGE_20_46  1.0
    x_20        EDGE_20_82  1.0
    x_20        EDGE_20_59  1.0
    x_20        EDGE_20_36  1.0
    x_21        OBJ       -1
    x_21        EDGE_21_64  1.0
    x_21        EDGE_21_41  1.0
    x_21        EDGE_10_21  1.0
    x_21        EDGE_21_96  1.0
    x_21        EDGE_21_86  1.0
    x_21        EDGE_21_63  1.0
    x_21        EDGE_21_76  1.0
    x_21        EDGE_21_66  1.0
    x_21        EDGE_21_108  1.0
    x_21        EDGE_21_98  1.0
    x_21        EDGE_21_88  1.0
    x_21        EDGE_21_78  1.0
    x_21        EDGE_21_68  1.0
    x_21        EDGE_21_100  1.0
    x_21        EDGE_0_21  1.0
    x_21        EDGE_21_34  1.0
    x_21        EDGE_17_21  1.0
    x_21        EDGE_20_21  1.0
    x_21        EDGE_21_102  1.0
    x_21        EDGE_21_79  1.0
    x_21        EDGE_21_56  1.0
    x_21        EDGE_21_49  1.0
    x_21        EDGE_21_91  1.0
    x_21        EDGE_21_71  1.0
    x_21        EDGE_1_21  1.0
    x_21        EDGE_21_70  1.0
    x_21        EDGE_21_106  1.0
    x_21        EDGE_21_83  1.0
    x_21        EDGE_15_21  1.0
    x_21        EDGE_21_30  1.0
    x_21        EDGE_21_42  1.0
    x_21        EDGE_21_51  1.0
    x_22        OBJ       -90
    x_22        EDGE_22_93  1.0
    x_22        EDGE_22_96  1.0
    x_22        EDGE_22_62  1.0
    x_22        EDGE_22_98  1.0
    x_22        EDGE_22_65  1.0
    x_22        EDGE_22_42  1.0
    x_22        EDGE_22_107  1.0
    x_22        EDGE_22_77  1.0
    x_22        EDGE_22_89  1.0
    x_22        EDGE_22_66  1.0
    x_22        EDGE_18_22  1.0
    x_22        EDGE_2_22  1.0
    x_22        EDGE_22_101  1.0
    x_22        EDGE_22_55  1.0
    x_22        EDGE_22_45  1.0
    x_22        EDGE_3_22  1.0
    x_22        EDGE_22_35  1.0
    x_22        EDGE_17_22  1.0
    x_22        EDGE_22_67  1.0
    x_22        EDGE_22_34  1.0
    x_22        EDGE_22_70  1.0
    x_22        EDGE_22_37  1.0
    x_22        EDGE_22_27  1.0
    x_22        EDGE_11_22  1.0
    x_22        EDGE_22_36  1.0
    x_22        EDGE_22_94  1.0
    x_22        EDGE_12_22  1.0
    x_22        EDGE_22_71  1.0
    x_23        OBJ       -58
    x_23        EDGE_23_99  1.0
    x_23        EDGE_23_89  1.0
    x_23        EDGE_23_66  1.0
    x_23        EDGE_23_33  1.0
    x_23        EDGE_10_23  1.0
    x_23        EDGE_23_78  1.0
    x_23        EDGE_23_90  1.0
    x_23        EDGE_23_37  1.0
    x_23        EDGE_18_23  1.0
    x_23        EDGE_23_92  1.0
    x_23        EDGE_2_23  1.0
    x_23        EDGE_23_49  1.0
    x_23        EDGE_23_91  1.0
    x_23        EDGE_23_104  1.0
    x_23        EDGE_23_58  1.0
    x_23        EDGE_23_71  1.0
    x_23        EDGE_6_23  1.0
    x_23        EDGE_23_48  1.0
    x_23        EDGE_23_106  1.0
    x_23        EDGE_23_73  1.0
    x_23        EDGE_11_23  1.0
    x_23        EDGE_15_23  1.0
    x_23        EDGE_23_97  1.0
    x_23        EDGE_13_23  1.0
    x_23        EDGE_23_96  1.0
    x_24        OBJ       -35
    x_24        EDGE_24_31  1.0
    x_24        EDGE_1_24  1.0
    x_24        EDGE_24_53  1.0
    x_24        EDGE_24_66  1.0
    x_24        EDGE_24_43  1.0
    x_24        EDGE_24_33  1.0
    x_24        EDGE_24_101  1.0
    x_24        EDGE_24_78  1.0
    x_24        EDGE_24_25  1.0
    x_24        EDGE_24_77  1.0
    x_24        EDGE_24_80  1.0
    x_24        EDGE_24_57  1.0
    x_24        EDGE_24_70  1.0
    x_24        EDGE_24_92  1.0
    x_24        EDGE_24_91  1.0
    x_24        EDGE_2_24  1.0
    x_24        EDGE_24_48  1.0
    x_24        EDGE_24_103  1.0
    x_24        EDGE_24_96  1.0
    x_24        EDGE_20_24  1.0
    x_24        EDGE_24_108  1.0
    x_24        EDGE_11_24  1.0
    x_25        OBJ       -93
    x_25        EDGE_25_34  1.0
    x_25        EDGE_25_89  1.0
    x_25        EDGE_25_102  1.0
    x_25        EDGE_25_79  1.0
    x_25        EDGE_25_36  1.0
    x_25        EDGE_25_101  1.0
    x_25        EDGE_25_91  1.0
    x_25        EDGE_11_25  1.0
    x_25        EDGE_25_81  1.0
    x_25        EDGE_25_48  1.0
    x_25        EDGE_24_25  1.0
    x_25        EDGE_25_106  1.0
    x_25        EDGE_25_60  1.0
    x_25        EDGE_25_73  1.0
    x_25        EDGE_25_82  1.0
    x_25        EDGE_25_95  1.0
    x_25        EDGE_25_52  1.0
    x_25        EDGE_25_42  1.0
    x_25        EDGE_7_25  1.0
    x_25        EDGE_25_51  1.0
    x_25        EDGE_25_41  1.0
    x_25        EDGE_25_63  1.0
    x_25        EDGE_25_53  1.0
    x_25        EDGE_25_78  1.0
    x_25        EDGE_25_45  1.0
    x_25        EDGE_25_100  1.0
    x_25        EDGE_25_77  1.0
    x_25        EDGE_0_25  1.0
    x_25        EDGE_1_25  1.0
    x_25        EDGE_25_90  1.0
    x_26        OBJ       -30
    x_26        EDGE_26_53  1.0
    x_26        EDGE_26_89  1.0
    x_26        EDGE_26_66  1.0
    x_26        EDGE_26_43  1.0
    x_26        EDGE_26_46  1.0
    x_26        EDGE_26_78  1.0
    x_26        EDGE_26_91  1.0
    x_26        EDGE_26_45  1.0
    x_26        EDGE_26_58  1.0
    x_26        EDGE_15_26  1.0
    x_26        EDGE_26_35  1.0
    x_26        EDGE_26_100  1.0
    x_26        EDGE_26_80  1.0
    x_26        EDGE_26_102  1.0
    x_26        EDGE_26_79  1.0
    x_26        EDGE_26_82  1.0
    x_26        EDGE_26_59  1.0
    x_26        EDGE_26_36  1.0
    x_26        EDGE_26_39  1.0
    x_26        EDGE_26_61  1.0
    x_26        EDGE_26_51  1.0
    x_26        EDGE_26_28  1.0
    x_26        EDGE_26_106  1.0
    x_26        EDGE_26_60  1.0
    x_26        EDGE_26_96  1.0
    x_26        EDGE_26_27  1.0
    x_26        EDGE_26_63  1.0
    x_26        EDGE_26_40  1.0
    x_26        EDGE_26_105  1.0
    x_26        EDGE_26_95  1.0
    x_26        EDGE_26_108  1.0
    x_26        EDGE_26_29  1.0
    x_26        EDGE_26_65  1.0
    x_26        EDGE_26_74  1.0
    x_26        EDGE_26_54  1.0
    x_27        OBJ       -76
    x_27        EDGE_27_107  1.0
    x_27        EDGE_0_27  1.0
    x_27        EDGE_3_27  1.0
    x_27        EDGE_27_109  1.0
    x_27        EDGE_27_89  1.0
    x_27        EDGE_20_27  1.0
    x_27        EDGE_27_43  1.0
    x_27        EDGE_27_58  1.0
    x_27        EDGE_27_35  1.0
    x_27        EDGE_27_90  1.0
    x_27        EDGE_27_80  1.0
    x_27        EDGE_1_27  1.0
    x_27        EDGE_27_79  1.0
    x_27        EDGE_4_27  1.0
    x_27        EDGE_26_27  1.0
    x_27        EDGE_10_27  1.0
    x_27        EDGE_27_93  1.0
    x_27        EDGE_22_27  1.0
    x_27        EDGE_27_95  1.0
    x_27        EDGE_27_108  1.0
    x_27        EDGE_27_62  1.0
    x_27        EDGE_27_29  1.0
    x_27        EDGE_27_65  1.0
    x_27        EDGE_27_32  1.0
    x_28        OBJ       -14
    x_28        EDGE_28_47  1.0
    x_28        EDGE_20_28  1.0
    x_28        EDGE_28_102  1.0
    x_28        EDGE_28_92  1.0
    x_28        EDGE_28_46  1.0
    x_28        EDGE_9_28  1.0
    x_28        EDGE_28_106  1.0
    x_28        EDGE_15_28  1.0
    x_28        EDGE_28_50  1.0
    x_28        EDGE_28_40  1.0
    x_28        EDGE_28_52  1.0
    x_28        EDGE_28_107  1.0
    x_28        EDGE_26_28  1.0
    x_28        EDGE_28_74  1.0
    x_28        EDGE_28_87  1.0
    x_28        EDGE_10_28  1.0
    x_28        EDGE_28_44  1.0
    x_28        EDGE_28_96  1.0
    x_28        EDGE_8_28  1.0
    x_28        EDGE_28_99  1.0
    x_28        EDGE_28_33  1.0
    x_28        EDGE_28_98  1.0
    x_28        EDGE_28_88  1.0
    x_28        EDGE_28_65  1.0
    x_28        EDGE_28_101  1.0
    x_28        EDGE_18_28  1.0
    x_28        EDGE_28_68  1.0
    x_28        EDGE_28_35  1.0
    x_28        EDGE_0_28  1.0
    x_29        OBJ       -41
    x_29        EDGE_29_32  1.0
    x_29        EDGE_29_68  1.0
    x_29        EDGE_29_90  1.0
    x_29        EDGE_29_47  1.0
    x_29        EDGE_29_37  1.0
    x_29        EDGE_29_46  1.0
    x_29        EDGE_3_29  1.0
    x_29        EDGE_29_59  1.0
    x_29        EDGE_6_29  1.0
    x_29        EDGE_17_29  1.0
    x_29        EDGE_29_91  1.0
    x_29        EDGE_29_58  1.0
    x_29        EDGE_29_61  1.0
    x_29        EDGE_29_103  1.0
    x_29        EDGE_29_83  1.0
    x_29        EDGE_29_73  1.0
    x_29        EDGE_29_50  1.0
    x_29        EDGE_29_30  1.0
    x_29        EDGE_29_72  1.0
    x_29        EDGE_29_75  1.0
    x_29        EDGE_13_29  1.0
    x_29        EDGE_29_107  1.0
    x_29        EDGE_4_29  1.0
    x_29        EDGE_26_29  1.0
    x_29        EDGE_29_89  1.0
    x_29        EDGE_27_29  1.0
    x_29        EDGE_29_101  1.0
    x_29        EDGE_29_55  1.0
    x_30        OBJ       -4
    x_30        EDGE_30_102  1.0
    x_30        EDGE_5_30  1.0
    x_30        EDGE_16_30  1.0
    x_30        EDGE_17_30  1.0
    x_30        EDGE_30_93  1.0
    x_30        EDGE_30_106  1.0
    x_30        EDGE_30_60  1.0
    x_30        EDGE_14_30  1.0
    x_30        EDGE_15_30  1.0
    x_30        EDGE_30_107  1.0
    x_30        EDGE_29_30  1.0
    x_30        EDGE_30_77  1.0
    x_30        EDGE_30_44  1.0
    x_30        EDGE_30_109  1.0
    x_30        EDGE_30_99  1.0
    x_30        EDGE_30_53  1.0
    x_30        EDGE_30_66  1.0
    x_30        EDGE_30_98  1.0
    x_30        EDGE_10_30  1.0
    x_30        EDGE_21_30  1.0
    x_30        EDGE_30_78  1.0
    x_31        OBJ       -3
    x_31        EDGE_31_103  1.0
    x_31        EDGE_31_80  1.0
    x_31        EDGE_31_57  1.0
    x_31        EDGE_31_34  1.0
    x_31        EDGE_31_70  1.0
    x_31        EDGE_24_31  1.0
    x_31        EDGE_31_47  1.0
    x_31        EDGE_31_37  1.0
    x_31        EDGE_8_31  1.0
    x_31        EDGE_31_102  1.0
    x_31        EDGE_18_31  1.0
    x_31        EDGE_31_91  1.0
    x_31        EDGE_31_94  1.0
    x_31        EDGE_31_61  1.0
    x_31        EDGE_16_31  1.0
    x_31        EDGE_0_31  1.0
    x_31        EDGE_31_60  1.0
    x_31        EDGE_31_63  1.0
    x_31        EDGE_31_105  1.0
    x_31        EDGE_31_72  1.0
    x_31        EDGE_31_32  1.0
    x_31        EDGE_31_86  1.0
    x_31        EDGE_31_99  1.0
    x_31        EDGE_31_89  1.0
    x_31        EDGE_31_43  1.0
    x_31        EDGE_31_98  1.0
    x_31        EDGE_31_88  1.0
    x_31        EDGE_31_58  1.0
    x_32        OBJ       -4
    x_32        EDGE_29_32  1.0
    x_32        EDGE_32_91  1.0
    x_32        EDGE_32_68  1.0
    x_32        EDGE_13_32  1.0
    x_32        EDGE_32_45  1.0
    x_32        EDGE_32_35  1.0
    x_32        EDGE_32_57  1.0
    x_32        EDGE_4_32  1.0
    x_32        EDGE_32_81  1.0
    x_32        EDGE_32_84  1.0
    x_32        EDGE_32_38  1.0
    x_32        EDGE_32_51  1.0
    x_32        EDGE_18_32  1.0
    x_32        EDGE_14_32  1.0
    x_32        EDGE_32_63  1.0
    x_32        EDGE_32_40  1.0
    x_32        EDGE_0_32  1.0
    x_32        EDGE_31_32  1.0
    x_32        EDGE_15_32  1.0
    x_32        EDGE_17_32  1.0
    x_32        EDGE_32_52  1.0
    x_32        EDGE_32_99  1.0
    x_32        EDGE_32_56  1.0
    x_32        EDGE_32_33  1.0
    x_32        EDGE_32_98  1.0
    x_32        EDGE_27_32  1.0
    x_32        EDGE_32_88  1.0
    x_33        OBJ       -84
    x_33        EDGE_33_70  1.0
    x_33        EDGE_33_106  1.0
    x_33        EDGE_23_33  1.0
    x_33        EDGE_33_83  1.0
    x_33        EDGE_33_73  1.0
    x_33        EDGE_33_63  1.0
    x_33        EDGE_10_33  1.0
    x_33        EDGE_24_33  1.0
    x_33        EDGE_33_75  1.0
    x_33        EDGE_33_74  1.0
    x_33        EDGE_18_33  1.0
    x_33        EDGE_2_33  1.0
    x_33        EDGE_0_33  1.0
    x_33        EDGE_33_43  1.0
    x_33        EDGE_33_88  1.0
    x_33        EDGE_33_55  1.0
    x_33        EDGE_33_80  1.0
    x_33        EDGE_33_34  1.0
    x_33        EDGE_33_37  1.0
    x_33        EDGE_28_33  1.0
    x_33        EDGE_1_33  1.0
    x_33        EDGE_12_33  1.0
    x_33        EDGE_33_92  1.0
    x_33        EDGE_32_33  1.0
    x_33        EDGE_33_91  1.0
    x_33        EDGE_13_33  1.0
    x_33        EDGE_33_104  1.0
    x_33        EDGE_33_81  1.0
    x_33        EDGE_33_61  1.0
    x_34        OBJ       -70
    x_34        EDGE_25_34  1.0
    x_34        EDGE_9_34  1.0
    x_34        EDGE_31_34  1.0
    x_34        EDGE_34_61  1.0
    x_34        EDGE_34_93  1.0
    x_34        EDGE_34_106  1.0
    x_34        EDGE_34_63  1.0
    x_34        EDGE_34_40  1.0
    x_34        EDGE_34_105  1.0
    x_34        EDGE_34_72  1.0
    x_34        EDGE_34_85  1.0
    x_34        EDGE_34_75  1.0
    x_34        EDGE_10_34  1.0
    x_34        EDGE_21_34  1.0
    x_34        EDGE_34_107  1.0
    x_34        EDGE_34_84  1.0
    x_34        EDGE_34_97  1.0
    x_34        EDGE_34_74  1.0
    x_34        EDGE_8_34  1.0
    x_34        EDGE_34_64  1.0
    x_34        EDGE_34_54  1.0
    x_34        EDGE_34_109  1.0
    x_34        EDGE_34_53  1.0
    x_34        EDGE_34_66  1.0
    x_34        EDGE_34_43  1.0
    x_34        EDGE_34_56  1.0
    x_34        EDGE_2_34  1.0
    x_34        EDGE_5_34  1.0
    x_34        EDGE_19_34  1.0
    x_34        EDGE_22_34  1.0
    x_34        EDGE_33_34  1.0
    x_34        EDGE_20_34  1.0
    x_34        EDGE_34_90  1.0
    x_34        EDGE_34_80  1.0
    x_34        EDGE_34_57  1.0
    x_34        EDGE_34_47  1.0
    x_34        EDGE_34_102  1.0
    x_34        EDGE_11_34  1.0
    x_34        EDGE_34_59  1.0
    x_34        EDGE_34_36  1.0
    x_35        OBJ       -2
    x_35        EDGE_35_63  1.0
    x_35        EDGE_32_35  1.0
    x_35        EDGE_13_35  1.0
    x_35        EDGE_35_95  1.0
    x_35        EDGE_35_85  1.0
    x_35        EDGE_35_75  1.0
    x_35        EDGE_4_35  1.0
    x_35        EDGE_35_107  1.0
    x_35        EDGE_26_35  1.0
    x_35        EDGE_35_87  1.0
    x_35        EDGE_10_35  1.0
    x_35        EDGE_27_35  1.0
    x_35        EDGE_8_35  1.0
    x_35        EDGE_35_89  1.0
    x_35        EDGE_35_65  1.0
    x_35        EDGE_35_55  1.0
    x_35        EDGE_35_58  1.0
    x_35        EDGE_22_35  1.0
    x_35        EDGE_35_90  1.0
    x_35        EDGE_35_103  1.0
    x_35        EDGE_35_57  1.0
    x_35        EDGE_17_35  1.0
    x_35        EDGE_35_79  1.0
    x_35        EDGE_35_94  1.0
    x_35        EDGE_35_61  1.0
    x_35        EDGE_28_35  1.0
    x_35        EDGE_12_35  1.0
    x_36        OBJ       -49
    x_36        EDGE_36_48  1.0
    x_36        EDGE_36_61  1.0
    x_36        EDGE_11_36  1.0
    x_36        EDGE_36_106  1.0
    x_36        EDGE_36_60  1.0
    x_36        EDGE_25_36  1.0
    x_36        EDGE_36_40  1.0
    x_36        EDGE_9_36  1.0
    x_36        EDGE_1_36  1.0
    x_36        EDGE_36_105  1.0
    x_36        EDGE_36_72  1.0
    x_36        EDGE_36_108  1.0
    x_36        EDGE_36_52  1.0
    x_36        EDGE_36_97  1.0
    x_36        EDGE_26_36  1.0
    x_36        EDGE_7_36  1.0
    x_36        EDGE_36_89  1.0
    x_36        EDGE_36_43  1.0
    x_36        EDGE_36_56  1.0
    x_36        EDGE_36_98  1.0
    x_36        EDGE_36_101  1.0
    x_36        EDGE_36_55  1.0
    x_36        EDGE_36_58  1.0
    x_36        EDGE_18_36  1.0
    x_36        EDGE_36_80  1.0
    x_36        EDGE_36_70  1.0
    x_36        EDGE_36_37  1.0
    x_36        EDGE_16_36  1.0
    x_36        EDGE_19_36  1.0
    x_36        EDGE_0_36  1.0
    x_36        EDGE_22_36  1.0
    x_36        EDGE_36_49  1.0
    x_36        EDGE_20_36  1.0
    x_36        EDGE_34_36  1.0
    x_37        OBJ       -88
    x_37        EDGE_1_37  1.0
    x_37        EDGE_31_37  1.0
    x_37        EDGE_37_108  1.0
    x_37        EDGE_29_37  1.0
    x_37        EDGE_37_98  1.0
    x_37        EDGE_37_88  1.0
    x_37        EDGE_37_101  1.0
    x_37        EDGE_37_68  1.0
    x_37        EDGE_37_45  1.0
    x_37        EDGE_37_100  1.0
    x_37        EDGE_37_44  1.0
    x_37        EDGE_37_80  1.0
    x_37        EDGE_23_37  1.0
    x_37        EDGE_37_89  1.0
    x_37        EDGE_37_49  1.0
    x_37        EDGE_37_48  1.0
    x_37        EDGE_18_37  1.0
    x_37        EDGE_4_37  1.0
    x_37        EDGE_37_70  1.0
    x_37        EDGE_37_106  1.0
    x_37        EDGE_37_40  1.0
    x_37        EDGE_22_37  1.0
    x_37        EDGE_3_37  1.0
    x_37        EDGE_33_37  1.0
    x_37        EDGE_36_37  1.0
    x_37        EDGE_37_72  1.0
    x_37        EDGE_37_39  1.0
    x_37        EDGE_37_75  1.0
    x_37        EDGE_37_84  1.0
    x_37        EDGE_37_74  1.0
    x_37        EDGE_37_64  1.0
    x_37        EDGE_37_54  1.0
    x_38        OBJ       -28
    x_38        EDGE_38_97  1.0
    x_38        EDGE_38_54  1.0
    x_38        EDGE_38_96  1.0
    x_38        EDGE_38_66  1.0
    x_38        EDGE_38_101  1.0
    x_38        EDGE_38_55  1.0
    x_38        EDGE_15_38  1.0
    x_38        EDGE_32_38  1.0
    x_38        EDGE_38_44  1.0
    x_38        EDGE_38_92  1.0
    x_38        EDGE_38_59  1.0
    x_38        EDGE_38_49  1.0
    x_38        EDGE_38_81  1.0
    x_38        EDGE_38_71  1.0
    x_38        EDGE_38_70  1.0
    x_38        EDGE_38_83  1.0
    x_38        EDGE_38_63  1.0
    x_38        EDGE_38_40  1.0
    x_38        EDGE_38_72  1.0
    x_38        EDGE_16_38  1.0
    x_38        EDGE_38_75  1.0
    x_38        EDGE_38_52  1.0
    x_38        EDGE_19_38  1.0
    x_39        OBJ       -55
    x_39        EDGE_39_94  1.0
    x_39        EDGE_39_61  1.0
    x_39        EDGE_39_41  1.0
    x_39        EDGE_39_73  1.0
    x_39        EDGE_39_50  1.0
    x_39        EDGE_39_86  1.0
    x_39        EDGE_16_39  1.0
    x_39        EDGE_39_40  1.0
    x_39        EDGE_39_53  1.0
    x_39        EDGE_3_39  1.0
    x_39        EDGE_15_39  1.0
    x_39        EDGE_39_85  1.0
    x_39        EDGE_17_39  1.0
    x_39        EDGE_39_75  1.0
    x_39        EDGE_39_42  1.0
    x_39        EDGE_39_87  1.0
    x_39        EDGE_39_77  1.0
    x_39        EDGE_39_54  1.0
    x_39        EDGE_11_39  1.0
    x_39        EDGE_26_39  1.0
    x_39        EDGE_9_39  1.0
    x_39        EDGE_10_39  1.0
    x_39        EDGE_39_56  1.0
    x_39        EDGE_39_46  1.0
    x_39        EDGE_39_91  1.0
    x_39        EDGE_39_68  1.0
    x_39        EDGE_39_45  1.0
    x_39        EDGE_39_103  1.0
    x_39        EDGE_4_39  1.0
    x_39        EDGE_7_39  1.0
    x_39        EDGE_37_39  1.0
    x_39        EDGE_39_102  1.0
    x_39        EDGE_39_69  1.0
    x_39        EDGE_39_82  1.0
    x_39        EDGE_6_39  1.0
    x_39        EDGE_39_49  1.0
    x_40        OBJ       -93
    x_40        EDGE_40_41  1.0
    x_40        EDGE_40_54  1.0
    x_40        EDGE_5_40  1.0
    x_40        EDGE_40_86  1.0
    x_40        EDGE_40_99  1.0
    x_40        EDGE_0_40  1.0
    x_40        EDGE_40_56  1.0
    x_40        EDGE_36_40  1.0
    x_40        EDGE_17_40  1.0
    x_40        EDGE_39_40  1.0
    x_40        EDGE_40_98  1.0
    x_40        EDGE_20_40  1.0
    x_40        EDGE_40_65  1.0
    x_40        EDGE_34_40  1.0
    x_40        EDGE_40_100  1.0
    x_40        EDGE_40_90  1.0
    x_40        EDGE_28_40  1.0
    x_40        EDGE_1_40  1.0
    x_40        EDGE_40_92  1.0
    x_40        EDGE_40_82  1.0
    x_40        EDGE_40_49  1.0
    x_40        EDGE_32_40  1.0
    x_40        EDGE_40_94  1.0
    x_40        EDGE_40_106  1.0
    x_40        EDGE_4_40  1.0
    x_40        EDGE_26_40  1.0
    x_40        EDGE_40_60  1.0
    x_40        EDGE_40_73  1.0
    x_40        EDGE_37_40  1.0
    x_40        EDGE_40_63  1.0
    x_40        EDGE_40_105  1.0
    x_40        EDGE_40_108  1.0
    x_40        EDGE_38_40  1.0
    x_40        EDGE_40_75  1.0
    x_41        OBJ       -4
    x_41        EDGE_40_41  1.0
    x_41        EDGE_21_41  1.0
    x_41        EDGE_39_41  1.0
    x_41        EDGE_41_64  1.0
    x_41        EDGE_41_99  1.0
    x_41        EDGE_41_76  1.0
    x_41        EDGE_41_66  1.0
    x_41        EDGE_41_43  1.0
    x_41        EDGE_41_78  1.0
    x_41        EDGE_6_41  1.0
    x_41        EDGE_41_70  1.0
    x_41        EDGE_41_47  1.0
    x_41        EDGE_41_102  1.0
    x_41        EDGE_41_79  1.0
    x_41        EDGE_41_92  1.0
    x_41        EDGE_41_59  1.0
    x_41        EDGE_25_41  1.0
    x_41        EDGE_41_94  1.0
    x_41        EDGE_41_48  1.0
    x_41        EDGE_13_41  1.0
    x_41        EDGE_41_83  1.0
    x_41        EDGE_41_50  1.0
    x_42        OBJ       -68
    x_42        EDGE_42_100  1.0
    x_42        EDGE_42_90  1.0
    x_42        EDGE_42_92  1.0
    x_42        EDGE_4_42  1.0
    x_42        EDGE_42_46  1.0
    x_42        EDGE_22_42  1.0
    x_42        EDGE_42_91  1.0
    x_42        EDGE_6_42  1.0
    x_42        EDGE_17_42  1.0
    x_42        EDGE_42_48  1.0
    x_42        EDGE_39_42  1.0
    x_42        EDGE_20_42  1.0
    x_42        EDGE_42_83  1.0
    x_42        EDGE_42_73  1.0
    x_42        EDGE_42_50  1.0
    x_42        EDGE_25_42  1.0
    x_42        EDGE_12_42  1.0
    x_42        EDGE_42_84  1.0
    x_42        EDGE_42_96  1.0
    x_42        EDGE_42_63  1.0
    x_42        EDGE_42_56  1.0
    x_42        EDGE_42_108  1.0
    x_42        EDGE_7_42  1.0
    x_42        EDGE_42_88  1.0
    x_42        EDGE_42_65  1.0
    x_42        EDGE_21_42  1.0
    x_42        EDGE_42_45  1.0
    x_43        OBJ       -29
    x_43        EDGE_43_77  1.0
    x_43        EDGE_26_43  1.0
    x_43        EDGE_43_86  1.0
    x_43        EDGE_24_43  1.0
    x_43        EDGE_43_46  1.0
    x_43        EDGE_27_43  1.0
    x_43        EDGE_41_43  1.0
    x_43        EDGE_43_55  1.0
    x_43        EDGE_43_91  1.0
    x_43        EDGE_43_68  1.0
    x_43        EDGE_43_100  1.0
    x_43        EDGE_2_43  1.0
    x_43        EDGE_43_47  1.0
    x_43        EDGE_16_43  1.0
    x_43        EDGE_0_43  1.0
    x_43        EDGE_43_102  1.0
    x_43        EDGE_3_43  1.0
    x_43        EDGE_33_43  1.0
    x_43        EDGE_43_92  1.0
    x_43        EDGE_43_69  1.0
    x_43        EDGE_36_43  1.0
    x_43        EDGE_34_43  1.0
    x_43        EDGE_43_81  1.0
    x_43        EDGE_43_71  1.0
    x_43        EDGE_43_83  1.0
    x_43        EDGE_43_96  1.0
    x_43        EDGE_43_63  1.0
    x_43        EDGE_1_43  1.0
    x_43        EDGE_31_43  1.0
    x_43        EDGE_12_43  1.0
    x_43        EDGE_43_107  1.0
    x_44        OBJ       -98
    x_44        EDGE_44_48  1.0
    x_44        EDGE_44_93  1.0
    x_44        EDGE_37_44  1.0
    x_44        EDGE_44_73  1.0
    x_44        EDGE_6_44  1.0
    x_44        EDGE_38_44  1.0
    x_44        EDGE_44_72  1.0
    x_44        EDGE_44_108  1.0
    x_44        EDGE_44_75  1.0
    x_44        EDGE_44_52  1.0
    x_44        EDGE_30_44  1.0
    x_44        EDGE_44_64  1.0
    x_44        EDGE_28_44  1.0
    x_44        EDGE_44_86  1.0
    x_44        EDGE_1_44  1.0
    x_44        EDGE_44_99  1.0
    x_44        EDGE_44_56  1.0
    x_44        EDGE_44_98  1.0
    x_44        EDGE_13_44  1.0
    x_44        EDGE_44_67  1.0
    x_44        EDGE_44_70  1.0
    x_45        OBJ       -57
    x_45        EDGE_32_45  1.0
    x_45        EDGE_13_45  1.0
    x_45        EDGE_45_90  1.0
    x_45        EDGE_45_102  1.0
    x_45        EDGE_45_92  1.0
    x_45        EDGE_45_69  1.0
    x_45        EDGE_26_45  1.0
    x_45        EDGE_45_49  1.0
    x_45        EDGE_37_45  1.0
    x_45        EDGE_45_91  1.0
    x_45        EDGE_45_104  1.0
    x_45        EDGE_45_71  1.0
    x_45        EDGE_45_48  1.0
    x_45        EDGE_45_51  1.0
    x_45        EDGE_45_50  1.0
    x_45        EDGE_2_45  1.0
    x_45        EDGE_45_75  1.0
    x_45        EDGE_45_52  1.0
    x_45        EDGE_22_45  1.0
    x_45        EDGE_45_107  1.0
    x_45        EDGE_39_45  1.0
    x_45        EDGE_45_74  1.0
    x_45        EDGE_45_87  1.0
    x_45        EDGE_45_77  1.0
    x_45        EDGE_45_109  1.0
    x_45        EDGE_45_86  1.0
    x_45        EDGE_45_99  1.0
    x_45        EDGE_14_45  1.0
    x_45        EDGE_25_45  1.0
    x_45        EDGE_1_45  1.0
    x_45        EDGE_42_45  1.0
    x_45        EDGE_45_55  1.0
    x_45        EDGE_45_68  1.0
    x_45        EDGE_15_45  1.0
    x_46        OBJ       -64
    x_46        EDGE_46_88  1.0
    x_46        EDGE_14_46  1.0
    x_46        EDGE_26_46  1.0
    x_46        EDGE_28_46  1.0
    x_46        EDGE_46_80  1.0
    x_46        EDGE_42_46  1.0
    x_46        EDGE_43_46  1.0
    x_46        EDGE_15_46  1.0
    x_46        EDGE_29_46  1.0
    x_46        EDGE_13_46  1.0
    x_46        EDGE_46_69  1.0
    x_46        EDGE_4_46  1.0
    x_46        EDGE_46_61  1.0
    x_46        EDGE_6_46  1.0
    x_46        EDGE_46_73  1.0
    x_46        EDGE_46_50  1.0
    x_46        EDGE_39_46  1.0
    x_46        EDGE_46_85  1.0
    x_46        EDGE_46_65  1.0
    x_46        EDGE_2_46  1.0
    x_46        EDGE_19_46  1.0
    x_46        EDGE_46_99  1.0
    x_46        EDGE_20_46  1.0
    x_46        EDGE_46_89  1.0
    x_46        EDGE_46_56  1.0
    x_47        OBJ       -71
    x_47        EDGE_47_80  1.0
    x_47        EDGE_28_47  1.0
    x_47        EDGE_1_47  1.0
    x_47        EDGE_31_47  1.0
    x_47        EDGE_15_47  1.0
    x_47        EDGE_47_79  1.0
    x_47        EDGE_29_47  1.0
    x_47        EDGE_47_84  1.0
    x_47        EDGE_47_50  1.0
    x_47        EDGE_43_47  1.0
    x_47        EDGE_47_95  1.0
    x_47        EDGE_41_47  1.0
    x_47        EDGE_47_77  1.0
    x_47        EDGE_5_47  1.0
    x_47        EDGE_47_109  1.0
    x_47        EDGE_47_99  1.0
    x_47        EDGE_20_47  1.0
    x_47        EDGE_34_47  1.0
    x_47        EDGE_47_78  1.0
    x_48        OBJ       -30
    x_48        EDGE_36_48  1.0
    x_48        EDGE_48_58  1.0
    x_48        EDGE_48_90  1.0
    x_48        EDGE_11_48  1.0
    x_48        EDGE_14_48  1.0
    x_48        EDGE_44_48  1.0
    x_48        EDGE_48_59  1.0
    x_48        EDGE_25_48  1.0
    x_48        EDGE_9_48  1.0
    x_48        EDGE_42_48  1.0
    x_48        EDGE_48_81  1.0
    x_48        EDGE_45_48  1.0
    x_48        EDGE_48_94  1.0
    x_48        EDGE_48_51  1.0
    x_48        EDGE_48_106  1.0
    x_48        EDGE_48_83  1.0
    x_48        EDGE_48_73  1.0
    x_48        EDGE_48_53  1.0
    x_48        EDGE_23_48  1.0
    x_48        EDGE_37_48  1.0
    x_48        EDGE_48_62  1.0
    x_48        EDGE_48_52  1.0
    x_48        EDGE_24_48  1.0
    x_48        EDGE_48_107  1.0
    x_48        EDGE_48_74  1.0
    x_48        EDGE_41_48  1.0
    x_48        EDGE_48_64  1.0
    x_48        EDGE_48_54  1.0
    x_48        EDGE_48_86  1.0
    x_48        EDGE_48_66  1.0
    x_48        EDGE_2_48  1.0
    x_48        EDGE_5_48  1.0
    x_48        EDGE_16_48  1.0
    x_48        EDGE_48_88  1.0
    x_49        OBJ       -45
    x_49        EDGE_49_83  1.0
    x_49        EDGE_49_73  1.0
    x_49        EDGE_49_105  1.0
    x_49        EDGE_49_72  1.0
    x_49        EDGE_45_49  1.0
    x_49        EDGE_49_84  1.0
    x_49        EDGE_49_109  1.0
    x_49        EDGE_49_89  1.0
    x_49        EDGE_23_49  1.0
    x_49        EDGE_49_56  1.0
    x_49        EDGE_37_49  1.0
    x_49        EDGE_40_49  1.0
    x_49        EDGE_21_49  1.0
    x_49        EDGE_49_101  1.0
    x_49        EDGE_38_49  1.0
    x_49        EDGE_2_49  1.0
    x_49        EDGE_49_59  1.0
    x_49        EDGE_36_49  1.0
    x_49        EDGE_49_94  1.0
    x_49        EDGE_39_49  1.0
    x_50        OBJ       -30
    x_50        EDGE_50_94  1.0
    x_50        EDGE_50_61  1.0
    x_50        EDGE_19_50  1.0
    x_50        EDGE_50_103  1.0
    x_50        EDGE_6_50  1.0
    x_50        EDGE_50_93  1.0
    x_50        EDGE_39_50  1.0
    x_50        EDGE_50_105  1.0
    x_50        EDGE_50_62  1.0
    x_50        EDGE_50_52  1.0
    x_50        EDGE_14_50  1.0
    x_50        EDGE_50_107  1.0
    x_50        EDGE_50_84  1.0
    x_50        EDGE_47_50  1.0
    x_50        EDGE_28_50  1.0
    x_50        EDGE_42_50  1.0
    x_50        EDGE_45_50  1.0
    x_50        EDGE_29_50  1.0
    x_50        EDGE_50_89  1.0
    x_50        EDGE_46_50  1.0
    x_50        EDGE_50_98  1.0
    x_50        EDGE_50_68  1.0
    x_50        EDGE_50_67  1.0
    x_50        EDGE_41_50  1.0
    x_50        EDGE_50_102  1.0
    x_50        EDGE_50_79  1.0
    x_50        EDGE_50_69  1.0
    x_50        EDGE_50_82  1.0
    x_50        EDGE_50_59  1.0
    x_51        OBJ       -87
    x_51        EDGE_6_51  1.0
    x_51        EDGE_51_90  1.0
    x_51        EDGE_51_70  1.0
    x_51        EDGE_51_60  1.0
    x_51        EDGE_18_51  1.0
    x_51        EDGE_14_51  1.0
    x_51        EDGE_1_51  1.0
    x_51        EDGE_45_51  1.0
    x_51        EDGE_51_94  1.0
    x_51        EDGE_17_51  1.0
    x_51        EDGE_51_84  1.0
    x_51        EDGE_48_51  1.0
    x_51        EDGE_32_51  1.0
    x_51        EDGE_51_83  1.0
    x_51        EDGE_51_96  1.0
    x_51        EDGE_51_63  1.0
    x_51        EDGE_25_51  1.0
    x_51        EDGE_26_51  1.0
    x_51        EDGE_51_75  1.0
    x_51        EDGE_51_52  1.0
    x_51        EDGE_51_64  1.0
    x_51        EDGE_51_89  1.0
    x_51        EDGE_51_79  1.0
    x_51        EDGE_5_51  1.0
    x_51        EDGE_21_51  1.0
    x_52        OBJ       -29
    x_52        EDGE_52_83  1.0
    x_52        EDGE_52_60  1.0
    x_52        EDGE_52_96  1.0
    x_52        EDGE_18_52  1.0
    x_52        EDGE_2_52  1.0
    x_52        EDGE_52_105  1.0
    x_52        EDGE_19_52  1.0
    x_52        EDGE_52_85  1.0
    x_52        EDGE_52_62  1.0
    x_52        EDGE_52_75  1.0
    x_52        EDGE_36_52  1.0
    x_52        EDGE_20_52  1.0
    x_52        EDGE_50_52  1.0
    x_52        EDGE_52_74  1.0
    x_52        EDGE_52_64  1.0
    x_52        EDGE_52_86  1.0
    x_52        EDGE_52_89  1.0
    x_52        EDGE_52_66  1.0
    x_52        EDGE_44_52  1.0
    x_52        EDGE_25_52  1.0
    x_52        EDGE_28_52  1.0
    x_52        EDGE_9_52  1.0
    x_52        EDGE_52_98  1.0
    x_52        EDGE_52_88  1.0
    x_52        EDGE_45_52  1.0
    x_52        EDGE_48_52  1.0
    x_52        EDGE_52_58  1.0
    x_52        EDGE_51_52  1.0
    x_52        EDGE_32_52  1.0
    x_52        EDGE_52_69  1.0
    x_52        EDGE_7_52  1.0
    x_52        EDGE_52_81  1.0
    x_52        EDGE_38_52  1.0
    x_52        EDGE_52_84  1.0
    x_53        OBJ       -98
    x_53        EDGE_53_81  1.0
    x_53        EDGE_26_53  1.0
    x_53        EDGE_53_84  1.0
    x_53        EDGE_24_53  1.0
    x_53        EDGE_53_96  1.0
    x_53        EDGE_39_53  1.0
    x_53        EDGE_53_73  1.0
    x_53        EDGE_53_98  1.0
    x_53        EDGE_53_65  1.0
    x_53        EDGE_2_53  1.0
    x_53        EDGE_53_77  1.0
    x_53        EDGE_3_53  1.0
    x_53        EDGE_6_53  1.0
    x_53        EDGE_48_53  1.0
    x_53        EDGE_53_99  1.0
    x_53        EDGE_53_76  1.0
    x_53        EDGE_53_89  1.0
    x_53        EDGE_34_53  1.0
    x_53        EDGE_53_79  1.0
    x_53        EDGE_30_53  1.0
    x_53        EDGE_53_78  1.0
    x_53        EDGE_53_55  1.0
    x_53        EDGE_25_53  1.0
    x_53        EDGE_53_100  1.0
    x_53        EDGE_53_90  1.0
    x_53        EDGE_53_72  1.0
    x_54        OBJ       -59
    x_54        EDGE_40_54  1.0
    x_54        EDGE_54_74  1.0
    x_54        EDGE_54_87  1.0
    x_54        EDGE_38_54  1.0
    x_54        EDGE_54_109  1.0
    x_54        EDGE_54_86  1.0
    x_54        EDGE_18_54  1.0
    x_54        EDGE_54_98  1.0
    x_54        EDGE_2_54  1.0
    x_54        EDGE_39_54  1.0
    x_54        EDGE_54_70  1.0
    x_54        EDGE_34_54  1.0
    x_54        EDGE_54_82  1.0
    x_54        EDGE_54_81  1.0
    x_54        EDGE_54_71  1.0
    x_54        EDGE_15_54  1.0
    x_54        EDGE_48_54  1.0
    x_54        EDGE_54_83  1.0
    x_54        EDGE_54_60  1.0
    x_54        EDGE_54_63  1.0
    x_54        EDGE_54_105  1.0
    x_54        EDGE_54_108  1.0
    x_54        EDGE_54_85  1.0
    x_54        EDGE_26_54  1.0
    x_54        EDGE_37_54  1.0
    x_54        EDGE_54_84  1.0
    x_55        OBJ       -38
    x_55        EDGE_55_61  1.0
    x_55        EDGE_55_83  1.0
    x_55        EDGE_55_96  1.0
    x_55        EDGE_55_73  1.0
    x_55        EDGE_55_86  1.0
    x_55        EDGE_55_95  1.0
    x_55        EDGE_55_98  1.0
    x_55        EDGE_43_55  1.0
    x_55        EDGE_8_55  1.0
    x_55        EDGE_38_55  1.0
    x_55        EDGE_55_107  1.0
    x_55        EDGE_55_97  1.0
    x_55        EDGE_18_55  1.0
    x_55        EDGE_55_99  1.0
    x_55        EDGE_55_79  1.0
    x_55        EDGE_35_55  1.0
    x_55        EDGE_22_55  1.0
    x_55        EDGE_33_55  1.0
    x_55        EDGE_55_78  1.0
    x_55        EDGE_55_91  1.0
    x_55        EDGE_6_55  1.0
    x_55        EDGE_36_55  1.0
    x_55        EDGE_55_68  1.0
    x_55        EDGE_53_55  1.0
    x_55        EDGE_55_100  1.0
    x_55        EDGE_55_80  1.0
    x_55        EDGE_55_57  1.0
    x_55        EDGE_55_60  1.0
    x_55        EDGE_55_92  1.0
    x_55        EDGE_55_59  1.0
    x_55        EDGE_55_72  1.0
    x_55        EDGE_1_55  1.0
    x_55        EDGE_45_55  1.0
    x_55        EDGE_29_55  1.0
    x_56        OBJ       -3
    x_56        EDGE_56_86  1.0
    x_56        EDGE_56_76  1.0
    x_56        EDGE_7_56  1.0
    x_56        EDGE_40_56  1.0
    x_56        EDGE_56_100  1.0
    x_56        EDGE_56_90  1.0
    x_56        EDGE_56_70  1.0
    x_56        EDGE_18_56  1.0
    x_56        EDGE_2_56  1.0
    x_56        EDGE_56_92  1.0
    x_56        EDGE_56_69  1.0
    x_56        EDGE_56_82  1.0
    x_56        EDGE_56_59  1.0
    x_56        EDGE_49_56  1.0
    x_56        EDGE_21_56  1.0
    x_56        EDGE_6_56  1.0
    x_56        EDGE_36_56  1.0
    x_56        EDGE_17_56  1.0
    x_56        EDGE_56_104  1.0
    x_56        EDGE_39_56  1.0
    x_56        EDGE_56_61  1.0
    x_56        EDGE_34_56  1.0
    x_56        EDGE_56_83  1.0
    x_56        EDGE_44_56  1.0
    x_56        EDGE_12_56  1.0
    x_56        EDGE_42_56  1.0
    x_56        EDGE_32_56  1.0
    x_56        EDGE_56_74  1.0
    x_56        EDGE_56_87  1.0
    x_56        EDGE_56_64  1.0
    x_56        EDGE_46_56  1.0
    x_57        OBJ       -54
    x_57        EDGE_57_107  1.0
    x_57        EDGE_57_74  1.0
    x_57        EDGE_31_57  1.0
    x_57        EDGE_32_57  1.0
    x_57        EDGE_57_66  1.0
    x_57        EDGE_57_91  1.0
    x_57        EDGE_24_57  1.0
    x_57        EDGE_57_90  1.0
    x_57        EDGE_57_92  1.0
    x_57        EDGE_57_72  1.0
    x_57        EDGE_5_57  1.0
    x_57        EDGE_35_57  1.0
    x_57        EDGE_57_71  1.0
    x_57        EDGE_57_84  1.0
    x_57        EDGE_0_57  1.0
    x_57        EDGE_3_57  1.0
    x_57        EDGE_55_57  1.0
    x_57        EDGE_6_57  1.0
    x_57        EDGE_17_57  1.0
    x_57        EDGE_34_57  1.0
    x_57        EDGE_11_57  1.0
    x_58        OBJ       -72
    x_58        EDGE_48_58  1.0
    x_58        EDGE_58_85  1.0
    x_58        EDGE_58_107  1.0
    x_58        EDGE_58_74  1.0
    x_58        EDGE_14_58  1.0
    x_58        EDGE_26_58  1.0
    x_58        EDGE_58_79  1.0
    x_58        EDGE_27_58  1.0
    x_58        EDGE_29_58  1.0
    x_58        EDGE_58_100  1.0
    x_58        EDGE_58_90  1.0
    x_58        EDGE_23_58  1.0
    x_58        EDGE_35_58  1.0
    x_58        EDGE_52_58  1.0
    x_58        EDGE_36_58  1.0
    x_58        EDGE_20_58  1.0
    x_58        EDGE_58_104  1.0
    x_58        EDGE_58_61  1.0
    x_58        EDGE_18_58  1.0
    x_58        EDGE_58_83  1.0
    x_58        EDGE_0_58  1.0
    x_58        EDGE_31_58  1.0
    x_59        OBJ       -83
    x_59        EDGE_59_100  1.0
    x_59        EDGE_14_59  1.0
    x_59        EDGE_12_59  1.0
    x_59        EDGE_48_59  1.0
    x_59        EDGE_29_59  1.0
    x_59        EDGE_59_91  1.0
    x_59        EDGE_59_104  1.0
    x_59        EDGE_59_81  1.0
    x_59        EDGE_26_59  1.0
    x_59        EDGE_56_59  1.0
    x_59        EDGE_38_59  1.0
    x_59        EDGE_41_59  1.0
    x_59        EDGE_59_75  1.0
    x_59        EDGE_59_84  1.0
    x_59        EDGE_59_97  1.0
    x_59        EDGE_16_59  1.0
    x_59        EDGE_19_59  1.0
    x_59        EDGE_49_59  1.0
    x_59        EDGE_3_59  1.0
    x_59        EDGE_55_59  1.0
    x_59        EDGE_20_59  1.0
    x_59        EDGE_50_59  1.0
    x_59        EDGE_34_59  1.0
    x_59        EDGE_59_101  1.0
    x_59        EDGE_59_78  1.0
    x_60        OBJ       -13
    x_60        EDGE_60_107  1.0
    x_60        EDGE_60_64  1.0
    x_60        EDGE_52_60  1.0
    x_60        EDGE_3_60  1.0
    x_60        EDGE_60_77  1.0
    x_60        EDGE_36_60  1.0
    x_60        EDGE_60_109  1.0
    x_60        EDGE_51_60  1.0
    x_60        EDGE_30_60  1.0
    x_60        EDGE_11_60  1.0
    x_60        EDGE_25_60  1.0
    x_60        EDGE_31_60  1.0
    x_60        EDGE_60_90  1.0
    x_60        EDGE_60_80  1.0
    x_60        EDGE_60_92  1.0
    x_60        EDGE_26_60  1.0
    x_60        EDGE_40_60  1.0
    x_60        EDGE_54_60  1.0
    x_60        EDGE_55_60  1.0
    x_60        EDGE_60_86  1.0
    x_60        EDGE_60_95  1.0
    x_60        EDGE_60_108  1.0
    x_61        OBJ       -24
    x_61        EDGE_55_61  1.0
    x_61        EDGE_36_61  1.0
    x_61        EDGE_61_67  1.0
    x_61        EDGE_61_103  1.0
    x_61        EDGE_39_61  1.0
    x_61        EDGE_50_61  1.0
    x_61        EDGE_61_70  1.0
    x_61        EDGE_34_61  1.0
    x_61        EDGE_61_102  1.0
    x_61        EDGE_61_91  1.0
    x_61        EDGE_61_104  1.0
    x_61        EDGE_61_94  1.0
    x_61        EDGE_1_61  1.0
    x_61        EDGE_31_61  1.0
    x_61        EDGE_29_61  1.0
    x_61        EDGE_61_83  1.0
    x_61        EDGE_13_61  1.0
    x_61        EDGE_46_61  1.0
    x_61        EDGE_61_75  1.0
    x_61        EDGE_26_61  1.0
    x_61        EDGE_56_61  1.0
    x_61        EDGE_10_61  1.0
    x_61        EDGE_61_87  1.0
    x_61        EDGE_61_109  1.0
    x_61        EDGE_61_86  1.0
    x_61        EDGE_61_99  1.0
    x_61        EDGE_58_61  1.0
    x_61        EDGE_61_66  1.0
    x_61        EDGE_61_88  1.0
    x_61        EDGE_35_61  1.0
    x_61        EDGE_16_61  1.0
    x_61        EDGE_61_68  1.0
    x_61        EDGE_0_61  1.0
    x_61        EDGE_33_61  1.0
    x_62        OBJ       -81
    x_62        EDGE_19_62  1.0
    x_62        EDGE_22_62  1.0
    x_62        EDGE_52_62  1.0
    x_62        EDGE_62_92  1.0
    x_62        EDGE_62_69  1.0
    x_62        EDGE_20_62  1.0
    x_62        EDGE_50_62  1.0
    x_62        EDGE_62_104  1.0
    x_62        EDGE_62_96  1.0
    x_62        EDGE_9_62  1.0
    x_62        EDGE_62_73  1.0
    x_62        EDGE_12_62  1.0
    x_62        EDGE_62_105  1.0
    x_62        EDGE_48_62  1.0
    x_62        EDGE_62_108  1.0
    x_62        EDGE_62_77  1.0
    x_62        EDGE_62_76  1.0
    x_62        EDGE_27_62  1.0
    x_63        OBJ       -93
    x_63        EDGE_4_63  1.0
    x_63        EDGE_5_63  1.0
    x_63        EDGE_35_63  1.0
    x_63        EDGE_63_70  1.0
    x_63        EDGE_63_83  1.0
    x_63        EDGE_21_63  1.0
    x_63        EDGE_33_63  1.0
    x_63        EDGE_63_95  1.0
    x_63        EDGE_34_63  1.0
    x_63        EDGE_63_107  1.0
    x_63        EDGE_31_63  1.0
    x_63        EDGE_51_63  1.0
    x_63        EDGE_32_63  1.0
    x_63        EDGE_13_63  1.0
    x_63        EDGE_63_88  1.0
    x_63        EDGE_25_63  1.0
    x_63        EDGE_26_63  1.0
    x_63        EDGE_63_80  1.0
    x_63        EDGE_10_63  1.0
    x_63        EDGE_40_63  1.0
    x_63        EDGE_42_63  1.0
    x_63        EDGE_43_63  1.0
    x_63        EDGE_54_63  1.0
    x_63        EDGE_38_63  1.0
    x_63        EDGE_63_92  1.0
    x_63        EDGE_63_81  1.0
    x_63        EDGE_63_94  1.0
    x_63        EDGE_18_63  1.0
    x_64        OBJ       -38
    x_64        EDGE_21_64  1.0
    x_64        EDGE_64_90  1.0
    x_64        EDGE_64_80  1.0
    x_64        EDGE_60_64  1.0
    x_64        EDGE_64_70  1.0
    x_64        EDGE_41_64  1.0
    x_64        EDGE_64_72  1.0
    x_64        EDGE_2_64  1.0
    x_64        EDGE_64_84  1.0
    x_64        EDGE_52_64  1.0
    x_64        EDGE_20_64  1.0
    x_64        EDGE_34_64  1.0
    x_64        EDGE_64_108  1.0
    x_64        EDGE_64_65  1.0
    x_64        EDGE_44_64  1.0
    x_64        EDGE_64_87  1.0
    x_64        EDGE_48_64  1.0
    x_64        EDGE_51_64  1.0
    x_64        EDGE_64_109  1.0
    x_64        EDGE_64_99  1.0
    x_64        EDGE_56_64  1.0
    x_64        EDGE_37_64  1.0
    x_64        EDGE_10_64  1.0
    x_65        OBJ       -16
    x_65        EDGE_65_101  1.0
    x_65        EDGE_65_78  1.0
    x_65        EDGE_65_91  1.0
    x_65        EDGE_65_68  1.0
    x_65        EDGE_65_90  1.0
    x_65        EDGE_4_65  1.0
    x_65        EDGE_40_65  1.0
    x_65        EDGE_22_65  1.0
    x_65        EDGE_65_82  1.0
    x_65        EDGE_53_65  1.0
    x_65        EDGE_18_65  1.0
    x_65        EDGE_5_65  1.0
    x_65        EDGE_35_65  1.0
    x_65        EDGE_65_96  1.0
    x_65        EDGE_65_73  1.0
    x_65        EDGE_64_65  1.0
    x_65        EDGE_65_108  1.0
    x_65        EDGE_65_98  1.0
    x_65        EDGE_46_65  1.0
    x_65        EDGE_65_74  1.0
    x_65        EDGE_65_77  1.0
    x_65        EDGE_26_65  1.0
    x_65        EDGE_28_65  1.0
    x_65        EDGE_65_99  1.0
    x_65        EDGE_42_65  1.0
    x_65        EDGE_65_89  1.0
    x_65        EDGE_65_66  1.0
    x_65        EDGE_27_65  1.0
    x_66        OBJ       -96
    x_66        EDGE_23_66  1.0
    x_66        EDGE_26_66  1.0
    x_66        EDGE_7_66  1.0
    x_66        EDGE_66_96  1.0
    x_66        EDGE_21_66  1.0
    x_66        EDGE_24_66  1.0
    x_66        EDGE_57_66  1.0
    x_66        EDGE_38_66  1.0
    x_66        EDGE_41_66  1.0
    x_66        EDGE_66_97  1.0
    x_66        EDGE_2_66  1.0
    x_66        EDGE_22_66  1.0
    x_66        EDGE_52_66  1.0
    x_66        EDGE_3_66  1.0
    x_66        EDGE_34_66  1.0
    x_66        EDGE_66_88  1.0
    x_66        EDGE_30_66  1.0
    x_66        EDGE_11_66  1.0
    x_66        EDGE_66_67  1.0
    x_66        EDGE_66_103  1.0
    x_66        EDGE_66_70  1.0
    x_66        EDGE_9_66  1.0
    x_66        EDGE_61_66  1.0
    x_66        EDGE_66_102  1.0
    x_66        EDGE_66_79  1.0
    x_66        EDGE_48_66  1.0
    x_66        EDGE_66_92  1.0
    x_66        EDGE_66_69  1.0
    x_66        EDGE_13_66  1.0
    x_66        EDGE_65_66  1.0
    x_66        EDGE_66_81  1.0
    x_67        OBJ       -43
    x_67        EDGE_9_67  1.0
    x_67        EDGE_61_67  1.0
    x_67        EDGE_67_104  1.0
    x_67        EDGE_67_71  1.0
    x_67        EDGE_67_84  1.0
    x_67        EDGE_13_67  1.0
    x_67        EDGE_67_105  1.0
    x_67        EDGE_67_95  1.0
    x_67        EDGE_67_85  1.0
    x_67        EDGE_67_109  1.0
    x_67        EDGE_2_67  1.0
    x_67        EDGE_67_89  1.0
    x_67        EDGE_22_67  1.0
    x_67        EDGE_3_67  1.0
    x_67        EDGE_6_67  1.0
    x_67        EDGE_66_67  1.0
    x_67        EDGE_67_68  1.0
    x_67        EDGE_20_67  1.0
    x_67        EDGE_50_67  1.0
    x_67        EDGE_67_90  1.0
    x_67        EDGE_67_70  1.0
    x_67        EDGE_67_102  1.0
    x_67        EDGE_14_67  1.0
    x_67        EDGE_67_79  1.0
    x_67        EDGE_44_67  1.0
    x_67        EDGE_67_92  1.0
    x_68        OBJ       -93
    x_68        EDGE_29_68  1.0
    x_68        EDGE_32_68  1.0
    x_68        EDGE_68_83  1.0
    x_68        EDGE_65_68  1.0
    x_68        EDGE_37_68  1.0
    x_68        EDGE_21_68  1.0
    x_68        EDGE_43_68  1.0
    x_68        EDGE_68_78  1.0
    x_68        EDGE_19_68  1.0
    x_68        EDGE_55_68  1.0
    x_68        EDGE_6_68  1.0
    x_68        EDGE_39_68  1.0
    x_68        EDGE_20_68  1.0
    x_68        EDGE_50_68  1.0
    x_68        EDGE_67_68  1.0
    x_68        EDGE_68_102  1.0
    x_68        EDGE_68_82  1.0
    x_68        EDGE_14_68  1.0
    x_68        EDGE_28_68  1.0
    x_68        EDGE_68_94  1.0
    x_68        EDGE_61_68  1.0
    x_68        EDGE_45_68  1.0
    x_69        OBJ       -92
    x_69        EDGE_69_81  1.0
    x_69        EDGE_69_94  1.0
    x_69        EDGE_69_93  1.0
    x_69        EDGE_12_69  1.0
    x_69        EDGE_45_69  1.0
    x_69        EDGE_62_69  1.0
    x_69        EDGE_46_69  1.0
    x_69        EDGE_69_97  1.0
    x_69        EDGE_69_74  1.0
    x_69        EDGE_56_69  1.0
    x_69        EDGE_69_109  1.0
    x_69        EDGE_43_69  1.0
    x_69        EDGE_69_99  1.0
    x_69        EDGE_69_79  1.0
    x_69        EDGE_69_101  1.0
    x_69        EDGE_5_69  1.0
    x_69        EDGE_69_103  1.0
    x_69        EDGE_52_69  1.0
    x_69        EDGE_66_69  1.0
    x_69        EDGE_17_69  1.0
    x_69        EDGE_39_69  1.0
    x_69        EDGE_20_69  1.0
    x_69        EDGE_50_69  1.0
    x_70        OBJ       -65
    x_70        EDGE_16_70  1.0
    x_70        EDGE_31_70  1.0
    x_70        EDGE_61_70  1.0
    x_70        EDGE_33_70  1.0
    x_70        EDGE_70_109  1.0
    x_70        EDGE_63_70  1.0
    x_70        EDGE_64_70  1.0
    x_70        EDGE_70_99  1.0
    x_70        EDGE_17_70  1.0
    x_70        EDGE_51_70  1.0
    x_70        EDGE_70_101  1.0
    x_70        EDGE_11_70  1.0
    x_70        EDGE_56_70  1.0
    x_70        EDGE_70_90  1.0
    x_70        EDGE_24_70  1.0
    x_70        EDGE_54_70  1.0
    x_70        EDGE_70_102  1.0
    x_70        EDGE_41_70  1.0
    x_70        EDGE_37_70  1.0
    x_70        EDGE_19_70  1.0
    x_70        EDGE_70_106  1.0
    x_70        EDGE_21_70  1.0
    x_70        EDGE_22_70  1.0
    x_70        EDGE_36_70  1.0
    x_70        EDGE_66_70  1.0
    x_70        EDGE_38_70  1.0
    x_70        EDGE_20_70  1.0
    x_70        EDGE_70_105  1.0
    x_70        EDGE_67_70  1.0
    x_70        EDGE_70_107  1.0
    x_70        EDGE_70_97  1.0
    x_70        EDGE_44_70  1.0
    x_71        OBJ       -55
    x_71        EDGE_17_71  1.0
    x_71        EDGE_67_71  1.0
    x_71        EDGE_71_99  1.0
    x_71        EDGE_14_71  1.0
    x_71        EDGE_45_71  1.0
    x_71        EDGE_71_103  1.0
    x_71        EDGE_23_71  1.0
    x_71        EDGE_4_71  1.0
    x_71        EDGE_71_102  1.0
    x_71        EDGE_71_82  1.0
    x_71        EDGE_21_71  1.0
    x_71        EDGE_43_71  1.0
    x_71        EDGE_54_71  1.0
    x_71        EDGE_57_71  1.0
    x_71        EDGE_38_71  1.0
    x_71        EDGE_71_104  1.0
    x_71        EDGE_71_81  1.0
    x_71        EDGE_18_71  1.0
    x_71        EDGE_71_73  1.0
    x_71        EDGE_16_71  1.0
    x_71        EDGE_19_71  1.0
    x_71        EDGE_71_72  1.0
    x_71        EDGE_22_71  1.0
    x_71        EDGE_71_85  1.0
    x_72        OBJ       -65
    x_72        EDGE_72_94  1.0
    x_72        EDGE_72_106  1.0
    x_72        EDGE_49_72  1.0
    x_72        EDGE_0_72  1.0
    x_72        EDGE_72_73  1.0
    x_72        EDGE_64_72  1.0
    x_72        EDGE_36_72  1.0
    x_72        EDGE_34_72  1.0
    x_72        EDGE_11_72  1.0
    x_72        EDGE_44_72  1.0
    x_72        EDGE_1_72  1.0
    x_72        EDGE_31_72  1.0
    x_72        EDGE_72_109  1.0
    x_72        EDGE_57_72  1.0
    x_72        EDGE_29_72  1.0
    x_72        EDGE_13_72  1.0
    x_72        EDGE_72_88  1.0
    x_72        EDGE_72_78  1.0
    x_72        EDGE_72_81  1.0
    x_72        EDGE_72_90  1.0
    x_72        EDGE_72_103  1.0
    x_72        EDGE_37_72  1.0
    x_72        EDGE_10_72  1.0
    x_72        EDGE_55_72  1.0
    x_72        EDGE_72_92  1.0
    x_72        EDGE_38_72  1.0
    x_72        EDGE_71_72  1.0
    x_72        EDGE_53_72  1.0
    x_73        OBJ       -86
    x_73        EDGE_73_74  1.0
    x_73        EDGE_73_87  1.0
    x_73        EDGE_5_73  1.0
    x_73        EDGE_73_77  1.0
    x_73        EDGE_19_73  1.0
    x_73        EDGE_49_73  1.0
    x_73        EDGE_0_73  1.0
    x_73        EDGE_33_73  1.0
    x_73        EDGE_73_86  1.0
    x_73        EDGE_55_73  1.0
    x_73        EDGE_73_99  1.0
    x_73        EDGE_39_73  1.0
    x_73        EDGE_72_73  1.0
    x_73        EDGE_53_73  1.0
    x_73        EDGE_73_88  1.0
    x_73        EDGE_73_91  1.0
    x_73        EDGE_44_73  1.0
    x_73        EDGE_25_73  1.0
    x_73        EDGE_9_73  1.0
    x_73        EDGE_42_73  1.0
    x_73        EDGE_48_73  1.0
    x_73        EDGE_73_102  1.0
    x_73        EDGE_29_73  1.0
    x_73        EDGE_62_73  1.0
    x_73        EDGE_65_73  1.0
    x_73        EDGE_46_73  1.0
    x_73        EDGE_73_104  1.0
    x_73        EDGE_73_84  1.0
    x_73        EDGE_23_73  1.0
    x_73        EDGE_40_73  1.0
    x_73        EDGE_71_73  1.0
    x_73        EDGE_2_73  1.0
    x_74        OBJ       -25
    x_74        EDGE_73_74  1.0
    x_74        EDGE_54_74  1.0
    x_74        EDGE_57_74  1.0
    x_74        EDGE_58_74  1.0
    x_74        EDGE_18_74  1.0
    x_74        EDGE_16_74  1.0
    x_74        EDGE_52_74  1.0
    x_74        EDGE_3_74  1.0
    x_74        EDGE_33_74  1.0
    x_74        EDGE_74_88  1.0
    x_74        EDGE_69_74  1.0
    x_74        EDGE_20_74  1.0
    x_74        EDGE_34_74  1.0
    x_74        EDGE_74_100  1.0
    x_74        EDGE_74_102  1.0
    x_74        EDGE_28_74  1.0
    x_74        EDGE_1_74  1.0
    x_74        EDGE_12_74  1.0
    x_74        EDGE_45_74  1.0
    x_74        EDGE_48_74  1.0
    x_74        EDGE_13_74  1.0
    x_74        EDGE_65_74  1.0
    x_74        EDGE_26_74  1.0
    x_74        EDGE_56_74  1.0
    x_74        EDGE_37_74  1.0
    x_75        OBJ       -39
    x_75        EDGE_75_80  1.0
    x_75        EDGE_18_75  1.0
    x_75        EDGE_35_75  1.0
    x_75        EDGE_75_92  1.0
    x_75        EDGE_52_75  1.0
    x_75        EDGE_33_75  1.0
    x_75        EDGE_6_75  1.0
    x_75        EDGE_17_75  1.0
    x_75        EDGE_39_75  1.0
    x_75        EDGE_75_104  1.0
    x_75        EDGE_75_94  1.0
    x_75        EDGE_34_75  1.0
    x_75        EDGE_14_75  1.0
    x_75        EDGE_44_75  1.0
    x_75        EDGE_75_105  1.0
    x_75        EDGE_61_75  1.0
    x_75        EDGE_12_75  1.0
    x_75        EDGE_45_75  1.0
    x_75        EDGE_29_75  1.0
    x_75        EDGE_59_75  1.0
    x_75        EDGE_51_75  1.0
    x_75        EDGE_75_76  1.0
    x_75        EDGE_75_89  1.0
    x_75        EDGE_37_75  1.0
    x_75        EDGE_40_75  1.0
    x_75        EDGE_38_75  1.0
    x_76        OBJ       -37
    x_76        EDGE_76_97  1.0
    x_76        EDGE_76_77  1.0
    x_76        EDGE_56_76  1.0
    x_76        EDGE_21_76  1.0
    x_76        EDGE_76_89  1.0
    x_76        EDGE_8_76  1.0
    x_76        EDGE_41_76  1.0
    x_76        EDGE_76_103  1.0
    x_76        EDGE_53_76  1.0
    x_76        EDGE_76_81  1.0
    x_76        EDGE_76_94  1.0
    x_76        EDGE_75_76  1.0
    x_76        EDGE_62_76  1.0
    x_76        EDGE_76_95  1.0
    x_76        EDGE_76_85  1.0
    x_77        OBJ       -76
    x_77        EDGE_12_77  1.0
    x_77        EDGE_43_77  1.0
    x_77        EDGE_73_77  1.0
    x_77        EDGE_76_77  1.0
    x_77        EDGE_60_77  1.0
    x_77        EDGE_77_89  1.0
    x_77        EDGE_22_77  1.0
    x_77        EDGE_24_77  1.0
    x_77        EDGE_77_101  1.0
    x_77        EDGE_39_77  1.0
    x_77        EDGE_53_77  1.0
    x_77        EDGE_30_77  1.0
    x_77        EDGE_2_77  1.0
    x_77        EDGE_16_77  1.0
    x_77        EDGE_47_77  1.0
    x_77        EDGE_3_77  1.0
    x_77        EDGE_45_77  1.0
    x_77        EDGE_77_104  1.0
    x_77        EDGE_77_84  1.0
    x_77        EDGE_62_77  1.0
    x_77        EDGE_65_77  1.0
    x_77        EDGE_77_106  1.0
    x_77        EDGE_77_83  1.0
    x_77        EDGE_77_86  1.0
    x_77        EDGE_25_77  1.0
    x_78        OBJ       -64
    x_78        EDGE_65_78  1.0
    x_78        EDGE_23_78  1.0
    x_78        EDGE_4_78  1.0
    x_78        EDGE_26_78  1.0
    x_78        EDGE_78_82  1.0
    x_78        EDGE_21_78  1.0
    x_78        EDGE_24_78  1.0
    x_78        EDGE_41_78  1.0
    x_78        EDGE_18_78  1.0
    x_78        EDGE_78_96  1.0
    x_78        EDGE_2_78  1.0
    x_78        EDGE_16_78  1.0
    x_78        EDGE_68_78  1.0
    x_78        EDGE_19_78  1.0
    x_78        EDGE_0_78  1.0
    x_78        EDGE_55_78  1.0
    x_78        EDGE_6_78  1.0
    x_78        EDGE_17_78  1.0
    x_78        EDGE_72_78  1.0
    x_78        EDGE_53_78  1.0
    x_78        EDGE_30_78  1.0
    x_78        EDGE_25_78  1.0
    x_78        EDGE_78_89  1.0
    x_78        EDGE_47_78  1.0
    x_78        EDGE_9_78  1.0
    x_78        EDGE_1_78  1.0
    x_78        EDGE_15_78  1.0
    x_78        EDGE_78_88  1.0
    x_78        EDGE_78_101  1.0
    x_78        EDGE_59_78  1.0
    x_79        OBJ       -65
    x_79        EDGE_25_79  1.0
    x_79        EDGE_47_79  1.0
    x_79        EDGE_79_100  1.0
    x_79        EDGE_13_79  1.0
    x_79        EDGE_58_79  1.0
    x_79        EDGE_79_92  1.0
    x_79        EDGE_26_79  1.0
    x_79        EDGE_21_79  1.0
    x_79        EDGE_55_79  1.0
    x_79        EDGE_27_79  1.0
    x_79        EDGE_8_79  1.0
    x_79        EDGE_79_93  1.0
    x_79        EDGE_69_79  1.0
    x_79        EDGE_41_79  1.0
    x_79        EDGE_53_79  1.0
    x_79        EDGE_18_79  1.0
    x_79        EDGE_35_79  1.0
    x_79        EDGE_16_79  1.0
    x_79        EDGE_79_107  1.0
    x_79        EDGE_66_79  1.0
    x_79        EDGE_17_79  1.0
    x_79        EDGE_50_79  1.0
    x_79        EDGE_51_79  1.0
    x_79        EDGE_67_79  1.0
    x_79        EDGE_79_89  1.0
    x_80        OBJ       -51
    x_80        EDGE_47_80  1.0
    x_80        EDGE_31_80  1.0
    x_80        EDGE_12_80  1.0
    x_80        EDGE_64_80  1.0
    x_80        EDGE_75_80  1.0
    x_80        EDGE_46_80  1.0
    x_80        EDGE_26_80  1.0
    x_80        EDGE_7_80  1.0
    x_80        EDGE_37_80  1.0
    x_80        EDGE_10_80  1.0
    x_80        EDGE_80_106  1.0
    x_80        EDGE_24_80  1.0
    x_80        EDGE_27_80  1.0
    x_80        EDGE_8_80  1.0
    x_80        EDGE_60_80  1.0
    x_80        EDGE_80_108  1.0
    x_80        EDGE_5_80  1.0
    x_80        EDGE_80_87  1.0
    x_80        EDGE_33_80  1.0
    x_80        EDGE_63_80  1.0
    x_80        EDGE_55_80  1.0
    x_80        EDGE_36_80  1.0
    x_80        EDGE_80_89  1.0
    x_80        EDGE_34_80  1.0
    x_80        EDGE_80_101  1.0
    x_80        EDGE_80_100  1.0
    x_81        OBJ       -76
    x_81        EDGE_69_81  1.0
    x_81        EDGE_81_91  1.0
    x_81        EDGE_53_81  1.0
    x_81        EDGE_25_81  1.0
    x_81        EDGE_81_105  1.0
    x_81        EDGE_81_82  1.0
    x_81        EDGE_15_81  1.0
    x_81        EDGE_48_81  1.0
    x_81        EDGE_59_81  1.0
    x_81        EDGE_32_81  1.0
    x_81        EDGE_7_81  1.0
    x_81        EDGE_43_81  1.0
    x_81        EDGE_81_98  1.0
    x_81        EDGE_54_81  1.0
    x_81        EDGE_76_81  1.0
    x_81        EDGE_38_81  1.0
    x_81        EDGE_71_81  1.0
    x_81        EDGE_72_81  1.0
    x_81        EDGE_81_87  1.0
    x_81        EDGE_52_81  1.0
    x_81        EDGE_33_81  1.0
    x_81        EDGE_63_81  1.0
    x_81        EDGE_66_81  1.0
    x_81        EDGE_17_81  1.0
    x_82        OBJ       -5
    x_82        EDGE_82_93  1.0
    x_82        EDGE_82_106  1.0
    x_82        EDGE_82_96  1.0
    x_82        EDGE_16_82  1.0
    x_82        EDGE_82_95  1.0
    x_82        EDGE_78_82  1.0
    x_82        EDGE_81_82  1.0
    x_82        EDGE_13_82  1.0
    x_82        EDGE_65_82  1.0
    x_82        EDGE_82_97  1.0
    x_82        EDGE_11_82  1.0
    x_82        EDGE_25_82  1.0
    x_82        EDGE_26_82  1.0
    x_82        EDGE_56_82  1.0
    x_82        EDGE_40_82  1.0
    x_82        EDGE_54_82  1.0
    x_82        EDGE_82_88  1.0
    x_82        EDGE_71_82  1.0
    x_82        EDGE_5_82  1.0
    x_82        EDGE_68_82  1.0
    x_82        EDGE_19_82  1.0
    x_82        EDGE_39_82  1.0
    x_82        EDGE_20_82  1.0
    x_82        EDGE_50_82  1.0
    x_82        EDGE_82_94  1.0
    x_83        OBJ       -62
    x_83        EDGE_16_83  1.0
    x_83        EDGE_68_83  1.0
    x_83        EDGE_49_83  1.0
    x_83        EDGE_52_83  1.0
    x_83        EDGE_83_84  1.0
    x_83        EDGE_33_83  1.0
    x_83        EDGE_63_83  1.0
    x_83        EDGE_55_83  1.0
    x_83        EDGE_17_83  1.0
    x_83        EDGE_83_93  1.0
    x_83        EDGE_83_95  1.0
    x_83        EDGE_83_98  1.0
    x_83        EDGE_14_83  1.0
    x_83        EDGE_9_83  1.0
    x_83        EDGE_61_83  1.0
    x_83        EDGE_42_83  1.0
    x_83        EDGE_83_87  1.0
    x_83        EDGE_48_83  1.0
    x_83        EDGE_29_83  1.0
    x_83        EDGE_51_83  1.0
    x_83        EDGE_83_109  1.0
    x_83        EDGE_83_86  1.0
    x_83        EDGE_56_83  1.0
    x_83        EDGE_83_91  1.0
    x_83        EDGE_10_83  1.0
    x_83        EDGE_21_83  1.0
    x_83        EDGE_43_83  1.0
    x_83        EDGE_54_83  1.0
    x_83        EDGE_83_100  1.0
    x_83        EDGE_38_83  1.0
    x_83        EDGE_83_103  1.0
    x_83        EDGE_41_83  1.0
    x_83        EDGE_77_83  1.0
    x_83        EDGE_58_83  1.0
    x_84        OBJ       -32
    x_84        EDGE_84_92  1.0
    x_84        EDGE_84_105  1.0
    x_84        EDGE_53_84  1.0
    x_84        EDGE_83_84  1.0
    x_84        EDGE_67_84  1.0
    x_84        EDGE_47_84  1.0
    x_84        EDGE_84_93  1.0
    x_84        EDGE_84_106  1.0
    x_84        EDGE_49_84  1.0
    x_84        EDGE_0_84  1.0
    x_84        EDGE_3_84  1.0
    x_84        EDGE_64_84  1.0
    x_84        EDGE_50_84  1.0
    x_84        EDGE_51_84  1.0
    x_84        EDGE_32_84  1.0
    x_84        EDGE_34_84  1.0
    x_84        EDGE_84_98  1.0
    x_84        EDGE_84_107  1.0
    x_84        EDGE_42_84  1.0
    x_84        EDGE_73_84  1.0
    x_84        EDGE_84_99  1.0
    x_84        EDGE_84_89  1.0
    x_84        EDGE_57_84  1.0
    x_84        EDGE_59_84  1.0
    x_84        EDGE_84_88  1.0
    x_84        EDGE_77_84  1.0
    x_84        EDGE_84_91  1.0
    x_84        EDGE_84_100  1.0
    x_84        EDGE_37_84  1.0
    x_84        EDGE_52_84  1.0
    x_84        EDGE_54_84  1.0
    x_85        OBJ       -96
    x_85        EDGE_58_85  1.0
    x_85        EDGE_35_85  1.0
    x_85        EDGE_52_85  1.0
    x_85        EDGE_3_85  1.0
    x_85        EDGE_85_108  1.0
    x_85        EDGE_39_85  1.0
    x_85        EDGE_34_85  1.0
    x_85        EDGE_85_107  1.0
    x_85        EDGE_67_85  1.0
    x_85        EDGE_1_85  1.0
    x_85        EDGE_46_85  1.0
    x_85        EDGE_7_85  1.0
    x_85        EDGE_10_85  1.0
    x_85        EDGE_85_105  1.0
    x_85        EDGE_54_85  1.0
    x_85        EDGE_76_85  1.0
    x_85        EDGE_71_85  1.0
    x_85        EDGE_85_94  1.0
    x_86        OBJ       -52
    x_86        EDGE_56_86  1.0
    x_86        EDGE_40_86  1.0
    x_86        EDGE_86_94  1.0
    x_86        EDGE_21_86  1.0
    x_86        EDGE_43_86  1.0
    x_86        EDGE_73_86  1.0
    x_86        EDGE_54_86  1.0
    x_86        EDGE_55_86  1.0
    x_86        EDGE_39_86  1.0
    x_86        EDGE_16_86  1.0
    x_86        EDGE_52_86  1.0
    x_86        EDGE_83_86  1.0
    x_86        EDGE_44_86  1.0
    x_86        EDGE_31_86  1.0
    x_86        EDGE_61_86  1.0
    x_86        EDGE_12_86  1.0
    x_86        EDGE_45_86  1.0
    x_86        EDGE_86_100  1.0
    x_86        EDGE_48_86  1.0
    x_86        EDGE_60_86  1.0
    x_86        EDGE_77_86  1.0
    x_87        OBJ       -54
    x_87        EDGE_73_87  1.0
    x_87        EDGE_87_107  1.0
    x_87        EDGE_54_87  1.0
    x_87        EDGE_87_97  1.0
    x_87        EDGE_87_99  1.0
    x_87        EDGE_2_87  1.0
    x_87        EDGE_35_87  1.0
    x_87        EDGE_16_87  1.0
    x_87        EDGE_87_91  1.0
    x_87        EDGE_39_87  1.0
    x_87        EDGE_83_87  1.0
    x_87        EDGE_87_92  1.0
    x_87        EDGE_14_87  1.0
    x_87        EDGE_28_87  1.0
    x_87        EDGE_80_87  1.0
    x_87        EDGE_61_87  1.0
    x_87        EDGE_64_87  1.0
    x_87        EDGE_45_87  1.0
    x_87        EDGE_81_87  1.0
    x_87        EDGE_13_87  1.0
    x_87        EDGE_87_105  1.0
    x_87        EDGE_56_87  1.0
    x_87        EDGE_9_87  1.0
    x_87        EDGE_10_87  1.0
    x_88        OBJ       -86
    x_88        EDGE_46_88  1.0
    x_88        EDGE_88_98  1.0
    x_88        EDGE_88_97  1.0
    x_88        EDGE_4_88  1.0
    x_88        EDGE_7_88  1.0
    x_88        EDGE_37_88  1.0
    x_88        EDGE_21_88  1.0
    x_88        EDGE_73_88  1.0
    x_88        EDGE_74_88  1.0
    x_88        EDGE_2_88  1.0
    x_88        EDGE_16_88  1.0
    x_88        EDGE_52_88  1.0
    x_88        EDGE_3_88  1.0
    x_88        EDGE_82_88  1.0
    x_88        EDGE_33_88  1.0
    x_88        EDGE_63_88  1.0
    x_88        EDGE_6_88  1.0
    x_88        EDGE_66_88  1.0
    x_88        EDGE_88_102  1.0
    x_88        EDGE_88_92  1.0
    x_88        EDGE_72_88  1.0
    x_88        EDGE_84_88  1.0
    x_88        EDGE_11_88  1.0
    x_88        EDGE_28_88  1.0
    x_88        EDGE_1_88  1.0
    x_88        EDGE_31_88  1.0
    x_88        EDGE_88_106  1.0
    x_88        EDGE_61_88  1.0
    x_88        EDGE_12_88  1.0
    x_88        EDGE_42_88  1.0
    x_88        EDGE_48_88  1.0
    x_88        EDGE_78_88  1.0
    x_88        EDGE_32_88  1.0
    x_89        OBJ       -23
    x_89        EDGE_23_89  1.0
    x_89        EDGE_25_89  1.0
    x_89        EDGE_26_89  1.0
    x_89        EDGE_89_99  1.0
    x_89        EDGE_76_89  1.0
    x_89        EDGE_27_89  1.0
    x_89        EDGE_77_89  1.0
    x_89        EDGE_18_89  1.0
    x_89        EDGE_4_89  1.0
    x_89        EDGE_35_89  1.0
    x_89        EDGE_7_89  1.0
    x_89        EDGE_37_89  1.0
    x_89        EDGE_49_89  1.0
    x_89        EDGE_89_102  1.0
    x_89        EDGE_22_89  1.0
    x_89        EDGE_52_89  1.0
    x_89        EDGE_36_89  1.0
    x_89        EDGE_50_89  1.0
    x_89        EDGE_53_89  1.0
    x_89        EDGE_89_104  1.0
    x_89        EDGE_67_89  1.0
    x_89        EDGE_84_89  1.0
    x_89        EDGE_16_89  1.0
    x_89        EDGE_1_89  1.0
    x_89        EDGE_80_89  1.0
    x_89        EDGE_31_89  1.0
    x_89        EDGE_89_95  1.0
    x_89        EDGE_75_89  1.0
    x_89        EDGE_78_89  1.0
    x_89        EDGE_29_89  1.0
    x_89        EDGE_51_89  1.0
    x_89        EDGE_65_89  1.0
    x_89        EDGE_46_89  1.0
    x_89        EDGE_89_107  1.0
    x_89        EDGE_79_89  1.0
    x_90        OBJ       -47
    x_90        EDGE_12_90  1.0
    x_90        EDGE_42_90  1.0
    x_90        EDGE_64_90  1.0
    x_90        EDGE_45_90  1.0
    x_90        EDGE_90_97  1.0
    x_90        EDGE_48_90  1.0
    x_90        EDGE_29_90  1.0
    x_90        EDGE_51_90  1.0
    x_90        EDGE_65_90  1.0
    x_90        EDGE_90_109  1.0
    x_90        EDGE_90_99  1.0
    x_90        EDGE_23_90  1.0
    x_90        EDGE_56_90  1.0
    x_90        EDGE_90_91  1.0
    x_90        EDGE_40_90  1.0
    x_90        EDGE_70_90  1.0
    x_90        EDGE_27_90  1.0
    x_90        EDGE_57_90  1.0
    x_90        EDGE_60_90  1.0
    x_90        EDGE_58_90  1.0
    x_90        EDGE_18_90  1.0
    x_90        EDGE_5_90  1.0
    x_90        EDGE_35_90  1.0
    x_90        EDGE_19_90  1.0
    x_90        EDGE_90_104  1.0
    x_90        EDGE_72_90  1.0
    x_90        EDGE_53_90  1.0
    x_90        EDGE_90_93  1.0
    x_90        EDGE_34_90  1.0
    x_90        EDGE_90_106  1.0
    x_90        EDGE_67_90  1.0
    x_90        EDGE_11_90  1.0
    x_90        EDGE_25_90  1.0
    x_91        OBJ       -71
    x_91        EDGE_81_91  1.0
    x_91        EDGE_32_91  1.0
    x_91        EDGE_91_95  1.0
    x_91        EDGE_65_91  1.0
    x_91        EDGE_11_91  1.0
    x_91        EDGE_14_91  1.0
    x_91        EDGE_25_91  1.0
    x_91        EDGE_26_91  1.0
    x_91        EDGE_31_91  1.0
    x_91        EDGE_61_91  1.0
    x_91        EDGE_42_91  1.0
    x_91        EDGE_43_91  1.0
    x_91        EDGE_91_109  1.0
    x_91        EDGE_73_91  1.0
    x_91        EDGE_45_91  1.0
    x_91        EDGE_57_91  1.0
    x_91        EDGE_87_91  1.0
    x_91        EDGE_29_91  1.0
    x_91        EDGE_59_91  1.0
    x_91        EDGE_90_91  1.0
    x_91        EDGE_13_91  1.0
    x_91        EDGE_23_91  1.0
    x_91        EDGE_91_103  1.0
    x_91        EDGE_21_91  1.0
    x_91        EDGE_24_91  1.0
    x_91        EDGE_55_91  1.0
    x_91        EDGE_39_91  1.0
    x_91        EDGE_83_91  1.0
    x_91        EDGE_84_91  1.0
    x_91        EDGE_5_91  1.0
    x_91        EDGE_91_106  1.0
    x_91        EDGE_33_91  1.0
    x_92        OBJ       -90
    x_92        EDGE_84_92  1.0
    x_92        EDGE_11_92  1.0
    x_92        EDGE_28_92  1.0
    x_92        EDGE_42_92  1.0
    x_92        EDGE_15_92  1.0
    x_92        EDGE_45_92  1.0
    x_92        EDGE_75_92  1.0
    x_92        EDGE_62_92  1.0
    x_92        EDGE_13_92  1.0
    x_92        EDGE_79_92  1.0
    x_92        EDGE_92_94  1.0
    x_92        EDGE_23_92  1.0
    x_92        EDGE_56_92  1.0
    x_92        EDGE_7_92  1.0
    x_92        EDGE_10_92  1.0
    x_92        EDGE_40_92  1.0
    x_92        EDGE_43_92  1.0
    x_92        EDGE_24_92  1.0
    x_92        EDGE_57_92  1.0
    x_92        EDGE_87_92  1.0
    x_92        EDGE_38_92  1.0
    x_92        EDGE_60_92  1.0
    x_92        EDGE_41_92  1.0
    x_92        EDGE_92_95  1.0
    x_92        EDGE_88_92  1.0
    x_92        EDGE_0_92  1.0
    x_92        EDGE_33_92  1.0
    x_92        EDGE_63_92  1.0
    x_92        EDGE_55_92  1.0
    x_92        EDGE_6_92  1.0
    x_92        EDGE_66_92  1.0
    x_92        EDGE_17_92  1.0
    x_92        EDGE_72_92  1.0
    x_92        EDGE_67_92  1.0
    x_93        OBJ       -100
    x_93        EDGE_16_93  1.0
    x_93        EDGE_22_93  1.0
    x_93        EDGE_82_93  1.0
    x_93        EDGE_6_93  1.0
    x_93        EDGE_17_93  1.0
    x_93        EDGE_69_93  1.0
    x_93        EDGE_50_93  1.0
    x_93        EDGE_83_93  1.0
    x_93        EDGE_34_93  1.0
    x_93        EDGE_84_93  1.0
    x_93        EDGE_30_93  1.0
    x_93        EDGE_11_93  1.0
    x_93        EDGE_44_93  1.0
    x_93        EDGE_93_103  1.0
    x_93        EDGE_79_93  1.0
    x_93        EDGE_27_93  1.0
    x_93        EDGE_90_93  1.0
    x_93        EDGE_18_93  1.0
    x_93        EDGE_93_108  1.0
    x_93        EDGE_93_98  1.0
    x_94        OBJ       -87
    x_94        EDGE_39_94  1.0
    x_94        EDGE_69_94  1.0
    x_94        EDGE_50_94  1.0
    x_94        EDGE_94_100  1.0
    x_94        EDGE_72_94  1.0
    x_94        EDGE_86_94  1.0
    x_94        EDGE_94_102  1.0
    x_94        EDGE_94_105  1.0
    x_94        EDGE_31_94  1.0
    x_94        EDGE_61_94  1.0
    x_94        EDGE_75_94  1.0
    x_94        EDGE_48_94  1.0
    x_94        EDGE_51_94  1.0
    x_94        EDGE_92_94  1.0
    x_94        EDGE_94_95  1.0
    x_94        EDGE_40_94  1.0
    x_94        EDGE_76_94  1.0
    x_94        EDGE_94_97  1.0
    x_94        EDGE_41_94  1.0
    x_94        EDGE_18_94  1.0
    x_94        EDGE_35_94  1.0
    x_94        EDGE_16_94  1.0
    x_94        EDGE_68_94  1.0
    x_94        EDGE_49_94  1.0
    x_94        EDGE_94_101  1.0
    x_94        EDGE_22_94  1.0
    x_94        EDGE_82_94  1.0
    x_94        EDGE_63_94  1.0
    x_94        EDGE_85_94  1.0
    x_95        OBJ       -95
    x_95        EDGE_91_95  1.0
    x_95        EDGE_5_95  1.0
    x_95        EDGE_35_95  1.0
    x_95        EDGE_95_100  1.0
    x_95        EDGE_95_103  1.0
    x_95        EDGE_82_95  1.0
    x_95        EDGE_63_95  1.0
    x_95        EDGE_55_95  1.0
    x_95        EDGE_95_102  1.0
    x_95        EDGE_83_95  1.0
    x_95        EDGE_95_105  1.0
    x_95        EDGE_67_95  1.0
    x_95        EDGE_14_95  1.0
    x_95        EDGE_25_95  1.0
    x_95        EDGE_47_95  1.0
    x_95        EDGE_12_95  1.0
    x_95        EDGE_94_95  1.0
    x_95        EDGE_13_95  1.0
    x_95        EDGE_92_95  1.0
    x_95        EDGE_26_95  1.0
    x_95        EDGE_89_95  1.0
    x_95        EDGE_76_95  1.0
    x_95        EDGE_27_95  1.0
    x_95        EDGE_60_95  1.0
    x_96        OBJ       -48
    x_96        EDGE_7_96  1.0
    x_96        EDGE_19_96  1.0
    x_96        EDGE_21_96  1.0
    x_96        EDGE_22_96  1.0
    x_96        EDGE_52_96  1.0
    x_96        EDGE_82_96  1.0
    x_96        EDGE_55_96  1.0
    x_96        EDGE_66_96  1.0
    x_96        EDGE_38_96  1.0
    x_96        EDGE_53_96  1.0
    x_96        EDGE_96_103  1.0
    x_96        EDGE_16_96  1.0
    x_96        EDGE_96_102  1.0
    x_96        EDGE_1_96  1.0
    x_96        EDGE_15_96  1.0
    x_96        EDGE_78_96  1.0
    x_96        EDGE_51_96  1.0
    x_96        EDGE_62_96  1.0
    x_96        EDGE_65_96  1.0
    x_96        EDGE_26_96  1.0
    x_96        EDGE_28_96  1.0
    x_96        EDGE_9_96  1.0
    x_96        EDGE_10_96  1.0
    x_96        EDGE_42_96  1.0
    x_96        EDGE_43_96  1.0
    x_96        EDGE_96_108  1.0
    x_96        EDGE_24_96  1.0
    x_96        EDGE_96_107  1.0
    x_96        EDGE_96_109  1.0
    x_96        EDGE_23_96  1.0
    x_97        OBJ       -12
    x_97        EDGE_76_97  1.0
    x_97        EDGE_8_97  1.0
    x_97        EDGE_87_97  1.0
    x_97        EDGE_38_97  1.0
    x_97        EDGE_90_97  1.0
    x_97        EDGE_88_97  1.0
    x_97        EDGE_97_102  1.0
    x_97        EDGE_19_97  1.0
    x_97        EDGE_97_104  1.0
    x_97        EDGE_82_97  1.0
    x_97        EDGE_55_97  1.0
    x_97        EDGE_36_97  1.0
    x_97        EDGE_66_97  1.0
    x_97        EDGE_17_97  1.0
    x_97        EDGE_69_97  1.0
    x_97        EDGE_34_97  1.0
    x_97        EDGE_97_108  1.0
    x_97        EDGE_9_97  1.0
    x_97        EDGE_1_97  1.0
    x_97        EDGE_12_97  1.0
    x_97        EDGE_94_97  1.0
    x_97        EDGE_59_97  1.0
    x_97        EDGE_97_109  1.0
    x_97        EDGE_23_97  1.0
    x_97        EDGE_7_97  1.0
    x_97        EDGE_97_101  1.0
    x_97        EDGE_70_97  1.0
    x_98        OBJ       -57
    x_98        EDGE_88_98  1.0
    x_98        EDGE_37_98  1.0
    x_98        EDGE_40_98  1.0
    x_98        EDGE_21_98  1.0
    x_98        EDGE_22_98  1.0
    x_98        EDGE_54_98  1.0
    x_98        EDGE_55_98  1.0
    x_98        EDGE_8_98  1.0
    x_98        EDGE_53_98  1.0
    x_98        EDGE_83_98  1.0
    x_98        EDGE_84_98  1.0
    x_98        EDGE_52_98  1.0
    x_98        EDGE_6_98  1.0
    x_98        EDGE_36_98  1.0
    x_98        EDGE_50_98  1.0
    x_98        EDGE_81_98  1.0
    x_98        EDGE_65_98  1.0
    x_98        EDGE_98_108  1.0
    x_98        EDGE_30_98  1.0
    x_98        EDGE_11_98  1.0
    x_98        EDGE_44_98  1.0
    x_98        EDGE_98_100  1.0
    x_98        EDGE_28_98  1.0
    x_98        EDGE_31_98  1.0
    x_98        EDGE_12_98  1.0
    x_98        EDGE_32_98  1.0
    x_98        EDGE_93_98  1.0
    x_99        OBJ       -85
    x_99        EDGE_23_99  1.0
    x_99        EDGE_89_99  1.0
    x_99        EDGE_40_99  1.0
    x_99        EDGE_70_99  1.0
    x_99        EDGE_73_99  1.0
    x_99        EDGE_87_99  1.0
    x_99        EDGE_90_99  1.0
    x_99        EDGE_41_99  1.0
    x_99        EDGE_71_99  1.0
    x_99        EDGE_5_99  1.0
    x_99        EDGE_19_99  1.0
    x_99        EDGE_55_99  1.0
    x_99        EDGE_69_99  1.0
    x_99        EDGE_53_99  1.0
    x_99        EDGE_84_99  1.0
    x_99        EDGE_30_99  1.0
    x_99        EDGE_44_99  1.0
    x_99        EDGE_47_99  1.0
    x_99        EDGE_28_99  1.0
    x_99        EDGE_9_99  1.0
    x_99        EDGE_31_99  1.0
    x_99        EDGE_61_99  1.0
    x_99        EDGE_64_99  1.0
    x_99        EDGE_45_99  1.0
    x_99        EDGE_32_99  1.0
    x_99        EDGE_99_102  1.0
    x_99        EDGE_65_99  1.0
    x_99        EDGE_46_99  1.0
    x_100       OBJ       -66
    x_100       EDGE_42_100  1.0
    x_100       EDGE_94_100  1.0
    x_100       EDGE_59_100  1.0
    x_100       EDGE_95_100  1.0
    x_100       EDGE_79_100  1.0
    x_100       EDGE_26_100  1.0
    x_100       EDGE_56_100  1.0
    x_100       EDGE_7_100  1.0
    x_100       EDGE_37_100  1.0
    x_100       EDGE_40_100  1.0
    x_100       EDGE_21_100  1.0
    x_100       EDGE_43_100  1.0
    x_100       EDGE_8_100  1.0
    x_100       EDGE_74_100  1.0
    x_100       EDGE_58_100  1.0
    x_100       EDGE_55_100  1.0
    x_100       EDGE_20_100  1.0
    x_100       EDGE_53_100  1.0
    x_100       EDGE_83_100  1.0
    x_100       EDGE_86_100  1.0
    x_100       EDGE_98_100  1.0
    x_100       EDGE_100_103  1.0
    x_100       EDGE_84_100  1.0
    x_100       EDGE_25_100  1.0
    x_100       EDGE_100_102  1.0
    x_100       EDGE_80_100  1.0
    x_101       OBJ       -14
    x_101       EDGE_65_101  1.0
    x_101       EDGE_25_101  1.0
    x_101       EDGE_37_101  1.0
    x_101       EDGE_70_101  1.0
    x_101       EDGE_24_101  1.0
    x_101       EDGE_8_101  1.0
    x_101       EDGE_38_101  1.0
    x_101       EDGE_77_101  1.0
    x_101       EDGE_49_101  1.0
    x_101       EDGE_22_101  1.0
    x_101       EDGE_6_101  1.0
    x_101       EDGE_36_101  1.0
    x_101       EDGE_69_101  1.0
    x_101       EDGE_20_101  1.0
    x_101       EDGE_14_101  1.0
    x_101       EDGE_16_101  1.0
    x_101       EDGE_28_101  1.0
    x_101       EDGE_0_101  1.0
    x_101       EDGE_80_101  1.0
    x_101       EDGE_15_101  1.0
    x_101       EDGE_101_104  1.0
    x_101       EDGE_94_101  1.0
    x_101       EDGE_97_101  1.0
    x_101       EDGE_78_101  1.0
    x_101       EDGE_29_101  1.0
    x_101       EDGE_59_101  1.0
    x_102       OBJ       -100
    x_102       EDGE_30_102  1.0
    x_102       EDGE_11_102  1.0
    x_102       EDGE_14_102  1.0
    x_102       EDGE_25_102  1.0
    x_102       EDGE_28_102  1.0
    x_102       EDGE_1_102  1.0
    x_102       EDGE_31_102  1.0
    x_102       EDGE_61_102  1.0
    x_102       EDGE_15_102  1.0
    x_102       EDGE_102_106  1.0
    x_102       EDGE_94_102  1.0
    x_102       EDGE_45_102  1.0
    x_102       EDGE_97_102  1.0
    x_102       EDGE_95_102  1.0
    x_102       EDGE_96_102  1.0
    x_102       EDGE_4_102  1.0
    x_102       EDGE_26_102  1.0
    x_102       EDGE_7_102  1.0
    x_102       EDGE_10_102  1.0
    x_102       EDGE_89_102  1.0
    x_102       EDGE_70_102  1.0
    x_102       EDGE_21_102  1.0
    x_102       EDGE_43_102  1.0
    x_102       EDGE_73_102  1.0
    x_102       EDGE_41_102  1.0
    x_102       EDGE_71_102  1.0
    x_102       EDGE_74_102  1.0
    x_102       EDGE_88_102  1.0
    x_102       EDGE_5_102  1.0
    x_102       EDGE_16_102  1.0
    x_102       EDGE_68_102  1.0
    x_102       EDGE_3_102  1.0
    x_102       EDGE_66_102  1.0
    x_102       EDGE_39_102  1.0
    x_102       EDGE_20_102  1.0
    x_102       EDGE_99_102  1.0
    x_102       EDGE_50_102  1.0
    x_102       EDGE_34_102  1.0
    x_102       EDGE_67_102  1.0
    x_102       EDGE_100_102  1.0
    x_103       OBJ       -21
    x_103       EDGE_31_103  1.0
    x_103       EDGE_61_103  1.0
    x_103       EDGE_15_103  1.0
    x_103       EDGE_50_103  1.0
    x_103       EDGE_103_107  1.0
    x_103       EDGE_95_103  1.0
    x_103       EDGE_103_106  1.0
    x_103       EDGE_96_103  1.0
    x_103       EDGE_14_103  1.0
    x_103       EDGE_103_108  1.0
    x_103       EDGE_76_103  1.0
    x_103       EDGE_29_103  1.0
    x_103       EDGE_71_103  1.0
    x_103       EDGE_93_103  1.0
    x_103       EDGE_91_103  1.0
    x_103       EDGE_5_103  1.0
    x_103       EDGE_35_103  1.0
    x_103       EDGE_24_103  1.0
    x_103       EDGE_66_103  1.0
    x_103       EDGE_39_103  1.0
    x_103       EDGE_69_103  1.0
    x_103       EDGE_72_103  1.0
    x_103       EDGE_83_103  1.0
    x_103       EDGE_100_103  1.0
    x_104       OBJ       -67
    x_104       EDGE_20_104  1.0
    x_104       EDGE_67_104  1.0
    x_104       EDGE_104_107  1.0
    x_104       EDGE_104_109  1.0
    x_104       EDGE_9_104  1.0
    x_104       EDGE_61_104  1.0
    x_104       EDGE_45_104  1.0
    x_104       EDGE_75_104  1.0
    x_104       EDGE_97_104  1.0
    x_104       EDGE_59_104  1.0
    x_104       EDGE_62_104  1.0
    x_104       EDGE_23_104  1.0
    x_104       EDGE_56_104  1.0
    x_104       EDGE_89_104  1.0
    x_104       EDGE_73_104  1.0
    x_104       EDGE_90_104  1.0
    x_104       EDGE_71_104  1.0
    x_104       EDGE_77_104  1.0
    x_104       EDGE_58_104  1.0
    x_104       EDGE_18_104  1.0
    x_104       EDGE_5_104  1.0
    x_104       EDGE_0_104  1.0
    x_104       EDGE_101_104  1.0
    x_104       EDGE_3_104  1.0
    x_104       EDGE_33_104  1.0
    x_105       OBJ       -51
    x_105       EDGE_84_105  1.0
    x_105       EDGE_16_105  1.0
    x_105       EDGE_49_105  1.0
    x_105       EDGE_52_105  1.0
    x_105       EDGE_6_105  1.0
    x_105       EDGE_94_105  1.0
    x_105       EDGE_36_105  1.0
    x_105       EDGE_50_105  1.0
    x_105       EDGE_81_105  1.0
    x_105       EDGE_34_105  1.0
    x_105       EDGE_95_105  1.0
    x_105       EDGE_67_105  1.0
    x_105       EDGE_14_105  1.0
    x_105       EDGE_9_105  1.0
    x_105       EDGE_31_105  1.0
    x_105       EDGE_12_105  1.0
    x_105       EDGE_75_105  1.0
    x_105       EDGE_62_105  1.0
    x_105       EDGE_26_105  1.0
    x_105       EDGE_40_105  1.0
    x_105       EDGE_70_105  1.0
    x_105       EDGE_54_105  1.0
    x_105       EDGE_85_105  1.0
    x_105       EDGE_87_105  1.0
    x_106       OBJ       -48
    x_106       EDGE_106_107  1.0
    x_106       EDGE_16_106  1.0
    x_106       EDGE_82_106  1.0
    x_106       EDGE_33_106  1.0
    x_106       EDGE_36_106  1.0
    x_106       EDGE_106_109  1.0
    x_106       EDGE_72_106  1.0
    x_106       EDGE_102_106  1.0
    x_106       EDGE_34_106  1.0
    x_106       EDGE_103_106  1.0
    x_106       EDGE_84_106  1.0
    x_106       EDGE_30_106  1.0
    x_106       EDGE_25_106  1.0
    x_106       EDGE_28_106  1.0
    x_106       EDGE_80_106  1.0
    x_106       EDGE_15_106  1.0
    x_106       EDGE_48_106  1.0
    x_106       EDGE_23_106  1.0
    x_106       EDGE_4_106  1.0
    x_106       EDGE_26_106  1.0
    x_106       EDGE_37_106  1.0
    x_106       EDGE_40_106  1.0
    x_106       EDGE_70_106  1.0
    x_106       EDGE_21_106  1.0
    x_106       EDGE_90_106  1.0
    x_106       EDGE_77_106  1.0
    x_106       EDGE_88_106  1.0
    x_106       EDGE_91_106  1.0
    x_106       EDGE_2_106  1.0
    x_107       OBJ       -63
    x_107       EDGE_27_107  1.0
    x_107       EDGE_106_107  1.0
    x_107       EDGE_57_107  1.0
    x_107       EDGE_87_107  1.0
    x_107       EDGE_60_107  1.0
    x_107       EDGE_104_107  1.0
    x_107       EDGE_58_107  1.0
    x_107       EDGE_18_107  1.0
    x_107       EDGE_103_107  1.0
    x_107       EDGE_2_107  1.0
    x_107       EDGE_5_107  1.0
    x_107       EDGE_35_107  1.0
    x_107       EDGE_22_107  1.0
    x_107       EDGE_3_107  1.0
    x_107       EDGE_63_107  1.0
    x_107       EDGE_55_107  1.0
    x_107       EDGE_6_107  1.0
    x_107       EDGE_85_107  1.0
    x_107       EDGE_17_107  1.0
    x_107       EDGE_50_107  1.0
    x_107       EDGE_34_107  1.0
    x_107       EDGE_84_107  1.0
    x_107       EDGE_30_107  1.0
    x_107       EDGE_14_107  1.0
    x_107       EDGE_28_107  1.0
    x_107       EDGE_45_107  1.0
    x_107       EDGE_48_107  1.0
    x_107       EDGE_29_107  1.0
    x_107       EDGE_79_107  1.0
    x_107       EDGE_96_107  1.0
    x_107       EDGE_89_107  1.0
    x_107       EDGE_70_107  1.0
    x_107       EDGE_43_107  1.0
    x_108       OBJ       -94
    x_108       EDGE_5_108  1.0
    x_108       EDGE_37_108  1.0
    x_108       EDGE_19_108  1.0
    x_108       EDGE_21_108  1.0
    x_108       EDGE_85_108  1.0
    x_108       EDGE_36_108  1.0
    x_108       EDGE_103_108  1.0
    x_108       EDGE_2_108  1.0
    x_108       EDGE_14_108  1.0
    x_108       EDGE_44_108  1.0
    x_108       EDGE_16_108  1.0
    x_108       EDGE_80_108  1.0
    x_108       EDGE_64_108  1.0
    x_108       EDGE_97_108  1.0
    x_108       EDGE_62_108  1.0
    x_108       EDGE_65_108  1.0
    x_108       EDGE_98_108  1.0
    x_108       EDGE_96_108  1.0
    x_108       EDGE_26_108  1.0
    x_108       EDGE_108_109  1.0
    x_108       EDGE_40_108  1.0
    x_108       EDGE_42_108  1.0
    x_108       EDGE_24_108  1.0
    x_108       EDGE_54_108  1.0
    x_108       EDGE_27_108  1.0
    x_108       EDGE_8_108  1.0
    x_108       EDGE_60_108  1.0
    x_108       EDGE_93_108  1.0
    x_109       OBJ       -4
    x_109       EDGE_70_109  1.0
    x_109       EDGE_54_109  1.0
    x_109       EDGE_27_109  1.0
    x_109       EDGE_106_109  1.0
    x_109       EDGE_60_109  1.0
    x_109       EDGE_90_109  1.0
    x_109       EDGE_104_109  1.0
    x_109       EDGE_91_109  1.0
    x_109       EDGE_2_109  1.0
    x_109       EDGE_49_109  1.0
    x_109       EDGE_6_109  1.0
    x_109       EDGE_17_109  1.0
    x_109       EDGE_69_109  1.0
    x_109       EDGE_72_109  1.0
    x_109       EDGE_83_109  1.0
    x_109       EDGE_34_109  1.0
    x_109       EDGE_67_109  1.0
    x_109       EDGE_30_109  1.0
    x_109       EDGE_11_109  1.0
    x_109       EDGE_47_109  1.0
    x_109       EDGE_9_109  1.0
    x_109       EDGE_61_109  1.0
    x_109       EDGE_12_109  1.0
    x_109       EDGE_64_109  1.0
    x_109       EDGE_45_109  1.0
    x_109       EDGE_97_109  1.0
    x_109       EDGE_108_109  1.0
    x_109       EDGE_96_109  1.0
RHS
    RHS1      EDGE_16_93  1.0
    RHS1      EDGE_29_32  1.0
    RHS1      EDGE_47_80  1.0
    RHS1      EDGE_40_41  1.0
    RHS1      EDGE_29_68  1.0
    RHS1      EDGE_21_64  1.0
    RHS1      EDGE_27_107  1.0
    RHS1      EDGE_73_74  1.0
    RHS1      EDGE_25_34  1.0
    RHS1      EDGE_3_15  1.0
    RHS1      EDGE_20_104  1.0
    RHS1      EDGE_106_107  1.0
    RHS1      EDGE_16_70  1.0
    RHS1      EDGE_36_48  1.0
    RHS1      EDGE_55_61  1.0
    RHS1      EDGE_16_106  1.0
    RHS1      EDGE_17_71  1.0
    RHS1      EDGE_57_107  1.0
    RHS1      EDGE_9_67  1.0
    RHS1      EDGE_69_81  1.0
    RHS1      EDGE_48_58  1.0
    RHS1      EDGE_21_41  1.0
    RHS1      EDGE_40_54  1.0
    RHS1      EDGE_42_100  1.0
    RHS1      EDGE_81_91  1.0
    RHS1      EDGE_54_74  1.0
    RHS1      EDGE_73_87  1.0
    RHS1      EDGE_39_94  1.0
    RHS1      EDGE_12_77  1.0
    RHS1      EDGE_87_107  1.0
    RHS1      EDGE_32_91  1.0
    RHS1      EDGE_16_83  1.0
    RHS1      EDGE_36_61  1.0
    RHS1      EDGE_76_97  1.0
    RHS1      EDGE_5_73  1.0
    RHS1      EDGE_58_85  1.0
    RHS1      EDGE_69_94  1.0
    RHS1      EDGE_30_102  1.0
    RHS1      EDGE_3_5  1.0
    RHS1      EDGE_54_87  1.0
    RHS1      EDGE_12_90  1.0
    RHS1      EDGE_31_103  1.0
    RHS1      EDGE_32_68  1.0
    RHS1      EDGE_23_99  1.0
    RHS1      EDGE_43_77  1.0
    RHS1      EDGE_46_88  1.0
    RHS1      EDGE_65_101  1.0
    RHS1      EDGE_61_67  1.0
    RHS1      EDGE_7_96  1.0
    RHS1      EDGE_6_51  1.0
    RHS1      EDGE_50_94  1.0
    RHS1      EDGE_10_21  1.0
    RHS1      EDGE_91_95  1.0
    RHS1      EDGE_42_90  1.0
    RHS1      EDGE_61_103  1.0
    RHS1      EDGE_8_97  1.0
    RHS1      EDGE_94_100  1.0
    RHS1      EDGE_73_77  1.0
    RHS1      EDGE_60_107  1.0
    RHS1      EDGE_11_102  1.0
    RHS1      EDGE_13_32  1.0
    RHS1      EDGE_31_80  1.0
    RHS1      EDGE_4_63  1.0
    RHS1      EDGE_32_45  1.0
    RHS1      EDGE_84_92  1.0
    RHS1      EDGE_87_97  1.0
    RHS1      EDGE_65_78  1.0
    RHS1      EDGE_57_74  1.0
    RHS1      EDGE_9_34  1.0
    RHS1      EDGE_28_47  1.0
    RHS1      EDGE_68_83  1.0
    RHS1      EDGE_88_98  1.0
    RHS1      EDGE_5_63  1.0
    RHS1      EDGE_38_97  1.0
    RHS1      EDGE_39_61  1.0
    RHS1      EDGE_31_57  1.0
    RHS1      EDGE_12_80  1.0
    RHS1      EDGE_13_45  1.0
    RHS1      EDGE_53_81  1.0
    RHS1      EDGE_72_94  1.0
    RHS1      EDGE_23_89  1.0
    RHS1      EDGE_64_90  1.0
    RHS1      EDGE_84_105  1.0
    RHS1      EDGE_56_86  1.0
    RHS1      EDGE_35_63  1.0
    RHS1      EDGE_22_93  1.0
    RHS1      EDGE_5_40  1.0
    RHS1      EDGE_65_91  1.0
    RHS1      EDGE_49_83  1.0
    RHS1      EDGE_31_34  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_2_7  1.0
    RHS1      EDGE_19_96  1.0
    RHS1      EDGE_11_92  1.0
    RHS1      EDGE_31_70  1.0
    RHS1      EDGE_32_35  1.0
    RHS1      EDGE_23_66  1.0
    RHS1      EDGE_24_31  1.0
    RHS1      EDGE_1_47  1.0
    RHS1      EDGE_45_90  1.0
    RHS1      EDGE_65_68  1.0
    RHS1      EDGE_76_77  1.0
    RHS1      EDGE_14_102  1.0
    RHS1      EDGE_6_18  1.0
    RHS1      EDGE_50_61  1.0
    RHS1      EDGE_90_97  1.0
    RHS1      EDGE_82_93  1.0
    RHS1      EDGE_15_103  1.0
    RHS1      EDGE_61_70  1.0
    RHS1      EDGE_19_73  1.0
    RHS1      EDGE_31_47  1.0
    RHS1      EDGE_1_24  1.0
    RHS1      EDGE_13_35  1.0
    RHS1      EDGE_25_89  1.0
    RHS1      EDGE_64_80  1.0
    RHS1      EDGE_56_76  1.0
    RHS1      EDGE_26_53  1.0
    RHS1      EDGE_5_30  1.0
    RHS1      EDGE_49_73  1.0
    RHS1      EDGE_26_89  1.0
    RHS1      EDGE_19_50  1.0
    RHS1      EDGE_82_106  1.0
    RHS1      EDGE_21_96  1.0
    RHS1      EDGE_0_73  1.0
    RHS1      EDGE_33_70  1.0
    RHS1      EDGE_52_83  1.0
    RHS1      EDGE_16_17  1.0
    RHS1      EDGE_1_37  1.0
    RHS1      EDGE_33_106  1.0
    RHS1      EDGE_25_102  1.0
    RHS1      EDGE_53_84  1.0
    RHS1      EDGE_22_96  1.0
    RHS1      EDGE_26_66  1.0
    RHS1      EDGE_67_104  1.0
    RHS1      EDGE_59_100  1.0
    RHS1      EDGE_70_109  1.0
    RHS1      EDGE_63_70  1.0
    RHS1      EDGE_48_90  1.0
    RHS1      EDGE_40_86  1.0
    RHS1      EDGE_20_28  1.0
    RHS1      EDGE_60_64  1.0
    RHS1      EDGE_6_93  1.0
    RHS1      EDGE_39_41  1.0
    RHS1      EDGE_52_60  1.0
    RHS1      EDGE_31_37  1.0
    RHS1      EDGE_23_33  1.0
    RHS1      EDGE_104_107  1.0
    RHS1      EDGE_83_84  1.0
    RHS1      EDGE_75_80  1.0
    RHS1      EDGE_33_83  1.0
    RHS1      EDGE_52_96  1.0
    RHS1      EDGE_25_79  1.0
    RHS1      EDGE_64_70  1.0
    RHS1      EDGE_16_30  1.0
    RHS1      EDGE_3_60  1.0
    RHS1      EDGE_26_43  1.0
    RHS1      EDGE_86_94  1.0
    RHS1      EDGE_38_54  1.0
    RHS1      EDGE_89_99  1.0
    RHS1      EDGE_7_66  1.0
    RHS1      EDGE_8_31  1.0
    RHS1      EDGE_0_27  1.0
    RHS1      EDGE_18_75  1.0
    RHS1      EDGE_11_36  1.0
    RHS1      EDGE_63_83  1.0
    RHS1      EDGE_82_96  1.0
    RHS1      EDGE_29_90  1.0
    RHS1      EDGE_21_86  1.0
    RHS1      EDGE_40_99  1.0
    RHS1      EDGE_41_64  1.0
    RHS1      EDGE_60_77  1.0
    RHS1      EDGE_14_46  1.0
    RHS1      EDGE_34_61  1.0
    RHS1      EDGE_15_47  1.0
    RHS1      EDGE_55_83  1.0
    RHS1      EDGE_47_79  1.0
    RHS1      EDGE_18_52  1.0
    RHS1      EDGE_70_99  1.0
    RHS1      EDGE_17_93  1.0
    RHS1      EDGE_36_106  1.0
    RHS1      EDGE_28_102  1.0
    RHS1      EDGE_21_63  1.0
    RHS1      EDGE_0_40  1.0
    RHS1      EDGE_33_73  1.0
    RHS1      EDGE_51_90  1.0
    RHS1      EDGE_43_86  1.0
    RHS1      EDGE_14_59  1.0
    RHS1      EDGE_67_71  1.0
    RHS1      EDGE_16_105  1.0
    RHS1      EDGE_17_70  1.0
    RHS1      EDGE_55_96  1.0
    RHS1      EDGE_7_56  1.0
    RHS1      EDGE_0_17  1.0
    RHS1      EDGE_5_95  1.0
    RHS1      EDGE_58_107  1.0
    RHS1      EDGE_50_103  1.0
    RHS1      EDGE_21_76  1.0
    RHS1      EDGE_73_86  1.0
    RHS1      EDGE_3_27  1.0
    RHS1      EDGE_54_109  1.0
    RHS1      EDGE_16_82  1.0
    RHS1      EDGE_35_95  1.0
    RHS1      EDGE_36_60  1.0
    RHS1      EDGE_55_73  1.0
    RHS1      EDGE_1_102  1.0
    RHS1      EDGE_26_46  1.0
    RHS1      EDGE_67_84  1.0
    RHS1      EDGE_17_83  1.0
    RHS1      EDGE_28_92  1.0
    RHS1      EDGE_69_93  1.0
    RHS1      EDGE_5_108  1.0
    RHS1      EDGE_54_86  1.0
    RHS1      EDGE_33_63  1.0
    RHS1      EDGE_73_99  1.0
    RHS1      EDGE_31_102  1.0
    RHS1      EDGE_66_96  1.0
    RHS1      EDGE_55_86  1.0
    RHS1      EDGE_6_50  1.0
    RHS1      EDGE_50_93  1.0
    RHS1      EDGE_21_66  1.0
    RHS1      EDGE_61_102  1.0
    RHS1      EDGE_27_109  1.0
    RHS1      EDGE_25_36  1.0
    RHS1      EDGE_2_52  1.0
    RHS1      EDGE_3_17  1.0
    RHS1      EDGE_95_100  1.0
    RHS1      EDGE_106_109  1.0
    RHS1      EDGE_13_67  1.0
    RHS1      EDGE_35_85  1.0
    RHS1      EDGE_28_46  1.0
    RHS1      EDGE_88_97  1.0
    RHS1      EDGE_38_96  1.0
    RHS1      EDGE_58_74  1.0
    RHS1      EDGE_49_105  1.0
    RHS1      EDGE_29_47  1.0
    RHS1      EDGE_40_56  1.0
    RHS1      EDGE_10_33  1.0
    RHS1      EDGE_32_57  1.0
    RHS1      EDGE_51_70  1.0
    RHS1      EDGE_24_53  1.0
    RHS1      EDGE_37_108  1.0
    RHS1      EDGE_65_90  1.0
    RHS1      EDGE_2_6  1.0
    RHS1      EDGE_11_91  1.0
    RHS1      EDGE_39_73  1.0
    RHS1      EDGE_4_88  1.0
    RHS1      EDGE_72_106  1.0
    RHS1      EDGE_24_66  1.0
    RHS1      EDGE_35_75  1.0
    RHS1      EDGE_36_40  1.0
    RHS1      EDGE_29_37  1.0
    RHS1      EDGE_15_102  1.0
    RHS1      EDGE_18_107  1.0
    RHS1      EDGE_39_50  1.0
    RHS1      EDGE_10_23  1.0
    RHS1      EDGE_42_92  1.0
    RHS1      EDGE_83_93  1.0
    RHS1      EDGE_102_106  1.0
    RHS1      EDGE_94_102  1.0
    RHS1      EDGE_19_108  1.0
    RHS1      EDGE_60_109  1.0
    RHS1      EDGE_39_86  1.0
    RHS1      EDGE_52_105  1.0
    RHS1      EDGE_12_69  1.0
    RHS1      EDGE_4_65  1.0
    RHS1      EDGE_23_78  1.0
    RHS1      EDGE_24_43  1.0
    RHS1      EDGE_51_60  1.0
    RHS1      EDGE_16_39  1.0
    RHS1      EDGE_103_107  1.0
    RHS1      EDGE_95_103  1.0
    RHS1      EDGE_87_99  1.0
    RHS1      EDGE_34_93  1.0
    RHS1      EDGE_45_102  1.0
    RHS1      EDGE_37_98  1.0
    RHS1      EDGE_17_40  1.0
    RHS1      EDGE_76_89  1.0
    RHS1      EDGE_9_36  1.0
    RHS1      EDGE_49_72  1.0
    RHS1      EDGE_79_100  1.0
    RHS1      EDGE_90_109  1.0
    RHS1      EDGE_8_76  1.0
    RHS1      EDGE_27_89  1.0
    RHS1      EDGE_0_72  1.0
    RHS1      EDGE_4_42  1.0
    RHS1      EDGE_1_36  1.0
    RHS1      EDGE_25_101  1.0
    RHS1      EDGE_4_78  1.0
    RHS1      EDGE_14_91  1.0
    RHS1      EDGE_34_106  1.0
    RHS1      EDGE_46_80  1.0
    RHS1      EDGE_42_46  1.0
    RHS1      EDGE_15_92  1.0
    RHS1      EDGE_7_88  1.0
    RHS1      EDGE_19_62  1.0
    RHS1      EDGE_20_27  1.0
    RHS1      EDGE_39_40  1.0
    RHS1      EDGE_2_9  1.0
    RHS1      EDGE_21_108  1.0
    RHS1      EDGE_12_59  1.0
    RHS1      EDGE_72_73  1.0
    RHS1      EDGE_24_33  1.0
    RHS1      EDGE_43_46  1.0
    RHS1      EDGE_53_96  1.0
    RHS1      EDGE_45_92  1.0
    RHS1      EDGE_37_88  1.0
    RHS1      EDGE_17_30  1.0
    RHS1      EDGE_57_66  1.0
    RHS1      EDGE_97_102  1.0
    RHS1      EDGE_26_78  1.0
    RHS1      EDGE_27_43  1.0
    RHS1      EDGE_18_74  1.0
    RHS1      EDGE_90_99  1.0
    RHS1      EDGE_82_95  1.0
    RHS1      EDGE_40_98  1.0
    RHS1      EDGE_20_40  1.0
    RHS1      EDGE_6_105  1.0
    RHS1      EDGE_39_53  1.0
    RHS1      EDGE_4_32  1.0
    RHS1      EDGE_75_92  1.0
    RHS1      EDGE_94_105  1.0
    RHS1      EDGE_41_99  1.0
    RHS1      EDGE_25_91  1.0
    RHS1      EDGE_53_73  1.0
    RHS1      EDGE_45_69  1.0
    RHS1      EDGE_2_107  1.0
    RHS1      EDGE_15_46  1.0
    RHS1      EDGE_18_51  1.0
    RHS1      EDGE_37_101  1.0
    RHS1      EDGE_38_66  1.0
    RHS1      EDGE_36_105  1.0
    RHS1      EDGE_26_91  1.0
    RHS1      EDGE_19_52  1.0
    RHS1      EDGE_11_48  1.0
    RHS1      EDGE_71_99  1.0
    RHS1      EDGE_63_95  1.0
    RHS1      EDGE_21_98  1.0
    RHS1      EDGE_41_76  1.0
    RHS1      EDGE_52_85  1.0
    RHS1      EDGE_22_62  1.0
    RHS1      EDGE_14_58  1.0
    RHS1      EDGE_3_85  1.0
    RHS1      EDGE_9_16  1.0
    RHS1      EDGE_22_98  1.0
    RHS1      EDGE_55_95  1.0
    RHS1      EDGE_11_25  1.0
    RHS1      EDGE_52_62  1.0
    RHS1      EDGE_104_109  1.0
    RHS1      EDGE_1_16  1.0
    RHS1      EDGE_25_81  1.0
    RHS1      EDGE_64_72  1.0
    RHS1      EDGE_14_71  1.0
    RHS1      EDGE_26_45  1.0
    RHS1      EDGE_40_65  1.0
    RHS1      EDGE_5_107  1.0
    RHS1      EDGE_21_88  1.0
    RHS1      EDGE_41_66  1.0
    RHS1      EDGE_52_75  1.0
    RHS1      EDGE_4_35  1.0
    RHS1      EDGE_3_39  1.0
    RHS1      EDGE_14_48  1.0
    RHS1      EDGE_34_63  1.0
    RHS1      EDGE_85_108  1.0
    RHS1      EDGE_37_68  1.0
    RHS1      EDGE_35_107  1.0
    RHS1      EDGE_36_72  1.0
    RHS1      EDGE_26_58  1.0
    RHS1      EDGE_18_54  1.0
    RHS1      EDGE_70_101  1.0
    RHS1      EDGE_36_108  1.0
    RHS1      EDGE_41_43  1.0
    RHS1      EDGE_44_48  1.0
    RHS1      EDGE_1_6  1.0
    RHS1      EDGE_54_98  1.0
    RHS1      EDGE_33_75  1.0
    RHS1      EDGE_34_40  1.0
    RHS1      EDGE_45_49  1.0
    RHS1      EDGE_37_45  1.0
    RHS1      EDGE_2_87  1.0
    RHS1      EDGE_22_65  1.0
    RHS1      EDGE_15_26  1.0
    RHS1      EDGE_26_35  1.0
    RHS1      EDGE_18_31  1.0
    RHS1      EDGE_78_82  1.0
    RHS1      EDGE_55_98  1.0
    RHS1      EDGE_29_46  1.0
    RHS1      EDGE_48_59  1.0
    RHS1      EDGE_9_104  1.0
    RHS1      EDGE_50_105  1.0
    RHS1      EDGE_21_78  1.0
    RHS1      EDGE_73_88  1.0
    RHS1      EDGE_25_48  1.0
    RHS1      EDGE_31_91  1.0
    RHS1      EDGE_2_64  1.0
    RHS1      EDGE_3_29  1.0
    RHS1      EDGE_22_42  1.0
    RHS1      EDGE_13_79  1.0
    RHS1      EDGE_15_39  1.0
    RHS1      EDGE_29_59  1.0
    RHS1      EDGE_61_91  1.0
    RHS1      EDGE_6_75  1.0
    RHS1      EDGE_3_6  1.0
    RHS1      EDGE_62_92  1.0
    RHS1      EDGE_81_105  1.0
    RHS1      EDGE_14_51  1.0
    RHS1      EDGE_7_12  1.0
    RHS1      EDGE_13_92  1.0
    RHS1      EDGE_24_101  1.0
    RHS1      EDGE_47_84  1.0
    RHS1      EDGE_0_9  1.0
    RHS1      EDGE_42_91  1.0
    RHS1      EDGE_21_68  1.0
    RHS1      EDGE_61_104  1.0
    RHS1      EDGE_62_69  1.0
    RHS1      EDGE_8_98  1.0
    RHS1      EDGE_81_82  1.0
    RHS1      EDGE_39_85  1.0
    RHS1      EDGE_2_54  1.0
    RHS1      EDGE_43_55  1.0
    RHS1      EDGE_84_93  1.0
    RHS1      EDGE_103_106  1.0
    RHS1      EDGE_95_102  1.0
    RHS1      EDGE_24_78  1.0
    RHS1      EDGE_43_91  1.0
    RHS1      EDGE_16_74  1.0
    RHS1      EDGE_17_39  1.0
    RHS1      EDGE_35_87  1.0
    RHS1      EDGE_36_52  1.0
    RHS1      EDGE_96_103  1.0
    RHS1      EDGE_6_29  1.0
    RHS1      EDGE_17_75  1.0
    RHS1      EDGE_77_89  1.0
    RHS1      EDGE_30_93  1.0
    RHS1      EDGE_10_35  1.0
    RHS1      EDGE_91_109  1.0
    RHS1      EDGE_73_91  1.0
    RHS1      EDGE_13_46  1.0
    RHS1      EDGE_31_94  1.0
    RHS1      EDGE_23_90  1.0
    RHS1      EDGE_43_68  1.0
    RHS1      EDGE_84_106  1.0
    RHS1      EDGE_34_105  1.0
    RHS1      EDGE_13_82  1.0
    RHS1      EDGE_16_87  1.0
    RHS1      EDGE_9_48  1.0
    RHS1      EDGE_49_84  1.0
    RHS1      EDGE_26_100  1.0
    RHS1      EDGE_6_42  1.0
    RHS1      EDGE_61_94  1.0
    RHS1      EDGE_0_84  1.0
    RHS1      EDGE_19_97  1.0
    RHS1      EDGE_20_62  1.0
    RHS1      EDGE_11_93  1.0
    RHS1      EDGE_39_75  1.0
    RHS1      EDGE_30_106  1.0
    RHS1      EDGE_45_91  1.0
    RHS1      EDGE_56_100  1.0
    RHS1      EDGE_17_29  1.0
    RHS1      EDGE_22_107  1.0
    RHS1      EDGE_14_103  1.0
    RHS1      EDGE_6_19  1.0
    RHS1      EDGE_50_62  1.0
    RHS1      EDGE_7_100  1.0
    RHS1      EDGE_11_70  1.0
    RHS1      EDGE_83_95  1.0
    RHS1      EDGE_8_101  1.0
    RHS1      EDGE_95_105  1.0
    RHS1      EDGE_1_61  1.0
    RHS1      EDGE_45_104  1.0
    RHS1      EDGE_46_69  1.0
    RHS1      EDGE_37_100  1.0
    RHS1      EDGE_65_82  1.0
    RHS1      EDGE_17_42  1.0
    RHS1      EDGE_3_107  1.0
    RHS1      EDGE_15_81  1.0
    RHS1      EDGE_38_101  1.0
    RHS1      EDGE_58_79  1.0
    RHS1      EDGE_30_60  1.0
    RHS1      EDGE_20_52  1.0
    RHS1      EDGE_31_61  1.0
    RHS1      EDGE_75_104  1.0
    RHS1      EDGE_34_72  1.0
    RHS1      EDGE_56_90  1.0
    RHS1      EDGE_17_19  1.0
    RHS1      EDGE_3_84  1.0
    RHS1      EDGE_67_105  1.0
    RHS1      EDGE_57_91  1.0
    RHS1      EDGE_50_52  1.0
    RHS1      EDGE_42_48  1.0
    RHS1      EDGE_8_55  1.0
    RHS1      EDGE_11_60  1.0
    RHS1      EDGE_39_42  1.0
    RHS1      EDGE_63_107  1.0
    RHS1      EDGE_44_93  1.0
    RHS1      EDGE_16_31  1.0
    RHS1      EDGE_1_51  1.0
    RHS1      EDGE_87_91  1.0
    RHS1      EDGE_34_85  1.0
    RHS1      EDGE_53_98  1.0
    RHS1      EDGE_38_55  1.0
    RHS1      EDGE_97_104  1.0
    RHS1      EDGE_9_28  1.0
    RHS1      EDGE_55_107  1.0
    RHS1      EDGE_26_80  1.0
    RHS1      EDGE_79_92  1.0
    RHS1      EDGE_82_97  1.0
    RHS1      EDGE_29_91  1.0
    RHS1      EDGE_40_100  1.0
    RHS1      EDGE_20_42  1.0
    RHS1      EDGE_6_107  1.0
    RHS1      EDGE_52_74  1.0
    RHS1      EDGE_83_98  1.0
    RHS1      EDGE_75_94  1.0
    RHS1      EDGE_45_71  1.0
    RHS1      EDGE_85_107  1.0
    RHS1      EDGE_64_84  1.0
    RHS1      EDGE_2_109  1.0
    RHS1      EDGE_3_74  1.0
    RHS1      EDGE_14_83  1.0
    RHS1      EDGE_67_95  1.0
    RHS1      EDGE_59_91  1.0
    RHS1      EDGE_7_80  1.0
    RHS1      EDGE_48_81  1.0
    RHS1      EDGE_27_58  1.0
    RHS1      EDGE_18_89  1.0
    RHS1      EDGE_21_100  1.0
    RHS1      EDGE_41_78  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_33_74  1.0
    RHS1      EDGE_45_48  1.0
    RHS1      EDGE_24_25  1.0
    RHS1      EDGE_37_44  1.0
    RHS1      EDGE_34_75  1.0
    RHS1      EDGE_25_106  1.0
    RHS1      EDGE_37_80  1.0
    RHS1      EDGE_55_97  1.0
    RHS1      EDGE_27_35  1.0
    RHS1      EDGE_59_104  1.0
    RHS1      EDGE_17_107  1.0
    RHS1      EDGE_90_91  1.0
    RHS1      EDGE_48_94  1.0
    RHS1      EDGE_40_90  1.0
    RHS1      EDGE_52_64  1.0
    RHS1      EDGE_23_37  1.0
    RHS1      EDGE_1_18  1.0
    RHS1      EDGE_74_88  1.0
    RHS1      EDGE_53_65  1.0
    RHS1      EDGE_56_70  1.0
    RHS1      EDGE_43_100  1.0
    RHS1      EDGE_22_77  1.0
    RHS1      EDGE_15_38  1.0
    RHS1      EDGE_67_85  1.0
    RHS1      EDGE_59_81  1.0
    RHS1      EDGE_70_90  1.0
    RHS1      EDGE_36_97  1.0
    RHS1      EDGE_29_58  1.0
    RHS1      EDGE_8_35  1.0
    RHS1      EDGE_0_31  1.0
    RHS1      EDGE_25_60  1.0
    RHS1      EDGE_44_73  1.0
    RHS1      EDGE_10_80  1.0
    RHS1      EDGE_14_50  1.0
    RHS1      EDGE_66_97  1.0
    RHS1      EDGE_13_91  1.0
    RHS1      EDGE_16_96  1.0
    RHS1      EDGE_18_56  1.0
    RHS1      EDGE_17_97  1.0
    RHS1      EDGE_28_106  1.0
    RHS1      EDGE_2_53  1.0
    RHS1      EDGE_62_104  1.0
    RHS1      EDGE_25_73  1.0
    RHS1      EDGE_45_51  1.0
    RHS1      EDGE_32_81  1.0
    RHS1      EDGE_51_94  1.0
    RHS1      EDGE_24_77  1.0
    RHS1      EDGE_15_28  1.0
    RHS1      EDGE_96_102  1.0
    RHS1      EDGE_18_33  1.0
    RHS1      EDGE_0_21  1.0
    RHS1      EDGE_5_99  1.0
    RHS1      EDGE_50_107  1.0
    RHS1      EDGE_10_34  1.0
    RHS1      EDGE_2_66  1.0
    RHS1      EDGE_16_86  1.0
    RHS1      EDGE_17_51  1.0
    RHS1      EDGE_6_41  1.0
    RHS1      EDGE_9_83  1.0
    RHS1      EDGE_50_84  1.0
    RHS1      EDGE_77_101  1.0
    RHS1      EDGE_29_61  1.0
    RHS1      EDGE_69_97  1.0
    RHS1      EDGE_80_106  1.0
    RHS1      EDGE_2_43  1.0
    RHS1      EDGE_4_89  1.0
    RHS1      EDGE_51_84  1.0
    RHS1      EDGE_47_50  1.0
    RHS1      EDGE_18_23  1.0
    RHS1      EDGE_69_74  1.0
    RHS1      EDGE_48_51  1.0
    RHS1      EDGE_21_34  1.0
    RHS1      EDGE_92_94  1.0
    RHS1      EDGE_2_20  1.0
    RHS1      EDGE_8_100  1.0
    RHS1      EDGE_20_74  1.0
    RHS1      EDGE_39_87  1.0
    RHS1      EDGE_2_56  1.0
    RHS1      EDGE_103_108  1.0
    RHS1      EDGE_14_30  1.0
    RHS1      EDGE_4_102  1.0
    RHS1      EDGE_32_84  1.0
    RHS1      EDGE_24_80  1.0
    RHS1      EDGE_35_89  1.0
    RHS1      EDGE_28_50  1.0
    RHS1      EDGE_1_96  1.0
    RHS1      EDGE_9_73  1.0
    RHS1      EDGE_49_109  1.0
    RHS1      EDGE_61_83  1.0
    RHS1      EDGE_27_90  1.0
    RHS1      EDGE_11_82  1.0
    RHS1      EDGE_31_60  1.0
    RHS1      EDGE_2_33  1.0
    RHS1      EDGE_23_92  1.0
    RHS1      EDGE_24_57  1.0
    RHS1      EDGE_34_107  1.0
    RHS1      EDGE_57_90  1.0
    RHS1      EDGE_76_103  1.0
    RHS1      EDGE_7_89  1.0
    RHS1      EDGE_26_102  1.0
    RHS1      EDGE_6_44  1.0
    RHS1      EDGE_10_14  1.0
    RHS1      EDGE_42_83  1.0
    RHS1      EDGE_19_99  1.0
    RHS1      EDGE_20_64  1.0
    RHS1      EDGE_39_77  1.0
    RHS1      EDGE_32_38  1.0
    RHS1      EDGE_43_47  1.0
    RHS1      EDGE_34_84  1.0
    RHS1      EDGE_13_61  1.0
    RHS1      EDGE_24_70  1.0
    RHS1      EDGE_37_89  1.0
    RHS1      EDGE_28_40  1.0
    RHS1      EDGE_14_105  1.0
    RHS1      EDGE_26_79  1.0
    RHS1      EDGE_15_106  1.0
    RHS1      EDGE_7_102  1.0
    RHS1      EDGE_27_80  1.0
    RHS1      EDGE_11_72  1.0
    RHS1      EDGE_39_54  1.0
    RHS1      EDGE_2_23  1.0
    RHS1      EDGE_54_70  1.0
    RHS1      EDGE_1_27  1.0
    RHS1      EDGE_32_51  1.0
    RHS1      EDGE_84_98  1.0
    RHS1      EDGE_16_43  1.0
    RHS1      EDGE_2_108  1.0
    RHS1      EDGE_34_97  1.0
    RHS1      EDGE_42_73  1.0
    RHS1      EDGE_29_103  1.0
    RHS1      EDGE_8_80  1.0
    RHS1      EDGE_60_90  1.0
    RHS1      EDGE_52_86  1.0
    RHS1      EDGE_13_15  1.0
    RHS1      EDGE_31_63  1.0
    RHS1      EDGE_4_46  1.0
    RHS1      EDGE_16_20  1.0
    RHS1      EDGE_1_40  1.0
    RHS1      EDGE_34_74  1.0
    RHS1      EDGE_38_44  1.0
    RHS1      EDGE_56_92  1.0
    RHS1      EDGE_17_21  1.0
    RHS1      EDGE_14_95  1.0
    RHS1      EDGE_18_65  1.0
    RHS1      EDGE_49_89  1.0
    RHS1      EDGE_42_50  1.0
    RHS1      EDGE_15_96  1.0
    RHS1      EDGE_7_92  1.0
    RHS1      EDGE_83_87  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_25_82  1.0
    RHS1      EDGE_10_102  1.0
    RHS1      EDGE_56_69  1.0
    RHS1      EDGE_46_61  1.0
    RHS1      EDGE_89_102  1.0
    RHS1      EDGE_14_108  1.0
    RHS1      EDGE_8_34  1.0
    RHS1      EDGE_26_82  1.0
    RHS1      EDGE_18_78  1.0
    RHS1      EDGE_11_39  1.0
    RHS1      EDGE_48_106  1.0
    RHS1      EDGE_60_80  1.0
    RHS1      EDGE_6_109  1.0
    RHS1      EDGE_44_72  1.0
    RHS1      EDGE_23_49  1.0
    RHS1      EDGE_34_64  1.0
    RHS1      EDGE_74_100  1.0
    RHS1      EDGE_25_95  1.0
    RHS1      EDGE_53_77  1.0
    RHS1      EDGE_44_108  1.0
    RHS1      EDGE_56_82  1.0
    RHS1      EDGE_22_89  1.0
    RHS1      EDGE_26_59  1.0
    RHS1      EDGE_18_55  1.0
    RHS1      EDGE_70_102  1.0
    RHS1      EDGE_48_83  1.0
    RHS1      EDGE_0_43  1.0
    RHS1      EDGE_20_21  1.0
    RHS1      EDGE_71_103  1.0
    RHS1      EDGE_21_102  1.0
    RHS1      EDGE_1_7  1.0
    RHS1      EDGE_52_89  1.0
    RHS1      EDGE_45_50  1.0
    RHS1      EDGE_10_92  1.0
    RHS1      EDGE_56_59  1.0
    RHS1      EDGE_2_88  1.0
    RHS1      EDGE_3_53  1.0
    RHS1      EDGE_22_66  1.0
    RHS1      EDGE_26_36  1.0
    RHS1      EDGE_18_32  1.0
    RHS1      EDGE_16_108  1.0
    RHS1      EDGE_49_56  1.0
    RHS1      EDGE_55_99  1.0
    RHS1      EDGE_47_95  1.0
    RHS1      EDGE_0_20  1.0
    RHS1      EDGE_17_109  1.0
    RHS1      EDGE_9_105  1.0
    RHS1      EDGE_29_83  1.0
    RHS1      EDGE_21_79  1.0
    RHS1      EDGE_40_92  1.0
    RHS1      EDGE_52_66  1.0
    RHS1      EDGE_1_20  1.0
    RHS1      EDGE_34_54  1.0
    RHS1      EDGE_93_103  1.0
    RHS1      EDGE_3_66  1.0
    RHS1      EDGE_43_102  1.0
    RHS1      EDGE_14_75  1.0
    RHS1      EDGE_7_36  1.0
    RHS1      EDGE_78_96  1.0
    RHS1      EDGE_48_73  1.0
    RHS1      EDGE_21_56  1.0
    RHS1      EDGE_0_33  1.0
    RHS1      EDGE_41_70  1.0
    RHS1      EDGE_73_102  1.0
    RHS1      EDGE_44_75  1.0
    RHS1      EDGE_31_105  1.0
    RHS1      EDGE_51_83  1.0
    RHS1      EDGE_2_78  1.0
    RHS1      EDGE_3_43  1.0
    RHS1      EDGE_18_22  1.0
    RHS1      EDGE_0_10  1.0
    RHS1      EDGE_6_53  1.0
    RHS1      EDGE_58_100  1.0
    RHS1      EDGE_29_73  1.0
    RHS1      EDGE_69_109  1.0
    RHS1      EDGE_40_82  1.0
    RHS1      EDGE_41_47  1.0
    RHS1      EDGE_33_43  1.0
    RHS1      EDGE_4_16  1.0
    RHS1      EDGE_44_52  1.0
    RHS1      EDGE_12_105  1.0
    RHS1      EDGE_37_49  1.0
    RHS1      EDGE_51_96  1.0
    RHS1      EDGE_43_92  1.0
    RHS1      EDGE_15_30  1.0
    RHS1      EDGE_26_39  1.0
    RHS1      EDGE_5_65  1.0
    RHS1      EDGE_36_89  1.0
    RHS1      EDGE_29_50  1.0
    RHS1      EDGE_25_52  1.0
    RHS1      EDGE_23_91  1.0
    RHS1      EDGE_43_69  1.0
    RHS1      EDGE_84_107  1.0
    RHS1      EDGE_35_65  1.0
    RHS1      EDGE_1_72  1.0
    RHS1      EDGE_24_92  1.0
    RHS1      EDGE_16_88  1.0
    RHS1      EDGE_55_79  1.0
    RHS1      EDGE_58_90  1.0
    RHS1      EDGE_69_99  1.0
    RHS1      EDGE_80_108  1.0
    RHS1      EDGE_30_107  1.0
    RHS1      EDGE_31_72  1.0
    RHS1      EDGE_2_45  1.0
    RHS1      EDGE_62_96  1.0
    RHS1      EDGE_14_19  1.0
    RHS1      EDGE_12_95  1.0
    RHS1      EDGE_72_109  1.0
    RHS1      EDGE_23_104  1.0
    RHS1      EDGE_36_43  1.0
    RHS1      EDGE_1_85  1.0
    RHS1      EDGE_9_62  1.0
    RHS1      EDGE_48_53  1.0
    RHS1      EDGE_40_49  1.0
    RHS1      EDGE_27_79  1.0
    RHS1      EDGE_6_56  1.0
    RHS1      EDGE_2_22  1.0
    RHS1      EDGE_62_73  1.0
    RHS1      EDGE_25_42  1.0
    RHS1      EDGE_51_63  1.0
    RHS1      EDGE_35_55  1.0
    RHS1      EDGE_14_32  1.0
    RHS1      EDGE_16_78  1.0
    RHS1      EDGE_36_56  1.0
    RHS1      EDGE_9_39  1.0
    RHS1      EDGE_28_52  1.0
    RHS1      EDGE_21_49  1.0
    RHS1      EDGE_8_79  1.0
    RHS1      EDGE_10_39  1.0
    RHS1      EDGE_23_58  1.0
    RHS1      EDGE_83_109  1.0
    RHS1      EDGE_75_105  1.0
    RHS1      EDGE_54_82  1.0
    RHS1      EDGE_32_63  1.0
    RHS1      EDGE_34_109  1.0
    RHS1      EDGE_65_96  1.0
    RHS1      EDGE_17_56  1.0
    RHS1      EDGE_57_92  1.0
    RHS1      EDGE_9_52  1.0
    RHS1      EDGE_29_30  1.0
    RHS1      EDGE_6_46  1.0
    RHS1      EDGE_50_89  1.0
    RHS1      EDGE_83_86  1.0
    RHS1      EDGE_94_95  1.0
    RHS1      EDGE_12_62  1.0
    RHS1      EDGE_52_98  1.0
    RHS1      EDGE_32_40  1.0
    RHS1      EDGE_23_71  1.0
    RHS1      EDGE_87_92  1.0
    RHS1      EDGE_13_63  1.0
    RHS1      EDGE_53_99  1.0
    RHS1      EDGE_64_108  1.0
    RHS1      EDGE_65_73  1.0
    RHS1      EDGE_56_104  1.0
    RHS1      EDGE_68_78  1.0
    RHS1      EDGE_14_107  1.0
    RHS1      EDGE_6_23  1.0
    RHS1      EDGE_38_92  1.0
    RHS1      EDGE_79_93  1.0
    RHS1      EDGE_49_101  1.0
    RHS1      EDGE_69_79  1.0
    RHS1      EDGE_61_75  1.0
    RHS1      EDGE_19_78  1.0
    RHS1      EDGE_39_56  1.0
    RHS1      EDGE_91_103  1.0
    RHS1      EDGE_23_48  1.0
    RHS1      EDGE_41_102  1.0
    RHS1      EDGE_12_75  1.0
    RHS1      EDGE_53_76  1.0
    RHS1      EDGE_4_71  1.0
    RHS1      EDGE_35_58  1.0
    RHS1      EDGE_46_73  1.0
    RHS1      EDGE_7_81  1.0
    RHS1      EDGE_18_90  1.0
    RHS1      EDGE_71_102  1.0
    RHS1      EDGE_0_78  1.0
    RHS1      EDGE_41_79  1.0
    RHS1      EDGE_60_92  1.0
    RHS1      EDGE_52_88  1.0
    RHS1      EDGE_53_89  1.0
    RHS1      EDGE_46_50  1.0
    RHS1      EDGE_3_88  1.0
    RHS1      EDGE_22_101  1.0
    RHS1      EDGE_67_109  1.0
    RHS1      EDGE_82_88  1.0
    RHS1      EDGE_19_68  1.0
    RHS1      EDGE_6_98  1.0
    RHS1      EDGE_39_46  1.0
    RHS1      EDGE_30_77  1.0
    RHS1      EDGE_41_92  1.0
    RHS1      EDGE_33_88  1.0
    RHS1      EDGE_34_53  1.0
    RHS1      EDGE_38_59  1.0
    RHS1      EDGE_57_72  1.0
    RHS1      EDGE_97_108  1.0
    RHS1      EDGE_89_104  1.0
    RHS1      EDGE_36_98  1.0
    RHS1      EDGE_0_32  1.0
    RHS1      EDGE_63_88  1.0
    RHS1      EDGE_21_91  1.0
    RHS1      EDGE_12_42  1.0
    RHS1      EDGE_2_77  1.0
    RHS1      EDGE_22_55  1.0
    RHS1      EDGE_34_66  1.0
    RHS1      EDGE_74_102  1.0
    RHS1      EDGE_53_79  1.0
    RHS1      EDGE_45_75  1.0
    RHS1      EDGE_14_87  1.0
    RHS1      EDGE_26_61  1.0
    RHS1      EDGE_11_18  1.0
    RHS1      EDGE_28_107  1.0
    RHS1      EDGE_29_72  1.0
    RHS1      EDGE_6_88  1.0
    RHS1      EDGE_31_32  1.0
    RHS1      EDGE_62_105  1.0
    RHS1      EDGE_34_43  1.0
    RHS1      EDGE_45_52  1.0
    RHS1      EDGE_64_65  1.0
    RHS1      EDGE_37_48  1.0
    RHS1      EDGE_56_61  1.0
    RHS1      EDGE_7_25  1.0
    RHS1      EDGE_38_49  1.0
    RHS1      EDGE_48_62  1.0
    RHS1      EDGE_30_44  1.0
    RHS1      EDGE_71_82  1.0
    RHS1      EDGE_40_94  1.0
    RHS1      EDGE_41_59  1.0
    RHS1      EDGE_33_55  1.0
    RHS1      EDGE_6_101  1.0
    RHS1      EDGE_25_51  1.0
    RHS1      EDGE_44_64  1.0
    RHS1      EDGE_2_67  1.0
    RHS1      EDGE_22_45  1.0
    RHS1      EDGE_34_56  1.0
    RHS1      EDGE_66_88  1.0
    RHS1      EDGE_24_91  1.0
    RHS1      EDGE_55_78  1.0
    RHS1      EDGE_26_51  1.0
    RHS1      EDGE_67_89  1.0
    RHS1      EDGE_36_101  1.0
    RHS1      EDGE_6_78  1.0
    RHS1      EDGE_73_104  1.0
    RHS1      EDGE_43_81  1.0
    RHS1      EDGE_15_19  1.0
    RHS1      EDGE_26_28  1.0
    RHS1      EDGE_13_95  1.0
    RHS1      EDGE_55_91  1.0
    RHS1      EDGE_28_74  1.0
    RHS1      EDGE_48_52  1.0
    RHS1      EDGE_5_90  1.0
    RHS1      EDGE_6_55  1.0
    RHS1      EDGE_92_95  1.0
    RHS1      EDGE_9_97  1.0
    RHS1      EDGE_50_98  1.0
    RHS1      EDGE_29_75  1.0
    RHS1      EDGE_21_71  1.0
    RHS1      EDGE_52_58  1.0
    RHS1      EDGE_25_41  1.0
    RHS1      EDGE_10_61  1.0
    RHS1      EDGE_3_22  1.0
    RHS1      EDGE_62_108  1.0
    RHS1      EDGE_22_35  1.0
    RHS1      EDGE_13_72  1.0
    RHS1      EDGE_16_77  1.0
    RHS1      EDGE_35_90  1.0
    RHS1      EDGE_36_55  1.0
    RHS1      EDGE_15_32  1.0
    RHS1      EDGE_55_68  1.0
    RHS1      EDGE_1_97  1.0
    RHS1      EDGE_88_102  1.0
    RHS1      EDGE_18_37  1.0
    RHS1      EDGE_59_75  1.0
    RHS1      EDGE_17_78  1.0
    RHS1      EDGE_28_87  1.0
    RHS1      EDGE_5_103  1.0
    RHS1      EDGE_6_68  1.0
    RHS1      EDGE_2_34  1.0
    RHS1      EDGE_81_98  1.0
    RHS1      EDGE_54_81  1.0
    RHS1      EDGE_51_75  1.0
    RHS1      EDGE_43_71  1.0
    RHS1      EDGE_1_74  1.0
    RHS1      EDGE_35_103  1.0
    RHS1      EDGE_47_77  1.0
    RHS1      EDGE_5_80  1.0
    RHS1      EDGE_10_15  1.0
    RHS1      EDGE_69_101  1.0
    RHS1      EDGE_42_84  1.0
    RHS1      EDGE_30_109  1.0
    RHS1      EDGE_51_52  1.0
    RHS1      EDGE_3_12  1.0
    RHS1      EDGE_20_101  1.0
    RHS1      EDGE_12_97  1.0
    RHS1      EDGE_23_106  1.0
    RHS1      EDGE_17_32  1.0
    RHS1      EDGE_76_81  1.0
    RHS1      EDGE_88_92  1.0
    RHS1      EDGE_5_57  1.0
    RHS1      EDGE_65_108  1.0
    RHS1      EDGE_80_87  1.0
    RHS1      EDGE_10_28  1.0
    RHS1      EDGE_2_24  1.0
    RHS1      EDGE_54_71  1.0
    RHS1      EDGE_73_84  1.0
    RHS1      EDGE_11_109  1.0
    RHS1      EDGE_12_74  1.0
    RHS1      EDGE_39_91  1.0
    RHS1      EDGE_32_52  1.0
    RHS1      EDGE_72_88  1.0
    RHS1      EDGE_24_48  1.0
    RHS1      EDGE_84_99  1.0
    RHS1      EDGE_35_57  1.0
    RHS1      EDGE_4_106  1.0
    RHS1      EDGE_45_107  1.0
    RHS1      EDGE_5_34  1.0
    RHS1      EDGE_36_58  1.0
    RHS1      EDGE_76_94  1.0
    RHS1      EDGE_61_87  1.0
    RHS1      EDGE_19_90  1.0
    RHS1      EDGE_39_68  1.0
    RHS1      EDGE_30_99  1.0
    RHS1      EDGE_17_22  1.0
    RHS1      EDGE_5_47  1.0
    RHS1      EDGE_6_12  1.0
    RHS1      EDGE_46_85  1.0
    RHS1      EDGE_38_81  1.0
    RHS1      EDGE_65_98  1.0
    RHS1      EDGE_26_106  1.0
    RHS1      EDGE_39_45  1.0
    RHS1      EDGE_94_97  1.0
    RHS1      EDGE_20_68  1.0
    RHS1      EDGE_13_29  1.0
    RHS1      EDGE_72_78  1.0
    RHS1      EDGE_23_73  1.0
    RHS1      EDGE_84_89  1.0
    RHS1      EDGE_17_35  1.0
    RHS1      EDGE_57_71  1.0
    RHS1      EDGE_28_44  1.0
    RHS1      EDGE_18_79  1.0
    RHS1      EDGE_98_108  1.0
    RHS1      EDGE_30_53  1.0
    RHS1      EDGE_50_68  1.0
    RHS1      EDGE_90_104  1.0
    RHS1      EDGE_48_107  1.0
    RHS1      EDGE_4_37  1.0
    RHS1      EDGE_53_78  1.0
    RHS1      EDGE_45_74  1.0
    RHS1      EDGE_64_87  1.0
    RHS1      EDGE_37_70  1.0
    RHS1      EDGE_56_83  1.0
    RHS1      EDGE_3_77  1.0
    RHS1      EDGE_26_60  1.0
    RHS1      EDGE_37_106  1.0
    RHS1      EDGE_38_71  1.0
    RHS1      EDGE_57_84  1.0
    RHS1      EDGE_26_96  1.0
    RHS1      EDGE_12_18  1.0
    RHS1      EDGE_30_66  1.0
    RHS1      EDGE_71_104  1.0
    RHS1      EDGE_2_4  1.0
    RHS1      EDGE_29_107  1.0
    RHS1      EDGE_20_58  1.0
    RHS1      EDGE_53_55  1.0
    RHS1      EDGE_44_86  1.0
    RHS1      EDGE_22_67  1.0
    RHS1      EDGE_1_44  1.0
    RHS1      EDGE_45_87  1.0
    RHS1      EDGE_55_100  1.0
    RHS1      EDGE_19_34  1.0
    RHS1      EDGE_71_81  1.0
    RHS1      EDGE_0_57  1.0
    RHS1      EDGE_19_70  1.0
    RHS1      EDGE_11_66  1.0
    RHS1      EDGE_4_27  1.0
    RHS1      EDGE_83_91  1.0
    RHS1      EDGE_41_94  1.0
    RHS1      EDGE_1_21  1.0
    RHS1      EDGE_44_99  1.0
    RHS1      EDGE_72_81  1.0
    RHS1      EDGE_3_67  1.0
    RHS1      EDGE_46_65  1.0
    RHS1      EDGE_59_84  1.0
    RHS1      EDGE_28_96  1.0
    RHS1      EDGE_47_109  1.0
    RHS1      EDGE_48_74  1.0
    RHS1      EDGE_40_106  1.0
    RHS1      EDGE_25_63  1.0
    RHS1      EDGE_4_40  1.0
    RHS1      EDGE_10_83  1.0
    RHS1      EDGE_26_27  1.0
    RHS1      EDGE_45_77  1.0
    RHS1      EDGE_24_103  1.0
    RHS1      EDGE_15_54  1.0
    RHS1      EDGE_26_63  1.0
    RHS1      EDGE_59_97  1.0
    RHS1      EDGE_11_20  1.0
    RHS1      EDGE_70_106  1.0
    RHS1      EDGE_9_96  1.0
    RHS1      EDGE_21_70  1.0
    RHS1      EDGE_41_48  1.0
    RHS1      EDGE_21_106  1.0
    RHS1      EDGE_22_34  1.0
    RHS1      EDGE_33_80  1.0
    RHS1      EDGE_10_96  1.0
    RHS1      EDGE_3_57  1.0
    RHS1      EDGE_22_70  1.0
    RHS1      EDGE_26_40  1.0
    RHS1      EDGE_18_36  1.0
    RHS1      EDGE_47_99  1.0
    RHS1      EDGE_8_28  1.0
    RHS1      EDGE_48_64  1.0
    RHS1      EDGE_40_60  1.0
    RHS1      EDGE_5_102  1.0
    RHS1      EDGE_6_67  1.0
    RHS1      EDGE_63_80  1.0
    RHS1      EDGE_9_109  1.0
    RHS1      EDGE_21_83  1.0
    RHS1      EDGE_25_53  1.0
    RHS1      EDGE_16_89  1.0
    RHS1      EDGE_55_80  1.0
    RHS1      EDGE_0_1  1.0
    RHS1      EDGE_77_104  1.0
    RHS1      EDGE_28_99  1.0
    RHS1      EDGE_40_73  1.0
    RHS1      EDGE_33_34  1.0
    RHS1      EDGE_4_7  1.0
    RHS1      EDGE_2_46  1.0
    RHS1      EDGE_20_100  1.0
    RHS1      EDGE_66_67  1.0
    RHS1      EDGE_37_40  1.0
    RHS1      EDGE_43_83  1.0
    RHS1      EDGE_35_79  1.0
    RHS1      EDGE_15_21  1.0
    RHS1      EDGE_55_57  1.0
    RHS1      EDGE_66_103  1.0
    RHS1      EDGE_67_68  1.0
    RHS1      EDGE_16_102  1.0
    RHS1      EDGE_36_80  1.0
    RHS1      EDGE_48_54  1.0
    RHS1      EDGE_0_14  1.0
    RHS1      EDGE_6_57  1.0
    RHS1      EDGE_11_23  1.0
    RHS1      EDGE_58_104  1.0
    RHS1      EDGE_9_99  1.0
    RHS1      EDGE_10_27  1.0
    RHS1      EDGE_42_96  1.0
    RHS1      EDGE_61_109  1.0
    RHS1      EDGE_81_87  1.0
    RHS1      EDGE_44_56  1.0
    RHS1      EDGE_31_86  1.0
    RHS1      EDGE_10_63  1.0
    RHS1      EDGE_51_64  1.0
    RHS1      EDGE_22_37  1.0
    RHS1      EDGE_12_109  1.0
    RHS1      EDGE_13_74  1.0
    RHS1      EDGE_43_96  1.0
    RHS1      EDGE_16_79  1.0
    RHS1      EDGE_96_108  1.0
    RHS1      EDGE_5_69  1.0
    RHS1      EDGE_61_86  1.0
    RHS1      EDGE_40_63  1.0
    RHS1      EDGE_27_93  1.0
    RHS1      EDGE_30_98  1.0
    RHS1      EDGE_54_83  1.0
    RHS1      EDGE_39_103  1.0
    RHS1      EDGE_12_86  1.0
    RHS1      EDGE_31_99  1.0
    RHS1      EDGE_3_37  1.0
    RHS1      EDGE_13_87  1.0
    RHS1      EDGE_24_96  1.0
    RHS1      EDGE_17_57  1.0
    RHS1      EDGE_36_70  1.0
    RHS1      EDGE_68_102  1.0
    RHS1      EDGE_26_105  1.0
    RHS1      EDGE_5_82  1.0
    RHS1      EDGE_69_103  1.0
    RHS1      EDGE_61_99  1.0
    RHS1      EDGE_54_60  1.0
    RHS1      EDGE_33_37  1.0
    RHS1      EDGE_20_67  1.0
    RHS1      EDGE_11_98  1.0
    RHS1      EDGE_2_49  1.0
    RHS1      EDGE_84_88  1.0
    RHS1      EDGE_22_27  1.0
    RHS1      EDGE_66_70  1.0
    RHS1      EDGE_53_100  1.0
    RHS1      EDGE_64_109  1.0
    RHS1      EDGE_65_74  1.0
    RHS1      EDGE_55_60  1.0
    RHS1      EDGE_1_89  1.0
    RHS1      EDGE_9_66  1.0
    RHS1      EDGE_50_67  1.0
    RHS1      EDGE_77_84  1.0
    RHS1      EDGE_42_63  1.0
    RHS1      EDGE_80_89  1.0
    RHS1      EDGE_10_30  1.0
    RHS1      EDGE_83_100  1.0
    RHS1      EDGE_62_77  1.0
    RHS1      EDGE_13_41  1.0
    RHS1      EDGE_31_89  1.0
    RHS1      EDGE_72_90  1.0
    RHS1      EDGE_43_63  1.0
    RHS1      EDGE_45_109  1.0
    RHS1      EDGE_38_70  1.0
    RHS1      EDGE_26_95  1.0
    RHS1      EDGE_79_107  1.0
    RHS1      EDGE_11_88  1.0
    RHS1      EDGE_1_43  1.0
    RHS1      EDGE_53_90  1.0
    RHS1      EDGE_72_103  1.0
    RHS1      EDGE_45_86  1.0
    RHS1      EDGE_64_99  1.0
    RHS1      EDGE_16_59  1.0
    RHS1      EDGE_36_37  1.0
    RHS1      EDGE_9_20  1.0
    RHS1      EDGE_28_33  1.0
    RHS1      EDGE_6_14  1.0
    RHS1      EDGE_38_83  1.0
    RHS1      EDGE_58_61  1.0
    RHS1      EDGE_90_93  1.0
    RHS1      EDGE_21_30  1.0
    RHS1      EDGE_61_66  1.0
    RHS1      EDGE_26_108  1.0
    RHS1      EDGE_18_104  1.0
    RHS1      EDGE_20_34  1.0
    RHS1      EDGE_30_78  1.0
    RHS1      EDGE_31_43  1.0
    RHS1      EDGE_54_63  1.0
    RHS1      EDGE_0_92  1.0
    RHS1      EDGE_20_70  1.0
    RHS1      EDGE_44_98  1.0
    RHS1      EDGE_84_91  1.0
    RHS1      EDGE_16_36  1.0
    RHS1      EDGE_34_90  1.0
    RHS1      EDGE_45_99  1.0
    RHS1      EDGE_86_100  1.0
    RHS1      EDGE_65_77  1.0
    RHS1      EDGE_97_109  1.0
    RHS1      EDGE_3_102  1.0
    RHS1      EDGE_68_82  1.0
    RHS1      EDGE_19_46  1.0
    RHS1      EDGE_90_106  1.0
    RHS1      EDGE_40_105  1.0
    RHS1      EDGE_19_82  1.0
    RHS1      EDGE_20_47  1.0
    RHS1      EDGE_12_43  1.0
    RHS1      EDGE_4_39  1.0
    RHS1      EDGE_83_103  1.0
    RHS1      EDGE_1_33  1.0
    RHS1      EDGE_13_44  1.0
    RHS1      EDGE_37_72  1.0
    RHS1      EDGE_18_58  1.0
    RHS1      EDGE_70_105  1.0
    RHS1      EDGE_7_85  1.0
    RHS1      EDGE_48_86  1.0
    RHS1      EDGE_18_94  1.0
    RHS1      EDGE_19_59  1.0
    RHS1      EDGE_20_24  1.0
    RHS1      EDGE_75_76  1.0
    RHS1      EDGE_41_83  1.0
    RHS1      EDGE_12_56  1.0
    RHS1      EDGE_108_109  1.0
    RHS1      EDGE_34_80  1.0
    RHS1      EDGE_49_59  1.0
    RHS1      EDGE_89_95  1.0
    RHS1      EDGE_14_101  1.0
    RHS1      EDGE_18_71  1.0
    RHS1      EDGE_19_36  1.0
    RHS1      EDGE_98_100  1.0
    RHS1      EDGE_42_56  1.0
    RHS1      EDGE_12_33  1.0
    RHS1      EDGE_52_69  1.0
    RHS1      EDGE_4_29  1.0
    RHS1      EDGE_10_72  1.0
    RHS1      EDGE_75_89  1.0
    RHS1      EDGE_33_92  1.0
    RHS1      EDGE_34_57  1.0
    RHS1      EDGE_7_39  1.0
    RHS1      EDGE_67_90  1.0
    RHS1      EDGE_38_63  1.0
    RHS1      EDGE_28_98  1.0
    RHS1      EDGE_0_36  1.0
    RHS1      EDGE_63_92  1.0
    RHS1      EDGE_40_108  1.0
    RHS1      EDGE_60_86  1.0
    RHS1      EDGE_37_39  1.0
    RHS1      EDGE_10_85  1.0
    RHS1      EDGE_66_102  1.0
    RHS1      EDGE_26_29  1.0
    RHS1      EDGE_37_75  1.0
    RHS1      EDGE_38_40  1.0
    RHS1      EDGE_16_101  1.0
    RHS1      EDGE_55_92  1.0
    RHS1      EDGE_7_52  1.0
    RHS1      EDGE_26_65  1.0
    RHS1      EDGE_5_91  1.0
    RHS1      EDGE_11_22  1.0
    RHS1      EDGE_71_73  1.0
    RHS1      EDGE_41_50  1.0
    RHS1      EDGE_6_92  1.0
    RHS1      EDGE_22_36  1.0
    RHS1      EDGE_54_105  1.0
    RHS1      EDGE_34_47  1.0
    RHS1      EDGE_25_78  1.0
    RHS1      EDGE_66_79  1.0
    RHS1      EDGE_3_59  1.0
    RHS1      EDGE_14_68  1.0
    RHS1      EDGE_96_107  1.0
    RHS1      EDGE_78_89  1.0
    RHS1      EDGE_17_79  1.0
    RHS1      EDGE_28_88  1.0
    RHS1      EDGE_48_66  1.0
    RHS1      EDGE_5_104  1.0
    RHS1      EDGE_29_89  1.0
    RHS1      EDGE_42_108  1.0
    RHS1      EDGE_39_102  1.0
    RHS1      EDGE_31_98  1.0
    RHS1      EDGE_14_45  1.0
    RHS1      EDGE_66_92  1.0
    RHS1      EDGE_85_105  1.0
    RHS1      EDGE_32_99  1.0
    RHS1      EDGE_28_65  1.0
    RHS1      EDGE_7_42  1.0
    RHS1      EDGE_47_78  1.0
    RHS1      EDGE_17_92  1.0
    RHS1      EDGE_77_106  1.0
    RHS1      EDGE_28_101  1.0
    RHS1      EDGE_40_75  1.0
    RHS1      EDGE_4_9  1.0
    RHS1      EDGE_2_48  1.0
    RHS1      EDGE_20_102  1.0
    RHS1      EDGE_66_69  1.0
    RHS1      EDGE_12_98  1.0
    RHS1      EDGE_51_89  1.0
    RHS1      EDGE_55_59  1.0
    RHS1      EDGE_15_23  1.0
    RHS1      EDGE_1_88  1.0
    RHS1      EDGE_67_70  1.0
    RHS1      EDGE_18_28  1.0
    RHS1      EDGE_99_102  1.0
    RHS1      EDGE_24_108  1.0
    RHS1      EDGE_17_69  1.0
    RHS1      EDGE_77_83  1.0
    RHS1      EDGE_100_103  1.0
    RHS1      EDGE_50_102  1.0
    RHS1      EDGE_62_76  1.0
    RHS1      EDGE_0_101  1.0
    RHS1      EDGE_25_45  1.0
    RHS1      EDGE_31_88  1.0
    RHS1      EDGE_84_100  1.0
    RHS1      EDGE_54_108  1.0
    RHS1      EDGE_87_105  1.0
    RHS1      EDGE_35_94  1.0
    RHS1      EDGE_76_95  1.0
    RHS1      EDGE_55_72  1.0
    RHS1      EDGE_88_106  1.0
    RHS1      EDGE_58_83  1.0
    RHS1      EDGE_9_78  1.0
    RHS1      EDGE_50_79  1.0
    RHS1      EDGE_61_88  1.0
    RHS1      EDGE_80_101  1.0
    RHS1      EDGE_27_95  1.0
    RHS1      EDGE_39_69  1.0
    RHS1      EDGE_54_85  1.0
    RHS1      EDGE_12_88  1.0
    RHS1      EDGE_23_97  1.0
    RHS1      EDGE_51_79  1.0
    RHS1      EDGE_1_78  1.0
    RHS1      EDGE_5_48  1.0
    RHS1      EDGE_65_99  1.0
    RHS1      EDGE_16_94  1.0
    RHS1      EDGE_28_68  1.0
    RHS1      EDGE_42_88  1.0
    RHS1      EDGE_27_108  1.0
    RHS1      EDGE_20_69  1.0
    RHS1      EDGE_39_82  1.0
    RHS1      EDGE_1_55  1.0
    RHS1      EDGE_13_66  1.0
    RHS1      EDGE_16_71  1.0
    RHS1      EDGE_36_49  1.0
    RHS1      EDGE_76_85  1.0
    RHS1      EDGE_46_99  1.0
    RHS1      EDGE_77_86  1.0
    RHS1      EDGE_50_69  1.0
    RHS1      EDGE_42_65  1.0
    RHS1      EDGE_21_42  1.0
    RHS1      EDGE_20_46  1.0
    RHS1      EDGE_91_106  1.0
    RHS1      EDGE_8_108  1.0
    RHS1      EDGE_0_104  1.0
    RHS1      EDGE_20_82  1.0
    RHS1      EDGE_32_56  1.0
    RHS1      EDGE_72_92  1.0
    RHS1      EDGE_16_48  1.0
    RHS1      EDGE_35_61  1.0
    RHS1      EDGE_34_102  1.0
    RHS1      EDGE_65_89  1.0
    RHS1      EDGE_38_72  1.0
    RHS1      EDGE_68_94  1.0
    RHS1      EDGE_27_62  1.0
    RHS1      EDGE_6_39  1.0
    RHS1      EDGE_18_93  1.0
    RHS1      EDGE_50_82  1.0
    RHS1      EDGE_20_59  1.0
    RHS1      EDGE_60_95  1.0
    RHS1      EDGE_11_90  1.0
    RHS1      EDGE_32_33  1.0
    RHS1      EDGE_1_45  1.0
    RHS1      EDGE_37_84  1.0
    RHS1      EDGE_65_66  1.0
    RHS1      EDGE_16_61  1.0
    RHS1      EDGE_28_35  1.0
    RHS1      EDGE_26_74  1.0
    RHS1      EDGE_5_51  1.0
    RHS1      EDGE_46_89  1.0
    RHS1      EDGE_49_94  1.0
    RHS1      EDGE_50_59  1.0
    RHS1      EDGE_15_101  1.0
    RHS1      EDGE_61_68  1.0
    RHS1      EDGE_101_104  1.0
    RHS1      EDGE_7_97  1.0
    RHS1      EDGE_0_58  1.0
    RHS1      EDGE_19_71  1.0
    RHS1      EDGE_20_36  1.0
    RHS1      EDGE_39_49  1.0
    RHS1      EDGE_94_101  1.0
    RHS1      EDGE_60_108  1.0
    RHS1      EDGE_33_91  1.0
    RHS1      EDGE_13_33  1.0
    RHS1      EDGE_16_38  1.0
    RHS1      EDGE_56_74  1.0
    RHS1      EDGE_3_104  1.0
    RHS1      EDGE_89_107  1.0
    RHS1      EDGE_15_78  1.0
    RHS1      EDGE_52_81  1.0
    RHS1      EDGE_31_58  1.0
    RHS1      EDGE_33_104  1.0
    RHS1      EDGE_25_100  1.0
    RHS1      EDGE_37_74  1.0
    RHS1      EDGE_56_87  1.0
    RHS1      EDGE_22_94  1.0
    RHS1      EDGE_67_102  1.0
    RHS1      EDGE_27_29  1.0
    RHS1      EDGE_38_75  1.0
    RHS1      EDGE_70_107  1.0
    RHS1      EDGE_71_72  1.0
    RHS1      EDGE_42_45  1.0
    RHS1      EDGE_48_88  1.0
    RHS1      EDGE_27_65  1.0
    RHS1      EDGE_11_57  1.0
    RHS1      EDGE_12_22  1.0
    RHS1      EDGE_33_81  1.0
    RHS1      EDGE_13_23  1.0
    RHS1      EDGE_25_77  1.0
    RHS1      EDGE_45_55  1.0
    RHS1      EDGE_56_64  1.0
    RHS1      EDGE_22_71  1.0
    RHS1      EDGE_14_67  1.0
    RHS1      EDGE_67_79  1.0
    RHS1      EDGE_46_56  1.0
    RHS1      EDGE_38_52  1.0
    RHS1      EDGE_78_88  1.0
    RHS1      EDGE_97_101  1.0
    RHS1      EDGE_0_25  1.0
    RHS1      EDGE_19_38  1.0
    RHS1      EDGE_79_89  1.0
    RHS1      EDGE_11_34  1.0
    RHS1      EDGE_71_85  1.0
    RHS1      EDGE_63_81  1.0
    RHS1      EDGE_82_94  1.0
    RHS1      EDGE_0_61  1.0
    RHS1      EDGE_12_35  1.0
    RHS1      EDGE_44_67  1.0
    RHS1      EDGE_1_25  1.0
    RHS1      EDGE_34_59  1.0
    RHS1      EDGE_25_90  1.0
    RHS1      EDGE_53_72  1.0
    RHS1      EDGE_93_108  1.0
    RHS1      EDGE_45_68  1.0
    RHS1      EDGE_32_98  1.0
    RHS1      EDGE_37_64  1.0
    RHS1      EDGE_2_106  1.0
    RHS1      EDGE_43_107  1.0
    RHS1      EDGE_15_45  1.0
    RHS1      EDGE_26_54  1.0
    RHS1      EDGE_67_92  1.0
    RHS1      EDGE_78_101  1.0
    RHS1      EDGE_70_97  1.0
    RHS1      EDGE_9_87  1.0
    RHS1      EDGE_63_94  1.0
    RHS1      EDGE_29_101  1.0
    RHS1      EDGE_34_36  1.0
    RHS1      EDGE_52_84  1.0
    RHS1      EDGE_10_87  1.0
    RHS1      EDGE_7_18  1.0
    RHS1      EDGE_8_19  1.0
    RHS1      EDGE_27_32  1.0
    RHS1      EDGE_59_101  1.0
    RHS1      EDGE_18_63  1.0
    RHS1      EDGE_100_102  1.0
    RHS1      EDGE_11_24  1.0
    RHS1      EDGE_10_64  1.0
    RHS1      EDGE_93_98  1.0
    RHS1      EDGE_66_81  1.0
    RHS1      EDGE_85_94  1.0
    RHS1      EDGE_32_88  1.0
    RHS1      EDGE_37_54  1.0
    RHS1      EDGE_96_109  1.0
    RHS1      EDGE_59_78  1.0
    RHS1      EDGE_17_81  1.0
    RHS1      EDGE_29_55  1.0
    RHS1      EDGE_21_51  1.0
    RHS1      EDGE_0_28  1.0
    RHS1      EDGE_80_100  1.0
    RHS1      EDGE_54_84  1.0
    RHS1      EDGE_33_61  1.0
    RHS1      EDGE_44_70  1.0
    RHS1      EDGE_23_96  1.0
    RHS1      EDGE_2_73  1.0
    RHS1      EDGE_7_8  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
 BV BND1      x_80
 BV BND1      x_81
 BV BND1      x_82
 BV BND1      x_83
 BV BND1      x_84
 BV BND1      x_85
 BV BND1      x_86
 BV BND1      x_87
 BV BND1      x_88
 BV BND1      x_89
 BV BND1      x_90
 BV BND1      x_91
 BV BND1      x_92
 BV BND1      x_93
 BV BND1      x_94
 BV BND1      x_95
 BV BND1      x_96
 BV BND1      x_97
 BV BND1      x_98
 BV BND1      x_99
 BV BND1      x_100
 BV BND1      x_101
 BV BND1      x_102
 BV BND1      x_103
 BV BND1      x_104
 BV BND1      x_105
 BV BND1      x_106
 BV BND1      x_107
 BV BND1      x_108
 BV BND1      x_109
ENDATA
