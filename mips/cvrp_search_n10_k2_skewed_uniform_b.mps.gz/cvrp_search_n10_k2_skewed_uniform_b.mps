NAME          cvrp_search_n10_k2_skewed_uniform_b
ROWS
 N  OBJ
 E  OUT1
 E  IN1
 E  FLOW1
 E  OUT2
 E  IN2
 E  FLOW2
 E  OUT3
 E  IN3
 E  FLOW3
 E  OUT4
 E  IN4
 E  FLOW4
 E  OUT5
 E  IN5
 E  FLOW5
 E  OUT6
 E  IN6
 E  FLOW6
 E  OUT7
 E  IN7
 E  FLOW7
 E  OUT8
 E  IN8
 E  FLOW8
 E  OUT9
 E  IN9
 E  FLOW9
 E  OUT10
 E  IN10
 E  FLOW10
 L  FLEET
 L  CAP0
 L  CAP1
 L  CAP2
 L  CAP3
 L  CAP4
 L  CAP5
 L  CAP6
 L  CAP7
 L  CAP8
 L  CAP9
 L  CAP10
 L  CAP11
 L  CAP12
 L  CAP13
 L  CAP14
 L  CAP15
 L  CAP16
 L  CAP17
 L  CAP18
 L  CAP19
 L  CAP20
 L  CAP21
 L  CAP22
 L  CAP23
 L  CAP24
 L  CAP25
 L  CAP26
 L  CAP27
 L  CAP28
 L  CAP29
 L  CAP30
 L  CAP31
 L  CAP32
 L  CAP33
 L  CAP34
 L  CAP35
 L  CAP36
 L  CAP37
 L  CAP38
 L  CAP39
 L  CAP40
 L  CAP41
 L  CAP42
 L  CAP43
 L  CAP44
 L  CAP45
 L  CAP46
 L  CAP47
 L  CAP48
 L  CAP49
 L  CAP50
 L  CAP51
 L  CAP52
 L  CAP53
 L  CAP54
 L  CAP55
 L  CAP56
 L  CAP57
 L  CAP58
 L  CAP59
 L  CAP60
 L  CAP61
 L  CAP62
 L  CAP63
 L  CAP64
 L  CAP65
 L  CAP66
 L  CAP67
 L  CAP68
 L  CAP69
 L  CAP70
 L  CAP71
 L  CAP72
 L  CAP73
 L  CAP74
 L  CAP75
 L  CAP76
 L  CAP77
 L  CAP78
 L  CAP79
 L  CAP80
 L  CAP81
 L  CAP82
 L  CAP83
 L  CAP84
 L  CAP85
 L  CAP86
 L  CAP87
 L  CAP88
 L  CAP89
 L  CAP90
 L  CAP91
 L  CAP92
 L  CAP93
 L  CAP94
 L  CAP95
 L  CAP96
 L  CAP97
 L  CAP98
 L  CAP99
 G  DLBO1
 L  DUBO1
 G  DLBO2
 L  DUBO2
 G  DLBO3
 L  DUBO3
 G  DLBO4
 L  DUBO4
 G  DLBO5
 L  DUBO5
 G  DLBO6
 L  DUBO6
 G  DLBO7
 L  DUBO7
 G  DLBO8
 L  DUBO8
 G  DLBO9
 L  DUBO9
 G  DLBO10
 L  DUBO10
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0_1          OBJ       93.52
    x0_1          IN1      1
    x0_1          FLOW1   -1
    x0_1          FLEET      1
    x0_1          CAP0    30
    x0_2          OBJ       49.49
    x0_2          IN2      1
    x0_2          FLOW2   -1
    x0_2          FLEET      1
    x0_2          CAP1    30
    x0_3          OBJ       83.41
    x0_3          IN3      1
    x0_3          FLOW3   -1
    x0_3          FLEET      1
    x0_3          CAP2    30
    x0_4          OBJ       98.76
    x0_4          IN4      1
    x0_4          FLOW4   -1
    x0_4          FLEET      1
    x0_4          CAP3    30
    x0_5          OBJ       52.94
    x0_5          IN5      1
    x0_5          FLOW5   -1
    x0_5          FLEET      1
    x0_5          CAP4    30
    x0_6          OBJ       37.09
    x0_6          IN6      1
    x0_6          FLOW6   -1
    x0_6          FLEET      1
    x0_6          CAP5    30
    x0_7          OBJ       39.10
    x0_7          IN7      1
    x0_7          FLOW7   -1
    x0_7          FLEET      1
    x0_7          CAP6    30
    x0_8          OBJ       94.09
    x0_8          IN8      1
    x0_8          FLOW8   -1
    x0_8          FLEET      1
    x0_8          CAP7    30
    x0_9          OBJ       85.50
    x0_9          IN9      1
    x0_9          FLOW9   -1
    x0_9          FLEET      1
    x0_9          CAP8    30
    x0_10         OBJ       84.96
    x0_10         IN10      1
    x0_10         FLOW10   -1
    x0_10         FLEET      1
    x0_10         CAP9    30
    x1_0          OBJ       93.52
    x1_0          OUT1     1
    x1_0          FLOW1    1
    x1_2          OBJ       87.14
    x1_2          OUT1     1
    x1_2          IN2      1
    x1_2          FLOW1    1
    x1_2          FLOW2   -1
    x1_2          CAP10    30
    x1_3          OBJ       29.82
    x1_3          OUT1     1
    x1_3          IN3      1
    x1_3          FLOW1    1
    x1_3          FLOW3   -1
    x1_3          CAP11    30
    x1_4          OBJ       60.92
    x1_4          OUT1     1
    x1_4          IN4      1
    x1_4          FLOW1    1
    x1_4          FLOW4   -1
    x1_4          CAP12    30
    x1_5          OBJ       47.43
    x1_5          OUT1     1
    x1_5          IN5      1
    x1_5          FLOW1    1
    x1_5          FLOW5   -1
    x1_5          CAP13    30
    x1_6          OBJ       63.22
    x1_6          OUT1     1
    x1_6          IN6      1
    x1_6          FLOW1    1
    x1_6          FLOW6   -1
    x1_6          CAP14    30
    x1_7          OBJ       100.93
    x1_7          OUT1     1
    x1_7          IN7      1
    x1_7          FLOW1    1
    x1_7          FLOW7   -1
    x1_7          CAP15    30
    x1_8          OBJ       9.08
    x1_8          OUT1     1
    x1_8          IN8      1
    x1_8          FLOW1    1
    x1_8          FLOW8   -1
    x1_8          CAP16    30
    x1_9          OBJ       10.91
    x1_9          OUT1     1
    x1_9          IN9      1
    x1_9          FLOW1    1
    x1_9          FLOW9   -1
    x1_9          CAP17    30
    x1_10         OBJ       65.90
    x1_10         OUT1     1
    x1_10         IN10      1
    x1_10         FLOW1    1
    x1_10         FLOW10   -1
    x1_10         CAP18    30
    x2_0          OBJ       49.49
    x2_0          OUT2     1
    x2_0          FLOW2    1
    x2_1          OBJ       87.14
    x2_1          OUT2     1
    x2_1          IN1      1
    x2_1          FLOW2    1
    x2_1          FLOW1   -1
    x2_1          CAP19    30
    x2_3          OBJ       63.01
    x2_3          OUT2     1
    x2_3          IN3      1
    x2_3          FLOW2    1
    x2_3          FLOW3   -1
    x2_3          CAP20    30
    x2_4          OBJ       61.33
    x2_4          OUT2     1
    x2_4          IN4      1
    x2_4          FLOW2    1
    x2_4          FLOW4   -1
    x2_4          CAP21    30
    x2_5          OBJ       70.68
    x2_5          OUT2     1
    x2_5          IN5      1
    x2_5          FLOW2    1
    x2_5          FLOW5   -1
    x2_5          CAP22    30
    x2_6          OBJ       31.23
    x2_6          OUT2     1
    x2_6          IN6      1
    x2_6          FLOW2    1
    x2_6          FLOW6   -1
    x2_6          CAP23    30
    x2_7          OBJ       86.75
    x2_7          OUT2     1
    x2_7          IN7      1
    x2_7          FLOW2    1
    x2_7          FLOW7   -1
    x2_7          CAP24    30
    x2_8          OBJ       92.32
    x2_8          OUT2     1
    x2_8          IN8      1
    x2_8          FLOW2    1
    x2_8          FLOW8   -1
    x2_8          CAP25    30
    x2_9          OBJ       84.39
    x2_9          OUT2     1
    x2_9          IN9      1
    x2_9          FLOW2    1
    x2_9          FLOW9   -1
    x2_9          CAP26    30
    x2_10         OBJ       44.62
    x2_10         OUT2     1
    x2_10         IN10      1
    x2_10         FLOW2    1
    x2_10         FLOW10   -1
    x2_10         CAP27    30
    x3_0          OBJ       83.41
    x3_0          OUT3     1
    x3_0          FLOW3    1
    x3_1          OBJ       29.82
    x3_1          OUT3     1
    x3_1          IN1      1
    x3_1          FLOW3    1
    x3_1          FLOW1   -1
    x3_1          CAP28    30
    x3_2          OBJ       63.01
    x3_2          OUT3     1
    x3_2          IN2      1
    x3_2          FLOW3    1
    x3_2          FLOW2   -1
    x3_2          CAP29    30
    x3_4          OBJ       33.02
    x3_4          OUT3     1
    x3_4          IN4      1
    x3_4          FLOW3    1
    x3_4          FLOW4   -1
    x3_4          CAP30    30
    x3_5          OBJ       53.26
    x3_5          OUT3     1
    x3_5          IN5      1
    x3_5          FLOW3    1
    x3_5          FLOW5   -1
    x3_5          CAP31    30
    x3_6          OBJ       47.27
    x3_6          OUT3     1
    x3_6          IN6      1
    x3_6          FLOW3    1
    x3_6          FLOW6   -1
    x3_6          CAP32    30
    x3_7          OBJ       102.26
    x3_7          OUT3     1
    x3_7          IN7      1
    x3_7          FLOW3    1
    x3_7          FLOW7   -1
    x3_7          CAP33    30
    x3_8          OBJ       38.09
    x3_8          OUT3     1
    x3_8          IN8      1
    x3_8          FLOW3    1
    x3_8          FLOW8   -1
    x3_8          CAP34    30
    x3_9          OBJ       33.77
    x3_9          OUT3     1
    x3_9          IN9      1
    x3_9          FLOW3    1
    x3_9          FLOW9   -1
    x3_9          CAP35    30
    x3_10         OBJ       36.08
    x3_10         OUT3     1
    x3_10         IN10      1
    x3_10         FLOW3    1
    x3_10         FLOW10   -1
    x3_10         CAP36    30
    x4_0          OBJ       98.76
    x4_0          OUT4     1
    x4_0          FLOW4    1
    x4_1          OBJ       60.92
    x4_1          OUT4     1
    x4_1          IN1      1
    x4_1          FLOW4    1
    x4_1          FLOW1   -1
    x4_1          CAP37    30
    x4_2          OBJ       61.33
    x4_2          OUT4     1
    x4_2          IN2      1
    x4_2          FLOW4    1
    x4_2          FLOW2   -1
    x4_2          CAP38    30
    x4_3          OBJ       33.02
    x4_3          OUT4     1
    x4_3          IN3      1
    x4_3          FLOW4    1
    x4_3          FLOW3   -1
    x4_3          CAP39    30
    x4_5          OBJ       82.75
    x4_5          OUT4     1
    x4_5          IN5      1
    x4_5          FLOW4    1
    x4_5          FLOW5   -1
    x4_5          CAP40    30
    x4_6          OBJ       62.36
    x4_6          OUT4     1
    x4_6          IN6      1
    x4_6          FLOW4    1
    x4_6          FLOW6   -1
    x4_6          CAP41    30
    x4_7          OBJ       125.84
    x4_7          OUT4     1
    x4_7          IN7      1
    x4_7          FLOW4    1
    x4_7          FLOW7   -1
    x4_7          CAP42    30
    x4_8          OBJ       69.79
    x4_8          OUT4     1
    x4_8          IN8      1
    x4_8          FLOW4    1
    x4_8          FLOW8   -1
    x4_8          CAP43    30
    x4_9          OBJ       66.53
    x4_9          OUT4     1
    x4_9          IN9      1
    x4_9          FLOW4    1
    x4_9          FLOW9   -1
    x4_9          CAP44    30
    x4_10         OBJ       16.98
    x4_10         OUT4     1
    x4_10         IN10      1
    x4_10         FLOW4    1
    x4_10         FLOW10   -1
    x4_10         CAP45    30
    x5_0          OBJ       52.94
    x5_0          OUT5     1
    x5_0          FLOW5    1
    x5_1          OBJ       47.43
    x5_1          OUT5     1
    x5_1          IN1      1
    x5_1          FLOW5    1
    x5_1          FLOW1   -1
    x5_1          CAP46    30
    x5_2          OBJ       70.68
    x5_2          OUT5     1
    x5_2          IN2      1
    x5_2          FLOW5    1
    x5_2          FLOW2   -1
    x5_2          CAP47    30
    x5_3          OBJ       53.26
    x5_3          OUT5     1
    x5_3          IN3      1
    x5_3          FLOW5    1
    x5_3          FLOW3   -1
    x5_3          CAP48    30
    x5_4          OBJ       82.75
    x5_4          OUT5     1
    x5_4          IN4      1
    x5_4          FLOW5    1
    x5_4          FLOW4   -1
    x5_4          CAP49    30
    x5_6          OBJ       39.45
    x5_6          OUT5     1
    x5_6          IN6      1
    x5_6          FLOW5    1
    x5_6          FLOW6   -1
    x5_6          CAP50    30
    x5_7          OBJ       53.50
    x5_7          OUT5     1
    x5_7          IN7      1
    x5_7          FLOW5    1
    x5_7          FLOW7   -1
    x5_7          CAP51    30
    x5_8          OBJ       44.88
    x5_8          OUT5     1
    x5_8          IN8      1
    x5_8          FLOW5    1
    x5_8          FLOW8   -1
    x5_8          CAP52    30
    x5_9          OBJ       37.20
    x5_9          OUT5     1
    x5_9          IN9      1
    x5_9          FLOW5    1
    x5_9          FLOW9   -1
    x5_9          CAP53    30
    x5_10         OBJ       77.15
    x5_10         OUT5     1
    x5_10         IN10      1
    x5_10         FLOW5    1
    x5_10         FLOW10   -1
    x5_10         CAP54    30
    x6_0          OBJ       37.09
    x6_0          OUT6     1
    x6_0          FLOW6    1
    x6_1          OBJ       63.22
    x6_1          OUT6     1
    x6_1          IN1      1
    x6_1          FLOW6    1
    x6_1          FLOW1   -1
    x6_1          CAP55    30
    x6_2          OBJ       31.23
    x6_2          OUT6     1
    x6_2          IN2      1
    x6_2          FLOW6    1
    x6_2          FLOW2   -1
    x6_2          CAP56    30
    x6_3          OBJ       47.27
    x6_3          OUT6     1
    x6_3          IN3      1
    x6_3          FLOW6    1
    x6_3          FLOW3   -1
    x6_3          CAP57    30
    x6_4          OBJ       62.36
    x6_4          OUT6     1
    x6_4          IN4      1
    x6_4          FLOW6    1
    x6_4          FLOW4   -1
    x6_4          CAP58    30
    x6_5          OBJ       39.45
    x6_5          OUT6     1
    x6_5          IN5      1
    x6_5          FLOW6    1
    x6_5          FLOW5   -1
    x6_5          CAP59    30
    x6_7          OBJ       65.09
    x6_7          OUT6     1
    x6_7          IN7      1
    x6_7          FLOW6    1
    x6_7          FLOW7   -1
    x6_7          CAP60    30
    x6_8          OBJ       66.42
    x6_8          OUT6     1
    x6_8          IN8      1
    x6_8          FLOW6    1
    x6_8          FLOW8   -1
    x6_8          CAP61    30
    x6_9          OBJ       57.89
    x6_9          OUT6     1
    x6_9          IN9      1
    x6_9          FLOW6    1
    x6_9          FLOW9   -1
    x6_9          CAP62    30
    x6_10         OBJ       50.06
    x6_10         OUT6     1
    x6_10         IN10      1
    x6_10         FLOW6    1
    x6_10         FLOW10   -1
    x6_10         CAP63    30
    x7_0          OBJ       39.10
    x7_0          OUT7     1
    x7_0          FLOW7    1
    x7_1          OBJ       100.93
    x7_1          OUT7     1
    x7_1          IN1      1
    x7_1          FLOW7    1
    x7_1          FLOW1   -1
    x7_1          CAP64    30
    x7_2          OBJ       86.75
    x7_2          OUT7     1
    x7_2          IN2      1
    x7_2          FLOW7    1
    x7_2          FLOW2   -1
    x7_2          CAP65    30
    x7_3          OBJ       102.26
    x7_3          OUT7     1
    x7_3          IN3      1
    x7_3          FLOW7    1
    x7_3          FLOW3   -1
    x7_3          CAP66    30
    x7_4          OBJ       125.84
    x7_4          OUT7     1
    x7_4          IN4      1
    x7_4          FLOW7    1
    x7_4          FLOW4   -1
    x7_4          CAP67    30
    x7_5          OBJ       53.50
    x7_5          OUT7     1
    x7_5          IN5      1
    x7_5          FLOW7    1
    x7_5          FLOW5   -1
    x7_5          CAP68    30
    x7_6          OBJ       65.09
    x7_6          OUT7     1
    x7_6          IN6      1
    x7_6          FLOW7    1
    x7_6          FLOW6   -1
    x7_6          CAP69    30
    x7_8          OBJ       97.90
    x7_8          OUT7     1
    x7_8          IN8      1
    x7_8          FLOW7    1
    x7_8          FLOW8   -1
    x7_8          CAP70    30
    x7_9          OBJ       90.59
    x7_9          OUT7     1
    x7_9          IN9      1
    x7_9          FLOW7    1
    x7_9          FLOW9   -1
    x7_9          CAP71    30
    x7_10         OBJ       114.98
    x7_10         OUT7     1
    x7_10         IN10      1
    x7_10         FLOW7    1
    x7_10         FLOW10   -1
    x7_10         CAP72    30
    x8_0          OBJ       94.09
    x8_0          OUT8     1
    x8_0          FLOW8    1
    x8_1          OBJ       9.08
    x8_1          OUT8     1
    x8_1          IN1      1
    x8_1          FLOW8    1
    x8_1          FLOW1   -1
    x8_1          CAP73    30
    x8_2          OBJ       92.32
    x8_2          OUT8     1
    x8_2          IN2      1
    x8_2          FLOW8    1
    x8_2          FLOW2   -1
    x8_2          CAP74    30
    x8_3          OBJ       38.09
    x8_3          OUT8     1
    x8_3          IN3      1
    x8_3          FLOW8    1
    x8_3          FLOW3   -1
    x8_3          CAP75    30
    x8_4          OBJ       69.79
    x8_4          OUT8     1
    x8_4          IN4      1
    x8_4          FLOW8    1
    x8_4          FLOW4   -1
    x8_4          CAP76    30
    x8_5          OBJ       44.88
    x8_5          OUT8     1
    x8_5          IN5      1
    x8_5          FLOW8    1
    x8_5          FLOW5   -1
    x8_5          CAP77    30
    x8_6          OBJ       66.42
    x8_6          OUT8     1
    x8_6          IN6      1
    x8_6          FLOW8    1
    x8_6          FLOW6   -1
    x8_6          CAP78    30
    x8_7          OBJ       97.90
    x8_7          OUT8     1
    x8_7          IN7      1
    x8_7          FLOW8    1
    x8_7          FLOW7   -1
    x8_7          CAP79    30
    x8_9          OBJ       8.68
    x8_9          OUT8     1
    x8_9          IN9      1
    x8_9          FLOW8    1
    x8_9          FLOW9   -1
    x8_9          CAP80    30
    x8_10         OBJ       74.06
    x8_10         OUT8     1
    x8_10         IN10      1
    x8_10         FLOW8    1
    x8_10         FLOW10   -1
    x8_10         CAP81    30
    x9_0          OBJ       85.50
    x9_0          OUT9     1
    x9_0          FLOW9    1
    x9_1          OBJ       10.91
    x9_1          OUT9     1
    x9_1          IN1      1
    x9_1          FLOW9    1
    x9_1          FLOW1   -1
    x9_1          CAP82    30
    x9_2          OBJ       84.39
    x9_2          OUT9     1
    x9_2          IN2      1
    x9_2          FLOW9    1
    x9_2          FLOW2   -1
    x9_2          CAP83    30
    x9_3          OBJ       33.77
    x9_3          OUT9     1
    x9_3          IN3      1
    x9_3          FLOW9    1
    x9_3          FLOW3   -1
    x9_3          CAP84    30
    x9_4          OBJ       66.53
    x9_4          OUT9     1
    x9_4          IN4      1
    x9_4          FLOW9    1
    x9_4          FLOW4   -1
    x9_4          CAP85    30
    x9_5          OBJ       37.20
    x9_5          OUT9     1
    x9_5          IN5      1
    x9_5          FLOW9    1
    x9_5          FLOW5   -1
    x9_5          CAP86    30
    x9_6          OBJ       57.89
    x9_6          OUT9     1
    x9_6          IN6      1
    x9_6          FLOW9    1
    x9_6          FLOW6   -1
    x9_6          CAP87    30
    x9_7          OBJ       90.59
    x9_7          OUT9     1
    x9_7          IN7      1
    x9_7          FLOW9    1
    x9_7          FLOW7   -1
    x9_7          CAP88    30
    x9_8          OBJ       8.68
    x9_8          OUT9     1
    x9_8          IN8      1
    x9_8          FLOW9    1
    x9_8          FLOW8   -1
    x9_8          CAP89    30
    x9_10         OBJ       68.99
    x9_10         OUT9     1
    x9_10         IN10      1
    x9_10         FLOW9    1
    x9_10         FLOW10   -1
    x9_10         CAP90    30
    x10_0         OBJ       84.96
    x10_0         OUT10     1
    x10_0         FLOW10    1
    x10_1         OBJ       65.90
    x10_1         OUT10     1
    x10_1         IN1      1
    x10_1         FLOW10    1
    x10_1         FLOW1   -1
    x10_1         CAP91    30
    x10_2         OBJ       44.62
    x10_2         OUT10     1
    x10_2         IN2      1
    x10_2         FLOW10    1
    x10_2         FLOW2   -1
    x10_2         CAP92    30
    x10_3         OBJ       36.08
    x10_3         OUT10     1
    x10_3         IN3      1
    x10_3         FLOW10    1
    x10_3         FLOW3   -1
    x10_3         CAP93    30
    x10_4         OBJ       16.98
    x10_4         OUT10     1
    x10_4         IN4      1
    x10_4         FLOW10    1
    x10_4         FLOW4   -1
    x10_4         CAP94    30
    x10_5         OBJ       77.15
    x10_5         OUT10     1
    x10_5         IN5      1
    x10_5         FLOW10    1
    x10_5         FLOW5   -1
    x10_5         CAP95    30
    x10_6         OBJ       50.06
    x10_6         OUT10     1
    x10_6         IN6      1
    x10_6         FLOW10    1
    x10_6         FLOW6   -1
    x10_6         CAP96    30
    x10_7         OBJ       114.98
    x10_7         OUT10     1
    x10_7         IN7      1
    x10_7         FLOW10    1
    x10_7         FLOW7   -1
    x10_7         CAP97    30
    x10_8         OBJ       74.06
    x10_8         OUT10     1
    x10_8         IN8      1
    x10_8         FLOW10    1
    x10_8         FLOW8   -1
    x10_8         CAP98    30
    x10_9         OBJ       68.99
    x10_9         OUT10     1
    x10_9         IN9      1
    x10_9         FLOW10    1
    x10_9         FLOW9   -1
    x10_9         CAP99    30
    MARK0000  'MARKER'                 'INTEND'
    u1            CAP0    -1
    u1            CAP10     1
    u1            CAP11     1
    u1            CAP12     1
    u1            CAP13     1
    u1            CAP14     1
    u1            CAP15     1
    u1            CAP16     1
    u1            CAP17     1
    u1            CAP18     1
    u1            CAP19    -1
    u1            CAP28    -1
    u1            CAP37    -1
    u1            CAP46    -1
    u1            CAP55    -1
    u1            CAP64    -1
    u1            CAP73    -1
    u1            CAP82    -1
    u1            CAP91    -1
    u1            DLBO1    1
    u1            DUBO1    1
    u2            CAP1    -1
    u2            CAP10    -1
    u2            CAP19     1
    u2            CAP20     1
    u2            CAP21     1
    u2            CAP22     1
    u2            CAP23     1
    u2            CAP24     1
    u2            CAP25     1
    u2            CAP26     1
    u2            CAP27     1
    u2            CAP29    -1
    u2            CAP38    -1
    u2            CAP47    -1
    u2            CAP56    -1
    u2            CAP65    -1
    u2            CAP74    -1
    u2            CAP83    -1
    u2            CAP92    -1
    u2            DLBO2    1
    u2            DUBO2    1
    u3            CAP2    -1
    u3            CAP11    -1
    u3            CAP20    -1
    u3            CAP28     1
    u3            CAP29     1
    u3            CAP30     1
    u3            CAP31     1
    u3            CAP32     1
    u3            CAP33     1
    u3            CAP34     1
    u3            CAP35     1
    u3            CAP36     1
    u3            CAP39    -1
    u3            CAP48    -1
    u3            CAP57    -1
    u3            CAP66    -1
    u3            CAP75    -1
    u3            CAP84    -1
    u3            CAP93    -1
    u3            DLBO3    1
    u3            DUBO3    1
    u4            CAP3    -1
    u4            CAP12    -1
    u4            CAP21    -1
    u4            CAP30    -1
    u4            CAP37     1
    u4            CAP38     1
    u4            CAP39     1
    u4            CAP40     1
    u4            CAP41     1
    u4            CAP42     1
    u4            CAP43     1
    u4            CAP44     1
    u4            CAP45     1
    u4            CAP49    -1
    u4            CAP58    -1
    u4            CAP67    -1
    u4            CAP76    -1
    u4            CAP85    -1
    u4            CAP94    -1
    u4            DLBO4    1
    u4            DUBO4    1
    u5            CAP4    -1
    u5            CAP13    -1
    u5            CAP22    -1
    u5            CAP31    -1
    u5            CAP40    -1
    u5            CAP46     1
    u5            CAP47     1
    u5            CAP48     1
    u5            CAP49     1
    u5            CAP50     1
    u5            CAP51     1
    u5            CAP52     1
    u5            CAP53     1
    u5            CAP54     1
    u5            CAP59    -1
    u5            CAP68    -1
    u5            CAP77    -1
    u5            CAP86    -1
    u5            CAP95    -1
    u5            DLBO5    1
    u5            DUBO5    1
    u6            CAP5    -1
    u6            CAP14    -1
    u6            CAP23    -1
    u6            CAP32    -1
    u6            CAP41    -1
    u6            CAP50    -1
    u6            CAP55     1
    u6            CAP56     1
    u6            CAP57     1
    u6            CAP58     1
    u6            CAP59     1
    u6            CAP60     1
    u6            CAP61     1
    u6            CAP62     1
    u6            CAP63     1
    u6            CAP69    -1
    u6            CAP78    -1
    u6            CAP87    -1
    u6            CAP96    -1
    u6            DLBO6    1
    u6            DUBO6    1
    u7            CAP6    -1
    u7            CAP15    -1
    u7            CAP24    -1
    u7            CAP33    -1
    u7            CAP42    -1
    u7            CAP51    -1
    u7            CAP60    -1
    u7            CAP64     1
    u7            CAP65     1
    u7            CAP66     1
    u7            CAP67     1
    u7            CAP68     1
    u7            CAP69     1
    u7            CAP70     1
    u7            CAP71     1
    u7            CAP72     1
    u7            CAP79    -1
    u7            CAP88    -1
    u7            CAP97    -1
    u7            DLBO7    1
    u7            DUBO7    1
    u8            CAP7    -1
    u8            CAP16    -1
    u8            CAP25    -1
    u8            CAP34    -1
    u8            CAP43    -1
    u8            CAP52    -1
    u8            CAP61    -1
    u8            CAP70    -1
    u8            CAP73     1
    u8            CAP74     1
    u8            CAP75     1
    u8            CAP76     1
    u8            CAP77     1
    u8            CAP78     1
    u8            CAP79     1
    u8            CAP80     1
    u8            CAP81     1
    u8            CAP89    -1
    u8            CAP98    -1
    u8            DLBO8    1
    u8            DUBO8    1
    u9            CAP8    -1
    u9            CAP17    -1
    u9            CAP26    -1
    u9            CAP35    -1
    u9            CAP44    -1
    u9            CAP53    -1
    u9            CAP62    -1
    u9            CAP71    -1
    u9            CAP80    -1
    u9            CAP82     1
    u9            CAP83     1
    u9            CAP84     1
    u9            CAP85     1
    u9            CAP86     1
    u9            CAP87     1
    u9            CAP88     1
    u9            CAP89     1
    u9            CAP90     1
    u9            CAP99    -1
    u9            DLBO9    1
    u9            DUBO9    1
    u10           CAP9    -1
    u10           CAP18    -1
    u10           CAP27    -1
    u10           CAP36    -1
    u10           CAP45    -1
    u10           CAP54    -1
    u10           CAP63    -1
    u10           CAP72    -1
    u10           CAP81    -1
    u10           CAP90    -1
    u10           CAP91     1
    u10           CAP92     1
    u10           CAP93     1
    u10           CAP94     1
    u10           CAP95     1
    u10           CAP96     1
    u10           CAP97     1
    u10           CAP98     1
    u10           CAP99     1
    u10           DLBO10    1
    u10           DUBO10    1
RHS
    RHS1      OUT1      1
    RHS1      IN1       1
    RHS1      OUT2      1
    RHS1      IN2       1
    RHS1      OUT3      1
    RHS1      IN3       1
    RHS1      OUT4      1
    RHS1      IN4       1
    RHS1      OUT5      1
    RHS1      IN5       1
    RHS1      OUT6      1
    RHS1      IN6       1
    RHS1      OUT7      1
    RHS1      IN7       1
    RHS1      OUT8      1
    RHS1      IN8       1
    RHS1      OUT9      1
    RHS1      IN9       1
    RHS1      OUT10      1
    RHS1      IN10       1
    RHS1      FLEET      2
    RHS1      CAP0     19
    RHS1      CAP1     28
    RHS1      CAP2     27
    RHS1      CAP3     19
    RHS1      CAP4     26
    RHS1      CAP5     27
    RHS1      CAP6     26
    RHS1      CAP7     27
    RHS1      CAP8     27
    RHS1      CAP9     22
    RHS1      CAP10     28
    RHS1      CAP11     27
    RHS1      CAP12     19
    RHS1      CAP13     26
    RHS1      CAP14     27
    RHS1      CAP15     26
    RHS1      CAP16     27
    RHS1      CAP17     27
    RHS1      CAP18     22
    RHS1      CAP19     19
    RHS1      CAP20     27
    RHS1      CAP21     19
    RHS1      CAP22     26
    RHS1      CAP23     27
    RHS1      CAP24     26
    RHS1      CAP25     27
    RHS1      CAP26     27
    RHS1      CAP27     22
    RHS1      CAP28     19
    RHS1      CAP29     28
    RHS1      CAP30     19
    RHS1      CAP31     26
    RHS1      CAP32     27
    RHS1      CAP33     26
    RHS1      CAP34     27
    RHS1      CAP35     27
    RHS1      CAP36     22
    RHS1      CAP37     19
    RHS1      CAP38     28
    RHS1      CAP39     27
    RHS1      CAP40     26
    RHS1      CAP41     27
    RHS1      CAP42     26
    RHS1      CAP43     27
    RHS1      CAP44     27
    RHS1      CAP45     22
    RHS1      CAP46     19
    RHS1      CAP47     28
    RHS1      CAP48     27
    RHS1      CAP49     19
    RHS1      CAP50     27
    RHS1      CAP51     26
    RHS1      CAP52     27
    RHS1      CAP53     27
    RHS1      CAP54     22
    RHS1      CAP55     19
    RHS1      CAP56     28
    RHS1      CAP57     27
    RHS1      CAP58     19
    RHS1      CAP59     26
    RHS1      CAP60     26
    RHS1      CAP61     27
    RHS1      CAP62     27
    RHS1      CAP63     22
    RHS1      CAP64     19
    RHS1      CAP65     28
    RHS1      CAP66     27
    RHS1      CAP67     19
    RHS1      CAP68     26
    RHS1      CAP69     27
    RHS1      CAP70     27
    RHS1      CAP71     27
    RHS1      CAP72     22
    RHS1      CAP73     19
    RHS1      CAP74     28
    RHS1      CAP75     27
    RHS1      CAP76     19
    RHS1      CAP77     26
    RHS1      CAP78     27
    RHS1      CAP79     26
    RHS1      CAP80     27
    RHS1      CAP81     22
    RHS1      CAP82     19
    RHS1      CAP83     28
    RHS1      CAP84     27
    RHS1      CAP85     19
    RHS1      CAP86     26
    RHS1      CAP87     27
    RHS1      CAP88     26
    RHS1      CAP89     27
    RHS1      CAP90     22
    RHS1      CAP91     19
    RHS1      CAP92     28
    RHS1      CAP93     27
    RHS1      CAP94     19
    RHS1      CAP95     26
    RHS1      CAP96     27
    RHS1      CAP97     26
    RHS1      CAP98     27
    RHS1      CAP99     27
    RHS1      DLBO1    11
    RHS1      DUBO1    30
    RHS1      DLBO2    2
    RHS1      DUBO2    30
    RHS1      DLBO3    3
    RHS1      DUBO3    30
    RHS1      DLBO4    11
    RHS1      DUBO4    30
    RHS1      DLBO5    4
    RHS1      DUBO5    30
    RHS1      DLBO6    3
    RHS1      DUBO6    30
    RHS1      DLBO7    4
    RHS1      DUBO7    30
    RHS1      DLBO8    3
    RHS1      DUBO8    30
    RHS1      DLBO9    3
    RHS1      DUBO9    30
    RHS1      DLBO10    8
    RHS1      DUBO10    30
BOUNDS
ENDATA
