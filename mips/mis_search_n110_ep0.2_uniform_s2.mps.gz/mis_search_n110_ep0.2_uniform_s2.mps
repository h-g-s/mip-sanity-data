NAME          MIS
ROWS
 N  OBJ
 L  EDGE_35_88
 L  EDGE_47_53
 L  EDGE_43_101
 L  EDGE_16_84
 L  EDGE_16_93
 L  EDGE_36_71
 L  EDGE_76_107
 L  EDGE_18_44
 L  EDGE_47_80
 L  EDGE_59_82
 L  EDGE_70_82
 L  EDGE_36_89
 L  EDGE_47_89
 L  EDGE_48_54
 L  EDGE_17_85
 L  EDGE_6_48
 L  EDGE_48_63
 L  EDGE_77_99
 L  EDGE_58_95
 L  EDGE_48_72
 L  EDGE_50_91
 L  EDGE_61_91
 L  EDGE_80_104
 L  EDGE_10_27
 L  EDGE_40_77
 L  EDGE_8_103
 L  EDGE_10_54
 L  EDGE_81_105
 L  EDGE_2_50
 L  EDGE_10_63
 L  EDGE_22_28
 L  EDGE_51_64
 L  EDGE_3_24
 L  EDGE_14_24
 L  EDGE_43_69
 L  EDGE_66_71
 L  EDGE_22_46
 L  EDGE_23_100
 L  EDGE_35_65
 L  EDGE_14_42
 L  EDGE_12_109
 L  EDGE_51_91
 L  EDGE_24_83
 L  EDGE_43_96
 L  EDGE_60_85
 L  EDGE_96_99
 L  EDGE_24_92
 L  EDGE_35_92
 L  EDGE_1_99
 L  EDGE_36_66
 L  EDGE_65_102
 L  EDGE_55_79
 L  EDGE_17_62
 L  EDGE_70_77
 L  EDGE_16_106
 L  EDGE_5_69
 L  EDGE_48_49
 L  EDGE_29_54
 L  EDGE_69_90
 L  EDGE_9_85
 L  EDGE_50_86
 L  EDGE_42_82
 L  EDGE_58_108
 L  EDGE_27_102
 L  EDGE_50_104
 L  EDGE_62_69
 L  EDGE_8_98
 L  EDGE_54_65
 L  EDGE_10_40
 L  EDGE_30_107
 L  EDGE_54_74
 L  EDGE_0_103
 L  EDGE_62_87
 L  EDGE_81_100
 L  EDGE_2_45
 L  EDGE_20_81
 L  EDGE_54_83
 L  EDGE_32_55
 L  EDGE_43_55
 L  EDGE_22_32
 L  EDGE_20_99
 L  EDGE_95_102
 L  EDGE_35_60
 L  EDGE_20_108
 L  EDGE_4_91
 L  EDGE_14_37
 L  EDGE_13_69
 L  EDGE_24_78
 L  EDGE_35_78
 L  EDGE_16_74
 L  EDGE_13_87
 L  EDGE_35_96
 L  EDGE_28_57
 L  EDGE_1_103
 L  EDGE_46_93
 L  EDGE_47_70
 L  EDGE_65_106
 L  EDGE_17_66
 L  EDGE_68_93
 L  EDGE_77_80
 L  EDGE_5_73
 L  EDGE_6_38
 L  EDGE_17_75
 L  EDGE_9_71
 L  EDGE_61_72
 L  EDGE_42_77
 L  EDGE_58_103
 L  EDGE_42_86
 L  EDGE_19_93
 L  EDGE_50_108
 L  EDGE_8_102
 L  EDGE_20_67
 L  EDGE_20_76
 L  EDGE_0_107
 L  EDGE_3_14
 L  EDGE_32_59
 L  EDGE_95_97
 L  EDGE_87_93
 L  EDGE_43_68
 L  EDGE_84_106
 L  EDGE_51_81
 L  EDGE_35_64
 L  EDGE_95_106
 L  EDGE_4_95
 L  EDGE_16_60
 L  EDGE_24_73
 L  EDGE_36_38
 L  EDGE_4_104
 L  EDGE_34_105
 L  EDGE_64_109
 L  EDGE_46_79
 L  EDGE_9_39
 L  EDGE_28_52
 L  EDGE_47_65
 L  EDGE_76_101
 L  EDGE_57_97
 L  EDGE_6_24
 L  EDGE_68_97
 L  EDGE_9_57
 L  EDGE_5_68
 L  EDGE_57_106
 L  EDGE_38_102
 L  EDGE_50_67
 L  EDGE_69_80
 L  EDGE_50_76
 L  EDGE_69_89
 L  EDGE_42_72
 L  EDGE_61_85
 L  EDGE_2_8
 L  EDGE_8_88
 L  EDGE_20_53
 L  EDGE_10_30
 L  EDGE_102_104
 L  EDGE_30_97
 L  EDGE_54_64
 L  EDGE_0_93
 L  EDGE_62_77
 L  EDGE_83_109
 L  EDGE_12_76
 L  EDGE_14_18
 L  EDGE_43_54
 L  EDGE_12_85
 L  EDGE_72_99
 L  EDGE_43_72
 L  EDGE_1_66
 L  EDGE_87_106
 L  EDGE_4_99
 L  EDGE_34_100
 L  EDGE_1_84
 L  EDGE_37_105
 L  EDGE_9_34
 L  EDGE_28_47
 L  EDGE_65_96
 L  EDGE_9_43
 L  EDGE_38_79
 L  EDGE_38_88
 L  EDGE_50_53
 L  EDGE_5_63
 L  EDGE_9_61
 L  EDGE_6_37
 L  EDGE_18_91
 L  EDGE_50_80
 L  EDGE_11_70
 L  EDGE_30_92
 L  EDGE_2_21
 L  EDGE_0_88
 L  EDGE_11_88
 L  EDGE_30_101
 L  EDGE_75_91
 L  EDGE_4_49
 L  EDGE_91_108
 L  EDGE_12_62
 L  EDGE_41_107
 L  EDGE_75_109
 L  EDGE_44_103
 L  EDGE_1_43
 L  EDGE_24_45
 L  EDGE_32_58
 L  EDGE_43_58
 L  EDGE_72_94
 L  EDGE_95_96
 L  EDGE_72_103
 L  EDGE_53_99
 L  EDGE_87_101
 L  EDGE_56_95
 L  EDGE_17_24
 L  EDGE_1_70
 L  EDGE_64_108
 L  EDGE_22_102
 L  EDGE_28_33
 L  EDGE_34_104
 L  EDGE_38_65
 L  EDGE_17_42
 L  EDGE_14_107
 L  EDGE_26_72
 L  EDGE_68_87
 L  EDGE_9_47
 L  EDGE_42_44
 L  EDGE_50_57
 L  EDGE_15_99
 L  EDGE_27_64
 L  EDGE_18_95
 L  EDGE_50_75
 L  EDGE_30_69
 L  EDGE_82_107
 L  EDGE_39_47
 L  EDGE_2_16
 L  EDGE_60_88
 L  EDGE_83_90
 L  EDGE_31_61
 L  EDGE_12_57
 L  EDGE_32_35
 L  EDGE_75_104
 L  EDGE_1_29
 L  EDGE_24_31
 L  EDGE_4_62
 L  EDGE_64_67
 L  EDGE_12_75
 L  EDGE_64_76
 L  EDGE_16_36
 L  EDGE_1_47
 L  EDGE_35_49
 L  EDGE_64_85
 L  EDGE_22_79
 L  EDGE_5_8
 L  EDGE_34_81
 L  EDGE_56_81
 L  EDGE_64_94
 L  EDGE_34_90
 L  EDGE_5_17
 L  EDGE_56_90
 L  EDGE_3_84
 L  EDGE_9_15
 L  EDGE_22_97
 L  EDGE_65_68
 L  EDGE_9_24
 L  EDGE_49_60
 L  EDGE_3_102
 L  EDGE_49_78
 L  EDGE_8_46
 L  EDGE_15_94
 L  EDGE_79_97
 L  EDGE_19_55
 L  EDGE_42_57
 L  EDGE_90_106
 L  EDGE_18_99
 L  EDGE_27_77
 L  EDGE_11_60
 L  EDGE_42_75
 L  EDGE_63_107
 L  EDGE_23_34
 L  EDGE_91_98
 L  EDGE_83_94
 L  EDGE_11_87
 L  EDGE_12_52
 L  EDGE_1_15
 L  EDGE_41_88
 L  EDGE_4_48
 L  EDGE_12_61
 L  EDGE_23_61
 L  EDGE_72_75
 L  EDGE_75_108
 L  EDGE_4_66
 L  EDGE_16_31
 L  EDGE_37_63
 L  EDGE_10_109
 L  EDGE_34_76
 L  EDGE_53_89
 L  EDGE_37_72
 L  EDGE_87_91
 L  EDGE_56_85
 L  EDGE_14_79
 L  EDGE_37_81
 L  EDGE_34_94
 L  EDGE_5_21
 L  EDGE_45_94
 L  EDGE_14_88
 L  EDGE_9_19
 L  EDGE_26_53
 L  EDGE_37_90
 L  EDGE_38_55
 L  EDGE_86_104
 L  EDGE_78_100
 L  EDGE_57_77
 L  EDGE_18_58
 L  EDGE_68_77
 L  EDGE_18_67
 L  EDGE_7_76
 L  EDGE_27_63
 L  EDGE_0_46
 L  EDGE_79_101
 L  EDGE_30_59
 L  EDGE_82_97
 L  EDGE_71_106
 L  EDGE_6_98
 L  EDGE_11_64
 L  EDGE_12_29
 L  EDGE_29_100
 L  EDGE_40_100
 L  EDGE_29_109
 L  EDGE_23_38
 L  EDGE_60_87
 L  EDGE_52_83
 L  EDGE_1_10
 L  EDGE_25_75
 L  EDGE_53_57
 L  EDGE_41_101
 L  EDGE_13_30
 L  EDGE_4_61
 L  EDGE_16_26
 L  EDGE_33_106
 L  EDGE_22_69
 L  EDGE_34_71
 L  EDGE_1_46
 L  EDGE_14_65
 L  EDGE_37_67
 L  EDGE_22_78
 L  EDGE_56_71
 L  EDGE_22_87
 L  EDGE_45_89
 L  EDGE_56_89
 L  EDGE_14_83
 L  EDGE_15_48
 L  EDGE_26_48
 L  EDGE_38_50
 L  EDGE_46_63
 L  EDGE_37_94
 L  EDGE_15_57
 L  EDGE_38_59
 L  EDGE_78_95
 L  EDGE_70_91
 L  EDGE_86_99
 L  EDGE_78_104
 L  EDGE_89_95
 L  EDGE_7_62
 L  EDGE_18_62
 L  EDGE_19_27
 L  EDGE_70_100
 L  EDGE_27_49
 L  EDGE_0_32
 L  EDGE_28_103
 L  EDGE_30_45
 L  EDGE_11_41
 L  EDGE_82_92
 L  EDGE_90_105
 L  EDGE_29_86
 L  EDGE_8_63
 L  EDGE_19_63
 L  EDGE_82_101
 L  EDGE_29_95
 L  EDGE_12_24
 L  EDGE_48_108
 L  EDGE_31_37
 L  EDGE_60_73
 L  EDGE_29_104
 L  EDGE_40_104
 L  EDGE_52_69
 L  EDGE_4_29
 L  EDGE_44_65
 L  EDGE_12_42
 L  EDGE_1_5
 L  EDGE_41_78
 L  EDGE_33_74
 L  EDGE_34_39
 L  EDGE_52_87
 L  EDGE_75_89
 L  EDGE_10_81
 L  EDGE_34_48
 L  EDGE_41_96
 L  EDGE_2_77
 L  EDGE_37_44
 L  EDGE_74_93
 L  EDGE_1_32
 L  EDGE_25_88
 L  EDGE_22_64
 L  EDGE_66_98
 L  EDGE_10_108
 L  EDGE_22_73
 L  EDGE_56_75
 L  EDGE_37_71
 L  EDGE_15_34
 L  EDGE_43_105
 L  EDGE_5_11
 L  EDGE_46_49
 L  EDGE_14_78
 L  EDGE_56_84
 L  EDGE_66_107
 L  EDGE_57_58
 L  EDGE_18_39
 L  EDGE_67_72
 L  EDGE_26_52
 L  EDGE_78_81
 L  EDGE_26_61
 L  EDGE_67_99
 L  EDGE_7_57
 L  EDGE_19_22
 L  EDGE_15_70
 L  EDGE_47_93
 L  EDGE_27_44
 L  EDGE_18_75
 L  EDGE_28_107
 L  EDGE_0_36
 L  EDGE_71_87
 L  EDGE_63_83
 L  EDGE_82_96
 L  EDGE_11_54
 L  EDGE_41_55
 L  EDGE_48_103
 L  EDGE_20_32
 L  EDGE_29_99
 L  EDGE_4_24
 L  EDGE_41_73
 L  EDGE_52_73
 L  EDGE_81_109
 L  EDGE_33_78
 L  EDGE_34_43
 L  EDGE_85_88
 L  EDGE_3_46
 L  EDGE_14_46
 L  EDGE_66_93
 L  EDGE_45_70
 L  EDGE_85_106
 L  EDGE_66_102
 L  EDGE_26_29
 L  EDGE_13_96
 L  EDGE_32_109
 L  EDGE_55_74
 L  EDGE_35_105
 L  EDGE_7_34
 L  EDGE_16_101
 L  EDGE_86_98
 L  EDGE_18_43
 L  EDGE_36_79
 L  EDGE_70_81
 L  EDGE_97_98
 L  EDGE_0_4
 L  EDGE_7_52
 L  EDGE_18_52
 L  EDGE_59_90
 L  EDGE_70_90
 L  EDGE_11_13
 L  EDGE_18_61
 L  EDGE_36_97
 L  EDGE_78_103
 L  EDGE_27_39
 L  EDGE_0_22
 L  EDGE_71_73
 L  EDGE_17_102
 L  EDGE_29_67
 L  EDGE_9_98
 L  EDGE_30_44
 L  EDGE_5_109
 L  EDGE_6_74
 L  EDGE_29_76
 L  EDGE_40_76
 L  EDGE_71_82
 L  EDGE_29_85
 L  EDGE_12_14
 L  EDGE_41_50
 L  EDGE_21_81
 L  EDGE_48_98
 L  EDGE_6_92
 L  EDGE_21_90
 L  EDGE_81_104
 L  EDGE_33_64
 L  EDGE_1_4
 L  EDGE_22_36
 L  EDGE_25_69
 L  EDGE_54_105
 L  EDGE_74_83
 L  EDGE_10_89
 L  EDGE_12_108
 L  EDGE_74_92
 L  EDGE_85_92
 L  EDGE_3_50
 L  EDGE_43_86
 L  EDGE_51_99
 L  EDGE_32_95
 L  EDGE_15_24
 L  EDGE_43_95
 L  EDGE_51_108
 L  EDGE_66_97
 L  EDGE_24_100
 L  EDGE_70_76
 L  EDGE_17_70
 L  EDGE_28_70
 L  EDGE_7_47
 L  EDGE_36_83
 L  EDGE_70_85
 L  EDGE_17_79
 L  EDGE_28_79
 L  EDGE_36_92
 L  EDGE_55_105
 L  EDGE_29_53
 L  EDGE_36_101
 L  EDGE_6_60
 L  EDGE_92_100
 L  EDGE_9_93
 L  EDGE_11_35
 L  EDGE_21_67
 L  EDGE_50_103
 L  EDGE_40_80
 L  EDGE_33_41
 L  EDGE_29_89
 L  EDGE_73_86
 L  EDGE_52_63
 L  EDGE_25_46
 L  EDGE_33_59
 L  EDGE_39_93
 L  EDGE_73_95
 L  EDGE_2_62
 L  EDGE_14_27
 L  EDGE_31_98
 L  EDGE_25_73
 L  EDGE_3_36
 L  EDGE_37_38
 L  EDGE_45_51
 L  EDGE_93_100
 L  EDGE_3_45
 L  EDGE_66_83
 L  EDGE_32_90
 L  EDGE_3_63
 L  EDGE_16_82
 L  EDGE_55_64
 L  EDGE_35_95
 L  EDGE_96_102
 L  EDGE_26_37
 L  EDGE_35_104
 L  EDGE_7_33
 L  EDGE_36_69
 L  EDGE_55_82
 L  EDGE_99_107
 L  EDGE_0_3
 L  EDGE_59_89
 L  EDGE_8_16
 L  EDGE_17_83
 L  EDGE_0_12
 L  EDGE_29_48
 L  EDGE_9_79
 L  EDGE_5_90
 L  EDGE_0_21
 L  EDGE_40_57
 L  EDGE_9_88
 L  EDGE_58_102
 L  EDGE_69_102
 L  EDGE_61_107
 L  EDGE_33_45
 L  EDGE_6_91
 L  EDGE_41_58
 L  EDGE_81_94
 L  EDGE_2_48
 L  EDGE_25_50
 L  EDGE_54_86
 L  EDGE_51_62
 L  EDGE_14_22
 L  EDGE_62_108
 L  EDGE_51_71
 L  EDGE_2_66
 L  EDGE_20_102
 L  EDGE_74_91
 L  EDGE_35_72
 L  EDGE_43_85
 L  EDGE_51_98
 L  EDGE_13_81
 L  EDGE_7_10
 L  EDGE_35_81
 L  EDGE_16_77
 L  EDGE_1_88
 L  EDGE_7_19
 L  EDGE_13_90
 L  EDGE_24_90
 L  EDGE_26_32
 L  EDGE_1_97
 L  EDGE_28_51
 L  EDGE_32_103
 L  EDGE_36_64
 L  EDGE_55_68
 L  EDGE_24_108
 L  EDGE_68_105
 L  EDGE_36_82
 L  EDGE_47_82
 L  EDGE_17_78
 L  EDGE_6_41
 L  EDGE_47_91
 L  EDGE_9_74
 L  EDGE_58_88
 L  EDGE_58_97
 L  EDGE_92_99
 L  EDGE_21_57
 L  EDGE_40_70
 L  EDGE_80_106
 L  EDGE_6_77
 L  EDGE_39_74
 L  EDGE_30_105
 L  EDGE_54_72
 L  EDGE_0_101
 L  EDGE_81_98
 L  EDGE_25_45
 L  EDGE_3_8
 L  EDGE_10_56
 L  EDGE_32_83
 L  EDGE_54_90
 L  EDGE_12_84
 L  EDGE_14_26
 L  EDGE_43_62
 L  EDGE_23_93
 L  EDGE_51_75
 L  EDGE_54_108
 L  EDGE_3_35
 L  EDGE_4_89
 L  EDGE_84_109
 L  EDGE_35_67
 L  EDGE_4_98
 L  EDGE_32_80
 L  EDGE_51_93
 L  EDGE_4_107
 L  EDGE_43_89
 L  EDGE_35_85
 L  EDGE_16_81
 L  EDGE_13_94
 L  EDGE_65_95
 L  EDGE_5_53
 L  EDGE_36_77
 L  EDGE_9_60
 L  EDGE_21_25
 L  EDGE_17_73
 L  EDGE_17_82
 L  EDGE_29_47
 L  EDGE_21_43
 L  EDGE_29_56
 L  EDGE_69_92
 L  EDGE_92_94
 L  EDGE_27_86
 L  EDGE_10_15
 L  EDGE_61_88
 L  EDGE_80_101
 L  EDGE_61_97
 L  EDGE_97_107
 L  EDGE_42_93
 L  EDGE_54_58
 L  EDGE_72_105
 L  EDGE_8_109
 L  EDGE_25_40
 L  EDGE_0_105
 L  EDGE_39_87
 L  EDGE_73_89
 L  EDGE_54_85
 L  EDGE_43_48
 L  EDGE_39_96
 L  EDGE_22_25
 L  EDGE_73_98
 L  EDGE_31_92
 L  EDGE_14_21
 L  EDGE_84_86
 L  EDGE_35_53
 L  EDGE_51_79
 L  EDGE_87_100
 L  EDGE_12_106
 L  EDGE_1_69
 L  EDGE_23_106
 L  EDGE_4_102
 L  EDGE_24_71
 L  EDGE_17_32
 L  EDGE_24_80
 L  EDGE_43_84
 L  EDGE_16_76
 L  EDGE_1_87
 L  EDGE_36_54
 L  EDGE_47_54
 L  EDGE_65_90
 L  EDGE_28_50
 L  EDGE_57_86
 L  EDGE_36_63
 L  EDGE_9_46
 L  EDGE_46_95
 L  EDGE_47_72
 L  EDGE_38_91
 L  EDGE_57_104
 L  EDGE_58_69
 L  EDGE_68_104
 L  EDGE_21_29
 L  EDGE_50_65
 L  EDGE_61_65
 L  EDGE_9_73
 L  EDGE_21_38
 L  EDGE_61_74
 L  EDGE_18_103
 L  EDGE_29_51
 L  EDGE_42_70
 L  EDGE_77_100
 L  EDGE_19_77
 L  EDGE_2_6
 L  EDGE_27_90
 L  EDGE_39_55
 L  EDGE_2_15
 L  EDGE_0_82
 L  EDGE_91_102
 L  EDGE_31_60
 L  EDGE_27_108
 L  EDGE_19_104
 L  EDGE_20_69
 L  EDGE_94_107
 L  EDGE_39_82
 L  EDGE_23_65
 L  EDGE_0_109
 L  EDGE_39_91
 L  EDGE_51_56
 L  EDGE_31_87
 L  EDGE_3_16
 L  EDGE_43_52
 L  EDGE_12_83
 L  EDGE_51_65
 L  EDGE_3_25
 L  EDGE_12_92
 L  EDGE_13_57
 L  EDGE_4_88
 L  EDGE_16_53
 L  EDGE_43_70
 L  EDGE_1_64
 L  EDGE_35_66
 L  EDGE_43_79
 L  EDGE_36_40
 L  EDGE_34_107
 L  EDGE_17_36
 L  EDGE_45_107
 L  EDGE_47_49
 L  EDGE_9_32
 L  EDGE_28_45
 L  EDGE_6_8
 L  EDGE_46_81
 L  EDGE_38_77
 L  EDGE_57_90
 L  EDGE_9_50
 L  EDGE_46_99
 L  EDGE_6_26
 L  EDGE_9_59
 L  EDGE_15_93
 L  EDGE_5_70
 L  EDGE_6_35
 L  EDGE_46_108
 L  EDGE_49_95
 L  EDGE_57_108
 L  EDGE_61_69
 L  EDGE_69_73
 L  EDGE_69_91
 L  EDGE_61_87
 L  EDGE_91_97
 L  EDGE_30_90
 L  EDGE_31_55
 L  EDGE_27_103
 L  EDGE_0_86
 L  EDGE_54_57
 L  EDGE_62_70
 L  EDGE_30_108
 L  EDGE_60_109
 L  EDGE_11_104
 L  EDGE_12_69
 L  EDGE_20_82
 L  EDGE_3_11
 L  EDGE_31_82
 L  EDGE_1_41
 L  EDGE_43_56
 L  EDGE_84_94
 L  EDGE_87_90
 L  EDGE_34_84
 L  EDGE_45_84
 L  EDGE_13_61
 L  EDGE_53_97
 L  EDGE_87_99
 L  EDGE_56_93
 L  EDGE_5_20
 L  EDGE_17_22
 L  EDGE_64_106
 L  EDGE_65_71
 L  EDGE_56_102
 L  EDGE_17_31
 L  EDGE_87_108
 L  EDGE_88_91
 L  EDGE_46_85
 L  EDGE_6_12
 L  EDGE_5_56
 L  EDGE_57_94
 L  EDGE_68_94
 L  EDGE_49_90
 L  EDGE_50_55
 L  EDGE_46_103
 L  EDGE_27_62
 L  EDGE_50_64
 L  EDGE_7_93
 L  EDGE_61_64
 L  EDGE_38_108
 L  EDGE_49_108
 L  EDGE_50_73
 L  EDGE_69_77
 L  EDGE_82_105
 L  EDGE_27_80
 L  EDGE_8_76
 L  EDGE_42_78
 L  EDGE_10_18
 L  EDGE_2_14
 L  EDGE_31_50
 L  EDGE_11_81
 L  EDGE_39_63
 L  EDGE_31_59
 L  EDGE_83_97
 L  EDGE_11_90
 L  EDGE_94_97
 L  EDGE_94_106
 L  EDGE_13_29
 L  EDGE_20_77
 L  EDGE_31_77
 L  EDGE_12_73
 L  EDGE_1_36
 L  EDGE_51_55
 L  EDGE_52_109
 L  EDGE_53_74
 L  EDGE_84_89
 L  EDGE_1_45
 L  EDGE_35_47
 L  EDGE_53_83
 L  EDGE_34_79
 L  EDGE_64_83
 L  EDGE_2_108
 L  EDGE_35_56
 L  EDGE_64_92
 L  EDGE_22_86
 L  EDGE_56_88
 L  EDGE_1_63
 L  EDGE_65_66
 L  EDGE_9_13
 L  EDGE_45_97
 L  EDGE_56_97
 L  EDGE_57_62
 L  EDGE_3_91
 L  EDGE_37_93
 L  EDGE_22_104
 L  EDGE_5_33
 L  EDGE_28_35
 L  EDGE_3_100
 L  EDGE_9_31
 L  EDGE_38_67
 L  EDGE_57_71
 L  EDGE_68_71
 L  EDGE_68_80
 L  EDGE_26_74
 L  EDGE_76_84
 L  EDGE_46_89
 L  EDGE_15_92
 L  EDGE_26_92
 L  EDGE_27_57
 L  EDGE_49_94
 L  EDGE_8_53
 L  EDGE_15_101
 L  EDGE_61_68
 L  EDGE_71_91
 L  EDGE_79_95
 L  EDGE_8_62
 L  EDGE_19_62
 L  EDGE_42_64
 L  EDGE_31_36
 L  EDGE_27_84
 L  EDGE_29_103
 L  EDGE_12_32
 L  EDGE_30_80
 L  EDGE_30_89
 L  EDGE_21_108
 L  EDGE_54_56
 L  EDGE_83_92
 L  EDGE_11_94
 L  EDGE_13_24
 L  EDGE_33_91
 L  EDGE_44_91
 L  EDGE_24_33
 L  EDGE_53_69
 L  EDGE_10_98
 L  EDGE_24_42
 L  EDGE_35_42
 L  EDGE_44_109
 L  EDGE_64_78
 L  EDGE_64_87
 L  EDGE_5_10
 L  EDGE_53_96
 L  EDGE_64_96
 L  EDGE_38_44
 L  EDGE_22_90
 L  EDGE_5_19
 L  EDGE_34_92
 L  EDGE_37_88
 L  EDGE_64_105
 L  EDGE_65_70
 L  EDGE_57_66
 L  EDGE_86_102
 L  EDGE_76_79
 L  EDGE_9_26
 L  EDGE_15_60
 L  EDGE_22_108
 L  EDGE_67_98
 L  EDGE_37_106
 L  EDGE_68_75
 L  EDGE_78_107
 L  EDGE_46_84
 L  EDGE_68_84
 L  EDGE_70_103
 L  EDGE_38_80
 L  EDGE_49_80
 L  EDGE_7_74
 L  EDGE_19_39
 L  EDGE_26_87
 L  EDGE_18_83
 L  EDGE_8_48
 L  EDGE_26_96
 L  EDGE_71_86
 L  EDGE_82_95
 L  EDGE_63_91
 L  EDGE_8_66
 L  EDGE_12_27
 L  EDGE_23_27
 L  EDGE_41_72
 L  EDGE_21_103
 L  EDGE_4_32
 L  EDGE_11_80
 L  EDGE_41_81
 L  EDGE_1_8
 L  EDGE_20_58
 L  EDGE_31_58
 L  EDGE_33_77
 L  EDGE_44_77
 L  EDGE_1_17
 L  EDGE_52_81
 L  EDGE_94_105
 L  EDGE_53_64
 L  EDGE_10_93
 L  EDGE_44_95
 L  EDGE_56_69
 L  EDGE_1_44
 L  EDGE_37_65
 L  EDGE_22_76
 L  EDGE_53_91
 L  EDGE_9_12
 L  EDGE_5_23
 L  EDGE_86_97
 L  EDGE_5_32
 L  EDGE_7_51
 L  EDGE_46_70
 L  EDGE_67_102
 L  EDGE_68_70
 L  EDGE_68_79
 L  EDGE_27_38
 L  EDGE_36_105
 L  EDGE_26_82
 L  EDGE_0_30
 L  EDGE_7_78
 L  EDGE_18_78
 L  EDGE_11_39
 L  EDGE_98_107
 L  EDGE_48_88
 L  EDGE_11_48
 L  EDGE_8_61
 L  EDGE_20_26
 L  EDGE_82_99
 L  EDGE_71_108
 L  EDGE_0_66
 L  EDGE_6_100
 L  EDGE_52_67
 L  EDGE_60_80
 L  EDGE_63_104
 L  EDGE_12_40
 L  EDGE_41_76
 L  EDGE_75_78
 L  EDGE_44_72
 L  EDGE_13_14
 L  EDGE_4_45
 L  EDGE_10_88
 L  EDGE_33_90
 L  EDGE_45_55
 L  EDGE_72_81
 L  EDGE_22_62
 L  EDGE_22_71
 L  EDGE_2_102
 L  EDGE_45_82
 L  EDGE_67_79
 L  EDGE_46_56
 L  EDGE_86_92
 L  EDGE_9_16
 L  EDGE_15_50
 L  EDGE_49_52
 L  EDGE_26_59
 L  EDGE_18_55
 L  EDGE_70_93
 L  EDGE_15_68
 L  EDGE_26_68
 L  EDGE_18_64
 L  EDGE_8_29
 L  EDGE_47_100
 L  EDGE_79_80
 L  EDGE_19_38
 L  EDGE_27_51
 L  EDGE_28_105
 L  EDGE_79_89
 L  EDGE_30_47
 L  EDGE_42_49
 L  EDGE_48_83
 L  EDGE_29_79
 L  EDGE_82_85
 L  EDGE_8_56
 L  EDGE_20_21
 L  EDGE_40_88
 L  EDGE_41_53
 L  EDGE_29_97
 L  EDGE_41_62
 L  EDGE_81_107
 L  EDGE_104_109
 L  EDGE_4_31
 L  EDGE_52_80
 L  EDGE_33_76
 L  EDGE_53_54
 L  EDGE_2_79
 L  EDGE_16_23
 L  EDGE_22_57
 L  EDGE_56_59
 L  EDGE_93_108
 L  EDGE_56_68
 L  EDGE_66_100
 L  EDGE_56_77
 L  EDGE_3_71
 L  EDGE_37_73
 L  EDGE_22_84
 L  EDGE_46_51
 L  EDGE_67_74
 L  EDGE_38_47
 L  EDGE_7_41
 L  EDGE_3_89
 L  EDGE_55_90
 L  EDGE_97_105
 L  EDGE_27_28
 L  EDGE_70_97
 L  EDGE_48_69
 L  EDGE_79_84
 L  EDGE_63_67
 L  EDGE_19_42
 L  EDGE_17_109
 L  EDGE_29_74
 L  EDGE_9_105
 L  EDGE_6_81
 L  EDGE_11_47
 L  EDGE_48_96
 L  EDGE_60_61
 L  EDGE_60_70
 L  EDGE_1_11
 L  EDGE_44_80
 L  EDGE_34_45
 L  EDGE_53_58
 L  EDGE_22_52
 L  EDGE_45_54
 L  EDGE_15_31
 L  EDGE_7_27
 L  EDGE_4_101
 L  EDGE_18_27
 L  EDGE_13_107
 L  EDGE_36_72
 L  EDGE_15_49
 L  EDGE_55_85
 L  EDGE_78_87
 L  EDGE_15_58
 L  EDGE_28_77
 L  EDGE_78_96
 L  EDGE_18_54
 L  EDGE_36_90
 L  EDGE_55_103
 L  EDGE_27_32
 L  EDGE_48_64
 L  EDGE_28_95
 L  EDGE_19_37
 L  EDGE_30_37
 L  EDGE_92_107
 L  EDGE_82_84
 L  EDGE_40_78
 L  EDGE_29_87
 L  EDGE_12_16
 L  EDGE_60_65
 L  EDGE_44_48
 L  EDGE_40_96
 L  EDGE_52_61
 L  EDGE_25_44
 L  EDGE_10_55
 L  EDGE_6_103
 L  EDGE_44_57
 L  EDGE_2_51
 L  EDGE_10_64
 L  EDGE_44_66
 L  EDGE_54_98
 L  EDGE_22_38
 L  EDGE_25_71
 L  EDGE_34_49
 L  EDGE_45_49
 L  EDGE_25_80
 L  EDGE_51_83
 L  EDGE_32_88
 L  EDGE_15_17
 L  EDGE_22_65
 L  EDGE_96_100
 L  EDGE_7_22
 L  EDGE_67_73
 L  EDGE_96_109
 L  EDGE_36_67
 L  EDGE_1_109
 L  EDGE_18_40
 L  EDGE_67_91
 L  EDGE_78_91
 L  EDGE_7_49
 L  EDGE_28_81
 L  EDGE_70_96
 L  EDGE_17_90
 L  EDGE_11_19
 L  EDGE_6_62
 L  EDGE_40_64
 L  EDGE_69_100
 L  EDGE_63_75
 L  EDGE_9_104
 L  EDGE_21_69
 L  EDGE_61_105
 L  EDGE_40_82
 L  EDGE_73_79
 L  EDGE_6_89
 L  EDGE_25_39
 L  EDGE_10_50
 L  EDGE_62_88
 L  EDGE_41_65
 L  EDGE_25_48
 L  EDGE_10_59
 L  EDGE_2_55
 L  EDGE_54_93
 L  EDGE_10_68
 L  EDGE_22_33
 L  EDGE_34_35
 L  EDGE_54_102
 L  EDGE_62_106
 L  EDGE_12_96
 L  EDGE_23_96
 L  EDGE_51_78
 L  EDGE_3_38
 L  EDGE_2_82
 L  EDGE_14_47
 L  EDGE_13_79
COLUMNS
    x_0         OBJ       -8
    x_0         EDGE_0_103  1.0
    x_0         EDGE_0_107  1.0
    x_0         EDGE_0_93  1.0
    x_0         EDGE_0_88  1.0
    x_0         EDGE_0_46  1.0
    x_0         EDGE_0_32  1.0
    x_0         EDGE_0_36  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_22  1.0
    x_0         EDGE_0_3  1.0
    x_0         EDGE_0_12  1.0
    x_0         EDGE_0_21  1.0
    x_0         EDGE_0_101  1.0
    x_0         EDGE_0_105  1.0
    x_0         EDGE_0_82  1.0
    x_0         EDGE_0_109  1.0
    x_0         EDGE_0_86  1.0
    x_0         EDGE_0_30  1.0
    x_0         EDGE_0_66  1.0
    x_1         OBJ       -12
    x_1         EDGE_1_99  1.0
    x_1         EDGE_1_103  1.0
    x_1         EDGE_1_66  1.0
    x_1         EDGE_1_84  1.0
    x_1         EDGE_1_43  1.0
    x_1         EDGE_1_70  1.0
    x_1         EDGE_1_29  1.0
    x_1         EDGE_1_47  1.0
    x_1         EDGE_1_15  1.0
    x_1         EDGE_1_10  1.0
    x_1         EDGE_1_46  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_32  1.0
    x_1         EDGE_1_4  1.0
    x_1         EDGE_1_88  1.0
    x_1         EDGE_1_97  1.0
    x_1         EDGE_1_69  1.0
    x_1         EDGE_1_87  1.0
    x_1         EDGE_1_64  1.0
    x_1         EDGE_1_41  1.0
    x_1         EDGE_1_36  1.0
    x_1         EDGE_1_45  1.0
    x_1         EDGE_1_63  1.0
    x_1         EDGE_1_8  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_44  1.0
    x_1         EDGE_1_11  1.0
    x_1         EDGE_1_109  1.0
    x_2         OBJ       -11
    x_2         EDGE_2_50  1.0
    x_2         EDGE_2_45  1.0
    x_2         EDGE_2_8  1.0
    x_2         EDGE_2_21  1.0
    x_2         EDGE_2_16  1.0
    x_2         EDGE_2_77  1.0
    x_2         EDGE_2_62  1.0
    x_2         EDGE_2_48  1.0
    x_2         EDGE_2_66  1.0
    x_2         EDGE_2_6  1.0
    x_2         EDGE_2_15  1.0
    x_2         EDGE_2_14  1.0
    x_2         EDGE_2_108  1.0
    x_2         EDGE_2_102  1.0
    x_2         EDGE_2_79  1.0
    x_2         EDGE_2_51  1.0
    x_2         EDGE_2_55  1.0
    x_2         EDGE_2_82  1.0
    x_3         OBJ       -47
    x_3         EDGE_3_24  1.0
    x_3         EDGE_3_14  1.0
    x_3         EDGE_3_84  1.0
    x_3         EDGE_3_102  1.0
    x_3         EDGE_3_46  1.0
    x_3         EDGE_3_50  1.0
    x_3         EDGE_3_36  1.0
    x_3         EDGE_3_45  1.0
    x_3         EDGE_3_63  1.0
    x_3         EDGE_0_3  1.0
    x_3         EDGE_3_8  1.0
    x_3         EDGE_3_35  1.0
    x_3         EDGE_3_16  1.0
    x_3         EDGE_3_25  1.0
    x_3         EDGE_3_11  1.0
    x_3         EDGE_3_91  1.0
    x_3         EDGE_3_100  1.0
    x_3         EDGE_3_71  1.0
    x_3         EDGE_3_89  1.0
    x_3         EDGE_3_38  1.0
    x_4         OBJ       -22
    x_4         EDGE_4_91  1.0
    x_4         EDGE_4_95  1.0
    x_4         EDGE_4_104  1.0
    x_4         EDGE_4_99  1.0
    x_4         EDGE_4_49  1.0
    x_4         EDGE_4_62  1.0
    x_4         EDGE_4_48  1.0
    x_4         EDGE_4_66  1.0
    x_4         EDGE_4_61  1.0
    x_4         EDGE_4_29  1.0
    x_4         EDGE_4_24  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_1_4  1.0
    x_4         EDGE_4_89  1.0
    x_4         EDGE_4_98  1.0
    x_4         EDGE_4_107  1.0
    x_4         EDGE_4_102  1.0
    x_4         EDGE_4_88  1.0
    x_4         EDGE_4_32  1.0
    x_4         EDGE_4_45  1.0
    x_4         EDGE_4_31  1.0
    x_4         EDGE_4_101  1.0
    x_5         OBJ       -95
    x_5         EDGE_5_69  1.0
    x_5         EDGE_5_73  1.0
    x_5         EDGE_5_68  1.0
    x_5         EDGE_5_63  1.0
    x_5         EDGE_5_8  1.0
    x_5         EDGE_5_17  1.0
    x_5         EDGE_5_21  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_11  1.0
    x_5         EDGE_5_109  1.0
    x_5         EDGE_5_90  1.0
    x_5         EDGE_5_53  1.0
    x_5         EDGE_5_70  1.0
    x_5         EDGE_5_20  1.0
    x_5         EDGE_5_56  1.0
    x_5         EDGE_5_33  1.0
    x_5         EDGE_5_10  1.0
    x_5         EDGE_5_19  1.0
    x_5         EDGE_5_23  1.0
    x_5         EDGE_5_32  1.0
    x_6         OBJ       -86
    x_6         EDGE_6_48  1.0
    x_6         EDGE_6_38  1.0
    x_6         EDGE_6_24  1.0
    x_6         EDGE_6_37  1.0
    x_6         EDGE_6_98  1.0
    x_6         EDGE_6_74  1.0
    x_6         EDGE_6_92  1.0
    x_6         EDGE_6_60  1.0
    x_6         EDGE_6_91  1.0
    x_6         EDGE_6_41  1.0
    x_6         EDGE_6_77  1.0
    x_6         EDGE_2_6  1.0
    x_6         EDGE_6_8  1.0
    x_6         EDGE_6_26  1.0
    x_6         EDGE_6_35  1.0
    x_6         EDGE_6_12  1.0
    x_6         EDGE_6_100  1.0
    x_6         EDGE_6_81  1.0
    x_6         EDGE_6_103  1.0
    x_6         EDGE_6_62  1.0
    x_6         EDGE_6_89  1.0
    x_7         OBJ       -40
    x_7         EDGE_7_76  1.0
    x_7         EDGE_7_62  1.0
    x_7         EDGE_7_57  1.0
    x_7         EDGE_7_34  1.0
    x_7         EDGE_7_52  1.0
    x_7         EDGE_7_47  1.0
    x_7         EDGE_7_33  1.0
    x_7         EDGE_7_10  1.0
    x_7         EDGE_7_19  1.0
    x_7         EDGE_7_93  1.0
    x_7         EDGE_7_74  1.0
    x_7         EDGE_7_51  1.0
    x_7         EDGE_7_78  1.0
    x_7         EDGE_7_41  1.0
    x_7         EDGE_7_27  1.0
    x_7         EDGE_7_22  1.0
    x_7         EDGE_7_49  1.0
    x_8         OBJ       -33
    x_8         EDGE_8_103  1.0
    x_8         EDGE_8_98  1.0
    x_8         EDGE_8_102  1.0
    x_8         EDGE_2_8  1.0
    x_8         EDGE_8_88  1.0
    x_8         EDGE_5_8  1.0
    x_8         EDGE_8_46  1.0
    x_8         EDGE_8_63  1.0
    x_8         EDGE_8_16  1.0
    x_8         EDGE_3_8  1.0
    x_8         EDGE_8_109  1.0
    x_8         EDGE_6_8  1.0
    x_8         EDGE_8_76  1.0
    x_8         EDGE_8_53  1.0
    x_8         EDGE_8_62  1.0
    x_8         EDGE_8_48  1.0
    x_8         EDGE_8_66  1.0
    x_8         EDGE_1_8  1.0
    x_8         EDGE_8_61  1.0
    x_8         EDGE_8_29  1.0
    x_8         EDGE_8_56  1.0
    x_9         OBJ       -78
    x_9         EDGE_9_85  1.0
    x_9         EDGE_9_71  1.0
    x_9         EDGE_9_39  1.0
    x_9         EDGE_9_57  1.0
    x_9         EDGE_9_34  1.0
    x_9         EDGE_9_43  1.0
    x_9         EDGE_9_61  1.0
    x_9         EDGE_9_47  1.0
    x_9         EDGE_9_15  1.0
    x_9         EDGE_9_24  1.0
    x_9         EDGE_9_19  1.0
    x_9         EDGE_9_98  1.0
    x_9         EDGE_9_93  1.0
    x_9         EDGE_9_79  1.0
    x_9         EDGE_9_88  1.0
    x_9         EDGE_9_74  1.0
    x_9         EDGE_9_60  1.0
    x_9         EDGE_9_46  1.0
    x_9         EDGE_9_73  1.0
    x_9         EDGE_9_32  1.0
    x_9         EDGE_9_50  1.0
    x_9         EDGE_9_59  1.0
    x_9         EDGE_9_13  1.0
    x_9         EDGE_9_31  1.0
    x_9         EDGE_9_26  1.0
    x_9         EDGE_9_12  1.0
    x_9         EDGE_9_16  1.0
    x_9         EDGE_9_105  1.0
    x_9         EDGE_9_104  1.0
    x_10        OBJ       -28
    x_10        EDGE_10_27  1.0
    x_10        EDGE_10_54  1.0
    x_10        EDGE_10_63  1.0
    x_10        EDGE_10_40  1.0
    x_10        EDGE_10_30  1.0
    x_10        EDGE_10_109  1.0
    x_10        EDGE_1_10  1.0
    x_10        EDGE_10_81  1.0
    x_10        EDGE_10_108  1.0
    x_10        EDGE_10_89  1.0
    x_10        EDGE_7_10  1.0
    x_10        EDGE_10_56  1.0
    x_10        EDGE_10_15  1.0
    x_10        EDGE_10_18  1.0
    x_10        EDGE_10_98  1.0
    x_10        EDGE_5_10  1.0
    x_10        EDGE_10_93  1.0
    x_10        EDGE_10_88  1.0
    x_10        EDGE_10_55  1.0
    x_10        EDGE_10_64  1.0
    x_10        EDGE_10_50  1.0
    x_10        EDGE_10_59  1.0
    x_10        EDGE_10_68  1.0
    x_11        OBJ       -78
    x_11        EDGE_11_70  1.0
    x_11        EDGE_11_88  1.0
    x_11        EDGE_11_60  1.0
    x_11        EDGE_11_87  1.0
    x_11        EDGE_11_64  1.0
    x_11        EDGE_11_41  1.0
    x_11        EDGE_5_11  1.0
    x_11        EDGE_11_54  1.0
    x_11        EDGE_11_13  1.0
    x_11        EDGE_11_35  1.0
    x_11        EDGE_11_104  1.0
    x_11        EDGE_3_11  1.0
    x_11        EDGE_11_81  1.0
    x_11        EDGE_11_90  1.0
    x_11        EDGE_11_94  1.0
    x_11        EDGE_11_80  1.0
    x_11        EDGE_11_39  1.0
    x_11        EDGE_11_48  1.0
    x_11        EDGE_11_47  1.0
    x_11        EDGE_1_11  1.0
    x_11        EDGE_11_19  1.0
    x_12        OBJ       -5
    x_12        EDGE_12_109  1.0
    x_12        EDGE_12_76  1.0
    x_12        EDGE_12_85  1.0
    x_12        EDGE_12_62  1.0
    x_12        EDGE_12_57  1.0
    x_12        EDGE_12_75  1.0
    x_12        EDGE_12_52  1.0
    x_12        EDGE_12_61  1.0
    x_12        EDGE_12_29  1.0
    x_12        EDGE_12_24  1.0
    x_12        EDGE_12_42  1.0
    x_12        EDGE_12_14  1.0
    x_12        EDGE_12_108  1.0
    x_12        EDGE_0_12  1.0
    x_12        EDGE_12_84  1.0
    x_12        EDGE_12_106  1.0
    x_12        EDGE_12_83  1.0
    x_12        EDGE_12_92  1.0
    x_12        EDGE_12_69  1.0
    x_12        EDGE_6_12  1.0
    x_12        EDGE_12_73  1.0
    x_12        EDGE_12_32  1.0
    x_12        EDGE_12_27  1.0
    x_12        EDGE_9_12  1.0
    x_12        EDGE_12_40  1.0
    x_12        EDGE_12_16  1.0
    x_12        EDGE_12_96  1.0
    x_13        OBJ       -75
    x_13        EDGE_13_69  1.0
    x_13        EDGE_13_87  1.0
    x_13        EDGE_13_30  1.0
    x_13        EDGE_13_96  1.0
    x_13        EDGE_11_13  1.0
    x_13        EDGE_13_81  1.0
    x_13        EDGE_13_90  1.0
    x_13        EDGE_13_94  1.0
    x_13        EDGE_13_57  1.0
    x_13        EDGE_13_61  1.0
    x_13        EDGE_13_29  1.0
    x_13        EDGE_9_13  1.0
    x_13        EDGE_13_24  1.0
    x_13        EDGE_13_14  1.0
    x_13        EDGE_13_107  1.0
    x_13        EDGE_13_79  1.0
    x_14        OBJ       -88
    x_14        EDGE_14_24  1.0
    x_14        EDGE_14_42  1.0
    x_14        EDGE_14_37  1.0
    x_14        EDGE_3_14  1.0
    x_14        EDGE_14_18  1.0
    x_14        EDGE_14_107  1.0
    x_14        EDGE_14_79  1.0
    x_14        EDGE_14_88  1.0
    x_14        EDGE_14_65  1.0
    x_14        EDGE_14_83  1.0
    x_14        EDGE_14_78  1.0
    x_14        EDGE_14_46  1.0
    x_14        EDGE_12_14  1.0
    x_14        EDGE_14_27  1.0
    x_14        EDGE_14_22  1.0
    x_14        EDGE_14_26  1.0
    x_14        EDGE_14_21  1.0
    x_14        EDGE_2_14  1.0
    x_14        EDGE_13_14  1.0
    x_14        EDGE_14_47  1.0
    x_15        OBJ       -21
    x_15        EDGE_15_99  1.0
    x_15        EDGE_9_15  1.0
    x_15        EDGE_15_94  1.0
    x_15        EDGE_1_15  1.0
    x_15        EDGE_15_48  1.0
    x_15        EDGE_15_57  1.0
    x_15        EDGE_15_34  1.0
    x_15        EDGE_15_70  1.0
    x_15        EDGE_15_24  1.0
    x_15        EDGE_10_15  1.0
    x_15        EDGE_2_15  1.0
    x_15        EDGE_15_93  1.0
    x_15        EDGE_15_92  1.0
    x_15        EDGE_15_101  1.0
    x_15        EDGE_15_60  1.0
    x_15        EDGE_15_50  1.0
    x_15        EDGE_15_68  1.0
    x_15        EDGE_15_31  1.0
    x_15        EDGE_15_49  1.0
    x_15        EDGE_15_58  1.0
    x_15        EDGE_15_17  1.0
    x_16        OBJ       -56
    x_16        EDGE_16_84  1.0
    x_16        EDGE_16_93  1.0
    x_16        EDGE_16_106  1.0
    x_16        EDGE_16_74  1.0
    x_16        EDGE_16_60  1.0
    x_16        EDGE_2_16  1.0
    x_16        EDGE_16_36  1.0
    x_16        EDGE_16_31  1.0
    x_16        EDGE_16_26  1.0
    x_16        EDGE_16_101  1.0
    x_16        EDGE_16_82  1.0
    x_16        EDGE_8_16  1.0
    x_16        EDGE_16_77  1.0
    x_16        EDGE_16_81  1.0
    x_16        EDGE_16_76  1.0
    x_16        EDGE_3_16  1.0
    x_16        EDGE_16_53  1.0
    x_16        EDGE_9_16  1.0
    x_16        EDGE_16_23  1.0
    x_16        EDGE_12_16  1.0
    x_17        OBJ       -82
    x_17        EDGE_17_85  1.0
    x_17        EDGE_17_62  1.0
    x_17        EDGE_17_66  1.0
    x_17        EDGE_17_75  1.0
    x_17        EDGE_17_24  1.0
    x_17        EDGE_17_42  1.0
    x_17        EDGE_5_17  1.0
    x_17        EDGE_17_102  1.0
    x_17        EDGE_17_70  1.0
    x_17        EDGE_17_79  1.0
    x_17        EDGE_17_83  1.0
    x_17        EDGE_17_78  1.0
    x_17        EDGE_17_73  1.0
    x_17        EDGE_17_82  1.0
    x_17        EDGE_17_32  1.0
    x_17        EDGE_17_36  1.0
    x_17        EDGE_17_22  1.0
    x_17        EDGE_17_31  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_17_109  1.0
    x_17        EDGE_15_17  1.0
    x_17        EDGE_17_90  1.0
    x_18        OBJ       -51
    x_18        EDGE_18_44  1.0
    x_18        EDGE_14_18  1.0
    x_18        EDGE_18_91  1.0
    x_18        EDGE_18_95  1.0
    x_18        EDGE_18_99  1.0
    x_18        EDGE_18_58  1.0
    x_18        EDGE_18_67  1.0
    x_18        EDGE_18_62  1.0
    x_18        EDGE_18_39  1.0
    x_18        EDGE_18_75  1.0
    x_18        EDGE_18_43  1.0
    x_18        EDGE_18_52  1.0
    x_18        EDGE_18_61  1.0
    x_18        EDGE_18_103  1.0
    x_18        EDGE_10_18  1.0
    x_18        EDGE_18_83  1.0
    x_18        EDGE_18_78  1.0
    x_18        EDGE_18_55  1.0
    x_18        EDGE_18_64  1.0
    x_18        EDGE_18_27  1.0
    x_18        EDGE_18_54  1.0
    x_18        EDGE_18_40  1.0
    x_19        OBJ       -93
    x_19        EDGE_19_93  1.0
    x_19        EDGE_19_55  1.0
    x_19        EDGE_9_19  1.0
    x_19        EDGE_19_27  1.0
    x_19        EDGE_19_63  1.0
    x_19        EDGE_19_22  1.0
    x_19        EDGE_7_19  1.0
    x_19        EDGE_19_77  1.0
    x_19        EDGE_19_104  1.0
    x_19        EDGE_19_62  1.0
    x_19        EDGE_5_19  1.0
    x_19        EDGE_19_39  1.0
    x_19        EDGE_19_38  1.0
    x_19        EDGE_19_42  1.0
    x_19        EDGE_19_37  1.0
    x_19        EDGE_11_19  1.0
    x_20        OBJ       -66
    x_20        EDGE_20_81  1.0
    x_20        EDGE_20_99  1.0
    x_20        EDGE_20_108  1.0
    x_20        EDGE_20_67  1.0
    x_20        EDGE_20_76  1.0
    x_20        EDGE_20_53  1.0
    x_20        EDGE_20_32  1.0
    x_20        EDGE_20_102  1.0
    x_20        EDGE_20_69  1.0
    x_20        EDGE_20_82  1.0
    x_20        EDGE_5_20  1.0
    x_20        EDGE_20_77  1.0
    x_20        EDGE_20_58  1.0
    x_20        EDGE_20_26  1.0
    x_20        EDGE_20_21  1.0
    x_21        OBJ       -48
    x_21        EDGE_2_21  1.0
    x_21        EDGE_5_21  1.0
    x_21        EDGE_21_81  1.0
    x_21        EDGE_21_90  1.0
    x_21        EDGE_21_67  1.0
    x_21        EDGE_0_21  1.0
    x_21        EDGE_21_57  1.0
    x_21        EDGE_21_25  1.0
    x_21        EDGE_21_43  1.0
    x_21        EDGE_14_21  1.0
    x_21        EDGE_21_29  1.0
    x_21        EDGE_21_38  1.0
    x_21        EDGE_21_108  1.0
    x_21        EDGE_21_103  1.0
    x_21        EDGE_20_21  1.0
    x_21        EDGE_21_69  1.0
    x_22        OBJ       -70
    x_22        EDGE_22_28  1.0
    x_22        EDGE_22_46  1.0
    x_22        EDGE_22_32  1.0
    x_22        EDGE_22_102  1.0
    x_22        EDGE_22_79  1.0
    x_22        EDGE_22_97  1.0
    x_22        EDGE_22_69  1.0
    x_22        EDGE_22_78  1.0
    x_22        EDGE_22_87  1.0
    x_22        EDGE_22_64  1.0
    x_22        EDGE_22_73  1.0
    x_22        EDGE_19_22  1.0
    x_22        EDGE_0_22  1.0
    x_22        EDGE_22_36  1.0
    x_22        EDGE_14_22  1.0
    x_22        EDGE_22_25  1.0
    x_22        EDGE_17_22  1.0
    x_22        EDGE_22_86  1.0
    x_22        EDGE_22_104  1.0
    x_22        EDGE_22_90  1.0
    x_22        EDGE_22_108  1.0
    x_22        EDGE_22_76  1.0
    x_22        EDGE_22_62  1.0
    x_22        EDGE_22_71  1.0
    x_22        EDGE_22_57  1.0
    x_22        EDGE_22_84  1.0
    x_22        EDGE_22_52  1.0
    x_22        EDGE_22_38  1.0
    x_22        EDGE_22_65  1.0
    x_22        EDGE_7_22  1.0
    x_22        EDGE_22_33  1.0
    x_23        OBJ       -57
    x_23        EDGE_23_100  1.0
    x_23        EDGE_23_34  1.0
    x_23        EDGE_23_61  1.0
    x_23        EDGE_23_38  1.0
    x_23        EDGE_23_93  1.0
    x_23        EDGE_23_106  1.0
    x_23        EDGE_23_65  1.0
    x_23        EDGE_23_27  1.0
    x_23        EDGE_5_23  1.0
    x_23        EDGE_16_23  1.0
    x_23        EDGE_23_96  1.0
    x_24        OBJ       -65
    x_24        EDGE_3_24  1.0
    x_24        EDGE_14_24  1.0
    x_24        EDGE_24_83  1.0
    x_24        EDGE_24_92  1.0
    x_24        EDGE_24_78  1.0
    x_24        EDGE_24_73  1.0
    x_24        EDGE_6_24  1.0
    x_24        EDGE_24_45  1.0
    x_24        EDGE_17_24  1.0
    x_24        EDGE_24_31  1.0
    x_24        EDGE_9_24  1.0
    x_24        EDGE_12_24  1.0
    x_24        EDGE_4_24  1.0
    x_24        EDGE_15_24  1.0
    x_24        EDGE_24_100  1.0
    x_24        EDGE_24_90  1.0
    x_24        EDGE_24_108  1.0
    x_24        EDGE_24_71  1.0
    x_24        EDGE_24_80  1.0
    x_24        EDGE_13_24  1.0
    x_24        EDGE_24_33  1.0
    x_24        EDGE_24_42  1.0
    x_25        OBJ       -35
    x_25        EDGE_25_75  1.0
    x_25        EDGE_25_88  1.0
    x_25        EDGE_25_69  1.0
    x_25        EDGE_25_46  1.0
    x_25        EDGE_25_73  1.0
    x_25        EDGE_25_50  1.0
    x_25        EDGE_25_45  1.0
    x_25        EDGE_21_25  1.0
    x_25        EDGE_25_40  1.0
    x_25        EDGE_22_25  1.0
    x_25        EDGE_3_25  1.0
    x_25        EDGE_25_44  1.0
    x_25        EDGE_25_71  1.0
    x_25        EDGE_25_80  1.0
    x_25        EDGE_25_39  1.0
    x_25        EDGE_25_48  1.0
    x_26        OBJ       -5
    x_26        EDGE_26_72  1.0
    x_26        EDGE_26_53  1.0
    x_26        EDGE_16_26  1.0
    x_26        EDGE_26_48  1.0
    x_26        EDGE_26_52  1.0
    x_26        EDGE_26_61  1.0
    x_26        EDGE_26_29  1.0
    x_26        EDGE_26_37  1.0
    x_26        EDGE_26_32  1.0
    x_26        EDGE_14_26  1.0
    x_26        EDGE_6_26  1.0
    x_26        EDGE_26_74  1.0
    x_26        EDGE_26_92  1.0
    x_26        EDGE_9_26  1.0
    x_26        EDGE_26_87  1.0
    x_26        EDGE_26_96  1.0
    x_26        EDGE_26_82  1.0
    x_26        EDGE_20_26  1.0
    x_26        EDGE_26_59  1.0
    x_26        EDGE_26_68  1.0
    x_27        OBJ       -4
    x_27        EDGE_10_27  1.0
    x_27        EDGE_27_102  1.0
    x_27        EDGE_27_64  1.0
    x_27        EDGE_27_77  1.0
    x_27        EDGE_27_63  1.0
    x_27        EDGE_19_27  1.0
    x_27        EDGE_27_49  1.0
    x_27        EDGE_27_44  1.0
    x_27        EDGE_27_39  1.0
    x_27        EDGE_14_27  1.0
    x_27        EDGE_27_86  1.0
    x_27        EDGE_27_90  1.0
    x_27        EDGE_27_108  1.0
    x_27        EDGE_27_103  1.0
    x_27        EDGE_27_62  1.0
    x_27        EDGE_27_80  1.0
    x_27        EDGE_27_57  1.0
    x_27        EDGE_27_84  1.0
    x_27        EDGE_12_27  1.0
    x_27        EDGE_23_27  1.0
    x_27        EDGE_27_38  1.0
    x_27        EDGE_27_51  1.0
    x_27        EDGE_27_28  1.0
    x_27        EDGE_7_27  1.0
    x_27        EDGE_18_27  1.0
    x_27        EDGE_27_32  1.0
    x_28        OBJ       -47
    x_28        EDGE_22_28  1.0
    x_28        EDGE_28_57  1.0
    x_28        EDGE_28_52  1.0
    x_28        EDGE_28_47  1.0
    x_28        EDGE_28_33  1.0
    x_28        EDGE_28_103  1.0
    x_28        EDGE_28_107  1.0
    x_28        EDGE_28_70  1.0
    x_28        EDGE_28_79  1.0
    x_28        EDGE_28_51  1.0
    x_28        EDGE_28_50  1.0
    x_28        EDGE_28_45  1.0
    x_28        EDGE_28_35  1.0
    x_28        EDGE_28_105  1.0
    x_28        EDGE_27_28  1.0
    x_28        EDGE_28_77  1.0
    x_28        EDGE_28_95  1.0
    x_28        EDGE_28_81  1.0
    x_29        OBJ       -60
    x_29        EDGE_29_54  1.0
    x_29        EDGE_1_29  1.0
    x_29        EDGE_12_29  1.0
    x_29        EDGE_29_100  1.0
    x_29        EDGE_29_109  1.0
    x_29        EDGE_29_86  1.0
    x_29        EDGE_29_95  1.0
    x_29        EDGE_29_104  1.0
    x_29        EDGE_4_29  1.0
    x_29        EDGE_29_99  1.0
    x_29        EDGE_26_29  1.0
    x_29        EDGE_29_67  1.0
    x_29        EDGE_29_76  1.0
    x_29        EDGE_29_85  1.0
    x_29        EDGE_29_53  1.0
    x_29        EDGE_29_89  1.0
    x_29        EDGE_29_48  1.0
    x_29        EDGE_29_47  1.0
    x_29        EDGE_29_56  1.0
    x_29        EDGE_21_29  1.0
    x_29        EDGE_29_51  1.0
    x_29        EDGE_13_29  1.0
    x_29        EDGE_29_103  1.0
    x_29        EDGE_8_29  1.0
    x_29        EDGE_29_79  1.0
    x_29        EDGE_29_97  1.0
    x_29        EDGE_29_74  1.0
    x_29        EDGE_29_87  1.0
    x_30        OBJ       -41
    x_30        EDGE_30_107  1.0
    x_30        EDGE_10_30  1.0
    x_30        EDGE_30_97  1.0
    x_30        EDGE_30_92  1.0
    x_30        EDGE_30_101  1.0
    x_30        EDGE_30_69  1.0
    x_30        EDGE_30_59  1.0
    x_30        EDGE_13_30  1.0
    x_30        EDGE_30_45  1.0
    x_30        EDGE_30_44  1.0
    x_30        EDGE_30_105  1.0
    x_30        EDGE_30_90  1.0
    x_30        EDGE_30_108  1.0
    x_30        EDGE_30_80  1.0
    x_30        EDGE_30_89  1.0
    x_30        EDGE_0_30  1.0
    x_30        EDGE_30_47  1.0
    x_30        EDGE_30_37  1.0
    x_31        OBJ       -49
    x_31        EDGE_31_61  1.0
    x_31        EDGE_24_31  1.0
    x_31        EDGE_16_31  1.0
    x_31        EDGE_31_37  1.0
    x_31        EDGE_31_98  1.0
    x_31        EDGE_31_92  1.0
    x_31        EDGE_31_60  1.0
    x_31        EDGE_31_87  1.0
    x_31        EDGE_31_55  1.0
    x_31        EDGE_31_82  1.0
    x_31        EDGE_17_31  1.0
    x_31        EDGE_31_50  1.0
    x_31        EDGE_31_59  1.0
    x_31        EDGE_31_77  1.0
    x_31        EDGE_9_31  1.0
    x_31        EDGE_31_36  1.0
    x_31        EDGE_31_58  1.0
    x_31        EDGE_4_31  1.0
    x_31        EDGE_15_31  1.0
    x_32        OBJ       -55
    x_32        EDGE_32_55  1.0
    x_32        EDGE_22_32  1.0
    x_32        EDGE_32_59  1.0
    x_32        EDGE_32_58  1.0
    x_32        EDGE_32_35  1.0
    x_32        EDGE_0_32  1.0
    x_32        EDGE_1_32  1.0
    x_32        EDGE_20_32  1.0
    x_32        EDGE_32_109  1.0
    x_32        EDGE_32_95  1.0
    x_32        EDGE_32_90  1.0
    x_32        EDGE_26_32  1.0
    x_32        EDGE_32_103  1.0
    x_32        EDGE_32_83  1.0
    x_32        EDGE_32_80  1.0
    x_32        EDGE_17_32  1.0
    x_32        EDGE_9_32  1.0
    x_32        EDGE_12_32  1.0
    x_32        EDGE_4_32  1.0
    x_32        EDGE_5_32  1.0
    x_32        EDGE_27_32  1.0
    x_32        EDGE_32_88  1.0
    x_33        OBJ       -68
    x_33        EDGE_28_33  1.0
    x_33        EDGE_33_106  1.0
    x_33        EDGE_33_74  1.0
    x_33        EDGE_33_78  1.0
    x_33        EDGE_33_64  1.0
    x_33        EDGE_33_41  1.0
    x_33        EDGE_33_59  1.0
    x_33        EDGE_7_33  1.0
    x_33        EDGE_33_45  1.0
    x_33        EDGE_5_33  1.0
    x_33        EDGE_33_91  1.0
    x_33        EDGE_24_33  1.0
    x_33        EDGE_33_77  1.0
    x_33        EDGE_33_90  1.0
    x_33        EDGE_33_76  1.0
    x_33        EDGE_22_33  1.0
    x_34        OBJ       -22
    x_34        EDGE_34_105  1.0
    x_34        EDGE_34_100  1.0
    x_34        EDGE_9_34  1.0
    x_34        EDGE_34_104  1.0
    x_34        EDGE_34_81  1.0
    x_34        EDGE_34_90  1.0
    x_34        EDGE_23_34  1.0
    x_34        EDGE_34_76  1.0
    x_34        EDGE_34_94  1.0
    x_34        EDGE_34_71  1.0
    x_34        EDGE_34_39  1.0
    x_34        EDGE_34_48  1.0
    x_34        EDGE_15_34  1.0
    x_34        EDGE_34_43  1.0
    x_34        EDGE_7_34  1.0
    x_34        EDGE_34_107  1.0
    x_34        EDGE_34_84  1.0
    x_34        EDGE_34_79  1.0
    x_34        EDGE_34_92  1.0
    x_34        EDGE_34_45  1.0
    x_34        EDGE_34_49  1.0
    x_34        EDGE_34_35  1.0
    x_35        OBJ       -72
    x_35        EDGE_35_88  1.0
    x_35        EDGE_35_65  1.0
    x_35        EDGE_35_92  1.0
    x_35        EDGE_35_60  1.0
    x_35        EDGE_35_78  1.0
    x_35        EDGE_35_96  1.0
    x_35        EDGE_35_64  1.0
    x_35        EDGE_32_35  1.0
    x_35        EDGE_35_49  1.0
    x_35        EDGE_35_105  1.0
    x_35        EDGE_11_35  1.0
    x_35        EDGE_35_95  1.0
    x_35        EDGE_35_104  1.0
    x_35        EDGE_35_72  1.0
    x_35        EDGE_35_81  1.0
    x_35        EDGE_3_35  1.0
    x_35        EDGE_35_67  1.0
    x_35        EDGE_35_85  1.0
    x_35        EDGE_35_53  1.0
    x_35        EDGE_35_66  1.0
    x_35        EDGE_6_35  1.0
    x_35        EDGE_35_47  1.0
    x_35        EDGE_35_56  1.0
    x_35        EDGE_28_35  1.0
    x_35        EDGE_35_42  1.0
    x_35        EDGE_34_35  1.0
    x_36        OBJ       -23
    x_36        EDGE_36_71  1.0
    x_36        EDGE_36_89  1.0
    x_36        EDGE_36_66  1.0
    x_36        EDGE_36_38  1.0
    x_36        EDGE_16_36  1.0
    x_36        EDGE_0_36  1.0
    x_36        EDGE_36_79  1.0
    x_36        EDGE_36_97  1.0
    x_36        EDGE_22_36  1.0
    x_36        EDGE_36_83  1.0
    x_36        EDGE_36_92  1.0
    x_36        EDGE_36_101  1.0
    x_36        EDGE_3_36  1.0
    x_36        EDGE_36_69  1.0
    x_36        EDGE_36_64  1.0
    x_36        EDGE_36_82  1.0
    x_36        EDGE_36_77  1.0
    x_36        EDGE_36_54  1.0
    x_36        EDGE_36_63  1.0
    x_36        EDGE_36_40  1.0
    x_36        EDGE_17_36  1.0
    x_36        EDGE_1_36  1.0
    x_36        EDGE_31_36  1.0
    x_36        EDGE_36_105  1.0
    x_36        EDGE_36_72  1.0
    x_36        EDGE_36_90  1.0
    x_36        EDGE_36_67  1.0
    x_37        OBJ       -31
    x_37        EDGE_14_37  1.0
    x_37        EDGE_37_105  1.0
    x_37        EDGE_6_37  1.0
    x_37        EDGE_37_63  1.0
    x_37        EDGE_37_72  1.0
    x_37        EDGE_37_81  1.0
    x_37        EDGE_37_90  1.0
    x_37        EDGE_37_67  1.0
    x_37        EDGE_37_94  1.0
    x_37        EDGE_31_37  1.0
    x_37        EDGE_37_44  1.0
    x_37        EDGE_37_71  1.0
    x_37        EDGE_37_38  1.0
    x_37        EDGE_26_37  1.0
    x_37        EDGE_37_93  1.0
    x_37        EDGE_37_88  1.0
    x_37        EDGE_37_106  1.0
    x_37        EDGE_37_65  1.0
    x_37        EDGE_37_73  1.0
    x_37        EDGE_19_37  1.0
    x_37        EDGE_30_37  1.0
    x_38        OBJ       -30
    x_38        EDGE_6_38  1.0
    x_38        EDGE_36_38  1.0
    x_38        EDGE_38_102  1.0
    x_38        EDGE_38_79  1.0
    x_38        EDGE_38_88  1.0
    x_38        EDGE_38_65  1.0
    x_38        EDGE_38_55  1.0
    x_38        EDGE_23_38  1.0
    x_38        EDGE_38_50  1.0
    x_38        EDGE_38_59  1.0
    x_38        EDGE_37_38  1.0
    x_38        EDGE_38_91  1.0
    x_38        EDGE_21_38  1.0
    x_38        EDGE_38_77  1.0
    x_38        EDGE_38_108  1.0
    x_38        EDGE_38_67  1.0
    x_38        EDGE_38_44  1.0
    x_38        EDGE_38_80  1.0
    x_38        EDGE_27_38  1.0
    x_38        EDGE_19_38  1.0
    x_38        EDGE_38_47  1.0
    x_38        EDGE_22_38  1.0
    x_38        EDGE_3_38  1.0
    x_39        OBJ       -4
    x_39        EDGE_9_39  1.0
    x_39        EDGE_39_47  1.0
    x_39        EDGE_34_39  1.0
    x_39        EDGE_18_39  1.0
    x_39        EDGE_27_39  1.0
    x_39        EDGE_39_93  1.0
    x_39        EDGE_39_74  1.0
    x_39        EDGE_39_87  1.0
    x_39        EDGE_39_96  1.0
    x_39        EDGE_39_55  1.0
    x_39        EDGE_39_82  1.0
    x_39        EDGE_39_91  1.0
    x_39        EDGE_39_63  1.0
    x_39        EDGE_19_39  1.0
    x_39        EDGE_11_39  1.0
    x_39        EDGE_25_39  1.0
    x_40        OBJ       -23
    x_40        EDGE_40_77  1.0
    x_40        EDGE_10_40  1.0
    x_40        EDGE_40_100  1.0
    x_40        EDGE_40_104  1.0
    x_40        EDGE_40_76  1.0
    x_40        EDGE_40_80  1.0
    x_40        EDGE_40_57  1.0
    x_40        EDGE_40_70  1.0
    x_40        EDGE_25_40  1.0
    x_40        EDGE_36_40  1.0
    x_40        EDGE_12_40  1.0
    x_40        EDGE_40_88  1.0
    x_40        EDGE_40_78  1.0
    x_40        EDGE_40_96  1.0
    x_40        EDGE_18_40  1.0
    x_40        EDGE_40_64  1.0
    x_40        EDGE_40_82  1.0
    x_41        OBJ       -42
    x_41        EDGE_41_107  1.0
    x_41        EDGE_41_88  1.0
    x_41        EDGE_41_101  1.0
    x_41        EDGE_11_41  1.0
    x_41        EDGE_41_78  1.0
    x_41        EDGE_41_96  1.0
    x_41        EDGE_41_55  1.0
    x_41        EDGE_41_73  1.0
    x_41        EDGE_41_50  1.0
    x_41        EDGE_33_41  1.0
    x_41        EDGE_41_58  1.0
    x_41        EDGE_6_41  1.0
    x_41        EDGE_1_41  1.0
    x_41        EDGE_41_72  1.0
    x_41        EDGE_41_81  1.0
    x_41        EDGE_41_76  1.0
    x_41        EDGE_41_53  1.0
    x_41        EDGE_41_62  1.0
    x_41        EDGE_7_41  1.0
    x_41        EDGE_41_65  1.0
    x_42        OBJ       -23
    x_42        EDGE_14_42  1.0
    x_42        EDGE_42_82  1.0
    x_42        EDGE_42_77  1.0
    x_42        EDGE_42_86  1.0
    x_42        EDGE_42_72  1.0
    x_42        EDGE_17_42  1.0
    x_42        EDGE_42_44  1.0
    x_42        EDGE_42_57  1.0
    x_42        EDGE_42_75  1.0
    x_42        EDGE_12_42  1.0
    x_42        EDGE_42_93  1.0
    x_42        EDGE_42_70  1.0
    x_42        EDGE_42_78  1.0
    x_42        EDGE_42_64  1.0
    x_42        EDGE_24_42  1.0
    x_42        EDGE_35_42  1.0
    x_42        EDGE_42_49  1.0
    x_42        EDGE_19_42  1.0
    x_43        OBJ       -18
    x_43        EDGE_43_101  1.0
    x_43        EDGE_43_69  1.0
    x_43        EDGE_43_96  1.0
    x_43        EDGE_43_55  1.0
    x_43        EDGE_43_68  1.0
    x_43        EDGE_43_54  1.0
    x_43        EDGE_43_72  1.0
    x_43        EDGE_9_43  1.0
    x_43        EDGE_1_43  1.0
    x_43        EDGE_43_58  1.0
    x_43        EDGE_43_105  1.0
    x_43        EDGE_34_43  1.0
    x_43        EDGE_18_43  1.0
    x_43        EDGE_43_86  1.0
    x_43        EDGE_43_95  1.0
    x_43        EDGE_43_85  1.0
    x_43        EDGE_43_62  1.0
    x_43        EDGE_43_89  1.0
    x_43        EDGE_21_43  1.0
    x_43        EDGE_43_48  1.0
    x_43        EDGE_43_84  1.0
    x_43        EDGE_43_52  1.0
    x_43        EDGE_43_70  1.0
    x_43        EDGE_43_79  1.0
    x_43        EDGE_43_56  1.0
    x_44        OBJ       -66
    x_44        EDGE_18_44  1.0
    x_44        EDGE_44_103  1.0
    x_44        EDGE_42_44  1.0
    x_44        EDGE_44_65  1.0
    x_44        EDGE_37_44  1.0
    x_44        EDGE_27_44  1.0
    x_44        EDGE_30_44  1.0
    x_44        EDGE_44_91  1.0
    x_44        EDGE_44_109  1.0
    x_44        EDGE_38_44  1.0
    x_44        EDGE_44_77  1.0
    x_44        EDGE_44_95  1.0
    x_44        EDGE_1_44  1.0
    x_44        EDGE_44_72  1.0
    x_44        EDGE_44_80  1.0
    x_44        EDGE_44_48  1.0
    x_44        EDGE_25_44  1.0
    x_44        EDGE_44_57  1.0
    x_44        EDGE_44_66  1.0
    x_45        OBJ       -66
    x_45        EDGE_2_45  1.0
    x_45        EDGE_24_45  1.0
    x_45        EDGE_45_94  1.0
    x_45        EDGE_45_89  1.0
    x_45        EDGE_30_45  1.0
    x_45        EDGE_45_70  1.0
    x_45        EDGE_45_51  1.0
    x_45        EDGE_3_45  1.0
    x_45        EDGE_33_45  1.0
    x_45        EDGE_25_45  1.0
    x_45        EDGE_45_107  1.0
    x_45        EDGE_28_45  1.0
    x_45        EDGE_45_84  1.0
    x_45        EDGE_1_45  1.0
    x_45        EDGE_45_97  1.0
    x_45        EDGE_4_45  1.0
    x_45        EDGE_45_55  1.0
    x_45        EDGE_45_82  1.0
    x_45        EDGE_34_45  1.0
    x_45        EDGE_45_54  1.0
    x_45        EDGE_45_49  1.0
    x_46        OBJ       -47
    x_46        EDGE_22_46  1.0
    x_46        EDGE_46_93  1.0
    x_46        EDGE_46_79  1.0
    x_46        EDGE_8_46  1.0
    x_46        EDGE_0_46  1.0
    x_46        EDGE_1_46  1.0
    x_46        EDGE_46_63  1.0
    x_46        EDGE_46_49  1.0
    x_46        EDGE_3_46  1.0
    x_46        EDGE_14_46  1.0
    x_46        EDGE_25_46  1.0
    x_46        EDGE_9_46  1.0
    x_46        EDGE_46_95  1.0
    x_46        EDGE_46_81  1.0
    x_46        EDGE_46_99  1.0
    x_46        EDGE_46_108  1.0
    x_46        EDGE_46_85  1.0
    x_46        EDGE_46_103  1.0
    x_46        EDGE_46_89  1.0
    x_46        EDGE_46_84  1.0
    x_46        EDGE_46_70  1.0
    x_46        EDGE_46_56  1.0
    x_46        EDGE_46_51  1.0
    x_47        OBJ       -66
    x_47        EDGE_47_53  1.0
    x_47        EDGE_47_80  1.0
    x_47        EDGE_47_89  1.0
    x_47        EDGE_47_70  1.0
    x_47        EDGE_47_65  1.0
    x_47        EDGE_28_47  1.0
    x_47        EDGE_9_47  1.0
    x_47        EDGE_39_47  1.0
    x_47        EDGE_1_47  1.0
    x_47        EDGE_47_93  1.0
    x_47        EDGE_7_47  1.0
    x_47        EDGE_47_82  1.0
    x_47        EDGE_47_91  1.0
    x_47        EDGE_29_47  1.0
    x_47        EDGE_47_54  1.0
    x_47        EDGE_47_72  1.0
    x_47        EDGE_47_49  1.0
    x_47        EDGE_35_47  1.0
    x_47        EDGE_47_100  1.0
    x_47        EDGE_30_47  1.0
    x_47        EDGE_38_47  1.0
    x_47        EDGE_11_47  1.0
    x_47        EDGE_14_47  1.0
    x_48        OBJ       -87
    x_48        EDGE_48_54  1.0
    x_48        EDGE_6_48  1.0
    x_48        EDGE_48_63  1.0
    x_48        EDGE_48_72  1.0
    x_48        EDGE_48_49  1.0
    x_48        EDGE_4_48  1.0
    x_48        EDGE_15_48  1.0
    x_48        EDGE_26_48  1.0
    x_48        EDGE_48_108  1.0
    x_48        EDGE_34_48  1.0
    x_48        EDGE_48_103  1.0
    x_48        EDGE_48_98  1.0
    x_48        EDGE_29_48  1.0
    x_48        EDGE_2_48  1.0
    x_48        EDGE_43_48  1.0
    x_48        EDGE_8_48  1.0
    x_48        EDGE_48_88  1.0
    x_48        EDGE_11_48  1.0
    x_48        EDGE_48_83  1.0
    x_48        EDGE_48_69  1.0
    x_48        EDGE_48_96  1.0
    x_48        EDGE_48_64  1.0
    x_48        EDGE_44_48  1.0
    x_48        EDGE_25_48  1.0
    x_49        OBJ       -72
    x_49        EDGE_48_49  1.0
    x_49        EDGE_4_49  1.0
    x_49        EDGE_35_49  1.0
    x_49        EDGE_49_60  1.0
    x_49        EDGE_49_78  1.0
    x_49        EDGE_27_49  1.0
    x_49        EDGE_46_49  1.0
    x_49        EDGE_47_49  1.0
    x_49        EDGE_49_95  1.0
    x_49        EDGE_49_90  1.0
    x_49        EDGE_49_108  1.0
    x_49        EDGE_49_94  1.0
    x_49        EDGE_49_80  1.0
    x_49        EDGE_49_52  1.0
    x_49        EDGE_42_49  1.0
    x_49        EDGE_15_49  1.0
    x_49        EDGE_34_49  1.0
    x_49        EDGE_45_49  1.0
    x_49        EDGE_7_49  1.0
    x_50        OBJ       -24
    x_50        EDGE_50_91  1.0
    x_50        EDGE_2_50  1.0
    x_50        EDGE_50_86  1.0
    x_50        EDGE_50_104  1.0
    x_50        EDGE_50_108  1.0
    x_50        EDGE_50_67  1.0
    x_50        EDGE_50_76  1.0
    x_50        EDGE_50_53  1.0
    x_50        EDGE_50_80  1.0
    x_50        EDGE_50_57  1.0
    x_50        EDGE_50_75  1.0
    x_50        EDGE_38_50  1.0
    x_50        EDGE_41_50  1.0
    x_50        EDGE_3_50  1.0
    x_50        EDGE_50_103  1.0
    x_50        EDGE_25_50  1.0
    x_50        EDGE_28_50  1.0
    x_50        EDGE_50_65  1.0
    x_50        EDGE_9_50  1.0
    x_50        EDGE_50_55  1.0
    x_50        EDGE_50_64  1.0
    x_50        EDGE_50_73  1.0
    x_50        EDGE_31_50  1.0
    x_50        EDGE_15_50  1.0
    x_50        EDGE_10_50  1.0
    x_51        OBJ       -58
    x_51        EDGE_51_64  1.0
    x_51        EDGE_51_91  1.0
    x_51        EDGE_51_81  1.0
    x_51        EDGE_51_99  1.0
    x_51        EDGE_51_108  1.0
    x_51        EDGE_45_51  1.0
    x_51        EDGE_51_62  1.0
    x_51        EDGE_51_71  1.0
    x_51        EDGE_51_98  1.0
    x_51        EDGE_28_51  1.0
    x_51        EDGE_51_75  1.0
    x_51        EDGE_51_93  1.0
    x_51        EDGE_51_79  1.0
    x_51        EDGE_29_51  1.0
    x_51        EDGE_51_56  1.0
    x_51        EDGE_51_65  1.0
    x_51        EDGE_51_55  1.0
    x_51        EDGE_7_51  1.0
    x_51        EDGE_27_51  1.0
    x_51        EDGE_46_51  1.0
    x_51        EDGE_2_51  1.0
    x_51        EDGE_51_83  1.0
    x_51        EDGE_51_78  1.0
    x_52        OBJ       -54
    x_52        EDGE_28_52  1.0
    x_52        EDGE_12_52  1.0
    x_52        EDGE_52_83  1.0
    x_52        EDGE_52_69  1.0
    x_52        EDGE_52_87  1.0
    x_52        EDGE_26_52  1.0
    x_52        EDGE_52_73  1.0
    x_52        EDGE_7_52  1.0
    x_52        EDGE_18_52  1.0
    x_52        EDGE_52_63  1.0
    x_52        EDGE_43_52  1.0
    x_52        EDGE_52_109  1.0
    x_52        EDGE_52_81  1.0
    x_52        EDGE_52_67  1.0
    x_52        EDGE_49_52  1.0
    x_52        EDGE_52_80  1.0
    x_52        EDGE_22_52  1.0
    x_52        EDGE_52_61  1.0
    x_53        OBJ       -95
    x_53        EDGE_47_53  1.0
    x_53        EDGE_20_53  1.0
    x_53        EDGE_50_53  1.0
    x_53        EDGE_53_99  1.0
    x_53        EDGE_53_89  1.0
    x_53        EDGE_26_53  1.0
    x_53        EDGE_53_57  1.0
    x_53        EDGE_29_53  1.0
    x_53        EDGE_5_53  1.0
    x_53        EDGE_35_53  1.0
    x_53        EDGE_16_53  1.0
    x_53        EDGE_53_97  1.0
    x_53        EDGE_53_74  1.0
    x_53        EDGE_53_83  1.0
    x_53        EDGE_8_53  1.0
    x_53        EDGE_53_69  1.0
    x_53        EDGE_53_96  1.0
    x_53        EDGE_53_64  1.0
    x_53        EDGE_53_91  1.0
    x_53        EDGE_41_53  1.0
    x_53        EDGE_53_54  1.0
    x_53        EDGE_53_58  1.0
    x_54        OBJ       -68
    x_54        EDGE_48_54  1.0
    x_54        EDGE_10_54  1.0
    x_54        EDGE_29_54  1.0
    x_54        EDGE_54_65  1.0
    x_54        EDGE_54_74  1.0
    x_54        EDGE_54_83  1.0
    x_54        EDGE_54_64  1.0
    x_54        EDGE_43_54  1.0
    x_54        EDGE_11_54  1.0
    x_54        EDGE_54_105  1.0
    x_54        EDGE_54_86  1.0
    x_54        EDGE_54_72  1.0
    x_54        EDGE_54_90  1.0
    x_54        EDGE_54_108  1.0
    x_54        EDGE_54_58  1.0
    x_54        EDGE_54_85  1.0
    x_54        EDGE_36_54  1.0
    x_54        EDGE_47_54  1.0
    x_54        EDGE_54_57  1.0
    x_54        EDGE_54_56  1.0
    x_54        EDGE_53_54  1.0
    x_54        EDGE_45_54  1.0
    x_54        EDGE_18_54  1.0
    x_54        EDGE_54_98  1.0
    x_54        EDGE_54_93  1.0
    x_54        EDGE_54_102  1.0
    x_55        OBJ       -98
    x_55        EDGE_55_79  1.0
    x_55        EDGE_32_55  1.0
    x_55        EDGE_43_55  1.0
    x_55        EDGE_19_55  1.0
    x_55        EDGE_38_55  1.0
    x_55        EDGE_41_55  1.0
    x_55        EDGE_55_74  1.0
    x_55        EDGE_55_105  1.0
    x_55        EDGE_55_64  1.0
    x_55        EDGE_55_82  1.0
    x_55        EDGE_55_68  1.0
    x_55        EDGE_39_55  1.0
    x_55        EDGE_31_55  1.0
    x_55        EDGE_50_55  1.0
    x_55        EDGE_51_55  1.0
    x_55        EDGE_45_55  1.0
    x_55        EDGE_18_55  1.0
    x_55        EDGE_55_90  1.0
    x_55        EDGE_55_85  1.0
    x_55        EDGE_55_103  1.0
    x_55        EDGE_10_55  1.0
    x_55        EDGE_2_55  1.0
    x_56        OBJ       -47
    x_56        EDGE_56_95  1.0
    x_56        EDGE_56_81  1.0
    x_56        EDGE_56_90  1.0
    x_56        EDGE_56_85  1.0
    x_56        EDGE_56_71  1.0
    x_56        EDGE_56_89  1.0
    x_56        EDGE_56_75  1.0
    x_56        EDGE_56_84  1.0
    x_56        EDGE_10_56  1.0
    x_56        EDGE_29_56  1.0
    x_56        EDGE_51_56  1.0
    x_56        EDGE_43_56  1.0
    x_56        EDGE_56_93  1.0
    x_56        EDGE_56_102  1.0
    x_56        EDGE_5_56  1.0
    x_56        EDGE_35_56  1.0
    x_56        EDGE_56_88  1.0
    x_56        EDGE_56_97  1.0
    x_56        EDGE_54_56  1.0
    x_56        EDGE_56_69  1.0
    x_56        EDGE_46_56  1.0
    x_56        EDGE_8_56  1.0
    x_56        EDGE_56_59  1.0
    x_56        EDGE_56_68  1.0
    x_56        EDGE_56_77  1.0
    x_57        OBJ       -76
    x_57        EDGE_28_57  1.0
    x_57        EDGE_57_97  1.0
    x_57        EDGE_9_57  1.0
    x_57        EDGE_57_106  1.0
    x_57        EDGE_50_57  1.0
    x_57        EDGE_12_57  1.0
    x_57        EDGE_42_57  1.0
    x_57        EDGE_57_77  1.0
    x_57        EDGE_53_57  1.0
    x_57        EDGE_15_57  1.0
    x_57        EDGE_57_58  1.0
    x_57        EDGE_7_57  1.0
    x_57        EDGE_40_57  1.0
    x_57        EDGE_21_57  1.0
    x_57        EDGE_57_86  1.0
    x_57        EDGE_57_104  1.0
    x_57        EDGE_13_57  1.0
    x_57        EDGE_57_90  1.0
    x_57        EDGE_57_108  1.0
    x_57        EDGE_54_57  1.0
    x_57        EDGE_57_94  1.0
    x_57        EDGE_57_62  1.0
    x_57        EDGE_57_71  1.0
    x_57        EDGE_27_57  1.0
    x_57        EDGE_57_66  1.0
    x_57        EDGE_22_57  1.0
    x_57        EDGE_44_57  1.0
    x_58        OBJ       -46
    x_58        EDGE_58_95  1.0
    x_58        EDGE_58_108  1.0
    x_58        EDGE_58_103  1.0
    x_58        EDGE_32_58  1.0
    x_58        EDGE_43_58  1.0
    x_58        EDGE_18_58  1.0
    x_58        EDGE_57_58  1.0
    x_58        EDGE_58_102  1.0
    x_58        EDGE_41_58  1.0
    x_58        EDGE_58_88  1.0
    x_58        EDGE_58_97  1.0
    x_58        EDGE_54_58  1.0
    x_58        EDGE_58_69  1.0
    x_58        EDGE_20_58  1.0
    x_58        EDGE_31_58  1.0
    x_58        EDGE_53_58  1.0
    x_58        EDGE_15_58  1.0
    x_59        OBJ       -47
    x_59        EDGE_59_82  1.0
    x_59        EDGE_32_59  1.0
    x_59        EDGE_30_59  1.0
    x_59        EDGE_38_59  1.0
    x_59        EDGE_59_90  1.0
    x_59        EDGE_33_59  1.0
    x_59        EDGE_59_89  1.0
    x_59        EDGE_9_59  1.0
    x_59        EDGE_31_59  1.0
    x_59        EDGE_26_59  1.0
    x_59        EDGE_56_59  1.0
    x_59        EDGE_10_59  1.0
    x_60        OBJ       -58
    x_60        EDGE_60_85  1.0
    x_60        EDGE_35_60  1.0
    x_60        EDGE_16_60  1.0
    x_60        EDGE_60_88  1.0
    x_60        EDGE_49_60  1.0
    x_60        EDGE_11_60  1.0
    x_60        EDGE_60_87  1.0
    x_60        EDGE_60_73  1.0
    x_60        EDGE_6_60  1.0
    x_60        EDGE_9_60  1.0
    x_60        EDGE_31_60  1.0
    x_60        EDGE_60_109  1.0
    x_60        EDGE_15_60  1.0
    x_60        EDGE_60_80  1.0
    x_60        EDGE_60_61  1.0
    x_60        EDGE_60_70  1.0
    x_60        EDGE_60_65  1.0
    x_61        OBJ       -21
    x_61        EDGE_61_91  1.0
    x_61        EDGE_61_72  1.0
    x_61        EDGE_61_85  1.0
    x_61        EDGE_9_61  1.0
    x_61        EDGE_31_61  1.0
    x_61        EDGE_12_61  1.0
    x_61        EDGE_23_61  1.0
    x_61        EDGE_4_61  1.0
    x_61        EDGE_26_61  1.0
    x_61        EDGE_18_61  1.0
    x_61        EDGE_61_107  1.0
    x_61        EDGE_61_88  1.0
    x_61        EDGE_61_97  1.0
    x_61        EDGE_61_65  1.0
    x_61        EDGE_61_74  1.0
    x_61        EDGE_61_69  1.0
    x_61        EDGE_61_87  1.0
    x_61        EDGE_13_61  1.0
    x_61        EDGE_61_64  1.0
    x_61        EDGE_61_68  1.0
    x_61        EDGE_8_61  1.0
    x_61        EDGE_60_61  1.0
    x_61        EDGE_52_61  1.0
    x_61        EDGE_61_105  1.0
    x_62        OBJ       -97
    x_62        EDGE_17_62  1.0
    x_62        EDGE_62_69  1.0
    x_62        EDGE_62_87  1.0
    x_62        EDGE_62_77  1.0
    x_62        EDGE_12_62  1.0
    x_62        EDGE_4_62  1.0
    x_62        EDGE_7_62  1.0
    x_62        EDGE_18_62  1.0
    x_62        EDGE_2_62  1.0
    x_62        EDGE_51_62  1.0
    x_62        EDGE_62_108  1.0
    x_62        EDGE_43_62  1.0
    x_62        EDGE_62_70  1.0
    x_62        EDGE_27_62  1.0
    x_62        EDGE_57_62  1.0
    x_62        EDGE_8_62  1.0
    x_62        EDGE_19_62  1.0
    x_62        EDGE_22_62  1.0
    x_62        EDGE_41_62  1.0
    x_62        EDGE_6_62  1.0
    x_62        EDGE_62_88  1.0
    x_62        EDGE_62_106  1.0
    x_63        OBJ       -52
    x_63        EDGE_48_63  1.0
    x_63        EDGE_10_63  1.0
    x_63        EDGE_5_63  1.0
    x_63        EDGE_63_107  1.0
    x_63        EDGE_37_63  1.0
    x_63        EDGE_27_63  1.0
    x_63        EDGE_46_63  1.0
    x_63        EDGE_8_63  1.0
    x_63        EDGE_19_63  1.0
    x_63        EDGE_63_83  1.0
    x_63        EDGE_52_63  1.0
    x_63        EDGE_3_63  1.0
    x_63        EDGE_36_63  1.0
    x_63        EDGE_39_63  1.0
    x_63        EDGE_1_63  1.0
    x_63        EDGE_63_91  1.0
    x_63        EDGE_63_104  1.0
    x_63        EDGE_63_67  1.0
    x_63        EDGE_63_75  1.0
    x_64        OBJ       -92
    x_64        EDGE_51_64  1.0
    x_64        EDGE_35_64  1.0
    x_64        EDGE_64_109  1.0
    x_64        EDGE_54_64  1.0
    x_64        EDGE_64_108  1.0
    x_64        EDGE_27_64  1.0
    x_64        EDGE_64_67  1.0
    x_64        EDGE_64_76  1.0
    x_64        EDGE_64_85  1.0
    x_64        EDGE_64_94  1.0
    x_64        EDGE_11_64  1.0
    x_64        EDGE_22_64  1.0
    x_64        EDGE_33_64  1.0
    x_64        EDGE_55_64  1.0
    x_64        EDGE_36_64  1.0
    x_64        EDGE_1_64  1.0
    x_64        EDGE_64_106  1.0
    x_64        EDGE_50_64  1.0
    x_64        EDGE_61_64  1.0
    x_64        EDGE_64_83  1.0
    x_64        EDGE_64_92  1.0
    x_64        EDGE_42_64  1.0
    x_64        EDGE_64_78  1.0
    x_64        EDGE_64_87  1.0
    x_64        EDGE_64_96  1.0
    x_64        EDGE_64_105  1.0
    x_64        EDGE_53_64  1.0
    x_64        EDGE_18_64  1.0
    x_64        EDGE_48_64  1.0
    x_64        EDGE_10_64  1.0
    x_64        EDGE_40_64  1.0
    x_65        OBJ       -95
    x_65        EDGE_35_65  1.0
    x_65        EDGE_65_102  1.0
    x_65        EDGE_54_65  1.0
    x_65        EDGE_65_106  1.0
    x_65        EDGE_47_65  1.0
    x_65        EDGE_65_96  1.0
    x_65        EDGE_38_65  1.0
    x_65        EDGE_65_68  1.0
    x_65        EDGE_14_65  1.0
    x_65        EDGE_44_65  1.0
    x_65        EDGE_65_95  1.0
    x_65        EDGE_65_90  1.0
    x_65        EDGE_50_65  1.0
    x_65        EDGE_61_65  1.0
    x_65        EDGE_23_65  1.0
    x_65        EDGE_51_65  1.0
    x_65        EDGE_65_71  1.0
    x_65        EDGE_65_66  1.0
    x_65        EDGE_65_70  1.0
    x_65        EDGE_37_65  1.0
    x_65        EDGE_60_65  1.0
    x_65        EDGE_22_65  1.0
    x_65        EDGE_41_65  1.0
    x_66        OBJ       -60
    x_66        EDGE_66_71  1.0
    x_66        EDGE_36_66  1.0
    x_66        EDGE_17_66  1.0
    x_66        EDGE_1_66  1.0
    x_66        EDGE_4_66  1.0
    x_66        EDGE_66_98  1.0
    x_66        EDGE_66_107  1.0
    x_66        EDGE_66_93  1.0
    x_66        EDGE_66_102  1.0
    x_66        EDGE_66_97  1.0
    x_66        EDGE_66_83  1.0
    x_66        EDGE_2_66  1.0
    x_66        EDGE_35_66  1.0
    x_66        EDGE_65_66  1.0
    x_66        EDGE_57_66  1.0
    x_66        EDGE_8_66  1.0
    x_66        EDGE_0_66  1.0
    x_66        EDGE_66_100  1.0
    x_66        EDGE_44_66  1.0
    x_67        OBJ       -84
    x_67        EDGE_20_67  1.0
    x_67        EDGE_50_67  1.0
    x_67        EDGE_64_67  1.0
    x_67        EDGE_18_67  1.0
    x_67        EDGE_37_67  1.0
    x_67        EDGE_67_72  1.0
    x_67        EDGE_67_99  1.0
    x_67        EDGE_29_67  1.0
    x_67        EDGE_21_67  1.0
    x_67        EDGE_35_67  1.0
    x_67        EDGE_38_67  1.0
    x_67        EDGE_67_98  1.0
    x_67        EDGE_67_102  1.0
    x_67        EDGE_52_67  1.0
    x_67        EDGE_67_79  1.0
    x_67        EDGE_67_74  1.0
    x_67        EDGE_63_67  1.0
    x_67        EDGE_67_73  1.0
    x_67        EDGE_36_67  1.0
    x_67        EDGE_67_91  1.0
    x_68        OBJ       -68
    x_68        EDGE_68_93  1.0
    x_68        EDGE_43_68  1.0
    x_68        EDGE_68_97  1.0
    x_68        EDGE_5_68  1.0
    x_68        EDGE_68_87  1.0
    x_68        EDGE_65_68  1.0
    x_68        EDGE_68_77  1.0
    x_68        EDGE_55_68  1.0
    x_68        EDGE_68_105  1.0
    x_68        EDGE_68_104  1.0
    x_68        EDGE_68_94  1.0
    x_68        EDGE_68_71  1.0
    x_68        EDGE_68_80  1.0
    x_68        EDGE_61_68  1.0
    x_68        EDGE_68_75  1.0
    x_68        EDGE_68_84  1.0
    x_68        EDGE_68_70  1.0
    x_68        EDGE_68_79  1.0
    x_68        EDGE_15_68  1.0
    x_68        EDGE_26_68  1.0
    x_68        EDGE_56_68  1.0
    x_68        EDGE_10_68  1.0
    x_69        OBJ       -32
    x_69        EDGE_43_69  1.0
    x_69        EDGE_5_69  1.0
    x_69        EDGE_69_90  1.0
    x_69        EDGE_62_69  1.0
    x_69        EDGE_13_69  1.0
    x_69        EDGE_69_80  1.0
    x_69        EDGE_69_89  1.0
    x_69        EDGE_30_69  1.0
    x_69        EDGE_22_69  1.0
    x_69        EDGE_52_69  1.0
    x_69        EDGE_25_69  1.0
    x_69        EDGE_36_69  1.0
    x_69        EDGE_69_102  1.0
    x_69        EDGE_69_92  1.0
    x_69        EDGE_1_69  1.0
    x_69        EDGE_58_69  1.0
    x_69        EDGE_20_69  1.0
    x_69        EDGE_61_69  1.0
    x_69        EDGE_69_73  1.0
    x_69        EDGE_69_91  1.0
    x_69        EDGE_12_69  1.0
    x_69        EDGE_69_77  1.0
    x_69        EDGE_53_69  1.0
    x_69        EDGE_56_69  1.0
    x_69        EDGE_48_69  1.0
    x_69        EDGE_69_100  1.0
    x_69        EDGE_21_69  1.0
    x_70        OBJ       -63
    x_70        EDGE_70_82  1.0
    x_70        EDGE_70_77  1.0
    x_70        EDGE_47_70  1.0
    x_70        EDGE_11_70  1.0
    x_70        EDGE_1_70  1.0
    x_70        EDGE_70_91  1.0
    x_70        EDGE_70_100  1.0
    x_70        EDGE_15_70  1.0
    x_70        EDGE_45_70  1.0
    x_70        EDGE_70_81  1.0
    x_70        EDGE_70_90  1.0
    x_70        EDGE_70_76  1.0
    x_70        EDGE_17_70  1.0
    x_70        EDGE_28_70  1.0
    x_70        EDGE_70_85  1.0
    x_70        EDGE_40_70  1.0
    x_70        EDGE_42_70  1.0
    x_70        EDGE_43_70  1.0
    x_70        EDGE_5_70  1.0
    x_70        EDGE_62_70  1.0
    x_70        EDGE_65_70  1.0
    x_70        EDGE_70_103  1.0
    x_70        EDGE_46_70  1.0
    x_70        EDGE_68_70  1.0
    x_70        EDGE_70_93  1.0
    x_70        EDGE_70_97  1.0
    x_70        EDGE_60_70  1.0
    x_70        EDGE_70_96  1.0
    x_71        OBJ       -36
    x_71        EDGE_36_71  1.0
    x_71        EDGE_66_71  1.0
    x_71        EDGE_9_71  1.0
    x_71        EDGE_71_106  1.0
    x_71        EDGE_34_71  1.0
    x_71        EDGE_56_71  1.0
    x_71        EDGE_37_71  1.0
    x_71        EDGE_71_87  1.0
    x_71        EDGE_71_73  1.0
    x_71        EDGE_71_82  1.0
    x_71        EDGE_51_71  1.0
    x_71        EDGE_24_71  1.0
    x_71        EDGE_65_71  1.0
    x_71        EDGE_57_71  1.0
    x_71        EDGE_68_71  1.0
    x_71        EDGE_71_91  1.0
    x_71        EDGE_71_86  1.0
    x_71        EDGE_71_108  1.0
    x_71        EDGE_22_71  1.0
    x_71        EDGE_3_71  1.0
    x_71        EDGE_25_71  1.0
    x_72        OBJ       -64
    x_72        EDGE_48_72  1.0
    x_72        EDGE_61_72  1.0
    x_72        EDGE_42_72  1.0
    x_72        EDGE_72_99  1.0
    x_72        EDGE_43_72  1.0
    x_72        EDGE_72_94  1.0
    x_72        EDGE_72_103  1.0
    x_72        EDGE_26_72  1.0
    x_72        EDGE_72_75  1.0
    x_72        EDGE_37_72  1.0
    x_72        EDGE_67_72  1.0
    x_72        EDGE_35_72  1.0
    x_72        EDGE_54_72  1.0
    x_72        EDGE_72_105  1.0
    x_72        EDGE_47_72  1.0
    x_72        EDGE_41_72  1.0
    x_72        EDGE_44_72  1.0
    x_72        EDGE_72_81  1.0
    x_72        EDGE_36_72  1.0
    x_73        OBJ       -65
    x_73        EDGE_5_73  1.0
    x_73        EDGE_24_73  1.0
    x_73        EDGE_60_73  1.0
    x_73        EDGE_22_73  1.0
    x_73        EDGE_41_73  1.0
    x_73        EDGE_52_73  1.0
    x_73        EDGE_71_73  1.0
    x_73        EDGE_73_86  1.0
    x_73        EDGE_73_95  1.0
    x_73        EDGE_25_73  1.0
    x_73        EDGE_17_73  1.0
    x_73        EDGE_73_89  1.0
    x_73        EDGE_73_98  1.0
    x_73        EDGE_9_73  1.0
    x_73        EDGE_69_73  1.0
    x_73        EDGE_50_73  1.0
    x_73        EDGE_12_73  1.0
    x_73        EDGE_37_73  1.0
    x_73        EDGE_67_73  1.0
    x_73        EDGE_73_79  1.0
    x_74        OBJ       -66
    x_74        EDGE_54_74  1.0
    x_74        EDGE_16_74  1.0
    x_74        EDGE_33_74  1.0
    x_74        EDGE_74_93  1.0
    x_74        EDGE_55_74  1.0
    x_74        EDGE_6_74  1.0
    x_74        EDGE_74_83  1.0
    x_74        EDGE_74_92  1.0
    x_74        EDGE_74_91  1.0
    x_74        EDGE_9_74  1.0
    x_74        EDGE_39_74  1.0
    x_74        EDGE_61_74  1.0
    x_74        EDGE_53_74  1.0
    x_74        EDGE_26_74  1.0
    x_74        EDGE_7_74  1.0
    x_74        EDGE_67_74  1.0
    x_74        EDGE_29_74  1.0
    x_75        OBJ       -46
    x_75        EDGE_17_75  1.0
    x_75        EDGE_75_91  1.0
    x_75        EDGE_75_109  1.0
    x_75        EDGE_50_75  1.0
    x_75        EDGE_75_104  1.0
    x_75        EDGE_12_75  1.0
    x_75        EDGE_42_75  1.0
    x_75        EDGE_72_75  1.0
    x_75        EDGE_75_108  1.0
    x_75        EDGE_25_75  1.0
    x_75        EDGE_75_89  1.0
    x_75        EDGE_56_75  1.0
    x_75        EDGE_18_75  1.0
    x_75        EDGE_51_75  1.0
    x_75        EDGE_68_75  1.0
    x_75        EDGE_75_78  1.0
    x_75        EDGE_63_75  1.0
    x_76        OBJ       -85
    x_76        EDGE_76_107  1.0
    x_76        EDGE_20_76  1.0
    x_76        EDGE_76_101  1.0
    x_76        EDGE_50_76  1.0
    x_76        EDGE_12_76  1.0
    x_76        EDGE_64_76  1.0
    x_76        EDGE_34_76  1.0
    x_76        EDGE_7_76  1.0
    x_76        EDGE_29_76  1.0
    x_76        EDGE_40_76  1.0
    x_76        EDGE_70_76  1.0
    x_76        EDGE_16_76  1.0
    x_76        EDGE_8_76  1.0
    x_76        EDGE_76_84  1.0
    x_76        EDGE_76_79  1.0
    x_76        EDGE_22_76  1.0
    x_76        EDGE_41_76  1.0
    x_76        EDGE_33_76  1.0
    x_77        OBJ       -59
    x_77        EDGE_77_99  1.0
    x_77        EDGE_40_77  1.0
    x_77        EDGE_70_77  1.0
    x_77        EDGE_77_80  1.0
    x_77        EDGE_42_77  1.0
    x_77        EDGE_62_77  1.0
    x_77        EDGE_27_77  1.0
    x_77        EDGE_57_77  1.0
    x_77        EDGE_68_77  1.0
    x_77        EDGE_2_77  1.0
    x_77        EDGE_16_77  1.0
    x_77        EDGE_6_77  1.0
    x_77        EDGE_36_77  1.0
    x_77        EDGE_77_100  1.0
    x_77        EDGE_19_77  1.0
    x_77        EDGE_38_77  1.0
    x_77        EDGE_69_77  1.0
    x_77        EDGE_20_77  1.0
    x_77        EDGE_31_77  1.0
    x_77        EDGE_33_77  1.0
    x_77        EDGE_44_77  1.0
    x_77        EDGE_56_77  1.0
    x_77        EDGE_28_77  1.0
    x_78        OBJ       -60
    x_78        EDGE_24_78  1.0
    x_78        EDGE_35_78  1.0
    x_78        EDGE_49_78  1.0
    x_78        EDGE_78_100  1.0
    x_78        EDGE_22_78  1.0
    x_78        EDGE_78_95  1.0
    x_78        EDGE_78_104  1.0
    x_78        EDGE_41_78  1.0
    x_78        EDGE_14_78  1.0
    x_78        EDGE_78_81  1.0
    x_78        EDGE_33_78  1.0
    x_78        EDGE_78_103  1.0
    x_78        EDGE_17_78  1.0
    x_78        EDGE_42_78  1.0
    x_78        EDGE_64_78  1.0
    x_78        EDGE_78_107  1.0
    x_78        EDGE_7_78  1.0
    x_78        EDGE_18_78  1.0
    x_78        EDGE_75_78  1.0
    x_78        EDGE_78_87  1.0
    x_78        EDGE_78_96  1.0
    x_78        EDGE_40_78  1.0
    x_78        EDGE_78_91  1.0
    x_78        EDGE_51_78  1.0
    x_79        OBJ       -45
    x_79        EDGE_55_79  1.0
    x_79        EDGE_46_79  1.0
    x_79        EDGE_38_79  1.0
    x_79        EDGE_22_79  1.0
    x_79        EDGE_79_97  1.0
    x_79        EDGE_14_79  1.0
    x_79        EDGE_79_101  1.0
    x_79        EDGE_36_79  1.0
    x_79        EDGE_17_79  1.0
    x_79        EDGE_28_79  1.0
    x_79        EDGE_9_79  1.0
    x_79        EDGE_51_79  1.0
    x_79        EDGE_43_79  1.0
    x_79        EDGE_34_79  1.0
    x_79        EDGE_79_95  1.0
    x_79        EDGE_76_79  1.0
    x_79        EDGE_68_79  1.0
    x_79        EDGE_67_79  1.0
    x_79        EDGE_79_80  1.0
    x_79        EDGE_79_89  1.0
    x_79        EDGE_29_79  1.0
    x_79        EDGE_2_79  1.0
    x_79        EDGE_79_84  1.0
    x_79        EDGE_73_79  1.0
    x_79        EDGE_13_79  1.0
    x_80        OBJ       -73
    x_80        EDGE_47_80  1.0
    x_80        EDGE_80_104  1.0
    x_80        EDGE_77_80  1.0
    x_80        EDGE_69_80  1.0
    x_80        EDGE_50_80  1.0
    x_80        EDGE_40_80  1.0
    x_80        EDGE_80_106  1.0
    x_80        EDGE_32_80  1.0
    x_80        EDGE_80_101  1.0
    x_80        EDGE_24_80  1.0
    x_80        EDGE_27_80  1.0
    x_80        EDGE_68_80  1.0
    x_80        EDGE_30_80  1.0
    x_80        EDGE_38_80  1.0
    x_80        EDGE_49_80  1.0
    x_80        EDGE_11_80  1.0
    x_80        EDGE_60_80  1.0
    x_80        EDGE_79_80  1.0
    x_80        EDGE_52_80  1.0
    x_80        EDGE_44_80  1.0
    x_80        EDGE_25_80  1.0
    x_81        OBJ       -93
    x_81        EDGE_81_105  1.0
    x_81        EDGE_81_100  1.0
    x_81        EDGE_20_81  1.0
    x_81        EDGE_51_81  1.0
    x_81        EDGE_34_81  1.0
    x_81        EDGE_56_81  1.0
    x_81        EDGE_37_81  1.0
    x_81        EDGE_10_81  1.0
    x_81        EDGE_78_81  1.0
    x_81        EDGE_81_109  1.0
    x_81        EDGE_70_81  1.0
    x_81        EDGE_21_81  1.0
    x_81        EDGE_81_104  1.0
    x_81        EDGE_81_94  1.0
    x_81        EDGE_13_81  1.0
    x_81        EDGE_35_81  1.0
    x_81        EDGE_81_98  1.0
    x_81        EDGE_16_81  1.0
    x_81        EDGE_46_81  1.0
    x_81        EDGE_11_81  1.0
    x_81        EDGE_41_81  1.0
    x_81        EDGE_52_81  1.0
    x_81        EDGE_72_81  1.0
    x_81        EDGE_81_107  1.0
    x_81        EDGE_6_81  1.0
    x_81        EDGE_28_81  1.0
    x_82        OBJ       -72
    x_82        EDGE_59_82  1.0
    x_82        EDGE_70_82  1.0
    x_82        EDGE_42_82  1.0
    x_82        EDGE_82_107  1.0
    x_82        EDGE_82_97  1.0
    x_82        EDGE_82_92  1.0
    x_82        EDGE_82_101  1.0
    x_82        EDGE_82_96  1.0
    x_82        EDGE_71_82  1.0
    x_82        EDGE_16_82  1.0
    x_82        EDGE_55_82  1.0
    x_82        EDGE_36_82  1.0
    x_82        EDGE_47_82  1.0
    x_82        EDGE_17_82  1.0
    x_82        EDGE_0_82  1.0
    x_82        EDGE_39_82  1.0
    x_82        EDGE_20_82  1.0
    x_82        EDGE_31_82  1.0
    x_82        EDGE_82_105  1.0
    x_82        EDGE_82_95  1.0
    x_82        EDGE_26_82  1.0
    x_82        EDGE_82_99  1.0
    x_82        EDGE_45_82  1.0
    x_82        EDGE_82_85  1.0
    x_82        EDGE_82_84  1.0
    x_82        EDGE_40_82  1.0
    x_82        EDGE_2_82  1.0
    x_83        OBJ       -93
    x_83        EDGE_24_83  1.0
    x_83        EDGE_54_83  1.0
    x_83        EDGE_83_109  1.0
    x_83        EDGE_83_90  1.0
    x_83        EDGE_83_94  1.0
    x_83        EDGE_52_83  1.0
    x_83        EDGE_14_83  1.0
    x_83        EDGE_63_83  1.0
    x_83        EDGE_74_83  1.0
    x_83        EDGE_36_83  1.0
    x_83        EDGE_66_83  1.0
    x_83        EDGE_17_83  1.0
    x_83        EDGE_32_83  1.0
    x_83        EDGE_12_83  1.0
    x_83        EDGE_83_97  1.0
    x_83        EDGE_53_83  1.0
    x_83        EDGE_64_83  1.0
    x_83        EDGE_83_92  1.0
    x_83        EDGE_18_83  1.0
    x_83        EDGE_48_83  1.0
    x_83        EDGE_51_83  1.0
    x_84        OBJ       -59
    x_84        EDGE_16_84  1.0
    x_84        EDGE_84_106  1.0
    x_84        EDGE_1_84  1.0
    x_84        EDGE_3_84  1.0
    x_84        EDGE_56_84  1.0
    x_84        EDGE_12_84  1.0
    x_84        EDGE_84_109  1.0
    x_84        EDGE_84_86  1.0
    x_84        EDGE_43_84  1.0
    x_84        EDGE_84_94  1.0
    x_84        EDGE_34_84  1.0
    x_84        EDGE_45_84  1.0
    x_84        EDGE_84_89  1.0
    x_84        EDGE_76_84  1.0
    x_84        EDGE_27_84  1.0
    x_84        EDGE_46_84  1.0
    x_84        EDGE_68_84  1.0
    x_84        EDGE_22_84  1.0
    x_84        EDGE_79_84  1.0
    x_84        EDGE_82_84  1.0
    x_85        OBJ       -63
    x_85        EDGE_17_85  1.0
    x_85        EDGE_60_85  1.0
    x_85        EDGE_9_85  1.0
    x_85        EDGE_61_85  1.0
    x_85        EDGE_12_85  1.0
    x_85        EDGE_64_85  1.0
    x_85        EDGE_56_85  1.0
    x_85        EDGE_85_88  1.0
    x_85        EDGE_85_106  1.0
    x_85        EDGE_29_85  1.0
    x_85        EDGE_85_92  1.0
    x_85        EDGE_70_85  1.0
    x_85        EDGE_43_85  1.0
    x_85        EDGE_35_85  1.0
    x_85        EDGE_54_85  1.0
    x_85        EDGE_46_85  1.0
    x_85        EDGE_82_85  1.0
    x_85        EDGE_55_85  1.0
    x_86        OBJ       -85
    x_86        EDGE_50_86  1.0
    x_86        EDGE_42_86  1.0
    x_86        EDGE_86_104  1.0
    x_86        EDGE_86_99  1.0
    x_86        EDGE_29_86  1.0
    x_86        EDGE_86_98  1.0
    x_86        EDGE_43_86  1.0
    x_86        EDGE_73_86  1.0
    x_86        EDGE_54_86  1.0
    x_86        EDGE_27_86  1.0
    x_86        EDGE_84_86  1.0
    x_86        EDGE_57_86  1.0
    x_86        EDGE_0_86  1.0
    x_86        EDGE_22_86  1.0
    x_86        EDGE_86_102  1.0
    x_86        EDGE_71_86  1.0
    x_86        EDGE_86_97  1.0
    x_86        EDGE_86_92  1.0
    x_87        OBJ       -29
    x_87        EDGE_62_87  1.0
    x_87        EDGE_13_87  1.0
    x_87        EDGE_87_93  1.0
    x_87        EDGE_87_106  1.0
    x_87        EDGE_87_101  1.0
    x_87        EDGE_68_87  1.0
    x_87        EDGE_11_87  1.0
    x_87        EDGE_87_91  1.0
    x_87        EDGE_60_87  1.0
    x_87        EDGE_22_87  1.0
    x_87        EDGE_52_87  1.0
    x_87        EDGE_71_87  1.0
    x_87        EDGE_39_87  1.0
    x_87        EDGE_87_100  1.0
    x_87        EDGE_1_87  1.0
    x_87        EDGE_31_87  1.0
    x_87        EDGE_61_87  1.0
    x_87        EDGE_87_90  1.0
    x_87        EDGE_87_99  1.0
    x_87        EDGE_87_108  1.0
    x_87        EDGE_64_87  1.0
    x_87        EDGE_26_87  1.0
    x_87        EDGE_78_87  1.0
    x_87        EDGE_29_87  1.0
    x_88        OBJ       -42
    x_88        EDGE_35_88  1.0
    x_88        EDGE_8_88  1.0
    x_88        EDGE_38_88  1.0
    x_88        EDGE_0_88  1.0
    x_88        EDGE_11_88  1.0
    x_88        EDGE_60_88  1.0
    x_88        EDGE_41_88  1.0
    x_88        EDGE_14_88  1.0
    x_88        EDGE_25_88  1.0
    x_88        EDGE_85_88  1.0
    x_88        EDGE_9_88  1.0
    x_88        EDGE_1_88  1.0
    x_88        EDGE_58_88  1.0
    x_88        EDGE_61_88  1.0
    x_88        EDGE_4_88  1.0
    x_88        EDGE_88_91  1.0
    x_88        EDGE_56_88  1.0
    x_88        EDGE_37_88  1.0
    x_88        EDGE_48_88  1.0
    x_88        EDGE_10_88  1.0
    x_88        EDGE_40_88  1.0
    x_88        EDGE_32_88  1.0
    x_88        EDGE_62_88  1.0
    x_89        OBJ       -90
    x_89        EDGE_36_89  1.0
    x_89        EDGE_47_89  1.0
    x_89        EDGE_69_89  1.0
    x_89        EDGE_53_89  1.0
    x_89        EDGE_45_89  1.0
    x_89        EDGE_56_89  1.0
    x_89        EDGE_89_95  1.0
    x_89        EDGE_75_89  1.0
    x_89        EDGE_10_89  1.0
    x_89        EDGE_29_89  1.0
    x_89        EDGE_59_89  1.0
    x_89        EDGE_4_89  1.0
    x_89        EDGE_43_89  1.0
    x_89        EDGE_73_89  1.0
    x_89        EDGE_84_89  1.0
    x_89        EDGE_46_89  1.0
    x_89        EDGE_30_89  1.0
    x_89        EDGE_79_89  1.0
    x_89        EDGE_3_89  1.0
    x_89        EDGE_6_89  1.0
    x_90        OBJ       -22
    x_90        EDGE_69_90  1.0
    x_90        EDGE_83_90  1.0
    x_90        EDGE_34_90  1.0
    x_90        EDGE_56_90  1.0
    x_90        EDGE_90_106  1.0
    x_90        EDGE_37_90  1.0
    x_90        EDGE_90_105  1.0
    x_90        EDGE_59_90  1.0
    x_90        EDGE_70_90  1.0
    x_90        EDGE_21_90  1.0
    x_90        EDGE_32_90  1.0
    x_90        EDGE_5_90  1.0
    x_90        EDGE_13_90  1.0
    x_90        EDGE_24_90  1.0
    x_90        EDGE_54_90  1.0
    x_90        EDGE_65_90  1.0
    x_90        EDGE_27_90  1.0
    x_90        EDGE_57_90  1.0
    x_90        EDGE_30_90  1.0
    x_90        EDGE_87_90  1.0
    x_90        EDGE_49_90  1.0
    x_90        EDGE_11_90  1.0
    x_90        EDGE_22_90  1.0
    x_90        EDGE_33_90  1.0
    x_90        EDGE_55_90  1.0
    x_90        EDGE_36_90  1.0
    x_90        EDGE_17_90  1.0
    x_91        OBJ       -79
    x_91        EDGE_50_91  1.0
    x_91        EDGE_61_91  1.0
    x_91        EDGE_51_91  1.0
    x_91        EDGE_4_91  1.0
    x_91        EDGE_18_91  1.0
    x_91        EDGE_75_91  1.0
    x_91        EDGE_91_108  1.0
    x_91        EDGE_91_98  1.0
    x_91        EDGE_87_91  1.0
    x_91        EDGE_70_91  1.0
    x_91        EDGE_6_91  1.0
    x_91        EDGE_74_91  1.0
    x_91        EDGE_47_91  1.0
    x_91        EDGE_38_91  1.0
    x_91        EDGE_91_102  1.0
    x_91        EDGE_39_91  1.0
    x_91        EDGE_69_91  1.0
    x_91        EDGE_91_97  1.0
    x_91        EDGE_88_91  1.0
    x_91        EDGE_3_91  1.0
    x_91        EDGE_71_91  1.0
    x_91        EDGE_33_91  1.0
    x_91        EDGE_44_91  1.0
    x_91        EDGE_63_91  1.0
    x_91        EDGE_53_91  1.0
    x_91        EDGE_67_91  1.0
    x_91        EDGE_78_91  1.0
    x_92        OBJ       -35
    x_92        EDGE_24_92  1.0
    x_92        EDGE_35_92  1.0
    x_92        EDGE_30_92  1.0
    x_92        EDGE_82_92  1.0
    x_92        EDGE_6_92  1.0
    x_92        EDGE_74_92  1.0
    x_92        EDGE_85_92  1.0
    x_92        EDGE_36_92  1.0
    x_92        EDGE_92_100  1.0
    x_92        EDGE_92_99  1.0
    x_92        EDGE_69_92  1.0
    x_92        EDGE_92_94  1.0
    x_92        EDGE_31_92  1.0
    x_92        EDGE_12_92  1.0
    x_92        EDGE_64_92  1.0
    x_92        EDGE_15_92  1.0
    x_92        EDGE_26_92  1.0
    x_92        EDGE_83_92  1.0
    x_92        EDGE_34_92  1.0
    x_92        EDGE_86_92  1.0
    x_92        EDGE_92_107  1.0
    x_93        OBJ       -99
    x_93        EDGE_16_93  1.0
    x_93        EDGE_46_93  1.0
    x_93        EDGE_68_93  1.0
    x_93        EDGE_19_93  1.0
    x_93        EDGE_87_93  1.0
    x_93        EDGE_0_93  1.0
    x_93        EDGE_74_93  1.0
    x_93        EDGE_47_93  1.0
    x_93        EDGE_66_93  1.0
    x_93        EDGE_9_93  1.0
    x_93        EDGE_39_93  1.0
    x_93        EDGE_93_100  1.0
    x_93        EDGE_23_93  1.0
    x_93        EDGE_51_93  1.0
    x_93        EDGE_42_93  1.0
    x_93        EDGE_15_93  1.0
    x_93        EDGE_56_93  1.0
    x_93        EDGE_7_93  1.0
    x_93        EDGE_37_93  1.0
    x_93        EDGE_10_93  1.0
    x_93        EDGE_70_93  1.0
    x_93        EDGE_93_108  1.0
    x_93        EDGE_54_93  1.0
    x_94        OBJ       -62
    x_94        EDGE_72_94  1.0
    x_94        EDGE_64_94  1.0
    x_94        EDGE_15_94  1.0
    x_94        EDGE_83_94  1.0
    x_94        EDGE_34_94  1.0
    x_94        EDGE_45_94  1.0
    x_94        EDGE_37_94  1.0
    x_94        EDGE_81_94  1.0
    x_94        EDGE_13_94  1.0
    x_94        EDGE_92_94  1.0
    x_94        EDGE_94_107  1.0
    x_94        EDGE_84_94  1.0
    x_94        EDGE_57_94  1.0
    x_94        EDGE_68_94  1.0
    x_94        EDGE_94_97  1.0
    x_94        EDGE_94_106  1.0
    x_94        EDGE_49_94  1.0
    x_94        EDGE_11_94  1.0
    x_94        EDGE_94_105  1.0
    x_95        OBJ       -40
    x_95        EDGE_58_95  1.0
    x_95        EDGE_95_102  1.0
    x_95        EDGE_95_97  1.0
    x_95        EDGE_95_106  1.0
    x_95        EDGE_4_95  1.0
    x_95        EDGE_95_96  1.0
    x_95        EDGE_56_95  1.0
    x_95        EDGE_18_95  1.0
    x_95        EDGE_78_95  1.0
    x_95        EDGE_89_95  1.0
    x_95        EDGE_29_95  1.0
    x_95        EDGE_32_95  1.0
    x_95        EDGE_43_95  1.0
    x_95        EDGE_73_95  1.0
    x_95        EDGE_35_95  1.0
    x_95        EDGE_65_95  1.0
    x_95        EDGE_46_95  1.0
    x_95        EDGE_49_95  1.0
    x_95        EDGE_79_95  1.0
    x_95        EDGE_82_95  1.0
    x_95        EDGE_44_95  1.0
    x_95        EDGE_28_95  1.0
    x_96        OBJ       -39
    x_96        EDGE_43_96  1.0
    x_96        EDGE_96_99  1.0
    x_96        EDGE_35_96  1.0
    x_96        EDGE_65_96  1.0
    x_96        EDGE_95_96  1.0
    x_96        EDGE_41_96  1.0
    x_96        EDGE_82_96  1.0
    x_96        EDGE_13_96  1.0
    x_96        EDGE_96_102  1.0
    x_96        EDGE_39_96  1.0
    x_96        EDGE_53_96  1.0
    x_96        EDGE_64_96  1.0
    x_96        EDGE_26_96  1.0
    x_96        EDGE_48_96  1.0
    x_96        EDGE_78_96  1.0
    x_96        EDGE_40_96  1.0
    x_96        EDGE_96_100  1.0
    x_96        EDGE_96_109  1.0
    x_96        EDGE_70_96  1.0
    x_96        EDGE_12_96  1.0
    x_96        EDGE_23_96  1.0
    x_97        OBJ       -91
    x_97        EDGE_95_97  1.0
    x_97        EDGE_57_97  1.0
    x_97        EDGE_68_97  1.0
    x_97        EDGE_30_97  1.0
    x_97        EDGE_22_97  1.0
    x_97        EDGE_79_97  1.0
    x_97        EDGE_82_97  1.0
    x_97        EDGE_97_98  1.0
    x_97        EDGE_36_97  1.0
    x_97        EDGE_66_97  1.0
    x_97        EDGE_1_97  1.0
    x_97        EDGE_58_97  1.0
    x_97        EDGE_61_97  1.0
    x_97        EDGE_97_107  1.0
    x_97        EDGE_91_97  1.0
    x_97        EDGE_53_97  1.0
    x_97        EDGE_83_97  1.0
    x_97        EDGE_94_97  1.0
    x_97        EDGE_45_97  1.0
    x_97        EDGE_56_97  1.0
    x_97        EDGE_86_97  1.0
    x_97        EDGE_29_97  1.0
    x_97        EDGE_97_105  1.0
    x_97        EDGE_70_97  1.0
    x_98        OBJ       -65
    x_98        EDGE_8_98  1.0
    x_98        EDGE_91_98  1.0
    x_98        EDGE_6_98  1.0
    x_98        EDGE_66_98  1.0
    x_98        EDGE_86_98  1.0
    x_98        EDGE_97_98  1.0
    x_98        EDGE_9_98  1.0
    x_98        EDGE_48_98  1.0
    x_98        EDGE_31_98  1.0
    x_98        EDGE_51_98  1.0
    x_98        EDGE_81_98  1.0
    x_98        EDGE_4_98  1.0
    x_98        EDGE_73_98  1.0
    x_98        EDGE_10_98  1.0
    x_98        EDGE_67_98  1.0
    x_98        EDGE_98_107  1.0
    x_98        EDGE_54_98  1.0
    x_99        OBJ       -72
    x_99        EDGE_77_99  1.0
    x_99        EDGE_96_99  1.0
    x_99        EDGE_1_99  1.0
    x_99        EDGE_20_99  1.0
    x_99        EDGE_72_99  1.0
    x_99        EDGE_4_99  1.0
    x_99        EDGE_53_99  1.0
    x_99        EDGE_15_99  1.0
    x_99        EDGE_18_99  1.0
    x_99        EDGE_86_99  1.0
    x_99        EDGE_67_99  1.0
    x_99        EDGE_29_99  1.0
    x_99        EDGE_51_99  1.0
    x_99        EDGE_99_107  1.0
    x_99        EDGE_92_99  1.0
    x_99        EDGE_46_99  1.0
    x_99        EDGE_87_99  1.0
    x_99        EDGE_82_99  1.0
    x_100       OBJ       -67
    x_100       EDGE_23_100  1.0
    x_100       EDGE_81_100  1.0
    x_100       EDGE_34_100  1.0
    x_100       EDGE_78_100  1.0
    x_100       EDGE_29_100  1.0
    x_100       EDGE_40_100  1.0
    x_100       EDGE_70_100  1.0
    x_100       EDGE_24_100  1.0
    x_100       EDGE_92_100  1.0
    x_100       EDGE_93_100  1.0
    x_100       EDGE_87_100  1.0
    x_100       EDGE_77_100  1.0
    x_100       EDGE_3_100  1.0
    x_100       EDGE_6_100  1.0
    x_100       EDGE_47_100  1.0
    x_100       EDGE_66_100  1.0
    x_100       EDGE_96_100  1.0
    x_100       EDGE_69_100  1.0
    x_101       OBJ       -65
    x_101       EDGE_43_101  1.0
    x_101       EDGE_76_101  1.0
    x_101       EDGE_30_101  1.0
    x_101       EDGE_87_101  1.0
    x_101       EDGE_79_101  1.0
    x_101       EDGE_41_101  1.0
    x_101       EDGE_82_101  1.0
    x_101       EDGE_16_101  1.0
    x_101       EDGE_36_101  1.0
    x_101       EDGE_0_101  1.0
    x_101       EDGE_80_101  1.0
    x_101       EDGE_15_101  1.0
    x_101       EDGE_4_101  1.0
    x_102       OBJ       -84
    x_102       EDGE_65_102  1.0
    x_102       EDGE_27_102  1.0
    x_102       EDGE_95_102  1.0
    x_102       EDGE_8_102  1.0
    x_102       EDGE_38_102  1.0
    x_102       EDGE_102_104  1.0
    x_102       EDGE_22_102  1.0
    x_102       EDGE_3_102  1.0
    x_102       EDGE_66_102  1.0
    x_102       EDGE_17_102  1.0
    x_102       EDGE_96_102  1.0
    x_102       EDGE_58_102  1.0
    x_102       EDGE_69_102  1.0
    x_102       EDGE_20_102  1.0
    x_102       EDGE_4_102  1.0
    x_102       EDGE_91_102  1.0
    x_102       EDGE_56_102  1.0
    x_102       EDGE_86_102  1.0
    x_102       EDGE_67_102  1.0
    x_102       EDGE_2_102  1.0
    x_102       EDGE_54_102  1.0
    x_103       OBJ       -79
    x_103       EDGE_8_103  1.0
    x_103       EDGE_0_103  1.0
    x_103       EDGE_1_103  1.0
    x_103       EDGE_58_103  1.0
    x_103       EDGE_44_103  1.0
    x_103       EDGE_72_103  1.0
    x_103       EDGE_28_103  1.0
    x_103       EDGE_48_103  1.0
    x_103       EDGE_78_103  1.0
    x_103       EDGE_50_103  1.0
    x_103       EDGE_32_103  1.0
    x_103       EDGE_18_103  1.0
    x_103       EDGE_27_103  1.0
    x_103       EDGE_46_103  1.0
    x_103       EDGE_29_103  1.0
    x_103       EDGE_70_103  1.0
    x_103       EDGE_21_103  1.0
    x_103       EDGE_55_103  1.0
    x_103       EDGE_6_103  1.0
    x_104       OBJ       -76
    x_104       EDGE_80_104  1.0
    x_104       EDGE_50_104  1.0
    x_104       EDGE_4_104  1.0
    x_104       EDGE_102_104  1.0
    x_104       EDGE_34_104  1.0
    x_104       EDGE_75_104  1.0
    x_104       EDGE_86_104  1.0
    x_104       EDGE_78_104  1.0
    x_104       EDGE_29_104  1.0
    x_104       EDGE_40_104  1.0
    x_104       EDGE_81_104  1.0
    x_104       EDGE_35_104  1.0
    x_104       EDGE_57_104  1.0
    x_104       EDGE_68_104  1.0
    x_104       EDGE_19_104  1.0
    x_104       EDGE_11_104  1.0
    x_104       EDGE_22_104  1.0
    x_104       EDGE_63_104  1.0
    x_104       EDGE_104_109  1.0
    x_104       EDGE_9_104  1.0
    x_105       OBJ       -53
    x_105       EDGE_81_105  1.0
    x_105       EDGE_34_105  1.0
    x_105       EDGE_37_105  1.0
    x_105       EDGE_90_105  1.0
    x_105       EDGE_43_105  1.0
    x_105       EDGE_35_105  1.0
    x_105       EDGE_54_105  1.0
    x_105       EDGE_55_105  1.0
    x_105       EDGE_68_105  1.0
    x_105       EDGE_30_105  1.0
    x_105       EDGE_72_105  1.0
    x_105       EDGE_0_105  1.0
    x_105       EDGE_82_105  1.0
    x_105       EDGE_64_105  1.0
    x_105       EDGE_94_105  1.0
    x_105       EDGE_36_105  1.0
    x_105       EDGE_28_105  1.0
    x_105       EDGE_97_105  1.0
    x_105       EDGE_9_105  1.0
    x_105       EDGE_61_105  1.0
    x_106       OBJ       -40
    x_106       EDGE_16_106  1.0
    x_106       EDGE_65_106  1.0
    x_106       EDGE_84_106  1.0
    x_106       EDGE_95_106  1.0
    x_106       EDGE_57_106  1.0
    x_106       EDGE_87_106  1.0
    x_106       EDGE_90_106  1.0
    x_106       EDGE_71_106  1.0
    x_106       EDGE_33_106  1.0
    x_106       EDGE_85_106  1.0
    x_106       EDGE_80_106  1.0
    x_106       EDGE_12_106  1.0
    x_106       EDGE_23_106  1.0
    x_106       EDGE_64_106  1.0
    x_106       EDGE_94_106  1.0
    x_106       EDGE_37_106  1.0
    x_106       EDGE_62_106  1.0
    x_107       OBJ       -94
    x_107       EDGE_76_107  1.0
    x_107       EDGE_30_107  1.0
    x_107       EDGE_0_107  1.0
    x_107       EDGE_41_107  1.0
    x_107       EDGE_14_107  1.0
    x_107       EDGE_82_107  1.0
    x_107       EDGE_63_107  1.0
    x_107       EDGE_66_107  1.0
    x_107       EDGE_28_107  1.0
    x_107       EDGE_99_107  1.0
    x_107       EDGE_61_107  1.0
    x_107       EDGE_4_107  1.0
    x_107       EDGE_97_107  1.0
    x_107       EDGE_94_107  1.0
    x_107       EDGE_34_107  1.0
    x_107       EDGE_45_107  1.0
    x_107       EDGE_78_107  1.0
    x_107       EDGE_98_107  1.0
    x_107       EDGE_81_107  1.0
    x_107       EDGE_13_107  1.0
    x_107       EDGE_92_107  1.0
    x_108       OBJ       -27
    x_108       EDGE_58_108  1.0
    x_108       EDGE_20_108  1.0
    x_108       EDGE_50_108  1.0
    x_108       EDGE_91_108  1.0
    x_108       EDGE_64_108  1.0
    x_108       EDGE_75_108  1.0
    x_108       EDGE_48_108  1.0
    x_108       EDGE_10_108  1.0
    x_108       EDGE_12_108  1.0
    x_108       EDGE_51_108  1.0
    x_108       EDGE_62_108  1.0
    x_108       EDGE_24_108  1.0
    x_108       EDGE_54_108  1.0
    x_108       EDGE_27_108  1.0
    x_108       EDGE_46_108  1.0
    x_108       EDGE_57_108  1.0
    x_108       EDGE_30_108  1.0
    x_108       EDGE_87_108  1.0
    x_108       EDGE_38_108  1.0
    x_108       EDGE_49_108  1.0
    x_108       EDGE_2_108  1.0
    x_108       EDGE_21_108  1.0
    x_108       EDGE_22_108  1.0
    x_108       EDGE_71_108  1.0
    x_108       EDGE_93_108  1.0
    x_109       OBJ       -63
    x_109       EDGE_12_109  1.0
    x_109       EDGE_64_109  1.0
    x_109       EDGE_83_109  1.0
    x_109       EDGE_75_109  1.0
    x_109       EDGE_10_109  1.0
    x_109       EDGE_29_109  1.0
    x_109       EDGE_81_109  1.0
    x_109       EDGE_32_109  1.0
    x_109       EDGE_5_109  1.0
    x_109       EDGE_84_109  1.0
    x_109       EDGE_8_109  1.0
    x_109       EDGE_0_109  1.0
    x_109       EDGE_60_109  1.0
    x_109       EDGE_52_109  1.0
    x_109       EDGE_44_109  1.0
    x_109       EDGE_104_109  1.0
    x_109       EDGE_17_109  1.0
    x_109       EDGE_96_109  1.0
    x_109       EDGE_1_109  1.0
RHS
    RHS1      EDGE_35_88  1.0
    RHS1      EDGE_47_53  1.0
    RHS1      EDGE_43_101  1.0
    RHS1      EDGE_16_84  1.0
    RHS1      EDGE_16_93  1.0
    RHS1      EDGE_36_71  1.0
    RHS1      EDGE_76_107  1.0
    RHS1      EDGE_18_44  1.0
    RHS1      EDGE_47_80  1.0
    RHS1      EDGE_59_82  1.0
    RHS1      EDGE_70_82  1.0
    RHS1      EDGE_36_89  1.0
    RHS1      EDGE_47_89  1.0
    RHS1      EDGE_48_54  1.0
    RHS1      EDGE_17_85  1.0
    RHS1      EDGE_6_48  1.0
    RHS1      EDGE_48_63  1.0
    RHS1      EDGE_77_99  1.0
    RHS1      EDGE_58_95  1.0
    RHS1      EDGE_48_72  1.0
    RHS1      EDGE_50_91  1.0
    RHS1      EDGE_61_91  1.0
    RHS1      EDGE_80_104  1.0
    RHS1      EDGE_10_27  1.0
    RHS1      EDGE_40_77  1.0
    RHS1      EDGE_8_103  1.0
    RHS1      EDGE_10_54  1.0
    RHS1      EDGE_81_105  1.0
    RHS1      EDGE_2_50  1.0
    RHS1      EDGE_10_63  1.0
    RHS1      EDGE_22_28  1.0
    RHS1      EDGE_51_64  1.0
    RHS1      EDGE_3_24  1.0
    RHS1      EDGE_14_24  1.0
    RHS1      EDGE_43_69  1.0
    RHS1      EDGE_66_71  1.0
    RHS1      EDGE_22_46  1.0
    RHS1      EDGE_23_100  1.0
    RHS1      EDGE_35_65  1.0
    RHS1      EDGE_14_42  1.0
    RHS1      EDGE_12_109  1.0
    RHS1      EDGE_51_91  1.0
    RHS1      EDGE_24_83  1.0
    RHS1      EDGE_43_96  1.0
    RHS1      EDGE_60_85  1.0
    RHS1      EDGE_96_99  1.0
    RHS1      EDGE_24_92  1.0
    RHS1      EDGE_35_92  1.0
    RHS1      EDGE_1_99  1.0
    RHS1      EDGE_36_66  1.0
    RHS1      EDGE_65_102  1.0
    RHS1      EDGE_55_79  1.0
    RHS1      EDGE_17_62  1.0
    RHS1      EDGE_70_77  1.0
    RHS1      EDGE_16_106  1.0
    RHS1      EDGE_5_69  1.0
    RHS1      EDGE_48_49  1.0
    RHS1      EDGE_29_54  1.0
    RHS1      EDGE_69_90  1.0
    RHS1      EDGE_9_85  1.0
    RHS1      EDGE_50_86  1.0
    RHS1      EDGE_42_82  1.0
    RHS1      EDGE_58_108  1.0
    RHS1      EDGE_27_102  1.0
    RHS1      EDGE_50_104  1.0
    RHS1      EDGE_62_69  1.0
    RHS1      EDGE_8_98  1.0
    RHS1      EDGE_54_65  1.0
    RHS1      EDGE_10_40  1.0
    RHS1      EDGE_30_107  1.0
    RHS1      EDGE_54_74  1.0
    RHS1      EDGE_0_103  1.0
    RHS1      EDGE_62_87  1.0
    RHS1      EDGE_81_100  1.0
    RHS1      EDGE_2_45  1.0
    RHS1      EDGE_20_81  1.0
    RHS1      EDGE_54_83  1.0
    RHS1      EDGE_32_55  1.0
    RHS1      EDGE_43_55  1.0
    RHS1      EDGE_22_32  1.0
    RHS1      EDGE_20_99  1.0
    RHS1      EDGE_95_102  1.0
    RHS1      EDGE_35_60  1.0
    RHS1      EDGE_20_108  1.0
    RHS1      EDGE_4_91  1.0
    RHS1      EDGE_14_37  1.0
    RHS1      EDGE_13_69  1.0
    RHS1      EDGE_24_78  1.0
    RHS1      EDGE_35_78  1.0
    RHS1      EDGE_16_74  1.0
    RHS1      EDGE_13_87  1.0
    RHS1      EDGE_35_96  1.0
    RHS1      EDGE_28_57  1.0
    RHS1      EDGE_1_103  1.0
    RHS1      EDGE_46_93  1.0
    RHS1      EDGE_47_70  1.0
    RHS1      EDGE_65_106  1.0
    RHS1      EDGE_17_66  1.0
    RHS1      EDGE_68_93  1.0
    RHS1      EDGE_77_80  1.0
    RHS1      EDGE_5_73  1.0
    RHS1      EDGE_6_38  1.0
    RHS1      EDGE_17_75  1.0
    RHS1      EDGE_9_71  1.0
    RHS1      EDGE_61_72  1.0
    RHS1      EDGE_42_77  1.0
    RHS1      EDGE_58_103  1.0
    RHS1      EDGE_42_86  1.0
    RHS1      EDGE_19_93  1.0
    RHS1      EDGE_50_108  1.0
    RHS1      EDGE_8_102  1.0
    RHS1      EDGE_20_67  1.0
    RHS1      EDGE_20_76  1.0
    RHS1      EDGE_0_107  1.0
    RHS1      EDGE_3_14  1.0
    RHS1      EDGE_32_59  1.0
    RHS1      EDGE_95_97  1.0
    RHS1      EDGE_87_93  1.0
    RHS1      EDGE_43_68  1.0
    RHS1      EDGE_84_106  1.0
    RHS1      EDGE_51_81  1.0
    RHS1      EDGE_35_64  1.0
    RHS1      EDGE_95_106  1.0
    RHS1      EDGE_4_95  1.0
    RHS1      EDGE_16_60  1.0
    RHS1      EDGE_24_73  1.0
    RHS1      EDGE_36_38  1.0
    RHS1      EDGE_4_104  1.0
    RHS1      EDGE_34_105  1.0
    RHS1      EDGE_64_109  1.0
    RHS1      EDGE_46_79  1.0
    RHS1      EDGE_9_39  1.0
    RHS1      EDGE_28_52  1.0
    RHS1      EDGE_47_65  1.0
    RHS1      EDGE_76_101  1.0
    RHS1      EDGE_57_97  1.0
    RHS1      EDGE_6_24  1.0
    RHS1      EDGE_68_97  1.0
    RHS1      EDGE_9_57  1.0
    RHS1      EDGE_5_68  1.0
    RHS1      EDGE_57_106  1.0
    RHS1      EDGE_38_102  1.0
    RHS1      EDGE_50_67  1.0
    RHS1      EDGE_69_80  1.0
    RHS1      EDGE_50_76  1.0
    RHS1      EDGE_69_89  1.0
    RHS1      EDGE_42_72  1.0
    RHS1      EDGE_61_85  1.0
    RHS1      EDGE_2_8  1.0
    RHS1      EDGE_8_88  1.0
    RHS1      EDGE_20_53  1.0
    RHS1      EDGE_10_30  1.0
    RHS1      EDGE_102_104  1.0
    RHS1      EDGE_30_97  1.0
    RHS1      EDGE_54_64  1.0
    RHS1      EDGE_0_93  1.0
    RHS1      EDGE_62_77  1.0
    RHS1      EDGE_83_109  1.0
    RHS1      EDGE_12_76  1.0
    RHS1      EDGE_14_18  1.0
    RHS1      EDGE_43_54  1.0
    RHS1      EDGE_12_85  1.0
    RHS1      EDGE_72_99  1.0
    RHS1      EDGE_43_72  1.0
    RHS1      EDGE_1_66  1.0
    RHS1      EDGE_87_106  1.0
    RHS1      EDGE_4_99  1.0
    RHS1      EDGE_34_100  1.0
    RHS1      EDGE_1_84  1.0
    RHS1      EDGE_37_105  1.0
    RHS1      EDGE_9_34  1.0
    RHS1      EDGE_28_47  1.0
    RHS1      EDGE_65_96  1.0
    RHS1      EDGE_9_43  1.0
    RHS1      EDGE_38_79  1.0
    RHS1      EDGE_38_88  1.0
    RHS1      EDGE_50_53  1.0
    RHS1      EDGE_5_63  1.0
    RHS1      EDGE_9_61  1.0
    RHS1      EDGE_6_37  1.0
    RHS1      EDGE_18_91  1.0
    RHS1      EDGE_50_80  1.0
    RHS1      EDGE_11_70  1.0
    RHS1      EDGE_30_92  1.0
    RHS1      EDGE_2_21  1.0
    RHS1      EDGE_0_88  1.0
    RHS1      EDGE_11_88  1.0
    RHS1      EDGE_30_101  1.0
    RHS1      EDGE_75_91  1.0
    RHS1      EDGE_4_49  1.0
    RHS1      EDGE_91_108  1.0
    RHS1      EDGE_12_62  1.0
    RHS1      EDGE_41_107  1.0
    RHS1      EDGE_75_109  1.0
    RHS1      EDGE_44_103  1.0
    RHS1      EDGE_1_43  1.0
    RHS1      EDGE_24_45  1.0
    RHS1      EDGE_32_58  1.0
    RHS1      EDGE_43_58  1.0
    RHS1      EDGE_72_94  1.0
    RHS1      EDGE_95_96  1.0
    RHS1      EDGE_72_103  1.0
    RHS1      EDGE_53_99  1.0
    RHS1      EDGE_87_101  1.0
    RHS1      EDGE_56_95  1.0
    RHS1      EDGE_17_24  1.0
    RHS1      EDGE_1_70  1.0
    RHS1      EDGE_64_108  1.0
    RHS1      EDGE_22_102  1.0
    RHS1      EDGE_28_33  1.0
    RHS1      EDGE_34_104  1.0
    RHS1      EDGE_38_65  1.0
    RHS1      EDGE_17_42  1.0
    RHS1      EDGE_14_107  1.0
    RHS1      EDGE_26_72  1.0
    RHS1      EDGE_68_87  1.0
    RHS1      EDGE_9_47  1.0
    RHS1      EDGE_42_44  1.0
    RHS1      EDGE_50_57  1.0
    RHS1      EDGE_15_99  1.0
    RHS1      EDGE_27_64  1.0
    RHS1      EDGE_18_95  1.0
    RHS1      EDGE_50_75  1.0
    RHS1      EDGE_30_69  1.0
    RHS1      EDGE_82_107  1.0
    RHS1      EDGE_39_47  1.0
    RHS1      EDGE_2_16  1.0
    RHS1      EDGE_60_88  1.0
    RHS1      EDGE_83_90  1.0
    RHS1      EDGE_31_61  1.0
    RHS1      EDGE_12_57  1.0
    RHS1      EDGE_32_35  1.0
    RHS1      EDGE_75_104  1.0
    RHS1      EDGE_1_29  1.0
    RHS1      EDGE_24_31  1.0
    RHS1      EDGE_4_62  1.0
    RHS1      EDGE_64_67  1.0
    RHS1      EDGE_12_75  1.0
    RHS1      EDGE_64_76  1.0
    RHS1      EDGE_16_36  1.0
    RHS1      EDGE_1_47  1.0
    RHS1      EDGE_35_49  1.0
    RHS1      EDGE_64_85  1.0
    RHS1      EDGE_22_79  1.0
    RHS1      EDGE_5_8  1.0
    RHS1      EDGE_34_81  1.0
    RHS1      EDGE_56_81  1.0
    RHS1      EDGE_64_94  1.0
    RHS1      EDGE_34_90  1.0
    RHS1      EDGE_5_17  1.0
    RHS1      EDGE_56_90  1.0
    RHS1      EDGE_3_84  1.0
    RHS1      EDGE_9_15  1.0
    RHS1      EDGE_22_97  1.0
    RHS1      EDGE_65_68  1.0
    RHS1      EDGE_9_24  1.0
    RHS1      EDGE_49_60  1.0
    RHS1      EDGE_3_102  1.0
    RHS1      EDGE_49_78  1.0
    RHS1      EDGE_8_46  1.0
    RHS1      EDGE_15_94  1.0
    RHS1      EDGE_79_97  1.0
    RHS1      EDGE_19_55  1.0
    RHS1      EDGE_42_57  1.0
    RHS1      EDGE_90_106  1.0
    RHS1      EDGE_18_99  1.0
    RHS1      EDGE_27_77  1.0
    RHS1      EDGE_11_60  1.0
    RHS1      EDGE_42_75  1.0
    RHS1      EDGE_63_107  1.0
    RHS1      EDGE_23_34  1.0
    RHS1      EDGE_91_98  1.0
    RHS1      EDGE_83_94  1.0
    RHS1      EDGE_11_87  1.0
    RHS1      EDGE_12_52  1.0
    RHS1      EDGE_1_15  1.0
    RHS1      EDGE_41_88  1.0
    RHS1      EDGE_4_48  1.0
    RHS1      EDGE_12_61  1.0
    RHS1      EDGE_23_61  1.0
    RHS1      EDGE_72_75  1.0
    RHS1      EDGE_75_108  1.0
    RHS1      EDGE_4_66  1.0
    RHS1      EDGE_16_31  1.0
    RHS1      EDGE_37_63  1.0
    RHS1      EDGE_10_109  1.0
    RHS1      EDGE_34_76  1.0
    RHS1      EDGE_53_89  1.0
    RHS1      EDGE_37_72  1.0
    RHS1      EDGE_87_91  1.0
    RHS1      EDGE_56_85  1.0
    RHS1      EDGE_14_79  1.0
    RHS1      EDGE_37_81  1.0
    RHS1      EDGE_34_94  1.0
    RHS1      EDGE_5_21  1.0
    RHS1      EDGE_45_94  1.0
    RHS1      EDGE_14_88  1.0
    RHS1      EDGE_9_19  1.0
    RHS1      EDGE_26_53  1.0
    RHS1      EDGE_37_90  1.0
    RHS1      EDGE_38_55  1.0
    RHS1      EDGE_86_104  1.0
    RHS1      EDGE_78_100  1.0
    RHS1      EDGE_57_77  1.0
    RHS1      EDGE_18_58  1.0
    RHS1      EDGE_68_77  1.0
    RHS1      EDGE_18_67  1.0
    RHS1      EDGE_7_76  1.0
    RHS1      EDGE_27_63  1.0
    RHS1      EDGE_0_46  1.0
    RHS1      EDGE_79_101  1.0
    RHS1      EDGE_30_59  1.0
    RHS1      EDGE_82_97  1.0
    RHS1      EDGE_71_106  1.0
    RHS1      EDGE_6_98  1.0
    RHS1      EDGE_11_64  1.0
    RHS1      EDGE_12_29  1.0
    RHS1      EDGE_29_100  1.0
    RHS1      EDGE_40_100  1.0
    RHS1      EDGE_29_109  1.0
    RHS1      EDGE_23_38  1.0
    RHS1      EDGE_60_87  1.0
    RHS1      EDGE_52_83  1.0
    RHS1      EDGE_1_10  1.0
    RHS1      EDGE_25_75  1.0
    RHS1      EDGE_53_57  1.0
    RHS1      EDGE_41_101  1.0
    RHS1      EDGE_13_30  1.0
    RHS1      EDGE_4_61  1.0
    RHS1      EDGE_16_26  1.0
    RHS1      EDGE_33_106  1.0
    RHS1      EDGE_22_69  1.0
    RHS1      EDGE_34_71  1.0
    RHS1      EDGE_1_46  1.0
    RHS1      EDGE_14_65  1.0
    RHS1      EDGE_37_67  1.0
    RHS1      EDGE_22_78  1.0
    RHS1      EDGE_56_71  1.0
    RHS1      EDGE_22_87  1.0
    RHS1      EDGE_45_89  1.0
    RHS1      EDGE_56_89  1.0
    RHS1      EDGE_14_83  1.0
    RHS1      EDGE_15_48  1.0
    RHS1      EDGE_26_48  1.0
    RHS1      EDGE_38_50  1.0
    RHS1      EDGE_46_63  1.0
    RHS1      EDGE_37_94  1.0
    RHS1      EDGE_15_57  1.0
    RHS1      EDGE_38_59  1.0
    RHS1      EDGE_78_95  1.0
    RHS1      EDGE_70_91  1.0
    RHS1      EDGE_86_99  1.0
    RHS1      EDGE_78_104  1.0
    RHS1      EDGE_89_95  1.0
    RHS1      EDGE_7_62  1.0
    RHS1      EDGE_18_62  1.0
    RHS1      EDGE_19_27  1.0
    RHS1      EDGE_70_100  1.0
    RHS1      EDGE_27_49  1.0
    RHS1      EDGE_0_32  1.0
    RHS1      EDGE_28_103  1.0
    RHS1      EDGE_30_45  1.0
    RHS1      EDGE_11_41  1.0
    RHS1      EDGE_82_92  1.0
    RHS1      EDGE_90_105  1.0
    RHS1      EDGE_29_86  1.0
    RHS1      EDGE_8_63  1.0
    RHS1      EDGE_19_63  1.0
    RHS1      EDGE_82_101  1.0
    RHS1      EDGE_29_95  1.0
    RHS1      EDGE_12_24  1.0
    RHS1      EDGE_48_108  1.0
    RHS1      EDGE_31_37  1.0
    RHS1      EDGE_60_73  1.0
    RHS1      EDGE_29_104  1.0
    RHS1      EDGE_40_104  1.0
    RHS1      EDGE_52_69  1.0
    RHS1      EDGE_4_29  1.0
    RHS1      EDGE_44_65  1.0
    RHS1      EDGE_12_42  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_41_78  1.0
    RHS1      EDGE_33_74  1.0
    RHS1      EDGE_34_39  1.0
    RHS1      EDGE_52_87  1.0
    RHS1      EDGE_75_89  1.0
    RHS1      EDGE_10_81  1.0
    RHS1      EDGE_34_48  1.0
    RHS1      EDGE_41_96  1.0
    RHS1      EDGE_2_77  1.0
    RHS1      EDGE_37_44  1.0
    RHS1      EDGE_74_93  1.0
    RHS1      EDGE_1_32  1.0
    RHS1      EDGE_25_88  1.0
    RHS1      EDGE_22_64  1.0
    RHS1      EDGE_66_98  1.0
    RHS1      EDGE_10_108  1.0
    RHS1      EDGE_22_73  1.0
    RHS1      EDGE_56_75  1.0
    RHS1      EDGE_37_71  1.0
    RHS1      EDGE_15_34  1.0
    RHS1      EDGE_43_105  1.0
    RHS1      EDGE_5_11  1.0
    RHS1      EDGE_46_49  1.0
    RHS1      EDGE_14_78  1.0
    RHS1      EDGE_56_84  1.0
    RHS1      EDGE_66_107  1.0
    RHS1      EDGE_57_58  1.0
    RHS1      EDGE_18_39  1.0
    RHS1      EDGE_67_72  1.0
    RHS1      EDGE_26_52  1.0
    RHS1      EDGE_78_81  1.0
    RHS1      EDGE_26_61  1.0
    RHS1      EDGE_67_99  1.0
    RHS1      EDGE_7_57  1.0
    RHS1      EDGE_19_22  1.0
    RHS1      EDGE_15_70  1.0
    RHS1      EDGE_47_93  1.0
    RHS1      EDGE_27_44  1.0
    RHS1      EDGE_18_75  1.0
    RHS1      EDGE_28_107  1.0
    RHS1      EDGE_0_36  1.0
    RHS1      EDGE_71_87  1.0
    RHS1      EDGE_63_83  1.0
    RHS1      EDGE_82_96  1.0
    RHS1      EDGE_11_54  1.0
    RHS1      EDGE_41_55  1.0
    RHS1      EDGE_48_103  1.0
    RHS1      EDGE_20_32  1.0
    RHS1      EDGE_29_99  1.0
    RHS1      EDGE_4_24  1.0
    RHS1      EDGE_41_73  1.0
    RHS1      EDGE_52_73  1.0
    RHS1      EDGE_81_109  1.0
    RHS1      EDGE_33_78  1.0
    RHS1      EDGE_34_43  1.0
    RHS1      EDGE_85_88  1.0
    RHS1      EDGE_3_46  1.0
    RHS1      EDGE_14_46  1.0
    RHS1      EDGE_66_93  1.0
    RHS1      EDGE_45_70  1.0
    RHS1      EDGE_85_106  1.0
    RHS1      EDGE_66_102  1.0
    RHS1      EDGE_26_29  1.0
    RHS1      EDGE_13_96  1.0
    RHS1      EDGE_32_109  1.0
    RHS1      EDGE_55_74  1.0
    RHS1      EDGE_35_105  1.0
    RHS1      EDGE_7_34  1.0
    RHS1      EDGE_16_101  1.0
    RHS1      EDGE_86_98  1.0
    RHS1      EDGE_18_43  1.0
    RHS1      EDGE_36_79  1.0
    RHS1      EDGE_70_81  1.0
    RHS1      EDGE_97_98  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_7_52  1.0
    RHS1      EDGE_18_52  1.0
    RHS1      EDGE_59_90  1.0
    RHS1      EDGE_70_90  1.0
    RHS1      EDGE_11_13  1.0
    RHS1      EDGE_18_61  1.0
    RHS1      EDGE_36_97  1.0
    RHS1      EDGE_78_103  1.0
    RHS1      EDGE_27_39  1.0
    RHS1      EDGE_0_22  1.0
    RHS1      EDGE_71_73  1.0
    RHS1      EDGE_17_102  1.0
    RHS1      EDGE_29_67  1.0
    RHS1      EDGE_9_98  1.0
    RHS1      EDGE_30_44  1.0
    RHS1      EDGE_5_109  1.0
    RHS1      EDGE_6_74  1.0
    RHS1      EDGE_29_76  1.0
    RHS1      EDGE_40_76  1.0
    RHS1      EDGE_71_82  1.0
    RHS1      EDGE_29_85  1.0
    RHS1      EDGE_12_14  1.0
    RHS1      EDGE_41_50  1.0
    RHS1      EDGE_21_81  1.0
    RHS1      EDGE_48_98  1.0
    RHS1      EDGE_6_92  1.0
    RHS1      EDGE_21_90  1.0
    RHS1      EDGE_81_104  1.0
    RHS1      EDGE_33_64  1.0
    RHS1      EDGE_1_4  1.0
    RHS1      EDGE_22_36  1.0
    RHS1      EDGE_25_69  1.0
    RHS1      EDGE_54_105  1.0
    RHS1      EDGE_74_83  1.0
    RHS1      EDGE_10_89  1.0
    RHS1      EDGE_12_108  1.0
    RHS1      EDGE_74_92  1.0
    RHS1      EDGE_85_92  1.0
    RHS1      EDGE_3_50  1.0
    RHS1      EDGE_43_86  1.0
    RHS1      EDGE_51_99  1.0
    RHS1      EDGE_32_95  1.0
    RHS1      EDGE_15_24  1.0
    RHS1      EDGE_43_95  1.0
    RHS1      EDGE_51_108  1.0
    RHS1      EDGE_66_97  1.0
    RHS1      EDGE_24_100  1.0
    RHS1      EDGE_70_76  1.0
    RHS1      EDGE_17_70  1.0
    RHS1      EDGE_28_70  1.0
    RHS1      EDGE_7_47  1.0
    RHS1      EDGE_36_83  1.0
    RHS1      EDGE_70_85  1.0
    RHS1      EDGE_17_79  1.0
    RHS1      EDGE_28_79  1.0
    RHS1      EDGE_36_92  1.0
    RHS1      EDGE_55_105  1.0
    RHS1      EDGE_29_53  1.0
    RHS1      EDGE_36_101  1.0
    RHS1      EDGE_6_60  1.0
    RHS1      EDGE_92_100  1.0
    RHS1      EDGE_9_93  1.0
    RHS1      EDGE_11_35  1.0
    RHS1      EDGE_21_67  1.0
    RHS1      EDGE_50_103  1.0
    RHS1      EDGE_40_80  1.0
    RHS1      EDGE_33_41  1.0
    RHS1      EDGE_29_89  1.0
    RHS1      EDGE_73_86  1.0
    RHS1      EDGE_52_63  1.0
    RHS1      EDGE_25_46  1.0
    RHS1      EDGE_33_59  1.0
    RHS1      EDGE_39_93  1.0
    RHS1      EDGE_73_95  1.0
    RHS1      EDGE_2_62  1.0
    RHS1      EDGE_14_27  1.0
    RHS1      EDGE_31_98  1.0
    RHS1      EDGE_25_73  1.0
    RHS1      EDGE_3_36  1.0
    RHS1      EDGE_37_38  1.0
    RHS1      EDGE_45_51  1.0
    RHS1      EDGE_93_100  1.0
    RHS1      EDGE_3_45  1.0
    RHS1      EDGE_66_83  1.0
    RHS1      EDGE_32_90  1.0
    RHS1      EDGE_3_63  1.0
    RHS1      EDGE_16_82  1.0
    RHS1      EDGE_55_64  1.0
    RHS1      EDGE_35_95  1.0
    RHS1      EDGE_96_102  1.0
    RHS1      EDGE_26_37  1.0
    RHS1      EDGE_35_104  1.0
    RHS1      EDGE_7_33  1.0
    RHS1      EDGE_36_69  1.0
    RHS1      EDGE_55_82  1.0
    RHS1      EDGE_99_107  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_59_89  1.0
    RHS1      EDGE_8_16  1.0
    RHS1      EDGE_17_83  1.0
    RHS1      EDGE_0_12  1.0
    RHS1      EDGE_29_48  1.0
    RHS1      EDGE_9_79  1.0
    RHS1      EDGE_5_90  1.0
    RHS1      EDGE_0_21  1.0
    RHS1      EDGE_40_57  1.0
    RHS1      EDGE_9_88  1.0
    RHS1      EDGE_58_102  1.0
    RHS1      EDGE_69_102  1.0
    RHS1      EDGE_61_107  1.0
    RHS1      EDGE_33_45  1.0
    RHS1      EDGE_6_91  1.0
    RHS1      EDGE_41_58  1.0
    RHS1      EDGE_81_94  1.0
    RHS1      EDGE_2_48  1.0
    RHS1      EDGE_25_50  1.0
    RHS1      EDGE_54_86  1.0
    RHS1      EDGE_51_62  1.0
    RHS1      EDGE_14_22  1.0
    RHS1      EDGE_62_108  1.0
    RHS1      EDGE_51_71  1.0
    RHS1      EDGE_2_66  1.0
    RHS1      EDGE_20_102  1.0
    RHS1      EDGE_74_91  1.0
    RHS1      EDGE_35_72  1.0
    RHS1      EDGE_43_85  1.0
    RHS1      EDGE_51_98  1.0
    RHS1      EDGE_13_81  1.0
    RHS1      EDGE_7_10  1.0
    RHS1      EDGE_35_81  1.0
    RHS1      EDGE_16_77  1.0
    RHS1      EDGE_1_88  1.0
    RHS1      EDGE_7_19  1.0
    RHS1      EDGE_13_90  1.0
    RHS1      EDGE_24_90  1.0
    RHS1      EDGE_26_32  1.0
    RHS1      EDGE_1_97  1.0
    RHS1      EDGE_28_51  1.0
    RHS1      EDGE_32_103  1.0
    RHS1      EDGE_36_64  1.0
    RHS1      EDGE_55_68  1.0
    RHS1      EDGE_24_108  1.0
    RHS1      EDGE_68_105  1.0
    RHS1      EDGE_36_82  1.0
    RHS1      EDGE_47_82  1.0
    RHS1      EDGE_17_78  1.0
    RHS1      EDGE_6_41  1.0
    RHS1      EDGE_47_91  1.0
    RHS1      EDGE_9_74  1.0
    RHS1      EDGE_58_88  1.0
    RHS1      EDGE_58_97  1.0
    RHS1      EDGE_92_99  1.0
    RHS1      EDGE_21_57  1.0
    RHS1      EDGE_40_70  1.0
    RHS1      EDGE_80_106  1.0
    RHS1      EDGE_6_77  1.0
    RHS1      EDGE_39_74  1.0
    RHS1      EDGE_30_105  1.0
    RHS1      EDGE_54_72  1.0
    RHS1      EDGE_0_101  1.0
    RHS1      EDGE_81_98  1.0
    RHS1      EDGE_25_45  1.0
    RHS1      EDGE_3_8  1.0
    RHS1      EDGE_10_56  1.0
    RHS1      EDGE_32_83  1.0
    RHS1      EDGE_54_90  1.0
    RHS1      EDGE_12_84  1.0
    RHS1      EDGE_14_26  1.0
    RHS1      EDGE_43_62  1.0
    RHS1      EDGE_23_93  1.0
    RHS1      EDGE_51_75  1.0
    RHS1      EDGE_54_108  1.0
    RHS1      EDGE_3_35  1.0
    RHS1      EDGE_4_89  1.0
    RHS1      EDGE_84_109  1.0
    RHS1      EDGE_35_67  1.0
    RHS1      EDGE_4_98  1.0
    RHS1      EDGE_32_80  1.0
    RHS1      EDGE_51_93  1.0
    RHS1      EDGE_4_107  1.0
    RHS1      EDGE_43_89  1.0
    RHS1      EDGE_35_85  1.0
    RHS1      EDGE_16_81  1.0
    RHS1      EDGE_13_94  1.0
    RHS1      EDGE_65_95  1.0
    RHS1      EDGE_5_53  1.0
    RHS1      EDGE_36_77  1.0
    RHS1      EDGE_9_60  1.0
    RHS1      EDGE_21_25  1.0
    RHS1      EDGE_17_73  1.0
    RHS1      EDGE_17_82  1.0
    RHS1      EDGE_29_47  1.0
    RHS1      EDGE_21_43  1.0
    RHS1      EDGE_29_56  1.0
    RHS1      EDGE_69_92  1.0
    RHS1      EDGE_92_94  1.0
    RHS1      EDGE_27_86  1.0
    RHS1      EDGE_10_15  1.0
    RHS1      EDGE_61_88  1.0
    RHS1      EDGE_80_101  1.0
    RHS1      EDGE_61_97  1.0
    RHS1      EDGE_97_107  1.0
    RHS1      EDGE_42_93  1.0
    RHS1      EDGE_54_58  1.0
    RHS1      EDGE_72_105  1.0
    RHS1      EDGE_8_109  1.0
    RHS1      EDGE_25_40  1.0
    RHS1      EDGE_0_105  1.0
    RHS1      EDGE_39_87  1.0
    RHS1      EDGE_73_89  1.0
    RHS1      EDGE_54_85  1.0
    RHS1      EDGE_43_48  1.0
    RHS1      EDGE_39_96  1.0
    RHS1      EDGE_22_25  1.0
    RHS1      EDGE_73_98  1.0
    RHS1      EDGE_31_92  1.0
    RHS1      EDGE_14_21  1.0
    RHS1      EDGE_84_86  1.0
    RHS1      EDGE_35_53  1.0
    RHS1      EDGE_51_79  1.0
    RHS1      EDGE_87_100  1.0
    RHS1      EDGE_12_106  1.0
    RHS1      EDGE_1_69  1.0
    RHS1      EDGE_23_106  1.0
    RHS1      EDGE_4_102  1.0
    RHS1      EDGE_24_71  1.0
    RHS1      EDGE_17_32  1.0
    RHS1      EDGE_24_80  1.0
    RHS1      EDGE_43_84  1.0
    RHS1      EDGE_16_76  1.0
    RHS1      EDGE_1_87  1.0
    RHS1      EDGE_36_54  1.0
    RHS1      EDGE_47_54  1.0
    RHS1      EDGE_65_90  1.0
    RHS1      EDGE_28_50  1.0
    RHS1      EDGE_57_86  1.0
    RHS1      EDGE_36_63  1.0
    RHS1      EDGE_9_46  1.0
    RHS1      EDGE_46_95  1.0
    RHS1      EDGE_47_72  1.0
    RHS1      EDGE_38_91  1.0
    RHS1      EDGE_57_104  1.0
    RHS1      EDGE_58_69  1.0
    RHS1      EDGE_68_104  1.0
    RHS1      EDGE_21_29  1.0
    RHS1      EDGE_50_65  1.0
    RHS1      EDGE_61_65  1.0
    RHS1      EDGE_9_73  1.0
    RHS1      EDGE_21_38  1.0
    RHS1      EDGE_61_74  1.0
    RHS1      EDGE_18_103  1.0
    RHS1      EDGE_29_51  1.0
    RHS1      EDGE_42_70  1.0
    RHS1      EDGE_77_100  1.0
    RHS1      EDGE_19_77  1.0
    RHS1      EDGE_2_6  1.0
    RHS1      EDGE_27_90  1.0
    RHS1      EDGE_39_55  1.0
    RHS1      EDGE_2_15  1.0
    RHS1      EDGE_0_82  1.0
    RHS1      EDGE_91_102  1.0
    RHS1      EDGE_31_60  1.0
    RHS1      EDGE_27_108  1.0
    RHS1      EDGE_19_104  1.0
    RHS1      EDGE_20_69  1.0
    RHS1      EDGE_94_107  1.0
    RHS1      EDGE_39_82  1.0
    RHS1      EDGE_23_65  1.0
    RHS1      EDGE_0_109  1.0
    RHS1      EDGE_39_91  1.0
    RHS1      EDGE_51_56  1.0
    RHS1      EDGE_31_87  1.0
    RHS1      EDGE_3_16  1.0
    RHS1      EDGE_43_52  1.0
    RHS1      EDGE_12_83  1.0
    RHS1      EDGE_51_65  1.0
    RHS1      EDGE_3_25  1.0
    RHS1      EDGE_12_92  1.0
    RHS1      EDGE_13_57  1.0
    RHS1      EDGE_4_88  1.0
    RHS1      EDGE_16_53  1.0
    RHS1      EDGE_43_70  1.0
    RHS1      EDGE_1_64  1.0
    RHS1      EDGE_35_66  1.0
    RHS1      EDGE_43_79  1.0
    RHS1      EDGE_36_40  1.0
    RHS1      EDGE_34_107  1.0
    RHS1      EDGE_17_36  1.0
    RHS1      EDGE_45_107  1.0
    RHS1      EDGE_47_49  1.0
    RHS1      EDGE_9_32  1.0
    RHS1      EDGE_28_45  1.0
    RHS1      EDGE_6_8  1.0
    RHS1      EDGE_46_81  1.0
    RHS1      EDGE_38_77  1.0
    RHS1      EDGE_57_90  1.0
    RHS1      EDGE_9_50  1.0
    RHS1      EDGE_46_99  1.0
    RHS1      EDGE_6_26  1.0
    RHS1      EDGE_9_59  1.0
    RHS1      EDGE_15_93  1.0
    RHS1      EDGE_5_70  1.0
    RHS1      EDGE_6_35  1.0
    RHS1      EDGE_46_108  1.0
    RHS1      EDGE_49_95  1.0
    RHS1      EDGE_57_108  1.0
    RHS1      EDGE_61_69  1.0
    RHS1      EDGE_69_73  1.0
    RHS1      EDGE_69_91  1.0
    RHS1      EDGE_61_87  1.0
    RHS1      EDGE_91_97  1.0
    RHS1      EDGE_30_90  1.0
    RHS1      EDGE_31_55  1.0
    RHS1      EDGE_27_103  1.0
    RHS1      EDGE_0_86  1.0
    RHS1      EDGE_54_57  1.0
    RHS1      EDGE_62_70  1.0
    RHS1      EDGE_30_108  1.0
    RHS1      EDGE_60_109  1.0
    RHS1      EDGE_11_104  1.0
    RHS1      EDGE_12_69  1.0
    RHS1      EDGE_20_82  1.0
    RHS1      EDGE_3_11  1.0
    RHS1      EDGE_31_82  1.0
    RHS1      EDGE_1_41  1.0
    RHS1      EDGE_43_56  1.0
    RHS1      EDGE_84_94  1.0
    RHS1      EDGE_87_90  1.0
    RHS1      EDGE_34_84  1.0
    RHS1      EDGE_45_84  1.0
    RHS1      EDGE_13_61  1.0
    RHS1      EDGE_53_97  1.0
    RHS1      EDGE_87_99  1.0
    RHS1      EDGE_56_93  1.0
    RHS1      EDGE_5_20  1.0
    RHS1      EDGE_17_22  1.0
    RHS1      EDGE_64_106  1.0
    RHS1      EDGE_65_71  1.0
    RHS1      EDGE_56_102  1.0
    RHS1      EDGE_17_31  1.0
    RHS1      EDGE_87_108  1.0
    RHS1      EDGE_88_91  1.0
    RHS1      EDGE_46_85  1.0
    RHS1      EDGE_6_12  1.0
    RHS1      EDGE_5_56  1.0
    RHS1      EDGE_57_94  1.0
    RHS1      EDGE_68_94  1.0
    RHS1      EDGE_49_90  1.0
    RHS1      EDGE_50_55  1.0
    RHS1      EDGE_46_103  1.0
    RHS1      EDGE_27_62  1.0
    RHS1      EDGE_50_64  1.0
    RHS1      EDGE_7_93  1.0
    RHS1      EDGE_61_64  1.0
    RHS1      EDGE_38_108  1.0
    RHS1      EDGE_49_108  1.0
    RHS1      EDGE_50_73  1.0
    RHS1      EDGE_69_77  1.0
    RHS1      EDGE_82_105  1.0
    RHS1      EDGE_27_80  1.0
    RHS1      EDGE_8_76  1.0
    RHS1      EDGE_42_78  1.0
    RHS1      EDGE_10_18  1.0
    RHS1      EDGE_2_14  1.0
    RHS1      EDGE_31_50  1.0
    RHS1      EDGE_11_81  1.0
    RHS1      EDGE_39_63  1.0
    RHS1      EDGE_31_59  1.0
    RHS1      EDGE_83_97  1.0
    RHS1      EDGE_11_90  1.0
    RHS1      EDGE_94_97  1.0
    RHS1      EDGE_94_106  1.0
    RHS1      EDGE_13_29  1.0
    RHS1      EDGE_20_77  1.0
    RHS1      EDGE_31_77  1.0
    RHS1      EDGE_12_73  1.0
    RHS1      EDGE_1_36  1.0
    RHS1      EDGE_51_55  1.0
    RHS1      EDGE_52_109  1.0
    RHS1      EDGE_53_74  1.0
    RHS1      EDGE_84_89  1.0
    RHS1      EDGE_1_45  1.0
    RHS1      EDGE_35_47  1.0
    RHS1      EDGE_53_83  1.0
    RHS1      EDGE_34_79  1.0
    RHS1      EDGE_64_83  1.0
    RHS1      EDGE_2_108  1.0
    RHS1      EDGE_35_56  1.0
    RHS1      EDGE_64_92  1.0
    RHS1      EDGE_22_86  1.0
    RHS1      EDGE_56_88  1.0
    RHS1      EDGE_1_63  1.0
    RHS1      EDGE_65_66  1.0
    RHS1      EDGE_9_13  1.0
    RHS1      EDGE_45_97  1.0
    RHS1      EDGE_56_97  1.0
    RHS1      EDGE_57_62  1.0
    RHS1      EDGE_3_91  1.0
    RHS1      EDGE_37_93  1.0
    RHS1      EDGE_22_104  1.0
    RHS1      EDGE_5_33  1.0
    RHS1      EDGE_28_35  1.0
    RHS1      EDGE_3_100  1.0
    RHS1      EDGE_9_31  1.0
    RHS1      EDGE_38_67  1.0
    RHS1      EDGE_57_71  1.0
    RHS1      EDGE_68_71  1.0
    RHS1      EDGE_68_80  1.0
    RHS1      EDGE_26_74  1.0
    RHS1      EDGE_76_84  1.0
    RHS1      EDGE_46_89  1.0
    RHS1      EDGE_15_92  1.0
    RHS1      EDGE_26_92  1.0
    RHS1      EDGE_27_57  1.0
    RHS1      EDGE_49_94  1.0
    RHS1      EDGE_8_53  1.0
    RHS1      EDGE_15_101  1.0
    RHS1      EDGE_61_68  1.0
    RHS1      EDGE_71_91  1.0
    RHS1      EDGE_79_95  1.0
    RHS1      EDGE_8_62  1.0
    RHS1      EDGE_19_62  1.0
    RHS1      EDGE_42_64  1.0
    RHS1      EDGE_31_36  1.0
    RHS1      EDGE_27_84  1.0
    RHS1      EDGE_29_103  1.0
    RHS1      EDGE_12_32  1.0
    RHS1      EDGE_30_80  1.0
    RHS1      EDGE_30_89  1.0
    RHS1      EDGE_21_108  1.0
    RHS1      EDGE_54_56  1.0
    RHS1      EDGE_83_92  1.0
    RHS1      EDGE_11_94  1.0
    RHS1      EDGE_13_24  1.0
    RHS1      EDGE_33_91  1.0
    RHS1      EDGE_44_91  1.0
    RHS1      EDGE_24_33  1.0
    RHS1      EDGE_53_69  1.0
    RHS1      EDGE_10_98  1.0
    RHS1      EDGE_24_42  1.0
    RHS1      EDGE_35_42  1.0
    RHS1      EDGE_44_109  1.0
    RHS1      EDGE_64_78  1.0
    RHS1      EDGE_64_87  1.0
    RHS1      EDGE_5_10  1.0
    RHS1      EDGE_53_96  1.0
    RHS1      EDGE_64_96  1.0
    RHS1      EDGE_38_44  1.0
    RHS1      EDGE_22_90  1.0
    RHS1      EDGE_5_19  1.0
    RHS1      EDGE_34_92  1.0
    RHS1      EDGE_37_88  1.0
    RHS1      EDGE_64_105  1.0
    RHS1      EDGE_65_70  1.0
    RHS1      EDGE_57_66  1.0
    RHS1      EDGE_86_102  1.0
    RHS1      EDGE_76_79  1.0
    RHS1      EDGE_9_26  1.0
    RHS1      EDGE_15_60  1.0
    RHS1      EDGE_22_108  1.0
    RHS1      EDGE_67_98  1.0
    RHS1      EDGE_37_106  1.0
    RHS1      EDGE_68_75  1.0
    RHS1      EDGE_78_107  1.0
    RHS1      EDGE_46_84  1.0
    RHS1      EDGE_68_84  1.0
    RHS1      EDGE_70_103  1.0
    RHS1      EDGE_38_80  1.0
    RHS1      EDGE_49_80  1.0
    RHS1      EDGE_7_74  1.0
    RHS1      EDGE_19_39  1.0
    RHS1      EDGE_26_87  1.0
    RHS1      EDGE_18_83  1.0
    RHS1      EDGE_8_48  1.0
    RHS1      EDGE_26_96  1.0
    RHS1      EDGE_71_86  1.0
    RHS1      EDGE_82_95  1.0
    RHS1      EDGE_63_91  1.0
    RHS1      EDGE_8_66  1.0
    RHS1      EDGE_12_27  1.0
    RHS1      EDGE_23_27  1.0
    RHS1      EDGE_41_72  1.0
    RHS1      EDGE_21_103  1.0
    RHS1      EDGE_4_32  1.0
    RHS1      EDGE_11_80  1.0
    RHS1      EDGE_41_81  1.0
    RHS1      EDGE_1_8  1.0
    RHS1      EDGE_20_58  1.0
    RHS1      EDGE_31_58  1.0
    RHS1      EDGE_33_77  1.0
    RHS1      EDGE_44_77  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_52_81  1.0
    RHS1      EDGE_94_105  1.0
    RHS1      EDGE_53_64  1.0
    RHS1      EDGE_10_93  1.0
    RHS1      EDGE_44_95  1.0
    RHS1      EDGE_56_69  1.0
    RHS1      EDGE_1_44  1.0
    RHS1      EDGE_37_65  1.0
    RHS1      EDGE_22_76  1.0
    RHS1      EDGE_53_91  1.0
    RHS1      EDGE_9_12  1.0
    RHS1      EDGE_5_23  1.0
    RHS1      EDGE_86_97  1.0
    RHS1      EDGE_5_32  1.0
    RHS1      EDGE_7_51  1.0
    RHS1      EDGE_46_70  1.0
    RHS1      EDGE_67_102  1.0
    RHS1      EDGE_68_70  1.0
    RHS1      EDGE_68_79  1.0
    RHS1      EDGE_27_38  1.0
    RHS1      EDGE_36_105  1.0
    RHS1      EDGE_26_82  1.0
    RHS1      EDGE_0_30  1.0
    RHS1      EDGE_7_78  1.0
    RHS1      EDGE_18_78  1.0
    RHS1      EDGE_11_39  1.0
    RHS1      EDGE_98_107  1.0
    RHS1      EDGE_48_88  1.0
    RHS1      EDGE_11_48  1.0
    RHS1      EDGE_8_61  1.0
    RHS1      EDGE_20_26  1.0
    RHS1      EDGE_82_99  1.0
    RHS1      EDGE_71_108  1.0
    RHS1      EDGE_0_66  1.0
    RHS1      EDGE_6_100  1.0
    RHS1      EDGE_52_67  1.0
    RHS1      EDGE_60_80  1.0
    RHS1      EDGE_63_104  1.0
    RHS1      EDGE_12_40  1.0
    RHS1      EDGE_41_76  1.0
    RHS1      EDGE_75_78  1.0
    RHS1      EDGE_44_72  1.0
    RHS1      EDGE_13_14  1.0
    RHS1      EDGE_4_45  1.0
    RHS1      EDGE_10_88  1.0
    RHS1      EDGE_33_90  1.0
    RHS1      EDGE_45_55  1.0
    RHS1      EDGE_72_81  1.0
    RHS1      EDGE_22_62  1.0
    RHS1      EDGE_22_71  1.0
    RHS1      EDGE_2_102  1.0
    RHS1      EDGE_45_82  1.0
    RHS1      EDGE_67_79  1.0
    RHS1      EDGE_46_56  1.0
    RHS1      EDGE_86_92  1.0
    RHS1      EDGE_9_16  1.0
    RHS1      EDGE_15_50  1.0
    RHS1      EDGE_49_52  1.0
    RHS1      EDGE_26_59  1.0
    RHS1      EDGE_18_55  1.0
    RHS1      EDGE_70_93  1.0
    RHS1      EDGE_15_68  1.0
    RHS1      EDGE_26_68  1.0
    RHS1      EDGE_18_64  1.0
    RHS1      EDGE_8_29  1.0
    RHS1      EDGE_47_100  1.0
    RHS1      EDGE_79_80  1.0
    RHS1      EDGE_19_38  1.0
    RHS1      EDGE_27_51  1.0
    RHS1      EDGE_28_105  1.0
    RHS1      EDGE_79_89  1.0
    RHS1      EDGE_30_47  1.0
    RHS1      EDGE_42_49  1.0
    RHS1      EDGE_48_83  1.0
    RHS1      EDGE_29_79  1.0
    RHS1      EDGE_82_85  1.0
    RHS1      EDGE_8_56  1.0
    RHS1      EDGE_20_21  1.0
    RHS1      EDGE_40_88  1.0
    RHS1      EDGE_41_53  1.0
    RHS1      EDGE_29_97  1.0
    RHS1      EDGE_41_62  1.0
    RHS1      EDGE_81_107  1.0
    RHS1      EDGE_104_109  1.0
    RHS1      EDGE_4_31  1.0
    RHS1      EDGE_52_80  1.0
    RHS1      EDGE_33_76  1.0
    RHS1      EDGE_53_54  1.0
    RHS1      EDGE_2_79  1.0
    RHS1      EDGE_16_23  1.0
    RHS1      EDGE_22_57  1.0
    RHS1      EDGE_56_59  1.0
    RHS1      EDGE_93_108  1.0
    RHS1      EDGE_56_68  1.0
    RHS1      EDGE_66_100  1.0
    RHS1      EDGE_56_77  1.0
    RHS1      EDGE_3_71  1.0
    RHS1      EDGE_37_73  1.0
    RHS1      EDGE_22_84  1.0
    RHS1      EDGE_46_51  1.0
    RHS1      EDGE_67_74  1.0
    RHS1      EDGE_38_47  1.0
    RHS1      EDGE_7_41  1.0
    RHS1      EDGE_3_89  1.0
    RHS1      EDGE_55_90  1.0
    RHS1      EDGE_97_105  1.0
    RHS1      EDGE_27_28  1.0
    RHS1      EDGE_70_97  1.0
    RHS1      EDGE_48_69  1.0
    RHS1      EDGE_79_84  1.0
    RHS1      EDGE_63_67  1.0
    RHS1      EDGE_19_42  1.0
    RHS1      EDGE_17_109  1.0
    RHS1      EDGE_29_74  1.0
    RHS1      EDGE_9_105  1.0
    RHS1      EDGE_6_81  1.0
    RHS1      EDGE_11_47  1.0
    RHS1      EDGE_48_96  1.0
    RHS1      EDGE_60_61  1.0
    RHS1      EDGE_60_70  1.0
    RHS1      EDGE_1_11  1.0
    RHS1      EDGE_44_80  1.0
    RHS1      EDGE_34_45  1.0
    RHS1      EDGE_53_58  1.0
    RHS1      EDGE_22_52  1.0
    RHS1      EDGE_45_54  1.0
    RHS1      EDGE_15_31  1.0
    RHS1      EDGE_7_27  1.0
    RHS1      EDGE_4_101  1.0
    RHS1      EDGE_18_27  1.0
    RHS1      EDGE_13_107  1.0
    RHS1      EDGE_36_72  1.0
    RHS1      EDGE_15_49  1.0
    RHS1      EDGE_55_85  1.0
    RHS1      EDGE_78_87  1.0
    RHS1      EDGE_15_58  1.0
    RHS1      EDGE_28_77  1.0
    RHS1      EDGE_78_96  1.0
    RHS1      EDGE_18_54  1.0
    RHS1      EDGE_36_90  1.0
    RHS1      EDGE_55_103  1.0
    RHS1      EDGE_27_32  1.0
    RHS1      EDGE_48_64  1.0
    RHS1      EDGE_28_95  1.0
    RHS1      EDGE_19_37  1.0
    RHS1      EDGE_30_37  1.0
    RHS1      EDGE_92_107  1.0
    RHS1      EDGE_82_84  1.0
    RHS1      EDGE_40_78  1.0
    RHS1      EDGE_29_87  1.0
    RHS1      EDGE_12_16  1.0
    RHS1      EDGE_60_65  1.0
    RHS1      EDGE_44_48  1.0
    RHS1      EDGE_40_96  1.0
    RHS1      EDGE_52_61  1.0
    RHS1      EDGE_25_44  1.0
    RHS1      EDGE_10_55  1.0
    RHS1      EDGE_6_103  1.0
    RHS1      EDGE_44_57  1.0
    RHS1      EDGE_2_51  1.0
    RHS1      EDGE_10_64  1.0
    RHS1      EDGE_44_66  1.0
    RHS1      EDGE_54_98  1.0
    RHS1      EDGE_22_38  1.0
    RHS1      EDGE_25_71  1.0
    RHS1      EDGE_34_49  1.0
    RHS1      EDGE_45_49  1.0
    RHS1      EDGE_25_80  1.0
    RHS1      EDGE_51_83  1.0
    RHS1      EDGE_32_88  1.0
    RHS1      EDGE_15_17  1.0
    RHS1      EDGE_22_65  1.0
    RHS1      EDGE_96_100  1.0
    RHS1      EDGE_7_22  1.0
    RHS1      EDGE_67_73  1.0
    RHS1      EDGE_96_109  1.0
    RHS1      EDGE_36_67  1.0
    RHS1      EDGE_1_109  1.0
    RHS1      EDGE_18_40  1.0
    RHS1      EDGE_67_91  1.0
    RHS1      EDGE_78_91  1.0
    RHS1      EDGE_7_49  1.0
    RHS1      EDGE_28_81  1.0
    RHS1      EDGE_70_96  1.0
    RHS1      EDGE_17_90  1.0
    RHS1      EDGE_11_19  1.0
    RHS1      EDGE_6_62  1.0
    RHS1      EDGE_40_64  1.0
    RHS1      EDGE_69_100  1.0
    RHS1      EDGE_63_75  1.0
    RHS1      EDGE_9_104  1.0
    RHS1      EDGE_21_69  1.0
    RHS1      EDGE_61_105  1.0
    RHS1      EDGE_40_82  1.0
    RHS1      EDGE_73_79  1.0
    RHS1      EDGE_6_89  1.0
    RHS1      EDGE_25_39  1.0
    RHS1      EDGE_10_50  1.0
    RHS1      EDGE_62_88  1.0
    RHS1      EDGE_41_65  1.0
    RHS1      EDGE_25_48  1.0
    RHS1      EDGE_10_59  1.0
    RHS1      EDGE_2_55  1.0
    RHS1      EDGE_54_93  1.0
    RHS1      EDGE_10_68  1.0
    RHS1      EDGE_22_33  1.0
    RHS1      EDGE_34_35  1.0
    RHS1      EDGE_54_102  1.0
    RHS1      EDGE_62_106  1.0
    RHS1      EDGE_12_96  1.0
    RHS1      EDGE_23_96  1.0
    RHS1      EDGE_51_78  1.0
    RHS1      EDGE_3_38  1.0
    RHS1      EDGE_2_82  1.0
    RHS1      EDGE_14_47  1.0
    RHS1      EDGE_13_79  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
 BV BND1      x_80
 BV BND1      x_81
 BV BND1      x_82
 BV BND1      x_83
 BV BND1      x_84
 BV BND1      x_85
 BV BND1      x_86
 BV BND1      x_87
 BV BND1      x_88
 BV BND1      x_89
 BV BND1      x_90
 BV BND1      x_91
 BV BND1      x_92
 BV BND1      x_93
 BV BND1      x_94
 BV BND1      x_95
 BV BND1      x_96
 BV BND1      x_97
 BV BND1      x_98
 BV BND1      x_99
 BV BND1      x_100
 BV BND1      x_101
 BV BND1      x_102
 BV BND1      x_103
 BV BND1      x_104
 BV BND1      x_105
 BV BND1      x_106
 BV BND1      x_107
 BV BND1      x_108
 BV BND1      x_109
ENDATA
