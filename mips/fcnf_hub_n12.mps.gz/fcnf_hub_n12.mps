NAME          fcnf_hub_n12
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
COLUMNS
    x_0         OBJ       7.22
    x_0         flow_2      1.0
    x_0         flow_0      -1.0
    x_0         link_0      1.0
    x_1         OBJ       5.11
    x_1         flow_0      1.0
    x_1         flow_2      -1.0
    x_1         link_1      1.0
    x_2         OBJ       4.61
    x_2         flow_3      1.0
    x_2         flow_0      -1.0
    x_2         link_2      1.0
    x_3         OBJ       1.21
    x_3         flow_0      1.0
    x_3         flow_3      -1.0
    x_3         link_3      1.0
    x_4         OBJ       6.78
    x_4         flow_4      1.0
    x_4         flow_0      -1.0
    x_4         link_4      1.0
    x_5         OBJ       4.84
    x_5         flow_0      1.0
    x_5         flow_4      -1.0
    x_5         link_5      1.0
    x_6         OBJ       7.78
    x_6         flow_5      1.0
    x_6         flow_0      -1.0
    x_6         link_6      1.0
    x_7         OBJ       3.79
    x_7         flow_0      1.0
    x_7         flow_5      -1.0
    x_7         link_7      1.0
    x_8         OBJ       2.09
    x_8         flow_6      1.0
    x_8         flow_0      -1.0
    x_8         link_8      1.0
    x_9         OBJ       4.22
    x_9         flow_0      1.0
    x_9         flow_6      -1.0
    x_9         link_9      1.0
    x_10        OBJ       1.77
    x_10        flow_7      1.0
    x_10        flow_0      -1.0
    x_10        link_10     1.0
    x_11        OBJ       4.11
    x_11        flow_0      1.0
    x_11        flow_7      -1.0
    x_11        link_11     1.0
    x_12        OBJ       1.75
    x_12        flow_8      1.0
    x_12        flow_0      -1.0
    x_12        link_12     1.0
    x_13        OBJ       5.26
    x_13        flow_0      1.0
    x_13        flow_8      -1.0
    x_13        link_13     1.0
    x_14        OBJ       2.29
    x_14        flow_9      1.0
    x_14        flow_0      -1.0
    x_14        link_14     1.0
    x_15        OBJ       6.8
    x_15        flow_0      1.0
    x_15        flow_9      -1.0
    x_15        link_15     1.0
    x_16        OBJ       6.02
    x_16        flow_10     1.0
    x_16        flow_0      -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.45
    x_17        flow_0      1.0
    x_17        flow_10     -1.0
    x_17        link_17     1.0
    x_18        OBJ       3.58
    x_18        flow_11     1.0
    x_18        flow_0      -1.0
    x_18        link_18     1.0
    x_19        OBJ       6.26
    x_19        flow_0      1.0
    x_19        flow_11     -1.0
    x_19        link_19     1.0
    x_20        OBJ       6.83
    x_20        flow_2      1.0
    x_20        flow_1      -1.0
    x_20        link_20     1.0
    x_21        OBJ       1.46
    x_21        flow_1      1.0
    x_21        flow_2      -1.0
    x_21        link_21     1.0
    x_22        OBJ       2.22
    x_22        flow_3      1.0
    x_22        flow_1      -1.0
    x_22        link_22     1.0
    x_23        OBJ       7.07
    x_23        flow_1      1.0
    x_23        flow_3      -1.0
    x_23        link_23     1.0
    x_24        OBJ       4.62
    x_24        flow_4      1.0
    x_24        flow_1      -1.0
    x_24        link_24     1.0
    x_25        OBJ       6.42
    x_25        flow_1      1.0
    x_25        flow_4      -1.0
    x_25        link_25     1.0
    x_26        OBJ       1.53
    x_26        flow_5      1.0
    x_26        flow_1      -1.0
    x_26        link_26     1.0
    x_27        OBJ       1.95
    x_27        flow_1      1.0
    x_27        flow_5      -1.0
    x_27        link_27     1.0
    x_28        OBJ       6.09
    x_28        flow_6      1.0
    x_28        flow_1      -1.0
    x_28        link_28     1.0
    x_29        OBJ       6.53
    x_29        flow_1      1.0
    x_29        flow_6      -1.0
    x_29        link_29     1.0
    x_30        OBJ       1.92
    x_30        flow_7      1.0
    x_30        flow_1      -1.0
    x_30        link_30     1.0
    x_31        OBJ       2.39
    x_31        flow_1      1.0
    x_31        flow_7      -1.0
    x_31        link_31     1.0
    x_32        OBJ       2.94
    x_32        flow_8      1.0
    x_32        flow_1      -1.0
    x_32        link_32     1.0
    x_33        OBJ       7.38
    x_33        flow_1      1.0
    x_33        flow_8      -1.0
    x_33        link_33     1.0
    x_34        OBJ       2.91
    x_34        flow_9      1.0
    x_34        flow_1      -1.0
    x_34        link_34     1.0
    x_35        OBJ       4.89
    x_35        flow_1      1.0
    x_35        flow_9      -1.0
    x_35        link_35     1.0
    x_36        OBJ       3.3
    x_36        flow_10     1.0
    x_36        flow_1      -1.0
    x_36        link_36     1.0
    x_37        OBJ       2.91
    x_37        flow_1      1.0
    x_37        flow_10     -1.0
    x_37        link_37     1.0
    x_38        OBJ       4.43
    x_38        flow_11     1.0
    x_38        flow_1      -1.0
    x_38        link_38     1.0
    x_39        OBJ       3.06
    x_39        flow_1      1.0
    x_39        flow_11     -1.0
    x_39        link_39     1.0
    x_40        OBJ       6.94
    x_40        flow_0      1.0
    x_40        flow_1      -1.0
    x_40        link_40     1.0
    x_41        OBJ       5.19
    x_41        flow_1      1.0
    x_41        flow_0      -1.0
    x_41        link_41     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       15.0
    y_0         link_0      -57.0
    y_1         OBJ       27.19
    y_1         link_1      -60.0
    y_2         OBJ       19.59
    y_2         link_2      -22.0
    y_3         OBJ       24.58
    y_3         link_3      -60.0
    y_4         OBJ       26.08
    y_4         link_4      -28.0
    y_5         OBJ       12.38
    y_5         link_5      -41.0
    y_6         OBJ       28.36
    y_6         link_6      -25.0
    y_7         OBJ       22.63
    y_7         link_7      -43.0
    y_8         OBJ       16.64
    y_8         link_8      -24.0
    y_9         OBJ       22.41
    y_9         link_9      -59.0
    y_10        OBJ       10.66
    y_10        link_10     -52.0
    y_11        OBJ       22.91
    y_11        link_11     -29.0
    y_12        OBJ       13.87
    y_12        link_12     -24.0
    y_13        OBJ       16.51
    y_13        link_13     -45.0
    y_14        OBJ       12.54
    y_14        link_14     -33.0
    y_15        OBJ       19.58
    y_15        link_15     -59.0
    y_16        OBJ       22.63
    y_16        link_16     -40.0
    y_17        OBJ       12.1
    y_17        link_17     -27.0
    y_18        OBJ       9.57
    y_18        link_18     -53.0
    y_19        OBJ       19.22
    y_19        link_19     -57.0
    y_20        OBJ       23.0
    y_20        link_20     -32.0
    y_21        OBJ       7.52
    y_21        link_21     -41.0
    y_22        OBJ       5.03
    y_22        link_22     -31.0
    y_23        OBJ       15.1
    y_23        link_23     -21.0
    y_24        OBJ       23.22
    y_24        link_24     -32.0
    y_25        OBJ       14.14
    y_25        link_25     -25.0
    y_26        OBJ       16.02
    y_26        link_26     -31.0
    y_27        OBJ       14.53
    y_27        link_27     -37.0
    y_28        OBJ       16.77
    y_28        link_28     -29.0
    y_29        OBJ       21.45
    y_29        link_29     -44.0
    y_30        OBJ       6.03
    y_30        link_30     -23.0
    y_31        OBJ       8.03
    y_31        link_31     -40.0
    y_32        OBJ       20.35
    y_32        link_32     -52.0
    y_33        OBJ       6.43
    y_33        link_33     -35.0
    y_34        OBJ       17.39
    y_34        link_34     -38.0
    y_35        OBJ       11.03
    y_35        link_35     -59.0
    y_36        OBJ       27.35
    y_36        link_36     -45.0
    y_37        OBJ       6.42
    y_37        link_37     -53.0
    y_38        OBJ       6.53
    y_38        link_38     -41.0
    y_39        OBJ       15.92
    y_39        link_39     -20.0
    y_40        OBJ       6.87
    y_40        link_40     -58.0
    y_41        OBJ       10.17
    y_41        link_41     -43.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_2      6
    RHS       flow_3      4
    RHS       flow_4      4
    RHS       flow_5      4
    RHS       flow_6      4
    RHS       flow_7      4
    RHS       flow_8      4
    RHS       flow_9      4
    RHS       flow_10     4
    RHS       flow_11     -38
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
ENDATA
