NAME          sppc_small_2
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 G  COVER_0
 G  COVER_1
 G  COVER_2
 G  COVER_3
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0             OBJ           27
    x_0             PART_0          1.0
    x_0             COVER_0         1.0
    x_0             COVER_2         1.0
    x_0             COVER_3         1.0
    x_1             OBJ           20
    x_1             PART_0          1.0
    x_1             PACK_0          1.0
    x_1             PACK_1          1.0
    x_1             PACK_2          1.0
    x_1             PACK_3          1.0
    x_1             PACK_4          1.0
    x_1             PACK_5          1.0
    x_1             COVER_1         1.0
    x_2             OBJ           29
    x_2             PART_1          1.0
    x_2             COVER_0         1.0
    x_2             COVER_1         1.0
    x_2             COVER_2         1.0
    x_3             OBJ           13
    x_3             PART_1          1.0
    x_3             PACK_0          1.0
    x_3             PACK_1          1.0
    x_3             PACK_2          1.0
    x_3             PACK_3          1.0
    x_3             PACK_4          1.0
    x_3             PACK_5          1.0
    x_3             COVER_2         1.0
    x_4             OBJ           29
    x_4             PART_2          1.0
    x_4             COVER_0         1.0
    x_4             COVER_2         1.0
    x_5             OBJ           22
    x_5             PART_2          1.0
    x_5             PACK_0          1.0
    x_5             PACK_1          1.0
    x_5             PACK_2          1.0
    x_5             PACK_3          1.0
    x_5             PACK_4          1.0
    x_5             PACK_5          1.0
    x_5             COVER_1         1.0
    x_5             COVER_2         1.0
    x_5             COVER_3         1.0
    x_6             OBJ           9
    x_6             PART_3          1.0
    x_6             PACK_0          1.0
    x_6             PACK_4          1.0
    x_6             PACK_5          1.0
    x_6             COVER_0         1.0
    x_6             COVER_1         1.0
    x_6             COVER_2         1.0
    x_7             OBJ           25
    x_7             PART_3          1.0
    x_7             COVER_0         1.0
    x_7             COVER_1         1.0
    x_8             OBJ           9
    x_8             PART_3          1.0
    x_8             PACK_1          1.0
    x_8             PACK_2          1.0
    x_8             PACK_3          1.0
    x_8             COVER_1         1.0
    x_8             COVER_3         1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           PART_0          1.0
    RHS           PART_1          1.0
    RHS           PART_2          1.0
    RHS           PART_3          1.0
    RHS           PACK_0          1.0
    RHS           PACK_1          1.0
    RHS           PACK_2          1.0
    RHS           PACK_3          1.0
    RHS           PACK_4          1.0
    RHS           PACK_5          1.0
    RHS           COVER_0         1.0
    RHS           COVER_1         1.0
    RHS           COVER_2         1.0
    RHS           COVER_3         1.0
BOUNDS
 BV BOUND         x_0
 BV BOUND         x_1
 BV BOUND         x_2
 BV BOUND         x_3
 BV BOUND         x_4
 BV BOUND         x_5
 BV BOUND         x_6
 BV BOUND         x_7
 BV BOUND         x_8
ENDATA
