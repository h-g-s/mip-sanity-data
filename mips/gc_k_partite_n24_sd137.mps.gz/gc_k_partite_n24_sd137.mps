NAME          gc_k_partite_n24_sd137
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 E  ASSIGN_11
 E  ASSIGN_12
 E  ASSIGN_13
 E  ASSIGN_14
 E  ASSIGN_15
 E  ASSIGN_16
 E  ASSIGN_17
 E  ASSIGN_18
 E  ASSIGN_19
 E  ASSIGN_20
 E  ASSIGN_21
 E  ASSIGN_22
 E  ASSIGN_23
 L  LINK_1_0
 L  LINK_2_0
 L  LINK_2_1
 L  LINK_3_0
 L  LINK_3_1
 L  LINK_3_2
 L  LINK_4_0
 L  LINK_4_1
 L  LINK_4_2
 L  LINK_4_3
 L  LINK_5_0
 L  LINK_5_1
 L  LINK_5_2
 L  LINK_5_3
 L  LINK_5_4
 L  LINK_6_0
 L  LINK_6_1
 L  LINK_6_2
 L  LINK_6_3
 L  LINK_6_4
 L  LINK_6_5
 L  LINK_7_0
 L  LINK_7_1
 L  LINK_7_2
 L  LINK_7_3
 L  LINK_7_4
 L  LINK_7_5
 L  LINK_7_6
 L  LINK_8_0
 L  LINK_8_1
 L  LINK_8_2
 L  LINK_8_3
 L  LINK_8_4
 L  LINK_8_5
 L  LINK_8_6
 L  LINK_8_7
 L  LINK_9_0
 L  LINK_9_1
 L  LINK_9_2
 L  LINK_9_3
 L  LINK_9_4
 L  LINK_9_5
 L  LINK_9_6
 L  LINK_9_7
 L  LINK_9_8
 L  LINK_10_0
 L  LINK_10_1
 L  LINK_10_2
 L  LINK_10_3
 L  LINK_10_4
 L  LINK_10_5
 L  LINK_10_6
 L  LINK_10_7
 L  LINK_10_8
 L  LINK_10_9
 L  LINK_11_0
 L  LINK_11_1
 L  LINK_11_2
 L  LINK_11_3
 L  LINK_11_4
 L  LINK_11_5
 L  LINK_11_6
 L  LINK_11_7
 L  LINK_11_8
 L  LINK_11_9
 L  LINK_11_10
 L  LINK_12_0
 L  LINK_12_1
 L  LINK_12_2
 L  LINK_12_3
 L  LINK_12_4
 L  LINK_12_5
 L  LINK_12_6
 L  LINK_12_7
 L  LINK_12_8
 L  LINK_12_9
 L  LINK_12_10
 L  LINK_12_11
 L  LINK_13_0
 L  LINK_13_1
 L  LINK_13_2
 L  LINK_13_3
 L  LINK_13_4
 L  LINK_13_5
 L  LINK_13_6
 L  LINK_13_7
 L  LINK_13_8
 L  LINK_13_9
 L  LINK_13_10
 L  LINK_13_11
 L  LINK_13_12
 L  LINK_14_0
 L  LINK_14_1
 L  LINK_14_2
 L  LINK_14_3
 L  LINK_14_4
 L  LINK_14_5
 L  LINK_14_6
 L  LINK_14_7
 L  LINK_14_8
 L  LINK_14_9
 L  LINK_14_10
 L  LINK_14_11
 L  LINK_14_12
 L  LINK_14_13
 L  LINK_15_0
 L  LINK_15_1
 L  LINK_15_2
 L  LINK_15_3
 L  LINK_15_4
 L  LINK_15_5
 L  LINK_15_6
 L  LINK_15_7
 L  LINK_15_8
 L  LINK_15_9
 L  LINK_15_10
 L  LINK_15_11
 L  LINK_15_12
 L  LINK_15_13
 L  LINK_15_14
 L  LINK_16_0
 L  LINK_16_1
 L  LINK_16_2
 L  LINK_16_3
 L  LINK_16_4
 L  LINK_16_5
 L  LINK_16_6
 L  LINK_16_7
 L  LINK_16_8
 L  LINK_16_9
 L  LINK_16_10
 L  LINK_16_11
 L  LINK_16_12
 L  LINK_16_13
 L  LINK_16_14
 L  LINK_16_15
 L  LINK_17_0
 L  LINK_17_1
 L  LINK_17_2
 L  LINK_17_3
 L  LINK_17_4
 L  LINK_17_5
 L  LINK_17_6
 L  LINK_17_7
 L  LINK_17_8
 L  LINK_17_9
 L  LINK_17_10
 L  LINK_17_11
 L  LINK_17_12
 L  LINK_17_13
 L  LINK_17_14
 L  LINK_17_15
 L  LINK_17_16
 L  LINK_18_0
 L  LINK_18_1
 L  LINK_18_2
 L  LINK_18_3
 L  LINK_18_4
 L  LINK_18_5
 L  LINK_18_6
 L  LINK_18_7
 L  LINK_18_8
 L  LINK_18_9
 L  LINK_18_10
 L  LINK_18_11
 L  LINK_18_12
 L  LINK_18_13
 L  LINK_18_14
 L  LINK_18_15
 L  LINK_18_16
 L  LINK_18_17
 L  LINK_19_0
 L  LINK_19_1
 L  LINK_19_2
 L  LINK_19_3
 L  LINK_19_4
 L  LINK_19_5
 L  LINK_19_6
 L  LINK_19_7
 L  LINK_19_8
 L  LINK_19_9
 L  LINK_19_10
 L  LINK_19_11
 L  LINK_19_12
 L  LINK_19_13
 L  LINK_19_14
 L  LINK_19_15
 L  LINK_19_16
 L  LINK_19_17
 L  LINK_19_18
 L  LINK_20_0
 L  LINK_20_1
 L  LINK_20_2
 L  LINK_20_3
 L  LINK_20_4
 L  LINK_20_5
 L  LINK_20_6
 L  LINK_20_7
 L  LINK_20_8
 L  LINK_20_9
 L  LINK_20_10
 L  LINK_20_11
 L  LINK_20_12
 L  LINK_20_13
 L  LINK_20_14
 L  LINK_20_15
 L  LINK_20_16
 L  LINK_20_17
 L  LINK_20_18
 L  LINK_20_19
 L  LINK_21_0
 L  LINK_21_1
 L  LINK_21_2
 L  LINK_21_3
 L  LINK_21_4
 L  LINK_21_5
 L  LINK_21_6
 L  LINK_21_7
 L  LINK_21_8
 L  LINK_21_9
 L  LINK_21_10
 L  LINK_21_11
 L  LINK_21_12
 L  LINK_21_13
 L  LINK_21_14
 L  LINK_21_15
 L  LINK_21_16
 L  LINK_21_17
 L  LINK_21_18
 L  LINK_21_19
 L  LINK_21_20
 L  LINK_22_0
 L  LINK_22_1
 L  LINK_22_2
 L  LINK_22_3
 L  LINK_22_4
 L  LINK_22_5
 L  LINK_22_6
 L  LINK_22_7
 L  LINK_22_8
 L  LINK_22_9
 L  LINK_22_10
 L  LINK_22_11
 L  LINK_22_12
 L  LINK_22_13
 L  LINK_22_14
 L  LINK_22_15
 L  LINK_22_16
 L  LINK_22_17
 L  LINK_22_18
 L  LINK_22_19
 L  LINK_22_20
 L  LINK_22_21
 L  LINK_23_0
 L  LINK_23_1
 L  LINK_23_2
 L  LINK_23_3
 L  LINK_23_4
 L  LINK_23_5
 L  LINK_23_6
 L  LINK_23_7
 L  LINK_23_8
 L  LINK_23_9
 L  LINK_23_10
 L  LINK_23_11
 L  LINK_23_12
 L  LINK_23_13
 L  LINK_23_14
 L  LINK_23_15
 L  LINK_23_16
 L  LINK_23_17
 L  LINK_23_18
 L  LINK_23_19
 L  LINK_23_20
 L  LINK_23_21
 L  LINK_23_22
 L  EDGE_0_1_0
 L  EDGE_0_2_0
 L  EDGE_0_3_0
 L  EDGE_0_4_0
 L  EDGE_0_6_0
 L  EDGE_0_7_0
 L  EDGE_0_12_0
 L  EDGE_0_13_0
 L  EDGE_0_14_0
 L  EDGE_0_18_0
 L  EDGE_0_20_0
 L  EDGE_0_21_0
 L  EDGE_0_22_0
 L  EDGE_1_4_0
 L  EDGE_1_4_1
 L  EDGE_1_5_0
 L  EDGE_1_5_1
 L  EDGE_1_6_0
 L  EDGE_1_6_1
 L  EDGE_1_7_0
 L  EDGE_1_7_1
 L  EDGE_1_8_0
 L  EDGE_1_8_1
 L  EDGE_1_9_0
 L  EDGE_1_9_1
 L  EDGE_1_10_0
 L  EDGE_1_10_1
 L  EDGE_1_15_0
 L  EDGE_1_15_1
 L  EDGE_1_16_0
 L  EDGE_1_16_1
 L  EDGE_1_18_0
 L  EDGE_1_18_1
 L  EDGE_1_21_0
 L  EDGE_1_21_1
 L  EDGE_2_3_0
 L  EDGE_2_3_1
 L  EDGE_2_3_2
 L  EDGE_2_4_0
 L  EDGE_2_4_1
 L  EDGE_2_4_2
 L  EDGE_2_5_0
 L  EDGE_2_5_1
 L  EDGE_2_5_2
 L  EDGE_2_6_0
 L  EDGE_2_6_1
 L  EDGE_2_6_2
 L  EDGE_2_8_0
 L  EDGE_2_8_1
 L  EDGE_2_8_2
 L  EDGE_2_9_0
 L  EDGE_2_9_1
 L  EDGE_2_9_2
 L  EDGE_2_10_0
 L  EDGE_2_10_1
 L  EDGE_2_10_2
 L  EDGE_2_15_0
 L  EDGE_2_15_1
 L  EDGE_2_15_2
 L  EDGE_2_16_0
 L  EDGE_2_16_1
 L  EDGE_2_16_2
 L  EDGE_2_18_0
 L  EDGE_2_18_1
 L  EDGE_2_18_2
 L  EDGE_2_19_0
 L  EDGE_2_19_1
 L  EDGE_2_19_2
 L  EDGE_3_5_0
 L  EDGE_3_5_1
 L  EDGE_3_5_2
 L  EDGE_3_5_3
 L  EDGE_3_9_0
 L  EDGE_3_9_1
 L  EDGE_3_9_2
 L  EDGE_3_9_3
 L  EDGE_3_10_0
 L  EDGE_3_10_1
 L  EDGE_3_10_2
 L  EDGE_3_10_3
 L  EDGE_3_12_0
 L  EDGE_3_12_1
 L  EDGE_3_12_2
 L  EDGE_3_12_3
 L  EDGE_3_13_0
 L  EDGE_3_13_1
 L  EDGE_3_13_2
 L  EDGE_3_13_3
 L  EDGE_3_14_0
 L  EDGE_3_14_1
 L  EDGE_3_14_2
 L  EDGE_3_14_3
 L  EDGE_3_15_0
 L  EDGE_3_15_1
 L  EDGE_3_15_2
 L  EDGE_3_15_3
 L  EDGE_3_20_0
 L  EDGE_3_20_1
 L  EDGE_3_20_2
 L  EDGE_3_20_3
 L  EDGE_3_22_0
 L  EDGE_3_22_1
 L  EDGE_3_22_2
 L  EDGE_3_22_3
 L  EDGE_4_5_0
 L  EDGE_4_5_1
 L  EDGE_4_5_2
 L  EDGE_4_5_3
 L  EDGE_4_5_4
 L  EDGE_4_8_0
 L  EDGE_4_8_1
 L  EDGE_4_8_2
 L  EDGE_4_8_3
 L  EDGE_4_8_4
 L  EDGE_4_9_0
 L  EDGE_4_9_1
 L  EDGE_4_9_2
 L  EDGE_4_9_3
 L  EDGE_4_9_4
 L  EDGE_4_10_0
 L  EDGE_4_10_1
 L  EDGE_4_10_2
 L  EDGE_4_10_3
 L  EDGE_4_10_4
 L  EDGE_4_13_0
 L  EDGE_4_13_1
 L  EDGE_4_13_2
 L  EDGE_4_13_3
 L  EDGE_4_13_4
 L  EDGE_4_19_0
 L  EDGE_4_19_1
 L  EDGE_4_19_2
 L  EDGE_4_19_3
 L  EDGE_4_19_4
 L  EDGE_4_20_0
 L  EDGE_4_20_1
 L  EDGE_4_20_2
 L  EDGE_4_20_3
 L  EDGE_4_20_4
 L  EDGE_4_22_0
 L  EDGE_4_22_1
 L  EDGE_4_22_2
 L  EDGE_4_22_3
 L  EDGE_4_22_4
 L  EDGE_5_7_0
 L  EDGE_5_7_1
 L  EDGE_5_7_2
 L  EDGE_5_7_3
 L  EDGE_5_7_4
 L  EDGE_5_7_5
 L  EDGE_5_11_0
 L  EDGE_5_11_1
 L  EDGE_5_11_2
 L  EDGE_5_11_3
 L  EDGE_5_11_4
 L  EDGE_5_11_5
 L  EDGE_5_13_0
 L  EDGE_5_13_1
 L  EDGE_5_13_2
 L  EDGE_5_13_3
 L  EDGE_5_13_4
 L  EDGE_5_13_5
 L  EDGE_5_14_0
 L  EDGE_5_14_1
 L  EDGE_5_14_2
 L  EDGE_5_14_3
 L  EDGE_5_14_4
 L  EDGE_5_14_5
 L  EDGE_5_18_0
 L  EDGE_5_18_1
 L  EDGE_5_18_2
 L  EDGE_5_18_3
 L  EDGE_5_18_4
 L  EDGE_5_18_5
 L  EDGE_5_20_0
 L  EDGE_5_20_1
 L  EDGE_5_20_2
 L  EDGE_5_20_3
 L  EDGE_5_20_4
 L  EDGE_5_20_5
 L  EDGE_5_21_0
 L  EDGE_5_21_1
 L  EDGE_5_21_2
 L  EDGE_5_21_3
 L  EDGE_5_21_4
 L  EDGE_5_21_5
 L  EDGE_6_11_0
 L  EDGE_6_11_1
 L  EDGE_6_11_2
 L  EDGE_6_11_3
 L  EDGE_6_11_4
 L  EDGE_6_11_5
 L  EDGE_6_11_6
 L  EDGE_6_12_0
 L  EDGE_6_12_1
 L  EDGE_6_12_2
 L  EDGE_6_12_3
 L  EDGE_6_12_4
 L  EDGE_6_12_5
 L  EDGE_6_12_6
 L  EDGE_6_13_0
 L  EDGE_6_13_1
 L  EDGE_6_13_2
 L  EDGE_6_13_3
 L  EDGE_6_13_4
 L  EDGE_6_13_5
 L  EDGE_6_13_6
 L  EDGE_6_14_0
 L  EDGE_6_14_1
 L  EDGE_6_14_2
 L  EDGE_6_14_3
 L  EDGE_6_14_4
 L  EDGE_6_14_5
 L  EDGE_6_14_6
 L  EDGE_6_15_0
 L  EDGE_6_15_1
 L  EDGE_6_15_2
 L  EDGE_6_15_3
 L  EDGE_6_15_4
 L  EDGE_6_15_5
 L  EDGE_6_15_6
 L  EDGE_6_20_0
 L  EDGE_6_20_1
 L  EDGE_6_20_2
 L  EDGE_6_20_3
 L  EDGE_6_20_4
 L  EDGE_6_20_5
 L  EDGE_6_20_6
 L  EDGE_6_22_0
 L  EDGE_6_22_1
 L  EDGE_6_22_2
 L  EDGE_6_22_3
 L  EDGE_6_22_4
 L  EDGE_6_22_5
 L  EDGE_6_22_6
 L  EDGE_7_10_0
 L  EDGE_7_10_1
 L  EDGE_7_10_2
 L  EDGE_7_10_3
 L  EDGE_7_10_4
 L  EDGE_7_10_5
 L  EDGE_7_10_6
 L  EDGE_7_10_7
 L  EDGE_7_11_0
 L  EDGE_7_11_1
 L  EDGE_7_11_2
 L  EDGE_7_11_3
 L  EDGE_7_11_4
 L  EDGE_7_11_5
 L  EDGE_7_11_6
 L  EDGE_7_11_7
 L  EDGE_7_12_0
 L  EDGE_7_12_1
 L  EDGE_7_12_2
 L  EDGE_7_12_3
 L  EDGE_7_12_4
 L  EDGE_7_12_5
 L  EDGE_7_12_6
 L  EDGE_7_12_7
 L  EDGE_7_13_0
 L  EDGE_7_13_1
 L  EDGE_7_13_2
 L  EDGE_7_13_3
 L  EDGE_7_13_4
 L  EDGE_7_13_5
 L  EDGE_7_13_6
 L  EDGE_7_13_7
 L  EDGE_7_15_0
 L  EDGE_7_15_1
 L  EDGE_7_15_2
 L  EDGE_7_15_3
 L  EDGE_7_15_4
 L  EDGE_7_15_5
 L  EDGE_7_15_6
 L  EDGE_7_15_7
 L  EDGE_7_16_0
 L  EDGE_7_16_1
 L  EDGE_7_16_2
 L  EDGE_7_16_3
 L  EDGE_7_16_4
 L  EDGE_7_16_5
 L  EDGE_7_16_6
 L  EDGE_7_16_7
 L  EDGE_7_19_0
 L  EDGE_7_19_1
 L  EDGE_7_19_2
 L  EDGE_7_19_3
 L  EDGE_7_19_4
 L  EDGE_7_19_5
 L  EDGE_7_19_6
 L  EDGE_7_19_7
 L  EDGE_8_11_0
 L  EDGE_8_11_1
 L  EDGE_8_11_2
 L  EDGE_8_11_3
 L  EDGE_8_11_4
 L  EDGE_8_11_5
 L  EDGE_8_11_6
 L  EDGE_8_11_7
 L  EDGE_8_11_8
 L  EDGE_8_13_0
 L  EDGE_8_13_1
 L  EDGE_8_13_2
 L  EDGE_8_13_3
 L  EDGE_8_13_4
 L  EDGE_8_13_5
 L  EDGE_8_13_6
 L  EDGE_8_13_7
 L  EDGE_8_13_8
 L  EDGE_8_14_0
 L  EDGE_8_14_1
 L  EDGE_8_14_2
 L  EDGE_8_14_3
 L  EDGE_8_14_4
 L  EDGE_8_14_5
 L  EDGE_8_14_6
 L  EDGE_8_14_7
 L  EDGE_8_14_8
 L  EDGE_8_17_0
 L  EDGE_8_17_1
 L  EDGE_8_17_2
 L  EDGE_8_17_3
 L  EDGE_8_17_4
 L  EDGE_8_17_5
 L  EDGE_8_17_6
 L  EDGE_8_17_7
 L  EDGE_8_17_8
 L  EDGE_8_20_0
 L  EDGE_8_20_1
 L  EDGE_8_20_2
 L  EDGE_8_20_3
 L  EDGE_8_20_4
 L  EDGE_8_20_5
 L  EDGE_8_20_6
 L  EDGE_8_20_7
 L  EDGE_8_20_8
 L  EDGE_8_21_0
 L  EDGE_8_21_1
 L  EDGE_8_21_2
 L  EDGE_8_21_3
 L  EDGE_8_21_4
 L  EDGE_8_21_5
 L  EDGE_8_21_6
 L  EDGE_8_21_7
 L  EDGE_8_21_8
 L  EDGE_8_23_0
 L  EDGE_8_23_1
 L  EDGE_8_23_2
 L  EDGE_8_23_3
 L  EDGE_8_23_4
 L  EDGE_8_23_5
 L  EDGE_8_23_6
 L  EDGE_8_23_7
 L  EDGE_8_23_8
 L  EDGE_9_11_0
 L  EDGE_9_11_1
 L  EDGE_9_11_2
 L  EDGE_9_11_3
 L  EDGE_9_11_4
 L  EDGE_9_11_5
 L  EDGE_9_11_6
 L  EDGE_9_11_7
 L  EDGE_9_11_8
 L  EDGE_9_11_9
 L  EDGE_9_12_0
 L  EDGE_9_12_1
 L  EDGE_9_12_2
 L  EDGE_9_12_3
 L  EDGE_9_12_4
 L  EDGE_9_12_5
 L  EDGE_9_12_6
 L  EDGE_9_12_7
 L  EDGE_9_12_8
 L  EDGE_9_12_9
 L  EDGE_9_14_0
 L  EDGE_9_14_1
 L  EDGE_9_14_2
 L  EDGE_9_14_3
 L  EDGE_9_14_4
 L  EDGE_9_14_5
 L  EDGE_9_14_6
 L  EDGE_9_14_7
 L  EDGE_9_14_8
 L  EDGE_9_14_9
 L  EDGE_9_17_0
 L  EDGE_9_17_1
 L  EDGE_9_17_2
 L  EDGE_9_17_3
 L  EDGE_9_17_4
 L  EDGE_9_17_5
 L  EDGE_9_17_6
 L  EDGE_9_17_7
 L  EDGE_9_17_8
 L  EDGE_9_17_9
 L  EDGE_9_20_0
 L  EDGE_9_20_1
 L  EDGE_9_20_2
 L  EDGE_9_20_3
 L  EDGE_9_20_4
 L  EDGE_9_20_5
 L  EDGE_9_20_6
 L  EDGE_9_20_7
 L  EDGE_9_20_8
 L  EDGE_9_20_9
 L  EDGE_9_23_0
 L  EDGE_9_23_1
 L  EDGE_9_23_2
 L  EDGE_9_23_3
 L  EDGE_9_23_4
 L  EDGE_9_23_5
 L  EDGE_9_23_6
 L  EDGE_9_23_7
 L  EDGE_9_23_8
 L  EDGE_9_23_9
 L  EDGE_10_11_0
 L  EDGE_10_11_1
 L  EDGE_10_11_2
 L  EDGE_10_11_3
 L  EDGE_10_11_4
 L  EDGE_10_11_5
 L  EDGE_10_11_6
 L  EDGE_10_11_7
 L  EDGE_10_11_8
 L  EDGE_10_11_9
 L  EDGE_10_11_10
 L  EDGE_10_14_0
 L  EDGE_10_14_1
 L  EDGE_10_14_2
 L  EDGE_10_14_3
 L  EDGE_10_14_4
 L  EDGE_10_14_5
 L  EDGE_10_14_6
 L  EDGE_10_14_7
 L  EDGE_10_14_8
 L  EDGE_10_14_9
 L  EDGE_10_14_10
 L  EDGE_10_17_0
 L  EDGE_10_17_1
 L  EDGE_10_17_2
 L  EDGE_10_17_3
 L  EDGE_10_17_4
 L  EDGE_10_17_5
 L  EDGE_10_17_6
 L  EDGE_10_17_7
 L  EDGE_10_17_8
 L  EDGE_10_17_9
 L  EDGE_10_17_10
 L  EDGE_10_20_0
 L  EDGE_10_20_1
 L  EDGE_10_20_2
 L  EDGE_10_20_3
 L  EDGE_10_20_4
 L  EDGE_10_20_5
 L  EDGE_10_20_6
 L  EDGE_10_20_7
 L  EDGE_10_20_8
 L  EDGE_10_20_9
 L  EDGE_10_20_10
 L  EDGE_10_23_0
 L  EDGE_10_23_1
 L  EDGE_10_23_2
 L  EDGE_10_23_3
 L  EDGE_10_23_4
 L  EDGE_10_23_5
 L  EDGE_10_23_6
 L  EDGE_10_23_7
 L  EDGE_10_23_8
 L  EDGE_10_23_9
 L  EDGE_10_23_10
 L  EDGE_11_15_0
 L  EDGE_11_15_1
 L  EDGE_11_15_2
 L  EDGE_11_15_3
 L  EDGE_11_15_4
 L  EDGE_11_15_5
 L  EDGE_11_15_6
 L  EDGE_11_15_7
 L  EDGE_11_15_8
 L  EDGE_11_15_9
 L  EDGE_11_15_10
 L  EDGE_11_15_11
 L  EDGE_11_16_0
 L  EDGE_11_16_1
 L  EDGE_11_16_2
 L  EDGE_11_16_3
 L  EDGE_11_16_4
 L  EDGE_11_16_5
 L  EDGE_11_16_6
 L  EDGE_11_16_7
 L  EDGE_11_16_8
 L  EDGE_11_16_9
 L  EDGE_11_16_10
 L  EDGE_11_16_11
 L  EDGE_11_17_0
 L  EDGE_11_17_1
 L  EDGE_11_17_2
 L  EDGE_11_17_3
 L  EDGE_11_17_4
 L  EDGE_11_17_5
 L  EDGE_11_17_6
 L  EDGE_11_17_7
 L  EDGE_11_17_8
 L  EDGE_11_17_9
 L  EDGE_11_17_10
 L  EDGE_11_17_11
 L  EDGE_11_19_0
 L  EDGE_11_19_1
 L  EDGE_11_19_2
 L  EDGE_11_19_3
 L  EDGE_11_19_4
 L  EDGE_11_19_5
 L  EDGE_11_19_6
 L  EDGE_11_19_7
 L  EDGE_11_19_8
 L  EDGE_11_19_9
 L  EDGE_11_19_10
 L  EDGE_11_19_11
 L  EDGE_12_15_0
 L  EDGE_12_15_1
 L  EDGE_12_15_2
 L  EDGE_12_15_3
 L  EDGE_12_15_4
 L  EDGE_12_15_5
 L  EDGE_12_15_6
 L  EDGE_12_15_7
 L  EDGE_12_15_8
 L  EDGE_12_15_9
 L  EDGE_12_15_10
 L  EDGE_12_15_11
 L  EDGE_12_15_12
 L  EDGE_12_17_0
 L  EDGE_12_17_1
 L  EDGE_12_17_2
 L  EDGE_12_17_3
 L  EDGE_12_17_4
 L  EDGE_12_17_5
 L  EDGE_12_17_6
 L  EDGE_12_17_7
 L  EDGE_12_17_8
 L  EDGE_12_17_9
 L  EDGE_12_17_10
 L  EDGE_12_17_11
 L  EDGE_12_17_12
 L  EDGE_12_19_0
 L  EDGE_12_19_1
 L  EDGE_12_19_2
 L  EDGE_12_19_3
 L  EDGE_12_19_4
 L  EDGE_12_19_5
 L  EDGE_12_19_6
 L  EDGE_12_19_7
 L  EDGE_12_19_8
 L  EDGE_12_19_9
 L  EDGE_12_19_10
 L  EDGE_12_19_11
 L  EDGE_12_19_12
 L  EDGE_12_21_0
 L  EDGE_12_21_1
 L  EDGE_12_21_2
 L  EDGE_12_21_3
 L  EDGE_12_21_4
 L  EDGE_12_21_5
 L  EDGE_12_21_6
 L  EDGE_12_21_7
 L  EDGE_12_21_8
 L  EDGE_12_21_9
 L  EDGE_12_21_10
 L  EDGE_12_21_11
 L  EDGE_12_21_12
 L  EDGE_12_23_0
 L  EDGE_12_23_1
 L  EDGE_12_23_2
 L  EDGE_12_23_3
 L  EDGE_12_23_4
 L  EDGE_12_23_5
 L  EDGE_12_23_6
 L  EDGE_12_23_7
 L  EDGE_12_23_8
 L  EDGE_12_23_9
 L  EDGE_12_23_10
 L  EDGE_12_23_11
 L  EDGE_12_23_12
 L  EDGE_13_18_0
 L  EDGE_13_18_1
 L  EDGE_13_18_2
 L  EDGE_13_18_3
 L  EDGE_13_18_4
 L  EDGE_13_18_5
 L  EDGE_13_18_6
 L  EDGE_13_18_7
 L  EDGE_13_18_8
 L  EDGE_13_18_9
 L  EDGE_13_18_10
 L  EDGE_13_18_11
 L  EDGE_13_18_12
 L  EDGE_13_18_13
 L  EDGE_13_19_0
 L  EDGE_13_19_1
 L  EDGE_13_19_2
 L  EDGE_13_19_3
 L  EDGE_13_19_4
 L  EDGE_13_19_5
 L  EDGE_13_19_6
 L  EDGE_13_19_7
 L  EDGE_13_19_8
 L  EDGE_13_19_9
 L  EDGE_13_19_10
 L  EDGE_13_19_11
 L  EDGE_13_19_12
 L  EDGE_13_19_13
 L  EDGE_13_23_0
 L  EDGE_13_23_1
 L  EDGE_13_23_2
 L  EDGE_13_23_3
 L  EDGE_13_23_4
 L  EDGE_13_23_5
 L  EDGE_13_23_6
 L  EDGE_13_23_7
 L  EDGE_13_23_8
 L  EDGE_13_23_9
 L  EDGE_13_23_10
 L  EDGE_13_23_11
 L  EDGE_13_23_12
 L  EDGE_13_23_13
 L  EDGE_14_16_0
 L  EDGE_14_16_1
 L  EDGE_14_16_2
 L  EDGE_14_16_3
 L  EDGE_14_16_4
 L  EDGE_14_16_5
 L  EDGE_14_16_6
 L  EDGE_14_16_7
 L  EDGE_14_16_8
 L  EDGE_14_16_9
 L  EDGE_14_16_10
 L  EDGE_14_16_11
 L  EDGE_14_16_12
 L  EDGE_14_16_13
 L  EDGE_14_16_14
 L  EDGE_14_17_0
 L  EDGE_14_17_1
 L  EDGE_14_17_2
 L  EDGE_14_17_3
 L  EDGE_14_17_4
 L  EDGE_14_17_5
 L  EDGE_14_17_6
 L  EDGE_14_17_7
 L  EDGE_14_17_8
 L  EDGE_14_17_9
 L  EDGE_14_17_10
 L  EDGE_14_17_11
 L  EDGE_14_17_12
 L  EDGE_14_17_13
 L  EDGE_14_17_14
 L  EDGE_14_19_0
 L  EDGE_14_19_1
 L  EDGE_14_19_2
 L  EDGE_14_19_3
 L  EDGE_14_19_4
 L  EDGE_14_19_5
 L  EDGE_14_19_6
 L  EDGE_14_19_7
 L  EDGE_14_19_8
 L  EDGE_14_19_9
 L  EDGE_14_19_10
 L  EDGE_14_19_11
 L  EDGE_14_19_12
 L  EDGE_14_19_13
 L  EDGE_14_19_14
 L  EDGE_15_17_0
 L  EDGE_15_17_1
 L  EDGE_15_17_2
 L  EDGE_15_17_3
 L  EDGE_15_17_4
 L  EDGE_15_17_5
 L  EDGE_15_17_6
 L  EDGE_15_17_7
 L  EDGE_15_17_8
 L  EDGE_15_17_9
 L  EDGE_15_17_10
 L  EDGE_15_17_11
 L  EDGE_15_17_12
 L  EDGE_15_17_13
 L  EDGE_15_17_14
 L  EDGE_15_17_15
 L  EDGE_15_18_0
 L  EDGE_15_18_1
 L  EDGE_15_18_2
 L  EDGE_15_18_3
 L  EDGE_15_18_4
 L  EDGE_15_18_5
 L  EDGE_15_18_6
 L  EDGE_15_18_7
 L  EDGE_15_18_8
 L  EDGE_15_18_9
 L  EDGE_15_18_10
 L  EDGE_15_18_11
 L  EDGE_15_18_12
 L  EDGE_15_18_13
 L  EDGE_15_18_14
 L  EDGE_15_18_15
 L  EDGE_16_17_0
 L  EDGE_16_17_1
 L  EDGE_16_17_2
 L  EDGE_16_17_3
 L  EDGE_16_17_4
 L  EDGE_16_17_5
 L  EDGE_16_17_6
 L  EDGE_16_17_7
 L  EDGE_16_17_8
 L  EDGE_16_17_9
 L  EDGE_16_17_10
 L  EDGE_16_17_11
 L  EDGE_16_17_12
 L  EDGE_16_17_13
 L  EDGE_16_17_14
 L  EDGE_16_17_15
 L  EDGE_16_17_16
 L  EDGE_16_18_0
 L  EDGE_16_18_1
 L  EDGE_16_18_2
 L  EDGE_16_18_3
 L  EDGE_16_18_4
 L  EDGE_16_18_5
 L  EDGE_16_18_6
 L  EDGE_16_18_7
 L  EDGE_16_18_8
 L  EDGE_16_18_9
 L  EDGE_16_18_10
 L  EDGE_16_18_11
 L  EDGE_16_18_12
 L  EDGE_16_18_13
 L  EDGE_16_18_14
 L  EDGE_16_18_15
 L  EDGE_16_18_16
 L  EDGE_16_22_0
 L  EDGE_16_22_1
 L  EDGE_16_22_2
 L  EDGE_16_22_3
 L  EDGE_16_22_4
 L  EDGE_16_22_5
 L  EDGE_16_22_6
 L  EDGE_16_22_7
 L  EDGE_16_22_8
 L  EDGE_16_22_9
 L  EDGE_16_22_10
 L  EDGE_16_22_11
 L  EDGE_16_22_12
 L  EDGE_16_22_13
 L  EDGE_16_22_14
 L  EDGE_16_22_15
 L  EDGE_16_22_16
 L  EDGE_16_23_0
 L  EDGE_16_23_1
 L  EDGE_16_23_2
 L  EDGE_16_23_3
 L  EDGE_16_23_4
 L  EDGE_16_23_5
 L  EDGE_16_23_6
 L  EDGE_16_23_7
 L  EDGE_16_23_8
 L  EDGE_16_23_9
 L  EDGE_16_23_10
 L  EDGE_16_23_11
 L  EDGE_16_23_12
 L  EDGE_16_23_13
 L  EDGE_16_23_14
 L  EDGE_16_23_15
 L  EDGE_16_23_16
 L  EDGE_18_22_0
 L  EDGE_18_22_1
 L  EDGE_18_22_2
 L  EDGE_18_22_3
 L  EDGE_18_22_4
 L  EDGE_18_22_5
 L  EDGE_18_22_6
 L  EDGE_18_22_7
 L  EDGE_18_22_8
 L  EDGE_18_22_9
 L  EDGE_18_22_10
 L  EDGE_18_22_11
 L  EDGE_18_22_12
 L  EDGE_18_22_13
 L  EDGE_18_22_14
 L  EDGE_18_22_15
 L  EDGE_18_22_16
 L  EDGE_18_22_17
 L  EDGE_18_22_18
 L  EDGE_19_21_0
 L  EDGE_19_21_1
 L  EDGE_19_21_2
 L  EDGE_19_21_3
 L  EDGE_19_21_4
 L  EDGE_19_21_5
 L  EDGE_19_21_6
 L  EDGE_19_21_7
 L  EDGE_19_21_8
 L  EDGE_19_21_9
 L  EDGE_19_21_10
 L  EDGE_19_21_11
 L  EDGE_19_21_12
 L  EDGE_19_21_13
 L  EDGE_19_21_14
 L  EDGE_19_21_15
 L  EDGE_19_21_16
 L  EDGE_19_21_17
 L  EDGE_19_21_18
 L  EDGE_19_21_19
 L  EDGE_21_22_0
 L  EDGE_21_22_1
 L  EDGE_21_22_2
 L  EDGE_21_22_3
 L  EDGE_21_22_4
 L  EDGE_21_22_5
 L  EDGE_21_22_6
 L  EDGE_21_22_7
 L  EDGE_21_22_8
 L  EDGE_21_22_9
 L  EDGE_21_22_10
 L  EDGE_21_22_11
 L  EDGE_21_22_12
 L  EDGE_21_22_13
 L  EDGE_21_22_14
 L  EDGE_21_22_15
 L  EDGE_21_22_16
 L  EDGE_21_22_17
 L  EDGE_21_22_18
 L  EDGE_21_22_19
 L  EDGE_21_22_20
 L  EDGE_21_22_21
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_0           OBJ           1.0
    x_0_0           ASSIGN_0        1.0
    x_0_0           LINK_1_0        -1.0
    x_0_0           LINK_2_0        -1.0
    x_0_0           LINK_3_0        -1.0
    x_0_0           LINK_4_0        -1.0
    x_0_0           LINK_5_0        -1.0
    x_0_0           LINK_6_0        -1.0
    x_0_0           LINK_7_0        -1.0
    x_0_0           LINK_8_0        -1.0
    x_0_0           LINK_9_0        -1.0
    x_0_0           LINK_10_0       -1.0
    x_0_0           LINK_11_0       -1.0
    x_0_0           LINK_12_0       -1.0
    x_0_0           LINK_13_0       -1.0
    x_0_0           LINK_14_0       -1.0
    x_0_0           LINK_15_0       -1.0
    x_0_0           LINK_16_0       -1.0
    x_0_0           LINK_17_0       -1.0
    x_0_0           LINK_18_0       -1.0
    x_0_0           LINK_19_0       -1.0
    x_0_0           LINK_20_0       -1.0
    x_0_0           LINK_21_0       -1.0
    x_0_0           LINK_22_0       -1.0
    x_0_0           LINK_23_0       -1.0
    x_0_0           EDGE_0_1_0      1.0
    x_0_0           EDGE_0_2_0      1.0
    x_0_0           EDGE_0_3_0      1.0
    x_0_0           EDGE_0_4_0      1.0
    x_0_0           EDGE_0_6_0      1.0
    x_0_0           EDGE_0_7_0      1.0
    x_0_0           EDGE_0_12_0     1.0
    x_0_0           EDGE_0_13_0     1.0
    x_0_0           EDGE_0_14_0     1.0
    x_0_0           EDGE_0_18_0     1.0
    x_0_0           EDGE_0_20_0     1.0
    x_0_0           EDGE_0_21_0     1.0
    x_0_0           EDGE_0_22_0     1.0
    x_0_0           EDGE_1_4_0      -1.0
    x_0_0           EDGE_1_5_0      -1.0
    x_0_0           EDGE_1_6_0      -1.0
    x_0_0           EDGE_1_7_0      -1.0
    x_0_0           EDGE_1_8_0      -1.0
    x_0_0           EDGE_1_9_0      -1.0
    x_0_0           EDGE_1_10_0     -1.0
    x_0_0           EDGE_1_15_0     -1.0
    x_0_0           EDGE_1_16_0     -1.0
    x_0_0           EDGE_1_18_0     -1.0
    x_0_0           EDGE_1_21_0     -1.0
    x_0_0           EDGE_2_3_0      -1.0
    x_0_0           EDGE_2_4_0      -1.0
    x_0_0           EDGE_2_5_0      -1.0
    x_0_0           EDGE_2_6_0      -1.0
    x_0_0           EDGE_2_8_0      -1.0
    x_0_0           EDGE_2_9_0      -1.0
    x_0_0           EDGE_2_10_0     -1.0
    x_0_0           EDGE_2_15_0     -1.0
    x_0_0           EDGE_2_16_0     -1.0
    x_0_0           EDGE_2_18_0     -1.0
    x_0_0           EDGE_2_19_0     -1.0
    x_0_0           EDGE_3_5_0      -1.0
    x_0_0           EDGE_3_9_0      -1.0
    x_0_0           EDGE_3_10_0     -1.0
    x_0_0           EDGE_3_12_0     -1.0
    x_0_0           EDGE_3_13_0     -1.0
    x_0_0           EDGE_3_14_0     -1.0
    x_0_0           EDGE_3_15_0     -1.0
    x_0_0           EDGE_3_20_0     -1.0
    x_0_0           EDGE_3_22_0     -1.0
    x_0_0           EDGE_4_5_0      -1.0
    x_0_0           EDGE_4_8_0      -1.0
    x_0_0           EDGE_4_9_0      -1.0
    x_0_0           EDGE_4_10_0     -1.0
    x_0_0           EDGE_4_13_0     -1.0
    x_0_0           EDGE_4_19_0     -1.0
    x_0_0           EDGE_4_20_0     -1.0
    x_0_0           EDGE_4_22_0     -1.0
    x_0_0           EDGE_5_7_0      -1.0
    x_0_0           EDGE_5_11_0     -1.0
    x_0_0           EDGE_5_13_0     -1.0
    x_0_0           EDGE_5_14_0     -1.0
    x_0_0           EDGE_5_18_0     -1.0
    x_0_0           EDGE_5_20_0     -1.0
    x_0_0           EDGE_5_21_0     -1.0
    x_0_0           EDGE_6_11_0     -1.0
    x_0_0           EDGE_6_12_0     -1.0
    x_0_0           EDGE_6_13_0     -1.0
    x_0_0           EDGE_6_14_0     -1.0
    x_0_0           EDGE_6_15_0     -1.0
    x_0_0           EDGE_6_20_0     -1.0
    x_0_0           EDGE_6_22_0     -1.0
    x_0_0           EDGE_7_10_0     -1.0
    x_0_0           EDGE_7_11_0     -1.0
    x_0_0           EDGE_7_12_0     -1.0
    x_0_0           EDGE_7_13_0     -1.0
    x_0_0           EDGE_7_15_0     -1.0
    x_0_0           EDGE_7_16_0     -1.0
    x_0_0           EDGE_7_19_0     -1.0
    x_0_0           EDGE_8_11_0     -1.0
    x_0_0           EDGE_8_13_0     -1.0
    x_0_0           EDGE_8_14_0     -1.0
    x_0_0           EDGE_8_17_0     -1.0
    x_0_0           EDGE_8_20_0     -1.0
    x_0_0           EDGE_8_21_0     -1.0
    x_0_0           EDGE_8_23_0     -1.0
    x_0_0           EDGE_9_11_0     -1.0
    x_0_0           EDGE_9_12_0     -1.0
    x_0_0           EDGE_9_14_0     -1.0
    x_0_0           EDGE_9_17_0     -1.0
    x_0_0           EDGE_9_20_0     -1.0
    x_0_0           EDGE_9_23_0     -1.0
    x_0_0           EDGE_10_11_0    -1.0
    x_0_0           EDGE_10_14_0    -1.0
    x_0_0           EDGE_10_17_0    -1.0
    x_0_0           EDGE_10_20_0    -1.0
    x_0_0           EDGE_10_23_0    -1.0
    x_0_0           EDGE_11_15_0    -1.0
    x_0_0           EDGE_11_16_0    -1.0
    x_0_0           EDGE_11_17_0    -1.0
    x_0_0           EDGE_11_19_0    -1.0
    x_0_0           EDGE_12_15_0    -1.0
    x_0_0           EDGE_12_17_0    -1.0
    x_0_0           EDGE_12_19_0    -1.0
    x_0_0           EDGE_12_21_0    -1.0
    x_0_0           EDGE_12_23_0    -1.0
    x_0_0           EDGE_13_18_0    -1.0
    x_0_0           EDGE_13_19_0    -1.0
    x_0_0           EDGE_13_23_0    -1.0
    x_0_0           EDGE_14_16_0    -1.0
    x_0_0           EDGE_14_17_0    -1.0
    x_0_0           EDGE_14_19_0    -1.0
    x_0_0           EDGE_15_17_0    -1.0
    x_0_0           EDGE_15_18_0    -1.0
    x_0_0           EDGE_16_17_0    -1.0
    x_0_0           EDGE_16_18_0    -1.0
    x_0_0           EDGE_16_22_0    -1.0
    x_0_0           EDGE_16_23_0    -1.0
    x_0_0           EDGE_18_22_0    -1.0
    x_0_0           EDGE_19_21_0    -1.0
    x_0_0           EDGE_21_22_0    -1.0
    x_1_0           ASSIGN_1        1.0
    x_1_0           LINK_1_0        1.0
    x_1_0           EDGE_0_1_0      1.0
    x_1_0           EDGE_1_4_0      1.0
    x_1_0           EDGE_1_5_0      1.0
    x_1_0           EDGE_1_6_0      1.0
    x_1_0           EDGE_1_7_0      1.0
    x_1_0           EDGE_1_8_0      1.0
    x_1_0           EDGE_1_9_0      1.0
    x_1_0           EDGE_1_10_0     1.0
    x_1_0           EDGE_1_15_0     1.0
    x_1_0           EDGE_1_16_0     1.0
    x_1_0           EDGE_1_18_0     1.0
    x_1_0           EDGE_1_21_0     1.0
    x_1_1           OBJ           1.0
    x_1_1           ASSIGN_1        1.0
    x_1_1           LINK_2_1        -1.0
    x_1_1           LINK_3_1        -1.0
    x_1_1           LINK_4_1        -1.0
    x_1_1           LINK_5_1        -1.0
    x_1_1           LINK_6_1        -1.0
    x_1_1           LINK_7_1        -1.0
    x_1_1           LINK_8_1        -1.0
    x_1_1           LINK_9_1        -1.0
    x_1_1           LINK_10_1       -1.0
    x_1_1           LINK_11_1       -1.0
    x_1_1           LINK_12_1       -1.0
    x_1_1           LINK_13_1       -1.0
    x_1_1           LINK_14_1       -1.0
    x_1_1           LINK_15_1       -1.0
    x_1_1           LINK_16_1       -1.0
    x_1_1           LINK_17_1       -1.0
    x_1_1           LINK_18_1       -1.0
    x_1_1           LINK_19_1       -1.0
    x_1_1           LINK_20_1       -1.0
    x_1_1           LINK_21_1       -1.0
    x_1_1           LINK_22_1       -1.0
    x_1_1           LINK_23_1       -1.0
    x_1_1           EDGE_1_4_1      1.0
    x_1_1           EDGE_1_5_1      1.0
    x_1_1           EDGE_1_6_1      1.0
    x_1_1           EDGE_1_7_1      1.0
    x_1_1           EDGE_1_8_1      1.0
    x_1_1           EDGE_1_9_1      1.0
    x_1_1           EDGE_1_10_1     1.0
    x_1_1           EDGE_1_15_1     1.0
    x_1_1           EDGE_1_16_1     1.0
    x_1_1           EDGE_1_18_1     1.0
    x_1_1           EDGE_1_21_1     1.0
    x_1_1           EDGE_2_3_1      -1.0
    x_1_1           EDGE_2_4_1      -1.0
    x_1_1           EDGE_2_5_1      -1.0
    x_1_1           EDGE_2_6_1      -1.0
    x_1_1           EDGE_2_8_1      -1.0
    x_1_1           EDGE_2_9_1      -1.0
    x_1_1           EDGE_2_10_1     -1.0
    x_1_1           EDGE_2_15_1     -1.0
    x_1_1           EDGE_2_16_1     -1.0
    x_1_1           EDGE_2_18_1     -1.0
    x_1_1           EDGE_2_19_1     -1.0
    x_1_1           EDGE_3_5_1      -1.0
    x_1_1           EDGE_3_9_1      -1.0
    x_1_1           EDGE_3_10_1     -1.0
    x_1_1           EDGE_3_12_1     -1.0
    x_1_1           EDGE_3_13_1     -1.0
    x_1_1           EDGE_3_14_1     -1.0
    x_1_1           EDGE_3_15_1     -1.0
    x_1_1           EDGE_3_20_1     -1.0
    x_1_1           EDGE_3_22_1     -1.0
    x_1_1           EDGE_4_5_1      -1.0
    x_1_1           EDGE_4_8_1      -1.0
    x_1_1           EDGE_4_9_1      -1.0
    x_1_1           EDGE_4_10_1     -1.0
    x_1_1           EDGE_4_13_1     -1.0
    x_1_1           EDGE_4_19_1     -1.0
    x_1_1           EDGE_4_20_1     -1.0
    x_1_1           EDGE_4_22_1     -1.0
    x_1_1           EDGE_5_7_1      -1.0
    x_1_1           EDGE_5_11_1     -1.0
    x_1_1           EDGE_5_13_1     -1.0
    x_1_1           EDGE_5_14_1     -1.0
    x_1_1           EDGE_5_18_1     -1.0
    x_1_1           EDGE_5_20_1     -1.0
    x_1_1           EDGE_5_21_1     -1.0
    x_1_1           EDGE_6_11_1     -1.0
    x_1_1           EDGE_6_12_1     -1.0
    x_1_1           EDGE_6_13_1     -1.0
    x_1_1           EDGE_6_14_1     -1.0
    x_1_1           EDGE_6_15_1     -1.0
    x_1_1           EDGE_6_20_1     -1.0
    x_1_1           EDGE_6_22_1     -1.0
    x_1_1           EDGE_7_10_1     -1.0
    x_1_1           EDGE_7_11_1     -1.0
    x_1_1           EDGE_7_12_1     -1.0
    x_1_1           EDGE_7_13_1     -1.0
    x_1_1           EDGE_7_15_1     -1.0
    x_1_1           EDGE_7_16_1     -1.0
    x_1_1           EDGE_7_19_1     -1.0
    x_1_1           EDGE_8_11_1     -1.0
    x_1_1           EDGE_8_13_1     -1.0
    x_1_1           EDGE_8_14_1     -1.0
    x_1_1           EDGE_8_17_1     -1.0
    x_1_1           EDGE_8_20_1     -1.0
    x_1_1           EDGE_8_21_1     -1.0
    x_1_1           EDGE_8_23_1     -1.0
    x_1_1           EDGE_9_11_1     -1.0
    x_1_1           EDGE_9_12_1     -1.0
    x_1_1           EDGE_9_14_1     -1.0
    x_1_1           EDGE_9_17_1     -1.0
    x_1_1           EDGE_9_20_1     -1.0
    x_1_1           EDGE_9_23_1     -1.0
    x_1_1           EDGE_10_11_1    -1.0
    x_1_1           EDGE_10_14_1    -1.0
    x_1_1           EDGE_10_17_1    -1.0
    x_1_1           EDGE_10_20_1    -1.0
    x_1_1           EDGE_10_23_1    -1.0
    x_1_1           EDGE_11_15_1    -1.0
    x_1_1           EDGE_11_16_1    -1.0
    x_1_1           EDGE_11_17_1    -1.0
    x_1_1           EDGE_11_19_1    -1.0
    x_1_1           EDGE_12_15_1    -1.0
    x_1_1           EDGE_12_17_1    -1.0
    x_1_1           EDGE_12_19_1    -1.0
    x_1_1           EDGE_12_21_1    -1.0
    x_1_1           EDGE_12_23_1    -1.0
    x_1_1           EDGE_13_18_1    -1.0
    x_1_1           EDGE_13_19_1    -1.0
    x_1_1           EDGE_13_23_1    -1.0
    x_1_1           EDGE_14_16_1    -1.0
    x_1_1           EDGE_14_17_1    -1.0
    x_1_1           EDGE_14_19_1    -1.0
    x_1_1           EDGE_15_17_1    -1.0
    x_1_1           EDGE_15_18_1    -1.0
    x_1_1           EDGE_16_17_1    -1.0
    x_1_1           EDGE_16_18_1    -1.0
    x_1_1           EDGE_16_22_1    -1.0
    x_1_1           EDGE_16_23_1    -1.0
    x_1_1           EDGE_18_22_1    -1.0
    x_1_1           EDGE_19_21_1    -1.0
    x_1_1           EDGE_21_22_1    -1.0
    x_2_0           ASSIGN_2        1.0
    x_2_0           LINK_2_0        1.0
    x_2_0           EDGE_0_2_0      1.0
    x_2_0           EDGE_2_3_0      1.0
    x_2_0           EDGE_2_4_0      1.0
    x_2_0           EDGE_2_5_0      1.0
    x_2_0           EDGE_2_6_0      1.0
    x_2_0           EDGE_2_8_0      1.0
    x_2_0           EDGE_2_9_0      1.0
    x_2_0           EDGE_2_10_0     1.0
    x_2_0           EDGE_2_15_0     1.0
    x_2_0           EDGE_2_16_0     1.0
    x_2_0           EDGE_2_18_0     1.0
    x_2_0           EDGE_2_19_0     1.0
    x_2_1           ASSIGN_2        1.0
    x_2_1           LINK_2_1        1.0
    x_2_1           EDGE_2_3_1      1.0
    x_2_1           EDGE_2_4_1      1.0
    x_2_1           EDGE_2_5_1      1.0
    x_2_1           EDGE_2_6_1      1.0
    x_2_1           EDGE_2_8_1      1.0
    x_2_1           EDGE_2_9_1      1.0
    x_2_1           EDGE_2_10_1     1.0
    x_2_1           EDGE_2_15_1     1.0
    x_2_1           EDGE_2_16_1     1.0
    x_2_1           EDGE_2_18_1     1.0
    x_2_1           EDGE_2_19_1     1.0
    x_2_2           OBJ           1.0
    x_2_2           ASSIGN_2        1.0
    x_2_2           LINK_3_2        -1.0
    x_2_2           LINK_4_2        -1.0
    x_2_2           LINK_5_2        -1.0
    x_2_2           LINK_6_2        -1.0
    x_2_2           LINK_7_2        -1.0
    x_2_2           LINK_8_2        -1.0
    x_2_2           LINK_9_2        -1.0
    x_2_2           LINK_10_2       -1.0
    x_2_2           LINK_11_2       -1.0
    x_2_2           LINK_12_2       -1.0
    x_2_2           LINK_13_2       -1.0
    x_2_2           LINK_14_2       -1.0
    x_2_2           LINK_15_2       -1.0
    x_2_2           LINK_16_2       -1.0
    x_2_2           LINK_17_2       -1.0
    x_2_2           LINK_18_2       -1.0
    x_2_2           LINK_19_2       -1.0
    x_2_2           LINK_20_2       -1.0
    x_2_2           LINK_21_2       -1.0
    x_2_2           LINK_22_2       -1.0
    x_2_2           LINK_23_2       -1.0
    x_2_2           EDGE_2_3_2      1.0
    x_2_2           EDGE_2_4_2      1.0
    x_2_2           EDGE_2_5_2      1.0
    x_2_2           EDGE_2_6_2      1.0
    x_2_2           EDGE_2_8_2      1.0
    x_2_2           EDGE_2_9_2      1.0
    x_2_2           EDGE_2_10_2     1.0
    x_2_2           EDGE_2_15_2     1.0
    x_2_2           EDGE_2_16_2     1.0
    x_2_2           EDGE_2_18_2     1.0
    x_2_2           EDGE_2_19_2     1.0
    x_2_2           EDGE_3_5_2      -1.0
    x_2_2           EDGE_3_9_2      -1.0
    x_2_2           EDGE_3_10_2     -1.0
    x_2_2           EDGE_3_12_2     -1.0
    x_2_2           EDGE_3_13_2     -1.0
    x_2_2           EDGE_3_14_2     -1.0
    x_2_2           EDGE_3_15_2     -1.0
    x_2_2           EDGE_3_20_2     -1.0
    x_2_2           EDGE_3_22_2     -1.0
    x_2_2           EDGE_4_5_2      -1.0
    x_2_2           EDGE_4_8_2      -1.0
    x_2_2           EDGE_4_9_2      -1.0
    x_2_2           EDGE_4_10_2     -1.0
    x_2_2           EDGE_4_13_2     -1.0
    x_2_2           EDGE_4_19_2     -1.0
    x_2_2           EDGE_4_20_2     -1.0
    x_2_2           EDGE_4_22_2     -1.0
    x_2_2           EDGE_5_7_2      -1.0
    x_2_2           EDGE_5_11_2     -1.0
    x_2_2           EDGE_5_13_2     -1.0
    x_2_2           EDGE_5_14_2     -1.0
    x_2_2           EDGE_5_18_2     -1.0
    x_2_2           EDGE_5_20_2     -1.0
    x_2_2           EDGE_5_21_2     -1.0
    x_2_2           EDGE_6_11_2     -1.0
    x_2_2           EDGE_6_12_2     -1.0
    x_2_2           EDGE_6_13_2     -1.0
    x_2_2           EDGE_6_14_2     -1.0
    x_2_2           EDGE_6_15_2     -1.0
    x_2_2           EDGE_6_20_2     -1.0
    x_2_2           EDGE_6_22_2     -1.0
    x_2_2           EDGE_7_10_2     -1.0
    x_2_2           EDGE_7_11_2     -1.0
    x_2_2           EDGE_7_12_2     -1.0
    x_2_2           EDGE_7_13_2     -1.0
    x_2_2           EDGE_7_15_2     -1.0
    x_2_2           EDGE_7_16_2     -1.0
    x_2_2           EDGE_7_19_2     -1.0
    x_2_2           EDGE_8_11_2     -1.0
    x_2_2           EDGE_8_13_2     -1.0
    x_2_2           EDGE_8_14_2     -1.0
    x_2_2           EDGE_8_17_2     -1.0
    x_2_2           EDGE_8_20_2     -1.0
    x_2_2           EDGE_8_21_2     -1.0
    x_2_2           EDGE_8_23_2     -1.0
    x_2_2           EDGE_9_11_2     -1.0
    x_2_2           EDGE_9_12_2     -1.0
    x_2_2           EDGE_9_14_2     -1.0
    x_2_2           EDGE_9_17_2     -1.0
    x_2_2           EDGE_9_20_2     -1.0
    x_2_2           EDGE_9_23_2     -1.0
    x_2_2           EDGE_10_11_2    -1.0
    x_2_2           EDGE_10_14_2    -1.0
    x_2_2           EDGE_10_17_2    -1.0
    x_2_2           EDGE_10_20_2    -1.0
    x_2_2           EDGE_10_23_2    -1.0
    x_2_2           EDGE_11_15_2    -1.0
    x_2_2           EDGE_11_16_2    -1.0
    x_2_2           EDGE_11_17_2    -1.0
    x_2_2           EDGE_11_19_2    -1.0
    x_2_2           EDGE_12_15_2    -1.0
    x_2_2           EDGE_12_17_2    -1.0
    x_2_2           EDGE_12_19_2    -1.0
    x_2_2           EDGE_12_21_2    -1.0
    x_2_2           EDGE_12_23_2    -1.0
    x_2_2           EDGE_13_18_2    -1.0
    x_2_2           EDGE_13_19_2    -1.0
    x_2_2           EDGE_13_23_2    -1.0
    x_2_2           EDGE_14_16_2    -1.0
    x_2_2           EDGE_14_17_2    -1.0
    x_2_2           EDGE_14_19_2    -1.0
    x_2_2           EDGE_15_17_2    -1.0
    x_2_2           EDGE_15_18_2    -1.0
    x_2_2           EDGE_16_17_2    -1.0
    x_2_2           EDGE_16_18_2    -1.0
    x_2_2           EDGE_16_22_2    -1.0
    x_2_2           EDGE_16_23_2    -1.0
    x_2_2           EDGE_18_22_2    -1.0
    x_2_2           EDGE_19_21_2    -1.0
    x_2_2           EDGE_21_22_2    -1.0
    x_3_0           ASSIGN_3        1.0
    x_3_0           LINK_3_0        1.0
    x_3_0           EDGE_0_3_0      1.0
    x_3_0           EDGE_2_3_0      1.0
    x_3_0           EDGE_3_5_0      1.0
    x_3_0           EDGE_3_9_0      1.0
    x_3_0           EDGE_3_10_0     1.0
    x_3_0           EDGE_3_12_0     1.0
    x_3_0           EDGE_3_13_0     1.0
    x_3_0           EDGE_3_14_0     1.0
    x_3_0           EDGE_3_15_0     1.0
    x_3_0           EDGE_3_20_0     1.0
    x_3_0           EDGE_3_22_0     1.0
    x_3_1           ASSIGN_3        1.0
    x_3_1           LINK_3_1        1.0
    x_3_1           EDGE_2_3_1      1.0
    x_3_1           EDGE_3_5_1      1.0
    x_3_1           EDGE_3_9_1      1.0
    x_3_1           EDGE_3_10_1     1.0
    x_3_1           EDGE_3_12_1     1.0
    x_3_1           EDGE_3_13_1     1.0
    x_3_1           EDGE_3_14_1     1.0
    x_3_1           EDGE_3_15_1     1.0
    x_3_1           EDGE_3_20_1     1.0
    x_3_1           EDGE_3_22_1     1.0
    x_3_2           ASSIGN_3        1.0
    x_3_2           LINK_3_2        1.0
    x_3_2           EDGE_2_3_2      1.0
    x_3_2           EDGE_3_5_2      1.0
    x_3_2           EDGE_3_9_2      1.0
    x_3_2           EDGE_3_10_2     1.0
    x_3_2           EDGE_3_12_2     1.0
    x_3_2           EDGE_3_13_2     1.0
    x_3_2           EDGE_3_14_2     1.0
    x_3_2           EDGE_3_15_2     1.0
    x_3_2           EDGE_3_20_2     1.0
    x_3_2           EDGE_3_22_2     1.0
    x_3_3           OBJ           1.0
    x_3_3           ASSIGN_3        1.0
    x_3_3           LINK_4_3        -1.0
    x_3_3           LINK_5_3        -1.0
    x_3_3           LINK_6_3        -1.0
    x_3_3           LINK_7_3        -1.0
    x_3_3           LINK_8_3        -1.0
    x_3_3           LINK_9_3        -1.0
    x_3_3           LINK_10_3       -1.0
    x_3_3           LINK_11_3       -1.0
    x_3_3           LINK_12_3       -1.0
    x_3_3           LINK_13_3       -1.0
    x_3_3           LINK_14_3       -1.0
    x_3_3           LINK_15_3       -1.0
    x_3_3           LINK_16_3       -1.0
    x_3_3           LINK_17_3       -1.0
    x_3_3           LINK_18_3       -1.0
    x_3_3           LINK_19_3       -1.0
    x_3_3           LINK_20_3       -1.0
    x_3_3           LINK_21_3       -1.0
    x_3_3           LINK_22_3       -1.0
    x_3_3           LINK_23_3       -1.0
    x_3_3           EDGE_3_5_3      1.0
    x_3_3           EDGE_3_9_3      1.0
    x_3_3           EDGE_3_10_3     1.0
    x_3_3           EDGE_3_12_3     1.0
    x_3_3           EDGE_3_13_3     1.0
    x_3_3           EDGE_3_14_3     1.0
    x_3_3           EDGE_3_15_3     1.0
    x_3_3           EDGE_3_20_3     1.0
    x_3_3           EDGE_3_22_3     1.0
    x_3_3           EDGE_4_5_3      -1.0
    x_3_3           EDGE_4_8_3      -1.0
    x_3_3           EDGE_4_9_3      -1.0
    x_3_3           EDGE_4_10_3     -1.0
    x_3_3           EDGE_4_13_3     -1.0
    x_3_3           EDGE_4_19_3     -1.0
    x_3_3           EDGE_4_20_3     -1.0
    x_3_3           EDGE_4_22_3     -1.0
    x_3_3           EDGE_5_7_3      -1.0
    x_3_3           EDGE_5_11_3     -1.0
    x_3_3           EDGE_5_13_3     -1.0
    x_3_3           EDGE_5_14_3     -1.0
    x_3_3           EDGE_5_18_3     -1.0
    x_3_3           EDGE_5_20_3     -1.0
    x_3_3           EDGE_5_21_3     -1.0
    x_3_3           EDGE_6_11_3     -1.0
    x_3_3           EDGE_6_12_3     -1.0
    x_3_3           EDGE_6_13_3     -1.0
    x_3_3           EDGE_6_14_3     -1.0
    x_3_3           EDGE_6_15_3     -1.0
    x_3_3           EDGE_6_20_3     -1.0
    x_3_3           EDGE_6_22_3     -1.0
    x_3_3           EDGE_7_10_3     -1.0
    x_3_3           EDGE_7_11_3     -1.0
    x_3_3           EDGE_7_12_3     -1.0
    x_3_3           EDGE_7_13_3     -1.0
    x_3_3           EDGE_7_15_3     -1.0
    x_3_3           EDGE_7_16_3     -1.0
    x_3_3           EDGE_7_19_3     -1.0
    x_3_3           EDGE_8_11_3     -1.0
    x_3_3           EDGE_8_13_3     -1.0
    x_3_3           EDGE_8_14_3     -1.0
    x_3_3           EDGE_8_17_3     -1.0
    x_3_3           EDGE_8_20_3     -1.0
    x_3_3           EDGE_8_21_3     -1.0
    x_3_3           EDGE_8_23_3     -1.0
    x_3_3           EDGE_9_11_3     -1.0
    x_3_3           EDGE_9_12_3     -1.0
    x_3_3           EDGE_9_14_3     -1.0
    x_3_3           EDGE_9_17_3     -1.0
    x_3_3           EDGE_9_20_3     -1.0
    x_3_3           EDGE_9_23_3     -1.0
    x_3_3           EDGE_10_11_3    -1.0
    x_3_3           EDGE_10_14_3    -1.0
    x_3_3           EDGE_10_17_3    -1.0
    x_3_3           EDGE_10_20_3    -1.0
    x_3_3           EDGE_10_23_3    -1.0
    x_3_3           EDGE_11_15_3    -1.0
    x_3_3           EDGE_11_16_3    -1.0
    x_3_3           EDGE_11_17_3    -1.0
    x_3_3           EDGE_11_19_3    -1.0
    x_3_3           EDGE_12_15_3    -1.0
    x_3_3           EDGE_12_17_3    -1.0
    x_3_3           EDGE_12_19_3    -1.0
    x_3_3           EDGE_12_21_3    -1.0
    x_3_3           EDGE_12_23_3    -1.0
    x_3_3           EDGE_13_18_3    -1.0
    x_3_3           EDGE_13_19_3    -1.0
    x_3_3           EDGE_13_23_3    -1.0
    x_3_3           EDGE_14_16_3    -1.0
    x_3_3           EDGE_14_17_3    -1.0
    x_3_3           EDGE_14_19_3    -1.0
    x_3_3           EDGE_15_17_3    -1.0
    x_3_3           EDGE_15_18_3    -1.0
    x_3_3           EDGE_16_17_3    -1.0
    x_3_3           EDGE_16_18_3    -1.0
    x_3_3           EDGE_16_22_3    -1.0
    x_3_3           EDGE_16_23_3    -1.0
    x_3_3           EDGE_18_22_3    -1.0
    x_3_3           EDGE_19_21_3    -1.0
    x_3_3           EDGE_21_22_3    -1.0
    x_4_0           ASSIGN_4        1.0
    x_4_0           LINK_4_0        1.0
    x_4_0           EDGE_0_4_0      1.0
    x_4_0           EDGE_1_4_0      1.0
    x_4_0           EDGE_2_4_0      1.0
    x_4_0           EDGE_4_5_0      1.0
    x_4_0           EDGE_4_8_0      1.0
    x_4_0           EDGE_4_9_0      1.0
    x_4_0           EDGE_4_10_0     1.0
    x_4_0           EDGE_4_13_0     1.0
    x_4_0           EDGE_4_19_0     1.0
    x_4_0           EDGE_4_20_0     1.0
    x_4_0           EDGE_4_22_0     1.0
    x_4_1           ASSIGN_4        1.0
    x_4_1           LINK_4_1        1.0
    x_4_1           EDGE_1_4_1      1.0
    x_4_1           EDGE_2_4_1      1.0
    x_4_1           EDGE_4_5_1      1.0
    x_4_1           EDGE_4_8_1      1.0
    x_4_1           EDGE_4_9_1      1.0
    x_4_1           EDGE_4_10_1     1.0
    x_4_1           EDGE_4_13_1     1.0
    x_4_1           EDGE_4_19_1     1.0
    x_4_1           EDGE_4_20_1     1.0
    x_4_1           EDGE_4_22_1     1.0
    x_4_2           ASSIGN_4        1.0
    x_4_2           LINK_4_2        1.0
    x_4_2           EDGE_2_4_2      1.0
    x_4_2           EDGE_4_5_2      1.0
    x_4_2           EDGE_4_8_2      1.0
    x_4_2           EDGE_4_9_2      1.0
    x_4_2           EDGE_4_10_2     1.0
    x_4_2           EDGE_4_13_2     1.0
    x_4_2           EDGE_4_19_2     1.0
    x_4_2           EDGE_4_20_2     1.0
    x_4_2           EDGE_4_22_2     1.0
    x_4_3           ASSIGN_4        1.0
    x_4_3           LINK_4_3        1.0
    x_4_3           EDGE_4_5_3      1.0
    x_4_3           EDGE_4_8_3      1.0
    x_4_3           EDGE_4_9_3      1.0
    x_4_3           EDGE_4_10_3     1.0
    x_4_3           EDGE_4_13_3     1.0
    x_4_3           EDGE_4_19_3     1.0
    x_4_3           EDGE_4_20_3     1.0
    x_4_3           EDGE_4_22_3     1.0
    x_4_4           OBJ           1.0
    x_4_4           ASSIGN_4        1.0
    x_4_4           LINK_5_4        -1.0
    x_4_4           LINK_6_4        -1.0
    x_4_4           LINK_7_4        -1.0
    x_4_4           LINK_8_4        -1.0
    x_4_4           LINK_9_4        -1.0
    x_4_4           LINK_10_4       -1.0
    x_4_4           LINK_11_4       -1.0
    x_4_4           LINK_12_4       -1.0
    x_4_4           LINK_13_4       -1.0
    x_4_4           LINK_14_4       -1.0
    x_4_4           LINK_15_4       -1.0
    x_4_4           LINK_16_4       -1.0
    x_4_4           LINK_17_4       -1.0
    x_4_4           LINK_18_4       -1.0
    x_4_4           LINK_19_4       -1.0
    x_4_4           LINK_20_4       -1.0
    x_4_4           LINK_21_4       -1.0
    x_4_4           LINK_22_4       -1.0
    x_4_4           LINK_23_4       -1.0
    x_4_4           EDGE_4_5_4      1.0
    x_4_4           EDGE_4_8_4      1.0
    x_4_4           EDGE_4_9_4      1.0
    x_4_4           EDGE_4_10_4     1.0
    x_4_4           EDGE_4_13_4     1.0
    x_4_4           EDGE_4_19_4     1.0
    x_4_4           EDGE_4_20_4     1.0
    x_4_4           EDGE_4_22_4     1.0
    x_4_4           EDGE_5_7_4      -1.0
    x_4_4           EDGE_5_11_4     -1.0
    x_4_4           EDGE_5_13_4     -1.0
    x_4_4           EDGE_5_14_4     -1.0
    x_4_4           EDGE_5_18_4     -1.0
    x_4_4           EDGE_5_20_4     -1.0
    x_4_4           EDGE_5_21_4     -1.0
    x_4_4           EDGE_6_11_4     -1.0
    x_4_4           EDGE_6_12_4     -1.0
    x_4_4           EDGE_6_13_4     -1.0
    x_4_4           EDGE_6_14_4     -1.0
    x_4_4           EDGE_6_15_4     -1.0
    x_4_4           EDGE_6_20_4     -1.0
    x_4_4           EDGE_6_22_4     -1.0
    x_4_4           EDGE_7_10_4     -1.0
    x_4_4           EDGE_7_11_4     -1.0
    x_4_4           EDGE_7_12_4     -1.0
    x_4_4           EDGE_7_13_4     -1.0
    x_4_4           EDGE_7_15_4     -1.0
    x_4_4           EDGE_7_16_4     -1.0
    x_4_4           EDGE_7_19_4     -1.0
    x_4_4           EDGE_8_11_4     -1.0
    x_4_4           EDGE_8_13_4     -1.0
    x_4_4           EDGE_8_14_4     -1.0
    x_4_4           EDGE_8_17_4     -1.0
    x_4_4           EDGE_8_20_4     -1.0
    x_4_4           EDGE_8_21_4     -1.0
    x_4_4           EDGE_8_23_4     -1.0
    x_4_4           EDGE_9_11_4     -1.0
    x_4_4           EDGE_9_12_4     -1.0
    x_4_4           EDGE_9_14_4     -1.0
    x_4_4           EDGE_9_17_4     -1.0
    x_4_4           EDGE_9_20_4     -1.0
    x_4_4           EDGE_9_23_4     -1.0
    x_4_4           EDGE_10_11_4    -1.0
    x_4_4           EDGE_10_14_4    -1.0
    x_4_4           EDGE_10_17_4    -1.0
    x_4_4           EDGE_10_20_4    -1.0
    x_4_4           EDGE_10_23_4    -1.0
    x_4_4           EDGE_11_15_4    -1.0
    x_4_4           EDGE_11_16_4    -1.0
    x_4_4           EDGE_11_17_4    -1.0
    x_4_4           EDGE_11_19_4    -1.0
    x_4_4           EDGE_12_15_4    -1.0
    x_4_4           EDGE_12_17_4    -1.0
    x_4_4           EDGE_12_19_4    -1.0
    x_4_4           EDGE_12_21_4    -1.0
    x_4_4           EDGE_12_23_4    -1.0
    x_4_4           EDGE_13_18_4    -1.0
    x_4_4           EDGE_13_19_4    -1.0
    x_4_4           EDGE_13_23_4    -1.0
    x_4_4           EDGE_14_16_4    -1.0
    x_4_4           EDGE_14_17_4    -1.0
    x_4_4           EDGE_14_19_4    -1.0
    x_4_4           EDGE_15_17_4    -1.0
    x_4_4           EDGE_15_18_4    -1.0
    x_4_4           EDGE_16_17_4    -1.0
    x_4_4           EDGE_16_18_4    -1.0
    x_4_4           EDGE_16_22_4    -1.0
    x_4_4           EDGE_16_23_4    -1.0
    x_4_4           EDGE_18_22_4    -1.0
    x_4_4           EDGE_19_21_4    -1.0
    x_4_4           EDGE_21_22_4    -1.0
    x_5_0           ASSIGN_5        1.0
    x_5_0           LINK_5_0        1.0
    x_5_0           EDGE_1_5_0      1.0
    x_5_0           EDGE_2_5_0      1.0
    x_5_0           EDGE_3_5_0      1.0
    x_5_0           EDGE_4_5_0      1.0
    x_5_0           EDGE_5_7_0      1.0
    x_5_0           EDGE_5_11_0     1.0
    x_5_0           EDGE_5_13_0     1.0
    x_5_0           EDGE_5_14_0     1.0
    x_5_0           EDGE_5_18_0     1.0
    x_5_0           EDGE_5_20_0     1.0
    x_5_0           EDGE_5_21_0     1.0
    x_5_1           ASSIGN_5        1.0
    x_5_1           LINK_5_1        1.0
    x_5_1           EDGE_1_5_1      1.0
    x_5_1           EDGE_2_5_1      1.0
    x_5_1           EDGE_3_5_1      1.0
    x_5_1           EDGE_4_5_1      1.0
    x_5_1           EDGE_5_7_1      1.0
    x_5_1           EDGE_5_11_1     1.0
    x_5_1           EDGE_5_13_1     1.0
    x_5_1           EDGE_5_14_1     1.0
    x_5_1           EDGE_5_18_1     1.0
    x_5_1           EDGE_5_20_1     1.0
    x_5_1           EDGE_5_21_1     1.0
    x_5_2           ASSIGN_5        1.0
    x_5_2           LINK_5_2        1.0
    x_5_2           EDGE_2_5_2      1.0
    x_5_2           EDGE_3_5_2      1.0
    x_5_2           EDGE_4_5_2      1.0
    x_5_2           EDGE_5_7_2      1.0
    x_5_2           EDGE_5_11_2     1.0
    x_5_2           EDGE_5_13_2     1.0
    x_5_2           EDGE_5_14_2     1.0
    x_5_2           EDGE_5_18_2     1.0
    x_5_2           EDGE_5_20_2     1.0
    x_5_2           EDGE_5_21_2     1.0
    x_5_3           ASSIGN_5        1.0
    x_5_3           LINK_5_3        1.0
    x_5_3           EDGE_3_5_3      1.0
    x_5_3           EDGE_4_5_3      1.0
    x_5_3           EDGE_5_7_3      1.0
    x_5_3           EDGE_5_11_3     1.0
    x_5_3           EDGE_5_13_3     1.0
    x_5_3           EDGE_5_14_3     1.0
    x_5_3           EDGE_5_18_3     1.0
    x_5_3           EDGE_5_20_3     1.0
    x_5_3           EDGE_5_21_3     1.0
    x_5_4           ASSIGN_5        1.0
    x_5_4           LINK_5_4        1.0
    x_5_4           EDGE_4_5_4      1.0
    x_5_4           EDGE_5_7_4      1.0
    x_5_4           EDGE_5_11_4     1.0
    x_5_4           EDGE_5_13_4     1.0
    x_5_4           EDGE_5_14_4     1.0
    x_5_4           EDGE_5_18_4     1.0
    x_5_4           EDGE_5_20_4     1.0
    x_5_4           EDGE_5_21_4     1.0
    x_5_5           OBJ           1.0
    x_5_5           ASSIGN_5        1.0
    x_5_5           LINK_6_5        -1.0
    x_5_5           LINK_7_5        -1.0
    x_5_5           LINK_8_5        -1.0
    x_5_5           LINK_9_5        -1.0
    x_5_5           LINK_10_5       -1.0
    x_5_5           LINK_11_5       -1.0
    x_5_5           LINK_12_5       -1.0
    x_5_5           LINK_13_5       -1.0
    x_5_5           LINK_14_5       -1.0
    x_5_5           LINK_15_5       -1.0
    x_5_5           LINK_16_5       -1.0
    x_5_5           LINK_17_5       -1.0
    x_5_5           LINK_18_5       -1.0
    x_5_5           LINK_19_5       -1.0
    x_5_5           LINK_20_5       -1.0
    x_5_5           LINK_21_5       -1.0
    x_5_5           LINK_22_5       -1.0
    x_5_5           LINK_23_5       -1.0
    x_5_5           EDGE_5_7_5      1.0
    x_5_5           EDGE_5_11_5     1.0
    x_5_5           EDGE_5_13_5     1.0
    x_5_5           EDGE_5_14_5     1.0
    x_5_5           EDGE_5_18_5     1.0
    x_5_5           EDGE_5_20_5     1.0
    x_5_5           EDGE_5_21_5     1.0
    x_5_5           EDGE_6_11_5     -1.0
    x_5_5           EDGE_6_12_5     -1.0
    x_5_5           EDGE_6_13_5     -1.0
    x_5_5           EDGE_6_14_5     -1.0
    x_5_5           EDGE_6_15_5     -1.0
    x_5_5           EDGE_6_20_5     -1.0
    x_5_5           EDGE_6_22_5     -1.0
    x_5_5           EDGE_7_10_5     -1.0
    x_5_5           EDGE_7_11_5     -1.0
    x_5_5           EDGE_7_12_5     -1.0
    x_5_5           EDGE_7_13_5     -1.0
    x_5_5           EDGE_7_15_5     -1.0
    x_5_5           EDGE_7_16_5     -1.0
    x_5_5           EDGE_7_19_5     -1.0
    x_5_5           EDGE_8_11_5     -1.0
    x_5_5           EDGE_8_13_5     -1.0
    x_5_5           EDGE_8_14_5     -1.0
    x_5_5           EDGE_8_17_5     -1.0
    x_5_5           EDGE_8_20_5     -1.0
    x_5_5           EDGE_8_21_5     -1.0
    x_5_5           EDGE_8_23_5     -1.0
    x_5_5           EDGE_9_11_5     -1.0
    x_5_5           EDGE_9_12_5     -1.0
    x_5_5           EDGE_9_14_5     -1.0
    x_5_5           EDGE_9_17_5     -1.0
    x_5_5           EDGE_9_20_5     -1.0
    x_5_5           EDGE_9_23_5     -1.0
    x_5_5           EDGE_10_11_5    -1.0
    x_5_5           EDGE_10_14_5    -1.0
    x_5_5           EDGE_10_17_5    -1.0
    x_5_5           EDGE_10_20_5    -1.0
    x_5_5           EDGE_10_23_5    -1.0
    x_5_5           EDGE_11_15_5    -1.0
    x_5_5           EDGE_11_16_5    -1.0
    x_5_5           EDGE_11_17_5    -1.0
    x_5_5           EDGE_11_19_5    -1.0
    x_5_5           EDGE_12_15_5    -1.0
    x_5_5           EDGE_12_17_5    -1.0
    x_5_5           EDGE_12_19_5    -1.0
    x_5_5           EDGE_12_21_5    -1.0
    x_5_5           EDGE_12_23_5    -1.0
    x_5_5           EDGE_13_18_5    -1.0
    x_5_5           EDGE_13_19_5    -1.0
    x_5_5           EDGE_13_23_5    -1.0
    x_5_5           EDGE_14_16_5    -1.0
    x_5_5           EDGE_14_17_5    -1.0
    x_5_5           EDGE_14_19_5    -1.0
    x_5_5           EDGE_15_17_5    -1.0
    x_5_5           EDGE_15_18_5    -1.0
    x_5_5           EDGE_16_17_5    -1.0
    x_5_5           EDGE_16_18_5    -1.0
    x_5_5           EDGE_16_22_5    -1.0
    x_5_5           EDGE_16_23_5    -1.0
    x_5_5           EDGE_18_22_5    -1.0
    x_5_5           EDGE_19_21_5    -1.0
    x_5_5           EDGE_21_22_5    -1.0
    x_6_0           ASSIGN_6        1.0
    x_6_0           LINK_6_0        1.0
    x_6_0           EDGE_0_6_0      1.0
    x_6_0           EDGE_1_6_0      1.0
    x_6_0           EDGE_2_6_0      1.0
    x_6_0           EDGE_6_11_0     1.0
    x_6_0           EDGE_6_12_0     1.0
    x_6_0           EDGE_6_13_0     1.0
    x_6_0           EDGE_6_14_0     1.0
    x_6_0           EDGE_6_15_0     1.0
    x_6_0           EDGE_6_20_0     1.0
    x_6_0           EDGE_6_22_0     1.0
    x_6_1           ASSIGN_6        1.0
    x_6_1           LINK_6_1        1.0
    x_6_1           EDGE_1_6_1      1.0
    x_6_1           EDGE_2_6_1      1.0
    x_6_1           EDGE_6_11_1     1.0
    x_6_1           EDGE_6_12_1     1.0
    x_6_1           EDGE_6_13_1     1.0
    x_6_1           EDGE_6_14_1     1.0
    x_6_1           EDGE_6_15_1     1.0
    x_6_1           EDGE_6_20_1     1.0
    x_6_1           EDGE_6_22_1     1.0
    x_6_2           ASSIGN_6        1.0
    x_6_2           LINK_6_2        1.0
    x_6_2           EDGE_2_6_2      1.0
    x_6_2           EDGE_6_11_2     1.0
    x_6_2           EDGE_6_12_2     1.0
    x_6_2           EDGE_6_13_2     1.0
    x_6_2           EDGE_6_14_2     1.0
    x_6_2           EDGE_6_15_2     1.0
    x_6_2           EDGE_6_20_2     1.0
    x_6_2           EDGE_6_22_2     1.0
    x_6_3           ASSIGN_6        1.0
    x_6_3           LINK_6_3        1.0
    x_6_3           EDGE_6_11_3     1.0
    x_6_3           EDGE_6_12_3     1.0
    x_6_3           EDGE_6_13_3     1.0
    x_6_3           EDGE_6_14_3     1.0
    x_6_3           EDGE_6_15_3     1.0
    x_6_3           EDGE_6_20_3     1.0
    x_6_3           EDGE_6_22_3     1.0
    x_6_4           ASSIGN_6        1.0
    x_6_4           LINK_6_4        1.0
    x_6_4           EDGE_6_11_4     1.0
    x_6_4           EDGE_6_12_4     1.0
    x_6_4           EDGE_6_13_4     1.0
    x_6_4           EDGE_6_14_4     1.0
    x_6_4           EDGE_6_15_4     1.0
    x_6_4           EDGE_6_20_4     1.0
    x_6_4           EDGE_6_22_4     1.0
    x_6_5           ASSIGN_6        1.0
    x_6_5           LINK_6_5        1.0
    x_6_5           EDGE_6_11_5     1.0
    x_6_5           EDGE_6_12_5     1.0
    x_6_5           EDGE_6_13_5     1.0
    x_6_5           EDGE_6_14_5     1.0
    x_6_5           EDGE_6_15_5     1.0
    x_6_5           EDGE_6_20_5     1.0
    x_6_5           EDGE_6_22_5     1.0
    x_6_6           OBJ           1.0
    x_6_6           ASSIGN_6        1.0
    x_6_6           LINK_7_6        -1.0
    x_6_6           LINK_8_6        -1.0
    x_6_6           LINK_9_6        -1.0
    x_6_6           LINK_10_6       -1.0
    x_6_6           LINK_11_6       -1.0
    x_6_6           LINK_12_6       -1.0
    x_6_6           LINK_13_6       -1.0
    x_6_6           LINK_14_6       -1.0
    x_6_6           LINK_15_6       -1.0
    x_6_6           LINK_16_6       -1.0
    x_6_6           LINK_17_6       -1.0
    x_6_6           LINK_18_6       -1.0
    x_6_6           LINK_19_6       -1.0
    x_6_6           LINK_20_6       -1.0
    x_6_6           LINK_21_6       -1.0
    x_6_6           LINK_22_6       -1.0
    x_6_6           LINK_23_6       -1.0
    x_6_6           EDGE_6_11_6     1.0
    x_6_6           EDGE_6_12_6     1.0
    x_6_6           EDGE_6_13_6     1.0
    x_6_6           EDGE_6_14_6     1.0
    x_6_6           EDGE_6_15_6     1.0
    x_6_6           EDGE_6_20_6     1.0
    x_6_6           EDGE_6_22_6     1.0
    x_6_6           EDGE_7_10_6     -1.0
    x_6_6           EDGE_7_11_6     -1.0
    x_6_6           EDGE_7_12_6     -1.0
    x_6_6           EDGE_7_13_6     -1.0
    x_6_6           EDGE_7_15_6     -1.0
    x_6_6           EDGE_7_16_6     -1.0
    x_6_6           EDGE_7_19_6     -1.0
    x_6_6           EDGE_8_11_6     -1.0
    x_6_6           EDGE_8_13_6     -1.0
    x_6_6           EDGE_8_14_6     -1.0
    x_6_6           EDGE_8_17_6     -1.0
    x_6_6           EDGE_8_20_6     -1.0
    x_6_6           EDGE_8_21_6     -1.0
    x_6_6           EDGE_8_23_6     -1.0
    x_6_6           EDGE_9_11_6     -1.0
    x_6_6           EDGE_9_12_6     -1.0
    x_6_6           EDGE_9_14_6     -1.0
    x_6_6           EDGE_9_17_6     -1.0
    x_6_6           EDGE_9_20_6     -1.0
    x_6_6           EDGE_9_23_6     -1.0
    x_6_6           EDGE_10_11_6    -1.0
    x_6_6           EDGE_10_14_6    -1.0
    x_6_6           EDGE_10_17_6    -1.0
    x_6_6           EDGE_10_20_6    -1.0
    x_6_6           EDGE_10_23_6    -1.0
    x_6_6           EDGE_11_15_6    -1.0
    x_6_6           EDGE_11_16_6    -1.0
    x_6_6           EDGE_11_17_6    -1.0
    x_6_6           EDGE_11_19_6    -1.0
    x_6_6           EDGE_12_15_6    -1.0
    x_6_6           EDGE_12_17_6    -1.0
    x_6_6           EDGE_12_19_6    -1.0
    x_6_6           EDGE_12_21_6    -1.0
    x_6_6           EDGE_12_23_6    -1.0
    x_6_6           EDGE_13_18_6    -1.0
    x_6_6           EDGE_13_19_6    -1.0
    x_6_6           EDGE_13_23_6    -1.0
    x_6_6           EDGE_14_16_6    -1.0
    x_6_6           EDGE_14_17_6    -1.0
    x_6_6           EDGE_14_19_6    -1.0
    x_6_6           EDGE_15_17_6    -1.0
    x_6_6           EDGE_15_18_6    -1.0
    x_6_6           EDGE_16_17_6    -1.0
    x_6_6           EDGE_16_18_6    -1.0
    x_6_6           EDGE_16_22_6    -1.0
    x_6_6           EDGE_16_23_6    -1.0
    x_6_6           EDGE_18_22_6    -1.0
    x_6_6           EDGE_19_21_6    -1.0
    x_6_6           EDGE_21_22_6    -1.0
    x_7_0           ASSIGN_7        1.0
    x_7_0           LINK_7_0        1.0
    x_7_0           EDGE_0_7_0      1.0
    x_7_0           EDGE_1_7_0      1.0
    x_7_0           EDGE_5_7_0      1.0
    x_7_0           EDGE_7_10_0     1.0
    x_7_0           EDGE_7_11_0     1.0
    x_7_0           EDGE_7_12_0     1.0
    x_7_0           EDGE_7_13_0     1.0
    x_7_0           EDGE_7_15_0     1.0
    x_7_0           EDGE_7_16_0     1.0
    x_7_0           EDGE_7_19_0     1.0
    x_7_1           ASSIGN_7        1.0
    x_7_1           LINK_7_1        1.0
    x_7_1           EDGE_1_7_1      1.0
    x_7_1           EDGE_5_7_1      1.0
    x_7_1           EDGE_7_10_1     1.0
    x_7_1           EDGE_7_11_1     1.0
    x_7_1           EDGE_7_12_1     1.0
    x_7_1           EDGE_7_13_1     1.0
    x_7_1           EDGE_7_15_1     1.0
    x_7_1           EDGE_7_16_1     1.0
    x_7_1           EDGE_7_19_1     1.0
    x_7_2           ASSIGN_7        1.0
    x_7_2           LINK_7_2        1.0
    x_7_2           EDGE_5_7_2      1.0
    x_7_2           EDGE_7_10_2     1.0
    x_7_2           EDGE_7_11_2     1.0
    x_7_2           EDGE_7_12_2     1.0
    x_7_2           EDGE_7_13_2     1.0
    x_7_2           EDGE_7_15_2     1.0
    x_7_2           EDGE_7_16_2     1.0
    x_7_2           EDGE_7_19_2     1.0
    x_7_3           ASSIGN_7        1.0
    x_7_3           LINK_7_3        1.0
    x_7_3           EDGE_5_7_3      1.0
    x_7_3           EDGE_7_10_3     1.0
    x_7_3           EDGE_7_11_3     1.0
    x_7_3           EDGE_7_12_3     1.0
    x_7_3           EDGE_7_13_3     1.0
    x_7_3           EDGE_7_15_3     1.0
    x_7_3           EDGE_7_16_3     1.0
    x_7_3           EDGE_7_19_3     1.0
    x_7_4           ASSIGN_7        1.0
    x_7_4           LINK_7_4        1.0
    x_7_4           EDGE_5_7_4      1.0
    x_7_4           EDGE_7_10_4     1.0
    x_7_4           EDGE_7_11_4     1.0
    x_7_4           EDGE_7_12_4     1.0
    x_7_4           EDGE_7_13_4     1.0
    x_7_4           EDGE_7_15_4     1.0
    x_7_4           EDGE_7_16_4     1.0
    x_7_4           EDGE_7_19_4     1.0
    x_7_5           ASSIGN_7        1.0
    x_7_5           LINK_7_5        1.0
    x_7_5           EDGE_5_7_5      1.0
    x_7_5           EDGE_7_10_5     1.0
    x_7_5           EDGE_7_11_5     1.0
    x_7_5           EDGE_7_12_5     1.0
    x_7_5           EDGE_7_13_5     1.0
    x_7_5           EDGE_7_15_5     1.0
    x_7_5           EDGE_7_16_5     1.0
    x_7_5           EDGE_7_19_5     1.0
    x_7_6           ASSIGN_7        1.0
    x_7_6           LINK_7_6        1.0
    x_7_6           EDGE_7_10_6     1.0
    x_7_6           EDGE_7_11_6     1.0
    x_7_6           EDGE_7_12_6     1.0
    x_7_6           EDGE_7_13_6     1.0
    x_7_6           EDGE_7_15_6     1.0
    x_7_6           EDGE_7_16_6     1.0
    x_7_6           EDGE_7_19_6     1.0
    x_7_7           OBJ           1.0
    x_7_7           ASSIGN_7        1.0
    x_7_7           LINK_8_7        -1.0
    x_7_7           LINK_9_7        -1.0
    x_7_7           LINK_10_7       -1.0
    x_7_7           LINK_11_7       -1.0
    x_7_7           LINK_12_7       -1.0
    x_7_7           LINK_13_7       -1.0
    x_7_7           LINK_14_7       -1.0
    x_7_7           LINK_15_7       -1.0
    x_7_7           LINK_16_7       -1.0
    x_7_7           LINK_17_7       -1.0
    x_7_7           LINK_18_7       -1.0
    x_7_7           LINK_19_7       -1.0
    x_7_7           LINK_20_7       -1.0
    x_7_7           LINK_21_7       -1.0
    x_7_7           LINK_22_7       -1.0
    x_7_7           LINK_23_7       -1.0
    x_7_7           EDGE_7_10_7     1.0
    x_7_7           EDGE_7_11_7     1.0
    x_7_7           EDGE_7_12_7     1.0
    x_7_7           EDGE_7_13_7     1.0
    x_7_7           EDGE_7_15_7     1.0
    x_7_7           EDGE_7_16_7     1.0
    x_7_7           EDGE_7_19_7     1.0
    x_7_7           EDGE_8_11_7     -1.0
    x_7_7           EDGE_8_13_7     -1.0
    x_7_7           EDGE_8_14_7     -1.0
    x_7_7           EDGE_8_17_7     -1.0
    x_7_7           EDGE_8_20_7     -1.0
    x_7_7           EDGE_8_21_7     -1.0
    x_7_7           EDGE_8_23_7     -1.0
    x_7_7           EDGE_9_11_7     -1.0
    x_7_7           EDGE_9_12_7     -1.0
    x_7_7           EDGE_9_14_7     -1.0
    x_7_7           EDGE_9_17_7     -1.0
    x_7_7           EDGE_9_20_7     -1.0
    x_7_7           EDGE_9_23_7     -1.0
    x_7_7           EDGE_10_11_7    -1.0
    x_7_7           EDGE_10_14_7    -1.0
    x_7_7           EDGE_10_17_7    -1.0
    x_7_7           EDGE_10_20_7    -1.0
    x_7_7           EDGE_10_23_7    -1.0
    x_7_7           EDGE_11_15_7    -1.0
    x_7_7           EDGE_11_16_7    -1.0
    x_7_7           EDGE_11_17_7    -1.0
    x_7_7           EDGE_11_19_7    -1.0
    x_7_7           EDGE_12_15_7    -1.0
    x_7_7           EDGE_12_17_7    -1.0
    x_7_7           EDGE_12_19_7    -1.0
    x_7_7           EDGE_12_21_7    -1.0
    x_7_7           EDGE_12_23_7    -1.0
    x_7_7           EDGE_13_18_7    -1.0
    x_7_7           EDGE_13_19_7    -1.0
    x_7_7           EDGE_13_23_7    -1.0
    x_7_7           EDGE_14_16_7    -1.0
    x_7_7           EDGE_14_17_7    -1.0
    x_7_7           EDGE_14_19_7    -1.0
    x_7_7           EDGE_15_17_7    -1.0
    x_7_7           EDGE_15_18_7    -1.0
    x_7_7           EDGE_16_17_7    -1.0
    x_7_7           EDGE_16_18_7    -1.0
    x_7_7           EDGE_16_22_7    -1.0
    x_7_7           EDGE_16_23_7    -1.0
    x_7_7           EDGE_18_22_7    -1.0
    x_7_7           EDGE_19_21_7    -1.0
    x_7_7           EDGE_21_22_7    -1.0
    x_8_0           ASSIGN_8        1.0
    x_8_0           LINK_8_0        1.0
    x_8_0           EDGE_1_8_0      1.0
    x_8_0           EDGE_2_8_0      1.0
    x_8_0           EDGE_4_8_0      1.0
    x_8_0           EDGE_8_11_0     1.0
    x_8_0           EDGE_8_13_0     1.0
    x_8_0           EDGE_8_14_0     1.0
    x_8_0           EDGE_8_17_0     1.0
    x_8_0           EDGE_8_20_0     1.0
    x_8_0           EDGE_8_21_0     1.0
    x_8_0           EDGE_8_23_0     1.0
    x_8_1           ASSIGN_8        1.0
    x_8_1           LINK_8_1        1.0
    x_8_1           EDGE_1_8_1      1.0
    x_8_1           EDGE_2_8_1      1.0
    x_8_1           EDGE_4_8_1      1.0
    x_8_1           EDGE_8_11_1     1.0
    x_8_1           EDGE_8_13_1     1.0
    x_8_1           EDGE_8_14_1     1.0
    x_8_1           EDGE_8_17_1     1.0
    x_8_1           EDGE_8_20_1     1.0
    x_8_1           EDGE_8_21_1     1.0
    x_8_1           EDGE_8_23_1     1.0
    x_8_2           ASSIGN_8        1.0
    x_8_2           LINK_8_2        1.0
    x_8_2           EDGE_2_8_2      1.0
    x_8_2           EDGE_4_8_2      1.0
    x_8_2           EDGE_8_11_2     1.0
    x_8_2           EDGE_8_13_2     1.0
    x_8_2           EDGE_8_14_2     1.0
    x_8_2           EDGE_8_17_2     1.0
    x_8_2           EDGE_8_20_2     1.0
    x_8_2           EDGE_8_21_2     1.0
    x_8_2           EDGE_8_23_2     1.0
    x_8_3           ASSIGN_8        1.0
    x_8_3           LINK_8_3        1.0
    x_8_3           EDGE_4_8_3      1.0
    x_8_3           EDGE_8_11_3     1.0
    x_8_3           EDGE_8_13_3     1.0
    x_8_3           EDGE_8_14_3     1.0
    x_8_3           EDGE_8_17_3     1.0
    x_8_3           EDGE_8_20_3     1.0
    x_8_3           EDGE_8_21_3     1.0
    x_8_3           EDGE_8_23_3     1.0
    x_8_4           ASSIGN_8        1.0
    x_8_4           LINK_8_4        1.0
    x_8_4           EDGE_4_8_4      1.0
    x_8_4           EDGE_8_11_4     1.0
    x_8_4           EDGE_8_13_4     1.0
    x_8_4           EDGE_8_14_4     1.0
    x_8_4           EDGE_8_17_4     1.0
    x_8_4           EDGE_8_20_4     1.0
    x_8_4           EDGE_8_21_4     1.0
    x_8_4           EDGE_8_23_4     1.0
    x_8_5           ASSIGN_8        1.0
    x_8_5           LINK_8_5        1.0
    x_8_5           EDGE_8_11_5     1.0
    x_8_5           EDGE_8_13_5     1.0
    x_8_5           EDGE_8_14_5     1.0
    x_8_5           EDGE_8_17_5     1.0
    x_8_5           EDGE_8_20_5     1.0
    x_8_5           EDGE_8_21_5     1.0
    x_8_5           EDGE_8_23_5     1.0
    x_8_6           ASSIGN_8        1.0
    x_8_6           LINK_8_6        1.0
    x_8_6           EDGE_8_11_6     1.0
    x_8_6           EDGE_8_13_6     1.0
    x_8_6           EDGE_8_14_6     1.0
    x_8_6           EDGE_8_17_6     1.0
    x_8_6           EDGE_8_20_6     1.0
    x_8_6           EDGE_8_21_6     1.0
    x_8_6           EDGE_8_23_6     1.0
    x_8_7           ASSIGN_8        1.0
    x_8_7           LINK_8_7        1.0
    x_8_7           EDGE_8_11_7     1.0
    x_8_7           EDGE_8_13_7     1.0
    x_8_7           EDGE_8_14_7     1.0
    x_8_7           EDGE_8_17_7     1.0
    x_8_7           EDGE_8_20_7     1.0
    x_8_7           EDGE_8_21_7     1.0
    x_8_7           EDGE_8_23_7     1.0
    x_8_8           OBJ           1.0
    x_8_8           ASSIGN_8        1.0
    x_8_8           LINK_9_8        -1.0
    x_8_8           LINK_10_8       -1.0
    x_8_8           LINK_11_8       -1.0
    x_8_8           LINK_12_8       -1.0
    x_8_8           LINK_13_8       -1.0
    x_8_8           LINK_14_8       -1.0
    x_8_8           LINK_15_8       -1.0
    x_8_8           LINK_16_8       -1.0
    x_8_8           LINK_17_8       -1.0
    x_8_8           LINK_18_8       -1.0
    x_8_8           LINK_19_8       -1.0
    x_8_8           LINK_20_8       -1.0
    x_8_8           LINK_21_8       -1.0
    x_8_8           LINK_22_8       -1.0
    x_8_8           LINK_23_8       -1.0
    x_8_8           EDGE_8_11_8     1.0
    x_8_8           EDGE_8_13_8     1.0
    x_8_8           EDGE_8_14_8     1.0
    x_8_8           EDGE_8_17_8     1.0
    x_8_8           EDGE_8_20_8     1.0
    x_8_8           EDGE_8_21_8     1.0
    x_8_8           EDGE_8_23_8     1.0
    x_8_8           EDGE_9_11_8     -1.0
    x_8_8           EDGE_9_12_8     -1.0
    x_8_8           EDGE_9_14_8     -1.0
    x_8_8           EDGE_9_17_8     -1.0
    x_8_8           EDGE_9_20_8     -1.0
    x_8_8           EDGE_9_23_8     -1.0
    x_8_8           EDGE_10_11_8    -1.0
    x_8_8           EDGE_10_14_8    -1.0
    x_8_8           EDGE_10_17_8    -1.0
    x_8_8           EDGE_10_20_8    -1.0
    x_8_8           EDGE_10_23_8    -1.0
    x_8_8           EDGE_11_15_8    -1.0
    x_8_8           EDGE_11_16_8    -1.0
    x_8_8           EDGE_11_17_8    -1.0
    x_8_8           EDGE_11_19_8    -1.0
    x_8_8           EDGE_12_15_8    -1.0
    x_8_8           EDGE_12_17_8    -1.0
    x_8_8           EDGE_12_19_8    -1.0
    x_8_8           EDGE_12_21_8    -1.0
    x_8_8           EDGE_12_23_8    -1.0
    x_8_8           EDGE_13_18_8    -1.0
    x_8_8           EDGE_13_19_8    -1.0
    x_8_8           EDGE_13_23_8    -1.0
    x_8_8           EDGE_14_16_8    -1.0
    x_8_8           EDGE_14_17_8    -1.0
    x_8_8           EDGE_14_19_8    -1.0
    x_8_8           EDGE_15_17_8    -1.0
    x_8_8           EDGE_15_18_8    -1.0
    x_8_8           EDGE_16_17_8    -1.0
    x_8_8           EDGE_16_18_8    -1.0
    x_8_8           EDGE_16_22_8    -1.0
    x_8_8           EDGE_16_23_8    -1.0
    x_8_8           EDGE_18_22_8    -1.0
    x_8_8           EDGE_19_21_8    -1.0
    x_8_8           EDGE_21_22_8    -1.0
    x_9_0           ASSIGN_9        1.0
    x_9_0           LINK_9_0        1.0
    x_9_0           EDGE_1_9_0      1.0
    x_9_0           EDGE_2_9_0      1.0
    x_9_0           EDGE_3_9_0      1.0
    x_9_0           EDGE_4_9_0      1.0
    x_9_0           EDGE_9_11_0     1.0
    x_9_0           EDGE_9_12_0     1.0
    x_9_0           EDGE_9_14_0     1.0
    x_9_0           EDGE_9_17_0     1.0
    x_9_0           EDGE_9_20_0     1.0
    x_9_0           EDGE_9_23_0     1.0
    x_9_1           ASSIGN_9        1.0
    x_9_1           LINK_9_1        1.0
    x_9_1           EDGE_1_9_1      1.0
    x_9_1           EDGE_2_9_1      1.0
    x_9_1           EDGE_3_9_1      1.0
    x_9_1           EDGE_4_9_1      1.0
    x_9_1           EDGE_9_11_1     1.0
    x_9_1           EDGE_9_12_1     1.0
    x_9_1           EDGE_9_14_1     1.0
    x_9_1           EDGE_9_17_1     1.0
    x_9_1           EDGE_9_20_1     1.0
    x_9_1           EDGE_9_23_1     1.0
    x_9_2           ASSIGN_9        1.0
    x_9_2           LINK_9_2        1.0
    x_9_2           EDGE_2_9_2      1.0
    x_9_2           EDGE_3_9_2      1.0
    x_9_2           EDGE_4_9_2      1.0
    x_9_2           EDGE_9_11_2     1.0
    x_9_2           EDGE_9_12_2     1.0
    x_9_2           EDGE_9_14_2     1.0
    x_9_2           EDGE_9_17_2     1.0
    x_9_2           EDGE_9_20_2     1.0
    x_9_2           EDGE_9_23_2     1.0
    x_9_3           ASSIGN_9        1.0
    x_9_3           LINK_9_3        1.0
    x_9_3           EDGE_3_9_3      1.0
    x_9_3           EDGE_4_9_3      1.0
    x_9_3           EDGE_9_11_3     1.0
    x_9_3           EDGE_9_12_3     1.0
    x_9_3           EDGE_9_14_3     1.0
    x_9_3           EDGE_9_17_3     1.0
    x_9_3           EDGE_9_20_3     1.0
    x_9_3           EDGE_9_23_3     1.0
    x_9_4           ASSIGN_9        1.0
    x_9_4           LINK_9_4        1.0
    x_9_4           EDGE_4_9_4      1.0
    x_9_4           EDGE_9_11_4     1.0
    x_9_4           EDGE_9_12_4     1.0
    x_9_4           EDGE_9_14_4     1.0
    x_9_4           EDGE_9_17_4     1.0
    x_9_4           EDGE_9_20_4     1.0
    x_9_4           EDGE_9_23_4     1.0
    x_9_5           ASSIGN_9        1.0
    x_9_5           LINK_9_5        1.0
    x_9_5           EDGE_9_11_5     1.0
    x_9_5           EDGE_9_12_5     1.0
    x_9_5           EDGE_9_14_5     1.0
    x_9_5           EDGE_9_17_5     1.0
    x_9_5           EDGE_9_20_5     1.0
    x_9_5           EDGE_9_23_5     1.0
    x_9_6           ASSIGN_9        1.0
    x_9_6           LINK_9_6        1.0
    x_9_6           EDGE_9_11_6     1.0
    x_9_6           EDGE_9_12_6     1.0
    x_9_6           EDGE_9_14_6     1.0
    x_9_6           EDGE_9_17_6     1.0
    x_9_6           EDGE_9_20_6     1.0
    x_9_6           EDGE_9_23_6     1.0
    x_9_7           ASSIGN_9        1.0
    x_9_7           LINK_9_7        1.0
    x_9_7           EDGE_9_11_7     1.0
    x_9_7           EDGE_9_12_7     1.0
    x_9_7           EDGE_9_14_7     1.0
    x_9_7           EDGE_9_17_7     1.0
    x_9_7           EDGE_9_20_7     1.0
    x_9_7           EDGE_9_23_7     1.0
    x_9_8           ASSIGN_9        1.0
    x_9_8           LINK_9_8        1.0
    x_9_8           EDGE_9_11_8     1.0
    x_9_8           EDGE_9_12_8     1.0
    x_9_8           EDGE_9_14_8     1.0
    x_9_8           EDGE_9_17_8     1.0
    x_9_8           EDGE_9_20_8     1.0
    x_9_8           EDGE_9_23_8     1.0
    x_9_9           OBJ           1.0
    x_9_9           ASSIGN_9        1.0
    x_9_9           LINK_10_9       -1.0
    x_9_9           LINK_11_9       -1.0
    x_9_9           LINK_12_9       -1.0
    x_9_9           LINK_13_9       -1.0
    x_9_9           LINK_14_9       -1.0
    x_9_9           LINK_15_9       -1.0
    x_9_9           LINK_16_9       -1.0
    x_9_9           LINK_17_9       -1.0
    x_9_9           LINK_18_9       -1.0
    x_9_9           LINK_19_9       -1.0
    x_9_9           LINK_20_9       -1.0
    x_9_9           LINK_21_9       -1.0
    x_9_9           LINK_22_9       -1.0
    x_9_9           LINK_23_9       -1.0
    x_9_9           EDGE_9_11_9     1.0
    x_9_9           EDGE_9_12_9     1.0
    x_9_9           EDGE_9_14_9     1.0
    x_9_9           EDGE_9_17_9     1.0
    x_9_9           EDGE_9_20_9     1.0
    x_9_9           EDGE_9_23_9     1.0
    x_9_9           EDGE_10_11_9    -1.0
    x_9_9           EDGE_10_14_9    -1.0
    x_9_9           EDGE_10_17_9    -1.0
    x_9_9           EDGE_10_20_9    -1.0
    x_9_9           EDGE_10_23_9    -1.0
    x_9_9           EDGE_11_15_9    -1.0
    x_9_9           EDGE_11_16_9    -1.0
    x_9_9           EDGE_11_17_9    -1.0
    x_9_9           EDGE_11_19_9    -1.0
    x_9_9           EDGE_12_15_9    -1.0
    x_9_9           EDGE_12_17_9    -1.0
    x_9_9           EDGE_12_19_9    -1.0
    x_9_9           EDGE_12_21_9    -1.0
    x_9_9           EDGE_12_23_9    -1.0
    x_9_9           EDGE_13_18_9    -1.0
    x_9_9           EDGE_13_19_9    -1.0
    x_9_9           EDGE_13_23_9    -1.0
    x_9_9           EDGE_14_16_9    -1.0
    x_9_9           EDGE_14_17_9    -1.0
    x_9_9           EDGE_14_19_9    -1.0
    x_9_9           EDGE_15_17_9    -1.0
    x_9_9           EDGE_15_18_9    -1.0
    x_9_9           EDGE_16_17_9    -1.0
    x_9_9           EDGE_16_18_9    -1.0
    x_9_9           EDGE_16_22_9    -1.0
    x_9_9           EDGE_16_23_9    -1.0
    x_9_9           EDGE_18_22_9    -1.0
    x_9_9           EDGE_19_21_9    -1.0
    x_9_9           EDGE_21_22_9    -1.0
    x_10_0          ASSIGN_10       1.0
    x_10_0          LINK_10_0       1.0
    x_10_0          EDGE_1_10_0     1.0
    x_10_0          EDGE_2_10_0     1.0
    x_10_0          EDGE_3_10_0     1.0
    x_10_0          EDGE_4_10_0     1.0
    x_10_0          EDGE_7_10_0     1.0
    x_10_0          EDGE_10_11_0    1.0
    x_10_0          EDGE_10_14_0    1.0
    x_10_0          EDGE_10_17_0    1.0
    x_10_0          EDGE_10_20_0    1.0
    x_10_0          EDGE_10_23_0    1.0
    x_10_1          ASSIGN_10       1.0
    x_10_1          LINK_10_1       1.0
    x_10_1          EDGE_1_10_1     1.0
    x_10_1          EDGE_2_10_1     1.0
    x_10_1          EDGE_3_10_1     1.0
    x_10_1          EDGE_4_10_1     1.0
    x_10_1          EDGE_7_10_1     1.0
    x_10_1          EDGE_10_11_1    1.0
    x_10_1          EDGE_10_14_1    1.0
    x_10_1          EDGE_10_17_1    1.0
    x_10_1          EDGE_10_20_1    1.0
    x_10_1          EDGE_10_23_1    1.0
    x_10_2          ASSIGN_10       1.0
    x_10_2          LINK_10_2       1.0
    x_10_2          EDGE_2_10_2     1.0
    x_10_2          EDGE_3_10_2     1.0
    x_10_2          EDGE_4_10_2     1.0
    x_10_2          EDGE_7_10_2     1.0
    x_10_2          EDGE_10_11_2    1.0
    x_10_2          EDGE_10_14_2    1.0
    x_10_2          EDGE_10_17_2    1.0
    x_10_2          EDGE_10_20_2    1.0
    x_10_2          EDGE_10_23_2    1.0
    x_10_3          ASSIGN_10       1.0
    x_10_3          LINK_10_3       1.0
    x_10_3          EDGE_3_10_3     1.0
    x_10_3          EDGE_4_10_3     1.0
    x_10_3          EDGE_7_10_3     1.0
    x_10_3          EDGE_10_11_3    1.0
    x_10_3          EDGE_10_14_3    1.0
    x_10_3          EDGE_10_17_3    1.0
    x_10_3          EDGE_10_20_3    1.0
    x_10_3          EDGE_10_23_3    1.0
    x_10_4          ASSIGN_10       1.0
    x_10_4          LINK_10_4       1.0
    x_10_4          EDGE_4_10_4     1.0
    x_10_4          EDGE_7_10_4     1.0
    x_10_4          EDGE_10_11_4    1.0
    x_10_4          EDGE_10_14_4    1.0
    x_10_4          EDGE_10_17_4    1.0
    x_10_4          EDGE_10_20_4    1.0
    x_10_4          EDGE_10_23_4    1.0
    x_10_5          ASSIGN_10       1.0
    x_10_5          LINK_10_5       1.0
    x_10_5          EDGE_7_10_5     1.0
    x_10_5          EDGE_10_11_5    1.0
    x_10_5          EDGE_10_14_5    1.0
    x_10_5          EDGE_10_17_5    1.0
    x_10_5          EDGE_10_20_5    1.0
    x_10_5          EDGE_10_23_5    1.0
    x_10_6          ASSIGN_10       1.0
    x_10_6          LINK_10_6       1.0
    x_10_6          EDGE_7_10_6     1.0
    x_10_6          EDGE_10_11_6    1.0
    x_10_6          EDGE_10_14_6    1.0
    x_10_6          EDGE_10_17_6    1.0
    x_10_6          EDGE_10_20_6    1.0
    x_10_6          EDGE_10_23_6    1.0
    x_10_7          ASSIGN_10       1.0
    x_10_7          LINK_10_7       1.0
    x_10_7          EDGE_7_10_7     1.0
    x_10_7          EDGE_10_11_7    1.0
    x_10_7          EDGE_10_14_7    1.0
    x_10_7          EDGE_10_17_7    1.0
    x_10_7          EDGE_10_20_7    1.0
    x_10_7          EDGE_10_23_7    1.0
    x_10_8          ASSIGN_10       1.0
    x_10_8          LINK_10_8       1.0
    x_10_8          EDGE_10_11_8    1.0
    x_10_8          EDGE_10_14_8    1.0
    x_10_8          EDGE_10_17_8    1.0
    x_10_8          EDGE_10_20_8    1.0
    x_10_8          EDGE_10_23_8    1.0
    x_10_9          ASSIGN_10       1.0
    x_10_9          LINK_10_9       1.0
    x_10_9          EDGE_10_11_9    1.0
    x_10_9          EDGE_10_14_9    1.0
    x_10_9          EDGE_10_17_9    1.0
    x_10_9          EDGE_10_20_9    1.0
    x_10_9          EDGE_10_23_9    1.0
    x_10_10         OBJ           1.0
    x_10_10         ASSIGN_10       1.0
    x_10_10         LINK_11_10      -1.0
    x_10_10         LINK_12_10      -1.0
    x_10_10         LINK_13_10      -1.0
    x_10_10         LINK_14_10      -1.0
    x_10_10         LINK_15_10      -1.0
    x_10_10         LINK_16_10      -1.0
    x_10_10         LINK_17_10      -1.0
    x_10_10         LINK_18_10      -1.0
    x_10_10         LINK_19_10      -1.0
    x_10_10         LINK_20_10      -1.0
    x_10_10         LINK_21_10      -1.0
    x_10_10         LINK_22_10      -1.0
    x_10_10         LINK_23_10      -1.0
    x_10_10         EDGE_10_11_10   1.0
    x_10_10         EDGE_10_14_10   1.0
    x_10_10         EDGE_10_17_10   1.0
    x_10_10         EDGE_10_20_10   1.0
    x_10_10         EDGE_10_23_10   1.0
    x_10_10         EDGE_11_15_10   -1.0
    x_10_10         EDGE_11_16_10   -1.0
    x_10_10         EDGE_11_17_10   -1.0
    x_10_10         EDGE_11_19_10   -1.0
    x_10_10         EDGE_12_15_10   -1.0
    x_10_10         EDGE_12_17_10   -1.0
    x_10_10         EDGE_12_19_10   -1.0
    x_10_10         EDGE_12_21_10   -1.0
    x_10_10         EDGE_12_23_10   -1.0
    x_10_10         EDGE_13_18_10   -1.0
    x_10_10         EDGE_13_19_10   -1.0
    x_10_10         EDGE_13_23_10   -1.0
    x_10_10         EDGE_14_16_10   -1.0
    x_10_10         EDGE_14_17_10   -1.0
    x_10_10         EDGE_14_19_10   -1.0
    x_10_10         EDGE_15_17_10   -1.0
    x_10_10         EDGE_15_18_10   -1.0
    x_10_10         EDGE_16_17_10   -1.0
    x_10_10         EDGE_16_18_10   -1.0
    x_10_10         EDGE_16_22_10   -1.0
    x_10_10         EDGE_16_23_10   -1.0
    x_10_10         EDGE_18_22_10   -1.0
    x_10_10         EDGE_19_21_10   -1.0
    x_10_10         EDGE_21_22_10   -1.0
    x_11_0          ASSIGN_11       1.0
    x_11_0          LINK_11_0       1.0
    x_11_0          EDGE_5_11_0     1.0
    x_11_0          EDGE_6_11_0     1.0
    x_11_0          EDGE_7_11_0     1.0
    x_11_0          EDGE_8_11_0     1.0
    x_11_0          EDGE_9_11_0     1.0
    x_11_0          EDGE_10_11_0    1.0
    x_11_0          EDGE_11_15_0    1.0
    x_11_0          EDGE_11_16_0    1.0
    x_11_0          EDGE_11_17_0    1.0
    x_11_0          EDGE_11_19_0    1.0
    x_11_1          ASSIGN_11       1.0
    x_11_1          LINK_11_1       1.0
    x_11_1          EDGE_5_11_1     1.0
    x_11_1          EDGE_6_11_1     1.0
    x_11_1          EDGE_7_11_1     1.0
    x_11_1          EDGE_8_11_1     1.0
    x_11_1          EDGE_9_11_1     1.0
    x_11_1          EDGE_10_11_1    1.0
    x_11_1          EDGE_11_15_1    1.0
    x_11_1          EDGE_11_16_1    1.0
    x_11_1          EDGE_11_17_1    1.0
    x_11_1          EDGE_11_19_1    1.0
    x_11_2          ASSIGN_11       1.0
    x_11_2          LINK_11_2       1.0
    x_11_2          EDGE_5_11_2     1.0
    x_11_2          EDGE_6_11_2     1.0
    x_11_2          EDGE_7_11_2     1.0
    x_11_2          EDGE_8_11_2     1.0
    x_11_2          EDGE_9_11_2     1.0
    x_11_2          EDGE_10_11_2    1.0
    x_11_2          EDGE_11_15_2    1.0
    x_11_2          EDGE_11_16_2    1.0
    x_11_2          EDGE_11_17_2    1.0
    x_11_2          EDGE_11_19_2    1.0
    x_11_3          ASSIGN_11       1.0
    x_11_3          LINK_11_3       1.0
    x_11_3          EDGE_5_11_3     1.0
    x_11_3          EDGE_6_11_3     1.0
    x_11_3          EDGE_7_11_3     1.0
    x_11_3          EDGE_8_11_3     1.0
    x_11_3          EDGE_9_11_3     1.0
    x_11_3          EDGE_10_11_3    1.0
    x_11_3          EDGE_11_15_3    1.0
    x_11_3          EDGE_11_16_3    1.0
    x_11_3          EDGE_11_17_3    1.0
    x_11_3          EDGE_11_19_3    1.0
    x_11_4          ASSIGN_11       1.0
    x_11_4          LINK_11_4       1.0
    x_11_4          EDGE_5_11_4     1.0
    x_11_4          EDGE_6_11_4     1.0
    x_11_4          EDGE_7_11_4     1.0
    x_11_4          EDGE_8_11_4     1.0
    x_11_4          EDGE_9_11_4     1.0
    x_11_4          EDGE_10_11_4    1.0
    x_11_4          EDGE_11_15_4    1.0
    x_11_4          EDGE_11_16_4    1.0
    x_11_4          EDGE_11_17_4    1.0
    x_11_4          EDGE_11_19_4    1.0
    x_11_5          ASSIGN_11       1.0
    x_11_5          LINK_11_5       1.0
    x_11_5          EDGE_5_11_5     1.0
    x_11_5          EDGE_6_11_5     1.0
    x_11_5          EDGE_7_11_5     1.0
    x_11_5          EDGE_8_11_5     1.0
    x_11_5          EDGE_9_11_5     1.0
    x_11_5          EDGE_10_11_5    1.0
    x_11_5          EDGE_11_15_5    1.0
    x_11_5          EDGE_11_16_5    1.0
    x_11_5          EDGE_11_17_5    1.0
    x_11_5          EDGE_11_19_5    1.0
    x_11_6          ASSIGN_11       1.0
    x_11_6          LINK_11_6       1.0
    x_11_6          EDGE_6_11_6     1.0
    x_11_6          EDGE_7_11_6     1.0
    x_11_6          EDGE_8_11_6     1.0
    x_11_6          EDGE_9_11_6     1.0
    x_11_6          EDGE_10_11_6    1.0
    x_11_6          EDGE_11_15_6    1.0
    x_11_6          EDGE_11_16_6    1.0
    x_11_6          EDGE_11_17_6    1.0
    x_11_6          EDGE_11_19_6    1.0
    x_11_7          ASSIGN_11       1.0
    x_11_7          LINK_11_7       1.0
    x_11_7          EDGE_7_11_7     1.0
    x_11_7          EDGE_8_11_7     1.0
    x_11_7          EDGE_9_11_7     1.0
    x_11_7          EDGE_10_11_7    1.0
    x_11_7          EDGE_11_15_7    1.0
    x_11_7          EDGE_11_16_7    1.0
    x_11_7          EDGE_11_17_7    1.0
    x_11_7          EDGE_11_19_7    1.0
    x_11_8          ASSIGN_11       1.0
    x_11_8          LINK_11_8       1.0
    x_11_8          EDGE_8_11_8     1.0
    x_11_8          EDGE_9_11_8     1.0
    x_11_8          EDGE_10_11_8    1.0
    x_11_8          EDGE_11_15_8    1.0
    x_11_8          EDGE_11_16_8    1.0
    x_11_8          EDGE_11_17_8    1.0
    x_11_8          EDGE_11_19_8    1.0
    x_11_9          ASSIGN_11       1.0
    x_11_9          LINK_11_9       1.0
    x_11_9          EDGE_9_11_9     1.0
    x_11_9          EDGE_10_11_9    1.0
    x_11_9          EDGE_11_15_9    1.0
    x_11_9          EDGE_11_16_9    1.0
    x_11_9          EDGE_11_17_9    1.0
    x_11_9          EDGE_11_19_9    1.0
    x_11_10         ASSIGN_11       1.0
    x_11_10         LINK_11_10      1.0
    x_11_10         EDGE_10_11_10   1.0
    x_11_10         EDGE_11_15_10   1.0
    x_11_10         EDGE_11_16_10   1.0
    x_11_10         EDGE_11_17_10   1.0
    x_11_10         EDGE_11_19_10   1.0
    x_11_11         OBJ           1.0
    x_11_11         ASSIGN_11       1.0
    x_11_11         LINK_12_11      -1.0
    x_11_11         LINK_13_11      -1.0
    x_11_11         LINK_14_11      -1.0
    x_11_11         LINK_15_11      -1.0
    x_11_11         LINK_16_11      -1.0
    x_11_11         LINK_17_11      -1.0
    x_11_11         LINK_18_11      -1.0
    x_11_11         LINK_19_11      -1.0
    x_11_11         LINK_20_11      -1.0
    x_11_11         LINK_21_11      -1.0
    x_11_11         LINK_22_11      -1.0
    x_11_11         LINK_23_11      -1.0
    x_11_11         EDGE_11_15_11   1.0
    x_11_11         EDGE_11_16_11   1.0
    x_11_11         EDGE_11_17_11   1.0
    x_11_11         EDGE_11_19_11   1.0
    x_11_11         EDGE_12_15_11   -1.0
    x_11_11         EDGE_12_17_11   -1.0
    x_11_11         EDGE_12_19_11   -1.0
    x_11_11         EDGE_12_21_11   -1.0
    x_11_11         EDGE_12_23_11   -1.0
    x_11_11         EDGE_13_18_11   -1.0
    x_11_11         EDGE_13_19_11   -1.0
    x_11_11         EDGE_13_23_11   -1.0
    x_11_11         EDGE_14_16_11   -1.0
    x_11_11         EDGE_14_17_11   -1.0
    x_11_11         EDGE_14_19_11   -1.0
    x_11_11         EDGE_15_17_11   -1.0
    x_11_11         EDGE_15_18_11   -1.0
    x_11_11         EDGE_16_17_11   -1.0
    x_11_11         EDGE_16_18_11   -1.0
    x_11_11         EDGE_16_22_11   -1.0
    x_11_11         EDGE_16_23_11   -1.0
    x_11_11         EDGE_18_22_11   -1.0
    x_11_11         EDGE_19_21_11   -1.0
    x_11_11         EDGE_21_22_11   -1.0
    x_12_0          ASSIGN_12       1.0
    x_12_0          LINK_12_0       1.0
    x_12_0          EDGE_0_12_0     1.0
    x_12_0          EDGE_3_12_0     1.0
    x_12_0          EDGE_6_12_0     1.0
    x_12_0          EDGE_7_12_0     1.0
    x_12_0          EDGE_9_12_0     1.0
    x_12_0          EDGE_12_15_0    1.0
    x_12_0          EDGE_12_17_0    1.0
    x_12_0          EDGE_12_19_0    1.0
    x_12_0          EDGE_12_21_0    1.0
    x_12_0          EDGE_12_23_0    1.0
    x_12_1          ASSIGN_12       1.0
    x_12_1          LINK_12_1       1.0
    x_12_1          EDGE_3_12_1     1.0
    x_12_1          EDGE_6_12_1     1.0
    x_12_1          EDGE_7_12_1     1.0
    x_12_1          EDGE_9_12_1     1.0
    x_12_1          EDGE_12_15_1    1.0
    x_12_1          EDGE_12_17_1    1.0
    x_12_1          EDGE_12_19_1    1.0
    x_12_1          EDGE_12_21_1    1.0
    x_12_1          EDGE_12_23_1    1.0
    x_12_2          ASSIGN_12       1.0
    x_12_2          LINK_12_2       1.0
    x_12_2          EDGE_3_12_2     1.0
    x_12_2          EDGE_6_12_2     1.0
    x_12_2          EDGE_7_12_2     1.0
    x_12_2          EDGE_9_12_2     1.0
    x_12_2          EDGE_12_15_2    1.0
    x_12_2          EDGE_12_17_2    1.0
    x_12_2          EDGE_12_19_2    1.0
    x_12_2          EDGE_12_21_2    1.0
    x_12_2          EDGE_12_23_2    1.0
    x_12_3          ASSIGN_12       1.0
    x_12_3          LINK_12_3       1.0
    x_12_3          EDGE_3_12_3     1.0
    x_12_3          EDGE_6_12_3     1.0
    x_12_3          EDGE_7_12_3     1.0
    x_12_3          EDGE_9_12_3     1.0
    x_12_3          EDGE_12_15_3    1.0
    x_12_3          EDGE_12_17_3    1.0
    x_12_3          EDGE_12_19_3    1.0
    x_12_3          EDGE_12_21_3    1.0
    x_12_3          EDGE_12_23_3    1.0
    x_12_4          ASSIGN_12       1.0
    x_12_4          LINK_12_4       1.0
    x_12_4          EDGE_6_12_4     1.0
    x_12_4          EDGE_7_12_4     1.0
    x_12_4          EDGE_9_12_4     1.0
    x_12_4          EDGE_12_15_4    1.0
    x_12_4          EDGE_12_17_4    1.0
    x_12_4          EDGE_12_19_4    1.0
    x_12_4          EDGE_12_21_4    1.0
    x_12_4          EDGE_12_23_4    1.0
    x_12_5          ASSIGN_12       1.0
    x_12_5          LINK_12_5       1.0
    x_12_5          EDGE_6_12_5     1.0
    x_12_5          EDGE_7_12_5     1.0
    x_12_5          EDGE_9_12_5     1.0
    x_12_5          EDGE_12_15_5    1.0
    x_12_5          EDGE_12_17_5    1.0
    x_12_5          EDGE_12_19_5    1.0
    x_12_5          EDGE_12_21_5    1.0
    x_12_5          EDGE_12_23_5    1.0
    x_12_6          ASSIGN_12       1.0
    x_12_6          LINK_12_6       1.0
    x_12_6          EDGE_6_12_6     1.0
    x_12_6          EDGE_7_12_6     1.0
    x_12_6          EDGE_9_12_6     1.0
    x_12_6          EDGE_12_15_6    1.0
    x_12_6          EDGE_12_17_6    1.0
    x_12_6          EDGE_12_19_6    1.0
    x_12_6          EDGE_12_21_6    1.0
    x_12_6          EDGE_12_23_6    1.0
    x_12_7          ASSIGN_12       1.0
    x_12_7          LINK_12_7       1.0
    x_12_7          EDGE_7_12_7     1.0
    x_12_7          EDGE_9_12_7     1.0
    x_12_7          EDGE_12_15_7    1.0
    x_12_7          EDGE_12_17_7    1.0
    x_12_7          EDGE_12_19_7    1.0
    x_12_7          EDGE_12_21_7    1.0
    x_12_7          EDGE_12_23_7    1.0
    x_12_8          ASSIGN_12       1.0
    x_12_8          LINK_12_8       1.0
    x_12_8          EDGE_9_12_8     1.0
    x_12_8          EDGE_12_15_8    1.0
    x_12_8          EDGE_12_17_8    1.0
    x_12_8          EDGE_12_19_8    1.0
    x_12_8          EDGE_12_21_8    1.0
    x_12_8          EDGE_12_23_8    1.0
    x_12_9          ASSIGN_12       1.0
    x_12_9          LINK_12_9       1.0
    x_12_9          EDGE_9_12_9     1.0
    x_12_9          EDGE_12_15_9    1.0
    x_12_9          EDGE_12_17_9    1.0
    x_12_9          EDGE_12_19_9    1.0
    x_12_9          EDGE_12_21_9    1.0
    x_12_9          EDGE_12_23_9    1.0
    x_12_10         ASSIGN_12       1.0
    x_12_10         LINK_12_10      1.0
    x_12_10         EDGE_12_15_10   1.0
    x_12_10         EDGE_12_17_10   1.0
    x_12_10         EDGE_12_19_10   1.0
    x_12_10         EDGE_12_21_10   1.0
    x_12_10         EDGE_12_23_10   1.0
    x_12_11         ASSIGN_12       1.0
    x_12_11         LINK_12_11      1.0
    x_12_11         EDGE_12_15_11   1.0
    x_12_11         EDGE_12_17_11   1.0
    x_12_11         EDGE_12_19_11   1.0
    x_12_11         EDGE_12_21_11   1.0
    x_12_11         EDGE_12_23_11   1.0
    x_12_12         OBJ           1.0
    x_12_12         ASSIGN_12       1.0
    x_12_12         LINK_13_12      -1.0
    x_12_12         LINK_14_12      -1.0
    x_12_12         LINK_15_12      -1.0
    x_12_12         LINK_16_12      -1.0
    x_12_12         LINK_17_12      -1.0
    x_12_12         LINK_18_12      -1.0
    x_12_12         LINK_19_12      -1.0
    x_12_12         LINK_20_12      -1.0
    x_12_12         LINK_21_12      -1.0
    x_12_12         LINK_22_12      -1.0
    x_12_12         LINK_23_12      -1.0
    x_12_12         EDGE_12_15_12   1.0
    x_12_12         EDGE_12_17_12   1.0
    x_12_12         EDGE_12_19_12   1.0
    x_12_12         EDGE_12_21_12   1.0
    x_12_12         EDGE_12_23_12   1.0
    x_12_12         EDGE_13_18_12   -1.0
    x_12_12         EDGE_13_19_12   -1.0
    x_12_12         EDGE_13_23_12   -1.0
    x_12_12         EDGE_14_16_12   -1.0
    x_12_12         EDGE_14_17_12   -1.0
    x_12_12         EDGE_14_19_12   -1.0
    x_12_12         EDGE_15_17_12   -1.0
    x_12_12         EDGE_15_18_12   -1.0
    x_12_12         EDGE_16_17_12   -1.0
    x_12_12         EDGE_16_18_12   -1.0
    x_12_12         EDGE_16_22_12   -1.0
    x_12_12         EDGE_16_23_12   -1.0
    x_12_12         EDGE_18_22_12   -1.0
    x_12_12         EDGE_19_21_12   -1.0
    x_12_12         EDGE_21_22_12   -1.0
    x_13_0          ASSIGN_13       1.0
    x_13_0          LINK_13_0       1.0
    x_13_0          EDGE_0_13_0     1.0
    x_13_0          EDGE_3_13_0     1.0
    x_13_0          EDGE_4_13_0     1.0
    x_13_0          EDGE_5_13_0     1.0
    x_13_0          EDGE_6_13_0     1.0
    x_13_0          EDGE_7_13_0     1.0
    x_13_0          EDGE_8_13_0     1.0
    x_13_0          EDGE_13_18_0    1.0
    x_13_0          EDGE_13_19_0    1.0
    x_13_0          EDGE_13_23_0    1.0
    x_13_1          ASSIGN_13       1.0
    x_13_1          LINK_13_1       1.0
    x_13_1          EDGE_3_13_1     1.0
    x_13_1          EDGE_4_13_1     1.0
    x_13_1          EDGE_5_13_1     1.0
    x_13_1          EDGE_6_13_1     1.0
    x_13_1          EDGE_7_13_1     1.0
    x_13_1          EDGE_8_13_1     1.0
    x_13_1          EDGE_13_18_1    1.0
    x_13_1          EDGE_13_19_1    1.0
    x_13_1          EDGE_13_23_1    1.0
    x_13_2          ASSIGN_13       1.0
    x_13_2          LINK_13_2       1.0
    x_13_2          EDGE_3_13_2     1.0
    x_13_2          EDGE_4_13_2     1.0
    x_13_2          EDGE_5_13_2     1.0
    x_13_2          EDGE_6_13_2     1.0
    x_13_2          EDGE_7_13_2     1.0
    x_13_2          EDGE_8_13_2     1.0
    x_13_2          EDGE_13_18_2    1.0
    x_13_2          EDGE_13_19_2    1.0
    x_13_2          EDGE_13_23_2    1.0
    x_13_3          ASSIGN_13       1.0
    x_13_3          LINK_13_3       1.0
    x_13_3          EDGE_3_13_3     1.0
    x_13_3          EDGE_4_13_3     1.0
    x_13_3          EDGE_5_13_3     1.0
    x_13_3          EDGE_6_13_3     1.0
    x_13_3          EDGE_7_13_3     1.0
    x_13_3          EDGE_8_13_3     1.0
    x_13_3          EDGE_13_18_3    1.0
    x_13_3          EDGE_13_19_3    1.0
    x_13_3          EDGE_13_23_3    1.0
    x_13_4          ASSIGN_13       1.0
    x_13_4          LINK_13_4       1.0
    x_13_4          EDGE_4_13_4     1.0
    x_13_4          EDGE_5_13_4     1.0
    x_13_4          EDGE_6_13_4     1.0
    x_13_4          EDGE_7_13_4     1.0
    x_13_4          EDGE_8_13_4     1.0
    x_13_4          EDGE_13_18_4    1.0
    x_13_4          EDGE_13_19_4    1.0
    x_13_4          EDGE_13_23_4    1.0
    x_13_5          ASSIGN_13       1.0
    x_13_5          LINK_13_5       1.0
    x_13_5          EDGE_5_13_5     1.0
    x_13_5          EDGE_6_13_5     1.0
    x_13_5          EDGE_7_13_5     1.0
    x_13_5          EDGE_8_13_5     1.0
    x_13_5          EDGE_13_18_5    1.0
    x_13_5          EDGE_13_19_5    1.0
    x_13_5          EDGE_13_23_5    1.0
    x_13_6          ASSIGN_13       1.0
    x_13_6          LINK_13_6       1.0
    x_13_6          EDGE_6_13_6     1.0
    x_13_6          EDGE_7_13_6     1.0
    x_13_6          EDGE_8_13_6     1.0
    x_13_6          EDGE_13_18_6    1.0
    x_13_6          EDGE_13_19_6    1.0
    x_13_6          EDGE_13_23_6    1.0
    x_13_7          ASSIGN_13       1.0
    x_13_7          LINK_13_7       1.0
    x_13_7          EDGE_7_13_7     1.0
    x_13_7          EDGE_8_13_7     1.0
    x_13_7          EDGE_13_18_7    1.0
    x_13_7          EDGE_13_19_7    1.0
    x_13_7          EDGE_13_23_7    1.0
    x_13_8          ASSIGN_13       1.0
    x_13_8          LINK_13_8       1.0
    x_13_8          EDGE_8_13_8     1.0
    x_13_8          EDGE_13_18_8    1.0
    x_13_8          EDGE_13_19_8    1.0
    x_13_8          EDGE_13_23_8    1.0
    x_13_9          ASSIGN_13       1.0
    x_13_9          LINK_13_9       1.0
    x_13_9          EDGE_13_18_9    1.0
    x_13_9          EDGE_13_19_9    1.0
    x_13_9          EDGE_13_23_9    1.0
    x_13_10         ASSIGN_13       1.0
    x_13_10         LINK_13_10      1.0
    x_13_10         EDGE_13_18_10   1.0
    x_13_10         EDGE_13_19_10   1.0
    x_13_10         EDGE_13_23_10   1.0
    x_13_11         ASSIGN_13       1.0
    x_13_11         LINK_13_11      1.0
    x_13_11         EDGE_13_18_11   1.0
    x_13_11         EDGE_13_19_11   1.0
    x_13_11         EDGE_13_23_11   1.0
    x_13_12         ASSIGN_13       1.0
    x_13_12         LINK_13_12      1.0
    x_13_12         EDGE_13_18_12   1.0
    x_13_12         EDGE_13_19_12   1.0
    x_13_12         EDGE_13_23_12   1.0
    x_13_13         OBJ           1.0
    x_13_13         ASSIGN_13       1.0
    x_13_13         LINK_14_13      -1.0
    x_13_13         LINK_15_13      -1.0
    x_13_13         LINK_16_13      -1.0
    x_13_13         LINK_17_13      -1.0
    x_13_13         LINK_18_13      -1.0
    x_13_13         LINK_19_13      -1.0
    x_13_13         LINK_20_13      -1.0
    x_13_13         LINK_21_13      -1.0
    x_13_13         LINK_22_13      -1.0
    x_13_13         LINK_23_13      -1.0
    x_13_13         EDGE_13_18_13   1.0
    x_13_13         EDGE_13_19_13   1.0
    x_13_13         EDGE_13_23_13   1.0
    x_13_13         EDGE_14_16_13   -1.0
    x_13_13         EDGE_14_17_13   -1.0
    x_13_13         EDGE_14_19_13   -1.0
    x_13_13         EDGE_15_17_13   -1.0
    x_13_13         EDGE_15_18_13   -1.0
    x_13_13         EDGE_16_17_13   -1.0
    x_13_13         EDGE_16_18_13   -1.0
    x_13_13         EDGE_16_22_13   -1.0
    x_13_13         EDGE_16_23_13   -1.0
    x_13_13         EDGE_18_22_13   -1.0
    x_13_13         EDGE_19_21_13   -1.0
    x_13_13         EDGE_21_22_13   -1.0
    x_14_0          ASSIGN_14       1.0
    x_14_0          LINK_14_0       1.0
    x_14_0          EDGE_0_14_0     1.0
    x_14_0          EDGE_3_14_0     1.0
    x_14_0          EDGE_5_14_0     1.0
    x_14_0          EDGE_6_14_0     1.0
    x_14_0          EDGE_8_14_0     1.0
    x_14_0          EDGE_9_14_0     1.0
    x_14_0          EDGE_10_14_0    1.0
    x_14_0          EDGE_14_16_0    1.0
    x_14_0          EDGE_14_17_0    1.0
    x_14_0          EDGE_14_19_0    1.0
    x_14_1          ASSIGN_14       1.0
    x_14_1          LINK_14_1       1.0
    x_14_1          EDGE_3_14_1     1.0
    x_14_1          EDGE_5_14_1     1.0
    x_14_1          EDGE_6_14_1     1.0
    x_14_1          EDGE_8_14_1     1.0
    x_14_1          EDGE_9_14_1     1.0
    x_14_1          EDGE_10_14_1    1.0
    x_14_1          EDGE_14_16_1    1.0
    x_14_1          EDGE_14_17_1    1.0
    x_14_1          EDGE_14_19_1    1.0
    x_14_2          ASSIGN_14       1.0
    x_14_2          LINK_14_2       1.0
    x_14_2          EDGE_3_14_2     1.0
    x_14_2          EDGE_5_14_2     1.0
    x_14_2          EDGE_6_14_2     1.0
    x_14_2          EDGE_8_14_2     1.0
    x_14_2          EDGE_9_14_2     1.0
    x_14_2          EDGE_10_14_2    1.0
    x_14_2          EDGE_14_16_2    1.0
    x_14_2          EDGE_14_17_2    1.0
    x_14_2          EDGE_14_19_2    1.0
    x_14_3          ASSIGN_14       1.0
    x_14_3          LINK_14_3       1.0
    x_14_3          EDGE_3_14_3     1.0
    x_14_3          EDGE_5_14_3     1.0
    x_14_3          EDGE_6_14_3     1.0
    x_14_3          EDGE_8_14_3     1.0
    x_14_3          EDGE_9_14_3     1.0
    x_14_3          EDGE_10_14_3    1.0
    x_14_3          EDGE_14_16_3    1.0
    x_14_3          EDGE_14_17_3    1.0
    x_14_3          EDGE_14_19_3    1.0
    x_14_4          ASSIGN_14       1.0
    x_14_4          LINK_14_4       1.0
    x_14_4          EDGE_5_14_4     1.0
    x_14_4          EDGE_6_14_4     1.0
    x_14_4          EDGE_8_14_4     1.0
    x_14_4          EDGE_9_14_4     1.0
    x_14_4          EDGE_10_14_4    1.0
    x_14_4          EDGE_14_16_4    1.0
    x_14_4          EDGE_14_17_4    1.0
    x_14_4          EDGE_14_19_4    1.0
    x_14_5          ASSIGN_14       1.0
    x_14_5          LINK_14_5       1.0
    x_14_5          EDGE_5_14_5     1.0
    x_14_5          EDGE_6_14_5     1.0
    x_14_5          EDGE_8_14_5     1.0
    x_14_5          EDGE_9_14_5     1.0
    x_14_5          EDGE_10_14_5    1.0
    x_14_5          EDGE_14_16_5    1.0
    x_14_5          EDGE_14_17_5    1.0
    x_14_5          EDGE_14_19_5    1.0
    x_14_6          ASSIGN_14       1.0
    x_14_6          LINK_14_6       1.0
    x_14_6          EDGE_6_14_6     1.0
    x_14_6          EDGE_8_14_6     1.0
    x_14_6          EDGE_9_14_6     1.0
    x_14_6          EDGE_10_14_6    1.0
    x_14_6          EDGE_14_16_6    1.0
    x_14_6          EDGE_14_17_6    1.0
    x_14_6          EDGE_14_19_6    1.0
    x_14_7          ASSIGN_14       1.0
    x_14_7          LINK_14_7       1.0
    x_14_7          EDGE_8_14_7     1.0
    x_14_7          EDGE_9_14_7     1.0
    x_14_7          EDGE_10_14_7    1.0
    x_14_7          EDGE_14_16_7    1.0
    x_14_7          EDGE_14_17_7    1.0
    x_14_7          EDGE_14_19_7    1.0
    x_14_8          ASSIGN_14       1.0
    x_14_8          LINK_14_8       1.0
    x_14_8          EDGE_8_14_8     1.0
    x_14_8          EDGE_9_14_8     1.0
    x_14_8          EDGE_10_14_8    1.0
    x_14_8          EDGE_14_16_8    1.0
    x_14_8          EDGE_14_17_8    1.0
    x_14_8          EDGE_14_19_8    1.0
    x_14_9          ASSIGN_14       1.0
    x_14_9          LINK_14_9       1.0
    x_14_9          EDGE_9_14_9     1.0
    x_14_9          EDGE_10_14_9    1.0
    x_14_9          EDGE_14_16_9    1.0
    x_14_9          EDGE_14_17_9    1.0
    x_14_9          EDGE_14_19_9    1.0
    x_14_10         ASSIGN_14       1.0
    x_14_10         LINK_14_10      1.0
    x_14_10         EDGE_10_14_10   1.0
    x_14_10         EDGE_14_16_10   1.0
    x_14_10         EDGE_14_17_10   1.0
    x_14_10         EDGE_14_19_10   1.0
    x_14_11         ASSIGN_14       1.0
    x_14_11         LINK_14_11      1.0
    x_14_11         EDGE_14_16_11   1.0
    x_14_11         EDGE_14_17_11   1.0
    x_14_11         EDGE_14_19_11   1.0
    x_14_12         ASSIGN_14       1.0
    x_14_12         LINK_14_12      1.0
    x_14_12         EDGE_14_16_12   1.0
    x_14_12         EDGE_14_17_12   1.0
    x_14_12         EDGE_14_19_12   1.0
    x_14_13         ASSIGN_14       1.0
    x_14_13         LINK_14_13      1.0
    x_14_13         EDGE_14_16_13   1.0
    x_14_13         EDGE_14_17_13   1.0
    x_14_13         EDGE_14_19_13   1.0
    x_14_14         OBJ           1.0
    x_14_14         ASSIGN_14       1.0
    x_14_14         LINK_15_14      -1.0
    x_14_14         LINK_16_14      -1.0
    x_14_14         LINK_17_14      -1.0
    x_14_14         LINK_18_14      -1.0
    x_14_14         LINK_19_14      -1.0
    x_14_14         LINK_20_14      -1.0
    x_14_14         LINK_21_14      -1.0
    x_14_14         LINK_22_14      -1.0
    x_14_14         LINK_23_14      -1.0
    x_14_14         EDGE_14_16_14   1.0
    x_14_14         EDGE_14_17_14   1.0
    x_14_14         EDGE_14_19_14   1.0
    x_14_14         EDGE_15_17_14   -1.0
    x_14_14         EDGE_15_18_14   -1.0
    x_14_14         EDGE_16_17_14   -1.0
    x_14_14         EDGE_16_18_14   -1.0
    x_14_14         EDGE_16_22_14   -1.0
    x_14_14         EDGE_16_23_14   -1.0
    x_14_14         EDGE_18_22_14   -1.0
    x_14_14         EDGE_19_21_14   -1.0
    x_14_14         EDGE_21_22_14   -1.0
    x_15_0          ASSIGN_15       1.0
    x_15_0          LINK_15_0       1.0
    x_15_0          EDGE_1_15_0     1.0
    x_15_0          EDGE_2_15_0     1.0
    x_15_0          EDGE_3_15_0     1.0
    x_15_0          EDGE_6_15_0     1.0
    x_15_0          EDGE_7_15_0     1.0
    x_15_0          EDGE_11_15_0    1.0
    x_15_0          EDGE_12_15_0    1.0
    x_15_0          EDGE_15_17_0    1.0
    x_15_0          EDGE_15_18_0    1.0
    x_15_1          ASSIGN_15       1.0
    x_15_1          LINK_15_1       1.0
    x_15_1          EDGE_1_15_1     1.0
    x_15_1          EDGE_2_15_1     1.0
    x_15_1          EDGE_3_15_1     1.0
    x_15_1          EDGE_6_15_1     1.0
    x_15_1          EDGE_7_15_1     1.0
    x_15_1          EDGE_11_15_1    1.0
    x_15_1          EDGE_12_15_1    1.0
    x_15_1          EDGE_15_17_1    1.0
    x_15_1          EDGE_15_18_1    1.0
    x_15_2          ASSIGN_15       1.0
    x_15_2          LINK_15_2       1.0
    x_15_2          EDGE_2_15_2     1.0
    x_15_2          EDGE_3_15_2     1.0
    x_15_2          EDGE_6_15_2     1.0
    x_15_2          EDGE_7_15_2     1.0
    x_15_2          EDGE_11_15_2    1.0
    x_15_2          EDGE_12_15_2    1.0
    x_15_2          EDGE_15_17_2    1.0
    x_15_2          EDGE_15_18_2    1.0
    x_15_3          ASSIGN_15       1.0
    x_15_3          LINK_15_3       1.0
    x_15_3          EDGE_3_15_3     1.0
    x_15_3          EDGE_6_15_3     1.0
    x_15_3          EDGE_7_15_3     1.0
    x_15_3          EDGE_11_15_3    1.0
    x_15_3          EDGE_12_15_3    1.0
    x_15_3          EDGE_15_17_3    1.0
    x_15_3          EDGE_15_18_3    1.0
    x_15_4          ASSIGN_15       1.0
    x_15_4          LINK_15_4       1.0
    x_15_4          EDGE_6_15_4     1.0
    x_15_4          EDGE_7_15_4     1.0
    x_15_4          EDGE_11_15_4    1.0
    x_15_4          EDGE_12_15_4    1.0
    x_15_4          EDGE_15_17_4    1.0
    x_15_4          EDGE_15_18_4    1.0
    x_15_5          ASSIGN_15       1.0
    x_15_5          LINK_15_5       1.0
    x_15_5          EDGE_6_15_5     1.0
    x_15_5          EDGE_7_15_5     1.0
    x_15_5          EDGE_11_15_5    1.0
    x_15_5          EDGE_12_15_5    1.0
    x_15_5          EDGE_15_17_5    1.0
    x_15_5          EDGE_15_18_5    1.0
    x_15_6          ASSIGN_15       1.0
    x_15_6          LINK_15_6       1.0
    x_15_6          EDGE_6_15_6     1.0
    x_15_6          EDGE_7_15_6     1.0
    x_15_6          EDGE_11_15_6    1.0
    x_15_6          EDGE_12_15_6    1.0
    x_15_6          EDGE_15_17_6    1.0
    x_15_6          EDGE_15_18_6    1.0
    x_15_7          ASSIGN_15       1.0
    x_15_7          LINK_15_7       1.0
    x_15_7          EDGE_7_15_7     1.0
    x_15_7          EDGE_11_15_7    1.0
    x_15_7          EDGE_12_15_7    1.0
    x_15_7          EDGE_15_17_7    1.0
    x_15_7          EDGE_15_18_7    1.0
    x_15_8          ASSIGN_15       1.0
    x_15_8          LINK_15_8       1.0
    x_15_8          EDGE_11_15_8    1.0
    x_15_8          EDGE_12_15_8    1.0
    x_15_8          EDGE_15_17_8    1.0
    x_15_8          EDGE_15_18_8    1.0
    x_15_9          ASSIGN_15       1.0
    x_15_9          LINK_15_9       1.0
    x_15_9          EDGE_11_15_9    1.0
    x_15_9          EDGE_12_15_9    1.0
    x_15_9          EDGE_15_17_9    1.0
    x_15_9          EDGE_15_18_9    1.0
    x_15_10         ASSIGN_15       1.0
    x_15_10         LINK_15_10      1.0
    x_15_10         EDGE_11_15_10   1.0
    x_15_10         EDGE_12_15_10   1.0
    x_15_10         EDGE_15_17_10   1.0
    x_15_10         EDGE_15_18_10   1.0
    x_15_11         ASSIGN_15       1.0
    x_15_11         LINK_15_11      1.0
    x_15_11         EDGE_11_15_11   1.0
    x_15_11         EDGE_12_15_11   1.0
    x_15_11         EDGE_15_17_11   1.0
    x_15_11         EDGE_15_18_11   1.0
    x_15_12         ASSIGN_15       1.0
    x_15_12         LINK_15_12      1.0
    x_15_12         EDGE_12_15_12   1.0
    x_15_12         EDGE_15_17_12   1.0
    x_15_12         EDGE_15_18_12   1.0
    x_15_13         ASSIGN_15       1.0
    x_15_13         LINK_15_13      1.0
    x_15_13         EDGE_15_17_13   1.0
    x_15_13         EDGE_15_18_13   1.0
    x_15_14         ASSIGN_15       1.0
    x_15_14         LINK_15_14      1.0
    x_15_14         EDGE_15_17_14   1.0
    x_15_14         EDGE_15_18_14   1.0
    x_15_15         OBJ           1.0
    x_15_15         ASSIGN_15       1.0
    x_15_15         LINK_16_15      -1.0
    x_15_15         LINK_17_15      -1.0
    x_15_15         LINK_18_15      -1.0
    x_15_15         LINK_19_15      -1.0
    x_15_15         LINK_20_15      -1.0
    x_15_15         LINK_21_15      -1.0
    x_15_15         LINK_22_15      -1.0
    x_15_15         LINK_23_15      -1.0
    x_15_15         EDGE_15_17_15   1.0
    x_15_15         EDGE_15_18_15   1.0
    x_15_15         EDGE_16_17_15   -1.0
    x_15_15         EDGE_16_18_15   -1.0
    x_15_15         EDGE_16_22_15   -1.0
    x_15_15         EDGE_16_23_15   -1.0
    x_15_15         EDGE_18_22_15   -1.0
    x_15_15         EDGE_19_21_15   -1.0
    x_15_15         EDGE_21_22_15   -1.0
    x_16_0          ASSIGN_16       1.0
    x_16_0          LINK_16_0       1.0
    x_16_0          EDGE_1_16_0     1.0
    x_16_0          EDGE_2_16_0     1.0
    x_16_0          EDGE_7_16_0     1.0
    x_16_0          EDGE_11_16_0    1.0
    x_16_0          EDGE_14_16_0    1.0
    x_16_0          EDGE_16_17_0    1.0
    x_16_0          EDGE_16_18_0    1.0
    x_16_0          EDGE_16_22_0    1.0
    x_16_0          EDGE_16_23_0    1.0
    x_16_1          ASSIGN_16       1.0
    x_16_1          LINK_16_1       1.0
    x_16_1          EDGE_1_16_1     1.0
    x_16_1          EDGE_2_16_1     1.0
    x_16_1          EDGE_7_16_1     1.0
    x_16_1          EDGE_11_16_1    1.0
    x_16_1          EDGE_14_16_1    1.0
    x_16_1          EDGE_16_17_1    1.0
    x_16_1          EDGE_16_18_1    1.0
    x_16_1          EDGE_16_22_1    1.0
    x_16_1          EDGE_16_23_1    1.0
    x_16_2          ASSIGN_16       1.0
    x_16_2          LINK_16_2       1.0
    x_16_2          EDGE_2_16_2     1.0
    x_16_2          EDGE_7_16_2     1.0
    x_16_2          EDGE_11_16_2    1.0
    x_16_2          EDGE_14_16_2    1.0
    x_16_2          EDGE_16_17_2    1.0
    x_16_2          EDGE_16_18_2    1.0
    x_16_2          EDGE_16_22_2    1.0
    x_16_2          EDGE_16_23_2    1.0
    x_16_3          ASSIGN_16       1.0
    x_16_3          LINK_16_3       1.0
    x_16_3          EDGE_7_16_3     1.0
    x_16_3          EDGE_11_16_3    1.0
    x_16_3          EDGE_14_16_3    1.0
    x_16_3          EDGE_16_17_3    1.0
    x_16_3          EDGE_16_18_3    1.0
    x_16_3          EDGE_16_22_3    1.0
    x_16_3          EDGE_16_23_3    1.0
    x_16_4          ASSIGN_16       1.0
    x_16_4          LINK_16_4       1.0
    x_16_4          EDGE_7_16_4     1.0
    x_16_4          EDGE_11_16_4    1.0
    x_16_4          EDGE_14_16_4    1.0
    x_16_4          EDGE_16_17_4    1.0
    x_16_4          EDGE_16_18_4    1.0
    x_16_4          EDGE_16_22_4    1.0
    x_16_4          EDGE_16_23_4    1.0
    x_16_5          ASSIGN_16       1.0
    x_16_5          LINK_16_5       1.0
    x_16_5          EDGE_7_16_5     1.0
    x_16_5          EDGE_11_16_5    1.0
    x_16_5          EDGE_14_16_5    1.0
    x_16_5          EDGE_16_17_5    1.0
    x_16_5          EDGE_16_18_5    1.0
    x_16_5          EDGE_16_22_5    1.0
    x_16_5          EDGE_16_23_5    1.0
    x_16_6          ASSIGN_16       1.0
    x_16_6          LINK_16_6       1.0
    x_16_6          EDGE_7_16_6     1.0
    x_16_6          EDGE_11_16_6    1.0
    x_16_6          EDGE_14_16_6    1.0
    x_16_6          EDGE_16_17_6    1.0
    x_16_6          EDGE_16_18_6    1.0
    x_16_6          EDGE_16_22_6    1.0
    x_16_6          EDGE_16_23_6    1.0
    x_16_7          ASSIGN_16       1.0
    x_16_7          LINK_16_7       1.0
    x_16_7          EDGE_7_16_7     1.0
    x_16_7          EDGE_11_16_7    1.0
    x_16_7          EDGE_14_16_7    1.0
    x_16_7          EDGE_16_17_7    1.0
    x_16_7          EDGE_16_18_7    1.0
    x_16_7          EDGE_16_22_7    1.0
    x_16_7          EDGE_16_23_7    1.0
    x_16_8          ASSIGN_16       1.0
    x_16_8          LINK_16_8       1.0
    x_16_8          EDGE_11_16_8    1.0
    x_16_8          EDGE_14_16_8    1.0
    x_16_8          EDGE_16_17_8    1.0
    x_16_8          EDGE_16_18_8    1.0
    x_16_8          EDGE_16_22_8    1.0
    x_16_8          EDGE_16_23_8    1.0
    x_16_9          ASSIGN_16       1.0
    x_16_9          LINK_16_9       1.0
    x_16_9          EDGE_11_16_9    1.0
    x_16_9          EDGE_14_16_9    1.0
    x_16_9          EDGE_16_17_9    1.0
    x_16_9          EDGE_16_18_9    1.0
    x_16_9          EDGE_16_22_9    1.0
    x_16_9          EDGE_16_23_9    1.0
    x_16_10         ASSIGN_16       1.0
    x_16_10         LINK_16_10      1.0
    x_16_10         EDGE_11_16_10   1.0
    x_16_10         EDGE_14_16_10   1.0
    x_16_10         EDGE_16_17_10   1.0
    x_16_10         EDGE_16_18_10   1.0
    x_16_10         EDGE_16_22_10   1.0
    x_16_10         EDGE_16_23_10   1.0
    x_16_11         ASSIGN_16       1.0
    x_16_11         LINK_16_11      1.0
    x_16_11         EDGE_11_16_11   1.0
    x_16_11         EDGE_14_16_11   1.0
    x_16_11         EDGE_16_17_11   1.0
    x_16_11         EDGE_16_18_11   1.0
    x_16_11         EDGE_16_22_11   1.0
    x_16_11         EDGE_16_23_11   1.0
    x_16_12         ASSIGN_16       1.0
    x_16_12         LINK_16_12      1.0
    x_16_12         EDGE_14_16_12   1.0
    x_16_12         EDGE_16_17_12   1.0
    x_16_12         EDGE_16_18_12   1.0
    x_16_12         EDGE_16_22_12   1.0
    x_16_12         EDGE_16_23_12   1.0
    x_16_13         ASSIGN_16       1.0
    x_16_13         LINK_16_13      1.0
    x_16_13         EDGE_14_16_13   1.0
    x_16_13         EDGE_16_17_13   1.0
    x_16_13         EDGE_16_18_13   1.0
    x_16_13         EDGE_16_22_13   1.0
    x_16_13         EDGE_16_23_13   1.0
    x_16_14         ASSIGN_16       1.0
    x_16_14         LINK_16_14      1.0
    x_16_14         EDGE_14_16_14   1.0
    x_16_14         EDGE_16_17_14   1.0
    x_16_14         EDGE_16_18_14   1.0
    x_16_14         EDGE_16_22_14   1.0
    x_16_14         EDGE_16_23_14   1.0
    x_16_15         ASSIGN_16       1.0
    x_16_15         LINK_16_15      1.0
    x_16_15         EDGE_16_17_15   1.0
    x_16_15         EDGE_16_18_15   1.0
    x_16_15         EDGE_16_22_15   1.0
    x_16_15         EDGE_16_23_15   1.0
    x_16_16         OBJ           1.0
    x_16_16         ASSIGN_16       1.0
    x_16_16         LINK_17_16      -1.0
    x_16_16         LINK_18_16      -1.0
    x_16_16         LINK_19_16      -1.0
    x_16_16         LINK_20_16      -1.0
    x_16_16         LINK_21_16      -1.0
    x_16_16         LINK_22_16      -1.0
    x_16_16         LINK_23_16      -1.0
    x_16_16         EDGE_16_17_16   1.0
    x_16_16         EDGE_16_18_16   1.0
    x_16_16         EDGE_16_22_16   1.0
    x_16_16         EDGE_16_23_16   1.0
    x_16_16         EDGE_18_22_16   -1.0
    x_16_16         EDGE_19_21_16   -1.0
    x_16_16         EDGE_21_22_16   -1.0
    x_17_0          ASSIGN_17       1.0
    x_17_0          LINK_17_0       1.0
    x_17_0          EDGE_8_17_0     1.0
    x_17_0          EDGE_9_17_0     1.0
    x_17_0          EDGE_10_17_0    1.0
    x_17_0          EDGE_11_17_0    1.0
    x_17_0          EDGE_12_17_0    1.0
    x_17_0          EDGE_14_17_0    1.0
    x_17_0          EDGE_15_17_0    1.0
    x_17_0          EDGE_16_17_0    1.0
    x_17_1          ASSIGN_17       1.0
    x_17_1          LINK_17_1       1.0
    x_17_1          EDGE_8_17_1     1.0
    x_17_1          EDGE_9_17_1     1.0
    x_17_1          EDGE_10_17_1    1.0
    x_17_1          EDGE_11_17_1    1.0
    x_17_1          EDGE_12_17_1    1.0
    x_17_1          EDGE_14_17_1    1.0
    x_17_1          EDGE_15_17_1    1.0
    x_17_1          EDGE_16_17_1    1.0
    x_17_2          ASSIGN_17       1.0
    x_17_2          LINK_17_2       1.0
    x_17_2          EDGE_8_17_2     1.0
    x_17_2          EDGE_9_17_2     1.0
    x_17_2          EDGE_10_17_2    1.0
    x_17_2          EDGE_11_17_2    1.0
    x_17_2          EDGE_12_17_2    1.0
    x_17_2          EDGE_14_17_2    1.0
    x_17_2          EDGE_15_17_2    1.0
    x_17_2          EDGE_16_17_2    1.0
    x_17_3          ASSIGN_17       1.0
    x_17_3          LINK_17_3       1.0
    x_17_3          EDGE_8_17_3     1.0
    x_17_3          EDGE_9_17_3     1.0
    x_17_3          EDGE_10_17_3    1.0
    x_17_3          EDGE_11_17_3    1.0
    x_17_3          EDGE_12_17_3    1.0
    x_17_3          EDGE_14_17_3    1.0
    x_17_3          EDGE_15_17_3    1.0
    x_17_3          EDGE_16_17_3    1.0
    x_17_4          ASSIGN_17       1.0
    x_17_4          LINK_17_4       1.0
    x_17_4          EDGE_8_17_4     1.0
    x_17_4          EDGE_9_17_4     1.0
    x_17_4          EDGE_10_17_4    1.0
    x_17_4          EDGE_11_17_4    1.0
    x_17_4          EDGE_12_17_4    1.0
    x_17_4          EDGE_14_17_4    1.0
    x_17_4          EDGE_15_17_4    1.0
    x_17_4          EDGE_16_17_4    1.0
    x_17_5          ASSIGN_17       1.0
    x_17_5          LINK_17_5       1.0
    x_17_5          EDGE_8_17_5     1.0
    x_17_5          EDGE_9_17_5     1.0
    x_17_5          EDGE_10_17_5    1.0
    x_17_5          EDGE_11_17_5    1.0
    x_17_5          EDGE_12_17_5    1.0
    x_17_5          EDGE_14_17_5    1.0
    x_17_5          EDGE_15_17_5    1.0
    x_17_5          EDGE_16_17_5    1.0
    x_17_6          ASSIGN_17       1.0
    x_17_6          LINK_17_6       1.0
    x_17_6          EDGE_8_17_6     1.0
    x_17_6          EDGE_9_17_6     1.0
    x_17_6          EDGE_10_17_6    1.0
    x_17_6          EDGE_11_17_6    1.0
    x_17_6          EDGE_12_17_6    1.0
    x_17_6          EDGE_14_17_6    1.0
    x_17_6          EDGE_15_17_6    1.0
    x_17_6          EDGE_16_17_6    1.0
    x_17_7          ASSIGN_17       1.0
    x_17_7          LINK_17_7       1.0
    x_17_7          EDGE_8_17_7     1.0
    x_17_7          EDGE_9_17_7     1.0
    x_17_7          EDGE_10_17_7    1.0
    x_17_7          EDGE_11_17_7    1.0
    x_17_7          EDGE_12_17_7    1.0
    x_17_7          EDGE_14_17_7    1.0
    x_17_7          EDGE_15_17_7    1.0
    x_17_7          EDGE_16_17_7    1.0
    x_17_8          ASSIGN_17       1.0
    x_17_8          LINK_17_8       1.0
    x_17_8          EDGE_8_17_8     1.0
    x_17_8          EDGE_9_17_8     1.0
    x_17_8          EDGE_10_17_8    1.0
    x_17_8          EDGE_11_17_8    1.0
    x_17_8          EDGE_12_17_8    1.0
    x_17_8          EDGE_14_17_8    1.0
    x_17_8          EDGE_15_17_8    1.0
    x_17_8          EDGE_16_17_8    1.0
    x_17_9          ASSIGN_17       1.0
    x_17_9          LINK_17_9       1.0
    x_17_9          EDGE_9_17_9     1.0
    x_17_9          EDGE_10_17_9    1.0
    x_17_9          EDGE_11_17_9    1.0
    x_17_9          EDGE_12_17_9    1.0
    x_17_9          EDGE_14_17_9    1.0
    x_17_9          EDGE_15_17_9    1.0
    x_17_9          EDGE_16_17_9    1.0
    x_17_10         ASSIGN_17       1.0
    x_17_10         LINK_17_10      1.0
    x_17_10         EDGE_10_17_10   1.0
    x_17_10         EDGE_11_17_10   1.0
    x_17_10         EDGE_12_17_10   1.0
    x_17_10         EDGE_14_17_10   1.0
    x_17_10         EDGE_15_17_10   1.0
    x_17_10         EDGE_16_17_10   1.0
    x_17_11         ASSIGN_17       1.0
    x_17_11         LINK_17_11      1.0
    x_17_11         EDGE_11_17_11   1.0
    x_17_11         EDGE_12_17_11   1.0
    x_17_11         EDGE_14_17_11   1.0
    x_17_11         EDGE_15_17_11   1.0
    x_17_11         EDGE_16_17_11   1.0
    x_17_12         ASSIGN_17       1.0
    x_17_12         LINK_17_12      1.0
    x_17_12         EDGE_12_17_12   1.0
    x_17_12         EDGE_14_17_12   1.0
    x_17_12         EDGE_15_17_12   1.0
    x_17_12         EDGE_16_17_12   1.0
    x_17_13         ASSIGN_17       1.0
    x_17_13         LINK_17_13      1.0
    x_17_13         EDGE_14_17_13   1.0
    x_17_13         EDGE_15_17_13   1.0
    x_17_13         EDGE_16_17_13   1.0
    x_17_14         ASSIGN_17       1.0
    x_17_14         LINK_17_14      1.0
    x_17_14         EDGE_14_17_14   1.0
    x_17_14         EDGE_15_17_14   1.0
    x_17_14         EDGE_16_17_14   1.0
    x_17_15         ASSIGN_17       1.0
    x_17_15         LINK_17_15      1.0
    x_17_15         EDGE_15_17_15   1.0
    x_17_15         EDGE_16_17_15   1.0
    x_17_16         ASSIGN_17       1.0
    x_17_16         LINK_17_16      1.0
    x_17_16         EDGE_16_17_16   1.0
    x_17_17         OBJ           1.0
    x_17_17         ASSIGN_17       1.0
    x_17_17         LINK_18_17      -1.0
    x_17_17         LINK_19_17      -1.0
    x_17_17         LINK_20_17      -1.0
    x_17_17         LINK_21_17      -1.0
    x_17_17         LINK_22_17      -1.0
    x_17_17         LINK_23_17      -1.0
    x_17_17         EDGE_18_22_17   -1.0
    x_17_17         EDGE_19_21_17   -1.0
    x_17_17         EDGE_21_22_17   -1.0
    x_18_0          ASSIGN_18       1.0
    x_18_0          LINK_18_0       1.0
    x_18_0          EDGE_0_18_0     1.0
    x_18_0          EDGE_1_18_0     1.0
    x_18_0          EDGE_2_18_0     1.0
    x_18_0          EDGE_5_18_0     1.0
    x_18_0          EDGE_13_18_0    1.0
    x_18_0          EDGE_15_18_0    1.0
    x_18_0          EDGE_16_18_0    1.0
    x_18_0          EDGE_18_22_0    1.0
    x_18_1          ASSIGN_18       1.0
    x_18_1          LINK_18_1       1.0
    x_18_1          EDGE_1_18_1     1.0
    x_18_1          EDGE_2_18_1     1.0
    x_18_1          EDGE_5_18_1     1.0
    x_18_1          EDGE_13_18_1    1.0
    x_18_1          EDGE_15_18_1    1.0
    x_18_1          EDGE_16_18_1    1.0
    x_18_1          EDGE_18_22_1    1.0
    x_18_2          ASSIGN_18       1.0
    x_18_2          LINK_18_2       1.0
    x_18_2          EDGE_2_18_2     1.0
    x_18_2          EDGE_5_18_2     1.0
    x_18_2          EDGE_13_18_2    1.0
    x_18_2          EDGE_15_18_2    1.0
    x_18_2          EDGE_16_18_2    1.0
    x_18_2          EDGE_18_22_2    1.0
    x_18_3          ASSIGN_18       1.0
    x_18_3          LINK_18_3       1.0
    x_18_3          EDGE_5_18_3     1.0
    x_18_3          EDGE_13_18_3    1.0
    x_18_3          EDGE_15_18_3    1.0
    x_18_3          EDGE_16_18_3    1.0
    x_18_3          EDGE_18_22_3    1.0
    x_18_4          ASSIGN_18       1.0
    x_18_4          LINK_18_4       1.0
    x_18_4          EDGE_5_18_4     1.0
    x_18_4          EDGE_13_18_4    1.0
    x_18_4          EDGE_15_18_4    1.0
    x_18_4          EDGE_16_18_4    1.0
    x_18_4          EDGE_18_22_4    1.0
    x_18_5          ASSIGN_18       1.0
    x_18_5          LINK_18_5       1.0
    x_18_5          EDGE_5_18_5     1.0
    x_18_5          EDGE_13_18_5    1.0
    x_18_5          EDGE_15_18_5    1.0
    x_18_5          EDGE_16_18_5    1.0
    x_18_5          EDGE_18_22_5    1.0
    x_18_6          ASSIGN_18       1.0
    x_18_6          LINK_18_6       1.0
    x_18_6          EDGE_13_18_6    1.0
    x_18_6          EDGE_15_18_6    1.0
    x_18_6          EDGE_16_18_6    1.0
    x_18_6          EDGE_18_22_6    1.0
    x_18_7          ASSIGN_18       1.0
    x_18_7          LINK_18_7       1.0
    x_18_7          EDGE_13_18_7    1.0
    x_18_7          EDGE_15_18_7    1.0
    x_18_7          EDGE_16_18_7    1.0
    x_18_7          EDGE_18_22_7    1.0
    x_18_8          ASSIGN_18       1.0
    x_18_8          LINK_18_8       1.0
    x_18_8          EDGE_13_18_8    1.0
    x_18_8          EDGE_15_18_8    1.0
    x_18_8          EDGE_16_18_8    1.0
    x_18_8          EDGE_18_22_8    1.0
    x_18_9          ASSIGN_18       1.0
    x_18_9          LINK_18_9       1.0
    x_18_9          EDGE_13_18_9    1.0
    x_18_9          EDGE_15_18_9    1.0
    x_18_9          EDGE_16_18_9    1.0
    x_18_9          EDGE_18_22_9    1.0
    x_18_10         ASSIGN_18       1.0
    x_18_10         LINK_18_10      1.0
    x_18_10         EDGE_13_18_10   1.0
    x_18_10         EDGE_15_18_10   1.0
    x_18_10         EDGE_16_18_10   1.0
    x_18_10         EDGE_18_22_10   1.0
    x_18_11         ASSIGN_18       1.0
    x_18_11         LINK_18_11      1.0
    x_18_11         EDGE_13_18_11   1.0
    x_18_11         EDGE_15_18_11   1.0
    x_18_11         EDGE_16_18_11   1.0
    x_18_11         EDGE_18_22_11   1.0
    x_18_12         ASSIGN_18       1.0
    x_18_12         LINK_18_12      1.0
    x_18_12         EDGE_13_18_12   1.0
    x_18_12         EDGE_15_18_12   1.0
    x_18_12         EDGE_16_18_12   1.0
    x_18_12         EDGE_18_22_12   1.0
    x_18_13         ASSIGN_18       1.0
    x_18_13         LINK_18_13      1.0
    x_18_13         EDGE_13_18_13   1.0
    x_18_13         EDGE_15_18_13   1.0
    x_18_13         EDGE_16_18_13   1.0
    x_18_13         EDGE_18_22_13   1.0
    x_18_14         ASSIGN_18       1.0
    x_18_14         LINK_18_14      1.0
    x_18_14         EDGE_15_18_14   1.0
    x_18_14         EDGE_16_18_14   1.0
    x_18_14         EDGE_18_22_14   1.0
    x_18_15         ASSIGN_18       1.0
    x_18_15         LINK_18_15      1.0
    x_18_15         EDGE_15_18_15   1.0
    x_18_15         EDGE_16_18_15   1.0
    x_18_15         EDGE_18_22_15   1.0
    x_18_16         ASSIGN_18       1.0
    x_18_16         LINK_18_16      1.0
    x_18_16         EDGE_16_18_16   1.0
    x_18_16         EDGE_18_22_16   1.0
    x_18_17         ASSIGN_18       1.0
    x_18_17         LINK_18_17      1.0
    x_18_17         EDGE_18_22_17   1.0
    x_18_18         OBJ           1.0
    x_18_18         ASSIGN_18       1.0
    x_18_18         LINK_19_18      -1.0
    x_18_18         LINK_20_18      -1.0
    x_18_18         LINK_21_18      -1.0
    x_18_18         LINK_22_18      -1.0
    x_18_18         LINK_23_18      -1.0
    x_18_18         EDGE_18_22_18   1.0
    x_18_18         EDGE_19_21_18   -1.0
    x_18_18         EDGE_21_22_18   -1.0
    x_19_0          ASSIGN_19       1.0
    x_19_0          LINK_19_0       1.0
    x_19_0          EDGE_2_19_0     1.0
    x_19_0          EDGE_4_19_0     1.0
    x_19_0          EDGE_7_19_0     1.0
    x_19_0          EDGE_11_19_0    1.0
    x_19_0          EDGE_12_19_0    1.0
    x_19_0          EDGE_13_19_0    1.0
    x_19_0          EDGE_14_19_0    1.0
    x_19_0          EDGE_19_21_0    1.0
    x_19_1          ASSIGN_19       1.0
    x_19_1          LINK_19_1       1.0
    x_19_1          EDGE_2_19_1     1.0
    x_19_1          EDGE_4_19_1     1.0
    x_19_1          EDGE_7_19_1     1.0
    x_19_1          EDGE_11_19_1    1.0
    x_19_1          EDGE_12_19_1    1.0
    x_19_1          EDGE_13_19_1    1.0
    x_19_1          EDGE_14_19_1    1.0
    x_19_1          EDGE_19_21_1    1.0
    x_19_2          ASSIGN_19       1.0
    x_19_2          LINK_19_2       1.0
    x_19_2          EDGE_2_19_2     1.0
    x_19_2          EDGE_4_19_2     1.0
    x_19_2          EDGE_7_19_2     1.0
    x_19_2          EDGE_11_19_2    1.0
    x_19_2          EDGE_12_19_2    1.0
    x_19_2          EDGE_13_19_2    1.0
    x_19_2          EDGE_14_19_2    1.0
    x_19_2          EDGE_19_21_2    1.0
    x_19_3          ASSIGN_19       1.0
    x_19_3          LINK_19_3       1.0
    x_19_3          EDGE_4_19_3     1.0
    x_19_3          EDGE_7_19_3     1.0
    x_19_3          EDGE_11_19_3    1.0
    x_19_3          EDGE_12_19_3    1.0
    x_19_3          EDGE_13_19_3    1.0
    x_19_3          EDGE_14_19_3    1.0
    x_19_3          EDGE_19_21_3    1.0
    x_19_4          ASSIGN_19       1.0
    x_19_4          LINK_19_4       1.0
    x_19_4          EDGE_4_19_4     1.0
    x_19_4          EDGE_7_19_4     1.0
    x_19_4          EDGE_11_19_4    1.0
    x_19_4          EDGE_12_19_4    1.0
    x_19_4          EDGE_13_19_4    1.0
    x_19_4          EDGE_14_19_4    1.0
    x_19_4          EDGE_19_21_4    1.0
    x_19_5          ASSIGN_19       1.0
    x_19_5          LINK_19_5       1.0
    x_19_5          EDGE_7_19_5     1.0
    x_19_5          EDGE_11_19_5    1.0
    x_19_5          EDGE_12_19_5    1.0
    x_19_5          EDGE_13_19_5    1.0
    x_19_5          EDGE_14_19_5    1.0
    x_19_5          EDGE_19_21_5    1.0
    x_19_6          ASSIGN_19       1.0
    x_19_6          LINK_19_6       1.0
    x_19_6          EDGE_7_19_6     1.0
    x_19_6          EDGE_11_19_6    1.0
    x_19_6          EDGE_12_19_6    1.0
    x_19_6          EDGE_13_19_6    1.0
    x_19_6          EDGE_14_19_6    1.0
    x_19_6          EDGE_19_21_6    1.0
    x_19_7          ASSIGN_19       1.0
    x_19_7          LINK_19_7       1.0
    x_19_7          EDGE_7_19_7     1.0
    x_19_7          EDGE_11_19_7    1.0
    x_19_7          EDGE_12_19_7    1.0
    x_19_7          EDGE_13_19_7    1.0
    x_19_7          EDGE_14_19_7    1.0
    x_19_7          EDGE_19_21_7    1.0
    x_19_8          ASSIGN_19       1.0
    x_19_8          LINK_19_8       1.0
    x_19_8          EDGE_11_19_8    1.0
    x_19_8          EDGE_12_19_8    1.0
    x_19_8          EDGE_13_19_8    1.0
    x_19_8          EDGE_14_19_8    1.0
    x_19_8          EDGE_19_21_8    1.0
    x_19_9          ASSIGN_19       1.0
    x_19_9          LINK_19_9       1.0
    x_19_9          EDGE_11_19_9    1.0
    x_19_9          EDGE_12_19_9    1.0
    x_19_9          EDGE_13_19_9    1.0
    x_19_9          EDGE_14_19_9    1.0
    x_19_9          EDGE_19_21_9    1.0
    x_19_10         ASSIGN_19       1.0
    x_19_10         LINK_19_10      1.0
    x_19_10         EDGE_11_19_10   1.0
    x_19_10         EDGE_12_19_10   1.0
    x_19_10         EDGE_13_19_10   1.0
    x_19_10         EDGE_14_19_10   1.0
    x_19_10         EDGE_19_21_10   1.0
    x_19_11         ASSIGN_19       1.0
    x_19_11         LINK_19_11      1.0
    x_19_11         EDGE_11_19_11   1.0
    x_19_11         EDGE_12_19_11   1.0
    x_19_11         EDGE_13_19_11   1.0
    x_19_11         EDGE_14_19_11   1.0
    x_19_11         EDGE_19_21_11   1.0
    x_19_12         ASSIGN_19       1.0
    x_19_12         LINK_19_12      1.0
    x_19_12         EDGE_12_19_12   1.0
    x_19_12         EDGE_13_19_12   1.0
    x_19_12         EDGE_14_19_12   1.0
    x_19_12         EDGE_19_21_12   1.0
    x_19_13         ASSIGN_19       1.0
    x_19_13         LINK_19_13      1.0
    x_19_13         EDGE_13_19_13   1.0
    x_19_13         EDGE_14_19_13   1.0
    x_19_13         EDGE_19_21_13   1.0
    x_19_14         ASSIGN_19       1.0
    x_19_14         LINK_19_14      1.0
    x_19_14         EDGE_14_19_14   1.0
    x_19_14         EDGE_19_21_14   1.0
    x_19_15         ASSIGN_19       1.0
    x_19_15         LINK_19_15      1.0
    x_19_15         EDGE_19_21_15   1.0
    x_19_16         ASSIGN_19       1.0
    x_19_16         LINK_19_16      1.0
    x_19_16         EDGE_19_21_16   1.0
    x_19_17         ASSIGN_19       1.0
    x_19_17         LINK_19_17      1.0
    x_19_17         EDGE_19_21_17   1.0
    x_19_18         ASSIGN_19       1.0
    x_19_18         LINK_19_18      1.0
    x_19_18         EDGE_19_21_18   1.0
    x_19_19         OBJ           1.0
    x_19_19         ASSIGN_19       1.0
    x_19_19         LINK_20_19      -1.0
    x_19_19         LINK_21_19      -1.0
    x_19_19         LINK_22_19      -1.0
    x_19_19         LINK_23_19      -1.0
    x_19_19         EDGE_19_21_19   1.0
    x_19_19         EDGE_21_22_19   -1.0
    x_20_0          ASSIGN_20       1.0
    x_20_0          LINK_20_0       1.0
    x_20_0          EDGE_0_20_0     1.0
    x_20_0          EDGE_3_20_0     1.0
    x_20_0          EDGE_4_20_0     1.0
    x_20_0          EDGE_5_20_0     1.0
    x_20_0          EDGE_6_20_0     1.0
    x_20_0          EDGE_8_20_0     1.0
    x_20_0          EDGE_9_20_0     1.0
    x_20_0          EDGE_10_20_0    1.0
    x_20_1          ASSIGN_20       1.0
    x_20_1          LINK_20_1       1.0
    x_20_1          EDGE_3_20_1     1.0
    x_20_1          EDGE_4_20_1     1.0
    x_20_1          EDGE_5_20_1     1.0
    x_20_1          EDGE_6_20_1     1.0
    x_20_1          EDGE_8_20_1     1.0
    x_20_1          EDGE_9_20_1     1.0
    x_20_1          EDGE_10_20_1    1.0
    x_20_2          ASSIGN_20       1.0
    x_20_2          LINK_20_2       1.0
    x_20_2          EDGE_3_20_2     1.0
    x_20_2          EDGE_4_20_2     1.0
    x_20_2          EDGE_5_20_2     1.0
    x_20_2          EDGE_6_20_2     1.0
    x_20_2          EDGE_8_20_2     1.0
    x_20_2          EDGE_9_20_2     1.0
    x_20_2          EDGE_10_20_2    1.0
    x_20_3          ASSIGN_20       1.0
    x_20_3          LINK_20_3       1.0
    x_20_3          EDGE_3_20_3     1.0
    x_20_3          EDGE_4_20_3     1.0
    x_20_3          EDGE_5_20_3     1.0
    x_20_3          EDGE_6_20_3     1.0
    x_20_3          EDGE_8_20_3     1.0
    x_20_3          EDGE_9_20_3     1.0
    x_20_3          EDGE_10_20_3    1.0
    x_20_4          ASSIGN_20       1.0
    x_20_4          LINK_20_4       1.0
    x_20_4          EDGE_4_20_4     1.0
    x_20_4          EDGE_5_20_4     1.0
    x_20_4          EDGE_6_20_4     1.0
    x_20_4          EDGE_8_20_4     1.0
    x_20_4          EDGE_9_20_4     1.0
    x_20_4          EDGE_10_20_4    1.0
    x_20_5          ASSIGN_20       1.0
    x_20_5          LINK_20_5       1.0
    x_20_5          EDGE_5_20_5     1.0
    x_20_5          EDGE_6_20_5     1.0
    x_20_5          EDGE_8_20_5     1.0
    x_20_5          EDGE_9_20_5     1.0
    x_20_5          EDGE_10_20_5    1.0
    x_20_6          ASSIGN_20       1.0
    x_20_6          LINK_20_6       1.0
    x_20_6          EDGE_6_20_6     1.0
    x_20_6          EDGE_8_20_6     1.0
    x_20_6          EDGE_9_20_6     1.0
    x_20_6          EDGE_10_20_6    1.0
    x_20_7          ASSIGN_20       1.0
    x_20_7          LINK_20_7       1.0
    x_20_7          EDGE_8_20_7     1.0
    x_20_7          EDGE_9_20_7     1.0
    x_20_7          EDGE_10_20_7    1.0
    x_20_8          ASSIGN_20       1.0
    x_20_8          LINK_20_8       1.0
    x_20_8          EDGE_8_20_8     1.0
    x_20_8          EDGE_9_20_8     1.0
    x_20_8          EDGE_10_20_8    1.0
    x_20_9          ASSIGN_20       1.0
    x_20_9          LINK_20_9       1.0
    x_20_9          EDGE_9_20_9     1.0
    x_20_9          EDGE_10_20_9    1.0
    x_20_10         ASSIGN_20       1.0
    x_20_10         LINK_20_10      1.0
    x_20_10         EDGE_10_20_10   1.0
    x_20_11         ASSIGN_20       1.0
    x_20_11         LINK_20_11      1.0
    x_20_12         ASSIGN_20       1.0
    x_20_12         LINK_20_12      1.0
    x_20_13         ASSIGN_20       1.0
    x_20_13         LINK_20_13      1.0
    x_20_14         ASSIGN_20       1.0
    x_20_14         LINK_20_14      1.0
    x_20_15         ASSIGN_20       1.0
    x_20_15         LINK_20_15      1.0
    x_20_16         ASSIGN_20       1.0
    x_20_16         LINK_20_16      1.0
    x_20_17         ASSIGN_20       1.0
    x_20_17         LINK_20_17      1.0
    x_20_18         ASSIGN_20       1.0
    x_20_18         LINK_20_18      1.0
    x_20_19         ASSIGN_20       1.0
    x_20_19         LINK_20_19      1.0
    x_20_20         OBJ           1.0
    x_20_20         ASSIGN_20       1.0
    x_20_20         LINK_21_20      -1.0
    x_20_20         LINK_22_20      -1.0
    x_20_20         LINK_23_20      -1.0
    x_20_20         EDGE_21_22_20   -1.0
    x_21_0          ASSIGN_21       1.0
    x_21_0          LINK_21_0       1.0
    x_21_0          EDGE_0_21_0     1.0
    x_21_0          EDGE_1_21_0     1.0
    x_21_0          EDGE_5_21_0     1.0
    x_21_0          EDGE_8_21_0     1.0
    x_21_0          EDGE_12_21_0    1.0
    x_21_0          EDGE_19_21_0    1.0
    x_21_0          EDGE_21_22_0    1.0
    x_21_1          ASSIGN_21       1.0
    x_21_1          LINK_21_1       1.0
    x_21_1          EDGE_1_21_1     1.0
    x_21_1          EDGE_5_21_1     1.0
    x_21_1          EDGE_8_21_1     1.0
    x_21_1          EDGE_12_21_1    1.0
    x_21_1          EDGE_19_21_1    1.0
    x_21_1          EDGE_21_22_1    1.0
    x_21_2          ASSIGN_21       1.0
    x_21_2          LINK_21_2       1.0
    x_21_2          EDGE_5_21_2     1.0
    x_21_2          EDGE_8_21_2     1.0
    x_21_2          EDGE_12_21_2    1.0
    x_21_2          EDGE_19_21_2    1.0
    x_21_2          EDGE_21_22_2    1.0
    x_21_3          ASSIGN_21       1.0
    x_21_3          LINK_21_3       1.0
    x_21_3          EDGE_5_21_3     1.0
    x_21_3          EDGE_8_21_3     1.0
    x_21_3          EDGE_12_21_3    1.0
    x_21_3          EDGE_19_21_3    1.0
    x_21_3          EDGE_21_22_3    1.0
    x_21_4          ASSIGN_21       1.0
    x_21_4          LINK_21_4       1.0
    x_21_4          EDGE_5_21_4     1.0
    x_21_4          EDGE_8_21_4     1.0
    x_21_4          EDGE_12_21_4    1.0
    x_21_4          EDGE_19_21_4    1.0
    x_21_4          EDGE_21_22_4    1.0
    x_21_5          ASSIGN_21       1.0
    x_21_5          LINK_21_5       1.0
    x_21_5          EDGE_5_21_5     1.0
    x_21_5          EDGE_8_21_5     1.0
    x_21_5          EDGE_12_21_5    1.0
    x_21_5          EDGE_19_21_5    1.0
    x_21_5          EDGE_21_22_5    1.0
    x_21_6          ASSIGN_21       1.0
    x_21_6          LINK_21_6       1.0
    x_21_6          EDGE_8_21_6     1.0
    x_21_6          EDGE_12_21_6    1.0
    x_21_6          EDGE_19_21_6    1.0
    x_21_6          EDGE_21_22_6    1.0
    x_21_7          ASSIGN_21       1.0
    x_21_7          LINK_21_7       1.0
    x_21_7          EDGE_8_21_7     1.0
    x_21_7          EDGE_12_21_7    1.0
    x_21_7          EDGE_19_21_7    1.0
    x_21_7          EDGE_21_22_7    1.0
    x_21_8          ASSIGN_21       1.0
    x_21_8          LINK_21_8       1.0
    x_21_8          EDGE_8_21_8     1.0
    x_21_8          EDGE_12_21_8    1.0
    x_21_8          EDGE_19_21_8    1.0
    x_21_8          EDGE_21_22_8    1.0
    x_21_9          ASSIGN_21       1.0
    x_21_9          LINK_21_9       1.0
    x_21_9          EDGE_12_21_9    1.0
    x_21_9          EDGE_19_21_9    1.0
    x_21_9          EDGE_21_22_9    1.0
    x_21_10         ASSIGN_21       1.0
    x_21_10         LINK_21_10      1.0
    x_21_10         EDGE_12_21_10   1.0
    x_21_10         EDGE_19_21_10   1.0
    x_21_10         EDGE_21_22_10   1.0
    x_21_11         ASSIGN_21       1.0
    x_21_11         LINK_21_11      1.0
    x_21_11         EDGE_12_21_11   1.0
    x_21_11         EDGE_19_21_11   1.0
    x_21_11         EDGE_21_22_11   1.0
    x_21_12         ASSIGN_21       1.0
    x_21_12         LINK_21_12      1.0
    x_21_12         EDGE_12_21_12   1.0
    x_21_12         EDGE_19_21_12   1.0
    x_21_12         EDGE_21_22_12   1.0
    x_21_13         ASSIGN_21       1.0
    x_21_13         LINK_21_13      1.0
    x_21_13         EDGE_19_21_13   1.0
    x_21_13         EDGE_21_22_13   1.0
    x_21_14         ASSIGN_21       1.0
    x_21_14         LINK_21_14      1.0
    x_21_14         EDGE_19_21_14   1.0
    x_21_14         EDGE_21_22_14   1.0
    x_21_15         ASSIGN_21       1.0
    x_21_15         LINK_21_15      1.0
    x_21_15         EDGE_19_21_15   1.0
    x_21_15         EDGE_21_22_15   1.0
    x_21_16         ASSIGN_21       1.0
    x_21_16         LINK_21_16      1.0
    x_21_16         EDGE_19_21_16   1.0
    x_21_16         EDGE_21_22_16   1.0
    x_21_17         ASSIGN_21       1.0
    x_21_17         LINK_21_17      1.0
    x_21_17         EDGE_19_21_17   1.0
    x_21_17         EDGE_21_22_17   1.0
    x_21_18         ASSIGN_21       1.0
    x_21_18         LINK_21_18      1.0
    x_21_18         EDGE_19_21_18   1.0
    x_21_18         EDGE_21_22_18   1.0
    x_21_19         ASSIGN_21       1.0
    x_21_19         LINK_21_19      1.0
    x_21_19         EDGE_19_21_19   1.0
    x_21_19         EDGE_21_22_19   1.0
    x_21_20         ASSIGN_21       1.0
    x_21_20         LINK_21_20      1.0
    x_21_20         EDGE_21_22_20   1.0
    x_21_21         OBJ           1.0
    x_21_21         ASSIGN_21       1.0
    x_21_21         LINK_22_21      -1.0
    x_21_21         LINK_23_21      -1.0
    x_21_21         EDGE_21_22_21   1.0
    x_22_0          ASSIGN_22       1.0
    x_22_0          LINK_22_0       1.0
    x_22_0          EDGE_0_22_0     1.0
    x_22_0          EDGE_3_22_0     1.0
    x_22_0          EDGE_4_22_0     1.0
    x_22_0          EDGE_6_22_0     1.0
    x_22_0          EDGE_16_22_0    1.0
    x_22_0          EDGE_18_22_0    1.0
    x_22_0          EDGE_21_22_0    1.0
    x_22_1          ASSIGN_22       1.0
    x_22_1          LINK_22_1       1.0
    x_22_1          EDGE_3_22_1     1.0
    x_22_1          EDGE_4_22_1     1.0
    x_22_1          EDGE_6_22_1     1.0
    x_22_1          EDGE_16_22_1    1.0
    x_22_1          EDGE_18_22_1    1.0
    x_22_1          EDGE_21_22_1    1.0
    x_22_2          ASSIGN_22       1.0
    x_22_2          LINK_22_2       1.0
    x_22_2          EDGE_3_22_2     1.0
    x_22_2          EDGE_4_22_2     1.0
    x_22_2          EDGE_6_22_2     1.0
    x_22_2          EDGE_16_22_2    1.0
    x_22_2          EDGE_18_22_2    1.0
    x_22_2          EDGE_21_22_2    1.0
    x_22_3          ASSIGN_22       1.0
    x_22_3          LINK_22_3       1.0
    x_22_3          EDGE_3_22_3     1.0
    x_22_3          EDGE_4_22_3     1.0
    x_22_3          EDGE_6_22_3     1.0
    x_22_3          EDGE_16_22_3    1.0
    x_22_3          EDGE_18_22_3    1.0
    x_22_3          EDGE_21_22_3    1.0
    x_22_4          ASSIGN_22       1.0
    x_22_4          LINK_22_4       1.0
    x_22_4          EDGE_4_22_4     1.0
    x_22_4          EDGE_6_22_4     1.0
    x_22_4          EDGE_16_22_4    1.0
    x_22_4          EDGE_18_22_4    1.0
    x_22_4          EDGE_21_22_4    1.0
    x_22_5          ASSIGN_22       1.0
    x_22_5          LINK_22_5       1.0
    x_22_5          EDGE_6_22_5     1.0
    x_22_5          EDGE_16_22_5    1.0
    x_22_5          EDGE_18_22_5    1.0
    x_22_5          EDGE_21_22_5    1.0
    x_22_6          ASSIGN_22       1.0
    x_22_6          LINK_22_6       1.0
    x_22_6          EDGE_6_22_6     1.0
    x_22_6          EDGE_16_22_6    1.0
    x_22_6          EDGE_18_22_6    1.0
    x_22_6          EDGE_21_22_6    1.0
    x_22_7          ASSIGN_22       1.0
    x_22_7          LINK_22_7       1.0
    x_22_7          EDGE_16_22_7    1.0
    x_22_7          EDGE_18_22_7    1.0
    x_22_7          EDGE_21_22_7    1.0
    x_22_8          ASSIGN_22       1.0
    x_22_8          LINK_22_8       1.0
    x_22_8          EDGE_16_22_8    1.0
    x_22_8          EDGE_18_22_8    1.0
    x_22_8          EDGE_21_22_8    1.0
    x_22_9          ASSIGN_22       1.0
    x_22_9          LINK_22_9       1.0
    x_22_9          EDGE_16_22_9    1.0
    x_22_9          EDGE_18_22_9    1.0
    x_22_9          EDGE_21_22_9    1.0
    x_22_10         ASSIGN_22       1.0
    x_22_10         LINK_22_10      1.0
    x_22_10         EDGE_16_22_10   1.0
    x_22_10         EDGE_18_22_10   1.0
    x_22_10         EDGE_21_22_10   1.0
    x_22_11         ASSIGN_22       1.0
    x_22_11         LINK_22_11      1.0
    x_22_11         EDGE_16_22_11   1.0
    x_22_11         EDGE_18_22_11   1.0
    x_22_11         EDGE_21_22_11   1.0
    x_22_12         ASSIGN_22       1.0
    x_22_12         LINK_22_12      1.0
    x_22_12         EDGE_16_22_12   1.0
    x_22_12         EDGE_18_22_12   1.0
    x_22_12         EDGE_21_22_12   1.0
    x_22_13         ASSIGN_22       1.0
    x_22_13         LINK_22_13      1.0
    x_22_13         EDGE_16_22_13   1.0
    x_22_13         EDGE_18_22_13   1.0
    x_22_13         EDGE_21_22_13   1.0
    x_22_14         ASSIGN_22       1.0
    x_22_14         LINK_22_14      1.0
    x_22_14         EDGE_16_22_14   1.0
    x_22_14         EDGE_18_22_14   1.0
    x_22_14         EDGE_21_22_14   1.0
    x_22_15         ASSIGN_22       1.0
    x_22_15         LINK_22_15      1.0
    x_22_15         EDGE_16_22_15   1.0
    x_22_15         EDGE_18_22_15   1.0
    x_22_15         EDGE_21_22_15   1.0
    x_22_16         ASSIGN_22       1.0
    x_22_16         LINK_22_16      1.0
    x_22_16         EDGE_16_22_16   1.0
    x_22_16         EDGE_18_22_16   1.0
    x_22_16         EDGE_21_22_16   1.0
    x_22_17         ASSIGN_22       1.0
    x_22_17         LINK_22_17      1.0
    x_22_17         EDGE_18_22_17   1.0
    x_22_17         EDGE_21_22_17   1.0
    x_22_18         ASSIGN_22       1.0
    x_22_18         LINK_22_18      1.0
    x_22_18         EDGE_18_22_18   1.0
    x_22_18         EDGE_21_22_18   1.0
    x_22_19         ASSIGN_22       1.0
    x_22_19         LINK_22_19      1.0
    x_22_19         EDGE_21_22_19   1.0
    x_22_20         ASSIGN_22       1.0
    x_22_20         LINK_22_20      1.0
    x_22_20         EDGE_21_22_20   1.0
    x_22_21         ASSIGN_22       1.0
    x_22_21         LINK_22_21      1.0
    x_22_21         EDGE_21_22_21   1.0
    x_22_22         OBJ           1.0
    x_22_22         ASSIGN_22       1.0
    x_22_22         LINK_23_22      -1.0
    x_23_0          ASSIGN_23       1.0
    x_23_0          LINK_23_0       1.0
    x_23_0          EDGE_8_23_0     1.0
    x_23_0          EDGE_9_23_0     1.0
    x_23_0          EDGE_10_23_0    1.0
    x_23_0          EDGE_12_23_0    1.0
    x_23_0          EDGE_13_23_0    1.0
    x_23_0          EDGE_16_23_0    1.0
    x_23_1          ASSIGN_23       1.0
    x_23_1          LINK_23_1       1.0
    x_23_1          EDGE_8_23_1     1.0
    x_23_1          EDGE_9_23_1     1.0
    x_23_1          EDGE_10_23_1    1.0
    x_23_1          EDGE_12_23_1    1.0
    x_23_1          EDGE_13_23_1    1.0
    x_23_1          EDGE_16_23_1    1.0
    x_23_2          ASSIGN_23       1.0
    x_23_2          LINK_23_2       1.0
    x_23_2          EDGE_8_23_2     1.0
    x_23_2          EDGE_9_23_2     1.0
    x_23_2          EDGE_10_23_2    1.0
    x_23_2          EDGE_12_23_2    1.0
    x_23_2          EDGE_13_23_2    1.0
    x_23_2          EDGE_16_23_2    1.0
    x_23_3          ASSIGN_23       1.0
    x_23_3          LINK_23_3       1.0
    x_23_3          EDGE_8_23_3     1.0
    x_23_3          EDGE_9_23_3     1.0
    x_23_3          EDGE_10_23_3    1.0
    x_23_3          EDGE_12_23_3    1.0
    x_23_3          EDGE_13_23_3    1.0
    x_23_3          EDGE_16_23_3    1.0
    x_23_4          ASSIGN_23       1.0
    x_23_4          LINK_23_4       1.0
    x_23_4          EDGE_8_23_4     1.0
    x_23_4          EDGE_9_23_4     1.0
    x_23_4          EDGE_10_23_4    1.0
    x_23_4          EDGE_12_23_4    1.0
    x_23_4          EDGE_13_23_4    1.0
    x_23_4          EDGE_16_23_4    1.0
    x_23_5          ASSIGN_23       1.0
    x_23_5          LINK_23_5       1.0
    x_23_5          EDGE_8_23_5     1.0
    x_23_5          EDGE_9_23_5     1.0
    x_23_5          EDGE_10_23_5    1.0
    x_23_5          EDGE_12_23_5    1.0
    x_23_5          EDGE_13_23_5    1.0
    x_23_5          EDGE_16_23_5    1.0
    x_23_6          ASSIGN_23       1.0
    x_23_6          LINK_23_6       1.0
    x_23_6          EDGE_8_23_6     1.0
    x_23_6          EDGE_9_23_6     1.0
    x_23_6          EDGE_10_23_6    1.0
    x_23_6          EDGE_12_23_6    1.0
    x_23_6          EDGE_13_23_6    1.0
    x_23_6          EDGE_16_23_6    1.0
    x_23_7          ASSIGN_23       1.0
    x_23_7          LINK_23_7       1.0
    x_23_7          EDGE_8_23_7     1.0
    x_23_7          EDGE_9_23_7     1.0
    x_23_7          EDGE_10_23_7    1.0
    x_23_7          EDGE_12_23_7    1.0
    x_23_7          EDGE_13_23_7    1.0
    x_23_7          EDGE_16_23_7    1.0
    x_23_8          ASSIGN_23       1.0
    x_23_8          LINK_23_8       1.0
    x_23_8          EDGE_8_23_8     1.0
    x_23_8          EDGE_9_23_8     1.0
    x_23_8          EDGE_10_23_8    1.0
    x_23_8          EDGE_12_23_8    1.0
    x_23_8          EDGE_13_23_8    1.0
    x_23_8          EDGE_16_23_8    1.0
    x_23_9          ASSIGN_23       1.0
    x_23_9          LINK_23_9       1.0
    x_23_9          EDGE_9_23_9     1.0
    x_23_9          EDGE_10_23_9    1.0
    x_23_9          EDGE_12_23_9    1.0
    x_23_9          EDGE_13_23_9    1.0
    x_23_9          EDGE_16_23_9    1.0
    x_23_10         ASSIGN_23       1.0
    x_23_10         LINK_23_10      1.0
    x_23_10         EDGE_10_23_10   1.0
    x_23_10         EDGE_12_23_10   1.0
    x_23_10         EDGE_13_23_10   1.0
    x_23_10         EDGE_16_23_10   1.0
    x_23_11         ASSIGN_23       1.0
    x_23_11         LINK_23_11      1.0
    x_23_11         EDGE_12_23_11   1.0
    x_23_11         EDGE_13_23_11   1.0
    x_23_11         EDGE_16_23_11   1.0
    x_23_12         ASSIGN_23       1.0
    x_23_12         LINK_23_12      1.0
    x_23_12         EDGE_12_23_12   1.0
    x_23_12         EDGE_13_23_12   1.0
    x_23_12         EDGE_16_23_12   1.0
    x_23_13         ASSIGN_23       1.0
    x_23_13         LINK_23_13      1.0
    x_23_13         EDGE_13_23_13   1.0
    x_23_13         EDGE_16_23_13   1.0
    x_23_14         ASSIGN_23       1.0
    x_23_14         LINK_23_14      1.0
    x_23_14         EDGE_16_23_14   1.0
    x_23_15         ASSIGN_23       1.0
    x_23_15         LINK_23_15      1.0
    x_23_15         EDGE_16_23_15   1.0
    x_23_16         ASSIGN_23       1.0
    x_23_16         LINK_23_16      1.0
    x_23_16         EDGE_16_23_16   1.0
    x_23_17         ASSIGN_23       1.0
    x_23_17         LINK_23_17      1.0
    x_23_18         ASSIGN_23       1.0
    x_23_18         LINK_23_18      1.0
    x_23_19         ASSIGN_23       1.0
    x_23_19         LINK_23_19      1.0
    x_23_20         ASSIGN_23       1.0
    x_23_20         LINK_23_20      1.0
    x_23_21         ASSIGN_23       1.0
    x_23_21         LINK_23_21      1.0
    x_23_22         ASSIGN_23       1.0
    x_23_22         LINK_23_22      1.0
    x_23_23         OBJ           1.0
    x_23_23         ASSIGN_23       1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           ASSIGN_0        1.0
    RHS           ASSIGN_1        1.0
    RHS           ASSIGN_2        1.0
    RHS           ASSIGN_3        1.0
    RHS           ASSIGN_4        1.0
    RHS           ASSIGN_5        1.0
    RHS           ASSIGN_6        1.0
    RHS           ASSIGN_7        1.0
    RHS           ASSIGN_8        1.0
    RHS           ASSIGN_9        1.0
    RHS           ASSIGN_10       1.0
    RHS           ASSIGN_11       1.0
    RHS           ASSIGN_12       1.0
    RHS           ASSIGN_13       1.0
    RHS           ASSIGN_14       1.0
    RHS           ASSIGN_15       1.0
    RHS           ASSIGN_16       1.0
    RHS           ASSIGN_17       1.0
    RHS           ASSIGN_18       1.0
    RHS           ASSIGN_19       1.0
    RHS           ASSIGN_20       1.0
    RHS           ASSIGN_21       1.0
    RHS           ASSIGN_22       1.0
    RHS           ASSIGN_23       1.0
    RHS           EDGE_0_1_0      1.0
    RHS           EDGE_0_2_0      1.0
    RHS           EDGE_0_3_0      1.0
    RHS           EDGE_0_4_0      1.0
    RHS           EDGE_0_6_0      1.0
    RHS           EDGE_0_7_0      1.0
    RHS           EDGE_0_12_0     1.0
    RHS           EDGE_0_13_0     1.0
    RHS           EDGE_0_14_0     1.0
    RHS           EDGE_0_18_0     1.0
    RHS           EDGE_0_20_0     1.0
    RHS           EDGE_0_21_0     1.0
    RHS           EDGE_0_22_0     1.0
    RHS           EDGE_1_4_1      1.0
    RHS           EDGE_1_5_1      1.0
    RHS           EDGE_1_6_1      1.0
    RHS           EDGE_1_7_1      1.0
    RHS           EDGE_1_8_1      1.0
    RHS           EDGE_1_9_1      1.0
    RHS           EDGE_1_10_1     1.0
    RHS           EDGE_1_15_1     1.0
    RHS           EDGE_1_16_1     1.0
    RHS           EDGE_1_18_1     1.0
    RHS           EDGE_1_21_1     1.0
    RHS           EDGE_2_3_2      1.0
    RHS           EDGE_2_4_2      1.0
    RHS           EDGE_2_5_2      1.0
    RHS           EDGE_2_6_2      1.0
    RHS           EDGE_2_8_2      1.0
    RHS           EDGE_2_9_2      1.0
    RHS           EDGE_2_10_2     1.0
    RHS           EDGE_2_15_2     1.0
    RHS           EDGE_2_16_2     1.0
    RHS           EDGE_2_18_2     1.0
    RHS           EDGE_2_19_2     1.0
    RHS           EDGE_3_5_3      1.0
    RHS           EDGE_3_9_3      1.0
    RHS           EDGE_3_10_3     1.0
    RHS           EDGE_3_12_3     1.0
    RHS           EDGE_3_13_3     1.0
    RHS           EDGE_3_14_3     1.0
    RHS           EDGE_3_15_3     1.0
    RHS           EDGE_3_20_3     1.0
    RHS           EDGE_3_22_3     1.0
    RHS           EDGE_4_5_4      1.0
    RHS           EDGE_4_8_4      1.0
    RHS           EDGE_4_9_4      1.0
    RHS           EDGE_4_10_4     1.0
    RHS           EDGE_4_13_4     1.0
    RHS           EDGE_4_19_4     1.0
    RHS           EDGE_4_20_4     1.0
    RHS           EDGE_4_22_4     1.0
    RHS           EDGE_5_7_5      1.0
    RHS           EDGE_5_11_5     1.0
    RHS           EDGE_5_13_5     1.0
    RHS           EDGE_5_14_5     1.0
    RHS           EDGE_5_18_5     1.0
    RHS           EDGE_5_20_5     1.0
    RHS           EDGE_5_21_5     1.0
    RHS           EDGE_6_11_6     1.0
    RHS           EDGE_6_12_6     1.0
    RHS           EDGE_6_13_6     1.0
    RHS           EDGE_6_14_6     1.0
    RHS           EDGE_6_15_6     1.0
    RHS           EDGE_6_20_6     1.0
    RHS           EDGE_6_22_6     1.0
    RHS           EDGE_7_10_7     1.0
    RHS           EDGE_7_11_7     1.0
    RHS           EDGE_7_12_7     1.0
    RHS           EDGE_7_13_7     1.0
    RHS           EDGE_7_15_7     1.0
    RHS           EDGE_7_16_7     1.0
    RHS           EDGE_7_19_7     1.0
    RHS           EDGE_8_11_8     1.0
    RHS           EDGE_8_13_8     1.0
    RHS           EDGE_8_14_8     1.0
    RHS           EDGE_8_17_8     1.0
    RHS           EDGE_8_20_8     1.0
    RHS           EDGE_8_21_8     1.0
    RHS           EDGE_8_23_8     1.0
    RHS           EDGE_9_11_9     1.0
    RHS           EDGE_9_12_9     1.0
    RHS           EDGE_9_14_9     1.0
    RHS           EDGE_9_17_9     1.0
    RHS           EDGE_9_20_9     1.0
    RHS           EDGE_9_23_9     1.0
    RHS           EDGE_10_11_10   1.0
    RHS           EDGE_10_14_10   1.0
    RHS           EDGE_10_17_10   1.0
    RHS           EDGE_10_20_10   1.0
    RHS           EDGE_10_23_10   1.0
    RHS           EDGE_11_15_11   1.0
    RHS           EDGE_11_16_11   1.0
    RHS           EDGE_11_17_11   1.0
    RHS           EDGE_11_19_11   1.0
    RHS           EDGE_12_15_12   1.0
    RHS           EDGE_12_17_12   1.0
    RHS           EDGE_12_19_12   1.0
    RHS           EDGE_12_21_12   1.0
    RHS           EDGE_12_23_12   1.0
    RHS           EDGE_13_18_13   1.0
    RHS           EDGE_13_19_13   1.0
    RHS           EDGE_13_23_13   1.0
    RHS           EDGE_14_16_14   1.0
    RHS           EDGE_14_17_14   1.0
    RHS           EDGE_14_19_14   1.0
    RHS           EDGE_15_17_15   1.0
    RHS           EDGE_15_18_15   1.0
    RHS           EDGE_16_17_16   1.0
    RHS           EDGE_16_18_16   1.0
    RHS           EDGE_16_22_16   1.0
    RHS           EDGE_16_23_16   1.0
    RHS           EDGE_18_22_18   1.0
    RHS           EDGE_19_21_19   1.0
    RHS           EDGE_21_22_21   1.0
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_2
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_3
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_4
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_5
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_6
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 BV BOUND         x_7_7
 BV BOUND         x_8_0
 BV BOUND         x_8_1
 BV BOUND         x_8_2
 BV BOUND         x_8_3
 BV BOUND         x_8_4
 BV BOUND         x_8_5
 BV BOUND         x_8_6
 BV BOUND         x_8_7
 BV BOUND         x_8_8
 BV BOUND         x_9_0
 BV BOUND         x_9_1
 BV BOUND         x_9_2
 BV BOUND         x_9_3
 BV BOUND         x_9_4
 BV BOUND         x_9_5
 BV BOUND         x_9_6
 BV BOUND         x_9_7
 BV BOUND         x_9_8
 BV BOUND         x_9_9
 BV BOUND         x_10_0
 BV BOUND         x_10_1
 BV BOUND         x_10_2
 BV BOUND         x_10_3
 BV BOUND         x_10_4
 BV BOUND         x_10_5
 BV BOUND         x_10_6
 BV BOUND         x_10_7
 BV BOUND         x_10_8
 BV BOUND         x_10_9
 BV BOUND         x_10_10
 BV BOUND         x_11_0
 BV BOUND         x_11_1
 BV BOUND         x_11_2
 BV BOUND         x_11_3
 BV BOUND         x_11_4
 BV BOUND         x_11_5
 BV BOUND         x_11_6
 BV BOUND         x_11_7
 BV BOUND         x_11_8
 BV BOUND         x_11_9
 BV BOUND         x_11_10
 BV BOUND         x_11_11
 BV BOUND         x_12_0
 BV BOUND         x_12_1
 BV BOUND         x_12_2
 BV BOUND         x_12_3
 BV BOUND         x_12_4
 BV BOUND         x_12_5
 BV BOUND         x_12_6
 BV BOUND         x_12_7
 BV BOUND         x_12_8
 BV BOUND         x_12_9
 BV BOUND         x_12_10
 BV BOUND         x_12_11
 BV BOUND         x_12_12
 BV BOUND         x_13_0
 BV BOUND         x_13_1
 BV BOUND         x_13_2
 BV BOUND         x_13_3
 BV BOUND         x_13_4
 BV BOUND         x_13_5
 BV BOUND         x_13_6
 BV BOUND         x_13_7
 BV BOUND         x_13_8
 BV BOUND         x_13_9
 BV BOUND         x_13_10
 BV BOUND         x_13_11
 BV BOUND         x_13_12
 BV BOUND         x_13_13
 BV BOUND         x_14_0
 BV BOUND         x_14_1
 BV BOUND         x_14_2
 BV BOUND         x_14_3
 BV BOUND         x_14_4
 BV BOUND         x_14_5
 BV BOUND         x_14_6
 BV BOUND         x_14_7
 BV BOUND         x_14_8
 BV BOUND         x_14_9
 BV BOUND         x_14_10
 BV BOUND         x_14_11
 BV BOUND         x_14_12
 BV BOUND         x_14_13
 BV BOUND         x_14_14
 BV BOUND         x_15_0
 BV BOUND         x_15_1
 BV BOUND         x_15_2
 BV BOUND         x_15_3
 BV BOUND         x_15_4
 BV BOUND         x_15_5
 BV BOUND         x_15_6
 BV BOUND         x_15_7
 BV BOUND         x_15_8
 BV BOUND         x_15_9
 BV BOUND         x_15_10
 BV BOUND         x_15_11
 BV BOUND         x_15_12
 BV BOUND         x_15_13
 BV BOUND         x_15_14
 BV BOUND         x_15_15
 BV BOUND         x_16_0
 BV BOUND         x_16_1
 BV BOUND         x_16_2
 BV BOUND         x_16_3
 BV BOUND         x_16_4
 BV BOUND         x_16_5
 BV BOUND         x_16_6
 BV BOUND         x_16_7
 BV BOUND         x_16_8
 BV BOUND         x_16_9
 BV BOUND         x_16_10
 BV BOUND         x_16_11
 BV BOUND         x_16_12
 BV BOUND         x_16_13
 BV BOUND         x_16_14
 BV BOUND         x_16_15
 BV BOUND         x_16_16
 BV BOUND         x_17_0
 BV BOUND         x_17_1
 BV BOUND         x_17_2
 BV BOUND         x_17_3
 BV BOUND         x_17_4
 BV BOUND         x_17_5
 BV BOUND         x_17_6
 BV BOUND         x_17_7
 BV BOUND         x_17_8
 BV BOUND         x_17_9
 BV BOUND         x_17_10
 BV BOUND         x_17_11
 BV BOUND         x_17_12
 BV BOUND         x_17_13
 BV BOUND         x_17_14
 BV BOUND         x_17_15
 BV BOUND         x_17_16
 BV BOUND         x_17_17
 BV BOUND         x_18_0
 BV BOUND         x_18_1
 BV BOUND         x_18_2
 BV BOUND         x_18_3
 BV BOUND         x_18_4
 BV BOUND         x_18_5
 BV BOUND         x_18_6
 BV BOUND         x_18_7
 BV BOUND         x_18_8
 BV BOUND         x_18_9
 BV BOUND         x_18_10
 BV BOUND         x_18_11
 BV BOUND         x_18_12
 BV BOUND         x_18_13
 BV BOUND         x_18_14
 BV BOUND         x_18_15
 BV BOUND         x_18_16
 BV BOUND         x_18_17
 BV BOUND         x_18_18
 BV BOUND         x_19_0
 BV BOUND         x_19_1
 BV BOUND         x_19_2
 BV BOUND         x_19_3
 BV BOUND         x_19_4
 BV BOUND         x_19_5
 BV BOUND         x_19_6
 BV BOUND         x_19_7
 BV BOUND         x_19_8
 BV BOUND         x_19_9
 BV BOUND         x_19_10
 BV BOUND         x_19_11
 BV BOUND         x_19_12
 BV BOUND         x_19_13
 BV BOUND         x_19_14
 BV BOUND         x_19_15
 BV BOUND         x_19_16
 BV BOUND         x_19_17
 BV BOUND         x_19_18
 BV BOUND         x_19_19
 BV BOUND         x_20_0
 BV BOUND         x_20_1
 BV BOUND         x_20_2
 BV BOUND         x_20_3
 BV BOUND         x_20_4
 BV BOUND         x_20_5
 BV BOUND         x_20_6
 BV BOUND         x_20_7
 BV BOUND         x_20_8
 BV BOUND         x_20_9
 BV BOUND         x_20_10
 BV BOUND         x_20_11
 BV BOUND         x_20_12
 BV BOUND         x_20_13
 BV BOUND         x_20_14
 BV BOUND         x_20_15
 BV BOUND         x_20_16
 BV BOUND         x_20_17
 BV BOUND         x_20_18
 BV BOUND         x_20_19
 BV BOUND         x_20_20
 BV BOUND         x_21_0
 BV BOUND         x_21_1
 BV BOUND         x_21_2
 BV BOUND         x_21_3
 BV BOUND         x_21_4
 BV BOUND         x_21_5
 BV BOUND         x_21_6
 BV BOUND         x_21_7
 BV BOUND         x_21_8
 BV BOUND         x_21_9
 BV BOUND         x_21_10
 BV BOUND         x_21_11
 BV BOUND         x_21_12
 BV BOUND         x_21_13
 BV BOUND         x_21_14
 BV BOUND         x_21_15
 BV BOUND         x_21_16
 BV BOUND         x_21_17
 BV BOUND         x_21_18
 BV BOUND         x_21_19
 BV BOUND         x_21_20
 BV BOUND         x_21_21
 BV BOUND         x_22_0
 BV BOUND         x_22_1
 BV BOUND         x_22_2
 BV BOUND         x_22_3
 BV BOUND         x_22_4
 BV BOUND         x_22_5
 BV BOUND         x_22_6
 BV BOUND         x_22_7
 BV BOUND         x_22_8
 BV BOUND         x_22_9
 BV BOUND         x_22_10
 BV BOUND         x_22_11
 BV BOUND         x_22_12
 BV BOUND         x_22_13
 BV BOUND         x_22_14
 BV BOUND         x_22_15
 BV BOUND         x_22_16
 BV BOUND         x_22_17
 BV BOUND         x_22_18
 BV BOUND         x_22_19
 BV BOUND         x_22_20
 BV BOUND         x_22_21
 BV BOUND         x_22_22
 BV BOUND         x_23_0
 BV BOUND         x_23_1
 BV BOUND         x_23_2
 BV BOUND         x_23_3
 BV BOUND         x_23_4
 BV BOUND         x_23_5
 BV BOUND         x_23_6
 BV BOUND         x_23_7
 BV BOUND         x_23_8
 BV BOUND         x_23_9
 BV BOUND         x_23_10
 BV BOUND         x_23_11
 BV BOUND         x_23_12
 BV BOUND         x_23_13
 BV BOUND         x_23_14
 BV BOUND         x_23_15
 BV BOUND         x_23_16
 BV BOUND         x_23_17
 BV BOUND         x_23_18
 BV BOUND         x_23_19
 BV BOUND         x_23_20
 BV BOUND         x_23_21
 BV BOUND         x_23_22
 BV BOUND         x_23_23
ENDATA
