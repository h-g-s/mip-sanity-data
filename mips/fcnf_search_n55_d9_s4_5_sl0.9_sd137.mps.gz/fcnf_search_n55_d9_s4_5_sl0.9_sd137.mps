NAME          fcnf_search_n55_d9_s4_5_sl0.9_sd137
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 E  flow_25
 E  flow_26
 E  flow_27
 E  flow_28
 E  flow_29
 E  flow_30
 E  flow_31
 E  flow_32
 E  flow_33
 E  flow_34
 E  flow_35
 E  flow_36
 E  flow_37
 E  flow_38
 E  flow_39
 E  flow_40
 E  flow_41
 E  flow_42
 E  flow_43
 E  flow_44
 E  flow_45
 E  flow_46
 E  flow_47
 E  flow_48
 E  flow_49
 E  flow_50
 E  flow_51
 E  flow_52
 E  flow_53
 E  flow_54
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
 L  link_84
 L  link_85
 L  link_86
 L  link_87
 L  link_88
 L  link_89
 L  link_90
 L  link_91
 L  link_92
 L  link_93
 L  link_94
 L  link_95
 L  link_96
 L  link_97
 L  link_98
 L  link_99
 L  link_100
 L  link_101
 L  link_102
 L  link_103
 L  link_104
 L  link_105
 L  link_106
 L  link_107
 L  link_108
 L  link_109
 L  link_110
 L  link_111
 L  link_112
 L  link_113
 L  link_114
 L  link_115
 L  link_116
 L  link_117
 L  link_118
 L  link_119
 L  link_120
 L  link_121
 L  link_122
 L  link_123
 L  link_124
 L  link_125
 L  link_126
 L  link_127
 L  link_128
 L  link_129
 L  link_130
 L  link_131
 L  link_132
 L  link_133
 L  link_134
 L  link_135
 L  link_136
 L  link_137
 L  link_138
 L  link_139
 L  link_140
 L  link_141
 L  link_142
 L  link_143
 L  link_144
 L  link_145
 L  link_146
 L  link_147
 L  link_148
 L  link_149
 L  link_150
 L  link_151
 L  link_152
 L  link_153
 L  link_154
 L  link_155
 L  link_156
 L  link_157
 L  link_158
 L  link_159
 L  link_160
 L  link_161
 L  link_162
 L  link_163
 L  link_164
 L  link_165
 L  link_166
 L  link_167
 L  link_168
 L  link_169
 L  link_170
 L  link_171
 L  link_172
 L  link_173
 L  link_174
 L  link_175
 L  link_176
 L  link_177
 L  link_178
 L  link_179
 L  link_180
 L  link_181
 L  link_182
 L  link_183
 L  link_184
 L  link_185
 L  link_186
 L  link_187
 L  link_188
 L  link_189
 L  link_190
 L  link_191
 L  link_192
 L  link_193
 L  link_194
 L  link_195
 L  link_196
 L  link_197
 L  link_198
 L  link_199
 L  link_200
 L  link_201
 L  link_202
 L  link_203
 L  link_204
 L  link_205
 L  link_206
 L  link_207
 L  link_208
 L  link_209
 L  link_210
 L  link_211
 L  link_212
 L  link_213
 L  link_214
 L  link_215
 L  link_216
 L  link_217
 L  link_218
 L  link_219
 L  link_220
 L  link_221
 L  link_222
 L  link_223
 L  link_224
 L  link_225
 L  link_226
 L  link_227
 L  link_228
 L  link_229
 L  link_230
 L  link_231
 L  link_232
 L  link_233
 L  link_234
 L  link_235
 L  link_236
 L  link_237
 L  link_238
 L  link_239
 L  link_240
 L  link_241
 L  link_242
 L  link_243
 L  link_244
 L  link_245
 L  link_246
 L  link_247
 L  link_248
 L  link_249
 L  link_250
 L  link_251
 L  link_252
 L  link_253
 L  link_254
 L  link_255
 L  link_256
 L  link_257
 L  link_258
 L  link_259
 L  link_260
 L  link_261
 L  link_262
 L  link_263
 L  link_264
 L  link_265
 L  link_266
 L  link_267
 L  link_268
 L  link_269
 L  link_270
 L  link_271
 L  link_272
 L  link_273
 L  link_274
 L  link_275
 L  link_276
 L  link_277
 L  link_278
 L  link_279
 L  link_280
 L  link_281
 L  link_282
 L  link_283
 L  link_284
 L  link_285
 L  link_286
 L  link_287
 L  link_288
 L  link_289
 L  link_290
 L  link_291
 L  link_292
 L  link_293
 L  link_294
 L  link_295
 L  link_296
 L  link_297
 L  link_298
 L  link_299
 L  link_300
 L  link_301
 L  link_302
 L  link_303
 L  link_304
 L  link_305
 L  link_306
 L  link_307
 L  link_308
 L  link_309
 L  link_310
 L  link_311
 L  link_312
 L  link_313
 L  link_314
 L  link_315
 L  link_316
 L  link_317
 L  link_318
 L  link_319
 L  link_320
 L  link_321
 L  link_322
 L  link_323
 L  link_324
 L  link_325
 L  link_326
 L  link_327
 L  link_328
 L  link_329
 L  link_330
 L  link_331
 L  link_332
 L  link_333
 L  link_334
 L  link_335
 L  link_336
 L  link_337
 L  link_338
 L  link_339
 L  link_340
 L  link_341
 L  link_342
 L  link_343
 L  link_344
 L  link_345
 L  link_346
 L  link_347
 L  link_348
 L  link_349
 L  link_350
 L  link_351
 L  link_352
 L  link_353
 L  link_354
 L  link_355
 L  link_356
 L  link_357
 L  link_358
 L  link_359
 L  link_360
 L  link_361
 L  link_362
 L  link_363
 L  link_364
 L  link_365
 L  link_366
 L  link_367
 L  link_368
 L  link_369
 L  link_370
 L  link_371
 L  link_372
 L  link_373
 L  link_374
 L  link_375
 L  link_376
 L  link_377
 L  link_378
 L  link_379
 L  link_380
 L  link_381
 L  link_382
 L  link_383
 L  link_384
 L  link_385
 L  link_386
 L  link_387
 L  link_388
 L  link_389
 L  link_390
 L  link_391
 L  link_392
 L  link_393
 L  link_394
 L  link_395
 L  link_396
 L  link_397
 L  link_398
 L  link_399
 L  link_400
 L  link_401
 L  link_402
 L  link_403
 L  link_404
 L  link_405
 L  link_406
 L  link_407
 L  link_408
 L  link_409
 L  link_410
 L  link_411
 L  link_412
 L  link_413
 L  link_414
 L  link_415
 L  link_416
 L  link_417
 L  link_418
 L  link_419
 L  link_420
 L  link_421
 L  link_422
 L  link_423
 L  link_424
 L  link_425
 L  link_426
 L  link_427
 L  link_428
 L  link_429
 L  link_430
 L  link_431
 L  link_432
 L  link_433
 L  link_434
 L  link_435
 L  link_436
 L  link_437
 L  link_438
 L  link_439
 L  link_440
 L  link_441
 L  link_442
 L  link_443
 L  link_444
 L  link_445
 L  link_446
 L  link_447
 L  link_448
 L  link_449
 L  link_450
 L  link_451
 L  link_452
 L  link_453
 L  link_454
 L  link_455
 L  link_456
 L  link_457
 L  link_458
 L  link_459
 L  link_460
 L  link_461
 L  link_462
 L  link_463
 L  link_464
 L  link_465
 L  link_466
 L  link_467
 L  link_468
 L  link_469
 L  link_470
 L  link_471
 L  link_472
 L  link_473
 L  link_474
 L  link_475
 L  link_476
 L  link_477
 L  link_478
 L  link_479
 L  link_480
 L  link_481
 L  link_482
 L  link_483
 L  link_484
 L  link_485
 L  link_486
 L  link_487
 L  link_488
 L  link_489
 L  link_490
 L  link_491
 L  link_492
 L  link_493
 L  link_494
COLUMNS
    x_0         OBJ       2.98
    x_0         flow_4      1.0
    x_0         flow_11     -1.0
    x_0         link_0      1.0
    x_1         OBJ       2.67
    x_1         flow_0      1.0
    x_1         flow_52     -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.57
    x_2         flow_33     1.0
    x_2         flow_30     -1.0
    x_2         link_2      1.0
    x_3         OBJ       61.31
    x_3         flow_39     1.0
    x_3         flow_1      -1.0
    x_3         link_3      1.0
    x_4         OBJ       71.59
    x_4         flow_11     1.0
    x_4         flow_22     -1.0
    x_4         link_4      1.0
    x_5         OBJ       40.4
    x_5         flow_45     1.0
    x_5         flow_0      -1.0
    x_5         link_5      1.0
    x_6         OBJ       1.99
    x_6         flow_32     1.0
    x_6         flow_7      -1.0
    x_6         link_6      1.0
    x_7         OBJ       40.35
    x_7         flow_36     1.0
    x_7         flow_35     -1.0
    x_7         link_7      1.0
    x_8         OBJ       68.49
    x_8         flow_6      1.0
    x_8         flow_24     -1.0
    x_8         link_8      1.0
    x_9         OBJ       1.08
    x_9         flow_13     1.0
    x_9         flow_54     -1.0
    x_9         link_9      1.0
    x_10        OBJ       69.93
    x_10        flow_8      1.0
    x_10        flow_39     -1.0
    x_10        link_10     1.0
    x_11        OBJ       0.88
    x_11        flow_42     1.0
    x_11        flow_35     -1.0
    x_11        link_11     1.0
    x_12        OBJ       53.05
    x_12        flow_25     1.0
    x_12        flow_45     -1.0
    x_12        link_12     1.0
    x_13        OBJ       0.75
    x_13        flow_33     1.0
    x_13        flow_5      -1.0
    x_13        link_13     1.0
    x_14        OBJ       0.96
    x_14        flow_6      1.0
    x_14        flow_49     -1.0
    x_14        link_14     1.0
    x_15        OBJ       78.94
    x_15        flow_19     1.0
    x_15        flow_45     -1.0
    x_15        link_15     1.0
    x_16        OBJ       43.5
    x_16        flow_6      1.0
    x_16        flow_12     -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.2
    x_17        flow_49     1.0
    x_17        flow_4      -1.0
    x_17        link_17     1.0
    x_18        OBJ       41.21
    x_18        flow_38     1.0
    x_18        flow_44     -1.0
    x_18        link_18     1.0
    x_19        OBJ       25.74
    x_19        flow_49     1.0
    x_19        flow_50     -1.0
    x_19        link_19     1.0
    x_20        OBJ       2.3
    x_20        flow_48     1.0
    x_20        flow_25     -1.0
    x_20        link_20     1.0
    x_21        OBJ       42.68
    x_21        flow_28     1.0
    x_21        flow_3      -1.0
    x_21        link_21     1.0
    x_22        OBJ       74.43
    x_22        flow_2      1.0
    x_22        flow_40     -1.0
    x_22        link_22     1.0
    x_23        OBJ       1.25
    x_23        flow_11     1.0
    x_23        flow_12     -1.0
    x_23        link_23     1.0
    x_24        OBJ       2.45
    x_24        flow_49     1.0
    x_24        flow_46     -1.0
    x_24        link_24     1.0
    x_25        OBJ       70.28
    x_25        flow_8      1.0
    x_25        flow_33     -1.0
    x_25        link_25     1.0
    x_26        OBJ       2.47
    x_26        flow_51     1.0
    x_26        flow_23     -1.0
    x_26        link_26     1.0
    x_27        OBJ       37.47
    x_27        flow_47     1.0
    x_27        flow_18     -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.47
    x_28        flow_51     1.0
    x_28        flow_41     -1.0
    x_28        link_28     1.0
    x_29        OBJ       1.93
    x_29        flow_25     1.0
    x_29        flow_16     -1.0
    x_29        link_29     1.0
    x_30        OBJ       1.29
    x_30        flow_6      1.0
    x_30        flow_16     -1.0
    x_30        link_30     1.0
    x_31        OBJ       74.63
    x_31        flow_28     1.0
    x_31        flow_53     -1.0
    x_31        link_31     1.0
    x_32        OBJ       25.98
    x_32        flow_34     1.0
    x_32        flow_46     -1.0
    x_32        link_32     1.0
    x_33        OBJ       61.01
    x_33        flow_16     1.0
    x_33        flow_3      -1.0
    x_33        link_33     1.0
    x_34        OBJ       1.66
    x_34        flow_18     1.0
    x_34        flow_24     -1.0
    x_34        link_34     1.0
    x_35        OBJ       1.58
    x_35        flow_34     1.0
    x_35        flow_44     -1.0
    x_35        link_35     1.0
    x_36        OBJ       51.17
    x_36        flow_43     1.0
    x_36        flow_16     -1.0
    x_36        link_36     1.0
    x_37        OBJ       0.96
    x_37        flow_28     1.0
    x_37        flow_41     -1.0
    x_37        link_37     1.0
    x_38        OBJ       0.8
    x_38        flow_34     1.0
    x_38        flow_47     -1.0
    x_38        link_38     1.0
    x_39        OBJ       55.89
    x_39        flow_25     1.0
    x_39        flow_29     -1.0
    x_39        link_39     1.0
    x_40        OBJ       70.8
    x_40        flow_53     1.0
    x_40        flow_15     -1.0
    x_40        link_40     1.0
    x_41        OBJ       2.96
    x_41        flow_32     1.0
    x_41        flow_27     -1.0
    x_41        link_41     1.0
    x_42        OBJ       52.17
    x_42        flow_6      1.0
    x_42        flow_28     -1.0
    x_42        link_42     1.0
    x_43        OBJ       39.52
    x_43        flow_53     1.0
    x_43        flow_22     -1.0
    x_43        link_43     1.0
    x_44        OBJ       51.64
    x_44        flow_53     1.0
    x_44        flow_32     -1.0
    x_44        link_44     1.0
    x_45        OBJ       0.79
    x_45        flow_9      1.0
    x_45        flow_38     -1.0
    x_45        link_45     1.0
    x_46        OBJ       2.48
    x_46        flow_47     1.0
    x_46        flow_45     -1.0
    x_46        link_46     1.0
    x_47        OBJ       0.9
    x_47        flow_27     1.0
    x_47        flow_2      -1.0
    x_47        link_47     1.0
    x_48        OBJ       2.95
    x_48        flow_44     1.0
    x_48        flow_2      -1.0
    x_48        link_48     1.0
    x_49        OBJ       2.86
    x_49        flow_39     1.0
    x_49        flow_26     -1.0
    x_49        link_49     1.0
    x_50        OBJ       1.54
    x_50        flow_16     1.0
    x_50        flow_52     -1.0
    x_50        link_50     1.0
    x_51        OBJ       2.27
    x_51        flow_35     1.0
    x_51        flow_20     -1.0
    x_51        link_51     1.0
    x_52        OBJ       1.58
    x_52        flow_11     1.0
    x_52        flow_14     -1.0
    x_52        link_52     1.0
    x_53        OBJ       77.59
    x_53        flow_49     1.0
    x_53        flow_3      -1.0
    x_53        link_53     1.0
    x_54        OBJ       51.78
    x_54        flow_26     1.0
    x_54        flow_47     -1.0
    x_54        link_54     1.0
    x_55        OBJ       49.42
    x_55        flow_40     1.0
    x_55        flow_13     -1.0
    x_55        link_55     1.0
    x_56        OBJ       1.45
    x_56        flow_15     1.0
    x_56        flow_42     -1.0
    x_56        link_56     1.0
    x_57        OBJ       1.82
    x_57        flow_10     1.0
    x_57        flow_54     -1.0
    x_57        link_57     1.0
    x_58        OBJ       63.21
    x_58        flow_27     1.0
    x_58        flow_51     -1.0
    x_58        link_58     1.0
    x_59        OBJ       1.92
    x_59        flow_30     1.0
    x_59        flow_24     -1.0
    x_59        link_59     1.0
    x_60        OBJ       1.22
    x_60        flow_48     1.0
    x_60        flow_41     -1.0
    x_60        link_60     1.0
    x_61        OBJ       69.08
    x_61        flow_50     1.0
    x_61        flow_37     -1.0
    x_61        link_61     1.0
    x_62        OBJ       2.71
    x_62        flow_12     1.0
    x_62        flow_45     -1.0
    x_62        link_62     1.0
    x_63        OBJ       1.51
    x_63        flow_8      1.0
    x_63        flow_0      -1.0
    x_63        link_63     1.0
    x_64        OBJ       79.64
    x_64        flow_2      1.0
    x_64        flow_18     -1.0
    x_64        link_64     1.0
    x_65        OBJ       0.82
    x_65        flow_22     1.0
    x_65        flow_53     -1.0
    x_65        link_65     1.0
    x_66        OBJ       1.59
    x_66        flow_26     1.0
    x_66        flow_24     -1.0
    x_66        link_66     1.0
    x_67        OBJ       1.16
    x_67        flow_1      1.0
    x_67        flow_3      -1.0
    x_67        link_67     1.0
    x_68        OBJ       20.67
    x_68        flow_50     1.0
    x_68        flow_36     -1.0
    x_68        link_68     1.0
    x_69        OBJ       58.77
    x_69        flow_40     1.0
    x_69        flow_3      -1.0
    x_69        link_69     1.0
    x_70        OBJ       34.05
    x_70        flow_46     1.0
    x_70        flow_33     -1.0
    x_70        link_70     1.0
    x_71        OBJ       0.63
    x_71        flow_16     1.0
    x_71        flow_36     -1.0
    x_71        link_71     1.0
    x_72        OBJ       56.22
    x_72        flow_49     1.0
    x_72        flow_11     -1.0
    x_72        link_72     1.0
    x_73        OBJ       1.14
    x_73        flow_2      1.0
    x_73        flow_19     -1.0
    x_73        link_73     1.0
    x_74        OBJ       62.67
    x_74        flow_19     1.0
    x_74        flow_35     -1.0
    x_74        link_74     1.0
    x_75        OBJ       1.46
    x_75        flow_52     1.0
    x_75        flow_2      -1.0
    x_75        link_75     1.0
    x_76        OBJ       73.24
    x_76        flow_25     1.0
    x_76        flow_4      -1.0
    x_76        link_76     1.0
    x_77        OBJ       33.44
    x_77        flow_21     1.0
    x_77        flow_4      -1.0
    x_77        link_77     1.0
    x_78        OBJ       72.98
    x_78        flow_18     1.0
    x_78        flow_15     -1.0
    x_78        link_78     1.0
    x_79        OBJ       2.5
    x_79        flow_21     1.0
    x_79        flow_23     -1.0
    x_79        link_79     1.0
    x_80        OBJ       49.18
    x_80        flow_35     1.0
    x_80        flow_31     -1.0
    x_80        link_80     1.0
    x_81        OBJ       2.76
    x_81        flow_29     1.0
    x_81        flow_50     -1.0
    x_81        link_81     1.0
    x_82        OBJ       2.22
    x_82        flow_5      1.0
    x_82        flow_54     -1.0
    x_82        link_82     1.0
    x_83        OBJ       40.02
    x_83        flow_13     1.0
    x_83        flow_53     -1.0
    x_83        link_83     1.0
    x_84        OBJ       1.09
    x_84        flow_23     1.0
    x_84        flow_7      -1.0
    x_84        link_84     1.0
    x_85        OBJ       51.49
    x_85        flow_18     1.0
    x_85        flow_32     -1.0
    x_85        link_85     1.0
    x_86        OBJ       1.97
    x_86        flow_9      1.0
    x_86        flow_28     -1.0
    x_86        link_86     1.0
    x_87        OBJ       21.82
    x_87        flow_6      1.0
    x_87        flow_54     -1.0
    x_87        link_87     1.0
    x_88        OBJ       38.47
    x_88        flow_49     1.0
    x_88        flow_39     -1.0
    x_88        link_88     1.0
    x_89        OBJ       2.01
    x_89        flow_53     1.0
    x_89        flow_9      -1.0
    x_89        link_89     1.0
    x_90        OBJ       1.18
    x_90        flow_17     1.0
    x_90        flow_24     -1.0
    x_90        link_90     1.0
    x_91        OBJ       53.26
    x_91        flow_22     1.0
    x_91        flow_2      -1.0
    x_91        link_91     1.0
    x_92        OBJ       38.56
    x_92        flow_3      1.0
    x_92        flow_43     -1.0
    x_92        link_92     1.0
    x_93        OBJ       1.49
    x_93        flow_23     1.0
    x_93        flow_1      -1.0
    x_93        link_93     1.0
    x_94        OBJ       39.93
    x_94        flow_35     1.0
    x_94        flow_24     -1.0
    x_94        link_94     1.0
    x_95        OBJ       2.21
    x_95        flow_3      1.0
    x_95        flow_46     -1.0
    x_95        link_95     1.0
    x_96        OBJ       0.63
    x_96        flow_17     1.0
    x_96        flow_31     -1.0
    x_96        link_96     1.0
    x_97        OBJ       2.8
    x_97        flow_27     1.0
    x_97        flow_30     -1.0
    x_97        link_97     1.0
    x_98        OBJ       57.55
    x_98        flow_29     1.0
    x_98        flow_34     -1.0
    x_98        link_98     1.0
    x_99        OBJ       2.64
    x_99        flow_12     1.0
    x_99        flow_16     -1.0
    x_99        link_99     1.0
    x_100       OBJ       32.02
    x_100       flow_3      1.0
    x_100       flow_18     -1.0
    x_100       link_100    1.0
    x_101       OBJ       50.9
    x_101       flow_0      1.0
    x_101       flow_24     -1.0
    x_101       link_101    1.0
    x_102       OBJ       1.78
    x_102       flow_9      1.0
    x_102       flow_40     -1.0
    x_102       link_102    1.0
    x_103       OBJ       30.17
    x_103       flow_32     1.0
    x_103       flow_47     -1.0
    x_103       link_103    1.0
    x_104       OBJ       2.85
    x_104       flow_13     1.0
    x_104       flow_43     -1.0
    x_104       link_104    1.0
    x_105       OBJ       2.86
    x_105       flow_37     1.0
    x_105       flow_16     -1.0
    x_105       link_105    1.0
    x_106       OBJ       26.6
    x_106       flow_41     1.0
    x_106       flow_20     -1.0
    x_106       link_106    1.0
    x_107       OBJ       69.08
    x_107       flow_18     1.0
    x_107       flow_19     -1.0
    x_107       link_107    1.0
    x_108       OBJ       2.12
    x_108       flow_10     1.0
    x_108       flow_33     -1.0
    x_108       link_108    1.0
    x_109       OBJ       1.21
    x_109       flow_54     1.0
    x_109       flow_5      -1.0
    x_109       link_109    1.0
    x_110       OBJ       70.05
    x_110       flow_53     1.0
    x_110       flow_31     -1.0
    x_110       link_110    1.0
    x_111       OBJ       50.26
    x_111       flow_44     1.0
    x_111       flow_12     -1.0
    x_111       link_111    1.0
    x_112       OBJ       2.02
    x_112       flow_30     1.0
    x_112       flow_26     -1.0
    x_112       link_112    1.0
    x_113       OBJ       2.83
    x_113       flow_47     1.0
    x_113       flow_4      -1.0
    x_113       link_113    1.0
    x_114       OBJ       0.64
    x_114       flow_16     1.0
    x_114       flow_7      -1.0
    x_114       link_114    1.0
    x_115       OBJ       32.05
    x_115       flow_23     1.0
    x_115       flow_31     -1.0
    x_115       link_115    1.0
    x_116       OBJ       2.53
    x_116       flow_42     1.0
    x_116       flow_38     -1.0
    x_116       link_116    1.0
    x_117       OBJ       70.91
    x_117       flow_43     1.0
    x_117       flow_3      -1.0
    x_117       link_117    1.0
    x_118       OBJ       60.34
    x_118       flow_16     1.0
    x_118       flow_48     -1.0
    x_118       link_118    1.0
    x_119       OBJ       2.83
    x_119       flow_32     1.0
    x_119       flow_0      -1.0
    x_119       link_119    1.0
    x_120       OBJ       64.36
    x_120       flow_17     1.0
    x_120       flow_3      -1.0
    x_120       link_120    1.0
    x_121       OBJ       1.46
    x_121       flow_45     1.0
    x_121       flow_6      -1.0
    x_121       link_121    1.0
    x_122       OBJ       2.52
    x_122       flow_1      1.0
    x_122       flow_43     -1.0
    x_122       link_122    1.0
    x_123       OBJ       2.09
    x_123       flow_21     1.0
    x_123       flow_0      -1.0
    x_123       link_123    1.0
    x_124       OBJ       46.01
    x_124       flow_4      1.0
    x_124       flow_6      -1.0
    x_124       link_124    1.0
    x_125       OBJ       1.64
    x_125       flow_52     1.0
    x_125       flow_40     -1.0
    x_125       link_125    1.0
    x_126       OBJ       50.24
    x_126       flow_18     1.0
    x_126       flow_26     -1.0
    x_126       link_126    1.0
    x_127       OBJ       0.67
    x_127       flow_34     1.0
    x_127       flow_20     -1.0
    x_127       link_127    1.0
    x_128       OBJ       78.82
    x_128       flow_24     1.0
    x_128       flow_17     -1.0
    x_128       link_128    1.0
    x_129       OBJ       28.84
    x_129       flow_8      1.0
    x_129       flow_44     -1.0
    x_129       link_129    1.0
    x_130       OBJ       2.99
    x_130       flow_31     1.0
    x_130       flow_45     -1.0
    x_130       link_130    1.0
    x_131       OBJ       76.92
    x_131       flow_35     1.0
    x_131       flow_48     -1.0
    x_131       link_131    1.0
    x_132       OBJ       25.18
    x_132       flow_29     1.0
    x_132       flow_16     -1.0
    x_132       link_132    1.0
    x_133       OBJ       77.09
    x_133       flow_13     1.0
    x_133       flow_47     -1.0
    x_133       link_133    1.0
    x_134       OBJ       75.87
    x_134       flow_35     1.0
    x_134       flow_11     -1.0
    x_134       link_134    1.0
    x_135       OBJ       65.11
    x_135       flow_0      1.0
    x_135       flow_39     -1.0
    x_135       link_135    1.0
    x_136       OBJ       0.98
    x_136       flow_2      1.0
    x_136       flow_6      -1.0
    x_136       link_136    1.0
    x_137       OBJ       2.56
    x_137       flow_3      1.0
    x_137       flow_50     -1.0
    x_137       link_137    1.0
    x_138       OBJ       2.03
    x_138       flow_7      1.0
    x_138       flow_26     -1.0
    x_138       link_138    1.0
    x_139       OBJ       1.0
    x_139       flow_19     1.0
    x_139       flow_14     -1.0
    x_139       link_139    1.0
    x_140       OBJ       60.36
    x_140       flow_15     1.0
    x_140       flow_37     -1.0
    x_140       link_140    1.0
    x_141       OBJ       2.88
    x_141       flow_23     1.0
    x_141       flow_29     -1.0
    x_141       link_141    1.0
    x_142       OBJ       79.21
    x_142       flow_25     1.0
    x_142       flow_54     -1.0
    x_142       link_142    1.0
    x_143       OBJ       48.27
    x_143       flow_46     1.0
    x_143       flow_39     -1.0
    x_143       link_143    1.0
    x_144       OBJ       2.04
    x_144       flow_23     1.0
    x_144       flow_19     -1.0
    x_144       link_144    1.0
    x_145       OBJ       2.78
    x_145       flow_49     1.0
    x_145       flow_7      -1.0
    x_145       link_145    1.0
    x_146       OBJ       25.67
    x_146       flow_49     1.0
    x_146       flow_37     -1.0
    x_146       link_146    1.0
    x_147       OBJ       64.98
    x_147       flow_42     1.0
    x_147       flow_21     -1.0
    x_147       link_147    1.0
    x_148       OBJ       1.02
    x_148       flow_21     1.0
    x_148       flow_18     -1.0
    x_148       link_148    1.0
    x_149       OBJ       2.86
    x_149       flow_6      1.0
    x_149       flow_37     -1.0
    x_149       link_149    1.0
    x_150       OBJ       36.56
    x_150       flow_26     1.0
    x_150       flow_44     -1.0
    x_150       link_150    1.0
    x_151       OBJ       1.31
    x_151       flow_6      1.0
    x_151       flow_45     -1.0
    x_151       link_151    1.0
    x_152       OBJ       68.89
    x_152       flow_44     1.0
    x_152       flow_7      -1.0
    x_152       link_152    1.0
    x_153       OBJ       67.06
    x_153       flow_3      1.0
    x_153       flow_20     -1.0
    x_153       link_153    1.0
    x_154       OBJ       1.23
    x_154       flow_7      1.0
    x_154       flow_23     -1.0
    x_154       link_154    1.0
    x_155       OBJ       2.04
    x_155       flow_10     1.0
    x_155       flow_32     -1.0
    x_155       link_155    1.0
    x_156       OBJ       72.87
    x_156       flow_25     1.0
    x_156       flow_32     -1.0
    x_156       link_156    1.0
    x_157       OBJ       2.86
    x_157       flow_24     1.0
    x_157       flow_53     -1.0
    x_157       link_157    1.0
    x_158       OBJ       41.45
    x_158       flow_41     1.0
    x_158       flow_15     -1.0
    x_158       link_158    1.0
    x_159       OBJ       69.04
    x_159       flow_52     1.0
    x_159       flow_13     -1.0
    x_159       link_159    1.0
    x_160       OBJ       2.24
    x_160       flow_4      1.0
    x_160       flow_22     -1.0
    x_160       link_160    1.0
    x_161       OBJ       2.82
    x_161       flow_19     1.0
    x_161       flow_33     -1.0
    x_161       link_161    1.0
    x_162       OBJ       1.19
    x_162       flow_28     1.0
    x_162       flow_22     -1.0
    x_162       link_162    1.0
    x_163       OBJ       1.7
    x_163       flow_3      1.0
    x_163       flow_23     -1.0
    x_163       link_163    1.0
    x_164       OBJ       1.1
    x_164       flow_0      1.0
    x_164       flow_11     -1.0
    x_164       link_164    1.0
    x_165       OBJ       1.28
    x_165       flow_30     1.0
    x_165       flow_42     -1.0
    x_165       link_165    1.0
    x_166       OBJ       42.77
    x_166       flow_49     1.0
    x_166       flow_42     -1.0
    x_166       link_166    1.0
    x_167       OBJ       2.28
    x_167       flow_33     1.0
    x_167       flow_13     -1.0
    x_167       link_167    1.0
    x_168       OBJ       2.82
    x_168       flow_1      1.0
    x_168       flow_50     -1.0
    x_168       link_168    1.0
    x_169       OBJ       37.88
    x_169       flow_30     1.0
    x_169       flow_35     -1.0
    x_169       link_169    1.0
    x_170       OBJ       2.65
    x_170       flow_31     1.0
    x_170       flow_43     -1.0
    x_170       link_170    1.0
    x_171       OBJ       2.47
    x_171       flow_38     1.0
    x_171       flow_11     -1.0
    x_171       link_171    1.0
    x_172       OBJ       39.99
    x_172       flow_2      1.0
    x_172       flow_35     -1.0
    x_172       link_172    1.0
    x_173       OBJ       2.72
    x_173       flow_41     1.0
    x_173       flow_29     -1.0
    x_173       link_173    1.0
    x_174       OBJ       2.23
    x_174       flow_12     1.0
    x_174       flow_46     -1.0
    x_174       link_174    1.0
    x_175       OBJ       2.76
    x_175       flow_25     1.0
    x_175       flow_1      -1.0
    x_175       link_175    1.0
    x_176       OBJ       28.67
    x_176       flow_45     1.0
    x_176       flow_11     -1.0
    x_176       link_176    1.0
    x_177       OBJ       2.12
    x_177       flow_17     1.0
    x_177       flow_22     -1.0
    x_177       link_177    1.0
    x_178       OBJ       53.98
    x_178       flow_23     1.0
    x_178       flow_39     -1.0
    x_178       link_178    1.0
    x_179       OBJ       3.0
    x_179       flow_20     1.0
    x_179       flow_22     -1.0
    x_179       link_179    1.0
    x_180       OBJ       1.52
    x_180       flow_11     1.0
    x_180       flow_3      -1.0
    x_180       link_180    1.0
    x_181       OBJ       1.85
    x_181       flow_47     1.0
    x_181       flow_19     -1.0
    x_181       link_181    1.0
    x_182       OBJ       24.31
    x_182       flow_38     1.0
    x_182       flow_13     -1.0
    x_182       link_182    1.0
    x_183       OBJ       33.44
    x_183       flow_37     1.0
    x_183       flow_29     -1.0
    x_183       link_183    1.0
    x_184       OBJ       48.6
    x_184       flow_45     1.0
    x_184       flow_39     -1.0
    x_184       link_184    1.0
    x_185       OBJ       2.53
    x_185       flow_43     1.0
    x_185       flow_33     -1.0
    x_185       link_185    1.0
    x_186       OBJ       1.09
    x_186       flow_10     1.0
    x_186       flow_0      -1.0
    x_186       link_186    1.0
    x_187       OBJ       2.93
    x_187       flow_1      1.0
    x_187       flow_36     -1.0
    x_187       link_187    1.0
    x_188       OBJ       76.4
    x_188       flow_40     1.0
    x_188       flow_43     -1.0
    x_188       link_188    1.0
    x_189       OBJ       2.12
    x_189       flow_10     1.0
    x_189       flow_13     -1.0
    x_189       link_189    1.0
    x_190       OBJ       58.19
    x_190       flow_5      1.0
    x_190       flow_41     -1.0
    x_190       link_190    1.0
    x_191       OBJ       35.52
    x_191       flow_41     1.0
    x_191       flow_0      -1.0
    x_191       link_191    1.0
    x_192       OBJ       2.31
    x_192       flow_13     1.0
    x_192       flow_8      -1.0
    x_192       link_192    1.0
    x_193       OBJ       60.13
    x_193       flow_3      1.0
    x_193       flow_7      -1.0
    x_193       link_193    1.0
    x_194       OBJ       2.75
    x_194       flow_7      1.0
    x_194       flow_33     -1.0
    x_194       link_194    1.0
    x_195       OBJ       37.46
    x_195       flow_27     1.0
    x_195       flow_18     -1.0
    x_195       link_195    1.0
    x_196       OBJ       1.98
    x_196       flow_45     1.0
    x_196       flow_47     -1.0
    x_196       link_196    1.0
    x_197       OBJ       65.02
    x_197       flow_3      1.0
    x_197       flow_27     -1.0
    x_197       link_197    1.0
    x_198       OBJ       1.62
    x_198       flow_18     1.0
    x_198       flow_45     -1.0
    x_198       link_198    1.0
    x_199       OBJ       76.53
    x_199       flow_21     1.0
    x_199       flow_34     -1.0
    x_199       link_199    1.0
    x_200       OBJ       63.1
    x_200       flow_32     1.0
    x_200       flow_1      -1.0
    x_200       link_200    1.0
    x_201       OBJ       55.99
    x_201       flow_1      1.0
    x_201       flow_54     -1.0
    x_201       link_201    1.0
    x_202       OBJ       62.29
    x_202       flow_14     1.0
    x_202       flow_13     -1.0
    x_202       link_202    1.0
    x_203       OBJ       2.93
    x_203       flow_1      1.0
    x_203       flow_49     -1.0
    x_203       link_203    1.0
    x_204       OBJ       46.38
    x_204       flow_12     1.0
    x_204       flow_2      -1.0
    x_204       link_204    1.0
    x_205       OBJ       59.9
    x_205       flow_15     1.0
    x_205       flow_32     -1.0
    x_205       link_205    1.0
    x_206       OBJ       46.23
    x_206       flow_27     1.0
    x_206       flow_34     -1.0
    x_206       link_206    1.0
    x_207       OBJ       65.41
    x_207       flow_31     1.0
    x_207       flow_15     -1.0
    x_207       link_207    1.0
    x_208       OBJ       23.14
    x_208       flow_29     1.0
    x_208       flow_12     -1.0
    x_208       link_208    1.0
    x_209       OBJ       60.65
    x_209       flow_5      1.0
    x_209       flow_36     -1.0
    x_209       link_209    1.0
    x_210       OBJ       2.78
    x_210       flow_18     1.0
    x_210       flow_20     -1.0
    x_210       link_210    1.0
    x_211       OBJ       52.27
    x_211       flow_3      1.0
    x_211       flow_34     -1.0
    x_211       link_211    1.0
    x_212       OBJ       1.9
    x_212       flow_30     1.0
    x_212       flow_17     -1.0
    x_212       link_212    1.0
    x_213       OBJ       2.61
    x_213       flow_25     1.0
    x_213       flow_52     -1.0
    x_213       link_213    1.0
    x_214       OBJ       50.46
    x_214       flow_1      1.0
    x_214       flow_17     -1.0
    x_214       link_214    1.0
    x_215       OBJ       23.34
    x_215       flow_49     1.0
    x_215       flow_2      -1.0
    x_215       link_215    1.0
    x_216       OBJ       0.91
    x_216       flow_22     1.0
    x_216       flow_12     -1.0
    x_216       link_216    1.0
    x_217       OBJ       1.69
    x_217       flow_48     1.0
    x_217       flow_26     -1.0
    x_217       link_217    1.0
    x_218       OBJ       51.79
    x_218       flow_46     1.0
    x_218       flow_4      -1.0
    x_218       link_218    1.0
    x_219       OBJ       58.03
    x_219       flow_32     1.0
    x_219       flow_3      -1.0
    x_219       link_219    1.0
    x_220       OBJ       66.13
    x_220       flow_7      1.0
    x_220       flow_48     -1.0
    x_220       link_220    1.0
    x_221       OBJ       43.92
    x_221       flow_14     1.0
    x_221       flow_18     -1.0
    x_221       link_221    1.0
    x_222       OBJ       1.06
    x_222       flow_10     1.0
    x_222       flow_40     -1.0
    x_222       link_222    1.0
    x_223       OBJ       61.74
    x_223       flow_5      1.0
    x_223       flow_10     -1.0
    x_223       link_223    1.0
    x_224       OBJ       1.8
    x_224       flow_18     1.0
    x_224       flow_48     -1.0
    x_224       link_224    1.0
    x_225       OBJ       1.71
    x_225       flow_15     1.0
    x_225       flow_28     -1.0
    x_225       link_225    1.0
    x_226       OBJ       1.01
    x_226       flow_21     1.0
    x_226       flow_16     -1.0
    x_226       link_226    1.0
    x_227       OBJ       60.02
    x_227       flow_13     1.0
    x_227       flow_40     -1.0
    x_227       link_227    1.0
    x_228       OBJ       42.47
    x_228       flow_53     1.0
    x_228       flow_3      -1.0
    x_228       link_228    1.0
    x_229       OBJ       0.69
    x_229       flow_4      1.0
    x_229       flow_28     -1.0
    x_229       link_229    1.0
    x_230       OBJ       1.97
    x_230       flow_29     1.0
    x_230       flow_33     -1.0
    x_230       link_230    1.0
    x_231       OBJ       65.94
    x_231       flow_20     1.0
    x_231       flow_4      -1.0
    x_231       link_231    1.0
    x_232       OBJ       54.93
    x_232       flow_25     1.0
    x_232       flow_43     -1.0
    x_232       link_232    1.0
    x_233       OBJ       1.26
    x_233       flow_33     1.0
    x_233       flow_24     -1.0
    x_233       link_233    1.0
    x_234       OBJ       34.88
    x_234       flow_25     1.0
    x_234       flow_39     -1.0
    x_234       link_234    1.0
    x_235       OBJ       1.34
    x_235       flow_14     1.0
    x_235       flow_23     -1.0
    x_235       link_235    1.0
    x_236       OBJ       62.04
    x_236       flow_49     1.0
    x_236       flow_5      -1.0
    x_236       link_236    1.0
    x_237       OBJ       2.61
    x_237       flow_53     1.0
    x_237       flow_44     -1.0
    x_237       link_237    1.0
    x_238       OBJ       27.42
    x_238       flow_30     1.0
    x_238       flow_52     -1.0
    x_238       link_238    1.0
    x_239       OBJ       60.25
    x_239       flow_29     1.0
    x_239       flow_27     -1.0
    x_239       link_239    1.0
    x_240       OBJ       51.47
    x_240       flow_53     1.0
    x_240       flow_29     -1.0
    x_240       link_240    1.0
    x_241       OBJ       27.3
    x_241       flow_4      1.0
    x_241       flow_26     -1.0
    x_241       link_241    1.0
    x_242       OBJ       2.25
    x_242       flow_33     1.0
    x_242       flow_39     -1.0
    x_242       link_242    1.0
    x_243       OBJ       1.48
    x_243       flow_52     1.0
    x_243       flow_48     -1.0
    x_243       link_243    1.0
    x_244       OBJ       2.29
    x_244       flow_53     1.0
    x_244       flow_33     -1.0
    x_244       link_244    1.0
    x_245       OBJ       1.42
    x_245       flow_5      1.0
    x_245       flow_46     -1.0
    x_245       link_245    1.0
    x_246       OBJ       70.95
    x_246       flow_34     1.0
    x_246       flow_38     -1.0
    x_246       link_246    1.0
    x_247       OBJ       1.27
    x_247       flow_52     1.0
    x_247       flow_12     -1.0
    x_247       link_247    1.0
    x_248       OBJ       2.1
    x_248       flow_23     1.0
    x_248       flow_45     -1.0
    x_248       link_248    1.0
    x_249       OBJ       2.55
    x_249       flow_19     1.0
    x_249       flow_8      -1.0
    x_249       link_249    1.0
    x_250       OBJ       58.92
    x_250       flow_52     1.0
    x_250       flow_23     -1.0
    x_250       link_250    1.0
    x_251       OBJ       56.49
    x_251       flow_8      1.0
    x_251       flow_38     -1.0
    x_251       link_251    1.0
    x_252       OBJ       73.46
    x_252       flow_49     1.0
    x_252       flow_30     -1.0
    x_252       link_252    1.0
    x_253       OBJ       32.64
    x_253       flow_13     1.0
    x_253       flow_12     -1.0
    x_253       link_253    1.0
    x_254       OBJ       2.89
    x_254       flow_19     1.0
    x_254       flow_48     -1.0
    x_254       link_254    1.0
    x_255       OBJ       0.61
    x_255       flow_16     1.0
    x_255       flow_2      -1.0
    x_255       link_255    1.0
    x_256       OBJ       44.7
    x_256       flow_32     1.0
    x_256       flow_11     -1.0
    x_256       link_256    1.0
    x_257       OBJ       1.39
    x_257       flow_38     1.0
    x_257       flow_34     -1.0
    x_257       link_257    1.0
    x_258       OBJ       44.95
    x_258       flow_42     1.0
    x_258       flow_40     -1.0
    x_258       link_258    1.0
    x_259       OBJ       69.02
    x_259       flow_3      1.0
    x_259       flow_52     -1.0
    x_259       link_259    1.0
    x_260       OBJ       2.81
    x_260       flow_45     1.0
    x_260       flow_42     -1.0
    x_260       link_260    1.0
    x_261       OBJ       53.81
    x_261       flow_5      1.0
    x_261       flow_17     -1.0
    x_261       link_261    1.0
    x_262       OBJ       1.7
    x_262       flow_50     1.0
    x_262       flow_4      -1.0
    x_262       link_262    1.0
    x_263       OBJ       1.57
    x_263       flow_40     1.0
    x_263       flow_28     -1.0
    x_263       link_263    1.0
    x_264       OBJ       1.12
    x_264       flow_13     1.0
    x_264       flow_42     -1.0
    x_264       link_264    1.0
    x_265       OBJ       75.05
    x_265       flow_39     1.0
    x_265       flow_22     -1.0
    x_265       link_265    1.0
    x_266       OBJ       2.17
    x_266       flow_27     1.0
    x_266       flow_5      -1.0
    x_266       link_266    1.0
    x_267       OBJ       2.04
    x_267       flow_44     1.0
    x_267       flow_17     -1.0
    x_267       link_267    1.0
    x_268       OBJ       56.31
    x_268       flow_15     1.0
    x_268       flow_35     -1.0
    x_268       link_268    1.0
    x_269       OBJ       1.19
    x_269       flow_27     1.0
    x_269       flow_25     -1.0
    x_269       link_269    1.0
    x_270       OBJ       43.88
    x_270       flow_20     1.0
    x_270       flow_48     -1.0
    x_270       link_270    1.0
    x_271       OBJ       1.23
    x_271       flow_35     1.0
    x_271       flow_37     -1.0
    x_271       link_271    1.0
    x_272       OBJ       26.62
    x_272       flow_29     1.0
    x_272       flow_51     -1.0
    x_272       link_272    1.0
    x_273       OBJ       54.89
    x_273       flow_24     1.0
    x_273       flow_48     -1.0
    x_273       link_273    1.0
    x_274       OBJ       78.19
    x_274       flow_36     1.0
    x_274       flow_23     -1.0
    x_274       link_274    1.0
    x_275       OBJ       2.16
    x_275       flow_39     1.0
    x_275       flow_0      -1.0
    x_275       link_275    1.0
    x_276       OBJ       70.5
    x_276       flow_33     1.0
    x_276       flow_3      -1.0
    x_276       link_276    1.0
    x_277       OBJ       2.29
    x_277       flow_32     1.0
    x_277       flow_8      -1.0
    x_277       link_277    1.0
    x_278       OBJ       0.79
    x_278       flow_2      1.0
    x_278       flow_33     -1.0
    x_278       link_278    1.0
    x_279       OBJ       63.52
    x_279       flow_32     1.0
    x_279       flow_22     -1.0
    x_279       link_279    1.0
    x_280       OBJ       2.81
    x_280       flow_16     1.0
    x_280       flow_54     -1.0
    x_280       link_280    1.0
    x_281       OBJ       2.57
    x_281       flow_54     1.0
    x_281       flow_35     -1.0
    x_281       link_281    1.0
    x_282       OBJ       63.76
    x_282       flow_17     1.0
    x_282       flow_21     -1.0
    x_282       link_282    1.0
    x_283       OBJ       2.74
    x_283       flow_4      1.0
    x_283       flow_3      -1.0
    x_283       link_283    1.0
    x_284       OBJ       65.38
    x_284       flow_6      1.0
    x_284       flow_26     -1.0
    x_284       link_284    1.0
    x_285       OBJ       21.03
    x_285       flow_16     1.0
    x_285       flow_44     -1.0
    x_285       link_285    1.0
    x_286       OBJ       1.1
    x_286       flow_49     1.0
    x_286       flow_28     -1.0
    x_286       link_286    1.0
    x_287       OBJ       29.63
    x_287       flow_47     1.0
    x_287       flow_48     -1.0
    x_287       link_287    1.0
    x_288       OBJ       28.07
    x_288       flow_18     1.0
    x_288       flow_49     -1.0
    x_288       link_288    1.0
    x_289       OBJ       2.14
    x_289       flow_9      1.0
    x_289       flow_43     -1.0
    x_289       link_289    1.0
    x_290       OBJ       1.28
    x_290       flow_3      1.0
    x_290       flow_51     -1.0
    x_290       link_290    1.0
    x_291       OBJ       1.83
    x_291       flow_42     1.0
    x_291       flow_22     -1.0
    x_291       link_291    1.0
    x_292       OBJ       72.02
    x_292       flow_24     1.0
    x_292       flow_35     -1.0
    x_292       link_292    1.0
    x_293       OBJ       26.95
    x_293       flow_21     1.0
    x_293       flow_22     -1.0
    x_293       link_293    1.0
    x_294       OBJ       79.98
    x_294       flow_36     1.0
    x_294       flow_52     -1.0
    x_294       link_294    1.0
    x_295       OBJ       51.42
    x_295       flow_9      1.0
    x_295       flow_1      -1.0
    x_295       link_295    1.0
    x_296       OBJ       27.48
    x_296       flow_39     1.0
    x_296       flow_21     -1.0
    x_296       link_296    1.0
    x_297       OBJ       0.57
    x_297       flow_8      1.0
    x_297       flow_43     -1.0
    x_297       link_297    1.0
    x_298       OBJ       32.61
    x_298       flow_50     1.0
    x_298       flow_40     -1.0
    x_298       link_298    1.0
    x_299       OBJ       55.55
    x_299       flow_7      1.0
    x_299       flow_8      -1.0
    x_299       link_299    1.0
    x_300       OBJ       0.77
    x_300       flow_3      1.0
    x_300       flow_24     -1.0
    x_300       link_300    1.0
    x_301       OBJ       2.9
    x_301       flow_22     1.0
    x_301       flow_42     -1.0
    x_301       link_301    1.0
    x_302       OBJ       2.4
    x_302       flow_23     1.0
    x_302       flow_47     -1.0
    x_302       link_302    1.0
    x_303       OBJ       49.74
    x_303       flow_40     1.0
    x_303       flow_27     -1.0
    x_303       link_303    1.0
    x_304       OBJ       1.46
    x_304       flow_26     1.0
    x_304       flow_38     -1.0
    x_304       link_304    1.0
    x_305       OBJ       1.53
    x_305       flow_33     1.0
    x_305       flow_17     -1.0
    x_305       link_305    1.0
    x_306       OBJ       0.53
    x_306       flow_41     1.0
    x_306       flow_19     -1.0
    x_306       link_306    1.0
    x_307       OBJ       28.47
    x_307       flow_45     1.0
    x_307       flow_20     -1.0
    x_307       link_307    1.0
    x_308       OBJ       28.84
    x_308       flow_47     1.0
    x_308       flow_29     -1.0
    x_308       link_308    1.0
    x_309       OBJ       36.38
    x_309       flow_39     1.0
    x_309       flow_24     -1.0
    x_309       link_309    1.0
    x_310       OBJ       39.14
    x_310       flow_28     1.0
    x_310       flow_36     -1.0
    x_310       link_310    1.0
    x_311       OBJ       78.35
    x_311       flow_38     1.0
    x_311       flow_6      -1.0
    x_311       link_311    1.0
    x_312       OBJ       47.52
    x_312       flow_46     1.0
    x_312       flow_43     -1.0
    x_312       link_312    1.0
    x_313       OBJ       2.85
    x_313       flow_43     1.0
    x_313       flow_4      -1.0
    x_313       link_313    1.0
    x_314       OBJ       60.5
    x_314       flow_7      1.0
    x_314       flow_16     -1.0
    x_314       link_314    1.0
    x_315       OBJ       40.03
    x_315       flow_15     1.0
    x_315       flow_33     -1.0
    x_315       link_315    1.0
    x_316       OBJ       24.59
    x_316       flow_22     1.0
    x_316       flow_47     -1.0
    x_316       link_316    1.0
    x_317       OBJ       69.82
    x_317       flow_27     1.0
    x_317       flow_46     -1.0
    x_317       link_317    1.0
    x_318       OBJ       1.54
    x_318       flow_50     1.0
    x_318       flow_13     -1.0
    x_318       link_318    1.0
    x_319       OBJ       1.59
    x_319       flow_16     1.0
    x_319       flow_18     -1.0
    x_319       link_319    1.0
    x_320       OBJ       44.03
    x_320       flow_17     1.0
    x_320       flow_18     -1.0
    x_320       link_320    1.0
    x_321       OBJ       27.26
    x_321       flow_44     1.0
    x_321       flow_54     -1.0
    x_321       link_321    1.0
    x_322       OBJ       2.34
    x_322       flow_6      1.0
    x_322       flow_18     -1.0
    x_322       link_322    1.0
    x_323       OBJ       2.82
    x_323       flow_30     1.0
    x_323       flow_23     -1.0
    x_323       link_323    1.0
    x_324       OBJ       24.37
    x_324       flow_23     1.0
    x_324       flow_17     -1.0
    x_324       link_324    1.0
    x_325       OBJ       67.53
    x_325       flow_40     1.0
    x_325       flow_11     -1.0
    x_325       link_325    1.0
    x_326       OBJ       1.25
    x_326       flow_14     1.0
    x_326       flow_47     -1.0
    x_326       link_326    1.0
    x_327       OBJ       1.18
    x_327       flow_29     1.0
    x_327       flow_23     -1.0
    x_327       link_327    1.0
    x_328       OBJ       41.89
    x_328       flow_14     1.0
    x_328       flow_34     -1.0
    x_328       link_328    1.0
    x_329       OBJ       0.57
    x_329       flow_18     1.0
    x_329       flow_34     -1.0
    x_329       link_329    1.0
    x_330       OBJ       0.52
    x_330       flow_26     1.0
    x_330       flow_45     -1.0
    x_330       link_330    1.0
    x_331       OBJ       0.73
    x_331       flow_16     1.0
    x_331       flow_10     -1.0
    x_331       link_331    1.0
    x_332       OBJ       1.28
    x_332       flow_43     1.0
    x_332       flow_18     -1.0
    x_332       link_332    1.0
    x_333       OBJ       25.06
    x_333       flow_40     1.0
    x_333       flow_7      -1.0
    x_333       link_333    1.0
    x_334       OBJ       22.39
    x_334       flow_38     1.0
    x_334       flow_46     -1.0
    x_334       link_334    1.0
    x_335       OBJ       21.03
    x_335       flow_9      1.0
    x_335       flow_53     -1.0
    x_335       link_335    1.0
    x_336       OBJ       1.93
    x_336       flow_44     1.0
    x_336       flow_21     -1.0
    x_336       link_336    1.0
    x_337       OBJ       51.66
    x_337       flow_33     1.0
    x_337       flow_53     -1.0
    x_337       link_337    1.0
    x_338       OBJ       75.32
    x_338       flow_49     1.0
    x_338       flow_27     -1.0
    x_338       link_338    1.0
    x_339       OBJ       2.45
    x_339       flow_26     1.0
    x_339       flow_32     -1.0
    x_339       link_339    1.0
    x_340       OBJ       1.94
    x_340       flow_0      1.0
    x_340       flow_42     -1.0
    x_340       link_340    1.0
    x_341       OBJ       46.56
    x_341       flow_0      1.0
    x_341       flow_17     -1.0
    x_341       link_341    1.0
    x_342       OBJ       1.02
    x_342       flow_22     1.0
    x_342       flow_13     -1.0
    x_342       link_342    1.0
    x_343       OBJ       2.33
    x_343       flow_54     1.0
    x_343       flow_52     -1.0
    x_343       link_343    1.0
    x_344       OBJ       2.57
    x_344       flow_23     1.0
    x_344       flow_15     -1.0
    x_344       link_344    1.0
    x_345       OBJ       30.33
    x_345       flow_15     1.0
    x_345       flow_20     -1.0
    x_345       link_345    1.0
    x_346       OBJ       50.09
    x_346       flow_8      1.0
    x_346       flow_21     -1.0
    x_346       link_346    1.0
    x_347       OBJ       0.89
    x_347       flow_1      1.0
    x_347       flow_52     -1.0
    x_347       link_347    1.0
    x_348       OBJ       59.69
    x_348       flow_42     1.0
    x_348       flow_3      -1.0
    x_348       link_348    1.0
    x_349       OBJ       24.35
    x_349       flow_10     1.0
    x_349       flow_31     -1.0
    x_349       link_349    1.0
    x_350       OBJ       64.44
    x_350       flow_2      1.0
    x_350       flow_17     -1.0
    x_350       link_350    1.0
    x_351       OBJ       21.31
    x_351       flow_46     1.0
    x_351       flow_13     -1.0
    x_351       link_351    1.0
    x_352       OBJ       2.1
    x_352       flow_45     1.0
    x_352       flow_44     -1.0
    x_352       link_352    1.0
    x_353       OBJ       32.24
    x_353       flow_28     1.0
    x_353       flow_29     -1.0
    x_353       link_353    1.0
    x_354       OBJ       2.06
    x_354       flow_45     1.0
    x_354       flow_7      -1.0
    x_354       link_354    1.0
    x_355       OBJ       50.78
    x_355       flow_24     1.0
    x_355       flow_5      -1.0
    x_355       link_355    1.0
    x_356       OBJ       1.51
    x_356       flow_12     1.0
    x_356       flow_18     -1.0
    x_356       link_356    1.0
    x_357       OBJ       44.12
    x_357       flow_24     1.0
    x_357       flow_45     -1.0
    x_357       link_357    1.0
    x_358       OBJ       34.92
    x_358       flow_46     1.0
    x_358       flow_0      -1.0
    x_358       link_358    1.0
    x_359       OBJ       40.94
    x_359       flow_41     1.0
    x_359       flow_33     -1.0
    x_359       link_359    1.0
    x_360       OBJ       68.64
    x_360       flow_42     1.0
    x_360       flow_41     -1.0
    x_360       link_360    1.0
    x_361       OBJ       2.44
    x_361       flow_6      1.0
    x_361       flow_44     -1.0
    x_361       link_361    1.0
    x_362       OBJ       1.36
    x_362       flow_3      1.0
    x_362       flow_2      -1.0
    x_362       link_362    1.0
    x_363       OBJ       53.98
    x_363       flow_37     1.0
    x_363       flow_44     -1.0
    x_363       link_363    1.0
    x_364       OBJ       48.05
    x_364       flow_33     1.0
    x_364       flow_11     -1.0
    x_364       link_364    1.0
    x_365       OBJ       63.17
    x_365       flow_40     1.0
    x_365       flow_6      -1.0
    x_365       link_365    1.0
    x_366       OBJ       2.3
    x_366       flow_47     1.0
    x_366       flow_25     -1.0
    x_366       link_366    1.0
    x_367       OBJ       78.35
    x_367       flow_18     1.0
    x_367       flow_2      -1.0
    x_367       link_367    1.0
    x_368       OBJ       47.74
    x_368       flow_31     1.0
    x_368       flow_50     -1.0
    x_368       link_368    1.0
    x_369       OBJ       1.68
    x_369       flow_17     1.0
    x_369       flow_12     -1.0
    x_369       link_369    1.0
    x_370       OBJ       51.4
    x_370       flow_17     1.0
    x_370       flow_27     -1.0
    x_370       link_370    1.0
    x_371       OBJ       1.18
    x_371       flow_14     1.0
    x_371       flow_9      -1.0
    x_371       link_371    1.0
    x_372       OBJ       55.45
    x_372       flow_29     1.0
    x_372       flow_6      -1.0
    x_372       link_372    1.0
    x_373       OBJ       47.38
    x_373       flow_17     1.0
    x_373       flow_49     -1.0
    x_373       link_373    1.0
    x_374       OBJ       47.0
    x_374       flow_16     1.0
    x_374       flow_17     -1.0
    x_374       link_374    1.0
    x_375       OBJ       64.86
    x_375       flow_40     1.0
    x_375       flow_33     -1.0
    x_375       link_375    1.0
    x_376       OBJ       45.92
    x_376       flow_17     1.0
    x_376       flow_28     -1.0
    x_376       link_376    1.0
    x_377       OBJ       71.43
    x_377       flow_14     1.0
    x_377       flow_16     -1.0
    x_377       link_377    1.0
    x_378       OBJ       79.82
    x_378       flow_25     1.0
    x_378       flow_21     -1.0
    x_378       link_378    1.0
    x_379       OBJ       68.09
    x_379       flow_14     1.0
    x_379       flow_19     -1.0
    x_379       link_379    1.0
    x_380       OBJ       78.93
    x_380       flow_12     1.0
    x_380       flow_15     -1.0
    x_380       link_380    1.0
    x_381       OBJ       79.27
    x_381       flow_17     1.0
    x_381       flow_36     -1.0
    x_381       link_381    1.0
    x_382       OBJ       1.57
    x_382       flow_51     1.0
    x_382       flow_33     -1.0
    x_382       link_382    1.0
    x_383       OBJ       0.55
    x_383       flow_3      1.0
    x_383       flow_21     -1.0
    x_383       link_383    1.0
    x_384       OBJ       1.03
    x_384       flow_8      1.0
    x_384       flow_54     -1.0
    x_384       link_384    1.0
    x_385       OBJ       1.85
    x_385       flow_22     1.0
    x_385       flow_30     -1.0
    x_385       link_385    1.0
    x_386       OBJ       1.11
    x_386       flow_31     1.0
    x_386       flow_32     -1.0
    x_386       link_386    1.0
    x_387       OBJ       78.19
    x_387       flow_26     1.0
    x_387       flow_8      -1.0
    x_387       link_387    1.0
    x_388       OBJ       1.68
    x_388       flow_30     1.0
    x_388       flow_11     -1.0
    x_388       link_388    1.0
    x_389       OBJ       2.93
    x_389       flow_53     1.0
    x_389       flow_7      -1.0
    x_389       link_389    1.0
    x_390       OBJ       0.51
    x_390       flow_8      1.0
    x_390       flow_34     -1.0
    x_390       link_390    1.0
    x_391       OBJ       72.96
    x_391       flow_3      1.0
    x_391       flow_54     -1.0
    x_391       link_391    1.0
    x_392       OBJ       20.31
    x_392       flow_4      1.0
    x_392       flow_34     -1.0
    x_392       link_392    1.0
    x_393       OBJ       0.54
    x_393       flow_16     1.0
    x_393       flow_38     -1.0
    x_393       link_393    1.0
    x_394       OBJ       24.48
    x_394       flow_46     1.0
    x_394       flow_26     -1.0
    x_394       link_394    1.0
    x_395       OBJ       75.17
    x_395       flow_1      1.0
    x_395       flow_4      -1.0
    x_395       link_395    1.0
    x_396       OBJ       36.5
    x_396       flow_10     1.0
    x_396       flow_26     -1.0
    x_396       link_396    1.0
    x_397       OBJ       61.04
    x_397       flow_42     1.0
    x_397       flow_23     -1.0
    x_397       link_397    1.0
    x_398       OBJ       0.81
    x_398       flow_47     1.0
    x_398       flow_38     -1.0
    x_398       link_398    1.0
    x_399       OBJ       53.67
    x_399       flow_9      1.0
    x_399       flow_44     -1.0
    x_399       link_399    1.0
    x_400       OBJ       42.84
    x_400       flow_38     1.0
    x_400       flow_19     -1.0
    x_400       link_400    1.0
    x_401       OBJ       0.96
    x_401       flow_34     1.0
    x_401       flow_39     -1.0
    x_401       link_401    1.0
    x_402       OBJ       59.55
    x_402       flow_6      1.0
    x_402       flow_43     -1.0
    x_402       link_402    1.0
    x_403       OBJ       51.87
    x_403       flow_15     1.0
    x_403       flow_5      -1.0
    x_403       link_403    1.0
    x_404       OBJ       32.38
    x_404       flow_50     1.0
    x_404       flow_25     -1.0
    x_404       link_404    1.0
    x_405       OBJ       69.18
    x_405       flow_0      1.0
    x_405       flow_49     -1.0
    x_405       link_405    1.0
    x_406       OBJ       1.62
    x_406       flow_48     1.0
    x_406       flow_10     -1.0
    x_406       link_406    1.0
    x_407       OBJ       76.85
    x_407       flow_44     1.0
    x_407       flow_32     -1.0
    x_407       link_407    1.0
    x_408       OBJ       63.08
    x_408       flow_24     1.0
    x_408       flow_6      -1.0
    x_408       link_408    1.0
    x_409       OBJ       47.74
    x_409       flow_52     1.0
    x_409       flow_35     -1.0
    x_409       link_409    1.0
    x_410       OBJ       0.85
    x_410       flow_45     1.0
    x_410       flow_21     -1.0
    x_410       link_410    1.0
    x_411       OBJ       31.81
    x_411       flow_24     1.0
    x_411       flow_15     -1.0
    x_411       link_411    1.0
    x_412       OBJ       39.51
    x_412       flow_47     1.0
    x_412       flow_1      -1.0
    x_412       link_412    1.0
    x_413       OBJ       2.19
    x_413       flow_47     1.0
    x_413       flow_36     -1.0
    x_413       link_413    1.0
    x_414       OBJ       70.15
    x_414       flow_5      1.0
    x_414       flow_28     -1.0
    x_414       link_414    1.0
    x_415       OBJ       2.74
    x_415       flow_21     1.0
    x_415       flow_41     -1.0
    x_415       link_415    1.0
    x_416       OBJ       1.81
    x_416       flow_45     1.0
    x_416       flow_22     -1.0
    x_416       link_416    1.0
    x_417       OBJ       35.74
    x_417       flow_32     1.0
    x_417       flow_20     -1.0
    x_417       link_417    1.0
    x_418       OBJ       62.95
    x_418       flow_53     1.0
    x_418       flow_46     -1.0
    x_418       link_418    1.0
    x_419       OBJ       37.06
    x_419       flow_5      1.0
    x_419       flow_22     -1.0
    x_419       link_419    1.0
    x_420       OBJ       65.85
    x_420       flow_0      1.0
    x_420       flow_34     -1.0
    x_420       link_420    1.0
    x_421       OBJ       1.98
    x_421       flow_29     1.0
    x_421       flow_49     -1.0
    x_421       link_421    1.0
    x_422       OBJ       29.0
    x_422       flow_17     1.0
    x_422       flow_7      -1.0
    x_422       link_422    1.0
    x_423       OBJ       37.98
    x_423       flow_42     1.0
    x_423       flow_26     -1.0
    x_423       link_423    1.0
    x_424       OBJ       2.88
    x_424       flow_44     1.0
    x_424       flow_14     -1.0
    x_424       link_424    1.0
    x_425       OBJ       70.71
    x_425       flow_51     1.0
    x_425       flow_8      -1.0
    x_425       link_425    1.0
    x_426       OBJ       1.8
    x_426       flow_15     1.0
    x_426       flow_11     -1.0
    x_426       link_426    1.0
    x_427       OBJ       1.18
    x_427       flow_25     1.0
    x_427       flow_44     -1.0
    x_427       link_427    1.0
    x_428       OBJ       1.81
    x_428       flow_9      1.0
    x_428       flow_54     -1.0
    x_428       link_428    1.0
    x_429       OBJ       1.53
    x_429       flow_51     1.0
    x_429       flow_10     -1.0
    x_429       link_429    1.0
    x_430       OBJ       1.46
    x_430       flow_41     1.0
    x_430       flow_30     -1.0
    x_430       link_430    1.0
    x_431       OBJ       51.39
    x_431       flow_10     1.0
    x_431       flow_49     -1.0
    x_431       link_431    1.0
    x_432       OBJ       57.84
    x_432       flow_35     1.0
    x_432       flow_17     -1.0
    x_432       link_432    1.0
    x_433       OBJ       20.24
    x_433       flow_10     1.0
    x_433       flow_43     -1.0
    x_433       link_433    1.0
    x_434       OBJ       54.61
    x_434       flow_47     1.0
    x_434       flow_31     -1.0
    x_434       link_434    1.0
    x_435       OBJ       26.86
    x_435       flow_14     1.0
    x_435       flow_29     -1.0
    x_435       link_435    1.0
    x_436       OBJ       0.91
    x_436       flow_46     1.0
    x_436       flow_17     -1.0
    x_436       link_436    1.0
    x_437       OBJ       1.68
    x_437       flow_35     1.0
    x_437       flow_0      -1.0
    x_437       link_437    1.0
    x_438       OBJ       1.71
    x_438       flow_0      1.0
    x_438       flow_16     -1.0
    x_438       link_438    1.0
    x_439       OBJ       34.37
    x_439       flow_44     1.0
    x_439       flow_20     -1.0
    x_439       link_439    1.0
    x_440       OBJ       69.85
    x_440       flow_45     1.0
    x_440       flow_18     -1.0
    x_440       link_440    1.0
    x_441       OBJ       1.82
    x_441       flow_34     1.0
    x_441       flow_18     -1.0
    x_441       link_441    1.0
    x_442       OBJ       20.85
    x_442       flow_44     1.0
    x_442       flow_25     -1.0
    x_442       link_442    1.0
    x_443       OBJ       37.93
    x_443       flow_50     1.0
    x_443       flow_1      -1.0
    x_443       link_443    1.0
    x_444       OBJ       2.13
    x_444       flow_42     1.0
    x_444       flow_44     -1.0
    x_444       link_444    1.0
    x_445       OBJ       2.44
    x_445       flow_14     1.0
    x_445       flow_54     -1.0
    x_445       link_445    1.0
    x_446       OBJ       49.4
    x_446       flow_2      1.0
    x_446       flow_1      -1.0
    x_446       link_446    1.0
    x_447       OBJ       22.87
    x_447       flow_5      1.0
    x_447       flow_12     -1.0
    x_447       link_447    1.0
    x_448       OBJ       1.15
    x_448       flow_23     1.0
    x_448       flow_10     -1.0
    x_448       link_448    1.0
    x_449       OBJ       20.22
    x_449       flow_18     1.0
    x_449       flow_3      -1.0
    x_449       link_449    1.0
    x_450       OBJ       1.19
    x_450       flow_45     1.0
    x_450       flow_46     -1.0
    x_450       link_450    1.0
    x_451       OBJ       40.53
    x_451       flow_24     1.0
    x_451       flow_36     -1.0
    x_451       link_451    1.0
    x_452       OBJ       2.75
    x_452       flow_28     1.0
    x_452       flow_17     -1.0
    x_452       link_452    1.0
    x_453       OBJ       28.99
    x_453       flow_50     1.0
    x_453       flow_18     -1.0
    x_453       link_453    1.0
    x_454       OBJ       2.7
    x_454       flow_51     1.0
    x_454       flow_21     -1.0
    x_454       link_454    1.0
    x_455       OBJ       2.78
    x_455       flow_35     1.0
    x_455       flow_34     -1.0
    x_455       link_455    1.0
    x_456       OBJ       26.34
    x_456       flow_17     1.0
    x_456       flow_19     -1.0
    x_456       link_456    1.0
    x_457       OBJ       1.67
    x_457       flow_34     1.0
    x_457       flow_26     -1.0
    x_457       link_457    1.0
    x_458       OBJ       62.98
    x_458       flow_31     1.0
    x_458       flow_2      -1.0
    x_458       link_458    1.0
    x_459       OBJ       53.89
    x_459       flow_29     1.0
    x_459       flow_31     -1.0
    x_459       link_459    1.0
    x_460       OBJ       2.7
    x_460       flow_16     1.0
    x_460       flow_22     -1.0
    x_460       link_460    1.0
    x_461       OBJ       2.7
    x_461       flow_40     1.0
    x_461       flow_50     -1.0
    x_461       link_461    1.0
    x_462       OBJ       56.11
    x_462       flow_3      1.0
    x_462       flow_33     -1.0
    x_462       link_462    1.0
    x_463       OBJ       53.5
    x_463       flow_12     1.0
    x_463       flow_36     -1.0
    x_463       link_463    1.0
    x_464       OBJ       2.09
    x_464       flow_46     1.0
    x_464       flow_19     -1.0
    x_464       link_464    1.0
    x_465       OBJ       0.58
    x_465       flow_23     1.0
    x_465       flow_42     -1.0
    x_465       link_465    1.0
    x_466       OBJ       52.92
    x_466       flow_42     1.0
    x_466       flow_46     -1.0
    x_466       link_466    1.0
    x_467       OBJ       20.08
    x_467       flow_41     1.0
    x_467       flow_9      -1.0
    x_467       link_467    1.0
    x_468       OBJ       33.68
    x_468       flow_32     1.0
    x_468       flow_45     -1.0
    x_468       link_468    1.0
    x_469       OBJ       40.63
    x_469       flow_4      1.0
    x_469       flow_33     -1.0
    x_469       link_469    1.0
    x_470       OBJ       2.52
    x_470       flow_0      1.0
    x_470       flow_38     -1.0
    x_470       link_470    1.0
    x_471       OBJ       68.57
    x_471       flow_10     1.0
    x_471       flow_9      -1.0
    x_471       link_471    1.0
    x_472       OBJ       23.09
    x_472       flow_10     1.0
    x_472       flow_52     -1.0
    x_472       link_472    1.0
    x_473       OBJ       0.79
    x_473       flow_37     1.0
    x_473       flow_21     -1.0
    x_473       link_473    1.0
    x_474       OBJ       39.67
    x_474       flow_4      1.0
    x_474       flow_39     -1.0
    x_474       link_474    1.0
    x_475       OBJ       68.75
    x_475       flow_11     1.0
    x_475       flow_24     -1.0
    x_475       link_475    1.0
    x_476       OBJ       50.49
    x_476       flow_5      1.0
    x_476       flow_39     -1.0
    x_476       link_476    1.0
    x_477       OBJ       0.65
    x_477       flow_2      1.0
    x_477       flow_46     -1.0
    x_477       link_477    1.0
    x_478       OBJ       61.07
    x_478       flow_40     1.0
    x_478       flow_4      -1.0
    x_478       link_478    1.0
    x_479       OBJ       2.89
    x_479       flow_1      1.0
    x_479       flow_33     -1.0
    x_479       link_479    1.0
    x_480       OBJ       1.62
    x_480       flow_5      1.0
    x_480       flow_37     -1.0
    x_480       link_480    1.0
    x_481       OBJ       2.59
    x_481       flow_11     1.0
    x_481       flow_27     -1.0
    x_481       link_481    1.0
    x_482       OBJ       1.48
    x_482       flow_18     1.0
    x_482       flow_37     -1.0
    x_482       link_482    1.0
    x_483       OBJ       61.68
    x_483       flow_26     1.0
    x_483       flow_14     -1.0
    x_483       link_483    1.0
    x_484       OBJ       28.96
    x_484       flow_12     1.0
    x_484       flow_30     -1.0
    x_484       link_484    1.0
    x_485       OBJ       0.54
    x_485       flow_29     1.0
    x_485       flow_0      -1.0
    x_485       link_485    1.0
    x_486       OBJ       0.61
    x_486       flow_39     1.0
    x_486       flow_43     -1.0
    x_486       link_486    1.0
    x_487       OBJ       1.79
    x_487       flow_30     1.0
    x_487       flow_25     -1.0
    x_487       link_487    1.0
    x_488       OBJ       2.01
    x_488       flow_52     1.0
    x_488       flow_53     -1.0
    x_488       link_488    1.0
    x_489       OBJ       35.19
    x_489       flow_41     1.0
    x_489       flow_17     -1.0
    x_489       link_489    1.0
    x_490       OBJ       73.6
    x_490       flow_20     1.0
    x_490       flow_46     -1.0
    x_490       link_490    1.0
    x_491       OBJ       58.04
    x_491       flow_21     1.0
    x_491       flow_31     -1.0
    x_491       link_491    1.0
    x_492       OBJ       20.29
    x_492       flow_22     1.0
    x_492       flow_23     -1.0
    x_492       link_492    1.0
    x_493       OBJ       60.27
    x_493       flow_48     1.0
    x_493       flow_38     -1.0
    x_493       link_493    1.0
    x_494       OBJ       44.75
    x_494       flow_26     1.0
    x_494       flow_34     -1.0
    x_494       link_494    1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       84.64
    y_0         link_0      -4.0
    y_1         OBJ       98.32
    y_1         link_1      -5.0
    y_2         OBJ       127.75
    y_2         link_2      -2.0
    y_3         OBJ       2.91
    y_3         link_3      -4.0
    y_4         OBJ       4.85
    y_4         link_4      -8.0
    y_5         OBJ       3.9
    y_5         link_5      -7.0
    y_6         OBJ       191.99
    y_6         link_6      -6.0
    y_7         OBJ       1.95
    y_7         link_7      -6.0
    y_8         OBJ       1.01
    y_8         link_8      -7.0
    y_9         OBJ       131.06
    y_9         link_9      -5.0
    y_10        OBJ       1.92
    y_10        link_10     -8.0
    y_11        OBJ       172.55
    y_11        link_11     -7.0
    y_12        OBJ       4.04
    y_12        link_12     -7.0
    y_13        OBJ       149.29
    y_13        link_13     -3.0
    y_14        OBJ       67.84
    y_14        link_14     -6.0
    y_15        OBJ       1.82
    y_15        link_15     -7.0
    y_16        OBJ       1.63
    y_16        link_16     -2.0
    y_17        OBJ       198.2
    y_17        link_17     -5.0
    y_18        OBJ       1.18
    y_18        link_18     -4.0
    y_19        OBJ       2.22
    y_19        link_19     -4.0
    y_20        OBJ       97.81
    y_20        link_20     -2.0
    y_21        OBJ       3.98
    y_21        link_21     -5.0
    y_22        OBJ       4.39
    y_22        link_22     -2.0
    y_23        OBJ       158.38
    y_23        link_23     -7.0
    y_24        OBJ       112.88
    y_24        link_24     -4.0
    y_25        OBJ       2.34
    y_25        link_25     -8.0
    y_26        OBJ       126.44
    y_26        link_26     -8.0
    y_27        OBJ       3.69
    y_27        link_27     -4.0
    y_28        OBJ       147.17
    y_28        link_28     -7.0
    y_29        OBJ       147.84
    y_29        link_29     -7.0
    y_30        OBJ       64.77
    y_30        link_30     -3.0
    y_31        OBJ       4.16
    y_31        link_31     -2.0
    y_32        OBJ       2.0
    y_32        link_32     -2.0
    y_33        OBJ       2.06
    y_33        link_33     -6.0
    y_34        OBJ       142.26
    y_34        link_34     -8.0
    y_35        OBJ       76.57
    y_35        link_35     -7.0
    y_36        OBJ       2.52
    y_36        link_36     -5.0
    y_37        OBJ       165.95
    y_37        link_37     -3.0
    y_38        OBJ       185.02
    y_38        link_38     -2.0
    y_39        OBJ       1.56
    y_39        link_39     -5.0
    y_40        OBJ       2.67
    y_40        link_40     -3.0
    y_41        OBJ       92.57
    y_41        link_41     -6.0
    y_42        OBJ       3.4
    y_42        link_42     -5.0
    y_43        OBJ       3.85
    y_43        link_43     -2.0
    y_44        OBJ       4.88
    y_44        link_44     -2.0
    y_45        OBJ       94.11
    y_45        link_45     -2.0
    y_46        OBJ       63.26
    y_46        link_46     -7.0
    y_47        OBJ       186.19
    y_47        link_47     -3.0
    y_48        OBJ       171.28
    y_48        link_48     -6.0
    y_49        OBJ       189.86
    y_49        link_49     -2.0
    y_50        OBJ       66.73
    y_50        link_50     -7.0
    y_51        OBJ       197.54
    y_51        link_51     -2.0
    y_52        OBJ       140.86
    y_52        link_52     -2.0
    y_53        OBJ       2.18
    y_53        link_53     -2.0
    y_54        OBJ       3.04
    y_54        link_54     -5.0
    y_55        OBJ       1.08
    y_55        link_55     -8.0
    y_56        OBJ       76.36
    y_56        link_56     -7.0
    y_57        OBJ       190.19
    y_57        link_57     -5.0
    y_58        OBJ       4.96
    y_58        link_58     -8.0
    y_59        OBJ       155.36
    y_59        link_59     -6.0
    y_60        OBJ       90.28
    y_60        link_60     -7.0
    y_61        OBJ       2.59
    y_61        link_61     -3.0
    y_62        OBJ       104.04
    y_62        link_62     -3.0
    y_63        OBJ       153.56
    y_63        link_63     -2.0
    y_64        OBJ       2.57
    y_64        link_64     -8.0
    y_65        OBJ       80.56
    y_65        link_65     -5.0
    y_66        OBJ       134.44
    y_66        link_66     -7.0
    y_67        OBJ       95.48
    y_67        link_67     -6.0
    y_68        OBJ       3.49
    y_68        link_68     -5.0
    y_69        OBJ       2.47
    y_69        link_69     -8.0
    y_70        OBJ       2.56
    y_70        link_70     -2.0
    y_71        OBJ       111.39
    y_71        link_71     -4.0
    y_72        OBJ       3.37
    y_72        link_72     -5.0
    y_73        OBJ       115.7
    y_73        link_73     -3.0
    y_74        OBJ       1.17
    y_74        link_74     -3.0
    y_75        OBJ       71.21
    y_75        link_75     -3.0
    y_76        OBJ       3.53
    y_76        link_76     -7.0
    y_77        OBJ       3.15
    y_77        link_77     -6.0
    y_78        OBJ       1.88
    y_78        link_78     -6.0
    y_79        OBJ       92.43
    y_79        link_79     -5.0
    y_80        OBJ       4.33
    y_80        link_80     -6.0
    y_81        OBJ       153.88
    y_81        link_81     -5.0
    y_82        OBJ       189.64
    y_82        link_82     -5.0
    y_83        OBJ       4.54
    y_83        link_83     -4.0
    y_84        OBJ       153.01
    y_84        link_84     -6.0
    y_85        OBJ       4.34
    y_85        link_85     -2.0
    y_86        OBJ       155.94
    y_86        link_86     -7.0
    y_87        OBJ       4.11
    y_87        link_87     -3.0
    y_88        OBJ       4.39
    y_88        link_88     -8.0
    y_89        OBJ       150.75
    y_89        link_89     -5.0
    y_90        OBJ       177.11
    y_90        link_90     -6.0
    y_91        OBJ       2.0
    y_91        link_91     -5.0
    y_92        OBJ       2.19
    y_92        link_92     -6.0
    y_93        OBJ       131.64
    y_93        link_93     -4.0
    y_94        OBJ       4.99
    y_94        link_94     -3.0
    y_95        OBJ       116.24
    y_95        link_95     -2.0
    y_96        OBJ       100.01
    y_96        link_96     -7.0
    y_97        OBJ       117.13
    y_97        link_97     -8.0
    y_98        OBJ       1.31
    y_98        link_98     -4.0
    y_99        OBJ       155.91
    y_99        link_99     -8.0
    y_100       OBJ       3.73
    y_100       link_100    -8.0
    y_101       OBJ       4.37
    y_101       link_101    -4.0
    y_102       OBJ       71.46
    y_102       link_102    -3.0
    y_103       OBJ       3.22
    y_103       link_103    -6.0
    y_104       OBJ       135.26
    y_104       link_104    -5.0
    y_105       OBJ       124.61
    y_105       link_105    -5.0
    y_106       OBJ       4.77
    y_106       link_106    -3.0
    y_107       OBJ       3.71
    y_107       link_107    -7.0
    y_108       OBJ       155.48
    y_108       link_108    -4.0
    y_109       OBJ       126.97
    y_109       link_109    -7.0
    y_110       OBJ       1.18
    y_110       link_110    -6.0
    y_111       OBJ       1.99
    y_111       link_111    -5.0
    y_112       OBJ       133.56
    y_112       link_112    -5.0
    y_113       OBJ       54.28
    y_113       link_113    -7.0
    y_114       OBJ       188.57
    y_114       link_114    -2.0
    y_115       OBJ       4.38
    y_115       link_115    -8.0
    y_116       OBJ       194.57
    y_116       link_116    -6.0
    y_117       OBJ       1.24
    y_117       link_117    -2.0
    y_118       OBJ       2.08
    y_118       link_118    -5.0
    y_119       OBJ       101.58
    y_119       link_119    -8.0
    y_120       OBJ       2.26
    y_120       link_120    -8.0
    y_121       OBJ       75.68
    y_121       link_121    -5.0
    y_122       OBJ       57.86
    y_122       link_122    -8.0
    y_123       OBJ       188.69
    y_123       link_123    -4.0
    y_124       OBJ       4.35
    y_124       link_124    -6.0
    y_125       OBJ       160.62
    y_125       link_125    -6.0
    y_126       OBJ       1.61
    y_126       link_126    -7.0
    y_127       OBJ       177.16
    y_127       link_127    -7.0
    y_128       OBJ       3.12
    y_128       link_128    -8.0
    y_129       OBJ       1.5
    y_129       link_129    -8.0
    y_130       OBJ       99.09
    y_130       link_130    -5.0
    y_131       OBJ       1.44
    y_131       link_131    -8.0
    y_132       OBJ       2.68
    y_132       link_132    -2.0
    y_133       OBJ       4.66
    y_133       link_133    -2.0
    y_134       OBJ       1.05
    y_134       link_134    -6.0
    y_135       OBJ       3.41
    y_135       link_135    -6.0
    y_136       OBJ       175.94
    y_136       link_136    -3.0
    y_137       OBJ       136.9
    y_137       link_137    -6.0
    y_138       OBJ       114.07
    y_138       link_138    -2.0
    y_139       OBJ       67.58
    y_139       link_139    -4.0
    y_140       OBJ       3.6
    y_140       link_140    -6.0
    y_141       OBJ       54.08
    y_141       link_141    -2.0
    y_142       OBJ       2.03
    y_142       link_142    -7.0
    y_143       OBJ       3.91
    y_143       link_143    -3.0
    y_144       OBJ       182.55
    y_144       link_144    -8.0
    y_145       OBJ       62.93
    y_145       link_145    -3.0
    y_146       OBJ       2.36
    y_146       link_146    -8.0
    y_147       OBJ       4.82
    y_147       link_147    -4.0
    y_148       OBJ       159.82
    y_148       link_148    -2.0
    y_149       OBJ       154.27
    y_149       link_149    -4.0
    y_150       OBJ       1.49
    y_150       link_150    -6.0
    y_151       OBJ       61.61
    y_151       link_151    -5.0
    y_152       OBJ       1.99
    y_152       link_152    -8.0
    y_153       OBJ       3.33
    y_153       link_153    -5.0
    y_154       OBJ       70.65
    y_154       link_154    -2.0
    y_155       OBJ       171.85
    y_155       link_155    -2.0
    y_156       OBJ       3.21
    y_156       link_156    -5.0
    y_157       OBJ       172.77
    y_157       link_157    -7.0
    y_158       OBJ       3.75
    y_158       link_158    -4.0
    y_159       OBJ       4.42
    y_159       link_159    -5.0
    y_160       OBJ       55.51
    y_160       link_160    -5.0
    y_161       OBJ       154.68
    y_161       link_161    -7.0
    y_162       OBJ       159.1
    y_162       link_162    -7.0
    y_163       OBJ       129.46
    y_163       link_163    -5.0
    y_164       OBJ       120.94
    y_164       link_164    -5.0
    y_165       OBJ       153.32
    y_165       link_165    -5.0
    y_166       OBJ       3.48
    y_166       link_166    -4.0
    y_167       OBJ       170.61
    y_167       link_167    -7.0
    y_168       OBJ       80.75
    y_168       link_168    -5.0
    y_169       OBJ       4.93
    y_169       link_169    -8.0
    y_170       OBJ       81.23
    y_170       link_170    -2.0
    y_171       OBJ       164.73
    y_171       link_171    -3.0
    y_172       OBJ       1.69
    y_172       link_172    -8.0
    y_173       OBJ       156.26
    y_173       link_173    -5.0
    y_174       OBJ       191.38
    y_174       link_174    -4.0
    y_175       OBJ       109.61
    y_175       link_175    -3.0
    y_176       OBJ       1.32
    y_176       link_176    -3.0
    y_177       OBJ       130.45
    y_177       link_177    -6.0
    y_178       OBJ       2.55
    y_178       link_178    -8.0
    y_179       OBJ       92.96
    y_179       link_179    -8.0
    y_180       OBJ       147.58
    y_180       link_180    -4.0
    y_181       OBJ       108.55
    y_181       link_181    -3.0
    y_182       OBJ       3.17
    y_182       link_182    -3.0
    y_183       OBJ       1.01
    y_183       link_183    -7.0
    y_184       OBJ       2.8
    y_184       link_184    -8.0
    y_185       OBJ       165.05
    y_185       link_185    -3.0
    y_186       OBJ       123.78
    y_186       link_186    -7.0
    y_187       OBJ       189.98
    y_187       link_187    -4.0
    y_188       OBJ       2.28
    y_188       link_188    -4.0
    y_189       OBJ       168.04
    y_189       link_189    -2.0
    y_190       OBJ       2.81
    y_190       link_190    -2.0
    y_191       OBJ       3.17
    y_191       link_191    -8.0
    y_192       OBJ       145.78
    y_192       link_192    -6.0
    y_193       OBJ       2.26
    y_193       link_193    -4.0
    y_194       OBJ       84.95
    y_194       link_194    -4.0
    y_195       OBJ       3.43
    y_195       link_195    -8.0
    y_196       OBJ       155.85
    y_196       link_196    -8.0
    y_197       OBJ       2.48
    y_197       link_197    -6.0
    y_198       OBJ       180.92
    y_198       link_198    -5.0
    y_199       OBJ       1.86
    y_199       link_199    -8.0
    y_200       OBJ       3.75
    y_200       link_200    -4.0
    y_201       OBJ       2.14
    y_201       link_201    -3.0
    y_202       OBJ       1.07
    y_202       link_202    -8.0
    y_203       OBJ       150.72
    y_203       link_203    -7.0
    y_204       OBJ       4.55
    y_204       link_204    -4.0
    y_205       OBJ       3.06
    y_205       link_205    -3.0
    y_206       OBJ       1.9
    y_206       link_206    -2.0
    y_207       OBJ       1.58
    y_207       link_207    -2.0
    y_208       OBJ       4.24
    y_208       link_208    -4.0
    y_209       OBJ       2.86
    y_209       link_209    -6.0
    y_210       OBJ       52.86
    y_210       link_210    -8.0
    y_211       OBJ       4.73
    y_211       link_211    -4.0
    y_212       OBJ       167.94
    y_212       link_212    -2.0
    y_213       OBJ       191.65
    y_213       link_213    -6.0
    y_214       OBJ       2.14
    y_214       link_214    -7.0
    y_215       OBJ       4.28
    y_215       link_215    -4.0
    y_216       OBJ       134.76
    y_216       link_216    -8.0
    y_217       OBJ       171.17
    y_217       link_217    -7.0
    y_218       OBJ       4.78
    y_218       link_218    -2.0
    y_219       OBJ       3.07
    y_219       link_219    -7.0
    y_220       OBJ       3.2
    y_220       link_220    -5.0
    y_221       OBJ       3.93
    y_221       link_221    -6.0
    y_222       OBJ       81.9
    y_222       link_222    -3.0
    y_223       OBJ       3.66
    y_223       link_223    -6.0
    y_224       OBJ       160.68
    y_224       link_224    -2.0
    y_225       OBJ       163.9
    y_225       link_225    -2.0
    y_226       OBJ       162.31
    y_226       link_226    -7.0
    y_227       OBJ       2.83
    y_227       link_227    -8.0
    y_228       OBJ       3.31
    y_228       link_228    -2.0
    y_229       OBJ       158.82
    y_229       link_229    -8.0
    y_230       OBJ       188.52
    y_230       link_230    -7.0
    y_231       OBJ       4.95
    y_231       link_231    -8.0
    y_232       OBJ       3.16
    y_232       link_232    -3.0
    y_233       OBJ       145.35
    y_233       link_233    -5.0
    y_234       OBJ       2.76
    y_234       link_234    -4.0
    y_235       OBJ       162.39
    y_235       link_235    -3.0
    y_236       OBJ       1.34
    y_236       link_236    -7.0
    y_237       OBJ       66.05
    y_237       link_237    -2.0
    y_238       OBJ       1.63
    y_238       link_238    -4.0
    y_239       OBJ       4.14
    y_239       link_239    -4.0
    y_240       OBJ       3.96
    y_240       link_240    -6.0
    y_241       OBJ       2.06
    y_241       link_241    -4.0
    y_242       OBJ       133.88
    y_242       link_242    -8.0
    y_243       OBJ       91.36
    y_243       link_243    -7.0
    y_244       OBJ       147.22
    y_244       link_244    -4.0
    y_245       OBJ       134.22
    y_245       link_245    -4.0
    y_246       OBJ       3.59
    y_246       link_246    -7.0
    y_247       OBJ       142.8
    y_247       link_247    -8.0
    y_248       OBJ       126.35
    y_248       link_248    -5.0
    y_249       OBJ       92.9
    y_249       link_249    -8.0
    y_250       OBJ       1.31
    y_250       link_250    -2.0
    y_251       OBJ       4.81
    y_251       link_251    -4.0
    y_252       OBJ       3.62
    y_252       link_252    -7.0
    y_253       OBJ       4.81
    y_253       link_253    -7.0
    y_254       OBJ       181.25
    y_254       link_254    -7.0
    y_255       OBJ       101.2
    y_255       link_255    -3.0
    y_256       OBJ       3.96
    y_256       link_256    -7.0
    y_257       OBJ       52.15
    y_257       link_257    -5.0
    y_258       OBJ       1.09
    y_258       link_258    -5.0
    y_259       OBJ       1.41
    y_259       link_259    -3.0
    y_260       OBJ       131.43
    y_260       link_260    -7.0
    y_261       OBJ       2.08
    y_261       link_261    -7.0
    y_262       OBJ       95.02
    y_262       link_262    -5.0
    y_263       OBJ       96.25
    y_263       link_263    -6.0
    y_264       OBJ       163.43
    y_264       link_264    -7.0
    y_265       OBJ       2.53
    y_265       link_265    -3.0
    y_266       OBJ       178.78
    y_266       link_266    -3.0
    y_267       OBJ       102.59
    y_267       link_267    -4.0
    y_268       OBJ       3.5
    y_268       link_268    -3.0
    y_269       OBJ       130.62
    y_269       link_269    -4.0
    y_270       OBJ       3.69
    y_270       link_270    -6.0
    y_271       OBJ       102.73
    y_271       link_271    -6.0
    y_272       OBJ       4.07
    y_272       link_272    -6.0
    y_273       OBJ       4.73
    y_273       link_273    -4.0
    y_274       OBJ       1.57
    y_274       link_274    -6.0
    y_275       OBJ       86.2
    y_275       link_275    -5.0
    y_276       OBJ       2.45
    y_276       link_276    -6.0
    y_277       OBJ       182.14
    y_277       link_277    -3.0
    y_278       OBJ       127.47
    y_278       link_278    -5.0
    y_279       OBJ       3.82
    y_279       link_279    -7.0
    y_280       OBJ       137.86
    y_280       link_280    -5.0
    y_281       OBJ       92.82
    y_281       link_281    -4.0
    y_282       OBJ       2.2
    y_282       link_282    -4.0
    y_283       OBJ       95.58
    y_283       link_283    -7.0
    y_284       OBJ       4.62
    y_284       link_284    -2.0
    y_285       OBJ       2.66
    y_285       link_285    -8.0
    y_286       OBJ       177.84
    y_286       link_286    -2.0
    y_287       OBJ       3.73
    y_287       link_287    -2.0
    y_288       OBJ       3.59
    y_288       link_288    -8.0
    y_289       OBJ       128.27
    y_289       link_289    -5.0
    y_290       OBJ       57.92
    y_290       link_290    -6.0
    y_291       OBJ       198.53
    y_291       link_291    -2.0
    y_292       OBJ       3.07
    y_292       link_292    -6.0
    y_293       OBJ       1.19
    y_293       link_293    -5.0
    y_294       OBJ       3.2
    y_294       link_294    -2.0
    y_295       OBJ       4.8
    y_295       link_295    -5.0
    y_296       OBJ       4.45
    y_296       link_296    -4.0
    y_297       OBJ       77.49
    y_297       link_297    -6.0
    y_298       OBJ       3.57
    y_298       link_298    -8.0
    y_299       OBJ       2.88
    y_299       link_299    -8.0
    y_300       OBJ       74.97
    y_300       link_300    -4.0
    y_301       OBJ       139.57
    y_301       link_301    -5.0
    y_302       OBJ       125.96
    y_302       link_302    -2.0
    y_303       OBJ       1.34
    y_303       link_303    -3.0
    y_304       OBJ       85.34
    y_304       link_304    -8.0
    y_305       OBJ       68.79
    y_305       link_305    -6.0
    y_306       OBJ       108.81
    y_306       link_306    -3.0
    y_307       OBJ       1.07
    y_307       link_307    -6.0
    y_308       OBJ       3.82
    y_308       link_308    -8.0
    y_309       OBJ       3.4
    y_309       link_309    -3.0
    y_310       OBJ       2.96
    y_310       link_310    -8.0
    y_311       OBJ       2.53
    y_311       link_311    -8.0
    y_312       OBJ       2.12
    y_312       link_312    -6.0
    y_313       OBJ       186.45
    y_313       link_313    -8.0
    y_314       OBJ       1.78
    y_314       link_314    -4.0
    y_315       OBJ       2.9
    y_315       link_315    -2.0
    y_316       OBJ       4.67
    y_316       link_316    -8.0
    y_317       OBJ       2.46
    y_317       link_317    -8.0
    y_318       OBJ       117.06
    y_318       link_318    -7.0
    y_319       OBJ       79.68
    y_319       link_319    -3.0
    y_320       OBJ       1.46
    y_320       link_320    -2.0
    y_321       OBJ       3.13
    y_321       link_321    -4.0
    y_322       OBJ       153.62
    y_322       link_322    -4.0
    y_323       OBJ       195.24
    y_323       link_323    -4.0
    y_324       OBJ       1.83
    y_324       link_324    -4.0
    y_325       OBJ       1.78
    y_325       link_325    -4.0
    y_326       OBJ       62.67
    y_326       link_326    -4.0
    y_327       OBJ       157.53
    y_327       link_327    -7.0
    y_328       OBJ       4.7
    y_328       link_328    -6.0
    y_329       OBJ       57.98
    y_329       link_329    -2.0
    y_330       OBJ       147.48
    y_330       link_330    -6.0
    y_331       OBJ       56.6
    y_331       link_331    -8.0
    y_332       OBJ       141.62
    y_332       link_332    -8.0
    y_333       OBJ       1.18
    y_333       link_333    -7.0
    y_334       OBJ       2.7
    y_334       link_334    -3.0
    y_335       OBJ       3.56
    y_335       link_335    -3.0
    y_336       OBJ       138.59
    y_336       link_336    -8.0
    y_337       OBJ       1.18
    y_337       link_337    -4.0
    y_338       OBJ       1.75
    y_338       link_338    -5.0
    y_339       OBJ       160.08
    y_339       link_339    -2.0
    y_340       OBJ       55.64
    y_340       link_340    -7.0
    y_341       OBJ       4.97
    y_341       link_341    -5.0
    y_342       OBJ       199.69
    y_342       link_342    -5.0
    y_343       OBJ       174.72
    y_343       link_343    -6.0
    y_344       OBJ       86.54
    y_344       link_344    -4.0
    y_345       OBJ       4.01
    y_345       link_345    -5.0
    y_346       OBJ       3.86
    y_346       link_346    -8.0
    y_347       OBJ       90.63
    y_347       link_347    -7.0
    y_348       OBJ       2.33
    y_348       link_348    -8.0
    y_349       OBJ       3.19
    y_349       link_349    -2.0
    y_350       OBJ       1.72
    y_350       link_350    -3.0
    y_351       OBJ       1.51
    y_351       link_351    -8.0
    y_352       OBJ       176.37
    y_352       link_352    -3.0
    y_353       OBJ       2.95
    y_353       link_353    -2.0
    y_354       OBJ       92.22
    y_354       link_354    -4.0
    y_355       OBJ       1.41
    y_355       link_355    -8.0
    y_356       OBJ       53.99
    y_356       link_356    -3.0
    y_357       OBJ       2.99
    y_357       link_357    -2.0
    y_358       OBJ       4.05
    y_358       link_358    -8.0
    y_359       OBJ       1.48
    y_359       link_359    -8.0
    y_360       OBJ       4.76
    y_360       link_360    -3.0
    y_361       OBJ       91.68
    y_361       link_361    -3.0
    y_362       OBJ       88.27
    y_362       link_362    -8.0
    y_363       OBJ       2.03
    y_363       link_363    -4.0
    y_364       OBJ       1.31
    y_364       link_364    -8.0
    y_365       OBJ       2.85
    y_365       link_365    -4.0
    y_366       OBJ       84.48
    y_366       link_366    -8.0
    y_367       OBJ       1.42
    y_367       link_367    -6.0
    y_368       OBJ       4.8
    y_368       link_368    -6.0
    y_369       OBJ       137.36
    y_369       link_369    -6.0
    y_370       OBJ       4.82
    y_370       link_370    -5.0
    y_371       OBJ       147.89
    y_371       link_371    -4.0
    y_372       OBJ       2.66
    y_372       link_372    -6.0
    y_373       OBJ       1.86
    y_373       link_373    -4.0
    y_374       OBJ       3.44
    y_374       link_374    -5.0
    y_375       OBJ       2.05
    y_375       link_375    -8.0
    y_376       OBJ       1.68
    y_376       link_376    -7.0
    y_377       OBJ       1.16
    y_377       link_377    -2.0
    y_378       OBJ       1.38
    y_378       link_378    -4.0
    y_379       OBJ       1.83
    y_379       link_379    -8.0
    y_380       OBJ       2.51
    y_380       link_380    -3.0
    y_381       OBJ       1.66
    y_381       link_381    -3.0
    y_382       OBJ       189.44
    y_382       link_382    -6.0
    y_383       OBJ       103.16
    y_383       link_383    -8.0
    y_384       OBJ       178.81
    y_384       link_384    -2.0
    y_385       OBJ       122.15
    y_385       link_385    -5.0
    y_386       OBJ       132.03
    y_386       link_386    -3.0
    y_387       OBJ       4.93
    y_387       link_387    -2.0
    y_388       OBJ       190.38
    y_388       link_388    -8.0
    y_389       OBJ       174.1
    y_389       link_389    -3.0
    y_390       OBJ       152.77
    y_390       link_390    -7.0
    y_391       OBJ       2.93
    y_391       link_391    -8.0
    y_392       OBJ       1.5
    y_392       link_392    -3.0
    y_393       OBJ       159.62
    y_393       link_393    -2.0
    y_394       OBJ       1.13
    y_394       link_394    -8.0
    y_395       OBJ       2.57
    y_395       link_395    -4.0
    y_396       OBJ       2.72
    y_396       link_396    -7.0
    y_397       OBJ       2.03
    y_397       link_397    -5.0
    y_398       OBJ       90.49
    y_398       link_398    -3.0
    y_399       OBJ       4.54
    y_399       link_399    -4.0
    y_400       OBJ       1.79
    y_400       link_400    -4.0
    y_401       OBJ       175.61
    y_401       link_401    -5.0
    y_402       OBJ       4.56
    y_402       link_402    -5.0
    y_403       OBJ       4.55
    y_403       link_403    -8.0
    y_404       OBJ       2.74
    y_404       link_404    -2.0
    y_405       OBJ       4.62
    y_405       link_405    -4.0
    y_406       OBJ       177.06
    y_406       link_406    -7.0
    y_407       OBJ       4.81
    y_407       link_407    -7.0
    y_408       OBJ       4.19
    y_408       link_408    -6.0
    y_409       OBJ       2.78
    y_409       link_409    -7.0
    y_410       OBJ       141.4
    y_410       link_410    -3.0
    y_411       OBJ       1.8
    y_411       link_411    -3.0
    y_412       OBJ       1.26
    y_412       link_412    -8.0
    y_413       OBJ       80.49
    y_413       link_413    -3.0
    y_414       OBJ       4.23
    y_414       link_414    -4.0
    y_415       OBJ       99.7
    y_415       link_415    -8.0
    y_416       OBJ       68.74
    y_416       link_416    -6.0
    y_417       OBJ       4.94
    y_417       link_417    -4.0
    y_418       OBJ       3.48
    y_418       link_418    -7.0
    y_419       OBJ       1.61
    y_419       link_419    -4.0
    y_420       OBJ       1.18
    y_420       link_420    -8.0
    y_421       OBJ       167.96
    y_421       link_421    -7.0
    y_422       OBJ       2.21
    y_422       link_422    -4.0
    y_423       OBJ       1.99
    y_423       link_423    -7.0
    y_424       OBJ       52.55
    y_424       link_424    -7.0
    y_425       OBJ       3.46
    y_425       link_425    -6.0
    y_426       OBJ       156.68
    y_426       link_426    -3.0
    y_427       OBJ       127.01
    y_427       link_427    -5.0
    y_428       OBJ       58.2
    y_428       link_428    -3.0
    y_429       OBJ       135.99
    y_429       link_429    -7.0
    y_430       OBJ       194.7
    y_430       link_430    -2.0
    y_431       OBJ       3.81
    y_431       link_431    -3.0
    y_432       OBJ       4.59
    y_432       link_432    -3.0
    y_433       OBJ       1.26
    y_433       link_433    -7.0
    y_434       OBJ       3.25
    y_434       link_434    -2.0
    y_435       OBJ       3.11
    y_435       link_435    -8.0
    y_436       OBJ       59.37
    y_436       link_436    -6.0
    y_437       OBJ       170.58
    y_437       link_437    -7.0
    y_438       OBJ       73.21
    y_438       link_438    -6.0
    y_439       OBJ       1.41
    y_439       link_439    -8.0
    y_440       OBJ       3.44
    y_440       link_440    -8.0
    y_441       OBJ       95.78
    y_441       link_441    -2.0
    y_442       OBJ       4.03
    y_442       link_442    -5.0
    y_443       OBJ       3.49
    y_443       link_443    -4.0
    y_444       OBJ       164.14
    y_444       link_444    -2.0
    y_445       OBJ       112.03
    y_445       link_445    -2.0
    y_446       OBJ       2.95
    y_446       link_446    -3.0
    y_447       OBJ       3.22
    y_447       link_447    -7.0
    y_448       OBJ       170.53
    y_448       link_448    -7.0
    y_449       OBJ       4.06
    y_449       link_449    -4.0
    y_450       OBJ       105.23
    y_450       link_450    -4.0
    y_451       OBJ       2.04
    y_451       link_451    -5.0
    y_452       OBJ       63.82
    y_452       link_452    -3.0
    y_453       OBJ       4.38
    y_453       link_453    -8.0
    y_454       OBJ       64.7
    y_454       link_454    -8.0
    y_455       OBJ       122.73
    y_455       link_455    -7.0
    y_456       OBJ       1.91
    y_456       link_456    -8.0
    y_457       OBJ       195.58
    y_457       link_457    -8.0
    y_458       OBJ       1.86
    y_458       link_458    -4.0
    y_459       OBJ       4.58
    y_459       link_459    -8.0
    y_460       OBJ       142.35
    y_460       link_460    -7.0
    y_461       OBJ       57.48
    y_461       link_461    -6.0
    y_462       OBJ       4.57
    y_462       link_462    -7.0
    y_463       OBJ       2.21
    y_463       link_463    -6.0
    y_464       OBJ       187.46
    y_464       link_464    -2.0
    y_465       OBJ       106.05
    y_465       link_465    -2.0
    y_466       OBJ       2.86
    y_466       link_466    -6.0
    y_467       OBJ       3.0
    y_467       link_467    -8.0
    y_468       OBJ       2.42
    y_468       link_468    -7.0
    y_469       OBJ       1.91
    y_469       link_469    -2.0
    y_470       OBJ       83.27
    y_470       link_470    -2.0
    y_471       OBJ       4.56
    y_471       link_471    -4.0
    y_472       OBJ       1.13
    y_472       link_472    -2.0
    y_473       OBJ       91.87
    y_473       link_473    -5.0
    y_474       OBJ       2.45
    y_474       link_474    -7.0
    y_475       OBJ       1.48
    y_475       link_475    -4.0
    y_476       OBJ       2.41
    y_476       link_476    -7.0
    y_477       OBJ       142.04
    y_477       link_477    -7.0
    y_478       OBJ       4.34
    y_478       link_478    -6.0
    y_479       OBJ       53.72
    y_479       link_479    -4.0
    y_480       OBJ       170.22
    y_480       link_480    -5.0
    y_481       OBJ       152.2
    y_481       link_481    -4.0
    y_482       OBJ       192.68
    y_482       link_482    -2.0
    y_483       OBJ       4.73
    y_483       link_483    -8.0
    y_484       OBJ       4.47
    y_484       link_484    -7.0
    y_485       OBJ       167.1
    y_485       link_485    -3.0
    y_486       OBJ       131.72
    y_486       link_486    -8.0
    y_487       OBJ       188.48
    y_487       link_487    -3.0
    y_488       OBJ       85.12
    y_488       link_488    -5.0
    y_489       OBJ       4.49
    y_489       link_489    -6.0
    y_490       OBJ       4.43
    y_490       link_490    -7.0
    y_491       OBJ       2.93
    y_491       link_491    -5.0
    y_492       OBJ       4.57
    y_492       link_492    -6.0
    y_493       OBJ       2.61
    y_493       link_493    -7.0
    y_494       OBJ       3.78
    y_494       link_494    -5.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_14     -11
    RHS       flow_25     -11
    RHS       flow_33     15
    RHS       flow_34     13
    RHS       flow_36     -11
    RHS       flow_38     -11
    RHS       flow_46     -11
    RHS       flow_51     13
    RHS       flow_54     14
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
 BV BOUND     y_84
 BV BOUND     y_85
 BV BOUND     y_86
 BV BOUND     y_87
 BV BOUND     y_88
 BV BOUND     y_89
 BV BOUND     y_90
 BV BOUND     y_91
 BV BOUND     y_92
 BV BOUND     y_93
 BV BOUND     y_94
 BV BOUND     y_95
 BV BOUND     y_96
 BV BOUND     y_97
 BV BOUND     y_98
 BV BOUND     y_99
 BV BOUND     y_100
 BV BOUND     y_101
 BV BOUND     y_102
 BV BOUND     y_103
 BV BOUND     y_104
 BV BOUND     y_105
 BV BOUND     y_106
 BV BOUND     y_107
 BV BOUND     y_108
 BV BOUND     y_109
 BV BOUND     y_110
 BV BOUND     y_111
 BV BOUND     y_112
 BV BOUND     y_113
 BV BOUND     y_114
 BV BOUND     y_115
 BV BOUND     y_116
 BV BOUND     y_117
 BV BOUND     y_118
 BV BOUND     y_119
 BV BOUND     y_120
 BV BOUND     y_121
 BV BOUND     y_122
 BV BOUND     y_123
 BV BOUND     y_124
 BV BOUND     y_125
 BV BOUND     y_126
 BV BOUND     y_127
 BV BOUND     y_128
 BV BOUND     y_129
 BV BOUND     y_130
 BV BOUND     y_131
 BV BOUND     y_132
 BV BOUND     y_133
 BV BOUND     y_134
 BV BOUND     y_135
 BV BOUND     y_136
 BV BOUND     y_137
 BV BOUND     y_138
 BV BOUND     y_139
 BV BOUND     y_140
 BV BOUND     y_141
 BV BOUND     y_142
 BV BOUND     y_143
 BV BOUND     y_144
 BV BOUND     y_145
 BV BOUND     y_146
 BV BOUND     y_147
 BV BOUND     y_148
 BV BOUND     y_149
 BV BOUND     y_150
 BV BOUND     y_151
 BV BOUND     y_152
 BV BOUND     y_153
 BV BOUND     y_154
 BV BOUND     y_155
 BV BOUND     y_156
 BV BOUND     y_157
 BV BOUND     y_158
 BV BOUND     y_159
 BV BOUND     y_160
 BV BOUND     y_161
 BV BOUND     y_162
 BV BOUND     y_163
 BV BOUND     y_164
 BV BOUND     y_165
 BV BOUND     y_166
 BV BOUND     y_167
 BV BOUND     y_168
 BV BOUND     y_169
 BV BOUND     y_170
 BV BOUND     y_171
 BV BOUND     y_172
 BV BOUND     y_173
 BV BOUND     y_174
 BV BOUND     y_175
 BV BOUND     y_176
 BV BOUND     y_177
 BV BOUND     y_178
 BV BOUND     y_179
 BV BOUND     y_180
 BV BOUND     y_181
 BV BOUND     y_182
 BV BOUND     y_183
 BV BOUND     y_184
 BV BOUND     y_185
 BV BOUND     y_186
 BV BOUND     y_187
 BV BOUND     y_188
 BV BOUND     y_189
 BV BOUND     y_190
 BV BOUND     y_191
 BV BOUND     y_192
 BV BOUND     y_193
 BV BOUND     y_194
 BV BOUND     y_195
 BV BOUND     y_196
 BV BOUND     y_197
 BV BOUND     y_198
 BV BOUND     y_199
 BV BOUND     y_200
 BV BOUND     y_201
 BV BOUND     y_202
 BV BOUND     y_203
 BV BOUND     y_204
 BV BOUND     y_205
 BV BOUND     y_206
 BV BOUND     y_207
 BV BOUND     y_208
 BV BOUND     y_209
 BV BOUND     y_210
 BV BOUND     y_211
 BV BOUND     y_212
 BV BOUND     y_213
 BV BOUND     y_214
 BV BOUND     y_215
 BV BOUND     y_216
 BV BOUND     y_217
 BV BOUND     y_218
 BV BOUND     y_219
 BV BOUND     y_220
 BV BOUND     y_221
 BV BOUND     y_222
 BV BOUND     y_223
 BV BOUND     y_224
 BV BOUND     y_225
 BV BOUND     y_226
 BV BOUND     y_227
 BV BOUND     y_228
 BV BOUND     y_229
 BV BOUND     y_230
 BV BOUND     y_231
 BV BOUND     y_232
 BV BOUND     y_233
 BV BOUND     y_234
 BV BOUND     y_235
 BV BOUND     y_236
 BV BOUND     y_237
 BV BOUND     y_238
 BV BOUND     y_239
 BV BOUND     y_240
 BV BOUND     y_241
 BV BOUND     y_242
 BV BOUND     y_243
 BV BOUND     y_244
 BV BOUND     y_245
 BV BOUND     y_246
 BV BOUND     y_247
 BV BOUND     y_248
 BV BOUND     y_249
 BV BOUND     y_250
 BV BOUND     y_251
 BV BOUND     y_252
 BV BOUND     y_253
 BV BOUND     y_254
 BV BOUND     y_255
 BV BOUND     y_256
 BV BOUND     y_257
 BV BOUND     y_258
 BV BOUND     y_259
 BV BOUND     y_260
 BV BOUND     y_261
 BV BOUND     y_262
 BV BOUND     y_263
 BV BOUND     y_264
 BV BOUND     y_265
 BV BOUND     y_266
 BV BOUND     y_267
 BV BOUND     y_268
 BV BOUND     y_269
 BV BOUND     y_270
 BV BOUND     y_271
 BV BOUND     y_272
 BV BOUND     y_273
 BV BOUND     y_274
 BV BOUND     y_275
 BV BOUND     y_276
 BV BOUND     y_277
 BV BOUND     y_278
 BV BOUND     y_279
 BV BOUND     y_280
 BV BOUND     y_281
 BV BOUND     y_282
 BV BOUND     y_283
 BV BOUND     y_284
 BV BOUND     y_285
 BV BOUND     y_286
 BV BOUND     y_287
 BV BOUND     y_288
 BV BOUND     y_289
 BV BOUND     y_290
 BV BOUND     y_291
 BV BOUND     y_292
 BV BOUND     y_293
 BV BOUND     y_294
 BV BOUND     y_295
 BV BOUND     y_296
 BV BOUND     y_297
 BV BOUND     y_298
 BV BOUND     y_299
 BV BOUND     y_300
 BV BOUND     y_301
 BV BOUND     y_302
 BV BOUND     y_303
 BV BOUND     y_304
 BV BOUND     y_305
 BV BOUND     y_306
 BV BOUND     y_307
 BV BOUND     y_308
 BV BOUND     y_309
 BV BOUND     y_310
 BV BOUND     y_311
 BV BOUND     y_312
 BV BOUND     y_313
 BV BOUND     y_314
 BV BOUND     y_315
 BV BOUND     y_316
 BV BOUND     y_317
 BV BOUND     y_318
 BV BOUND     y_319
 BV BOUND     y_320
 BV BOUND     y_321
 BV BOUND     y_322
 BV BOUND     y_323
 BV BOUND     y_324
 BV BOUND     y_325
 BV BOUND     y_326
 BV BOUND     y_327
 BV BOUND     y_328
 BV BOUND     y_329
 BV BOUND     y_330
 BV BOUND     y_331
 BV BOUND     y_332
 BV BOUND     y_333
 BV BOUND     y_334
 BV BOUND     y_335
 BV BOUND     y_336
 BV BOUND     y_337
 BV BOUND     y_338
 BV BOUND     y_339
 BV BOUND     y_340
 BV BOUND     y_341
 BV BOUND     y_342
 BV BOUND     y_343
 BV BOUND     y_344
 BV BOUND     y_345
 BV BOUND     y_346
 BV BOUND     y_347
 BV BOUND     y_348
 BV BOUND     y_349
 BV BOUND     y_350
 BV BOUND     y_351
 BV BOUND     y_352
 BV BOUND     y_353
 BV BOUND     y_354
 BV BOUND     y_355
 BV BOUND     y_356
 BV BOUND     y_357
 BV BOUND     y_358
 BV BOUND     y_359
 BV BOUND     y_360
 BV BOUND     y_361
 BV BOUND     y_362
 BV BOUND     y_363
 BV BOUND     y_364
 BV BOUND     y_365
 BV BOUND     y_366
 BV BOUND     y_367
 BV BOUND     y_368
 BV BOUND     y_369
 BV BOUND     y_370
 BV BOUND     y_371
 BV BOUND     y_372
 BV BOUND     y_373
 BV BOUND     y_374
 BV BOUND     y_375
 BV BOUND     y_376
 BV BOUND     y_377
 BV BOUND     y_378
 BV BOUND     y_379
 BV BOUND     y_380
 BV BOUND     y_381
 BV BOUND     y_382
 BV BOUND     y_383
 BV BOUND     y_384
 BV BOUND     y_385
 BV BOUND     y_386
 BV BOUND     y_387
 BV BOUND     y_388
 BV BOUND     y_389
 BV BOUND     y_390
 BV BOUND     y_391
 BV BOUND     y_392
 BV BOUND     y_393
 BV BOUND     y_394
 BV BOUND     y_395
 BV BOUND     y_396
 BV BOUND     y_397
 BV BOUND     y_398
 BV BOUND     y_399
 BV BOUND     y_400
 BV BOUND     y_401
 BV BOUND     y_402
 BV BOUND     y_403
 BV BOUND     y_404
 BV BOUND     y_405
 BV BOUND     y_406
 BV BOUND     y_407
 BV BOUND     y_408
 BV BOUND     y_409
 BV BOUND     y_410
 BV BOUND     y_411
 BV BOUND     y_412
 BV BOUND     y_413
 BV BOUND     y_414
 BV BOUND     y_415
 BV BOUND     y_416
 BV BOUND     y_417
 BV BOUND     y_418
 BV BOUND     y_419
 BV BOUND     y_420
 BV BOUND     y_421
 BV BOUND     y_422
 BV BOUND     y_423
 BV BOUND     y_424
 BV BOUND     y_425
 BV BOUND     y_426
 BV BOUND     y_427
 BV BOUND     y_428
 BV BOUND     y_429
 BV BOUND     y_430
 BV BOUND     y_431
 BV BOUND     y_432
 BV BOUND     y_433
 BV BOUND     y_434
 BV BOUND     y_435
 BV BOUND     y_436
 BV BOUND     y_437
 BV BOUND     y_438
 BV BOUND     y_439
 BV BOUND     y_440
 BV BOUND     y_441
 BV BOUND     y_442
 BV BOUND     y_443
 BV BOUND     y_444
 BV BOUND     y_445
 BV BOUND     y_446
 BV BOUND     y_447
 BV BOUND     y_448
 BV BOUND     y_449
 BV BOUND     y_450
 BV BOUND     y_451
 BV BOUND     y_452
 BV BOUND     y_453
 BV BOUND     y_454
 BV BOUND     y_455
 BV BOUND     y_456
 BV BOUND     y_457
 BV BOUND     y_458
 BV BOUND     y_459
 BV BOUND     y_460
 BV BOUND     y_461
 BV BOUND     y_462
 BV BOUND     y_463
 BV BOUND     y_464
 BV BOUND     y_465
 BV BOUND     y_466
 BV BOUND     y_467
 BV BOUND     y_468
 BV BOUND     y_469
 BV BOUND     y_470
 BV BOUND     y_471
 BV BOUND     y_472
 BV BOUND     y_473
 BV BOUND     y_474
 BV BOUND     y_475
 BV BOUND     y_476
 BV BOUND     y_477
 BV BOUND     y_478
 BV BOUND     y_479
 BV BOUND     y_480
 BV BOUND     y_481
 BV BOUND     y_482
 BV BOUND     y_483
 BV BOUND     y_484
 BV BOUND     y_485
 BV BOUND     y_486
 BV BOUND     y_487
 BV BOUND     y_488
 BV BOUND     y_489
 BV BOUND     y_490
 BV BOUND     y_491
 BV BOUND     y_492
 BV BOUND     y_493
 BV BOUND     y_494
ENDATA
