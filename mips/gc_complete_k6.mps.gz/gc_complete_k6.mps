NAME          gc_complete_k6
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 L  LINK_1_0
 L  LINK_2_0
 L  LINK_2_1
 L  LINK_3_0
 L  LINK_3_1
 L  LINK_3_2
 L  LINK_4_0
 L  LINK_4_1
 L  LINK_4_2
 L  LINK_4_3
 L  LINK_5_0
 L  LINK_5_1
 L  LINK_5_2
 L  LINK_5_3
 L  LINK_5_4
 L  EDGE_0_1_0
 L  EDGE_0_2_0
 L  EDGE_0_3_0
 L  EDGE_0_4_0
 L  EDGE_0_5_0
 L  EDGE_1_2_0
 L  EDGE_1_2_1
 L  EDGE_1_3_0
 L  EDGE_1_3_1
 L  EDGE_1_4_0
 L  EDGE_1_4_1
 L  EDGE_1_5_0
 L  EDGE_1_5_1
 L  EDGE_2_3_0
 L  EDGE_2_3_1
 L  EDGE_2_3_2
 L  EDGE_2_4_0
 L  EDGE_2_4_1
 L  EDGE_2_4_2
 L  EDGE_2_5_0
 L  EDGE_2_5_1
 L  EDGE_2_5_2
 L  EDGE_3_4_0
 L  EDGE_3_4_1
 L  EDGE_3_4_2
 L  EDGE_3_4_3
 L  EDGE_3_5_0
 L  EDGE_3_5_1
 L  EDGE_3_5_2
 L  EDGE_3_5_3
 L  EDGE_4_5_0
 L  EDGE_4_5_1
 L  EDGE_4_5_2
 L  EDGE_4_5_3
 L  EDGE_4_5_4
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_0           OBJ           1.0
    x_0_0           ASSIGN_0        1.0
    x_0_0           LINK_1_0        -1.0
    x_0_0           LINK_2_0        -1.0
    x_0_0           LINK_3_0        -1.0
    x_0_0           LINK_4_0        -1.0
    x_0_0           LINK_5_0        -1.0
    x_0_0           EDGE_0_1_0      1.0
    x_0_0           EDGE_0_2_0      1.0
    x_0_0           EDGE_0_3_0      1.0
    x_0_0           EDGE_0_4_0      1.0
    x_0_0           EDGE_0_5_0      1.0
    x_0_0           EDGE_1_2_0      -1.0
    x_0_0           EDGE_1_3_0      -1.0
    x_0_0           EDGE_1_4_0      -1.0
    x_0_0           EDGE_1_5_0      -1.0
    x_0_0           EDGE_2_3_0      -1.0
    x_0_0           EDGE_2_4_0      -1.0
    x_0_0           EDGE_2_5_0      -1.0
    x_0_0           EDGE_3_4_0      -1.0
    x_0_0           EDGE_3_5_0      -1.0
    x_0_0           EDGE_4_5_0      -1.0
    x_1_0           ASSIGN_1        1.0
    x_1_0           LINK_1_0        1.0
    x_1_0           EDGE_0_1_0      1.0
    x_1_0           EDGE_1_2_0      1.0
    x_1_0           EDGE_1_3_0      1.0
    x_1_0           EDGE_1_4_0      1.0
    x_1_0           EDGE_1_5_0      1.0
    x_1_1           OBJ           1.0
    x_1_1           ASSIGN_1        1.0
    x_1_1           LINK_2_1        -1.0
    x_1_1           LINK_3_1        -1.0
    x_1_1           LINK_4_1        -1.0
    x_1_1           LINK_5_1        -1.0
    x_1_1           EDGE_1_2_1      1.0
    x_1_1           EDGE_1_3_1      1.0
    x_1_1           EDGE_1_4_1      1.0
    x_1_1           EDGE_1_5_1      1.0
    x_1_1           EDGE_2_3_1      -1.0
    x_1_1           EDGE_2_4_1      -1.0
    x_1_1           EDGE_2_5_1      -1.0
    x_1_1           EDGE_3_4_1      -1.0
    x_1_1           EDGE_3_5_1      -1.0
    x_1_1           EDGE_4_5_1      -1.0
    x_2_0           ASSIGN_2        1.0
    x_2_0           LINK_2_0        1.0
    x_2_0           EDGE_0_2_0      1.0
    x_2_0           EDGE_1_2_0      1.0
    x_2_0           EDGE_2_3_0      1.0
    x_2_0           EDGE_2_4_0      1.0
    x_2_0           EDGE_2_5_0      1.0
    x_2_1           ASSIGN_2        1.0
    x_2_1           LINK_2_1        1.0
    x_2_1           EDGE_1_2_1      1.0
    x_2_1           EDGE_2_3_1      1.0
    x_2_1           EDGE_2_4_1      1.0
    x_2_1           EDGE_2_5_1      1.0
    x_2_2           OBJ           1.0
    x_2_2           ASSIGN_2        1.0
    x_2_2           LINK_3_2        -1.0
    x_2_2           LINK_4_2        -1.0
    x_2_2           LINK_5_2        -1.0
    x_2_2           EDGE_2_3_2      1.0
    x_2_2           EDGE_2_4_2      1.0
    x_2_2           EDGE_2_5_2      1.0
    x_2_2           EDGE_3_4_2      -1.0
    x_2_2           EDGE_3_5_2      -1.0
    x_2_2           EDGE_4_5_2      -1.0
    x_3_0           ASSIGN_3        1.0
    x_3_0           LINK_3_0        1.0
    x_3_0           EDGE_0_3_0      1.0
    x_3_0           EDGE_1_3_0      1.0
    x_3_0           EDGE_2_3_0      1.0
    x_3_0           EDGE_3_4_0      1.0
    x_3_0           EDGE_3_5_0      1.0
    x_3_1           ASSIGN_3        1.0
    x_3_1           LINK_3_1        1.0
    x_3_1           EDGE_1_3_1      1.0
    x_3_1           EDGE_2_3_1      1.0
    x_3_1           EDGE_3_4_1      1.0
    x_3_1           EDGE_3_5_1      1.0
    x_3_2           ASSIGN_3        1.0
    x_3_2           LINK_3_2        1.0
    x_3_2           EDGE_2_3_2      1.0
    x_3_2           EDGE_3_4_2      1.0
    x_3_2           EDGE_3_5_2      1.0
    x_3_3           OBJ           1.0
    x_3_3           ASSIGN_3        1.0
    x_3_3           LINK_4_3        -1.0
    x_3_3           LINK_5_3        -1.0
    x_3_3           EDGE_3_4_3      1.0
    x_3_3           EDGE_3_5_3      1.0
    x_3_3           EDGE_4_5_3      -1.0
    x_4_0           ASSIGN_4        1.0
    x_4_0           LINK_4_0        1.0
    x_4_0           EDGE_0_4_0      1.0
    x_4_0           EDGE_1_4_0      1.0
    x_4_0           EDGE_2_4_0      1.0
    x_4_0           EDGE_3_4_0      1.0
    x_4_0           EDGE_4_5_0      1.0
    x_4_1           ASSIGN_4        1.0
    x_4_1           LINK_4_1        1.0
    x_4_1           EDGE_1_4_1      1.0
    x_4_1           EDGE_2_4_1      1.0
    x_4_1           EDGE_3_4_1      1.0
    x_4_1           EDGE_4_5_1      1.0
    x_4_2           ASSIGN_4        1.0
    x_4_2           LINK_4_2        1.0
    x_4_2           EDGE_2_4_2      1.0
    x_4_2           EDGE_3_4_2      1.0
    x_4_2           EDGE_4_5_2      1.0
    x_4_3           ASSIGN_4        1.0
    x_4_3           LINK_4_3        1.0
    x_4_3           EDGE_3_4_3      1.0
    x_4_3           EDGE_4_5_3      1.0
    x_4_4           OBJ           1.0
    x_4_4           ASSIGN_4        1.0
    x_4_4           LINK_5_4        -1.0
    x_4_4           EDGE_4_5_4      1.0
    x_5_0           ASSIGN_5        1.0
    x_5_0           LINK_5_0        1.0
    x_5_0           EDGE_0_5_0      1.0
    x_5_0           EDGE_1_5_0      1.0
    x_5_0           EDGE_2_5_0      1.0
    x_5_0           EDGE_3_5_0      1.0
    x_5_0           EDGE_4_5_0      1.0
    x_5_1           ASSIGN_5        1.0
    x_5_1           LINK_5_1        1.0
    x_5_1           EDGE_1_5_1      1.0
    x_5_1           EDGE_2_5_1      1.0
    x_5_1           EDGE_3_5_1      1.0
    x_5_1           EDGE_4_5_1      1.0
    x_5_2           ASSIGN_5        1.0
    x_5_2           LINK_5_2        1.0
    x_5_2           EDGE_2_5_2      1.0
    x_5_2           EDGE_3_5_2      1.0
    x_5_2           EDGE_4_5_2      1.0
    x_5_3           ASSIGN_5        1.0
    x_5_3           LINK_5_3        1.0
    x_5_3           EDGE_3_5_3      1.0
    x_5_3           EDGE_4_5_3      1.0
    x_5_4           ASSIGN_5        1.0
    x_5_4           LINK_5_4        1.0
    x_5_4           EDGE_4_5_4      1.0
    x_5_5           OBJ           1.0
    x_5_5           ASSIGN_5        1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           ASSIGN_0        1.0
    RHS           ASSIGN_1        1.0
    RHS           ASSIGN_2        1.0
    RHS           ASSIGN_3        1.0
    RHS           ASSIGN_4        1.0
    RHS           ASSIGN_5        1.0
    RHS           EDGE_0_1_0      1.0
    RHS           EDGE_0_2_0      1.0
    RHS           EDGE_0_3_0      1.0
    RHS           EDGE_0_4_0      1.0
    RHS           EDGE_0_5_0      1.0
    RHS           EDGE_1_2_1      1.0
    RHS           EDGE_1_3_1      1.0
    RHS           EDGE_1_4_1      1.0
    RHS           EDGE_1_5_1      1.0
    RHS           EDGE_2_3_2      1.0
    RHS           EDGE_2_4_2      1.0
    RHS           EDGE_2_5_2      1.0
    RHS           EDGE_3_4_3      1.0
    RHS           EDGE_3_5_3      1.0
    RHS           EDGE_4_5_4      1.0
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_2
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_3
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_4
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_5
ENDATA
