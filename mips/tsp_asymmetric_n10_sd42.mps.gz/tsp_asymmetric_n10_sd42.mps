NAME          tsp_asymmetric_n10_sd42
ROWS
 N  OBJ
 E  OUT_0
 E  OUT_1
 E  OUT_2
 E  OUT_3
 E  OUT_4
 E  OUT_5
 E  OUT_6
 E  OUT_7
 E  OUT_8
 E  OUT_9
 E  IN_0
 E  IN_1
 E  IN_2
 E  IN_3
 E  IN_4
 E  IN_5
 E  IN_6
 E  IN_7
 E  IN_8
 E  IN_9
 L  MTZ_1_2
 L  MTZ_1_3
 L  MTZ_1_4
 L  MTZ_1_5
 L  MTZ_1_6
 L  MTZ_1_7
 L  MTZ_1_8
 L  MTZ_1_9
 L  MTZ_2_1
 L  MTZ_2_3
 L  MTZ_2_4
 L  MTZ_2_5
 L  MTZ_2_6
 L  MTZ_2_7
 L  MTZ_2_8
 L  MTZ_2_9
 L  MTZ_3_1
 L  MTZ_3_2
 L  MTZ_3_4
 L  MTZ_3_5
 L  MTZ_3_6
 L  MTZ_3_7
 L  MTZ_3_8
 L  MTZ_3_9
 L  MTZ_4_1
 L  MTZ_4_2
 L  MTZ_4_3
 L  MTZ_4_5
 L  MTZ_4_6
 L  MTZ_4_7
 L  MTZ_4_8
 L  MTZ_4_9
 L  MTZ_5_1
 L  MTZ_5_2
 L  MTZ_5_3
 L  MTZ_5_4
 L  MTZ_5_6
 L  MTZ_5_7
 L  MTZ_5_8
 L  MTZ_5_9
 L  MTZ_6_1
 L  MTZ_6_2
 L  MTZ_6_3
 L  MTZ_6_4
 L  MTZ_6_5
 L  MTZ_6_7
 L  MTZ_6_8
 L  MTZ_6_9
 L  MTZ_7_1
 L  MTZ_7_2
 L  MTZ_7_3
 L  MTZ_7_4
 L  MTZ_7_5
 L  MTZ_7_6
 L  MTZ_7_8
 L  MTZ_7_9
 L  MTZ_8_1
 L  MTZ_8_2
 L  MTZ_8_3
 L  MTZ_8_4
 L  MTZ_8_5
 L  MTZ_8_6
 L  MTZ_8_7
 L  MTZ_8_9
 L  MTZ_9_1
 L  MTZ_9_2
 L  MTZ_9_3
 L  MTZ_9_4
 L  MTZ_9_5
 L  MTZ_9_6
 L  MTZ_9_7
 L  MTZ_9_8
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_1           OBJ           450
    x_0_1           OUT_0           1.0
    x_0_1           IN_1            1.0
    x_0_2           OBJ           471
    x_0_2           OUT_0           1.0
    x_0_2           IN_2            1.0
    x_0_3           OBJ           225
    x_0_3           OUT_0           1.0
    x_0_3           IN_3            1.0
    x_0_4           OBJ           182
    x_0_4           OUT_0           1.0
    x_0_4           IN_4            1.0
    x_0_5           OBJ           730
    x_0_5           OUT_0           1.0
    x_0_5           IN_5            1.0
    x_0_6           OBJ           705
    x_0_6           OUT_0           1.0
    x_0_6           IN_6            1.0
    x_0_7           OBJ           642
    x_0_7           OUT_0           1.0
    x_0_7           IN_7            1.0
    x_0_8           OBJ           529
    x_0_8           OUT_0           1.0
    x_0_8           IN_8            1.0
    x_0_9           OBJ           163
    x_0_9           OUT_0           1.0
    x_0_9           IN_9            1.0
    x_1_0           OBJ           298
    x_1_0           OUT_1           1.0
    x_1_0           IN_0            1.0
    x_1_2           OBJ           538
    x_1_2           OUT_1           1.0
    x_1_2           IN_2            1.0
    x_1_2           MTZ_1_2         9.0
    x_1_3           OBJ           634
    x_1_3           OUT_1           1.0
    x_1_3           IN_3            1.0
    x_1_3           MTZ_1_3         9.0
    x_1_4           OBJ           174
    x_1_4           OUT_1           1.0
    x_1_4           IN_4            1.0
    x_1_4           MTZ_1_4         9.0
    x_1_5           OBJ           236
    x_1_5           OUT_1           1.0
    x_1_5           IN_5            1.0
    x_1_5           MTZ_1_5         9.0
    x_1_6           OBJ           272
    x_1_6           OUT_1           1.0
    x_1_6           IN_6            1.0
    x_1_6           MTZ_1_6         9.0
    x_1_7           OBJ           507
    x_1_7           OUT_1           1.0
    x_1_7           IN_7            1.0
    x_1_7           MTZ_1_7         9.0
    x_1_8           OBJ           308
    x_1_8           OUT_1           1.0
    x_1_8           IN_8            1.0
    x_1_8           MTZ_1_8         9.0
    x_1_9           OBJ           608
    x_1_9           OUT_1           1.0
    x_1_9           IN_9            1.0
    x_1_9           MTZ_1_9         9.0
    x_2_0           OBJ           781
    x_2_0           OUT_2           1.0
    x_2_0           IN_0            1.0
    x_2_1           OBJ           455
    x_2_1           OUT_2           1.0
    x_2_1           IN_1            1.0
    x_2_1           MTZ_2_1         9.0
    x_2_3           OBJ           722
    x_2_3           OUT_2           1.0
    x_2_3           IN_3            1.0
    x_2_3           MTZ_2_3         9.0
    x_2_4           OBJ           804
    x_2_4           OUT_2           1.0
    x_2_4           IN_4            1.0
    x_2_4           MTZ_2_4         9.0
    x_2_5           OBJ           493
    x_2_5           OUT_2           1.0
    x_2_5           IN_5            1.0
    x_2_5           MTZ_2_5         9.0
    x_2_6           OBJ           679
    x_2_6           OUT_2           1.0
    x_2_6           IN_6            1.0
    x_2_6           MTZ_2_6         9.0
    x_2_7           OBJ           201
    x_2_7           OUT_2           1.0
    x_2_7           IN_7            1.0
    x_2_7           MTZ_2_7         9.0
    x_2_8           OBJ           472
    x_2_8           OUT_2           1.0
    x_2_8           IN_8            1.0
    x_2_8           MTZ_2_8         9.0
    x_2_9           OBJ           509
    x_2_9           OUT_2           1.0
    x_2_9           IN_9            1.0
    x_2_9           MTZ_2_9         9.0
    x_3_0           OBJ           197
    x_3_0           OUT_3           1.0
    x_3_0           IN_0            1.0
    x_3_1           OBJ           764
    x_3_1           OUT_3           1.0
    x_3_1           IN_1            1.0
    x_3_1           MTZ_3_1         9.0
    x_3_2           OBJ           648
    x_3_2           OUT_3           1.0
    x_3_2           IN_2            1.0
    x_3_2           MTZ_3_2         9.0
    x_3_4           OBJ           561
    x_3_4           OUT_3           1.0
    x_3_4           IN_4            1.0
    x_3_4           MTZ_3_4         9.0
    x_3_5           OBJ           902
    x_3_5           OUT_3           1.0
    x_3_5           IN_5            1.0
    x_3_5           MTZ_3_5         9.0
    x_3_6           OBJ           892
    x_3_6           OUT_3           1.0
    x_3_6           IN_6            1.0
    x_3_6           MTZ_3_6         9.0
    x_3_7           OBJ           665
    x_3_7           OUT_3           1.0
    x_3_7           IN_7            1.0
    x_3_7           MTZ_3_7         9.0
    x_3_8           OBJ           778
    x_3_8           OUT_3           1.0
    x_3_8           IN_8            1.0
    x_3_8           MTZ_3_8         9.0
    x_3_9           OBJ           119
    x_3_9           OUT_3           1.0
    x_3_9           IN_9            1.0
    x_3_9           MTZ_3_9         9.0
    x_4_0           OBJ           261
    x_4_0           OUT_4           1.0
    x_4_0           IN_0            1.0
    x_4_1           OBJ           260
    x_4_1           OUT_4           1.0
    x_4_1           IN_1            1.0
    x_4_1           MTZ_4_1         9.0
    x_4_2           OBJ           875
    x_4_2           OUT_4           1.0
    x_4_2           IN_2            1.0
    x_4_2           MTZ_4_2         9.0
    x_4_3           OBJ           496
    x_4_3           OUT_4           1.0
    x_4_3           IN_3            1.0
    x_4_3           MTZ_4_3         9.0
    x_4_5           OBJ           580
    x_4_5           OUT_4           1.0
    x_4_5           IN_5            1.0
    x_4_5           MTZ_4_5         9.0
    x_4_6           OBJ           313
    x_4_6           OUT_4           1.0
    x_4_6           IN_6            1.0
    x_4_6           MTZ_4_6         9.0
    x_4_7           OBJ           471
    x_4_7           OUT_4           1.0
    x_4_7           IN_7            1.0
    x_4_7           MTZ_4_7         9.0
    x_4_8           OBJ           520
    x_4_8           OUT_4           1.0
    x_4_8           IN_8            1.0
    x_4_8           MTZ_4_8         9.0
    x_4_9           OBJ           290
    x_4_9           OUT_4           1.0
    x_4_9           IN_9            1.0
    x_4_9           MTZ_4_9         9.0
    x_5_0           OBJ           537
    x_5_0           OUT_5           1.0
    x_5_0           IN_0            1.0
    x_5_1           OBJ           219
    x_5_1           OUT_5           1.0
    x_5_1           IN_1            1.0
    x_5_1           MTZ_5_1         9.0
    x_5_2           OBJ           472
    x_5_2           OUT_5           1.0
    x_5_2           IN_2            1.0
    x_5_2           MTZ_5_2         9.0
    x_5_3           OBJ           858
    x_5_3           OUT_5           1.0
    x_5_3           IN_3            1.0
    x_5_3           MTZ_5_3         9.0
    x_5_4           OBJ           475
    x_5_4           OUT_5           1.0
    x_5_4           IN_4            1.0
    x_5_4           MTZ_5_4         9.0
    x_5_6           OBJ           334
    x_5_6           OUT_5           1.0
    x_5_6           IN_6            1.0
    x_5_6           MTZ_5_6         9.0
    x_5_7           OBJ           358
    x_5_7           OUT_5           1.0
    x_5_7           IN_7            1.0
    x_5_7           MTZ_5_7         9.0
    x_5_8           OBJ           72
    x_5_8           OUT_5           1.0
    x_5_8           IN_8            1.0
    x_5_8           MTZ_5_8         9.0
    x_5_9           OBJ           976
    x_5_9           OUT_5           1.0
    x_5_9           IN_9            1.0
    x_5_9           MTZ_5_9         9.0
    x_6_0           OBJ           694
    x_6_0           OUT_6           1.0
    x_6_0           IN_0            1.0
    x_6_1           OBJ           266
    x_6_1           OUT_6           1.0
    x_6_1           IN_1            1.0
    x_6_1           MTZ_6_1         9.0
    x_6_2           OBJ           687
    x_6_2           OUT_6           1.0
    x_6_2           IN_2            1.0
    x_6_2           MTZ_6_2         9.0
    x_6_3           OBJ           993
    x_6_3           OUT_6           1.0
    x_6_3           IN_3            1.0
    x_6_3           MTZ_6_3         9.0
    x_6_4           OBJ           343
    x_6_4           OUT_6           1.0
    x_6_4           IN_4            1.0
    x_6_4           MTZ_6_4         9.0
    x_6_5           OBJ           336
    x_6_5           OUT_6           1.0
    x_6_5           IN_5            1.0
    x_6_5           MTZ_6_5         9.0
    x_6_7           OBJ           922
    x_6_7           OUT_6           1.0
    x_6_7           IN_7            1.0
    x_6_7           MTZ_6_7         9.0
    x_6_8           OBJ           473
    x_6_8           OUT_6           1.0
    x_6_8           IN_8            1.0
    x_6_8           MTZ_6_8         9.0
    x_6_9           OBJ           834
    x_6_9           OUT_6           1.0
    x_6_9           IN_9            1.0
    x_6_9           MTZ_6_9         9.0
    x_7_0           OBJ           578
    x_7_0           OUT_7           1.0
    x_7_0           IN_0            1.0
    x_7_1           OBJ           596
    x_7_1           OUT_7           1.0
    x_7_1           IN_1            1.0
    x_7_1           MTZ_7_1         9.0
    x_7_2           OBJ           184
    x_7_2           OUT_7           1.0
    x_7_2           IN_2            1.0
    x_7_2           MTZ_7_2         9.0
    x_7_3           OBJ           434
    x_7_3           OUT_7           1.0
    x_7_3           IN_3            1.0
    x_7_3           MTZ_7_3         9.0
    x_7_4           OBJ           405
    x_7_4           OUT_7           1.0
    x_7_4           IN_4            1.0
    x_7_4           MTZ_7_4         9.0
    x_7_5           OBJ           385
    x_7_5           OUT_7           1.0
    x_7_5           IN_5            1.0
    x_7_5           MTZ_7_5         9.0
    x_7_6           OBJ           614
    x_7_6           OUT_7           1.0
    x_7_6           IN_6            1.0
    x_7_6           MTZ_7_6         9.0
    x_7_8           OBJ           357
    x_7_8           OUT_7           1.0
    x_7_8           IN_8            1.0
    x_7_8           MTZ_7_8         9.0
    x_7_9           OBJ           711
    x_7_9           OUT_7           1.0
    x_7_9           IN_9            1.0
    x_7_9           MTZ_7_9         9.0
    x_8_0           OBJ           862
    x_8_0           OUT_8           1.0
    x_8_0           IN_0            1.0
    x_8_1           OBJ           329
    x_8_1           OUT_8           1.0
    x_8_1           IN_1            1.0
    x_8_1           MTZ_8_1         9.0
    x_8_2           OBJ           572
    x_8_2           OUT_8           1.0
    x_8_2           IN_2            1.0
    x_8_2           MTZ_8_2         9.0
    x_8_3           OBJ           786
    x_8_3           OUT_8           1.0
    x_8_3           IN_3            1.0
    x_8_3           MTZ_8_3         9.0
    x_8_4           OBJ           743
    x_8_4           OUT_8           1.0
    x_8_4           IN_4            1.0
    x_8_4           MTZ_8_4         9.0
    x_8_5           OBJ           82
    x_8_5           OUT_8           1.0
    x_8_5           IN_5            1.0
    x_8_5           MTZ_8_5         9.0
    x_8_6           OBJ           374
    x_8_6           OUT_8           1.0
    x_8_6           IN_6            1.0
    x_8_6           MTZ_8_6         9.0
    x_8_7           OBJ           366
    x_8_7           OUT_8           1.0
    x_8_7           IN_7            1.0
    x_8_7           MTZ_8_7         9.0
    x_8_9           OBJ           860
    x_8_9           OUT_8           1.0
    x_8_9           IN_9            1.0
    x_8_9           MTZ_8_9         9.0
    x_9_0           OBJ           147
    x_9_0           OUT_9           1.0
    x_9_0           IN_0            1.0
    x_9_1           OBJ           606
    x_9_1           OUT_9           1.0
    x_9_1           IN_1            1.0
    x_9_1           MTZ_9_1         9.0
    x_9_2           OBJ           835
    x_9_2           OUT_9           1.0
    x_9_2           IN_2            1.0
    x_9_2           MTZ_9_2         9.0
    x_9_3           OBJ           108
    x_9_3           OUT_9           1.0
    x_9_3           IN_3            1.0
    x_9_3           MTZ_9_3         9.0
    x_9_4           OBJ           323
    x_9_4           OUT_9           1.0
    x_9_4           IN_4            1.0
    x_9_4           MTZ_9_4         9.0
    x_9_5           OBJ           1004
    x_9_5           OUT_9           1.0
    x_9_5           IN_5            1.0
    x_9_5           MTZ_9_5         9.0
    x_9_6           OBJ           811
    x_9_6           OUT_9           1.0
    x_9_6           IN_6            1.0
    x_9_6           MTZ_9_6         9.0
    x_9_7           OBJ           424
    x_9_7           OUT_9           1.0
    x_9_7           IN_7            1.0
    x_9_7           MTZ_9_7         9.0
    x_9_8           OBJ           604
    x_9_8           OUT_9           1.0
    x_9_8           IN_8            1.0
    x_9_8           MTZ_9_8         9.0
    MARK0001  'MARKER'                 'INTEND'
    u_1             MTZ_1_2         1.0
    u_1             MTZ_1_3         1.0
    u_1             MTZ_1_4         1.0
    u_1             MTZ_1_5         1.0
    u_1             MTZ_1_6         1.0
    u_1             MTZ_1_7         1.0
    u_1             MTZ_1_8         1.0
    u_1             MTZ_1_9         1.0
    u_1             MTZ_2_1         -1.0
    u_1             MTZ_3_1         -1.0
    u_1             MTZ_4_1         -1.0
    u_1             MTZ_5_1         -1.0
    u_1             MTZ_6_1         -1.0
    u_1             MTZ_7_1         -1.0
    u_1             MTZ_8_1         -1.0
    u_1             MTZ_9_1         -1.0
    u_2             MTZ_1_2         -1.0
    u_2             MTZ_2_1         1.0
    u_2             MTZ_2_3         1.0
    u_2             MTZ_2_4         1.0
    u_2             MTZ_2_5         1.0
    u_2             MTZ_2_6         1.0
    u_2             MTZ_2_7         1.0
    u_2             MTZ_2_8         1.0
    u_2             MTZ_2_9         1.0
    u_2             MTZ_3_2         -1.0
    u_2             MTZ_4_2         -1.0
    u_2             MTZ_5_2         -1.0
    u_2             MTZ_6_2         -1.0
    u_2             MTZ_7_2         -1.0
    u_2             MTZ_8_2         -1.0
    u_2             MTZ_9_2         -1.0
    u_3             MTZ_1_3         -1.0
    u_3             MTZ_2_3         -1.0
    u_3             MTZ_3_1         1.0
    u_3             MTZ_3_2         1.0
    u_3             MTZ_3_4         1.0
    u_3             MTZ_3_5         1.0
    u_3             MTZ_3_6         1.0
    u_3             MTZ_3_7         1.0
    u_3             MTZ_3_8         1.0
    u_3             MTZ_3_9         1.0
    u_3             MTZ_4_3         -1.0
    u_3             MTZ_5_3         -1.0
    u_3             MTZ_6_3         -1.0
    u_3             MTZ_7_3         -1.0
    u_3             MTZ_8_3         -1.0
    u_3             MTZ_9_3         -1.0
    u_4             MTZ_1_4         -1.0
    u_4             MTZ_2_4         -1.0
    u_4             MTZ_3_4         -1.0
    u_4             MTZ_4_1         1.0
    u_4             MTZ_4_2         1.0
    u_4             MTZ_4_3         1.0
    u_4             MTZ_4_5         1.0
    u_4             MTZ_4_6         1.0
    u_4             MTZ_4_7         1.0
    u_4             MTZ_4_8         1.0
    u_4             MTZ_4_9         1.0
    u_4             MTZ_5_4         -1.0
    u_4             MTZ_6_4         -1.0
    u_4             MTZ_7_4         -1.0
    u_4             MTZ_8_4         -1.0
    u_4             MTZ_9_4         -1.0
    u_5             MTZ_1_5         -1.0
    u_5             MTZ_2_5         -1.0
    u_5             MTZ_3_5         -1.0
    u_5             MTZ_4_5         -1.0
    u_5             MTZ_5_1         1.0
    u_5             MTZ_5_2         1.0
    u_5             MTZ_5_3         1.0
    u_5             MTZ_5_4         1.0
    u_5             MTZ_5_6         1.0
    u_5             MTZ_5_7         1.0
    u_5             MTZ_5_8         1.0
    u_5             MTZ_5_9         1.0
    u_5             MTZ_6_5         -1.0
    u_5             MTZ_7_5         -1.0
    u_5             MTZ_8_5         -1.0
    u_5             MTZ_9_5         -1.0
    u_6             MTZ_1_6         -1.0
    u_6             MTZ_2_6         -1.0
    u_6             MTZ_3_6         -1.0
    u_6             MTZ_4_6         -1.0
    u_6             MTZ_5_6         -1.0
    u_6             MTZ_6_1         1.0
    u_6             MTZ_6_2         1.0
    u_6             MTZ_6_3         1.0
    u_6             MTZ_6_4         1.0
    u_6             MTZ_6_5         1.0
    u_6             MTZ_6_7         1.0
    u_6             MTZ_6_8         1.0
    u_6             MTZ_6_9         1.0
    u_6             MTZ_7_6         -1.0
    u_6             MTZ_8_6         -1.0
    u_6             MTZ_9_6         -1.0
    u_7             MTZ_1_7         -1.0
    u_7             MTZ_2_7         -1.0
    u_7             MTZ_3_7         -1.0
    u_7             MTZ_4_7         -1.0
    u_7             MTZ_5_7         -1.0
    u_7             MTZ_6_7         -1.0
    u_7             MTZ_7_1         1.0
    u_7             MTZ_7_2         1.0
    u_7             MTZ_7_3         1.0
    u_7             MTZ_7_4         1.0
    u_7             MTZ_7_5         1.0
    u_7             MTZ_7_6         1.0
    u_7             MTZ_7_8         1.0
    u_7             MTZ_7_9         1.0
    u_7             MTZ_8_7         -1.0
    u_7             MTZ_9_7         -1.0
    u_8             MTZ_1_8         -1.0
    u_8             MTZ_2_8         -1.0
    u_8             MTZ_3_8         -1.0
    u_8             MTZ_4_8         -1.0
    u_8             MTZ_5_8         -1.0
    u_8             MTZ_6_8         -1.0
    u_8             MTZ_7_8         -1.0
    u_8             MTZ_8_1         1.0
    u_8             MTZ_8_2         1.0
    u_8             MTZ_8_3         1.0
    u_8             MTZ_8_4         1.0
    u_8             MTZ_8_5         1.0
    u_8             MTZ_8_6         1.0
    u_8             MTZ_8_7         1.0
    u_8             MTZ_8_9         1.0
    u_8             MTZ_9_8         -1.0
    u_9             MTZ_1_9         -1.0
    u_9             MTZ_2_9         -1.0
    u_9             MTZ_3_9         -1.0
    u_9             MTZ_4_9         -1.0
    u_9             MTZ_5_9         -1.0
    u_9             MTZ_6_9         -1.0
    u_9             MTZ_7_9         -1.0
    u_9             MTZ_8_9         -1.0
    u_9             MTZ_9_1         1.0
    u_9             MTZ_9_2         1.0
    u_9             MTZ_9_3         1.0
    u_9             MTZ_9_4         1.0
    u_9             MTZ_9_5         1.0
    u_9             MTZ_9_6         1.0
    u_9             MTZ_9_7         1.0
    u_9             MTZ_9_8         1.0
RHS
    RHS           OUT_0           1.0
    RHS           OUT_1           1.0
    RHS           OUT_2           1.0
    RHS           OUT_3           1.0
    RHS           OUT_4           1.0
    RHS           OUT_5           1.0
    RHS           OUT_6           1.0
    RHS           OUT_7           1.0
    RHS           OUT_8           1.0
    RHS           OUT_9           1.0
    RHS           IN_0            1.0
    RHS           IN_1            1.0
    RHS           IN_2            1.0
    RHS           IN_3            1.0
    RHS           IN_4            1.0
    RHS           IN_5            1.0
    RHS           IN_6            1.0
    RHS           IN_7            1.0
    RHS           IN_8            1.0
    RHS           IN_9            1.0
    RHS           MTZ_1_2         8.0
    RHS           MTZ_1_3         8.0
    RHS           MTZ_1_4         8.0
    RHS           MTZ_1_5         8.0
    RHS           MTZ_1_6         8.0
    RHS           MTZ_1_7         8.0
    RHS           MTZ_1_8         8.0
    RHS           MTZ_1_9         8.0
    RHS           MTZ_2_1         8.0
    RHS           MTZ_2_3         8.0
    RHS           MTZ_2_4         8.0
    RHS           MTZ_2_5         8.0
    RHS           MTZ_2_6         8.0
    RHS           MTZ_2_7         8.0
    RHS           MTZ_2_8         8.0
    RHS           MTZ_2_9         8.0
    RHS           MTZ_3_1         8.0
    RHS           MTZ_3_2         8.0
    RHS           MTZ_3_4         8.0
    RHS           MTZ_3_5         8.0
    RHS           MTZ_3_6         8.0
    RHS           MTZ_3_7         8.0
    RHS           MTZ_3_8         8.0
    RHS           MTZ_3_9         8.0
    RHS           MTZ_4_1         8.0
    RHS           MTZ_4_2         8.0
    RHS           MTZ_4_3         8.0
    RHS           MTZ_4_5         8.0
    RHS           MTZ_4_6         8.0
    RHS           MTZ_4_7         8.0
    RHS           MTZ_4_8         8.0
    RHS           MTZ_4_9         8.0
    RHS           MTZ_5_1         8.0
    RHS           MTZ_5_2         8.0
    RHS           MTZ_5_3         8.0
    RHS           MTZ_5_4         8.0
    RHS           MTZ_5_6         8.0
    RHS           MTZ_5_7         8.0
    RHS           MTZ_5_8         8.0
    RHS           MTZ_5_9         8.0
    RHS           MTZ_6_1         8.0
    RHS           MTZ_6_2         8.0
    RHS           MTZ_6_3         8.0
    RHS           MTZ_6_4         8.0
    RHS           MTZ_6_5         8.0
    RHS           MTZ_6_7         8.0
    RHS           MTZ_6_8         8.0
    RHS           MTZ_6_9         8.0
    RHS           MTZ_7_1         8.0
    RHS           MTZ_7_2         8.0
    RHS           MTZ_7_3         8.0
    RHS           MTZ_7_4         8.0
    RHS           MTZ_7_5         8.0
    RHS           MTZ_7_6         8.0
    RHS           MTZ_7_8         8.0
    RHS           MTZ_7_9         8.0
    RHS           MTZ_8_1         8.0
    RHS           MTZ_8_2         8.0
    RHS           MTZ_8_3         8.0
    RHS           MTZ_8_4         8.0
    RHS           MTZ_8_5         8.0
    RHS           MTZ_8_6         8.0
    RHS           MTZ_8_7         8.0
    RHS           MTZ_8_9         8.0
    RHS           MTZ_9_1         8.0
    RHS           MTZ_9_2         8.0
    RHS           MTZ_9_3         8.0
    RHS           MTZ_9_4         8.0
    RHS           MTZ_9_5         8.0
    RHS           MTZ_9_6         8.0
    RHS           MTZ_9_7         8.0
    RHS           MTZ_9_8         8.0
BOUNDS
 BV BOUND         x_0_1
 BV BOUND         x_0_2
 BV BOUND         x_0_3
 BV BOUND         x_0_4
 BV BOUND         x_0_5
 BV BOUND         x_0_6
 BV BOUND         x_0_7
 BV BOUND         x_0_8
 BV BOUND         x_0_9
 BV BOUND         x_1_0
 BV BOUND         x_1_2
 BV BOUND         x_1_3
 BV BOUND         x_1_4
 BV BOUND         x_1_5
 BV BOUND         x_1_6
 BV BOUND         x_1_7
 BV BOUND         x_1_8
 BV BOUND         x_1_9
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_3
 BV BOUND         x_2_4
 BV BOUND         x_2_5
 BV BOUND         x_2_6
 BV BOUND         x_2_7
 BV BOUND         x_2_8
 BV BOUND         x_2_9
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_4
 BV BOUND         x_3_5
 BV BOUND         x_3_6
 BV BOUND         x_3_7
 BV BOUND         x_3_8
 BV BOUND         x_3_9
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_5
 BV BOUND         x_4_6
 BV BOUND         x_4_7
 BV BOUND         x_4_8
 BV BOUND         x_4_9
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_6
 BV BOUND         x_5_7
 BV BOUND         x_5_8
 BV BOUND         x_5_9
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_7
 BV BOUND         x_6_8
 BV BOUND         x_6_9
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 BV BOUND         x_7_8
 BV BOUND         x_7_9
 BV BOUND         x_8_0
 BV BOUND         x_8_1
 BV BOUND         x_8_2
 BV BOUND         x_8_3
 BV BOUND         x_8_4
 BV BOUND         x_8_5
 BV BOUND         x_8_6
 BV BOUND         x_8_7
 BV BOUND         x_8_9
 BV BOUND         x_9_0
 BV BOUND         x_9_1
 BV BOUND         x_9_2
 BV BOUND         x_9_3
 BV BOUND         x_9_4
 BV BOUND         x_9_5
 BV BOUND         x_9_6
 BV BOUND         x_9_7
 BV BOUND         x_9_8
 LO BOUND         u_1       1.0
 UP BOUND         u_1       9.0
 LO BOUND         u_2       1.0
 UP BOUND         u_2       9.0
 LO BOUND         u_3       1.0
 UP BOUND         u_3       9.0
 LO BOUND         u_4       1.0
 UP BOUND         u_4       9.0
 LO BOUND         u_5       1.0
 UP BOUND         u_5       9.0
 LO BOUND         u_6       1.0
 UP BOUND         u_6       9.0
 LO BOUND         u_7       1.0
 UP BOUND         u_7       9.0
 LO BOUND         u_8       1.0
 UP BOUND         u_8       9.0
 LO BOUND         u_9       1.0
 UP BOUND         u_9       9.0
ENDATA
