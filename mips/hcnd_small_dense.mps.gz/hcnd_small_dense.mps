NAME          hcnd_small_dense
ROWS
 N  OBJ
 L  CAP_0_1
 L  CAP_0_3
 L  CAP_1_2
 L  CAP_1_3
 L  CAP_1_4
 L  CAP_1_5
 L  CAP_2_3
 L  CAP_2_4
 L  CAP_2_5
 L  CAP_3_4
 L  CAP_3_5
 L  CAP_4_5
 E  SUP_0
 E  DEM_0
 E  CONS_0_1_1
 E  CONS_0_3_1
 E  CONS_0_0_1
 E  CONS_0_1_2
 E  CONS_0_3_2
 E  CONS_0_4_2
 E  CONS_0_5_2
 E  SUP_1
 E  DEM_1
 E  CONS_1_1_1
 E  CONS_1_3_1
 E  CONS_1_0_1
 E  CONS_1_1_2
 E  CONS_1_3_2
 E  CONS_1_2_2
 E  CONS_1_5_2
 E  SUP_2
 E  DEM_2
 E  CONS_2_1_1
 E  CONS_2_3_1
 E  CONS_2_0_1
 E  CONS_2_1_2
 E  CONS_2_3_2
 E  CONS_2_4_2
 E  CONS_2_5_2
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_1           OBJ           1167
    y_0_1           CAP_0_1         -12.0
    y_0_3           OBJ           678
    y_0_3           CAP_0_3         -8.0
    y_1_2           OBJ           1278
    y_1_2           CAP_1_2         -10.0
    y_1_3           OBJ           803
    y_1_3           CAP_1_3         -6.0
    y_1_4           OBJ           638
    y_1_4           CAP_1_4         -4.0
    y_1_5           OBJ           426
    y_1_5           CAP_1_5         -12.0
    y_2_3           OBJ           596
    y_2_3           CAP_2_3         -12.0
    y_2_4           OBJ           326
    y_2_4           CAP_2_4         -10.0
    y_2_5           OBJ           785
    y_2_5           CAP_2_5         -9.0
    y_3_4           OBJ           279
    y_3_4           CAP_3_4         -11.0
    y_3_5           OBJ           200
    y_3_5           CAP_3_5         -11.0
    y_4_5           OBJ           382
    y_4_5           CAP_4_5         -8.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_0_1_0       CAP_0_1         1.0
    f_0_0_1_0       SUP_0           1.0
    f_0_0_1_0       CONS_0_1_1      -1.0
    f_0_0_3_0       CAP_0_3         1.0
    f_0_0_3_0       SUP_0           1.0
    f_0_0_3_0       CONS_0_3_1      -1.0
    f_0_0_1_1       CAP_0_1         1.0
    f_0_0_1_1       CONS_0_0_1      1.0
    f_0_0_1_1       CONS_0_1_2      -1.0
    f_0_0_3_1       CAP_0_3         1.0
    f_0_0_3_1       CONS_0_0_1      1.0
    f_0_0_3_1       CONS_0_3_2      -1.0
    f_0_1_2_1       CAP_1_2         1.0
    f_0_1_2_1       CONS_0_1_1      1.0
    f_0_1_2_1       DEM_0           1.0
    f_0_1_3_1       CAP_1_3         1.0
    f_0_1_3_1       CONS_0_1_1      1.0
    f_0_1_3_1       CONS_0_3_2      -1.0
    f_0_3_1_1       CAP_1_3         1.0
    f_0_3_1_1       CONS_0_3_1      1.0
    f_0_3_1_1       CONS_0_1_2      -1.0
    f_0_1_4_1       CAP_1_4         1.0
    f_0_1_4_1       CONS_0_1_1      1.0
    f_0_1_4_1       CONS_0_4_2      -1.0
    f_0_1_5_1       CAP_1_5         1.0
    f_0_1_5_1       CONS_0_1_1      1.0
    f_0_1_5_1       CONS_0_5_2      -1.0
    f_0_3_2_1       CAP_2_3         1.0
    f_0_3_2_1       CONS_0_3_1      1.0
    f_0_3_2_1       DEM_0           1.0
    f_0_3_4_1       CAP_3_4         1.0
    f_0_3_4_1       CONS_0_3_1      1.0
    f_0_3_4_1       CONS_0_4_2      -1.0
    f_0_3_5_1       CAP_3_5         1.0
    f_0_3_5_1       CONS_0_3_1      1.0
    f_0_3_5_1       CONS_0_5_2      -1.0
    f_0_1_2_2       CAP_1_2         1.0
    f_0_1_2_2       CONS_0_1_2      1.0
    f_0_1_2_2       DEM_0           1.0
    f_0_3_2_2       CAP_2_3         1.0
    f_0_3_2_2       CONS_0_3_2      1.0
    f_0_3_2_2       DEM_0           1.0
    f_0_4_2_2       CAP_2_4         1.0
    f_0_4_2_2       CONS_0_4_2      1.0
    f_0_4_2_2       DEM_0           1.0
    f_0_5_2_2       CAP_2_5         1.0
    f_0_5_2_2       CONS_0_5_2      1.0
    f_0_5_2_2       DEM_0           1.0
    f_1_0_1_0       CAP_0_1         1.0
    f_1_0_1_0       SUP_1           1.0
    f_1_0_1_0       CONS_1_1_1      -1.0
    f_1_0_3_0       CAP_0_3         1.0
    f_1_0_3_0       SUP_1           1.0
    f_1_0_3_0       CONS_1_3_1      -1.0
    f_1_0_1_1       CAP_0_1         1.0
    f_1_0_1_1       CONS_1_0_1      1.0
    f_1_0_1_1       CONS_1_1_2      -1.0
    f_1_0_3_1       CAP_0_3         1.0
    f_1_0_3_1       CONS_1_0_1      1.0
    f_1_0_3_1       CONS_1_3_2      -1.0
    f_1_1_2_1       CAP_1_2         1.0
    f_1_1_2_1       CONS_1_1_1      1.0
    f_1_1_2_1       CONS_1_2_2      -1.0
    f_1_1_3_1       CAP_1_3         1.0
    f_1_1_3_1       CONS_1_1_1      1.0
    f_1_1_3_1       CONS_1_3_2      -1.0
    f_1_3_1_1       CAP_1_3         1.0
    f_1_3_1_1       CONS_1_3_1      1.0
    f_1_3_1_1       CONS_1_1_2      -1.0
    f_1_1_4_1       CAP_1_4         1.0
    f_1_1_4_1       CONS_1_1_1      1.0
    f_1_1_4_1       DEM_1           1.0
    f_1_1_5_1       CAP_1_5         1.0
    f_1_1_5_1       CONS_1_1_1      1.0
    f_1_1_5_1       CONS_1_5_2      -1.0
    f_1_3_2_1       CAP_2_3         1.0
    f_1_3_2_1       CONS_1_3_1      1.0
    f_1_3_2_1       CONS_1_2_2      -1.0
    f_1_3_4_1       CAP_3_4         1.0
    f_1_3_4_1       CONS_1_3_1      1.0
    f_1_3_4_1       DEM_1           1.0
    f_1_3_5_1       CAP_3_5         1.0
    f_1_3_5_1       CONS_1_3_1      1.0
    f_1_3_5_1       CONS_1_5_2      -1.0
    f_1_1_4_2       CAP_1_4         1.0
    f_1_1_4_2       CONS_1_1_2      1.0
    f_1_1_4_2       DEM_1           1.0
    f_1_2_4_2       CAP_2_4         1.0
    f_1_2_4_2       CONS_1_2_2      1.0
    f_1_2_4_2       DEM_1           1.0
    f_1_3_4_2       CAP_3_4         1.0
    f_1_3_4_2       CONS_1_3_2      1.0
    f_1_3_4_2       DEM_1           1.0
    f_1_5_4_2       CAP_4_5         1.0
    f_1_5_4_2       CONS_1_5_2      1.0
    f_1_5_4_2       DEM_1           1.0
    f_2_0_1_0       CAP_0_1         1.0
    f_2_0_1_0       SUP_2           1.0
    f_2_0_1_0       CONS_2_1_1      -1.0
    f_2_0_3_0       CAP_0_3         1.0
    f_2_0_3_0       SUP_2           1.0
    f_2_0_3_0       CONS_2_3_1      -1.0
    f_2_0_1_1       CAP_0_1         1.0
    f_2_0_1_1       CONS_2_0_1      1.0
    f_2_0_1_1       CONS_2_1_2      -1.0
    f_2_0_3_1       CAP_0_3         1.0
    f_2_0_3_1       CONS_2_0_1      1.0
    f_2_0_3_1       CONS_2_3_2      -1.0
    f_2_1_2_1       CAP_1_2         1.0
    f_2_1_2_1       CONS_2_1_1      1.0
    f_2_1_2_1       DEM_2           1.0
    f_2_1_3_1       CAP_1_3         1.0
    f_2_1_3_1       CONS_2_1_1      1.0
    f_2_1_3_1       CONS_2_3_2      -1.0
    f_2_3_1_1       CAP_1_3         1.0
    f_2_3_1_1       CONS_2_3_1      1.0
    f_2_3_1_1       CONS_2_1_2      -1.0
    f_2_1_4_1       CAP_1_4         1.0
    f_2_1_4_1       CONS_2_1_1      1.0
    f_2_1_4_1       CONS_2_4_2      -1.0
    f_2_1_5_1       CAP_1_5         1.0
    f_2_1_5_1       CONS_2_1_1      1.0
    f_2_1_5_1       CONS_2_5_2      -1.0
    f_2_3_2_1       CAP_2_3         1.0
    f_2_3_2_1       CONS_2_3_1      1.0
    f_2_3_2_1       DEM_2           1.0
    f_2_3_4_1       CAP_3_4         1.0
    f_2_3_4_1       CONS_2_3_1      1.0
    f_2_3_4_1       CONS_2_4_2      -1.0
    f_2_3_5_1       CAP_3_5         1.0
    f_2_3_5_1       CONS_2_3_1      1.0
    f_2_3_5_1       CONS_2_5_2      -1.0
    f_2_1_2_2       CAP_1_2         1.0
    f_2_1_2_2       CONS_2_1_2      1.0
    f_2_1_2_2       DEM_2           1.0
    f_2_3_2_2       CAP_2_3         1.0
    f_2_3_2_2       CONS_2_3_2      1.0
    f_2_3_2_2       DEM_2           1.0
    f_2_4_2_2       CAP_2_4         1.0
    f_2_4_2_2       CONS_2_4_2      1.0
    f_2_4_2_2       DEM_2           1.0
    f_2_5_2_2       CAP_2_5         1.0
    f_2_5_2_2       CONS_2_5_2      1.0
    f_2_5_2_2       DEM_2           1.0
RHS
    RHS           SUP_0           1.0
    RHS           DEM_0           1.0
    RHS           SUP_1           1.0
    RHS           DEM_1           1.0
    RHS           SUP_2           3.0
    RHS           DEM_2           3.0
BOUNDS
 BV BOUND         y_0_1
 BV BOUND         y_0_3
 BV BOUND         y_1_2
 BV BOUND         y_1_3
 BV BOUND         y_1_4
 BV BOUND         y_1_5
 BV BOUND         y_2_3
 BV BOUND         y_2_4
 BV BOUND         y_2_5
 BV BOUND         y_3_4
 BV BOUND         y_3_5
 BV BOUND         y_4_5
 UP BOUND         f_0_0_1_0       1.0
 UP BOUND         f_0_0_3_0       1.0
 UP BOUND         f_0_0_1_1       1.0
 UP BOUND         f_0_0_3_1       1.0
 UP BOUND         f_0_1_2_1       1.0
 UP BOUND         f_0_1_3_1       1.0
 UP BOUND         f_0_3_1_1       1.0
 UP BOUND         f_0_1_4_1       1.0
 UP BOUND         f_0_1_5_1       1.0
 UP BOUND         f_0_3_2_1       1.0
 UP BOUND         f_0_3_4_1       1.0
 UP BOUND         f_0_3_5_1       1.0
 UP BOUND         f_0_1_2_2       1.0
 UP BOUND         f_0_3_2_2       1.0
 UP BOUND         f_0_4_2_2       1.0
 UP BOUND         f_0_5_2_2       1.0
 UP BOUND         f_1_0_1_0       1.0
 UP BOUND         f_1_0_3_0       1.0
 UP BOUND         f_1_0_1_1       1.0
 UP BOUND         f_1_0_3_1       1.0
 UP BOUND         f_1_1_2_1       1.0
 UP BOUND         f_1_1_3_1       1.0
 UP BOUND         f_1_3_1_1       1.0
 UP BOUND         f_1_1_4_1       1.0
 UP BOUND         f_1_1_5_1       1.0
 UP BOUND         f_1_3_2_1       1.0
 UP BOUND         f_1_3_4_1       1.0
 UP BOUND         f_1_3_5_1       1.0
 UP BOUND         f_1_1_4_2       1.0
 UP BOUND         f_1_2_4_2       1.0
 UP BOUND         f_1_3_4_2       1.0
 UP BOUND         f_1_5_4_2       1.0
 UP BOUND         f_2_0_1_0       3.0
 UP BOUND         f_2_0_3_0       3.0
 UP BOUND         f_2_0_1_1       3.0
 UP BOUND         f_2_0_3_1       3.0
 UP BOUND         f_2_1_2_1       3.0
 UP BOUND         f_2_1_3_1       3.0
 UP BOUND         f_2_3_1_1       3.0
 UP BOUND         f_2_1_4_1       3.0
 UP BOUND         f_2_1_5_1       3.0
 UP BOUND         f_2_3_2_1       3.0
 UP BOUND         f_2_3_4_1       3.0
 UP BOUND         f_2_3_5_1       3.0
 UP BOUND         f_2_1_2_2       3.0
 UP BOUND         f_2_3_2_2       3.0
 UP BOUND         f_2_4_2_2       3.0
 UP BOUND         f_2_5_2_2       3.0
ENDATA
