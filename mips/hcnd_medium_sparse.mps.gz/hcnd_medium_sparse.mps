NAME          hcnd_medium_sparse
ROWS
 N  OBJ
 L  CAP_0_4
 L  CAP_0_5
 L  CAP_1_4
 L  CAP_1_6
 L  CAP_1_7
 L  CAP_3_4
 L  CAP_3_8
 L  CAP_4_8
 L  CAP_5_6
 L  CAP_5_7
 L  CAP_6_7
 L  CAP_7_8
 L  CAP_0_2
 E  SUP_0
 E  DEM_0
 E  CONS_0_4_1
 E  CONS_0_5_1
 E  CONS_0_2_1
 E  CONS_0_0_1
 E  CONS_0_4_2
 E  CONS_0_5_2
 E  CONS_0_3_2
 E  CONS_0_8_2
 E  CONS_0_6_2
 E  CONS_0_7_2
 E  CONS_0_2_2
 E  SUP_1
 E  DEM_1
 E  CONS_1_3_1
 E  CONS_1_4_1
 E  CONS_1_7_1
 E  CONS_1_1_2
 E  CONS_1_4_2
 E  CONS_1_3_2
 E  CONS_1_8_1
 E  CONS_1_5_2
 E  CONS_1_6_2
 E  CONS_1_7_2
 E  SUP_2
 E  DEM_2
 E  CONS_2_1_1
 E  CONS_2_5_1
 E  CONS_2_7_1
 E  CONS_2_0_2
 E  CONS_2_6_1
 E  CONS_2_1_2
 E  CONS_2_7_2
 E  CONS_2_5_2
 E  CONS_2_8_2
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_4           OBJ           359
    y_0_4           CAP_0_4         -4.0
    y_0_5           OBJ           547
    y_0_5           CAP_0_5         -8.0
    y_1_4           OBJ           455
    y_1_4           CAP_1_4         -11.0
    y_1_6           OBJ           445
    y_1_6           CAP_1_6         -4.0
    y_1_7           OBJ           438
    y_1_7           CAP_1_7         -10.0
    y_3_4           OBJ           588
    y_3_4           CAP_3_4         -4.0
    y_3_8           OBJ           757
    y_3_8           CAP_3_8         -12.0
    y_4_8           OBJ           883
    y_4_8           CAP_4_8         -8.0
    y_5_6           OBJ           118
    y_5_6           CAP_5_6         -11.0
    y_5_7           OBJ           565
    y_5_7           CAP_5_7         -10.0
    y_6_7           OBJ           364
    y_6_7           CAP_6_7         -10.0
    y_7_8           OBJ           767
    y_7_8           CAP_7_8         -4.0
    y_0_2           OBJ           571
    y_0_2           CAP_0_2         -9.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_0_4_0       CAP_0_4         1.0
    f_0_0_4_0       SUP_0           1.0
    f_0_0_4_0       CONS_0_4_1      -1.0
    f_0_0_5_0       CAP_0_5         1.0
    f_0_0_5_0       SUP_0           1.0
    f_0_0_5_0       CONS_0_5_1      -1.0
    f_0_0_2_0       CAP_0_2         1.0
    f_0_0_2_0       SUP_0           1.0
    f_0_0_2_0       CONS_0_2_1      -1.0
    f_0_0_4_1       CAP_0_4         1.0
    f_0_0_4_1       CONS_0_0_1      1.0
    f_0_0_4_1       CONS_0_4_2      -1.0
    f_0_0_5_1       CAP_0_5         1.0
    f_0_0_5_1       CONS_0_0_1      1.0
    f_0_0_5_1       CONS_0_5_2      -1.0
    f_0_4_1_1       CAP_1_4         1.0
    f_0_4_1_1       CONS_0_4_1      1.0
    f_0_4_1_1       DEM_0           1.0
    f_0_4_3_1       CAP_3_4         1.0
    f_0_4_3_1       CONS_0_4_1      1.0
    f_0_4_3_1       CONS_0_3_2      -1.0
    f_0_4_8_1       CAP_4_8         1.0
    f_0_4_8_1       CONS_0_4_1      1.0
    f_0_4_8_1       CONS_0_8_2      -1.0
    f_0_5_6_1       CAP_5_6         1.0
    f_0_5_6_1       CONS_0_5_1      1.0
    f_0_5_6_1       CONS_0_6_2      -1.0
    f_0_5_7_1       CAP_5_7         1.0
    f_0_5_7_1       CONS_0_5_1      1.0
    f_0_5_7_1       CONS_0_7_2      -1.0
    f_0_0_2_1       CAP_0_2         1.0
    f_0_0_2_1       CONS_0_0_1      1.0
    f_0_0_2_1       CONS_0_2_2      -1.0
    f_0_4_1_2       CAP_1_4         1.0
    f_0_4_1_2       CONS_0_4_2      1.0
    f_0_4_1_2       DEM_0           1.0
    f_0_6_1_2       CAP_1_6         1.0
    f_0_6_1_2       CONS_0_6_2      1.0
    f_0_6_1_2       DEM_0           1.0
    f_0_7_1_2       CAP_1_7         1.0
    f_0_7_1_2       CONS_0_7_2      1.0
    f_0_7_1_2       DEM_0           1.0
    f_1_8_3_0       CAP_3_8         1.0
    f_1_8_3_0       SUP_1           1.0
    f_1_8_3_0       CONS_1_3_1      -1.0
    f_1_8_4_0       CAP_4_8         1.0
    f_1_8_4_0       SUP_1           1.0
    f_1_8_4_0       CONS_1_4_1      -1.0
    f_1_8_7_0       CAP_7_8         1.0
    f_1_8_7_0       SUP_1           1.0
    f_1_8_7_0       CONS_1_7_1      -1.0
    f_1_4_0_1       CAP_0_4         1.0
    f_1_4_0_1       CONS_1_4_1      1.0
    f_1_4_0_1       DEM_1           1.0
    f_1_4_1_1       CAP_1_4         1.0
    f_1_4_1_1       CONS_1_4_1      1.0
    f_1_4_1_1       CONS_1_1_2      -1.0
    f_1_7_1_1       CAP_1_7         1.0
    f_1_7_1_1       CONS_1_7_1      1.0
    f_1_7_1_1       CONS_1_1_2      -1.0
    f_1_3_4_1       CAP_3_4         1.0
    f_1_3_4_1       CONS_1_3_1      1.0
    f_1_3_4_1       CONS_1_4_2      -1.0
    f_1_4_3_1       CAP_3_4         1.0
    f_1_4_3_1       CONS_1_4_1      1.0
    f_1_4_3_1       CONS_1_3_2      -1.0
    f_1_8_3_1       CAP_3_8         1.0
    f_1_8_3_1       CONS_1_8_1      1.0
    f_1_8_3_1       CONS_1_3_2      -1.0
    f_1_8_4_1       CAP_4_8         1.0
    f_1_8_4_1       CONS_1_8_1      1.0
    f_1_8_4_1       CONS_1_4_2      -1.0
    f_1_7_5_1       CAP_5_7         1.0
    f_1_7_5_1       CONS_1_7_1      1.0
    f_1_7_5_1       CONS_1_5_2      -1.0
    f_1_7_6_1       CAP_6_7         1.0
    f_1_7_6_1       CONS_1_7_1      1.0
    f_1_7_6_1       CONS_1_6_2      -1.0
    f_1_8_7_1       CAP_7_8         1.0
    f_1_8_7_1       CONS_1_8_1      1.0
    f_1_8_7_1       CONS_1_7_2      -1.0
    f_1_4_0_2       CAP_0_4         1.0
    f_1_4_0_2       CONS_1_4_2      1.0
    f_1_4_0_2       DEM_1           1.0
    f_1_5_0_2       CAP_0_5         1.0
    f_1_5_0_2       CONS_1_5_2      1.0
    f_1_5_0_2       DEM_1           1.0
    f_2_6_1_0       CAP_1_6         1.0
    f_2_6_1_0       SUP_2           1.0
    f_2_6_1_0       CONS_2_1_1      -1.0
    f_2_6_5_0       CAP_5_6         1.0
    f_2_6_5_0       SUP_2           1.0
    f_2_6_5_0       CONS_2_5_1      -1.0
    f_2_6_7_0       CAP_6_7         1.0
    f_2_6_7_0       SUP_2           1.0
    f_2_6_7_0       CONS_2_7_1      -1.0
    f_2_5_0_1       CAP_0_5         1.0
    f_2_5_0_1       CONS_2_5_1      1.0
    f_2_5_0_1       CONS_2_0_2      -1.0
    f_2_1_4_1       CAP_1_4         1.0
    f_2_1_4_1       CONS_2_1_1      1.0
    f_2_1_4_1       DEM_2           1.0
    f_2_6_1_1       CAP_1_6         1.0
    f_2_6_1_1       CONS_2_6_1      1.0
    f_2_6_1_1       CONS_2_1_2      -1.0
    f_2_1_7_1       CAP_1_7         1.0
    f_2_1_7_1       CONS_2_1_1      1.0
    f_2_1_7_1       CONS_2_7_2      -1.0
    f_2_7_1_1       CAP_1_7         1.0
    f_2_7_1_1       CONS_2_7_1      1.0
    f_2_7_1_1       CONS_2_1_2      -1.0
    f_2_6_5_1       CAP_5_6         1.0
    f_2_6_5_1       CONS_2_6_1      1.0
    f_2_6_5_1       CONS_2_5_2      -1.0
    f_2_5_7_1       CAP_5_7         1.0
    f_2_5_7_1       CONS_2_5_1      1.0
    f_2_5_7_1       CONS_2_7_2      -1.0
    f_2_7_5_1       CAP_5_7         1.0
    f_2_7_5_1       CONS_2_7_1      1.0
    f_2_7_5_1       CONS_2_5_2      -1.0
    f_2_6_7_1       CAP_6_7         1.0
    f_2_6_7_1       CONS_2_6_1      1.0
    f_2_6_7_1       CONS_2_7_2      -1.0
    f_2_7_8_1       CAP_7_8         1.0
    f_2_7_8_1       CONS_2_7_1      1.0
    f_2_7_8_1       CONS_2_8_2      -1.0
    f_2_0_4_2       CAP_0_4         1.0
    f_2_0_4_2       CONS_2_0_2      1.0
    f_2_0_4_2       DEM_2           1.0
    f_2_1_4_2       CAP_1_4         1.0
    f_2_1_4_2       CONS_2_1_2      1.0
    f_2_1_4_2       DEM_2           1.0
    f_2_8_4_2       CAP_4_8         1.0
    f_2_8_4_2       CONS_2_8_2      1.0
    f_2_8_4_2       DEM_2           1.0
RHS
    RHS           SUP_0           1.0
    RHS           DEM_0           1.0
    RHS           SUP_1           2.0
    RHS           DEM_1           2.0
    RHS           SUP_2           3.0
    RHS           DEM_2           3.0
BOUNDS
 BV BOUND         y_0_4
 BV BOUND         y_0_5
 BV BOUND         y_1_4
 BV BOUND         y_1_6
 BV BOUND         y_1_7
 BV BOUND         y_3_4
 BV BOUND         y_3_8
 BV BOUND         y_4_8
 BV BOUND         y_5_6
 BV BOUND         y_5_7
 BV BOUND         y_6_7
 BV BOUND         y_7_8
 BV BOUND         y_0_2
 UP BOUND         f_0_0_4_0       1.0
 UP BOUND         f_0_0_5_0       1.0
 UP BOUND         f_0_0_2_0       1.0
 UP BOUND         f_0_0_4_1       1.0
 UP BOUND         f_0_0_5_1       1.0
 UP BOUND         f_0_4_1_1       1.0
 UP BOUND         f_0_4_3_1       1.0
 UP BOUND         f_0_4_8_1       1.0
 UP BOUND         f_0_5_6_1       1.0
 UP BOUND         f_0_5_7_1       1.0
 UP BOUND         f_0_0_2_1       1.0
 UP BOUND         f_0_4_1_2       1.0
 UP BOUND         f_0_6_1_2       1.0
 UP BOUND         f_0_7_1_2       1.0
 UP BOUND         f_1_8_3_0       2.0
 UP BOUND         f_1_8_4_0       2.0
 UP BOUND         f_1_8_7_0       2.0
 UP BOUND         f_1_4_0_1       2.0
 UP BOUND         f_1_4_1_1       2.0
 UP BOUND         f_1_7_1_1       2.0
 UP BOUND         f_1_3_4_1       2.0
 UP BOUND         f_1_4_3_1       2.0
 UP BOUND         f_1_8_3_1       2.0
 UP BOUND         f_1_8_4_1       2.0
 UP BOUND         f_1_7_5_1       2.0
 UP BOUND         f_1_7_6_1       2.0
 UP BOUND         f_1_8_7_1       2.0
 UP BOUND         f_1_4_0_2       2.0
 UP BOUND         f_1_5_0_2       2.0
 UP BOUND         f_2_6_1_0       3.0
 UP BOUND         f_2_6_5_0       3.0
 UP BOUND         f_2_6_7_0       3.0
 UP BOUND         f_2_5_0_1       3.0
 UP BOUND         f_2_1_4_1       3.0
 UP BOUND         f_2_6_1_1       3.0
 UP BOUND         f_2_1_7_1       3.0
 UP BOUND         f_2_7_1_1       3.0
 UP BOUND         f_2_6_5_1       3.0
 UP BOUND         f_2_5_7_1       3.0
 UP BOUND         f_2_7_5_1       3.0
 UP BOUND         f_2_6_7_1       3.0
 UP BOUND         f_2_7_8_1       3.0
 UP BOUND         f_2_0_4_2       3.0
 UP BOUND         f_2_1_4_2       3.0
 UP BOUND         f_2_8_4_2       3.0
ENDATA
