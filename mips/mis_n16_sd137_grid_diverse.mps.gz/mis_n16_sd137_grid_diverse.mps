NAME          MIS
ROWS
 N  OBJ
 L  EDGE_3_7
 L  EDGE_12_13
 L  EDGE_8_9
 L  EDGE_8_12
 L  EDGE_13_14
 L  EDGE_4_5
 L  EDGE_5_6
 L  EDGE_4_8
 L  EDGE_5_9
 L  EDGE_14_15
 L  EDGE_0_1
 L  EDGE_9_10
 L  EDGE_1_2
 L  EDGE_0_4
 L  EDGE_9_13
 L  EDGE_10_11
 L  EDGE_1_5
 L  EDGE_10_14
 L  EDGE_6_7
 L  EDGE_6_10
 L  EDGE_2_3
 L  EDGE_2_6
 L  EDGE_11_15
 L  EDGE_7_11
COLUMNS
    x_0         OBJ       -3
    x_0         EDGE_0_1  1.0
    x_0         EDGE_0_4  1.0
    x_1         OBJ       -41
    x_1         EDGE_0_1  1.0
    x_1         EDGE_1_2  1.0
    x_1         EDGE_1_5  1.0
    x_2         OBJ       -132
    x_2         EDGE_1_2  1.0
    x_2         EDGE_2_3  1.0
    x_2         EDGE_2_6  1.0
    x_3         OBJ       -11
    x_3         EDGE_3_7  1.0
    x_3         EDGE_2_3  1.0
    x_4         OBJ       -42
    x_4         EDGE_4_5  1.0
    x_4         EDGE_4_8  1.0
    x_4         EDGE_0_4  1.0
    x_5         OBJ       -109
    x_5         EDGE_4_5  1.0
    x_5         EDGE_5_6  1.0
    x_5         EDGE_5_9  1.0
    x_5         EDGE_1_5  1.0
    x_6         OBJ       -16
    x_6         EDGE_5_6  1.0
    x_6         EDGE_6_7  1.0
    x_6         EDGE_6_10  1.0
    x_6         EDGE_2_6  1.0
    x_7         OBJ       -52
    x_7         EDGE_3_7  1.0
    x_7         EDGE_6_7  1.0
    x_7         EDGE_7_11  1.0
    x_8         OBJ       -81
    x_8         EDGE_8_9  1.0
    x_8         EDGE_8_12  1.0
    x_8         EDGE_4_8  1.0
    x_9         OBJ       -13
    x_9         EDGE_8_9  1.0
    x_9         EDGE_5_9  1.0
    x_9         EDGE_9_10  1.0
    x_9         EDGE_9_13  1.0
    x_10        OBJ       -62
    x_10        EDGE_9_10  1.0
    x_10        EDGE_10_11  1.0
    x_10        EDGE_10_14  1.0
    x_10        EDGE_6_10  1.0
    x_11        OBJ       -121
    x_11        EDGE_10_11  1.0
    x_11        EDGE_11_15  1.0
    x_11        EDGE_7_11  1.0
    x_12        OBJ       -13
    x_12        EDGE_12_13  1.0
    x_12        EDGE_8_12  1.0
    x_13        OBJ       -63
    x_13        EDGE_12_13  1.0
    x_13        EDGE_13_14  1.0
    x_13        EDGE_9_13  1.0
    x_14        OBJ       -140
    x_14        EDGE_13_14  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_10_14  1.0
    x_15        OBJ       -5
    x_15        EDGE_14_15  1.0
    x_15        EDGE_11_15  1.0
RHS
    RHS1      EDGE_3_7  1.0
    RHS1      EDGE_12_13  1.0
    RHS1      EDGE_8_9  1.0
    RHS1      EDGE_8_12  1.0
    RHS1      EDGE_13_14  1.0
    RHS1      EDGE_4_5  1.0
    RHS1      EDGE_5_6  1.0
    RHS1      EDGE_4_8  1.0
    RHS1      EDGE_5_9  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_0_1  1.0
    RHS1      EDGE_9_10  1.0
    RHS1      EDGE_1_2  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_9_13  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_10_14  1.0
    RHS1      EDGE_6_7  1.0
    RHS1      EDGE_6_10  1.0
    RHS1      EDGE_2_3  1.0
    RHS1      EDGE_2_6  1.0
    RHS1      EDGE_11_15  1.0
    RHS1      EDGE_7_11  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
ENDATA
