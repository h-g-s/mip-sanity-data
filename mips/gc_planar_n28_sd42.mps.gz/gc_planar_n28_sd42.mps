NAME          gc_planar_n28_sd42
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 E  ASSIGN_11
 E  ASSIGN_12
 E  ASSIGN_13
 E  ASSIGN_14
 E  ASSIGN_15
 E  ASSIGN_16
 E  ASSIGN_17
 E  ASSIGN_18
 E  ASSIGN_19
 E  ASSIGN_20
 E  ASSIGN_21
 E  ASSIGN_22
 E  ASSIGN_23
 E  ASSIGN_24
 E  ASSIGN_25
 E  ASSIGN_26
 E  ASSIGN_27
 L  LINK_1_0
 L  LINK_2_0
 L  LINK_2_1
 L  LINK_3_0
 L  LINK_3_1
 L  LINK_3_2
 L  LINK_4_0
 L  LINK_4_1
 L  LINK_4_2
 L  LINK_4_3
 L  LINK_5_0
 L  LINK_5_1
 L  LINK_5_2
 L  LINK_5_3
 L  LINK_5_4
 L  LINK_6_0
 L  LINK_6_1
 L  LINK_6_2
 L  LINK_6_3
 L  LINK_6_4
 L  LINK_6_5
 L  LINK_7_0
 L  LINK_7_1
 L  LINK_7_2
 L  LINK_7_3
 L  LINK_7_4
 L  LINK_7_5
 L  LINK_7_6
 L  LINK_8_0
 L  LINK_8_1
 L  LINK_8_2
 L  LINK_8_3
 L  LINK_8_4
 L  LINK_8_5
 L  LINK_8_6
 L  LINK_8_7
 L  LINK_9_0
 L  LINK_9_1
 L  LINK_9_2
 L  LINK_9_3
 L  LINK_9_4
 L  LINK_9_5
 L  LINK_9_6
 L  LINK_9_7
 L  LINK_9_8
 L  LINK_10_0
 L  LINK_10_1
 L  LINK_10_2
 L  LINK_10_3
 L  LINK_10_4
 L  LINK_10_5
 L  LINK_10_6
 L  LINK_10_7
 L  LINK_10_8
 L  LINK_10_9
 L  LINK_11_0
 L  LINK_11_1
 L  LINK_11_2
 L  LINK_11_3
 L  LINK_11_4
 L  LINK_11_5
 L  LINK_11_6
 L  LINK_11_7
 L  LINK_11_8
 L  LINK_11_9
 L  LINK_11_10
 L  LINK_12_0
 L  LINK_12_1
 L  LINK_12_2
 L  LINK_12_3
 L  LINK_12_4
 L  LINK_12_5
 L  LINK_12_6
 L  LINK_12_7
 L  LINK_12_8
 L  LINK_12_9
 L  LINK_12_10
 L  LINK_12_11
 L  LINK_13_0
 L  LINK_13_1
 L  LINK_13_2
 L  LINK_13_3
 L  LINK_13_4
 L  LINK_13_5
 L  LINK_13_6
 L  LINK_13_7
 L  LINK_13_8
 L  LINK_13_9
 L  LINK_13_10
 L  LINK_13_11
 L  LINK_13_12
 L  LINK_14_0
 L  LINK_14_1
 L  LINK_14_2
 L  LINK_14_3
 L  LINK_14_4
 L  LINK_14_5
 L  LINK_14_6
 L  LINK_14_7
 L  LINK_14_8
 L  LINK_14_9
 L  LINK_14_10
 L  LINK_14_11
 L  LINK_14_12
 L  LINK_14_13
 L  LINK_15_0
 L  LINK_15_1
 L  LINK_15_2
 L  LINK_15_3
 L  LINK_15_4
 L  LINK_15_5
 L  LINK_15_6
 L  LINK_15_7
 L  LINK_15_8
 L  LINK_15_9
 L  LINK_15_10
 L  LINK_15_11
 L  LINK_15_12
 L  LINK_15_13
 L  LINK_15_14
 L  LINK_16_0
 L  LINK_16_1
 L  LINK_16_2
 L  LINK_16_3
 L  LINK_16_4
 L  LINK_16_5
 L  LINK_16_6
 L  LINK_16_7
 L  LINK_16_8
 L  LINK_16_9
 L  LINK_16_10
 L  LINK_16_11
 L  LINK_16_12
 L  LINK_16_13
 L  LINK_16_14
 L  LINK_16_15
 L  LINK_17_0
 L  LINK_17_1
 L  LINK_17_2
 L  LINK_17_3
 L  LINK_17_4
 L  LINK_17_5
 L  LINK_17_6
 L  LINK_17_7
 L  LINK_17_8
 L  LINK_17_9
 L  LINK_17_10
 L  LINK_17_11
 L  LINK_17_12
 L  LINK_17_13
 L  LINK_17_14
 L  LINK_17_15
 L  LINK_17_16
 L  LINK_18_0
 L  LINK_18_1
 L  LINK_18_2
 L  LINK_18_3
 L  LINK_18_4
 L  LINK_18_5
 L  LINK_18_6
 L  LINK_18_7
 L  LINK_18_8
 L  LINK_18_9
 L  LINK_18_10
 L  LINK_18_11
 L  LINK_18_12
 L  LINK_18_13
 L  LINK_18_14
 L  LINK_18_15
 L  LINK_18_16
 L  LINK_18_17
 L  LINK_19_0
 L  LINK_19_1
 L  LINK_19_2
 L  LINK_19_3
 L  LINK_19_4
 L  LINK_19_5
 L  LINK_19_6
 L  LINK_19_7
 L  LINK_19_8
 L  LINK_19_9
 L  LINK_19_10
 L  LINK_19_11
 L  LINK_19_12
 L  LINK_19_13
 L  LINK_19_14
 L  LINK_19_15
 L  LINK_19_16
 L  LINK_19_17
 L  LINK_19_18
 L  LINK_20_0
 L  LINK_20_1
 L  LINK_20_2
 L  LINK_20_3
 L  LINK_20_4
 L  LINK_20_5
 L  LINK_20_6
 L  LINK_20_7
 L  LINK_20_8
 L  LINK_20_9
 L  LINK_20_10
 L  LINK_20_11
 L  LINK_20_12
 L  LINK_20_13
 L  LINK_20_14
 L  LINK_20_15
 L  LINK_20_16
 L  LINK_20_17
 L  LINK_20_18
 L  LINK_20_19
 L  LINK_21_0
 L  LINK_21_1
 L  LINK_21_2
 L  LINK_21_3
 L  LINK_21_4
 L  LINK_21_5
 L  LINK_21_6
 L  LINK_21_7
 L  LINK_21_8
 L  LINK_21_9
 L  LINK_21_10
 L  LINK_21_11
 L  LINK_21_12
 L  LINK_21_13
 L  LINK_21_14
 L  LINK_21_15
 L  LINK_21_16
 L  LINK_21_17
 L  LINK_21_18
 L  LINK_21_19
 L  LINK_21_20
 L  LINK_22_0
 L  LINK_22_1
 L  LINK_22_2
 L  LINK_22_3
 L  LINK_22_4
 L  LINK_22_5
 L  LINK_22_6
 L  LINK_22_7
 L  LINK_22_8
 L  LINK_22_9
 L  LINK_22_10
 L  LINK_22_11
 L  LINK_22_12
 L  LINK_22_13
 L  LINK_22_14
 L  LINK_22_15
 L  LINK_22_16
 L  LINK_22_17
 L  LINK_22_18
 L  LINK_22_19
 L  LINK_22_20
 L  LINK_22_21
 L  LINK_23_0
 L  LINK_23_1
 L  LINK_23_2
 L  LINK_23_3
 L  LINK_23_4
 L  LINK_23_5
 L  LINK_23_6
 L  LINK_23_7
 L  LINK_23_8
 L  LINK_23_9
 L  LINK_23_10
 L  LINK_23_11
 L  LINK_23_12
 L  LINK_23_13
 L  LINK_23_14
 L  LINK_23_15
 L  LINK_23_16
 L  LINK_23_17
 L  LINK_23_18
 L  LINK_23_19
 L  LINK_23_20
 L  LINK_23_21
 L  LINK_23_22
 L  LINK_24_0
 L  LINK_24_1
 L  LINK_24_2
 L  LINK_24_3
 L  LINK_24_4
 L  LINK_24_5
 L  LINK_24_6
 L  LINK_24_7
 L  LINK_24_8
 L  LINK_24_9
 L  LINK_24_10
 L  LINK_24_11
 L  LINK_24_12
 L  LINK_24_13
 L  LINK_24_14
 L  LINK_24_15
 L  LINK_24_16
 L  LINK_24_17
 L  LINK_24_18
 L  LINK_24_19
 L  LINK_24_20
 L  LINK_24_21
 L  LINK_24_22
 L  LINK_24_23
 L  LINK_25_0
 L  LINK_25_1
 L  LINK_25_2
 L  LINK_25_3
 L  LINK_25_4
 L  LINK_25_5
 L  LINK_25_6
 L  LINK_25_7
 L  LINK_25_8
 L  LINK_25_9
 L  LINK_25_10
 L  LINK_25_11
 L  LINK_25_12
 L  LINK_25_13
 L  LINK_25_14
 L  LINK_25_15
 L  LINK_25_16
 L  LINK_25_17
 L  LINK_25_18
 L  LINK_25_19
 L  LINK_25_20
 L  LINK_25_21
 L  LINK_25_22
 L  LINK_25_23
 L  LINK_25_24
 L  LINK_26_0
 L  LINK_26_1
 L  LINK_26_2
 L  LINK_26_3
 L  LINK_26_4
 L  LINK_26_5
 L  LINK_26_6
 L  LINK_26_7
 L  LINK_26_8
 L  LINK_26_9
 L  LINK_26_10
 L  LINK_26_11
 L  LINK_26_12
 L  LINK_26_13
 L  LINK_26_14
 L  LINK_26_15
 L  LINK_26_16
 L  LINK_26_17
 L  LINK_26_18
 L  LINK_26_19
 L  LINK_26_20
 L  LINK_26_21
 L  LINK_26_22
 L  LINK_26_23
 L  LINK_26_24
 L  LINK_26_25
 L  LINK_27_0
 L  LINK_27_1
 L  LINK_27_2
 L  LINK_27_3
 L  LINK_27_4
 L  LINK_27_5
 L  LINK_27_6
 L  LINK_27_7
 L  LINK_27_8
 L  LINK_27_9
 L  LINK_27_10
 L  LINK_27_11
 L  LINK_27_12
 L  LINK_27_13
 L  LINK_27_14
 L  LINK_27_15
 L  LINK_27_16
 L  LINK_27_17
 L  LINK_27_18
 L  LINK_27_19
 L  LINK_27_20
 L  LINK_27_21
 L  LINK_27_22
 L  LINK_27_23
 L  LINK_27_24
 L  LINK_27_25
 L  LINK_27_26
 L  EDGE_0_1_0
 L  EDGE_0_8_0
 L  EDGE_0_9_0
 L  EDGE_0_11_0
 L  EDGE_0_12_0
 L  EDGE_0_13_0
 L  EDGE_1_3_0
 L  EDGE_1_3_1
 L  EDGE_1_7_0
 L  EDGE_1_7_1
 L  EDGE_1_8_0
 L  EDGE_1_8_1
 L  EDGE_1_10_0
 L  EDGE_1_10_1
 L  EDGE_2_3_0
 L  EDGE_2_3_1
 L  EDGE_2_3_2
 L  EDGE_2_4_0
 L  EDGE_2_4_1
 L  EDGE_2_4_2
 L  EDGE_2_5_0
 L  EDGE_2_5_1
 L  EDGE_2_5_2
 L  EDGE_2_10_0
 L  EDGE_2_10_1
 L  EDGE_2_10_2
 L  EDGE_2_18_0
 L  EDGE_2_18_1
 L  EDGE_2_18_2
 L  EDGE_3_5_0
 L  EDGE_3_5_1
 L  EDGE_3_5_2
 L  EDGE_3_5_3
 L  EDGE_3_6_0
 L  EDGE_3_6_1
 L  EDGE_3_6_2
 L  EDGE_3_6_3
 L  EDGE_3_12_0
 L  EDGE_3_12_1
 L  EDGE_3_12_2
 L  EDGE_3_12_3
 L  EDGE_4_5_0
 L  EDGE_4_5_1
 L  EDGE_4_5_2
 L  EDGE_4_5_3
 L  EDGE_4_5_4
 L  EDGE_4_14_0
 L  EDGE_4_14_1
 L  EDGE_4_14_2
 L  EDGE_4_14_3
 L  EDGE_4_14_4
 L  EDGE_4_15_0
 L  EDGE_4_15_1
 L  EDGE_4_15_2
 L  EDGE_4_15_3
 L  EDGE_4_15_4
 L  EDGE_4_16_0
 L  EDGE_4_16_1
 L  EDGE_4_16_2
 L  EDGE_4_16_3
 L  EDGE_4_16_4
 L  EDGE_5_6_0
 L  EDGE_5_6_1
 L  EDGE_5_6_2
 L  EDGE_5_6_3
 L  EDGE_5_6_4
 L  EDGE_5_6_5
 L  EDGE_5_16_0
 L  EDGE_5_16_1
 L  EDGE_5_16_2
 L  EDGE_5_16_3
 L  EDGE_5_16_4
 L  EDGE_5_16_5
 L  EDGE_6_12_0
 L  EDGE_6_12_1
 L  EDGE_6_12_2
 L  EDGE_6_12_3
 L  EDGE_6_12_4
 L  EDGE_6_12_5
 L  EDGE_6_12_6
 L  EDGE_6_19_0
 L  EDGE_6_19_1
 L  EDGE_6_19_2
 L  EDGE_6_19_3
 L  EDGE_6_19_4
 L  EDGE_6_19_5
 L  EDGE_6_19_6
 L  EDGE_6_20_0
 L  EDGE_6_20_1
 L  EDGE_6_20_2
 L  EDGE_6_20_3
 L  EDGE_6_20_4
 L  EDGE_6_20_5
 L  EDGE_6_20_6
 L  EDGE_7_8_0
 L  EDGE_7_8_1
 L  EDGE_7_8_2
 L  EDGE_7_8_3
 L  EDGE_7_8_4
 L  EDGE_7_8_5
 L  EDGE_7_8_6
 L  EDGE_7_8_7
 L  EDGE_7_10_0
 L  EDGE_7_10_1
 L  EDGE_7_10_2
 L  EDGE_7_10_3
 L  EDGE_7_10_4
 L  EDGE_7_10_5
 L  EDGE_7_10_6
 L  EDGE_7_10_7
 L  EDGE_7_21_0
 L  EDGE_7_21_1
 L  EDGE_7_21_2
 L  EDGE_7_21_3
 L  EDGE_7_21_4
 L  EDGE_7_21_5
 L  EDGE_7_21_6
 L  EDGE_7_21_7
 L  EDGE_8_9_0
 L  EDGE_8_9_1
 L  EDGE_8_9_2
 L  EDGE_8_9_3
 L  EDGE_8_9_4
 L  EDGE_8_9_5
 L  EDGE_8_9_6
 L  EDGE_8_9_7
 L  EDGE_8_9_8
 L  EDGE_9_11_0
 L  EDGE_9_11_1
 L  EDGE_9_11_2
 L  EDGE_9_11_3
 L  EDGE_9_11_4
 L  EDGE_9_11_5
 L  EDGE_9_11_6
 L  EDGE_9_11_7
 L  EDGE_9_11_8
 L  EDGE_9_11_9
 L  EDGE_9_22_0
 L  EDGE_9_22_1
 L  EDGE_9_22_2
 L  EDGE_9_22_3
 L  EDGE_9_22_4
 L  EDGE_9_22_5
 L  EDGE_9_22_6
 L  EDGE_9_22_7
 L  EDGE_9_22_8
 L  EDGE_9_22_9
 L  EDGE_10_17_0
 L  EDGE_10_17_1
 L  EDGE_10_17_2
 L  EDGE_10_17_3
 L  EDGE_10_17_4
 L  EDGE_10_17_5
 L  EDGE_10_17_6
 L  EDGE_10_17_7
 L  EDGE_10_17_8
 L  EDGE_10_17_9
 L  EDGE_10_17_10
 L  EDGE_11_13_0
 L  EDGE_11_13_1
 L  EDGE_11_13_2
 L  EDGE_11_13_3
 L  EDGE_11_13_4
 L  EDGE_11_13_5
 L  EDGE_11_13_6
 L  EDGE_11_13_7
 L  EDGE_11_13_8
 L  EDGE_11_13_9
 L  EDGE_11_13_10
 L  EDGE_11_13_11
 L  EDGE_11_22_0
 L  EDGE_11_22_1
 L  EDGE_11_22_2
 L  EDGE_11_22_3
 L  EDGE_11_22_4
 L  EDGE_11_22_5
 L  EDGE_11_22_6
 L  EDGE_11_22_7
 L  EDGE_11_22_8
 L  EDGE_11_22_9
 L  EDGE_11_22_10
 L  EDGE_11_22_11
 L  EDGE_12_13_0
 L  EDGE_12_13_1
 L  EDGE_12_13_2
 L  EDGE_12_13_3
 L  EDGE_12_13_4
 L  EDGE_12_13_5
 L  EDGE_12_13_6
 L  EDGE_12_13_7
 L  EDGE_12_13_8
 L  EDGE_12_13_9
 L  EDGE_12_13_10
 L  EDGE_12_13_11
 L  EDGE_12_13_12
 L  EDGE_13_19_0
 L  EDGE_13_19_1
 L  EDGE_13_19_2
 L  EDGE_13_19_3
 L  EDGE_13_19_4
 L  EDGE_13_19_5
 L  EDGE_13_19_6
 L  EDGE_13_19_7
 L  EDGE_13_19_8
 L  EDGE_13_19_9
 L  EDGE_13_19_10
 L  EDGE_13_19_11
 L  EDGE_13_19_12
 L  EDGE_13_19_13
 L  EDGE_14_15_0
 L  EDGE_14_15_1
 L  EDGE_14_15_2
 L  EDGE_14_15_3
 L  EDGE_14_15_4
 L  EDGE_14_15_5
 L  EDGE_14_15_6
 L  EDGE_14_15_7
 L  EDGE_14_15_8
 L  EDGE_14_15_9
 L  EDGE_14_15_10
 L  EDGE_14_15_11
 L  EDGE_14_15_12
 L  EDGE_14_15_13
 L  EDGE_14_15_14
 L  EDGE_14_18_0
 L  EDGE_14_18_1
 L  EDGE_14_18_2
 L  EDGE_14_18_3
 L  EDGE_14_18_4
 L  EDGE_14_18_5
 L  EDGE_14_18_6
 L  EDGE_14_18_7
 L  EDGE_14_18_8
 L  EDGE_14_18_9
 L  EDGE_14_18_10
 L  EDGE_14_18_11
 L  EDGE_14_18_12
 L  EDGE_14_18_13
 L  EDGE_14_18_14
 L  EDGE_14_23_0
 L  EDGE_14_23_1
 L  EDGE_14_23_2
 L  EDGE_14_23_3
 L  EDGE_14_23_4
 L  EDGE_14_23_5
 L  EDGE_14_23_6
 L  EDGE_14_23_7
 L  EDGE_14_23_8
 L  EDGE_14_23_9
 L  EDGE_14_23_10
 L  EDGE_14_23_11
 L  EDGE_14_23_12
 L  EDGE_14_23_13
 L  EDGE_14_23_14
 L  EDGE_15_16_0
 L  EDGE_15_16_1
 L  EDGE_15_16_2
 L  EDGE_15_16_3
 L  EDGE_15_16_4
 L  EDGE_15_16_5
 L  EDGE_15_16_6
 L  EDGE_15_16_7
 L  EDGE_15_16_8
 L  EDGE_15_16_9
 L  EDGE_15_16_10
 L  EDGE_15_16_11
 L  EDGE_15_16_12
 L  EDGE_15_16_13
 L  EDGE_15_16_14
 L  EDGE_15_16_15
 L  EDGE_15_23_0
 L  EDGE_15_23_1
 L  EDGE_15_23_2
 L  EDGE_15_23_3
 L  EDGE_15_23_4
 L  EDGE_15_23_5
 L  EDGE_15_23_6
 L  EDGE_15_23_7
 L  EDGE_15_23_8
 L  EDGE_15_23_9
 L  EDGE_15_23_10
 L  EDGE_15_23_11
 L  EDGE_15_23_12
 L  EDGE_15_23_13
 L  EDGE_15_23_14
 L  EDGE_15_23_15
 L  EDGE_16_20_0
 L  EDGE_16_20_1
 L  EDGE_16_20_2
 L  EDGE_16_20_3
 L  EDGE_16_20_4
 L  EDGE_16_20_5
 L  EDGE_16_20_6
 L  EDGE_16_20_7
 L  EDGE_16_20_8
 L  EDGE_16_20_9
 L  EDGE_16_20_10
 L  EDGE_16_20_11
 L  EDGE_16_20_12
 L  EDGE_16_20_13
 L  EDGE_16_20_14
 L  EDGE_16_20_15
 L  EDGE_16_20_16
 L  EDGE_17_18_0
 L  EDGE_17_18_1
 L  EDGE_17_18_2
 L  EDGE_17_18_3
 L  EDGE_17_18_4
 L  EDGE_17_18_5
 L  EDGE_17_18_6
 L  EDGE_17_18_7
 L  EDGE_17_18_8
 L  EDGE_17_18_9
 L  EDGE_17_18_10
 L  EDGE_17_18_11
 L  EDGE_17_18_12
 L  EDGE_17_18_13
 L  EDGE_17_18_14
 L  EDGE_17_18_15
 L  EDGE_17_18_16
 L  EDGE_17_18_17
 L  EDGE_17_21_0
 L  EDGE_17_21_1
 L  EDGE_17_21_2
 L  EDGE_17_21_3
 L  EDGE_17_21_4
 L  EDGE_17_21_5
 L  EDGE_17_21_6
 L  EDGE_17_21_7
 L  EDGE_17_21_8
 L  EDGE_17_21_9
 L  EDGE_17_21_10
 L  EDGE_17_21_11
 L  EDGE_17_21_12
 L  EDGE_17_21_13
 L  EDGE_17_21_14
 L  EDGE_17_21_15
 L  EDGE_17_21_16
 L  EDGE_17_21_17
 L  EDGE_19_24_0
 L  EDGE_19_24_1
 L  EDGE_19_24_2
 L  EDGE_19_24_3
 L  EDGE_19_24_4
 L  EDGE_19_24_5
 L  EDGE_19_24_6
 L  EDGE_19_24_7
 L  EDGE_19_24_8
 L  EDGE_19_24_9
 L  EDGE_19_24_10
 L  EDGE_19_24_11
 L  EDGE_19_24_12
 L  EDGE_19_24_13
 L  EDGE_19_24_14
 L  EDGE_19_24_15
 L  EDGE_19_24_16
 L  EDGE_19_24_17
 L  EDGE_19_24_18
 L  EDGE_19_24_19
 L  EDGE_20_24_0
 L  EDGE_20_24_1
 L  EDGE_20_24_2
 L  EDGE_20_24_3
 L  EDGE_20_24_4
 L  EDGE_20_24_5
 L  EDGE_20_24_6
 L  EDGE_20_24_7
 L  EDGE_20_24_8
 L  EDGE_20_24_9
 L  EDGE_20_24_10
 L  EDGE_20_24_11
 L  EDGE_20_24_12
 L  EDGE_20_24_13
 L  EDGE_20_24_14
 L  EDGE_20_24_15
 L  EDGE_20_24_16
 L  EDGE_20_24_17
 L  EDGE_20_24_18
 L  EDGE_20_24_19
 L  EDGE_20_24_20
 L  EDGE_25_26_0
 L  EDGE_25_26_1
 L  EDGE_25_26_2
 L  EDGE_25_26_3
 L  EDGE_25_26_4
 L  EDGE_25_26_5
 L  EDGE_25_26_6
 L  EDGE_25_26_7
 L  EDGE_25_26_8
 L  EDGE_25_26_9
 L  EDGE_25_26_10
 L  EDGE_25_26_11
 L  EDGE_25_26_12
 L  EDGE_25_26_13
 L  EDGE_25_26_14
 L  EDGE_25_26_15
 L  EDGE_25_26_16
 L  EDGE_25_26_17
 L  EDGE_25_26_18
 L  EDGE_25_26_19
 L  EDGE_25_26_20
 L  EDGE_25_26_21
 L  EDGE_25_26_22
 L  EDGE_25_26_23
 L  EDGE_25_26_24
 L  EDGE_25_26_25
 L  EDGE_25_27_0
 L  EDGE_25_27_1
 L  EDGE_25_27_2
 L  EDGE_25_27_3
 L  EDGE_25_27_4
 L  EDGE_25_27_5
 L  EDGE_25_27_6
 L  EDGE_25_27_7
 L  EDGE_25_27_8
 L  EDGE_25_27_9
 L  EDGE_25_27_10
 L  EDGE_25_27_11
 L  EDGE_25_27_12
 L  EDGE_25_27_13
 L  EDGE_25_27_14
 L  EDGE_25_27_15
 L  EDGE_25_27_16
 L  EDGE_25_27_17
 L  EDGE_25_27_18
 L  EDGE_25_27_19
 L  EDGE_25_27_20
 L  EDGE_25_27_21
 L  EDGE_25_27_22
 L  EDGE_25_27_23
 L  EDGE_25_27_24
 L  EDGE_25_27_25
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_0           OBJ           1.0
    x_0_0           ASSIGN_0        1.0
    x_0_0           LINK_1_0        -1.0
    x_0_0           LINK_2_0        -1.0
    x_0_0           LINK_3_0        -1.0
    x_0_0           LINK_4_0        -1.0
    x_0_0           LINK_5_0        -1.0
    x_0_0           LINK_6_0        -1.0
    x_0_0           LINK_7_0        -1.0
    x_0_0           LINK_8_0        -1.0
    x_0_0           LINK_9_0        -1.0
    x_0_0           LINK_10_0       -1.0
    x_0_0           LINK_11_0       -1.0
    x_0_0           LINK_12_0       -1.0
    x_0_0           LINK_13_0       -1.0
    x_0_0           LINK_14_0       -1.0
    x_0_0           LINK_15_0       -1.0
    x_0_0           LINK_16_0       -1.0
    x_0_0           LINK_17_0       -1.0
    x_0_0           LINK_18_0       -1.0
    x_0_0           LINK_19_0       -1.0
    x_0_0           LINK_20_0       -1.0
    x_0_0           LINK_21_0       -1.0
    x_0_0           LINK_22_0       -1.0
    x_0_0           LINK_23_0       -1.0
    x_0_0           LINK_24_0       -1.0
    x_0_0           LINK_25_0       -1.0
    x_0_0           LINK_26_0       -1.0
    x_0_0           LINK_27_0       -1.0
    x_0_0           EDGE_0_1_0      1.0
    x_0_0           EDGE_0_8_0      1.0
    x_0_0           EDGE_0_9_0      1.0
    x_0_0           EDGE_0_11_0     1.0
    x_0_0           EDGE_0_12_0     1.0
    x_0_0           EDGE_0_13_0     1.0
    x_0_0           EDGE_1_3_0      -1.0
    x_0_0           EDGE_1_7_0      -1.0
    x_0_0           EDGE_1_8_0      -1.0
    x_0_0           EDGE_1_10_0     -1.0
    x_0_0           EDGE_2_3_0      -1.0
    x_0_0           EDGE_2_4_0      -1.0
    x_0_0           EDGE_2_5_0      -1.0
    x_0_0           EDGE_2_10_0     -1.0
    x_0_0           EDGE_2_18_0     -1.0
    x_0_0           EDGE_3_5_0      -1.0
    x_0_0           EDGE_3_6_0      -1.0
    x_0_0           EDGE_3_12_0     -1.0
    x_0_0           EDGE_4_5_0      -1.0
    x_0_0           EDGE_4_14_0     -1.0
    x_0_0           EDGE_4_15_0     -1.0
    x_0_0           EDGE_4_16_0     -1.0
    x_0_0           EDGE_5_6_0      -1.0
    x_0_0           EDGE_5_16_0     -1.0
    x_0_0           EDGE_6_12_0     -1.0
    x_0_0           EDGE_6_19_0     -1.0
    x_0_0           EDGE_6_20_0     -1.0
    x_0_0           EDGE_7_8_0      -1.0
    x_0_0           EDGE_7_10_0     -1.0
    x_0_0           EDGE_7_21_0     -1.0
    x_0_0           EDGE_8_9_0      -1.0
    x_0_0           EDGE_9_11_0     -1.0
    x_0_0           EDGE_9_22_0     -1.0
    x_0_0           EDGE_10_17_0    -1.0
    x_0_0           EDGE_11_13_0    -1.0
    x_0_0           EDGE_11_22_0    -1.0
    x_0_0           EDGE_12_13_0    -1.0
    x_0_0           EDGE_13_19_0    -1.0
    x_0_0           EDGE_14_15_0    -1.0
    x_0_0           EDGE_14_18_0    -1.0
    x_0_0           EDGE_14_23_0    -1.0
    x_0_0           EDGE_15_16_0    -1.0
    x_0_0           EDGE_15_23_0    -1.0
    x_0_0           EDGE_16_20_0    -1.0
    x_0_0           EDGE_17_18_0    -1.0
    x_0_0           EDGE_17_21_0    -1.0
    x_0_0           EDGE_19_24_0    -1.0
    x_0_0           EDGE_20_24_0    -1.0
    x_0_0           EDGE_25_26_0    -1.0
    x_0_0           EDGE_25_27_0    -1.0
    x_1_0           ASSIGN_1        1.0
    x_1_0           LINK_1_0        1.0
    x_1_0           EDGE_0_1_0      1.0
    x_1_0           EDGE_1_3_0      1.0
    x_1_0           EDGE_1_7_0      1.0
    x_1_0           EDGE_1_8_0      1.0
    x_1_0           EDGE_1_10_0     1.0
    x_1_1           OBJ           1.0
    x_1_1           ASSIGN_1        1.0
    x_1_1           LINK_2_1        -1.0
    x_1_1           LINK_3_1        -1.0
    x_1_1           LINK_4_1        -1.0
    x_1_1           LINK_5_1        -1.0
    x_1_1           LINK_6_1        -1.0
    x_1_1           LINK_7_1        -1.0
    x_1_1           LINK_8_1        -1.0
    x_1_1           LINK_9_1        -1.0
    x_1_1           LINK_10_1       -1.0
    x_1_1           LINK_11_1       -1.0
    x_1_1           LINK_12_1       -1.0
    x_1_1           LINK_13_1       -1.0
    x_1_1           LINK_14_1       -1.0
    x_1_1           LINK_15_1       -1.0
    x_1_1           LINK_16_1       -1.0
    x_1_1           LINK_17_1       -1.0
    x_1_1           LINK_18_1       -1.0
    x_1_1           LINK_19_1       -1.0
    x_1_1           LINK_20_1       -1.0
    x_1_1           LINK_21_1       -1.0
    x_1_1           LINK_22_1       -1.0
    x_1_1           LINK_23_1       -1.0
    x_1_1           LINK_24_1       -1.0
    x_1_1           LINK_25_1       -1.0
    x_1_1           LINK_26_1       -1.0
    x_1_1           LINK_27_1       -1.0
    x_1_1           EDGE_1_3_1      1.0
    x_1_1           EDGE_1_7_1      1.0
    x_1_1           EDGE_1_8_1      1.0
    x_1_1           EDGE_1_10_1     1.0
    x_1_1           EDGE_2_3_1      -1.0
    x_1_1           EDGE_2_4_1      -1.0
    x_1_1           EDGE_2_5_1      -1.0
    x_1_1           EDGE_2_10_1     -1.0
    x_1_1           EDGE_2_18_1     -1.0
    x_1_1           EDGE_3_5_1      -1.0
    x_1_1           EDGE_3_6_1      -1.0
    x_1_1           EDGE_3_12_1     -1.0
    x_1_1           EDGE_4_5_1      -1.0
    x_1_1           EDGE_4_14_1     -1.0
    x_1_1           EDGE_4_15_1     -1.0
    x_1_1           EDGE_4_16_1     -1.0
    x_1_1           EDGE_5_6_1      -1.0
    x_1_1           EDGE_5_16_1     -1.0
    x_1_1           EDGE_6_12_1     -1.0
    x_1_1           EDGE_6_19_1     -1.0
    x_1_1           EDGE_6_20_1     -1.0
    x_1_1           EDGE_7_8_1      -1.0
    x_1_1           EDGE_7_10_1     -1.0
    x_1_1           EDGE_7_21_1     -1.0
    x_1_1           EDGE_8_9_1      -1.0
    x_1_1           EDGE_9_11_1     -1.0
    x_1_1           EDGE_9_22_1     -1.0
    x_1_1           EDGE_10_17_1    -1.0
    x_1_1           EDGE_11_13_1    -1.0
    x_1_1           EDGE_11_22_1    -1.0
    x_1_1           EDGE_12_13_1    -1.0
    x_1_1           EDGE_13_19_1    -1.0
    x_1_1           EDGE_14_15_1    -1.0
    x_1_1           EDGE_14_18_1    -1.0
    x_1_1           EDGE_14_23_1    -1.0
    x_1_1           EDGE_15_16_1    -1.0
    x_1_1           EDGE_15_23_1    -1.0
    x_1_1           EDGE_16_20_1    -1.0
    x_1_1           EDGE_17_18_1    -1.0
    x_1_1           EDGE_17_21_1    -1.0
    x_1_1           EDGE_19_24_1    -1.0
    x_1_1           EDGE_20_24_1    -1.0
    x_1_1           EDGE_25_26_1    -1.0
    x_1_1           EDGE_25_27_1    -1.0
    x_2_0           ASSIGN_2        1.0
    x_2_0           LINK_2_0        1.0
    x_2_0           EDGE_2_3_0      1.0
    x_2_0           EDGE_2_4_0      1.0
    x_2_0           EDGE_2_5_0      1.0
    x_2_0           EDGE_2_10_0     1.0
    x_2_0           EDGE_2_18_0     1.0
    x_2_1           ASSIGN_2        1.0
    x_2_1           LINK_2_1        1.0
    x_2_1           EDGE_2_3_1      1.0
    x_2_1           EDGE_2_4_1      1.0
    x_2_1           EDGE_2_5_1      1.0
    x_2_1           EDGE_2_10_1     1.0
    x_2_1           EDGE_2_18_1     1.0
    x_2_2           OBJ           1.0
    x_2_2           ASSIGN_2        1.0
    x_2_2           LINK_3_2        -1.0
    x_2_2           LINK_4_2        -1.0
    x_2_2           LINK_5_2        -1.0
    x_2_2           LINK_6_2        -1.0
    x_2_2           LINK_7_2        -1.0
    x_2_2           LINK_8_2        -1.0
    x_2_2           LINK_9_2        -1.0
    x_2_2           LINK_10_2       -1.0
    x_2_2           LINK_11_2       -1.0
    x_2_2           LINK_12_2       -1.0
    x_2_2           LINK_13_2       -1.0
    x_2_2           LINK_14_2       -1.0
    x_2_2           LINK_15_2       -1.0
    x_2_2           LINK_16_2       -1.0
    x_2_2           LINK_17_2       -1.0
    x_2_2           LINK_18_2       -1.0
    x_2_2           LINK_19_2       -1.0
    x_2_2           LINK_20_2       -1.0
    x_2_2           LINK_21_2       -1.0
    x_2_2           LINK_22_2       -1.0
    x_2_2           LINK_23_2       -1.0
    x_2_2           LINK_24_2       -1.0
    x_2_2           LINK_25_2       -1.0
    x_2_2           LINK_26_2       -1.0
    x_2_2           LINK_27_2       -1.0
    x_2_2           EDGE_2_3_2      1.0
    x_2_2           EDGE_2_4_2      1.0
    x_2_2           EDGE_2_5_2      1.0
    x_2_2           EDGE_2_10_2     1.0
    x_2_2           EDGE_2_18_2     1.0
    x_2_2           EDGE_3_5_2      -1.0
    x_2_2           EDGE_3_6_2      -1.0
    x_2_2           EDGE_3_12_2     -1.0
    x_2_2           EDGE_4_5_2      -1.0
    x_2_2           EDGE_4_14_2     -1.0
    x_2_2           EDGE_4_15_2     -1.0
    x_2_2           EDGE_4_16_2     -1.0
    x_2_2           EDGE_5_6_2      -1.0
    x_2_2           EDGE_5_16_2     -1.0
    x_2_2           EDGE_6_12_2     -1.0
    x_2_2           EDGE_6_19_2     -1.0
    x_2_2           EDGE_6_20_2     -1.0
    x_2_2           EDGE_7_8_2      -1.0
    x_2_2           EDGE_7_10_2     -1.0
    x_2_2           EDGE_7_21_2     -1.0
    x_2_2           EDGE_8_9_2      -1.0
    x_2_2           EDGE_9_11_2     -1.0
    x_2_2           EDGE_9_22_2     -1.0
    x_2_2           EDGE_10_17_2    -1.0
    x_2_2           EDGE_11_13_2    -1.0
    x_2_2           EDGE_11_22_2    -1.0
    x_2_2           EDGE_12_13_2    -1.0
    x_2_2           EDGE_13_19_2    -1.0
    x_2_2           EDGE_14_15_2    -1.0
    x_2_2           EDGE_14_18_2    -1.0
    x_2_2           EDGE_14_23_2    -1.0
    x_2_2           EDGE_15_16_2    -1.0
    x_2_2           EDGE_15_23_2    -1.0
    x_2_2           EDGE_16_20_2    -1.0
    x_2_2           EDGE_17_18_2    -1.0
    x_2_2           EDGE_17_21_2    -1.0
    x_2_2           EDGE_19_24_2    -1.0
    x_2_2           EDGE_20_24_2    -1.0
    x_2_2           EDGE_25_26_2    -1.0
    x_2_2           EDGE_25_27_2    -1.0
    x_3_0           ASSIGN_3        1.0
    x_3_0           LINK_3_0        1.0
    x_3_0           EDGE_1_3_0      1.0
    x_3_0           EDGE_2_3_0      1.0
    x_3_0           EDGE_3_5_0      1.0
    x_3_0           EDGE_3_6_0      1.0
    x_3_0           EDGE_3_12_0     1.0
    x_3_1           ASSIGN_3        1.0
    x_3_1           LINK_3_1        1.0
    x_3_1           EDGE_1_3_1      1.0
    x_3_1           EDGE_2_3_1      1.0
    x_3_1           EDGE_3_5_1      1.0
    x_3_1           EDGE_3_6_1      1.0
    x_3_1           EDGE_3_12_1     1.0
    x_3_2           ASSIGN_3        1.0
    x_3_2           LINK_3_2        1.0
    x_3_2           EDGE_2_3_2      1.0
    x_3_2           EDGE_3_5_2      1.0
    x_3_2           EDGE_3_6_2      1.0
    x_3_2           EDGE_3_12_2     1.0
    x_3_3           OBJ           1.0
    x_3_3           ASSIGN_3        1.0
    x_3_3           LINK_4_3        -1.0
    x_3_3           LINK_5_3        -1.0
    x_3_3           LINK_6_3        -1.0
    x_3_3           LINK_7_3        -1.0
    x_3_3           LINK_8_3        -1.0
    x_3_3           LINK_9_3        -1.0
    x_3_3           LINK_10_3       -1.0
    x_3_3           LINK_11_3       -1.0
    x_3_3           LINK_12_3       -1.0
    x_3_3           LINK_13_3       -1.0
    x_3_3           LINK_14_3       -1.0
    x_3_3           LINK_15_3       -1.0
    x_3_3           LINK_16_3       -1.0
    x_3_3           LINK_17_3       -1.0
    x_3_3           LINK_18_3       -1.0
    x_3_3           LINK_19_3       -1.0
    x_3_3           LINK_20_3       -1.0
    x_3_3           LINK_21_3       -1.0
    x_3_3           LINK_22_3       -1.0
    x_3_3           LINK_23_3       -1.0
    x_3_3           LINK_24_3       -1.0
    x_3_3           LINK_25_3       -1.0
    x_3_3           LINK_26_3       -1.0
    x_3_3           LINK_27_3       -1.0
    x_3_3           EDGE_3_5_3      1.0
    x_3_3           EDGE_3_6_3      1.0
    x_3_3           EDGE_3_12_3     1.0
    x_3_3           EDGE_4_5_3      -1.0
    x_3_3           EDGE_4_14_3     -1.0
    x_3_3           EDGE_4_15_3     -1.0
    x_3_3           EDGE_4_16_3     -1.0
    x_3_3           EDGE_5_6_3      -1.0
    x_3_3           EDGE_5_16_3     -1.0
    x_3_3           EDGE_6_12_3     -1.0
    x_3_3           EDGE_6_19_3     -1.0
    x_3_3           EDGE_6_20_3     -1.0
    x_3_3           EDGE_7_8_3      -1.0
    x_3_3           EDGE_7_10_3     -1.0
    x_3_3           EDGE_7_21_3     -1.0
    x_3_3           EDGE_8_9_3      -1.0
    x_3_3           EDGE_9_11_3     -1.0
    x_3_3           EDGE_9_22_3     -1.0
    x_3_3           EDGE_10_17_3    -1.0
    x_3_3           EDGE_11_13_3    -1.0
    x_3_3           EDGE_11_22_3    -1.0
    x_3_3           EDGE_12_13_3    -1.0
    x_3_3           EDGE_13_19_3    -1.0
    x_3_3           EDGE_14_15_3    -1.0
    x_3_3           EDGE_14_18_3    -1.0
    x_3_3           EDGE_14_23_3    -1.0
    x_3_3           EDGE_15_16_3    -1.0
    x_3_3           EDGE_15_23_3    -1.0
    x_3_3           EDGE_16_20_3    -1.0
    x_3_3           EDGE_17_18_3    -1.0
    x_3_3           EDGE_17_21_3    -1.0
    x_3_3           EDGE_19_24_3    -1.0
    x_3_3           EDGE_20_24_3    -1.0
    x_3_3           EDGE_25_26_3    -1.0
    x_3_3           EDGE_25_27_3    -1.0
    x_4_0           ASSIGN_4        1.0
    x_4_0           LINK_4_0        1.0
    x_4_0           EDGE_2_4_0      1.0
    x_4_0           EDGE_4_5_0      1.0
    x_4_0           EDGE_4_14_0     1.0
    x_4_0           EDGE_4_15_0     1.0
    x_4_0           EDGE_4_16_0     1.0
    x_4_1           ASSIGN_4        1.0
    x_4_1           LINK_4_1        1.0
    x_4_1           EDGE_2_4_1      1.0
    x_4_1           EDGE_4_5_1      1.0
    x_4_1           EDGE_4_14_1     1.0
    x_4_1           EDGE_4_15_1     1.0
    x_4_1           EDGE_4_16_1     1.0
    x_4_2           ASSIGN_4        1.0
    x_4_2           LINK_4_2        1.0
    x_4_2           EDGE_2_4_2      1.0
    x_4_2           EDGE_4_5_2      1.0
    x_4_2           EDGE_4_14_2     1.0
    x_4_2           EDGE_4_15_2     1.0
    x_4_2           EDGE_4_16_2     1.0
    x_4_3           ASSIGN_4        1.0
    x_4_3           LINK_4_3        1.0
    x_4_3           EDGE_4_5_3      1.0
    x_4_3           EDGE_4_14_3     1.0
    x_4_3           EDGE_4_15_3     1.0
    x_4_3           EDGE_4_16_3     1.0
    x_4_4           OBJ           1.0
    x_4_4           ASSIGN_4        1.0
    x_4_4           LINK_5_4        -1.0
    x_4_4           LINK_6_4        -1.0
    x_4_4           LINK_7_4        -1.0
    x_4_4           LINK_8_4        -1.0
    x_4_4           LINK_9_4        -1.0
    x_4_4           LINK_10_4       -1.0
    x_4_4           LINK_11_4       -1.0
    x_4_4           LINK_12_4       -1.0
    x_4_4           LINK_13_4       -1.0
    x_4_4           LINK_14_4       -1.0
    x_4_4           LINK_15_4       -1.0
    x_4_4           LINK_16_4       -1.0
    x_4_4           LINK_17_4       -1.0
    x_4_4           LINK_18_4       -1.0
    x_4_4           LINK_19_4       -1.0
    x_4_4           LINK_20_4       -1.0
    x_4_4           LINK_21_4       -1.0
    x_4_4           LINK_22_4       -1.0
    x_4_4           LINK_23_4       -1.0
    x_4_4           LINK_24_4       -1.0
    x_4_4           LINK_25_4       -1.0
    x_4_4           LINK_26_4       -1.0
    x_4_4           LINK_27_4       -1.0
    x_4_4           EDGE_4_5_4      1.0
    x_4_4           EDGE_4_14_4     1.0
    x_4_4           EDGE_4_15_4     1.0
    x_4_4           EDGE_4_16_4     1.0
    x_4_4           EDGE_5_6_4      -1.0
    x_4_4           EDGE_5_16_4     -1.0
    x_4_4           EDGE_6_12_4     -1.0
    x_4_4           EDGE_6_19_4     -1.0
    x_4_4           EDGE_6_20_4     -1.0
    x_4_4           EDGE_7_8_4      -1.0
    x_4_4           EDGE_7_10_4     -1.0
    x_4_4           EDGE_7_21_4     -1.0
    x_4_4           EDGE_8_9_4      -1.0
    x_4_4           EDGE_9_11_4     -1.0
    x_4_4           EDGE_9_22_4     -1.0
    x_4_4           EDGE_10_17_4    -1.0
    x_4_4           EDGE_11_13_4    -1.0
    x_4_4           EDGE_11_22_4    -1.0
    x_4_4           EDGE_12_13_4    -1.0
    x_4_4           EDGE_13_19_4    -1.0
    x_4_4           EDGE_14_15_4    -1.0
    x_4_4           EDGE_14_18_4    -1.0
    x_4_4           EDGE_14_23_4    -1.0
    x_4_4           EDGE_15_16_4    -1.0
    x_4_4           EDGE_15_23_4    -1.0
    x_4_4           EDGE_16_20_4    -1.0
    x_4_4           EDGE_17_18_4    -1.0
    x_4_4           EDGE_17_21_4    -1.0
    x_4_4           EDGE_19_24_4    -1.0
    x_4_4           EDGE_20_24_4    -1.0
    x_4_4           EDGE_25_26_4    -1.0
    x_4_4           EDGE_25_27_4    -1.0
    x_5_0           ASSIGN_5        1.0
    x_5_0           LINK_5_0        1.0
    x_5_0           EDGE_2_5_0      1.0
    x_5_0           EDGE_3_5_0      1.0
    x_5_0           EDGE_4_5_0      1.0
    x_5_0           EDGE_5_6_0      1.0
    x_5_0           EDGE_5_16_0     1.0
    x_5_1           ASSIGN_5        1.0
    x_5_1           LINK_5_1        1.0
    x_5_1           EDGE_2_5_1      1.0
    x_5_1           EDGE_3_5_1      1.0
    x_5_1           EDGE_4_5_1      1.0
    x_5_1           EDGE_5_6_1      1.0
    x_5_1           EDGE_5_16_1     1.0
    x_5_2           ASSIGN_5        1.0
    x_5_2           LINK_5_2        1.0
    x_5_2           EDGE_2_5_2      1.0
    x_5_2           EDGE_3_5_2      1.0
    x_5_2           EDGE_4_5_2      1.0
    x_5_2           EDGE_5_6_2      1.0
    x_5_2           EDGE_5_16_2     1.0
    x_5_3           ASSIGN_5        1.0
    x_5_3           LINK_5_3        1.0
    x_5_3           EDGE_3_5_3      1.0
    x_5_3           EDGE_4_5_3      1.0
    x_5_3           EDGE_5_6_3      1.0
    x_5_3           EDGE_5_16_3     1.0
    x_5_4           ASSIGN_5        1.0
    x_5_4           LINK_5_4        1.0
    x_5_4           EDGE_4_5_4      1.0
    x_5_4           EDGE_5_6_4      1.0
    x_5_4           EDGE_5_16_4     1.0
    x_5_5           OBJ           1.0
    x_5_5           ASSIGN_5        1.0
    x_5_5           LINK_6_5        -1.0
    x_5_5           LINK_7_5        -1.0
    x_5_5           LINK_8_5        -1.0
    x_5_5           LINK_9_5        -1.0
    x_5_5           LINK_10_5       -1.0
    x_5_5           LINK_11_5       -1.0
    x_5_5           LINK_12_5       -1.0
    x_5_5           LINK_13_5       -1.0
    x_5_5           LINK_14_5       -1.0
    x_5_5           LINK_15_5       -1.0
    x_5_5           LINK_16_5       -1.0
    x_5_5           LINK_17_5       -1.0
    x_5_5           LINK_18_5       -1.0
    x_5_5           LINK_19_5       -1.0
    x_5_5           LINK_20_5       -1.0
    x_5_5           LINK_21_5       -1.0
    x_5_5           LINK_22_5       -1.0
    x_5_5           LINK_23_5       -1.0
    x_5_5           LINK_24_5       -1.0
    x_5_5           LINK_25_5       -1.0
    x_5_5           LINK_26_5       -1.0
    x_5_5           LINK_27_5       -1.0
    x_5_5           EDGE_5_6_5      1.0
    x_5_5           EDGE_5_16_5     1.0
    x_5_5           EDGE_6_12_5     -1.0
    x_5_5           EDGE_6_19_5     -1.0
    x_5_5           EDGE_6_20_5     -1.0
    x_5_5           EDGE_7_8_5      -1.0
    x_5_5           EDGE_7_10_5     -1.0
    x_5_5           EDGE_7_21_5     -1.0
    x_5_5           EDGE_8_9_5      -1.0
    x_5_5           EDGE_9_11_5     -1.0
    x_5_5           EDGE_9_22_5     -1.0
    x_5_5           EDGE_10_17_5    -1.0
    x_5_5           EDGE_11_13_5    -1.0
    x_5_5           EDGE_11_22_5    -1.0
    x_5_5           EDGE_12_13_5    -1.0
    x_5_5           EDGE_13_19_5    -1.0
    x_5_5           EDGE_14_15_5    -1.0
    x_5_5           EDGE_14_18_5    -1.0
    x_5_5           EDGE_14_23_5    -1.0
    x_5_5           EDGE_15_16_5    -1.0
    x_5_5           EDGE_15_23_5    -1.0
    x_5_5           EDGE_16_20_5    -1.0
    x_5_5           EDGE_17_18_5    -1.0
    x_5_5           EDGE_17_21_5    -1.0
    x_5_5           EDGE_19_24_5    -1.0
    x_5_5           EDGE_20_24_5    -1.0
    x_5_5           EDGE_25_26_5    -1.0
    x_5_5           EDGE_25_27_5    -1.0
    x_6_0           ASSIGN_6        1.0
    x_6_0           LINK_6_0        1.0
    x_6_0           EDGE_3_6_0      1.0
    x_6_0           EDGE_5_6_0      1.0
    x_6_0           EDGE_6_12_0     1.0
    x_6_0           EDGE_6_19_0     1.0
    x_6_0           EDGE_6_20_0     1.0
    x_6_1           ASSIGN_6        1.0
    x_6_1           LINK_6_1        1.0
    x_6_1           EDGE_3_6_1      1.0
    x_6_1           EDGE_5_6_1      1.0
    x_6_1           EDGE_6_12_1     1.0
    x_6_1           EDGE_6_19_1     1.0
    x_6_1           EDGE_6_20_1     1.0
    x_6_2           ASSIGN_6        1.0
    x_6_2           LINK_6_2        1.0
    x_6_2           EDGE_3_6_2      1.0
    x_6_2           EDGE_5_6_2      1.0
    x_6_2           EDGE_6_12_2     1.0
    x_6_2           EDGE_6_19_2     1.0
    x_6_2           EDGE_6_20_2     1.0
    x_6_3           ASSIGN_6        1.0
    x_6_3           LINK_6_3        1.0
    x_6_3           EDGE_3_6_3      1.0
    x_6_3           EDGE_5_6_3      1.0
    x_6_3           EDGE_6_12_3     1.0
    x_6_3           EDGE_6_19_3     1.0
    x_6_3           EDGE_6_20_3     1.0
    x_6_4           ASSIGN_6        1.0
    x_6_4           LINK_6_4        1.0
    x_6_4           EDGE_5_6_4      1.0
    x_6_4           EDGE_6_12_4     1.0
    x_6_4           EDGE_6_19_4     1.0
    x_6_4           EDGE_6_20_4     1.0
    x_6_5           ASSIGN_6        1.0
    x_6_5           LINK_6_5        1.0
    x_6_5           EDGE_5_6_5      1.0
    x_6_5           EDGE_6_12_5     1.0
    x_6_5           EDGE_6_19_5     1.0
    x_6_5           EDGE_6_20_5     1.0
    x_6_6           OBJ           1.0
    x_6_6           ASSIGN_6        1.0
    x_6_6           LINK_7_6        -1.0
    x_6_6           LINK_8_6        -1.0
    x_6_6           LINK_9_6        -1.0
    x_6_6           LINK_10_6       -1.0
    x_6_6           LINK_11_6       -1.0
    x_6_6           LINK_12_6       -1.0
    x_6_6           LINK_13_6       -1.0
    x_6_6           LINK_14_6       -1.0
    x_6_6           LINK_15_6       -1.0
    x_6_6           LINK_16_6       -1.0
    x_6_6           LINK_17_6       -1.0
    x_6_6           LINK_18_6       -1.0
    x_6_6           LINK_19_6       -1.0
    x_6_6           LINK_20_6       -1.0
    x_6_6           LINK_21_6       -1.0
    x_6_6           LINK_22_6       -1.0
    x_6_6           LINK_23_6       -1.0
    x_6_6           LINK_24_6       -1.0
    x_6_6           LINK_25_6       -1.0
    x_6_6           LINK_26_6       -1.0
    x_6_6           LINK_27_6       -1.0
    x_6_6           EDGE_6_12_6     1.0
    x_6_6           EDGE_6_19_6     1.0
    x_6_6           EDGE_6_20_6     1.0
    x_6_6           EDGE_7_8_6      -1.0
    x_6_6           EDGE_7_10_6     -1.0
    x_6_6           EDGE_7_21_6     -1.0
    x_6_6           EDGE_8_9_6      -1.0
    x_6_6           EDGE_9_11_6     -1.0
    x_6_6           EDGE_9_22_6     -1.0
    x_6_6           EDGE_10_17_6    -1.0
    x_6_6           EDGE_11_13_6    -1.0
    x_6_6           EDGE_11_22_6    -1.0
    x_6_6           EDGE_12_13_6    -1.0
    x_6_6           EDGE_13_19_6    -1.0
    x_6_6           EDGE_14_15_6    -1.0
    x_6_6           EDGE_14_18_6    -1.0
    x_6_6           EDGE_14_23_6    -1.0
    x_6_6           EDGE_15_16_6    -1.0
    x_6_6           EDGE_15_23_6    -1.0
    x_6_6           EDGE_16_20_6    -1.0
    x_6_6           EDGE_17_18_6    -1.0
    x_6_6           EDGE_17_21_6    -1.0
    x_6_6           EDGE_19_24_6    -1.0
    x_6_6           EDGE_20_24_6    -1.0
    x_6_6           EDGE_25_26_6    -1.0
    x_6_6           EDGE_25_27_6    -1.0
    x_7_0           ASSIGN_7        1.0
    x_7_0           LINK_7_0        1.0
    x_7_0           EDGE_1_7_0      1.0
    x_7_0           EDGE_7_8_0      1.0
    x_7_0           EDGE_7_10_0     1.0
    x_7_0           EDGE_7_21_0     1.0
    x_7_1           ASSIGN_7        1.0
    x_7_1           LINK_7_1        1.0
    x_7_1           EDGE_1_7_1      1.0
    x_7_1           EDGE_7_8_1      1.0
    x_7_1           EDGE_7_10_1     1.0
    x_7_1           EDGE_7_21_1     1.0
    x_7_2           ASSIGN_7        1.0
    x_7_2           LINK_7_2        1.0
    x_7_2           EDGE_7_8_2      1.0
    x_7_2           EDGE_7_10_2     1.0
    x_7_2           EDGE_7_21_2     1.0
    x_7_3           ASSIGN_7        1.0
    x_7_3           LINK_7_3        1.0
    x_7_3           EDGE_7_8_3      1.0
    x_7_3           EDGE_7_10_3     1.0
    x_7_3           EDGE_7_21_3     1.0
    x_7_4           ASSIGN_7        1.0
    x_7_4           LINK_7_4        1.0
    x_7_4           EDGE_7_8_4      1.0
    x_7_4           EDGE_7_10_4     1.0
    x_7_4           EDGE_7_21_4     1.0
    x_7_5           ASSIGN_7        1.0
    x_7_5           LINK_7_5        1.0
    x_7_5           EDGE_7_8_5      1.0
    x_7_5           EDGE_7_10_5     1.0
    x_7_5           EDGE_7_21_5     1.0
    x_7_6           ASSIGN_7        1.0
    x_7_6           LINK_7_6        1.0
    x_7_6           EDGE_7_8_6      1.0
    x_7_6           EDGE_7_10_6     1.0
    x_7_6           EDGE_7_21_6     1.0
    x_7_7           OBJ           1.0
    x_7_7           ASSIGN_7        1.0
    x_7_7           LINK_8_7        -1.0
    x_7_7           LINK_9_7        -1.0
    x_7_7           LINK_10_7       -1.0
    x_7_7           LINK_11_7       -1.0
    x_7_7           LINK_12_7       -1.0
    x_7_7           LINK_13_7       -1.0
    x_7_7           LINK_14_7       -1.0
    x_7_7           LINK_15_7       -1.0
    x_7_7           LINK_16_7       -1.0
    x_7_7           LINK_17_7       -1.0
    x_7_7           LINK_18_7       -1.0
    x_7_7           LINK_19_7       -1.0
    x_7_7           LINK_20_7       -1.0
    x_7_7           LINK_21_7       -1.0
    x_7_7           LINK_22_7       -1.0
    x_7_7           LINK_23_7       -1.0
    x_7_7           LINK_24_7       -1.0
    x_7_7           LINK_25_7       -1.0
    x_7_7           LINK_26_7       -1.0
    x_7_7           LINK_27_7       -1.0
    x_7_7           EDGE_7_8_7      1.0
    x_7_7           EDGE_7_10_7     1.0
    x_7_7           EDGE_7_21_7     1.0
    x_7_7           EDGE_8_9_7      -1.0
    x_7_7           EDGE_9_11_7     -1.0
    x_7_7           EDGE_9_22_7     -1.0
    x_7_7           EDGE_10_17_7    -1.0
    x_7_7           EDGE_11_13_7    -1.0
    x_7_7           EDGE_11_22_7    -1.0
    x_7_7           EDGE_12_13_7    -1.0
    x_7_7           EDGE_13_19_7    -1.0
    x_7_7           EDGE_14_15_7    -1.0
    x_7_7           EDGE_14_18_7    -1.0
    x_7_7           EDGE_14_23_7    -1.0
    x_7_7           EDGE_15_16_7    -1.0
    x_7_7           EDGE_15_23_7    -1.0
    x_7_7           EDGE_16_20_7    -1.0
    x_7_7           EDGE_17_18_7    -1.0
    x_7_7           EDGE_17_21_7    -1.0
    x_7_7           EDGE_19_24_7    -1.0
    x_7_7           EDGE_20_24_7    -1.0
    x_7_7           EDGE_25_26_7    -1.0
    x_7_7           EDGE_25_27_7    -1.0
    x_8_0           ASSIGN_8        1.0
    x_8_0           LINK_8_0        1.0
    x_8_0           EDGE_0_8_0      1.0
    x_8_0           EDGE_1_8_0      1.0
    x_8_0           EDGE_7_8_0      1.0
    x_8_0           EDGE_8_9_0      1.0
    x_8_1           ASSIGN_8        1.0
    x_8_1           LINK_8_1        1.0
    x_8_1           EDGE_1_8_1      1.0
    x_8_1           EDGE_7_8_1      1.0
    x_8_1           EDGE_8_9_1      1.0
    x_8_2           ASSIGN_8        1.0
    x_8_2           LINK_8_2        1.0
    x_8_2           EDGE_7_8_2      1.0
    x_8_2           EDGE_8_9_2      1.0
    x_8_3           ASSIGN_8        1.0
    x_8_3           LINK_8_3        1.0
    x_8_3           EDGE_7_8_3      1.0
    x_8_3           EDGE_8_9_3      1.0
    x_8_4           ASSIGN_8        1.0
    x_8_4           LINK_8_4        1.0
    x_8_4           EDGE_7_8_4      1.0
    x_8_4           EDGE_8_9_4      1.0
    x_8_5           ASSIGN_8        1.0
    x_8_5           LINK_8_5        1.0
    x_8_5           EDGE_7_8_5      1.0
    x_8_5           EDGE_8_9_5      1.0
    x_8_6           ASSIGN_8        1.0
    x_8_6           LINK_8_6        1.0
    x_8_6           EDGE_7_8_6      1.0
    x_8_6           EDGE_8_9_6      1.0
    x_8_7           ASSIGN_8        1.0
    x_8_7           LINK_8_7        1.0
    x_8_7           EDGE_7_8_7      1.0
    x_8_7           EDGE_8_9_7      1.0
    x_8_8           OBJ           1.0
    x_8_8           ASSIGN_8        1.0
    x_8_8           LINK_9_8        -1.0
    x_8_8           LINK_10_8       -1.0
    x_8_8           LINK_11_8       -1.0
    x_8_8           LINK_12_8       -1.0
    x_8_8           LINK_13_8       -1.0
    x_8_8           LINK_14_8       -1.0
    x_8_8           LINK_15_8       -1.0
    x_8_8           LINK_16_8       -1.0
    x_8_8           LINK_17_8       -1.0
    x_8_8           LINK_18_8       -1.0
    x_8_8           LINK_19_8       -1.0
    x_8_8           LINK_20_8       -1.0
    x_8_8           LINK_21_8       -1.0
    x_8_8           LINK_22_8       -1.0
    x_8_8           LINK_23_8       -1.0
    x_8_8           LINK_24_8       -1.0
    x_8_8           LINK_25_8       -1.0
    x_8_8           LINK_26_8       -1.0
    x_8_8           LINK_27_8       -1.0
    x_8_8           EDGE_8_9_8      1.0
    x_8_8           EDGE_9_11_8     -1.0
    x_8_8           EDGE_9_22_8     -1.0
    x_8_8           EDGE_10_17_8    -1.0
    x_8_8           EDGE_11_13_8    -1.0
    x_8_8           EDGE_11_22_8    -1.0
    x_8_8           EDGE_12_13_8    -1.0
    x_8_8           EDGE_13_19_8    -1.0
    x_8_8           EDGE_14_15_8    -1.0
    x_8_8           EDGE_14_18_8    -1.0
    x_8_8           EDGE_14_23_8    -1.0
    x_8_8           EDGE_15_16_8    -1.0
    x_8_8           EDGE_15_23_8    -1.0
    x_8_8           EDGE_16_20_8    -1.0
    x_8_8           EDGE_17_18_8    -1.0
    x_8_8           EDGE_17_21_8    -1.0
    x_8_8           EDGE_19_24_8    -1.0
    x_8_8           EDGE_20_24_8    -1.0
    x_8_8           EDGE_25_26_8    -1.0
    x_8_8           EDGE_25_27_8    -1.0
    x_9_0           ASSIGN_9        1.0
    x_9_0           LINK_9_0        1.0
    x_9_0           EDGE_0_9_0      1.0
    x_9_0           EDGE_8_9_0      1.0
    x_9_0           EDGE_9_11_0     1.0
    x_9_0           EDGE_9_22_0     1.0
    x_9_1           ASSIGN_9        1.0
    x_9_1           LINK_9_1        1.0
    x_9_1           EDGE_8_9_1      1.0
    x_9_1           EDGE_9_11_1     1.0
    x_9_1           EDGE_9_22_1     1.0
    x_9_2           ASSIGN_9        1.0
    x_9_2           LINK_9_2        1.0
    x_9_2           EDGE_8_9_2      1.0
    x_9_2           EDGE_9_11_2     1.0
    x_9_2           EDGE_9_22_2     1.0
    x_9_3           ASSIGN_9        1.0
    x_9_3           LINK_9_3        1.0
    x_9_3           EDGE_8_9_3      1.0
    x_9_3           EDGE_9_11_3     1.0
    x_9_3           EDGE_9_22_3     1.0
    x_9_4           ASSIGN_9        1.0
    x_9_4           LINK_9_4        1.0
    x_9_4           EDGE_8_9_4      1.0
    x_9_4           EDGE_9_11_4     1.0
    x_9_4           EDGE_9_22_4     1.0
    x_9_5           ASSIGN_9        1.0
    x_9_5           LINK_9_5        1.0
    x_9_5           EDGE_8_9_5      1.0
    x_9_5           EDGE_9_11_5     1.0
    x_9_5           EDGE_9_22_5     1.0
    x_9_6           ASSIGN_9        1.0
    x_9_6           LINK_9_6        1.0
    x_9_6           EDGE_8_9_6      1.0
    x_9_6           EDGE_9_11_6     1.0
    x_9_6           EDGE_9_22_6     1.0
    x_9_7           ASSIGN_9        1.0
    x_9_7           LINK_9_7        1.0
    x_9_7           EDGE_8_9_7      1.0
    x_9_7           EDGE_9_11_7     1.0
    x_9_7           EDGE_9_22_7     1.0
    x_9_8           ASSIGN_9        1.0
    x_9_8           LINK_9_8        1.0
    x_9_8           EDGE_8_9_8      1.0
    x_9_8           EDGE_9_11_8     1.0
    x_9_8           EDGE_9_22_8     1.0
    x_9_9           OBJ           1.0
    x_9_9           ASSIGN_9        1.0
    x_9_9           LINK_10_9       -1.0
    x_9_9           LINK_11_9       -1.0
    x_9_9           LINK_12_9       -1.0
    x_9_9           LINK_13_9       -1.0
    x_9_9           LINK_14_9       -1.0
    x_9_9           LINK_15_9       -1.0
    x_9_9           LINK_16_9       -1.0
    x_9_9           LINK_17_9       -1.0
    x_9_9           LINK_18_9       -1.0
    x_9_9           LINK_19_9       -1.0
    x_9_9           LINK_20_9       -1.0
    x_9_9           LINK_21_9       -1.0
    x_9_9           LINK_22_9       -1.0
    x_9_9           LINK_23_9       -1.0
    x_9_9           LINK_24_9       -1.0
    x_9_9           LINK_25_9       -1.0
    x_9_9           LINK_26_9       -1.0
    x_9_9           LINK_27_9       -1.0
    x_9_9           EDGE_9_11_9     1.0
    x_9_9           EDGE_9_22_9     1.0
    x_9_9           EDGE_10_17_9    -1.0
    x_9_9           EDGE_11_13_9    -1.0
    x_9_9           EDGE_11_22_9    -1.0
    x_9_9           EDGE_12_13_9    -1.0
    x_9_9           EDGE_13_19_9    -1.0
    x_9_9           EDGE_14_15_9    -1.0
    x_9_9           EDGE_14_18_9    -1.0
    x_9_9           EDGE_14_23_9    -1.0
    x_9_9           EDGE_15_16_9    -1.0
    x_9_9           EDGE_15_23_9    -1.0
    x_9_9           EDGE_16_20_9    -1.0
    x_9_9           EDGE_17_18_9    -1.0
    x_9_9           EDGE_17_21_9    -1.0
    x_9_9           EDGE_19_24_9    -1.0
    x_9_9           EDGE_20_24_9    -1.0
    x_9_9           EDGE_25_26_9    -1.0
    x_9_9           EDGE_25_27_9    -1.0
    x_10_0          ASSIGN_10       1.0
    x_10_0          LINK_10_0       1.0
    x_10_0          EDGE_1_10_0     1.0
    x_10_0          EDGE_2_10_0     1.0
    x_10_0          EDGE_7_10_0     1.0
    x_10_0          EDGE_10_17_0    1.0
    x_10_1          ASSIGN_10       1.0
    x_10_1          LINK_10_1       1.0
    x_10_1          EDGE_1_10_1     1.0
    x_10_1          EDGE_2_10_1     1.0
    x_10_1          EDGE_7_10_1     1.0
    x_10_1          EDGE_10_17_1    1.0
    x_10_2          ASSIGN_10       1.0
    x_10_2          LINK_10_2       1.0
    x_10_2          EDGE_2_10_2     1.0
    x_10_2          EDGE_7_10_2     1.0
    x_10_2          EDGE_10_17_2    1.0
    x_10_3          ASSIGN_10       1.0
    x_10_3          LINK_10_3       1.0
    x_10_3          EDGE_7_10_3     1.0
    x_10_3          EDGE_10_17_3    1.0
    x_10_4          ASSIGN_10       1.0
    x_10_4          LINK_10_4       1.0
    x_10_4          EDGE_7_10_4     1.0
    x_10_4          EDGE_10_17_4    1.0
    x_10_5          ASSIGN_10       1.0
    x_10_5          LINK_10_5       1.0
    x_10_5          EDGE_7_10_5     1.0
    x_10_5          EDGE_10_17_5    1.0
    x_10_6          ASSIGN_10       1.0
    x_10_6          LINK_10_6       1.0
    x_10_6          EDGE_7_10_6     1.0
    x_10_6          EDGE_10_17_6    1.0
    x_10_7          ASSIGN_10       1.0
    x_10_7          LINK_10_7       1.0
    x_10_7          EDGE_7_10_7     1.0
    x_10_7          EDGE_10_17_7    1.0
    x_10_8          ASSIGN_10       1.0
    x_10_8          LINK_10_8       1.0
    x_10_8          EDGE_10_17_8    1.0
    x_10_9          ASSIGN_10       1.0
    x_10_9          LINK_10_9       1.0
    x_10_9          EDGE_10_17_9    1.0
    x_10_10         OBJ           1.0
    x_10_10         ASSIGN_10       1.0
    x_10_10         LINK_11_10      -1.0
    x_10_10         LINK_12_10      -1.0
    x_10_10         LINK_13_10      -1.0
    x_10_10         LINK_14_10      -1.0
    x_10_10         LINK_15_10      -1.0
    x_10_10         LINK_16_10      -1.0
    x_10_10         LINK_17_10      -1.0
    x_10_10         LINK_18_10      -1.0
    x_10_10         LINK_19_10      -1.0
    x_10_10         LINK_20_10      -1.0
    x_10_10         LINK_21_10      -1.0
    x_10_10         LINK_22_10      -1.0
    x_10_10         LINK_23_10      -1.0
    x_10_10         LINK_24_10      -1.0
    x_10_10         LINK_25_10      -1.0
    x_10_10         LINK_26_10      -1.0
    x_10_10         LINK_27_10      -1.0
    x_10_10         EDGE_10_17_10   1.0
    x_10_10         EDGE_11_13_10   -1.0
    x_10_10         EDGE_11_22_10   -1.0
    x_10_10         EDGE_12_13_10   -1.0
    x_10_10         EDGE_13_19_10   -1.0
    x_10_10         EDGE_14_15_10   -1.0
    x_10_10         EDGE_14_18_10   -1.0
    x_10_10         EDGE_14_23_10   -1.0
    x_10_10         EDGE_15_16_10   -1.0
    x_10_10         EDGE_15_23_10   -1.0
    x_10_10         EDGE_16_20_10   -1.0
    x_10_10         EDGE_17_18_10   -1.0
    x_10_10         EDGE_17_21_10   -1.0
    x_10_10         EDGE_19_24_10   -1.0
    x_10_10         EDGE_20_24_10   -1.0
    x_10_10         EDGE_25_26_10   -1.0
    x_10_10         EDGE_25_27_10   -1.0
    x_11_0          ASSIGN_11       1.0
    x_11_0          LINK_11_0       1.0
    x_11_0          EDGE_0_11_0     1.0
    x_11_0          EDGE_9_11_0     1.0
    x_11_0          EDGE_11_13_0    1.0
    x_11_0          EDGE_11_22_0    1.0
    x_11_1          ASSIGN_11       1.0
    x_11_1          LINK_11_1       1.0
    x_11_1          EDGE_9_11_1     1.0
    x_11_1          EDGE_11_13_1    1.0
    x_11_1          EDGE_11_22_1    1.0
    x_11_2          ASSIGN_11       1.0
    x_11_2          LINK_11_2       1.0
    x_11_2          EDGE_9_11_2     1.0
    x_11_2          EDGE_11_13_2    1.0
    x_11_2          EDGE_11_22_2    1.0
    x_11_3          ASSIGN_11       1.0
    x_11_3          LINK_11_3       1.0
    x_11_3          EDGE_9_11_3     1.0
    x_11_3          EDGE_11_13_3    1.0
    x_11_3          EDGE_11_22_3    1.0
    x_11_4          ASSIGN_11       1.0
    x_11_4          LINK_11_4       1.0
    x_11_4          EDGE_9_11_4     1.0
    x_11_4          EDGE_11_13_4    1.0
    x_11_4          EDGE_11_22_4    1.0
    x_11_5          ASSIGN_11       1.0
    x_11_5          LINK_11_5       1.0
    x_11_5          EDGE_9_11_5     1.0
    x_11_5          EDGE_11_13_5    1.0
    x_11_5          EDGE_11_22_5    1.0
    x_11_6          ASSIGN_11       1.0
    x_11_6          LINK_11_6       1.0
    x_11_6          EDGE_9_11_6     1.0
    x_11_6          EDGE_11_13_6    1.0
    x_11_6          EDGE_11_22_6    1.0
    x_11_7          ASSIGN_11       1.0
    x_11_7          LINK_11_7       1.0
    x_11_7          EDGE_9_11_7     1.0
    x_11_7          EDGE_11_13_7    1.0
    x_11_7          EDGE_11_22_7    1.0
    x_11_8          ASSIGN_11       1.0
    x_11_8          LINK_11_8       1.0
    x_11_8          EDGE_9_11_8     1.0
    x_11_8          EDGE_11_13_8    1.0
    x_11_8          EDGE_11_22_8    1.0
    x_11_9          ASSIGN_11       1.0
    x_11_9          LINK_11_9       1.0
    x_11_9          EDGE_9_11_9     1.0
    x_11_9          EDGE_11_13_9    1.0
    x_11_9          EDGE_11_22_9    1.0
    x_11_10         ASSIGN_11       1.0
    x_11_10         LINK_11_10      1.0
    x_11_10         EDGE_11_13_10   1.0
    x_11_10         EDGE_11_22_10   1.0
    x_11_11         OBJ           1.0
    x_11_11         ASSIGN_11       1.0
    x_11_11         LINK_12_11      -1.0
    x_11_11         LINK_13_11      -1.0
    x_11_11         LINK_14_11      -1.0
    x_11_11         LINK_15_11      -1.0
    x_11_11         LINK_16_11      -1.0
    x_11_11         LINK_17_11      -1.0
    x_11_11         LINK_18_11      -1.0
    x_11_11         LINK_19_11      -1.0
    x_11_11         LINK_20_11      -1.0
    x_11_11         LINK_21_11      -1.0
    x_11_11         LINK_22_11      -1.0
    x_11_11         LINK_23_11      -1.0
    x_11_11         LINK_24_11      -1.0
    x_11_11         LINK_25_11      -1.0
    x_11_11         LINK_26_11      -1.0
    x_11_11         LINK_27_11      -1.0
    x_11_11         EDGE_11_13_11   1.0
    x_11_11         EDGE_11_22_11   1.0
    x_11_11         EDGE_12_13_11   -1.0
    x_11_11         EDGE_13_19_11   -1.0
    x_11_11         EDGE_14_15_11   -1.0
    x_11_11         EDGE_14_18_11   -1.0
    x_11_11         EDGE_14_23_11   -1.0
    x_11_11         EDGE_15_16_11   -1.0
    x_11_11         EDGE_15_23_11   -1.0
    x_11_11         EDGE_16_20_11   -1.0
    x_11_11         EDGE_17_18_11   -1.0
    x_11_11         EDGE_17_21_11   -1.0
    x_11_11         EDGE_19_24_11   -1.0
    x_11_11         EDGE_20_24_11   -1.0
    x_11_11         EDGE_25_26_11   -1.0
    x_11_11         EDGE_25_27_11   -1.0
    x_12_0          ASSIGN_12       1.0
    x_12_0          LINK_12_0       1.0
    x_12_0          EDGE_0_12_0     1.0
    x_12_0          EDGE_3_12_0     1.0
    x_12_0          EDGE_6_12_0     1.0
    x_12_0          EDGE_12_13_0    1.0
    x_12_1          ASSIGN_12       1.0
    x_12_1          LINK_12_1       1.0
    x_12_1          EDGE_3_12_1     1.0
    x_12_1          EDGE_6_12_1     1.0
    x_12_1          EDGE_12_13_1    1.0
    x_12_2          ASSIGN_12       1.0
    x_12_2          LINK_12_2       1.0
    x_12_2          EDGE_3_12_2     1.0
    x_12_2          EDGE_6_12_2     1.0
    x_12_2          EDGE_12_13_2    1.0
    x_12_3          ASSIGN_12       1.0
    x_12_3          LINK_12_3       1.0
    x_12_3          EDGE_3_12_3     1.0
    x_12_3          EDGE_6_12_3     1.0
    x_12_3          EDGE_12_13_3    1.0
    x_12_4          ASSIGN_12       1.0
    x_12_4          LINK_12_4       1.0
    x_12_4          EDGE_6_12_4     1.0
    x_12_4          EDGE_12_13_4    1.0
    x_12_5          ASSIGN_12       1.0
    x_12_5          LINK_12_5       1.0
    x_12_5          EDGE_6_12_5     1.0
    x_12_5          EDGE_12_13_5    1.0
    x_12_6          ASSIGN_12       1.0
    x_12_6          LINK_12_6       1.0
    x_12_6          EDGE_6_12_6     1.0
    x_12_6          EDGE_12_13_6    1.0
    x_12_7          ASSIGN_12       1.0
    x_12_7          LINK_12_7       1.0
    x_12_7          EDGE_12_13_7    1.0
    x_12_8          ASSIGN_12       1.0
    x_12_8          LINK_12_8       1.0
    x_12_8          EDGE_12_13_8    1.0
    x_12_9          ASSIGN_12       1.0
    x_12_9          LINK_12_9       1.0
    x_12_9          EDGE_12_13_9    1.0
    x_12_10         ASSIGN_12       1.0
    x_12_10         LINK_12_10      1.0
    x_12_10         EDGE_12_13_10   1.0
    x_12_11         ASSIGN_12       1.0
    x_12_11         LINK_12_11      1.0
    x_12_11         EDGE_12_13_11   1.0
    x_12_12         OBJ           1.0
    x_12_12         ASSIGN_12       1.0
    x_12_12         LINK_13_12      -1.0
    x_12_12         LINK_14_12      -1.0
    x_12_12         LINK_15_12      -1.0
    x_12_12         LINK_16_12      -1.0
    x_12_12         LINK_17_12      -1.0
    x_12_12         LINK_18_12      -1.0
    x_12_12         LINK_19_12      -1.0
    x_12_12         LINK_20_12      -1.0
    x_12_12         LINK_21_12      -1.0
    x_12_12         LINK_22_12      -1.0
    x_12_12         LINK_23_12      -1.0
    x_12_12         LINK_24_12      -1.0
    x_12_12         LINK_25_12      -1.0
    x_12_12         LINK_26_12      -1.0
    x_12_12         LINK_27_12      -1.0
    x_12_12         EDGE_12_13_12   1.0
    x_12_12         EDGE_13_19_12   -1.0
    x_12_12         EDGE_14_15_12   -1.0
    x_12_12         EDGE_14_18_12   -1.0
    x_12_12         EDGE_14_23_12   -1.0
    x_12_12         EDGE_15_16_12   -1.0
    x_12_12         EDGE_15_23_12   -1.0
    x_12_12         EDGE_16_20_12   -1.0
    x_12_12         EDGE_17_18_12   -1.0
    x_12_12         EDGE_17_21_12   -1.0
    x_12_12         EDGE_19_24_12   -1.0
    x_12_12         EDGE_20_24_12   -1.0
    x_12_12         EDGE_25_26_12   -1.0
    x_12_12         EDGE_25_27_12   -1.0
    x_13_0          ASSIGN_13       1.0
    x_13_0          LINK_13_0       1.0
    x_13_0          EDGE_0_13_0     1.0
    x_13_0          EDGE_11_13_0    1.0
    x_13_0          EDGE_12_13_0    1.0
    x_13_0          EDGE_13_19_0    1.0
    x_13_1          ASSIGN_13       1.0
    x_13_1          LINK_13_1       1.0
    x_13_1          EDGE_11_13_1    1.0
    x_13_1          EDGE_12_13_1    1.0
    x_13_1          EDGE_13_19_1    1.0
    x_13_2          ASSIGN_13       1.0
    x_13_2          LINK_13_2       1.0
    x_13_2          EDGE_11_13_2    1.0
    x_13_2          EDGE_12_13_2    1.0
    x_13_2          EDGE_13_19_2    1.0
    x_13_3          ASSIGN_13       1.0
    x_13_3          LINK_13_3       1.0
    x_13_3          EDGE_11_13_3    1.0
    x_13_3          EDGE_12_13_3    1.0
    x_13_3          EDGE_13_19_3    1.0
    x_13_4          ASSIGN_13       1.0
    x_13_4          LINK_13_4       1.0
    x_13_4          EDGE_11_13_4    1.0
    x_13_4          EDGE_12_13_4    1.0
    x_13_4          EDGE_13_19_4    1.0
    x_13_5          ASSIGN_13       1.0
    x_13_5          LINK_13_5       1.0
    x_13_5          EDGE_11_13_5    1.0
    x_13_5          EDGE_12_13_5    1.0
    x_13_5          EDGE_13_19_5    1.0
    x_13_6          ASSIGN_13       1.0
    x_13_6          LINK_13_6       1.0
    x_13_6          EDGE_11_13_6    1.0
    x_13_6          EDGE_12_13_6    1.0
    x_13_6          EDGE_13_19_6    1.0
    x_13_7          ASSIGN_13       1.0
    x_13_7          LINK_13_7       1.0
    x_13_7          EDGE_11_13_7    1.0
    x_13_7          EDGE_12_13_7    1.0
    x_13_7          EDGE_13_19_7    1.0
    x_13_8          ASSIGN_13       1.0
    x_13_8          LINK_13_8       1.0
    x_13_8          EDGE_11_13_8    1.0
    x_13_8          EDGE_12_13_8    1.0
    x_13_8          EDGE_13_19_8    1.0
    x_13_9          ASSIGN_13       1.0
    x_13_9          LINK_13_9       1.0
    x_13_9          EDGE_11_13_9    1.0
    x_13_9          EDGE_12_13_9    1.0
    x_13_9          EDGE_13_19_9    1.0
    x_13_10         ASSIGN_13       1.0
    x_13_10         LINK_13_10      1.0
    x_13_10         EDGE_11_13_10   1.0
    x_13_10         EDGE_12_13_10   1.0
    x_13_10         EDGE_13_19_10   1.0
    x_13_11         ASSIGN_13       1.0
    x_13_11         LINK_13_11      1.0
    x_13_11         EDGE_11_13_11   1.0
    x_13_11         EDGE_12_13_11   1.0
    x_13_11         EDGE_13_19_11   1.0
    x_13_12         ASSIGN_13       1.0
    x_13_12         LINK_13_12      1.0
    x_13_12         EDGE_12_13_12   1.0
    x_13_12         EDGE_13_19_12   1.0
    x_13_13         OBJ           1.0
    x_13_13         ASSIGN_13       1.0
    x_13_13         LINK_14_13      -1.0
    x_13_13         LINK_15_13      -1.0
    x_13_13         LINK_16_13      -1.0
    x_13_13         LINK_17_13      -1.0
    x_13_13         LINK_18_13      -1.0
    x_13_13         LINK_19_13      -1.0
    x_13_13         LINK_20_13      -1.0
    x_13_13         LINK_21_13      -1.0
    x_13_13         LINK_22_13      -1.0
    x_13_13         LINK_23_13      -1.0
    x_13_13         LINK_24_13      -1.0
    x_13_13         LINK_25_13      -1.0
    x_13_13         LINK_26_13      -1.0
    x_13_13         LINK_27_13      -1.0
    x_13_13         EDGE_13_19_13   1.0
    x_13_13         EDGE_14_15_13   -1.0
    x_13_13         EDGE_14_18_13   -1.0
    x_13_13         EDGE_14_23_13   -1.0
    x_13_13         EDGE_15_16_13   -1.0
    x_13_13         EDGE_15_23_13   -1.0
    x_13_13         EDGE_16_20_13   -1.0
    x_13_13         EDGE_17_18_13   -1.0
    x_13_13         EDGE_17_21_13   -1.0
    x_13_13         EDGE_19_24_13   -1.0
    x_13_13         EDGE_20_24_13   -1.0
    x_13_13         EDGE_25_26_13   -1.0
    x_13_13         EDGE_25_27_13   -1.0
    x_14_0          ASSIGN_14       1.0
    x_14_0          LINK_14_0       1.0
    x_14_0          EDGE_4_14_0     1.0
    x_14_0          EDGE_14_15_0    1.0
    x_14_0          EDGE_14_18_0    1.0
    x_14_0          EDGE_14_23_0    1.0
    x_14_1          ASSIGN_14       1.0
    x_14_1          LINK_14_1       1.0
    x_14_1          EDGE_4_14_1     1.0
    x_14_1          EDGE_14_15_1    1.0
    x_14_1          EDGE_14_18_1    1.0
    x_14_1          EDGE_14_23_1    1.0
    x_14_2          ASSIGN_14       1.0
    x_14_2          LINK_14_2       1.0
    x_14_2          EDGE_4_14_2     1.0
    x_14_2          EDGE_14_15_2    1.0
    x_14_2          EDGE_14_18_2    1.0
    x_14_2          EDGE_14_23_2    1.0
    x_14_3          ASSIGN_14       1.0
    x_14_3          LINK_14_3       1.0
    x_14_3          EDGE_4_14_3     1.0
    x_14_3          EDGE_14_15_3    1.0
    x_14_3          EDGE_14_18_3    1.0
    x_14_3          EDGE_14_23_3    1.0
    x_14_4          ASSIGN_14       1.0
    x_14_4          LINK_14_4       1.0
    x_14_4          EDGE_4_14_4     1.0
    x_14_4          EDGE_14_15_4    1.0
    x_14_4          EDGE_14_18_4    1.0
    x_14_4          EDGE_14_23_4    1.0
    x_14_5          ASSIGN_14       1.0
    x_14_5          LINK_14_5       1.0
    x_14_5          EDGE_14_15_5    1.0
    x_14_5          EDGE_14_18_5    1.0
    x_14_5          EDGE_14_23_5    1.0
    x_14_6          ASSIGN_14       1.0
    x_14_6          LINK_14_6       1.0
    x_14_6          EDGE_14_15_6    1.0
    x_14_6          EDGE_14_18_6    1.0
    x_14_6          EDGE_14_23_6    1.0
    x_14_7          ASSIGN_14       1.0
    x_14_7          LINK_14_7       1.0
    x_14_7          EDGE_14_15_7    1.0
    x_14_7          EDGE_14_18_7    1.0
    x_14_7          EDGE_14_23_7    1.0
    x_14_8          ASSIGN_14       1.0
    x_14_8          LINK_14_8       1.0
    x_14_8          EDGE_14_15_8    1.0
    x_14_8          EDGE_14_18_8    1.0
    x_14_8          EDGE_14_23_8    1.0
    x_14_9          ASSIGN_14       1.0
    x_14_9          LINK_14_9       1.0
    x_14_9          EDGE_14_15_9    1.0
    x_14_9          EDGE_14_18_9    1.0
    x_14_9          EDGE_14_23_9    1.0
    x_14_10         ASSIGN_14       1.0
    x_14_10         LINK_14_10      1.0
    x_14_10         EDGE_14_15_10   1.0
    x_14_10         EDGE_14_18_10   1.0
    x_14_10         EDGE_14_23_10   1.0
    x_14_11         ASSIGN_14       1.0
    x_14_11         LINK_14_11      1.0
    x_14_11         EDGE_14_15_11   1.0
    x_14_11         EDGE_14_18_11   1.0
    x_14_11         EDGE_14_23_11   1.0
    x_14_12         ASSIGN_14       1.0
    x_14_12         LINK_14_12      1.0
    x_14_12         EDGE_14_15_12   1.0
    x_14_12         EDGE_14_18_12   1.0
    x_14_12         EDGE_14_23_12   1.0
    x_14_13         ASSIGN_14       1.0
    x_14_13         LINK_14_13      1.0
    x_14_13         EDGE_14_15_13   1.0
    x_14_13         EDGE_14_18_13   1.0
    x_14_13         EDGE_14_23_13   1.0
    x_14_14         OBJ           1.0
    x_14_14         ASSIGN_14       1.0
    x_14_14         LINK_15_14      -1.0
    x_14_14         LINK_16_14      -1.0
    x_14_14         LINK_17_14      -1.0
    x_14_14         LINK_18_14      -1.0
    x_14_14         LINK_19_14      -1.0
    x_14_14         LINK_20_14      -1.0
    x_14_14         LINK_21_14      -1.0
    x_14_14         LINK_22_14      -1.0
    x_14_14         LINK_23_14      -1.0
    x_14_14         LINK_24_14      -1.0
    x_14_14         LINK_25_14      -1.0
    x_14_14         LINK_26_14      -1.0
    x_14_14         LINK_27_14      -1.0
    x_14_14         EDGE_14_15_14   1.0
    x_14_14         EDGE_14_18_14   1.0
    x_14_14         EDGE_14_23_14   1.0
    x_14_14         EDGE_15_16_14   -1.0
    x_14_14         EDGE_15_23_14   -1.0
    x_14_14         EDGE_16_20_14   -1.0
    x_14_14         EDGE_17_18_14   -1.0
    x_14_14         EDGE_17_21_14   -1.0
    x_14_14         EDGE_19_24_14   -1.0
    x_14_14         EDGE_20_24_14   -1.0
    x_14_14         EDGE_25_26_14   -1.0
    x_14_14         EDGE_25_27_14   -1.0
    x_15_0          ASSIGN_15       1.0
    x_15_0          LINK_15_0       1.0
    x_15_0          EDGE_4_15_0     1.0
    x_15_0          EDGE_14_15_0    1.0
    x_15_0          EDGE_15_16_0    1.0
    x_15_0          EDGE_15_23_0    1.0
    x_15_1          ASSIGN_15       1.0
    x_15_1          LINK_15_1       1.0
    x_15_1          EDGE_4_15_1     1.0
    x_15_1          EDGE_14_15_1    1.0
    x_15_1          EDGE_15_16_1    1.0
    x_15_1          EDGE_15_23_1    1.0
    x_15_2          ASSIGN_15       1.0
    x_15_2          LINK_15_2       1.0
    x_15_2          EDGE_4_15_2     1.0
    x_15_2          EDGE_14_15_2    1.0
    x_15_2          EDGE_15_16_2    1.0
    x_15_2          EDGE_15_23_2    1.0
    x_15_3          ASSIGN_15       1.0
    x_15_3          LINK_15_3       1.0
    x_15_3          EDGE_4_15_3     1.0
    x_15_3          EDGE_14_15_3    1.0
    x_15_3          EDGE_15_16_3    1.0
    x_15_3          EDGE_15_23_3    1.0
    x_15_4          ASSIGN_15       1.0
    x_15_4          LINK_15_4       1.0
    x_15_4          EDGE_4_15_4     1.0
    x_15_4          EDGE_14_15_4    1.0
    x_15_4          EDGE_15_16_4    1.0
    x_15_4          EDGE_15_23_4    1.0
    x_15_5          ASSIGN_15       1.0
    x_15_5          LINK_15_5       1.0
    x_15_5          EDGE_14_15_5    1.0
    x_15_5          EDGE_15_16_5    1.0
    x_15_5          EDGE_15_23_5    1.0
    x_15_6          ASSIGN_15       1.0
    x_15_6          LINK_15_6       1.0
    x_15_6          EDGE_14_15_6    1.0
    x_15_6          EDGE_15_16_6    1.0
    x_15_6          EDGE_15_23_6    1.0
    x_15_7          ASSIGN_15       1.0
    x_15_7          LINK_15_7       1.0
    x_15_7          EDGE_14_15_7    1.0
    x_15_7          EDGE_15_16_7    1.0
    x_15_7          EDGE_15_23_7    1.0
    x_15_8          ASSIGN_15       1.0
    x_15_8          LINK_15_8       1.0
    x_15_8          EDGE_14_15_8    1.0
    x_15_8          EDGE_15_16_8    1.0
    x_15_8          EDGE_15_23_8    1.0
    x_15_9          ASSIGN_15       1.0
    x_15_9          LINK_15_9       1.0
    x_15_9          EDGE_14_15_9    1.0
    x_15_9          EDGE_15_16_9    1.0
    x_15_9          EDGE_15_23_9    1.0
    x_15_10         ASSIGN_15       1.0
    x_15_10         LINK_15_10      1.0
    x_15_10         EDGE_14_15_10   1.0
    x_15_10         EDGE_15_16_10   1.0
    x_15_10         EDGE_15_23_10   1.0
    x_15_11         ASSIGN_15       1.0
    x_15_11         LINK_15_11      1.0
    x_15_11         EDGE_14_15_11   1.0
    x_15_11         EDGE_15_16_11   1.0
    x_15_11         EDGE_15_23_11   1.0
    x_15_12         ASSIGN_15       1.0
    x_15_12         LINK_15_12      1.0
    x_15_12         EDGE_14_15_12   1.0
    x_15_12         EDGE_15_16_12   1.0
    x_15_12         EDGE_15_23_12   1.0
    x_15_13         ASSIGN_15       1.0
    x_15_13         LINK_15_13      1.0
    x_15_13         EDGE_14_15_13   1.0
    x_15_13         EDGE_15_16_13   1.0
    x_15_13         EDGE_15_23_13   1.0
    x_15_14         ASSIGN_15       1.0
    x_15_14         LINK_15_14      1.0
    x_15_14         EDGE_14_15_14   1.0
    x_15_14         EDGE_15_16_14   1.0
    x_15_14         EDGE_15_23_14   1.0
    x_15_15         OBJ           1.0
    x_15_15         ASSIGN_15       1.0
    x_15_15         LINK_16_15      -1.0
    x_15_15         LINK_17_15      -1.0
    x_15_15         LINK_18_15      -1.0
    x_15_15         LINK_19_15      -1.0
    x_15_15         LINK_20_15      -1.0
    x_15_15         LINK_21_15      -1.0
    x_15_15         LINK_22_15      -1.0
    x_15_15         LINK_23_15      -1.0
    x_15_15         LINK_24_15      -1.0
    x_15_15         LINK_25_15      -1.0
    x_15_15         LINK_26_15      -1.0
    x_15_15         LINK_27_15      -1.0
    x_15_15         EDGE_15_16_15   1.0
    x_15_15         EDGE_15_23_15   1.0
    x_15_15         EDGE_16_20_15   -1.0
    x_15_15         EDGE_17_18_15   -1.0
    x_15_15         EDGE_17_21_15   -1.0
    x_15_15         EDGE_19_24_15   -1.0
    x_15_15         EDGE_20_24_15   -1.0
    x_15_15         EDGE_25_26_15   -1.0
    x_15_15         EDGE_25_27_15   -1.0
    x_16_0          ASSIGN_16       1.0
    x_16_0          LINK_16_0       1.0
    x_16_0          EDGE_4_16_0     1.0
    x_16_0          EDGE_5_16_0     1.0
    x_16_0          EDGE_15_16_0    1.0
    x_16_0          EDGE_16_20_0    1.0
    x_16_1          ASSIGN_16       1.0
    x_16_1          LINK_16_1       1.0
    x_16_1          EDGE_4_16_1     1.0
    x_16_1          EDGE_5_16_1     1.0
    x_16_1          EDGE_15_16_1    1.0
    x_16_1          EDGE_16_20_1    1.0
    x_16_2          ASSIGN_16       1.0
    x_16_2          LINK_16_2       1.0
    x_16_2          EDGE_4_16_2     1.0
    x_16_2          EDGE_5_16_2     1.0
    x_16_2          EDGE_15_16_2    1.0
    x_16_2          EDGE_16_20_2    1.0
    x_16_3          ASSIGN_16       1.0
    x_16_3          LINK_16_3       1.0
    x_16_3          EDGE_4_16_3     1.0
    x_16_3          EDGE_5_16_3     1.0
    x_16_3          EDGE_15_16_3    1.0
    x_16_3          EDGE_16_20_3    1.0
    x_16_4          ASSIGN_16       1.0
    x_16_4          LINK_16_4       1.0
    x_16_4          EDGE_4_16_4     1.0
    x_16_4          EDGE_5_16_4     1.0
    x_16_4          EDGE_15_16_4    1.0
    x_16_4          EDGE_16_20_4    1.0
    x_16_5          ASSIGN_16       1.0
    x_16_5          LINK_16_5       1.0
    x_16_5          EDGE_5_16_5     1.0
    x_16_5          EDGE_15_16_5    1.0
    x_16_5          EDGE_16_20_5    1.0
    x_16_6          ASSIGN_16       1.0
    x_16_6          LINK_16_6       1.0
    x_16_6          EDGE_15_16_6    1.0
    x_16_6          EDGE_16_20_6    1.0
    x_16_7          ASSIGN_16       1.0
    x_16_7          LINK_16_7       1.0
    x_16_7          EDGE_15_16_7    1.0
    x_16_7          EDGE_16_20_7    1.0
    x_16_8          ASSIGN_16       1.0
    x_16_8          LINK_16_8       1.0
    x_16_8          EDGE_15_16_8    1.0
    x_16_8          EDGE_16_20_8    1.0
    x_16_9          ASSIGN_16       1.0
    x_16_9          LINK_16_9       1.0
    x_16_9          EDGE_15_16_9    1.0
    x_16_9          EDGE_16_20_9    1.0
    x_16_10         ASSIGN_16       1.0
    x_16_10         LINK_16_10      1.0
    x_16_10         EDGE_15_16_10   1.0
    x_16_10         EDGE_16_20_10   1.0
    x_16_11         ASSIGN_16       1.0
    x_16_11         LINK_16_11      1.0
    x_16_11         EDGE_15_16_11   1.0
    x_16_11         EDGE_16_20_11   1.0
    x_16_12         ASSIGN_16       1.0
    x_16_12         LINK_16_12      1.0
    x_16_12         EDGE_15_16_12   1.0
    x_16_12         EDGE_16_20_12   1.0
    x_16_13         ASSIGN_16       1.0
    x_16_13         LINK_16_13      1.0
    x_16_13         EDGE_15_16_13   1.0
    x_16_13         EDGE_16_20_13   1.0
    x_16_14         ASSIGN_16       1.0
    x_16_14         LINK_16_14      1.0
    x_16_14         EDGE_15_16_14   1.0
    x_16_14         EDGE_16_20_14   1.0
    x_16_15         ASSIGN_16       1.0
    x_16_15         LINK_16_15      1.0
    x_16_15         EDGE_15_16_15   1.0
    x_16_15         EDGE_16_20_15   1.0
    x_16_16         OBJ           1.0
    x_16_16         ASSIGN_16       1.0
    x_16_16         LINK_17_16      -1.0
    x_16_16         LINK_18_16      -1.0
    x_16_16         LINK_19_16      -1.0
    x_16_16         LINK_20_16      -1.0
    x_16_16         LINK_21_16      -1.0
    x_16_16         LINK_22_16      -1.0
    x_16_16         LINK_23_16      -1.0
    x_16_16         LINK_24_16      -1.0
    x_16_16         LINK_25_16      -1.0
    x_16_16         LINK_26_16      -1.0
    x_16_16         LINK_27_16      -1.0
    x_16_16         EDGE_16_20_16   1.0
    x_16_16         EDGE_17_18_16   -1.0
    x_16_16         EDGE_17_21_16   -1.0
    x_16_16         EDGE_19_24_16   -1.0
    x_16_16         EDGE_20_24_16   -1.0
    x_16_16         EDGE_25_26_16   -1.0
    x_16_16         EDGE_25_27_16   -1.0
    x_17_0          ASSIGN_17       1.0
    x_17_0          LINK_17_0       1.0
    x_17_0          EDGE_10_17_0    1.0
    x_17_0          EDGE_17_18_0    1.0
    x_17_0          EDGE_17_21_0    1.0
    x_17_1          ASSIGN_17       1.0
    x_17_1          LINK_17_1       1.0
    x_17_1          EDGE_10_17_1    1.0
    x_17_1          EDGE_17_18_1    1.0
    x_17_1          EDGE_17_21_1    1.0
    x_17_2          ASSIGN_17       1.0
    x_17_2          LINK_17_2       1.0
    x_17_2          EDGE_10_17_2    1.0
    x_17_2          EDGE_17_18_2    1.0
    x_17_2          EDGE_17_21_2    1.0
    x_17_3          ASSIGN_17       1.0
    x_17_3          LINK_17_3       1.0
    x_17_3          EDGE_10_17_3    1.0
    x_17_3          EDGE_17_18_3    1.0
    x_17_3          EDGE_17_21_3    1.0
    x_17_4          ASSIGN_17       1.0
    x_17_4          LINK_17_4       1.0
    x_17_4          EDGE_10_17_4    1.0
    x_17_4          EDGE_17_18_4    1.0
    x_17_4          EDGE_17_21_4    1.0
    x_17_5          ASSIGN_17       1.0
    x_17_5          LINK_17_5       1.0
    x_17_5          EDGE_10_17_5    1.0
    x_17_5          EDGE_17_18_5    1.0
    x_17_5          EDGE_17_21_5    1.0
    x_17_6          ASSIGN_17       1.0
    x_17_6          LINK_17_6       1.0
    x_17_6          EDGE_10_17_6    1.0
    x_17_6          EDGE_17_18_6    1.0
    x_17_6          EDGE_17_21_6    1.0
    x_17_7          ASSIGN_17       1.0
    x_17_7          LINK_17_7       1.0
    x_17_7          EDGE_10_17_7    1.0
    x_17_7          EDGE_17_18_7    1.0
    x_17_7          EDGE_17_21_7    1.0
    x_17_8          ASSIGN_17       1.0
    x_17_8          LINK_17_8       1.0
    x_17_8          EDGE_10_17_8    1.0
    x_17_8          EDGE_17_18_8    1.0
    x_17_8          EDGE_17_21_8    1.0
    x_17_9          ASSIGN_17       1.0
    x_17_9          LINK_17_9       1.0
    x_17_9          EDGE_10_17_9    1.0
    x_17_9          EDGE_17_18_9    1.0
    x_17_9          EDGE_17_21_9    1.0
    x_17_10         ASSIGN_17       1.0
    x_17_10         LINK_17_10      1.0
    x_17_10         EDGE_10_17_10   1.0
    x_17_10         EDGE_17_18_10   1.0
    x_17_10         EDGE_17_21_10   1.0
    x_17_11         ASSIGN_17       1.0
    x_17_11         LINK_17_11      1.0
    x_17_11         EDGE_17_18_11   1.0
    x_17_11         EDGE_17_21_11   1.0
    x_17_12         ASSIGN_17       1.0
    x_17_12         LINK_17_12      1.0
    x_17_12         EDGE_17_18_12   1.0
    x_17_12         EDGE_17_21_12   1.0
    x_17_13         ASSIGN_17       1.0
    x_17_13         LINK_17_13      1.0
    x_17_13         EDGE_17_18_13   1.0
    x_17_13         EDGE_17_21_13   1.0
    x_17_14         ASSIGN_17       1.0
    x_17_14         LINK_17_14      1.0
    x_17_14         EDGE_17_18_14   1.0
    x_17_14         EDGE_17_21_14   1.0
    x_17_15         ASSIGN_17       1.0
    x_17_15         LINK_17_15      1.0
    x_17_15         EDGE_17_18_15   1.0
    x_17_15         EDGE_17_21_15   1.0
    x_17_16         ASSIGN_17       1.0
    x_17_16         LINK_17_16      1.0
    x_17_16         EDGE_17_18_16   1.0
    x_17_16         EDGE_17_21_16   1.0
    x_17_17         OBJ           1.0
    x_17_17         ASSIGN_17       1.0
    x_17_17         LINK_18_17      -1.0
    x_17_17         LINK_19_17      -1.0
    x_17_17         LINK_20_17      -1.0
    x_17_17         LINK_21_17      -1.0
    x_17_17         LINK_22_17      -1.0
    x_17_17         LINK_23_17      -1.0
    x_17_17         LINK_24_17      -1.0
    x_17_17         LINK_25_17      -1.0
    x_17_17         LINK_26_17      -1.0
    x_17_17         LINK_27_17      -1.0
    x_17_17         EDGE_17_18_17   1.0
    x_17_17         EDGE_17_21_17   1.0
    x_17_17         EDGE_19_24_17   -1.0
    x_17_17         EDGE_20_24_17   -1.0
    x_17_17         EDGE_25_26_17   -1.0
    x_17_17         EDGE_25_27_17   -1.0
    x_18_0          ASSIGN_18       1.0
    x_18_0          LINK_18_0       1.0
    x_18_0          EDGE_2_18_0     1.0
    x_18_0          EDGE_14_18_0    1.0
    x_18_0          EDGE_17_18_0    1.0
    x_18_1          ASSIGN_18       1.0
    x_18_1          LINK_18_1       1.0
    x_18_1          EDGE_2_18_1     1.0
    x_18_1          EDGE_14_18_1    1.0
    x_18_1          EDGE_17_18_1    1.0
    x_18_2          ASSIGN_18       1.0
    x_18_2          LINK_18_2       1.0
    x_18_2          EDGE_2_18_2     1.0
    x_18_2          EDGE_14_18_2    1.0
    x_18_2          EDGE_17_18_2    1.0
    x_18_3          ASSIGN_18       1.0
    x_18_3          LINK_18_3       1.0
    x_18_3          EDGE_14_18_3    1.0
    x_18_3          EDGE_17_18_3    1.0
    x_18_4          ASSIGN_18       1.0
    x_18_4          LINK_18_4       1.0
    x_18_4          EDGE_14_18_4    1.0
    x_18_4          EDGE_17_18_4    1.0
    x_18_5          ASSIGN_18       1.0
    x_18_5          LINK_18_5       1.0
    x_18_5          EDGE_14_18_5    1.0
    x_18_5          EDGE_17_18_5    1.0
    x_18_6          ASSIGN_18       1.0
    x_18_6          LINK_18_6       1.0
    x_18_6          EDGE_14_18_6    1.0
    x_18_6          EDGE_17_18_6    1.0
    x_18_7          ASSIGN_18       1.0
    x_18_7          LINK_18_7       1.0
    x_18_7          EDGE_14_18_7    1.0
    x_18_7          EDGE_17_18_7    1.0
    x_18_8          ASSIGN_18       1.0
    x_18_8          LINK_18_8       1.0
    x_18_8          EDGE_14_18_8    1.0
    x_18_8          EDGE_17_18_8    1.0
    x_18_9          ASSIGN_18       1.0
    x_18_9          LINK_18_9       1.0
    x_18_9          EDGE_14_18_9    1.0
    x_18_9          EDGE_17_18_9    1.0
    x_18_10         ASSIGN_18       1.0
    x_18_10         LINK_18_10      1.0
    x_18_10         EDGE_14_18_10   1.0
    x_18_10         EDGE_17_18_10   1.0
    x_18_11         ASSIGN_18       1.0
    x_18_11         LINK_18_11      1.0
    x_18_11         EDGE_14_18_11   1.0
    x_18_11         EDGE_17_18_11   1.0
    x_18_12         ASSIGN_18       1.0
    x_18_12         LINK_18_12      1.0
    x_18_12         EDGE_14_18_12   1.0
    x_18_12         EDGE_17_18_12   1.0
    x_18_13         ASSIGN_18       1.0
    x_18_13         LINK_18_13      1.0
    x_18_13         EDGE_14_18_13   1.0
    x_18_13         EDGE_17_18_13   1.0
    x_18_14         ASSIGN_18       1.0
    x_18_14         LINK_18_14      1.0
    x_18_14         EDGE_14_18_14   1.0
    x_18_14         EDGE_17_18_14   1.0
    x_18_15         ASSIGN_18       1.0
    x_18_15         LINK_18_15      1.0
    x_18_15         EDGE_17_18_15   1.0
    x_18_16         ASSIGN_18       1.0
    x_18_16         LINK_18_16      1.0
    x_18_16         EDGE_17_18_16   1.0
    x_18_17         ASSIGN_18       1.0
    x_18_17         LINK_18_17      1.0
    x_18_17         EDGE_17_18_17   1.0
    x_18_18         OBJ           1.0
    x_18_18         ASSIGN_18       1.0
    x_18_18         LINK_19_18      -1.0
    x_18_18         LINK_20_18      -1.0
    x_18_18         LINK_21_18      -1.0
    x_18_18         LINK_22_18      -1.0
    x_18_18         LINK_23_18      -1.0
    x_18_18         LINK_24_18      -1.0
    x_18_18         LINK_25_18      -1.0
    x_18_18         LINK_26_18      -1.0
    x_18_18         LINK_27_18      -1.0
    x_18_18         EDGE_19_24_18   -1.0
    x_18_18         EDGE_20_24_18   -1.0
    x_18_18         EDGE_25_26_18   -1.0
    x_18_18         EDGE_25_27_18   -1.0
    x_19_0          ASSIGN_19       1.0
    x_19_0          LINK_19_0       1.0
    x_19_0          EDGE_6_19_0     1.0
    x_19_0          EDGE_13_19_0    1.0
    x_19_0          EDGE_19_24_0    1.0
    x_19_1          ASSIGN_19       1.0
    x_19_1          LINK_19_1       1.0
    x_19_1          EDGE_6_19_1     1.0
    x_19_1          EDGE_13_19_1    1.0
    x_19_1          EDGE_19_24_1    1.0
    x_19_2          ASSIGN_19       1.0
    x_19_2          LINK_19_2       1.0
    x_19_2          EDGE_6_19_2     1.0
    x_19_2          EDGE_13_19_2    1.0
    x_19_2          EDGE_19_24_2    1.0
    x_19_3          ASSIGN_19       1.0
    x_19_3          LINK_19_3       1.0
    x_19_3          EDGE_6_19_3     1.0
    x_19_3          EDGE_13_19_3    1.0
    x_19_3          EDGE_19_24_3    1.0
    x_19_4          ASSIGN_19       1.0
    x_19_4          LINK_19_4       1.0
    x_19_4          EDGE_6_19_4     1.0
    x_19_4          EDGE_13_19_4    1.0
    x_19_4          EDGE_19_24_4    1.0
    x_19_5          ASSIGN_19       1.0
    x_19_5          LINK_19_5       1.0
    x_19_5          EDGE_6_19_5     1.0
    x_19_5          EDGE_13_19_5    1.0
    x_19_5          EDGE_19_24_5    1.0
    x_19_6          ASSIGN_19       1.0
    x_19_6          LINK_19_6       1.0
    x_19_6          EDGE_6_19_6     1.0
    x_19_6          EDGE_13_19_6    1.0
    x_19_6          EDGE_19_24_6    1.0
    x_19_7          ASSIGN_19       1.0
    x_19_7          LINK_19_7       1.0
    x_19_7          EDGE_13_19_7    1.0
    x_19_7          EDGE_19_24_7    1.0
    x_19_8          ASSIGN_19       1.0
    x_19_8          LINK_19_8       1.0
    x_19_8          EDGE_13_19_8    1.0
    x_19_8          EDGE_19_24_8    1.0
    x_19_9          ASSIGN_19       1.0
    x_19_9          LINK_19_9       1.0
    x_19_9          EDGE_13_19_9    1.0
    x_19_9          EDGE_19_24_9    1.0
    x_19_10         ASSIGN_19       1.0
    x_19_10         LINK_19_10      1.0
    x_19_10         EDGE_13_19_10   1.0
    x_19_10         EDGE_19_24_10   1.0
    x_19_11         ASSIGN_19       1.0
    x_19_11         LINK_19_11      1.0
    x_19_11         EDGE_13_19_11   1.0
    x_19_11         EDGE_19_24_11   1.0
    x_19_12         ASSIGN_19       1.0
    x_19_12         LINK_19_12      1.0
    x_19_12         EDGE_13_19_12   1.0
    x_19_12         EDGE_19_24_12   1.0
    x_19_13         ASSIGN_19       1.0
    x_19_13         LINK_19_13      1.0
    x_19_13         EDGE_13_19_13   1.0
    x_19_13         EDGE_19_24_13   1.0
    x_19_14         ASSIGN_19       1.0
    x_19_14         LINK_19_14      1.0
    x_19_14         EDGE_19_24_14   1.0
    x_19_15         ASSIGN_19       1.0
    x_19_15         LINK_19_15      1.0
    x_19_15         EDGE_19_24_15   1.0
    x_19_16         ASSIGN_19       1.0
    x_19_16         LINK_19_16      1.0
    x_19_16         EDGE_19_24_16   1.0
    x_19_17         ASSIGN_19       1.0
    x_19_17         LINK_19_17      1.0
    x_19_17         EDGE_19_24_17   1.0
    x_19_18         ASSIGN_19       1.0
    x_19_18         LINK_19_18      1.0
    x_19_18         EDGE_19_24_18   1.0
    x_19_19         OBJ           1.0
    x_19_19         ASSIGN_19       1.0
    x_19_19         LINK_20_19      -1.0
    x_19_19         LINK_21_19      -1.0
    x_19_19         LINK_22_19      -1.0
    x_19_19         LINK_23_19      -1.0
    x_19_19         LINK_24_19      -1.0
    x_19_19         LINK_25_19      -1.0
    x_19_19         LINK_26_19      -1.0
    x_19_19         LINK_27_19      -1.0
    x_19_19         EDGE_19_24_19   1.0
    x_19_19         EDGE_20_24_19   -1.0
    x_19_19         EDGE_25_26_19   -1.0
    x_19_19         EDGE_25_27_19   -1.0
    x_20_0          ASSIGN_20       1.0
    x_20_0          LINK_20_0       1.0
    x_20_0          EDGE_6_20_0     1.0
    x_20_0          EDGE_16_20_0    1.0
    x_20_0          EDGE_20_24_0    1.0
    x_20_1          ASSIGN_20       1.0
    x_20_1          LINK_20_1       1.0
    x_20_1          EDGE_6_20_1     1.0
    x_20_1          EDGE_16_20_1    1.0
    x_20_1          EDGE_20_24_1    1.0
    x_20_2          ASSIGN_20       1.0
    x_20_2          LINK_20_2       1.0
    x_20_2          EDGE_6_20_2     1.0
    x_20_2          EDGE_16_20_2    1.0
    x_20_2          EDGE_20_24_2    1.0
    x_20_3          ASSIGN_20       1.0
    x_20_3          LINK_20_3       1.0
    x_20_3          EDGE_6_20_3     1.0
    x_20_3          EDGE_16_20_3    1.0
    x_20_3          EDGE_20_24_3    1.0
    x_20_4          ASSIGN_20       1.0
    x_20_4          LINK_20_4       1.0
    x_20_4          EDGE_6_20_4     1.0
    x_20_4          EDGE_16_20_4    1.0
    x_20_4          EDGE_20_24_4    1.0
    x_20_5          ASSIGN_20       1.0
    x_20_5          LINK_20_5       1.0
    x_20_5          EDGE_6_20_5     1.0
    x_20_5          EDGE_16_20_5    1.0
    x_20_5          EDGE_20_24_5    1.0
    x_20_6          ASSIGN_20       1.0
    x_20_6          LINK_20_6       1.0
    x_20_6          EDGE_6_20_6     1.0
    x_20_6          EDGE_16_20_6    1.0
    x_20_6          EDGE_20_24_6    1.0
    x_20_7          ASSIGN_20       1.0
    x_20_7          LINK_20_7       1.0
    x_20_7          EDGE_16_20_7    1.0
    x_20_7          EDGE_20_24_7    1.0
    x_20_8          ASSIGN_20       1.0
    x_20_8          LINK_20_8       1.0
    x_20_8          EDGE_16_20_8    1.0
    x_20_8          EDGE_20_24_8    1.0
    x_20_9          ASSIGN_20       1.0
    x_20_9          LINK_20_9       1.0
    x_20_9          EDGE_16_20_9    1.0
    x_20_9          EDGE_20_24_9    1.0
    x_20_10         ASSIGN_20       1.0
    x_20_10         LINK_20_10      1.0
    x_20_10         EDGE_16_20_10   1.0
    x_20_10         EDGE_20_24_10   1.0
    x_20_11         ASSIGN_20       1.0
    x_20_11         LINK_20_11      1.0
    x_20_11         EDGE_16_20_11   1.0
    x_20_11         EDGE_20_24_11   1.0
    x_20_12         ASSIGN_20       1.0
    x_20_12         LINK_20_12      1.0
    x_20_12         EDGE_16_20_12   1.0
    x_20_12         EDGE_20_24_12   1.0
    x_20_13         ASSIGN_20       1.0
    x_20_13         LINK_20_13      1.0
    x_20_13         EDGE_16_20_13   1.0
    x_20_13         EDGE_20_24_13   1.0
    x_20_14         ASSIGN_20       1.0
    x_20_14         LINK_20_14      1.0
    x_20_14         EDGE_16_20_14   1.0
    x_20_14         EDGE_20_24_14   1.0
    x_20_15         ASSIGN_20       1.0
    x_20_15         LINK_20_15      1.0
    x_20_15         EDGE_16_20_15   1.0
    x_20_15         EDGE_20_24_15   1.0
    x_20_16         ASSIGN_20       1.0
    x_20_16         LINK_20_16      1.0
    x_20_16         EDGE_16_20_16   1.0
    x_20_16         EDGE_20_24_16   1.0
    x_20_17         ASSIGN_20       1.0
    x_20_17         LINK_20_17      1.0
    x_20_17         EDGE_20_24_17   1.0
    x_20_18         ASSIGN_20       1.0
    x_20_18         LINK_20_18      1.0
    x_20_18         EDGE_20_24_18   1.0
    x_20_19         ASSIGN_20       1.0
    x_20_19         LINK_20_19      1.0
    x_20_19         EDGE_20_24_19   1.0
    x_20_20         OBJ           1.0
    x_20_20         ASSIGN_20       1.0
    x_20_20         LINK_21_20      -1.0
    x_20_20         LINK_22_20      -1.0
    x_20_20         LINK_23_20      -1.0
    x_20_20         LINK_24_20      -1.0
    x_20_20         LINK_25_20      -1.0
    x_20_20         LINK_26_20      -1.0
    x_20_20         LINK_27_20      -1.0
    x_20_20         EDGE_20_24_20   1.0
    x_20_20         EDGE_25_26_20   -1.0
    x_20_20         EDGE_25_27_20   -1.0
    x_21_0          ASSIGN_21       1.0
    x_21_0          LINK_21_0       1.0
    x_21_0          EDGE_7_21_0     1.0
    x_21_0          EDGE_17_21_0    1.0
    x_21_1          ASSIGN_21       1.0
    x_21_1          LINK_21_1       1.0
    x_21_1          EDGE_7_21_1     1.0
    x_21_1          EDGE_17_21_1    1.0
    x_21_2          ASSIGN_21       1.0
    x_21_2          LINK_21_2       1.0
    x_21_2          EDGE_7_21_2     1.0
    x_21_2          EDGE_17_21_2    1.0
    x_21_3          ASSIGN_21       1.0
    x_21_3          LINK_21_3       1.0
    x_21_3          EDGE_7_21_3     1.0
    x_21_3          EDGE_17_21_3    1.0
    x_21_4          ASSIGN_21       1.0
    x_21_4          LINK_21_4       1.0
    x_21_4          EDGE_7_21_4     1.0
    x_21_4          EDGE_17_21_4    1.0
    x_21_5          ASSIGN_21       1.0
    x_21_5          LINK_21_5       1.0
    x_21_5          EDGE_7_21_5     1.0
    x_21_5          EDGE_17_21_5    1.0
    x_21_6          ASSIGN_21       1.0
    x_21_6          LINK_21_6       1.0
    x_21_6          EDGE_7_21_6     1.0
    x_21_6          EDGE_17_21_6    1.0
    x_21_7          ASSIGN_21       1.0
    x_21_7          LINK_21_7       1.0
    x_21_7          EDGE_7_21_7     1.0
    x_21_7          EDGE_17_21_7    1.0
    x_21_8          ASSIGN_21       1.0
    x_21_8          LINK_21_8       1.0
    x_21_8          EDGE_17_21_8    1.0
    x_21_9          ASSIGN_21       1.0
    x_21_9          LINK_21_9       1.0
    x_21_9          EDGE_17_21_9    1.0
    x_21_10         ASSIGN_21       1.0
    x_21_10         LINK_21_10      1.0
    x_21_10         EDGE_17_21_10   1.0
    x_21_11         ASSIGN_21       1.0
    x_21_11         LINK_21_11      1.0
    x_21_11         EDGE_17_21_11   1.0
    x_21_12         ASSIGN_21       1.0
    x_21_12         LINK_21_12      1.0
    x_21_12         EDGE_17_21_12   1.0
    x_21_13         ASSIGN_21       1.0
    x_21_13         LINK_21_13      1.0
    x_21_13         EDGE_17_21_13   1.0
    x_21_14         ASSIGN_21       1.0
    x_21_14         LINK_21_14      1.0
    x_21_14         EDGE_17_21_14   1.0
    x_21_15         ASSIGN_21       1.0
    x_21_15         LINK_21_15      1.0
    x_21_15         EDGE_17_21_15   1.0
    x_21_16         ASSIGN_21       1.0
    x_21_16         LINK_21_16      1.0
    x_21_16         EDGE_17_21_16   1.0
    x_21_17         ASSIGN_21       1.0
    x_21_17         LINK_21_17      1.0
    x_21_17         EDGE_17_21_17   1.0
    x_21_18         ASSIGN_21       1.0
    x_21_18         LINK_21_18      1.0
    x_21_19         ASSIGN_21       1.0
    x_21_19         LINK_21_19      1.0
    x_21_20         ASSIGN_21       1.0
    x_21_20         LINK_21_20      1.0
    x_21_21         OBJ           1.0
    x_21_21         ASSIGN_21       1.0
    x_21_21         LINK_22_21      -1.0
    x_21_21         LINK_23_21      -1.0
    x_21_21         LINK_24_21      -1.0
    x_21_21         LINK_25_21      -1.0
    x_21_21         LINK_26_21      -1.0
    x_21_21         LINK_27_21      -1.0
    x_21_21         EDGE_25_26_21   -1.0
    x_21_21         EDGE_25_27_21   -1.0
    x_22_0          ASSIGN_22       1.0
    x_22_0          LINK_22_0       1.0
    x_22_0          EDGE_9_22_0     1.0
    x_22_0          EDGE_11_22_0    1.0
    x_22_1          ASSIGN_22       1.0
    x_22_1          LINK_22_1       1.0
    x_22_1          EDGE_9_22_1     1.0
    x_22_1          EDGE_11_22_1    1.0
    x_22_2          ASSIGN_22       1.0
    x_22_2          LINK_22_2       1.0
    x_22_2          EDGE_9_22_2     1.0
    x_22_2          EDGE_11_22_2    1.0
    x_22_3          ASSIGN_22       1.0
    x_22_3          LINK_22_3       1.0
    x_22_3          EDGE_9_22_3     1.0
    x_22_3          EDGE_11_22_3    1.0
    x_22_4          ASSIGN_22       1.0
    x_22_4          LINK_22_4       1.0
    x_22_4          EDGE_9_22_4     1.0
    x_22_4          EDGE_11_22_4    1.0
    x_22_5          ASSIGN_22       1.0
    x_22_5          LINK_22_5       1.0
    x_22_5          EDGE_9_22_5     1.0
    x_22_5          EDGE_11_22_5    1.0
    x_22_6          ASSIGN_22       1.0
    x_22_6          LINK_22_6       1.0
    x_22_6          EDGE_9_22_6     1.0
    x_22_6          EDGE_11_22_6    1.0
    x_22_7          ASSIGN_22       1.0
    x_22_7          LINK_22_7       1.0
    x_22_7          EDGE_9_22_7     1.0
    x_22_7          EDGE_11_22_7    1.0
    x_22_8          ASSIGN_22       1.0
    x_22_8          LINK_22_8       1.0
    x_22_8          EDGE_9_22_8     1.0
    x_22_8          EDGE_11_22_8    1.0
    x_22_9          ASSIGN_22       1.0
    x_22_9          LINK_22_9       1.0
    x_22_9          EDGE_9_22_9     1.0
    x_22_9          EDGE_11_22_9    1.0
    x_22_10         ASSIGN_22       1.0
    x_22_10         LINK_22_10      1.0
    x_22_10         EDGE_11_22_10   1.0
    x_22_11         ASSIGN_22       1.0
    x_22_11         LINK_22_11      1.0
    x_22_11         EDGE_11_22_11   1.0
    x_22_12         ASSIGN_22       1.0
    x_22_12         LINK_22_12      1.0
    x_22_13         ASSIGN_22       1.0
    x_22_13         LINK_22_13      1.0
    x_22_14         ASSIGN_22       1.0
    x_22_14         LINK_22_14      1.0
    x_22_15         ASSIGN_22       1.0
    x_22_15         LINK_22_15      1.0
    x_22_16         ASSIGN_22       1.0
    x_22_16         LINK_22_16      1.0
    x_22_17         ASSIGN_22       1.0
    x_22_17         LINK_22_17      1.0
    x_22_18         ASSIGN_22       1.0
    x_22_18         LINK_22_18      1.0
    x_22_19         ASSIGN_22       1.0
    x_22_19         LINK_22_19      1.0
    x_22_20         ASSIGN_22       1.0
    x_22_20         LINK_22_20      1.0
    x_22_21         ASSIGN_22       1.0
    x_22_21         LINK_22_21      1.0
    x_22_22         OBJ           1.0
    x_22_22         ASSIGN_22       1.0
    x_22_22         LINK_23_22      -1.0
    x_22_22         LINK_24_22      -1.0
    x_22_22         LINK_25_22      -1.0
    x_22_22         LINK_26_22      -1.0
    x_22_22         LINK_27_22      -1.0
    x_22_22         EDGE_25_26_22   -1.0
    x_22_22         EDGE_25_27_22   -1.0
    x_23_0          ASSIGN_23       1.0
    x_23_0          LINK_23_0       1.0
    x_23_0          EDGE_14_23_0    1.0
    x_23_0          EDGE_15_23_0    1.0
    x_23_1          ASSIGN_23       1.0
    x_23_1          LINK_23_1       1.0
    x_23_1          EDGE_14_23_1    1.0
    x_23_1          EDGE_15_23_1    1.0
    x_23_2          ASSIGN_23       1.0
    x_23_2          LINK_23_2       1.0
    x_23_2          EDGE_14_23_2    1.0
    x_23_2          EDGE_15_23_2    1.0
    x_23_3          ASSIGN_23       1.0
    x_23_3          LINK_23_3       1.0
    x_23_3          EDGE_14_23_3    1.0
    x_23_3          EDGE_15_23_3    1.0
    x_23_4          ASSIGN_23       1.0
    x_23_4          LINK_23_4       1.0
    x_23_4          EDGE_14_23_4    1.0
    x_23_4          EDGE_15_23_4    1.0
    x_23_5          ASSIGN_23       1.0
    x_23_5          LINK_23_5       1.0
    x_23_5          EDGE_14_23_5    1.0
    x_23_5          EDGE_15_23_5    1.0
    x_23_6          ASSIGN_23       1.0
    x_23_6          LINK_23_6       1.0
    x_23_6          EDGE_14_23_6    1.0
    x_23_6          EDGE_15_23_6    1.0
    x_23_7          ASSIGN_23       1.0
    x_23_7          LINK_23_7       1.0
    x_23_7          EDGE_14_23_7    1.0
    x_23_7          EDGE_15_23_7    1.0
    x_23_8          ASSIGN_23       1.0
    x_23_8          LINK_23_8       1.0
    x_23_8          EDGE_14_23_8    1.0
    x_23_8          EDGE_15_23_8    1.0
    x_23_9          ASSIGN_23       1.0
    x_23_9          LINK_23_9       1.0
    x_23_9          EDGE_14_23_9    1.0
    x_23_9          EDGE_15_23_9    1.0
    x_23_10         ASSIGN_23       1.0
    x_23_10         LINK_23_10      1.0
    x_23_10         EDGE_14_23_10   1.0
    x_23_10         EDGE_15_23_10   1.0
    x_23_11         ASSIGN_23       1.0
    x_23_11         LINK_23_11      1.0
    x_23_11         EDGE_14_23_11   1.0
    x_23_11         EDGE_15_23_11   1.0
    x_23_12         ASSIGN_23       1.0
    x_23_12         LINK_23_12      1.0
    x_23_12         EDGE_14_23_12   1.0
    x_23_12         EDGE_15_23_12   1.0
    x_23_13         ASSIGN_23       1.0
    x_23_13         LINK_23_13      1.0
    x_23_13         EDGE_14_23_13   1.0
    x_23_13         EDGE_15_23_13   1.0
    x_23_14         ASSIGN_23       1.0
    x_23_14         LINK_23_14      1.0
    x_23_14         EDGE_14_23_14   1.0
    x_23_14         EDGE_15_23_14   1.0
    x_23_15         ASSIGN_23       1.0
    x_23_15         LINK_23_15      1.0
    x_23_15         EDGE_15_23_15   1.0
    x_23_16         ASSIGN_23       1.0
    x_23_16         LINK_23_16      1.0
    x_23_17         ASSIGN_23       1.0
    x_23_17         LINK_23_17      1.0
    x_23_18         ASSIGN_23       1.0
    x_23_18         LINK_23_18      1.0
    x_23_19         ASSIGN_23       1.0
    x_23_19         LINK_23_19      1.0
    x_23_20         ASSIGN_23       1.0
    x_23_20         LINK_23_20      1.0
    x_23_21         ASSIGN_23       1.0
    x_23_21         LINK_23_21      1.0
    x_23_22         ASSIGN_23       1.0
    x_23_22         LINK_23_22      1.0
    x_23_23         OBJ           1.0
    x_23_23         ASSIGN_23       1.0
    x_23_23         LINK_24_23      -1.0
    x_23_23         LINK_25_23      -1.0
    x_23_23         LINK_26_23      -1.0
    x_23_23         LINK_27_23      -1.0
    x_23_23         EDGE_25_26_23   -1.0
    x_23_23         EDGE_25_27_23   -1.0
    x_24_0          ASSIGN_24       1.0
    x_24_0          LINK_24_0       1.0
    x_24_0          EDGE_19_24_0    1.0
    x_24_0          EDGE_20_24_0    1.0
    x_24_1          ASSIGN_24       1.0
    x_24_1          LINK_24_1       1.0
    x_24_1          EDGE_19_24_1    1.0
    x_24_1          EDGE_20_24_1    1.0
    x_24_2          ASSIGN_24       1.0
    x_24_2          LINK_24_2       1.0
    x_24_2          EDGE_19_24_2    1.0
    x_24_2          EDGE_20_24_2    1.0
    x_24_3          ASSIGN_24       1.0
    x_24_3          LINK_24_3       1.0
    x_24_3          EDGE_19_24_3    1.0
    x_24_3          EDGE_20_24_3    1.0
    x_24_4          ASSIGN_24       1.0
    x_24_4          LINK_24_4       1.0
    x_24_4          EDGE_19_24_4    1.0
    x_24_4          EDGE_20_24_4    1.0
    x_24_5          ASSIGN_24       1.0
    x_24_5          LINK_24_5       1.0
    x_24_5          EDGE_19_24_5    1.0
    x_24_5          EDGE_20_24_5    1.0
    x_24_6          ASSIGN_24       1.0
    x_24_6          LINK_24_6       1.0
    x_24_6          EDGE_19_24_6    1.0
    x_24_6          EDGE_20_24_6    1.0
    x_24_7          ASSIGN_24       1.0
    x_24_7          LINK_24_7       1.0
    x_24_7          EDGE_19_24_7    1.0
    x_24_7          EDGE_20_24_7    1.0
    x_24_8          ASSIGN_24       1.0
    x_24_8          LINK_24_8       1.0
    x_24_8          EDGE_19_24_8    1.0
    x_24_8          EDGE_20_24_8    1.0
    x_24_9          ASSIGN_24       1.0
    x_24_9          LINK_24_9       1.0
    x_24_9          EDGE_19_24_9    1.0
    x_24_9          EDGE_20_24_9    1.0
    x_24_10         ASSIGN_24       1.0
    x_24_10         LINK_24_10      1.0
    x_24_10         EDGE_19_24_10   1.0
    x_24_10         EDGE_20_24_10   1.0
    x_24_11         ASSIGN_24       1.0
    x_24_11         LINK_24_11      1.0
    x_24_11         EDGE_19_24_11   1.0
    x_24_11         EDGE_20_24_11   1.0
    x_24_12         ASSIGN_24       1.0
    x_24_12         LINK_24_12      1.0
    x_24_12         EDGE_19_24_12   1.0
    x_24_12         EDGE_20_24_12   1.0
    x_24_13         ASSIGN_24       1.0
    x_24_13         LINK_24_13      1.0
    x_24_13         EDGE_19_24_13   1.0
    x_24_13         EDGE_20_24_13   1.0
    x_24_14         ASSIGN_24       1.0
    x_24_14         LINK_24_14      1.0
    x_24_14         EDGE_19_24_14   1.0
    x_24_14         EDGE_20_24_14   1.0
    x_24_15         ASSIGN_24       1.0
    x_24_15         LINK_24_15      1.0
    x_24_15         EDGE_19_24_15   1.0
    x_24_15         EDGE_20_24_15   1.0
    x_24_16         ASSIGN_24       1.0
    x_24_16         LINK_24_16      1.0
    x_24_16         EDGE_19_24_16   1.0
    x_24_16         EDGE_20_24_16   1.0
    x_24_17         ASSIGN_24       1.0
    x_24_17         LINK_24_17      1.0
    x_24_17         EDGE_19_24_17   1.0
    x_24_17         EDGE_20_24_17   1.0
    x_24_18         ASSIGN_24       1.0
    x_24_18         LINK_24_18      1.0
    x_24_18         EDGE_19_24_18   1.0
    x_24_18         EDGE_20_24_18   1.0
    x_24_19         ASSIGN_24       1.0
    x_24_19         LINK_24_19      1.0
    x_24_19         EDGE_19_24_19   1.0
    x_24_19         EDGE_20_24_19   1.0
    x_24_20         ASSIGN_24       1.0
    x_24_20         LINK_24_20      1.0
    x_24_20         EDGE_20_24_20   1.0
    x_24_21         ASSIGN_24       1.0
    x_24_21         LINK_24_21      1.0
    x_24_22         ASSIGN_24       1.0
    x_24_22         LINK_24_22      1.0
    x_24_23         ASSIGN_24       1.0
    x_24_23         LINK_24_23      1.0
    x_24_24         OBJ           1.0
    x_24_24         ASSIGN_24       1.0
    x_24_24         LINK_25_24      -1.0
    x_24_24         LINK_26_24      -1.0
    x_24_24         LINK_27_24      -1.0
    x_24_24         EDGE_25_26_24   -1.0
    x_24_24         EDGE_25_27_24   -1.0
    x_25_0          ASSIGN_25       1.0
    x_25_0          LINK_25_0       1.0
    x_25_0          EDGE_25_26_0    1.0
    x_25_0          EDGE_25_27_0    1.0
    x_25_1          ASSIGN_25       1.0
    x_25_1          LINK_25_1       1.0
    x_25_1          EDGE_25_26_1    1.0
    x_25_1          EDGE_25_27_1    1.0
    x_25_2          ASSIGN_25       1.0
    x_25_2          LINK_25_2       1.0
    x_25_2          EDGE_25_26_2    1.0
    x_25_2          EDGE_25_27_2    1.0
    x_25_3          ASSIGN_25       1.0
    x_25_3          LINK_25_3       1.0
    x_25_3          EDGE_25_26_3    1.0
    x_25_3          EDGE_25_27_3    1.0
    x_25_4          ASSIGN_25       1.0
    x_25_4          LINK_25_4       1.0
    x_25_4          EDGE_25_26_4    1.0
    x_25_4          EDGE_25_27_4    1.0
    x_25_5          ASSIGN_25       1.0
    x_25_5          LINK_25_5       1.0
    x_25_5          EDGE_25_26_5    1.0
    x_25_5          EDGE_25_27_5    1.0
    x_25_6          ASSIGN_25       1.0
    x_25_6          LINK_25_6       1.0
    x_25_6          EDGE_25_26_6    1.0
    x_25_6          EDGE_25_27_6    1.0
    x_25_7          ASSIGN_25       1.0
    x_25_7          LINK_25_7       1.0
    x_25_7          EDGE_25_26_7    1.0
    x_25_7          EDGE_25_27_7    1.0
    x_25_8          ASSIGN_25       1.0
    x_25_8          LINK_25_8       1.0
    x_25_8          EDGE_25_26_8    1.0
    x_25_8          EDGE_25_27_8    1.0
    x_25_9          ASSIGN_25       1.0
    x_25_9          LINK_25_9       1.0
    x_25_9          EDGE_25_26_9    1.0
    x_25_9          EDGE_25_27_9    1.0
    x_25_10         ASSIGN_25       1.0
    x_25_10         LINK_25_10      1.0
    x_25_10         EDGE_25_26_10   1.0
    x_25_10         EDGE_25_27_10   1.0
    x_25_11         ASSIGN_25       1.0
    x_25_11         LINK_25_11      1.0
    x_25_11         EDGE_25_26_11   1.0
    x_25_11         EDGE_25_27_11   1.0
    x_25_12         ASSIGN_25       1.0
    x_25_12         LINK_25_12      1.0
    x_25_12         EDGE_25_26_12   1.0
    x_25_12         EDGE_25_27_12   1.0
    x_25_13         ASSIGN_25       1.0
    x_25_13         LINK_25_13      1.0
    x_25_13         EDGE_25_26_13   1.0
    x_25_13         EDGE_25_27_13   1.0
    x_25_14         ASSIGN_25       1.0
    x_25_14         LINK_25_14      1.0
    x_25_14         EDGE_25_26_14   1.0
    x_25_14         EDGE_25_27_14   1.0
    x_25_15         ASSIGN_25       1.0
    x_25_15         LINK_25_15      1.0
    x_25_15         EDGE_25_26_15   1.0
    x_25_15         EDGE_25_27_15   1.0
    x_25_16         ASSIGN_25       1.0
    x_25_16         LINK_25_16      1.0
    x_25_16         EDGE_25_26_16   1.0
    x_25_16         EDGE_25_27_16   1.0
    x_25_17         ASSIGN_25       1.0
    x_25_17         LINK_25_17      1.0
    x_25_17         EDGE_25_26_17   1.0
    x_25_17         EDGE_25_27_17   1.0
    x_25_18         ASSIGN_25       1.0
    x_25_18         LINK_25_18      1.0
    x_25_18         EDGE_25_26_18   1.0
    x_25_18         EDGE_25_27_18   1.0
    x_25_19         ASSIGN_25       1.0
    x_25_19         LINK_25_19      1.0
    x_25_19         EDGE_25_26_19   1.0
    x_25_19         EDGE_25_27_19   1.0
    x_25_20         ASSIGN_25       1.0
    x_25_20         LINK_25_20      1.0
    x_25_20         EDGE_25_26_20   1.0
    x_25_20         EDGE_25_27_20   1.0
    x_25_21         ASSIGN_25       1.0
    x_25_21         LINK_25_21      1.0
    x_25_21         EDGE_25_26_21   1.0
    x_25_21         EDGE_25_27_21   1.0
    x_25_22         ASSIGN_25       1.0
    x_25_22         LINK_25_22      1.0
    x_25_22         EDGE_25_26_22   1.0
    x_25_22         EDGE_25_27_22   1.0
    x_25_23         ASSIGN_25       1.0
    x_25_23         LINK_25_23      1.0
    x_25_23         EDGE_25_26_23   1.0
    x_25_23         EDGE_25_27_23   1.0
    x_25_24         ASSIGN_25       1.0
    x_25_24         LINK_25_24      1.0
    x_25_24         EDGE_25_26_24   1.0
    x_25_24         EDGE_25_27_24   1.0
    x_25_25         OBJ           1.0
    x_25_25         ASSIGN_25       1.0
    x_25_25         LINK_26_25      -1.0
    x_25_25         LINK_27_25      -1.0
    x_25_25         EDGE_25_26_25   1.0
    x_25_25         EDGE_25_27_25   1.0
    x_26_0          ASSIGN_26       1.0
    x_26_0          LINK_26_0       1.0
    x_26_0          EDGE_25_26_0    1.0
    x_26_1          ASSIGN_26       1.0
    x_26_1          LINK_26_1       1.0
    x_26_1          EDGE_25_26_1    1.0
    x_26_2          ASSIGN_26       1.0
    x_26_2          LINK_26_2       1.0
    x_26_2          EDGE_25_26_2    1.0
    x_26_3          ASSIGN_26       1.0
    x_26_3          LINK_26_3       1.0
    x_26_3          EDGE_25_26_3    1.0
    x_26_4          ASSIGN_26       1.0
    x_26_4          LINK_26_4       1.0
    x_26_4          EDGE_25_26_4    1.0
    x_26_5          ASSIGN_26       1.0
    x_26_5          LINK_26_5       1.0
    x_26_5          EDGE_25_26_5    1.0
    x_26_6          ASSIGN_26       1.0
    x_26_6          LINK_26_6       1.0
    x_26_6          EDGE_25_26_6    1.0
    x_26_7          ASSIGN_26       1.0
    x_26_7          LINK_26_7       1.0
    x_26_7          EDGE_25_26_7    1.0
    x_26_8          ASSIGN_26       1.0
    x_26_8          LINK_26_8       1.0
    x_26_8          EDGE_25_26_8    1.0
    x_26_9          ASSIGN_26       1.0
    x_26_9          LINK_26_9       1.0
    x_26_9          EDGE_25_26_9    1.0
    x_26_10         ASSIGN_26       1.0
    x_26_10         LINK_26_10      1.0
    x_26_10         EDGE_25_26_10   1.0
    x_26_11         ASSIGN_26       1.0
    x_26_11         LINK_26_11      1.0
    x_26_11         EDGE_25_26_11   1.0
    x_26_12         ASSIGN_26       1.0
    x_26_12         LINK_26_12      1.0
    x_26_12         EDGE_25_26_12   1.0
    x_26_13         ASSIGN_26       1.0
    x_26_13         LINK_26_13      1.0
    x_26_13         EDGE_25_26_13   1.0
    x_26_14         ASSIGN_26       1.0
    x_26_14         LINK_26_14      1.0
    x_26_14         EDGE_25_26_14   1.0
    x_26_15         ASSIGN_26       1.0
    x_26_15         LINK_26_15      1.0
    x_26_15         EDGE_25_26_15   1.0
    x_26_16         ASSIGN_26       1.0
    x_26_16         LINK_26_16      1.0
    x_26_16         EDGE_25_26_16   1.0
    x_26_17         ASSIGN_26       1.0
    x_26_17         LINK_26_17      1.0
    x_26_17         EDGE_25_26_17   1.0
    x_26_18         ASSIGN_26       1.0
    x_26_18         LINK_26_18      1.0
    x_26_18         EDGE_25_26_18   1.0
    x_26_19         ASSIGN_26       1.0
    x_26_19         LINK_26_19      1.0
    x_26_19         EDGE_25_26_19   1.0
    x_26_20         ASSIGN_26       1.0
    x_26_20         LINK_26_20      1.0
    x_26_20         EDGE_25_26_20   1.0
    x_26_21         ASSIGN_26       1.0
    x_26_21         LINK_26_21      1.0
    x_26_21         EDGE_25_26_21   1.0
    x_26_22         ASSIGN_26       1.0
    x_26_22         LINK_26_22      1.0
    x_26_22         EDGE_25_26_22   1.0
    x_26_23         ASSIGN_26       1.0
    x_26_23         LINK_26_23      1.0
    x_26_23         EDGE_25_26_23   1.0
    x_26_24         ASSIGN_26       1.0
    x_26_24         LINK_26_24      1.0
    x_26_24         EDGE_25_26_24   1.0
    x_26_25         ASSIGN_26       1.0
    x_26_25         LINK_26_25      1.0
    x_26_25         EDGE_25_26_25   1.0
    x_26_26         OBJ           1.0
    x_26_26         ASSIGN_26       1.0
    x_26_26         LINK_27_26      -1.0
    x_27_0          ASSIGN_27       1.0
    x_27_0          LINK_27_0       1.0
    x_27_0          EDGE_25_27_0    1.0
    x_27_1          ASSIGN_27       1.0
    x_27_1          LINK_27_1       1.0
    x_27_1          EDGE_25_27_1    1.0
    x_27_2          ASSIGN_27       1.0
    x_27_2          LINK_27_2       1.0
    x_27_2          EDGE_25_27_2    1.0
    x_27_3          ASSIGN_27       1.0
    x_27_3          LINK_27_3       1.0
    x_27_3          EDGE_25_27_3    1.0
    x_27_4          ASSIGN_27       1.0
    x_27_4          LINK_27_4       1.0
    x_27_4          EDGE_25_27_4    1.0
    x_27_5          ASSIGN_27       1.0
    x_27_5          LINK_27_5       1.0
    x_27_5          EDGE_25_27_5    1.0
    x_27_6          ASSIGN_27       1.0
    x_27_6          LINK_27_6       1.0
    x_27_6          EDGE_25_27_6    1.0
    x_27_7          ASSIGN_27       1.0
    x_27_7          LINK_27_7       1.0
    x_27_7          EDGE_25_27_7    1.0
    x_27_8          ASSIGN_27       1.0
    x_27_8          LINK_27_8       1.0
    x_27_8          EDGE_25_27_8    1.0
    x_27_9          ASSIGN_27       1.0
    x_27_9          LINK_27_9       1.0
    x_27_9          EDGE_25_27_9    1.0
    x_27_10         ASSIGN_27       1.0
    x_27_10         LINK_27_10      1.0
    x_27_10         EDGE_25_27_10   1.0
    x_27_11         ASSIGN_27       1.0
    x_27_11         LINK_27_11      1.0
    x_27_11         EDGE_25_27_11   1.0
    x_27_12         ASSIGN_27       1.0
    x_27_12         LINK_27_12      1.0
    x_27_12         EDGE_25_27_12   1.0
    x_27_13         ASSIGN_27       1.0
    x_27_13         LINK_27_13      1.0
    x_27_13         EDGE_25_27_13   1.0
    x_27_14         ASSIGN_27       1.0
    x_27_14         LINK_27_14      1.0
    x_27_14         EDGE_25_27_14   1.0
    x_27_15         ASSIGN_27       1.0
    x_27_15         LINK_27_15      1.0
    x_27_15         EDGE_25_27_15   1.0
    x_27_16         ASSIGN_27       1.0
    x_27_16         LINK_27_16      1.0
    x_27_16         EDGE_25_27_16   1.0
    x_27_17         ASSIGN_27       1.0
    x_27_17         LINK_27_17      1.0
    x_27_17         EDGE_25_27_17   1.0
    x_27_18         ASSIGN_27       1.0
    x_27_18         LINK_27_18      1.0
    x_27_18         EDGE_25_27_18   1.0
    x_27_19         ASSIGN_27       1.0
    x_27_19         LINK_27_19      1.0
    x_27_19         EDGE_25_27_19   1.0
    x_27_20         ASSIGN_27       1.0
    x_27_20         LINK_27_20      1.0
    x_27_20         EDGE_25_27_20   1.0
    x_27_21         ASSIGN_27       1.0
    x_27_21         LINK_27_21      1.0
    x_27_21         EDGE_25_27_21   1.0
    x_27_22         ASSIGN_27       1.0
    x_27_22         LINK_27_22      1.0
    x_27_22         EDGE_25_27_22   1.0
    x_27_23         ASSIGN_27       1.0
    x_27_23         LINK_27_23      1.0
    x_27_23         EDGE_25_27_23   1.0
    x_27_24         ASSIGN_27       1.0
    x_27_24         LINK_27_24      1.0
    x_27_24         EDGE_25_27_24   1.0
    x_27_25         ASSIGN_27       1.0
    x_27_25         LINK_27_25      1.0
    x_27_25         EDGE_25_27_25   1.0
    x_27_26         ASSIGN_27       1.0
    x_27_26         LINK_27_26      1.0
    x_27_27         OBJ           1.0
    x_27_27         ASSIGN_27       1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           ASSIGN_0        1.0
    RHS           ASSIGN_1        1.0
    RHS           ASSIGN_2        1.0
    RHS           ASSIGN_3        1.0
    RHS           ASSIGN_4        1.0
    RHS           ASSIGN_5        1.0
    RHS           ASSIGN_6        1.0
    RHS           ASSIGN_7        1.0
    RHS           ASSIGN_8        1.0
    RHS           ASSIGN_9        1.0
    RHS           ASSIGN_10       1.0
    RHS           ASSIGN_11       1.0
    RHS           ASSIGN_12       1.0
    RHS           ASSIGN_13       1.0
    RHS           ASSIGN_14       1.0
    RHS           ASSIGN_15       1.0
    RHS           ASSIGN_16       1.0
    RHS           ASSIGN_17       1.0
    RHS           ASSIGN_18       1.0
    RHS           ASSIGN_19       1.0
    RHS           ASSIGN_20       1.0
    RHS           ASSIGN_21       1.0
    RHS           ASSIGN_22       1.0
    RHS           ASSIGN_23       1.0
    RHS           ASSIGN_24       1.0
    RHS           ASSIGN_25       1.0
    RHS           ASSIGN_26       1.0
    RHS           ASSIGN_27       1.0
    RHS           EDGE_0_1_0      1.0
    RHS           EDGE_0_8_0      1.0
    RHS           EDGE_0_9_0      1.0
    RHS           EDGE_0_11_0     1.0
    RHS           EDGE_0_12_0     1.0
    RHS           EDGE_0_13_0     1.0
    RHS           EDGE_1_3_1      1.0
    RHS           EDGE_1_7_1      1.0
    RHS           EDGE_1_8_1      1.0
    RHS           EDGE_1_10_1     1.0
    RHS           EDGE_2_3_2      1.0
    RHS           EDGE_2_4_2      1.0
    RHS           EDGE_2_5_2      1.0
    RHS           EDGE_2_10_2     1.0
    RHS           EDGE_2_18_2     1.0
    RHS           EDGE_3_5_3      1.0
    RHS           EDGE_3_6_3      1.0
    RHS           EDGE_3_12_3     1.0
    RHS           EDGE_4_5_4      1.0
    RHS           EDGE_4_14_4     1.0
    RHS           EDGE_4_15_4     1.0
    RHS           EDGE_4_16_4     1.0
    RHS           EDGE_5_6_5      1.0
    RHS           EDGE_5_16_5     1.0
    RHS           EDGE_6_12_6     1.0
    RHS           EDGE_6_19_6     1.0
    RHS           EDGE_6_20_6     1.0
    RHS           EDGE_7_8_7      1.0
    RHS           EDGE_7_10_7     1.0
    RHS           EDGE_7_21_7     1.0
    RHS           EDGE_8_9_8      1.0
    RHS           EDGE_9_11_9     1.0
    RHS           EDGE_9_22_9     1.0
    RHS           EDGE_10_17_10   1.0
    RHS           EDGE_11_13_11   1.0
    RHS           EDGE_11_22_11   1.0
    RHS           EDGE_12_13_12   1.0
    RHS           EDGE_13_19_13   1.0
    RHS           EDGE_14_15_14   1.0
    RHS           EDGE_14_18_14   1.0
    RHS           EDGE_14_23_14   1.0
    RHS           EDGE_15_16_15   1.0
    RHS           EDGE_15_23_15   1.0
    RHS           EDGE_16_20_16   1.0
    RHS           EDGE_17_18_17   1.0
    RHS           EDGE_17_21_17   1.0
    RHS           EDGE_19_24_19   1.0
    RHS           EDGE_20_24_20   1.0
    RHS           EDGE_25_26_25   1.0
    RHS           EDGE_25_27_25   1.0
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_2
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_3
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_4
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_5
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_6
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 BV BOUND         x_7_7
 BV BOUND         x_8_0
 BV BOUND         x_8_1
 BV BOUND         x_8_2
 BV BOUND         x_8_3
 BV BOUND         x_8_4
 BV BOUND         x_8_5
 BV BOUND         x_8_6
 BV BOUND         x_8_7
 BV BOUND         x_8_8
 BV BOUND         x_9_0
 BV BOUND         x_9_1
 BV BOUND         x_9_2
 BV BOUND         x_9_3
 BV BOUND         x_9_4
 BV BOUND         x_9_5
 BV BOUND         x_9_6
 BV BOUND         x_9_7
 BV BOUND         x_9_8
 BV BOUND         x_9_9
 BV BOUND         x_10_0
 BV BOUND         x_10_1
 BV BOUND         x_10_2
 BV BOUND         x_10_3
 BV BOUND         x_10_4
 BV BOUND         x_10_5
 BV BOUND         x_10_6
 BV BOUND         x_10_7
 BV BOUND         x_10_8
 BV BOUND         x_10_9
 BV BOUND         x_10_10
 BV BOUND         x_11_0
 BV BOUND         x_11_1
 BV BOUND         x_11_2
 BV BOUND         x_11_3
 BV BOUND         x_11_4
 BV BOUND         x_11_5
 BV BOUND         x_11_6
 BV BOUND         x_11_7
 BV BOUND         x_11_8
 BV BOUND         x_11_9
 BV BOUND         x_11_10
 BV BOUND         x_11_11
 BV BOUND         x_12_0
 BV BOUND         x_12_1
 BV BOUND         x_12_2
 BV BOUND         x_12_3
 BV BOUND         x_12_4
 BV BOUND         x_12_5
 BV BOUND         x_12_6
 BV BOUND         x_12_7
 BV BOUND         x_12_8
 BV BOUND         x_12_9
 BV BOUND         x_12_10
 BV BOUND         x_12_11
 BV BOUND         x_12_12
 BV BOUND         x_13_0
 BV BOUND         x_13_1
 BV BOUND         x_13_2
 BV BOUND         x_13_3
 BV BOUND         x_13_4
 BV BOUND         x_13_5
 BV BOUND         x_13_6
 BV BOUND         x_13_7
 BV BOUND         x_13_8
 BV BOUND         x_13_9
 BV BOUND         x_13_10
 BV BOUND         x_13_11
 BV BOUND         x_13_12
 BV BOUND         x_13_13
 BV BOUND         x_14_0
 BV BOUND         x_14_1
 BV BOUND         x_14_2
 BV BOUND         x_14_3
 BV BOUND         x_14_4
 BV BOUND         x_14_5
 BV BOUND         x_14_6
 BV BOUND         x_14_7
 BV BOUND         x_14_8
 BV BOUND         x_14_9
 BV BOUND         x_14_10
 BV BOUND         x_14_11
 BV BOUND         x_14_12
 BV BOUND         x_14_13
 BV BOUND         x_14_14
 BV BOUND         x_15_0
 BV BOUND         x_15_1
 BV BOUND         x_15_2
 BV BOUND         x_15_3
 BV BOUND         x_15_4
 BV BOUND         x_15_5
 BV BOUND         x_15_6
 BV BOUND         x_15_7
 BV BOUND         x_15_8
 BV BOUND         x_15_9
 BV BOUND         x_15_10
 BV BOUND         x_15_11
 BV BOUND         x_15_12
 BV BOUND         x_15_13
 BV BOUND         x_15_14
 BV BOUND         x_15_15
 BV BOUND         x_16_0
 BV BOUND         x_16_1
 BV BOUND         x_16_2
 BV BOUND         x_16_3
 BV BOUND         x_16_4
 BV BOUND         x_16_5
 BV BOUND         x_16_6
 BV BOUND         x_16_7
 BV BOUND         x_16_8
 BV BOUND         x_16_9
 BV BOUND         x_16_10
 BV BOUND         x_16_11
 BV BOUND         x_16_12
 BV BOUND         x_16_13
 BV BOUND         x_16_14
 BV BOUND         x_16_15
 BV BOUND         x_16_16
 BV BOUND         x_17_0
 BV BOUND         x_17_1
 BV BOUND         x_17_2
 BV BOUND         x_17_3
 BV BOUND         x_17_4
 BV BOUND         x_17_5
 BV BOUND         x_17_6
 BV BOUND         x_17_7
 BV BOUND         x_17_8
 BV BOUND         x_17_9
 BV BOUND         x_17_10
 BV BOUND         x_17_11
 BV BOUND         x_17_12
 BV BOUND         x_17_13
 BV BOUND         x_17_14
 BV BOUND         x_17_15
 BV BOUND         x_17_16
 BV BOUND         x_17_17
 BV BOUND         x_18_0
 BV BOUND         x_18_1
 BV BOUND         x_18_2
 BV BOUND         x_18_3
 BV BOUND         x_18_4
 BV BOUND         x_18_5
 BV BOUND         x_18_6
 BV BOUND         x_18_7
 BV BOUND         x_18_8
 BV BOUND         x_18_9
 BV BOUND         x_18_10
 BV BOUND         x_18_11
 BV BOUND         x_18_12
 BV BOUND         x_18_13
 BV BOUND         x_18_14
 BV BOUND         x_18_15
 BV BOUND         x_18_16
 BV BOUND         x_18_17
 BV BOUND         x_18_18
 BV BOUND         x_19_0
 BV BOUND         x_19_1
 BV BOUND         x_19_2
 BV BOUND         x_19_3
 BV BOUND         x_19_4
 BV BOUND         x_19_5
 BV BOUND         x_19_6
 BV BOUND         x_19_7
 BV BOUND         x_19_8
 BV BOUND         x_19_9
 BV BOUND         x_19_10
 BV BOUND         x_19_11
 BV BOUND         x_19_12
 BV BOUND         x_19_13
 BV BOUND         x_19_14
 BV BOUND         x_19_15
 BV BOUND         x_19_16
 BV BOUND         x_19_17
 BV BOUND         x_19_18
 BV BOUND         x_19_19
 BV BOUND         x_20_0
 BV BOUND         x_20_1
 BV BOUND         x_20_2
 BV BOUND         x_20_3
 BV BOUND         x_20_4
 BV BOUND         x_20_5
 BV BOUND         x_20_6
 BV BOUND         x_20_7
 BV BOUND         x_20_8
 BV BOUND         x_20_9
 BV BOUND         x_20_10
 BV BOUND         x_20_11
 BV BOUND         x_20_12
 BV BOUND         x_20_13
 BV BOUND         x_20_14
 BV BOUND         x_20_15
 BV BOUND         x_20_16
 BV BOUND         x_20_17
 BV BOUND         x_20_18
 BV BOUND         x_20_19
 BV BOUND         x_20_20
 BV BOUND         x_21_0
 BV BOUND         x_21_1
 BV BOUND         x_21_2
 BV BOUND         x_21_3
 BV BOUND         x_21_4
 BV BOUND         x_21_5
 BV BOUND         x_21_6
 BV BOUND         x_21_7
 BV BOUND         x_21_8
 BV BOUND         x_21_9
 BV BOUND         x_21_10
 BV BOUND         x_21_11
 BV BOUND         x_21_12
 BV BOUND         x_21_13
 BV BOUND         x_21_14
 BV BOUND         x_21_15
 BV BOUND         x_21_16
 BV BOUND         x_21_17
 BV BOUND         x_21_18
 BV BOUND         x_21_19
 BV BOUND         x_21_20
 BV BOUND         x_21_21
 BV BOUND         x_22_0
 BV BOUND         x_22_1
 BV BOUND         x_22_2
 BV BOUND         x_22_3
 BV BOUND         x_22_4
 BV BOUND         x_22_5
 BV BOUND         x_22_6
 BV BOUND         x_22_7
 BV BOUND         x_22_8
 BV BOUND         x_22_9
 BV BOUND         x_22_10
 BV BOUND         x_22_11
 BV BOUND         x_22_12
 BV BOUND         x_22_13
 BV BOUND         x_22_14
 BV BOUND         x_22_15
 BV BOUND         x_22_16
 BV BOUND         x_22_17
 BV BOUND         x_22_18
 BV BOUND         x_22_19
 BV BOUND         x_22_20
 BV BOUND         x_22_21
 BV BOUND         x_22_22
 BV BOUND         x_23_0
 BV BOUND         x_23_1
 BV BOUND         x_23_2
 BV BOUND         x_23_3
 BV BOUND         x_23_4
 BV BOUND         x_23_5
 BV BOUND         x_23_6
 BV BOUND         x_23_7
 BV BOUND         x_23_8
 BV BOUND         x_23_9
 BV BOUND         x_23_10
 BV BOUND         x_23_11
 BV BOUND         x_23_12
 BV BOUND         x_23_13
 BV BOUND         x_23_14
 BV BOUND         x_23_15
 BV BOUND         x_23_16
 BV BOUND         x_23_17
 BV BOUND         x_23_18
 BV BOUND         x_23_19
 BV BOUND         x_23_20
 BV BOUND         x_23_21
 BV BOUND         x_23_22
 BV BOUND         x_23_23
 BV BOUND         x_24_0
 BV BOUND         x_24_1
 BV BOUND         x_24_2
 BV BOUND         x_24_3
 BV BOUND         x_24_4
 BV BOUND         x_24_5
 BV BOUND         x_24_6
 BV BOUND         x_24_7
 BV BOUND         x_24_8
 BV BOUND         x_24_9
 BV BOUND         x_24_10
 BV BOUND         x_24_11
 BV BOUND         x_24_12
 BV BOUND         x_24_13
 BV BOUND         x_24_14
 BV BOUND         x_24_15
 BV BOUND         x_24_16
 BV BOUND         x_24_17
 BV BOUND         x_24_18
 BV BOUND         x_24_19
 BV BOUND         x_24_20
 BV BOUND         x_24_21
 BV BOUND         x_24_22
 BV BOUND         x_24_23
 BV BOUND         x_24_24
 BV BOUND         x_25_0
 BV BOUND         x_25_1
 BV BOUND         x_25_2
 BV BOUND         x_25_3
 BV BOUND         x_25_4
 BV BOUND         x_25_5
 BV BOUND         x_25_6
 BV BOUND         x_25_7
 BV BOUND         x_25_8
 BV BOUND         x_25_9
 BV BOUND         x_25_10
 BV BOUND         x_25_11
 BV BOUND         x_25_12
 BV BOUND         x_25_13
 BV BOUND         x_25_14
 BV BOUND         x_25_15
 BV BOUND         x_25_16
 BV BOUND         x_25_17
 BV BOUND         x_25_18
 BV BOUND         x_25_19
 BV BOUND         x_25_20
 BV BOUND         x_25_21
 BV BOUND         x_25_22
 BV BOUND         x_25_23
 BV BOUND         x_25_24
 BV BOUND         x_25_25
 BV BOUND         x_26_0
 BV BOUND         x_26_1
 BV BOUND         x_26_2
 BV BOUND         x_26_3
 BV BOUND         x_26_4
 BV BOUND         x_26_5
 BV BOUND         x_26_6
 BV BOUND         x_26_7
 BV BOUND         x_26_8
 BV BOUND         x_26_9
 BV BOUND         x_26_10
 BV BOUND         x_26_11
 BV BOUND         x_26_12
 BV BOUND         x_26_13
 BV BOUND         x_26_14
 BV BOUND         x_26_15
 BV BOUND         x_26_16
 BV BOUND         x_26_17
 BV BOUND         x_26_18
 BV BOUND         x_26_19
 BV BOUND         x_26_20
 BV BOUND         x_26_21
 BV BOUND         x_26_22
 BV BOUND         x_26_23
 BV BOUND         x_26_24
 BV BOUND         x_26_25
 BV BOUND         x_26_26
 BV BOUND         x_27_0
 BV BOUND         x_27_1
 BV BOUND         x_27_2
 BV BOUND         x_27_3
 BV BOUND         x_27_4
 BV BOUND         x_27_5
 BV BOUND         x_27_6
 BV BOUND         x_27_7
 BV BOUND         x_27_8
 BV BOUND         x_27_9
 BV BOUND         x_27_10
 BV BOUND         x_27_11
 BV BOUND         x_27_12
 BV BOUND         x_27_13
 BV BOUND         x_27_14
 BV BOUND         x_27_15
 BV BOUND         x_27_16
 BV BOUND         x_27_17
 BV BOUND         x_27_18
 BV BOUND         x_27_19
 BV BOUND         x_27_20
 BV BOUND         x_27_21
 BV BOUND         x_27_22
 BV BOUND         x_27_23
 BV BOUND         x_27_24
 BV BOUND         x_27_25
 BV BOUND         x_27_26
 BV BOUND         x_27_27
ENDATA
