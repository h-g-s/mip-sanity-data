NAME          fcnf_search_n55_d10_s3_4_sl0.95_sd7
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 E  flow_25
 E  flow_26
 E  flow_27
 E  flow_28
 E  flow_29
 E  flow_30
 E  flow_31
 E  flow_32
 E  flow_33
 E  flow_34
 E  flow_35
 E  flow_36
 E  flow_37
 E  flow_38
 E  flow_39
 E  flow_40
 E  flow_41
 E  flow_42
 E  flow_43
 E  flow_44
 E  flow_45
 E  flow_46
 E  flow_47
 E  flow_48
 E  flow_49
 E  flow_50
 E  flow_51
 E  flow_52
 E  flow_53
 E  flow_54
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
 L  link_84
 L  link_85
 L  link_86
 L  link_87
 L  link_88
 L  link_89
 L  link_90
 L  link_91
 L  link_92
 L  link_93
 L  link_94
 L  link_95
 L  link_96
 L  link_97
 L  link_98
 L  link_99
 L  link_100
 L  link_101
 L  link_102
 L  link_103
 L  link_104
 L  link_105
 L  link_106
 L  link_107
 L  link_108
 L  link_109
 L  link_110
 L  link_111
 L  link_112
 L  link_113
 L  link_114
 L  link_115
 L  link_116
 L  link_117
 L  link_118
 L  link_119
 L  link_120
 L  link_121
 L  link_122
 L  link_123
 L  link_124
 L  link_125
 L  link_126
 L  link_127
 L  link_128
 L  link_129
 L  link_130
 L  link_131
 L  link_132
 L  link_133
 L  link_134
 L  link_135
 L  link_136
 L  link_137
 L  link_138
 L  link_139
 L  link_140
 L  link_141
 L  link_142
 L  link_143
 L  link_144
 L  link_145
 L  link_146
 L  link_147
 L  link_148
 L  link_149
 L  link_150
 L  link_151
 L  link_152
 L  link_153
 L  link_154
 L  link_155
 L  link_156
 L  link_157
 L  link_158
 L  link_159
 L  link_160
 L  link_161
 L  link_162
 L  link_163
 L  link_164
 L  link_165
 L  link_166
 L  link_167
 L  link_168
 L  link_169
 L  link_170
 L  link_171
 L  link_172
 L  link_173
 L  link_174
 L  link_175
 L  link_176
 L  link_177
 L  link_178
 L  link_179
 L  link_180
 L  link_181
 L  link_182
 L  link_183
 L  link_184
 L  link_185
 L  link_186
 L  link_187
 L  link_188
 L  link_189
 L  link_190
 L  link_191
 L  link_192
 L  link_193
 L  link_194
 L  link_195
 L  link_196
 L  link_197
 L  link_198
 L  link_199
 L  link_200
 L  link_201
 L  link_202
 L  link_203
 L  link_204
 L  link_205
 L  link_206
 L  link_207
 L  link_208
 L  link_209
 L  link_210
 L  link_211
 L  link_212
 L  link_213
 L  link_214
 L  link_215
 L  link_216
 L  link_217
 L  link_218
 L  link_219
 L  link_220
 L  link_221
 L  link_222
 L  link_223
 L  link_224
 L  link_225
 L  link_226
 L  link_227
 L  link_228
 L  link_229
 L  link_230
 L  link_231
 L  link_232
 L  link_233
 L  link_234
 L  link_235
 L  link_236
 L  link_237
 L  link_238
 L  link_239
 L  link_240
 L  link_241
 L  link_242
 L  link_243
 L  link_244
 L  link_245
 L  link_246
 L  link_247
 L  link_248
 L  link_249
 L  link_250
 L  link_251
 L  link_252
 L  link_253
 L  link_254
 L  link_255
 L  link_256
 L  link_257
 L  link_258
 L  link_259
 L  link_260
 L  link_261
 L  link_262
 L  link_263
 L  link_264
 L  link_265
 L  link_266
 L  link_267
 L  link_268
 L  link_269
 L  link_270
 L  link_271
 L  link_272
 L  link_273
 L  link_274
 L  link_275
 L  link_276
 L  link_277
 L  link_278
 L  link_279
 L  link_280
 L  link_281
 L  link_282
 L  link_283
 L  link_284
 L  link_285
 L  link_286
 L  link_287
 L  link_288
 L  link_289
 L  link_290
 L  link_291
 L  link_292
 L  link_293
 L  link_294
 L  link_295
 L  link_296
 L  link_297
 L  link_298
 L  link_299
 L  link_300
 L  link_301
 L  link_302
 L  link_303
 L  link_304
 L  link_305
 L  link_306
 L  link_307
 L  link_308
 L  link_309
 L  link_310
 L  link_311
 L  link_312
 L  link_313
 L  link_314
 L  link_315
 L  link_316
 L  link_317
 L  link_318
 L  link_319
 L  link_320
 L  link_321
 L  link_322
 L  link_323
 L  link_324
 L  link_325
 L  link_326
 L  link_327
 L  link_328
 L  link_329
 L  link_330
 L  link_331
 L  link_332
 L  link_333
 L  link_334
 L  link_335
 L  link_336
 L  link_337
 L  link_338
 L  link_339
 L  link_340
 L  link_341
 L  link_342
 L  link_343
 L  link_344
 L  link_345
 L  link_346
 L  link_347
 L  link_348
 L  link_349
 L  link_350
 L  link_351
 L  link_352
 L  link_353
 L  link_354
 L  link_355
 L  link_356
 L  link_357
 L  link_358
 L  link_359
 L  link_360
 L  link_361
 L  link_362
 L  link_363
 L  link_364
 L  link_365
 L  link_366
 L  link_367
 L  link_368
 L  link_369
 L  link_370
 L  link_371
 L  link_372
 L  link_373
 L  link_374
 L  link_375
 L  link_376
 L  link_377
 L  link_378
 L  link_379
 L  link_380
 L  link_381
 L  link_382
 L  link_383
 L  link_384
 L  link_385
 L  link_386
 L  link_387
 L  link_388
 L  link_389
 L  link_390
 L  link_391
 L  link_392
 L  link_393
 L  link_394
 L  link_395
 L  link_396
 L  link_397
 L  link_398
 L  link_399
 L  link_400
 L  link_401
 L  link_402
 L  link_403
 L  link_404
 L  link_405
 L  link_406
 L  link_407
 L  link_408
 L  link_409
 L  link_410
 L  link_411
 L  link_412
 L  link_413
 L  link_414
 L  link_415
 L  link_416
 L  link_417
 L  link_418
 L  link_419
 L  link_420
 L  link_421
 L  link_422
 L  link_423
 L  link_424
 L  link_425
 L  link_426
 L  link_427
 L  link_428
 L  link_429
 L  link_430
 L  link_431
 L  link_432
 L  link_433
 L  link_434
 L  link_435
 L  link_436
 L  link_437
 L  link_438
 L  link_439
 L  link_440
 L  link_441
 L  link_442
 L  link_443
 L  link_444
 L  link_445
 L  link_446
 L  link_447
 L  link_448
 L  link_449
 L  link_450
 L  link_451
 L  link_452
 L  link_453
 L  link_454
 L  link_455
 L  link_456
 L  link_457
 L  link_458
 L  link_459
 L  link_460
 L  link_461
 L  link_462
 L  link_463
 L  link_464
 L  link_465
 L  link_466
 L  link_467
 L  link_468
 L  link_469
 L  link_470
 L  link_471
 L  link_472
 L  link_473
 L  link_474
 L  link_475
 L  link_476
 L  link_477
 L  link_478
 L  link_479
 L  link_480
 L  link_481
 L  link_482
 L  link_483
 L  link_484
 L  link_485
 L  link_486
 L  link_487
 L  link_488
 L  link_489
 L  link_490
 L  link_491
 L  link_492
 L  link_493
 L  link_494
 L  link_495
 L  link_496
 L  link_497
 L  link_498
 L  link_499
 L  link_500
 L  link_501
 L  link_502
 L  link_503
 L  link_504
 L  link_505
 L  link_506
 L  link_507
 L  link_508
 L  link_509
 L  link_510
 L  link_511
 L  link_512
 L  link_513
 L  link_514
 L  link_515
 L  link_516
 L  link_517
 L  link_518
 L  link_519
 L  link_520
 L  link_521
 L  link_522
 L  link_523
 L  link_524
 L  link_525
 L  link_526
 L  link_527
 L  link_528
 L  link_529
 L  link_530
 L  link_531
 L  link_532
 L  link_533
 L  link_534
 L  link_535
 L  link_536
 L  link_537
 L  link_538
 L  link_539
 L  link_540
 L  link_541
 L  link_542
 L  link_543
 L  link_544
 L  link_545
 L  link_546
 L  link_547
 L  link_548
 L  link_549
COLUMNS
    x_0         OBJ       0.62
    x_0         flow_20     1.0
    x_0         flow_9      -1.0
    x_0         link_0      1.0
    x_1         OBJ       1.77
    x_1         flow_23     1.0
    x_1         flow_37     -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.88
    x_2         flow_26     1.0
    x_2         flow_4      -1.0
    x_2         link_2      1.0
    x_3         OBJ       54.98
    x_3         flow_7      1.0
    x_3         flow_14     -1.0
    x_3         link_3      1.0
    x_4         OBJ       22.79
    x_4         flow_25     1.0
    x_4         flow_3      -1.0
    x_4         link_4      1.0
    x_5         OBJ       54.25
    x_5         flow_26     1.0
    x_5         flow_9      -1.0
    x_5         link_5      1.0
    x_6         OBJ       58.33
    x_6         flow_11     1.0
    x_6         flow_6      -1.0
    x_6         link_6      1.0
    x_7         OBJ       57.14
    x_7         flow_45     1.0
    x_7         flow_4      -1.0
    x_7         link_7      1.0
    x_8         OBJ       1.96
    x_8         flow_27     1.0
    x_8         flow_49     -1.0
    x_8         link_8      1.0
    x_9         OBJ       2.45
    x_9         flow_15     1.0
    x_9         flow_50     -1.0
    x_9         link_9      1.0
    x_10        OBJ       63.77
    x_10        flow_33     1.0
    x_10        flow_31     -1.0
    x_10        link_10     1.0
    x_11        OBJ       2.39
    x_11        flow_7      1.0
    x_11        flow_32     -1.0
    x_11        link_11     1.0
    x_12        OBJ       24.66
    x_12        flow_26     1.0
    x_12        flow_2      -1.0
    x_12        link_12     1.0
    x_13        OBJ       1.38
    x_13        flow_52     1.0
    x_13        flow_20     -1.0
    x_13        link_13     1.0
    x_14        OBJ       76.68
    x_14        flow_29     1.0
    x_14        flow_4      -1.0
    x_14        link_14     1.0
    x_15        OBJ       38.58
    x_15        flow_4      1.0
    x_15        flow_3      -1.0
    x_15        link_15     1.0
    x_16        OBJ       1.46
    x_16        flow_52     1.0
    x_16        flow_28     -1.0
    x_16        link_16     1.0
    x_17        OBJ       0.79
    x_17        flow_29     1.0
    x_17        flow_22     -1.0
    x_17        link_17     1.0
    x_18        OBJ       43.87
    x_18        flow_18     1.0
    x_18        flow_8      -1.0
    x_18        link_18     1.0
    x_19        OBJ       1.87
    x_19        flow_5      1.0
    x_19        flow_10     -1.0
    x_19        link_19     1.0
    x_20        OBJ       1.54
    x_20        flow_27     1.0
    x_20        flow_35     -1.0
    x_20        link_20     1.0
    x_21        OBJ       0.88
    x_21        flow_14     1.0
    x_21        flow_9      -1.0
    x_21        link_21     1.0
    x_22        OBJ       35.76
    x_22        flow_31     1.0
    x_22        flow_53     -1.0
    x_22        link_22     1.0
    x_23        OBJ       39.12
    x_23        flow_34     1.0
    x_23        flow_23     -1.0
    x_23        link_23     1.0
    x_24        OBJ       64.39
    x_24        flow_32     1.0
    x_24        flow_39     -1.0
    x_24        link_24     1.0
    x_25        OBJ       43.54
    x_25        flow_49     1.0
    x_25        flow_43     -1.0
    x_25        link_25     1.0
    x_26        OBJ       0.98
    x_26        flow_30     1.0
    x_26        flow_40     -1.0
    x_26        link_26     1.0
    x_27        OBJ       0.63
    x_27        flow_10     1.0
    x_27        flow_7      -1.0
    x_27        link_27     1.0
    x_28        OBJ       56.82
    x_28        flow_34     1.0
    x_28        flow_6      -1.0
    x_28        link_28     1.0
    x_29        OBJ       1.13
    x_29        flow_39     1.0
    x_29        flow_24     -1.0
    x_29        link_29     1.0
    x_30        OBJ       1.72
    x_30        flow_30     1.0
    x_30        flow_7      -1.0
    x_30        link_30     1.0
    x_31        OBJ       0.76
    x_31        flow_30     1.0
    x_31        flow_19     -1.0
    x_31        link_31     1.0
    x_32        OBJ       50.98
    x_32        flow_30     1.0
    x_32        flow_53     -1.0
    x_32        link_32     1.0
    x_33        OBJ       74.85
    x_33        flow_23     1.0
    x_33        flow_9      -1.0
    x_33        link_33     1.0
    x_34        OBJ       35.67
    x_34        flow_41     1.0
    x_34        flow_5      -1.0
    x_34        link_34     1.0
    x_35        OBJ       1.85
    x_35        flow_22     1.0
    x_35        flow_49     -1.0
    x_35        link_35     1.0
    x_36        OBJ       79.1
    x_36        flow_14     1.0
    x_36        flow_39     -1.0
    x_36        link_36     1.0
    x_37        OBJ       2.51
    x_37        flow_15     1.0
    x_37        flow_52     -1.0
    x_37        link_37     1.0
    x_38        OBJ       0.57
    x_38        flow_22     1.0
    x_38        flow_46     -1.0
    x_38        link_38     1.0
    x_39        OBJ       40.66
    x_39        flow_12     1.0
    x_39        flow_44     -1.0
    x_39        link_39     1.0
    x_40        OBJ       0.76
    x_40        flow_22     1.0
    x_40        flow_23     -1.0
    x_40        link_40     1.0
    x_41        OBJ       74.02
    x_41        flow_13     1.0
    x_41        flow_30     -1.0
    x_41        link_41     1.0
    x_42        OBJ       25.09
    x_42        flow_41     1.0
    x_42        flow_22     -1.0
    x_42        link_42     1.0
    x_43        OBJ       48.68
    x_43        flow_50     1.0
    x_43        flow_45     -1.0
    x_43        link_43     1.0
    x_44        OBJ       2.87
    x_44        flow_40     1.0
    x_44        flow_21     -1.0
    x_44        link_44     1.0
    x_45        OBJ       63.49
    x_45        flow_25     1.0
    x_45        flow_47     -1.0
    x_45        link_45     1.0
    x_46        OBJ       47.92
    x_46        flow_1      1.0
    x_46        flow_9      -1.0
    x_46        link_46     1.0
    x_47        OBJ       59.44
    x_47        flow_52     1.0
    x_47        flow_38     -1.0
    x_47        link_47     1.0
    x_48        OBJ       2.5
    x_48        flow_35     1.0
    x_48        flow_8      -1.0
    x_48        link_48     1.0
    x_49        OBJ       46.03
    x_49        flow_33     1.0
    x_49        flow_47     -1.0
    x_49        link_49     1.0
    x_50        OBJ       1.23
    x_50        flow_13     1.0
    x_50        flow_1      -1.0
    x_50        link_50     1.0
    x_51        OBJ       70.05
    x_51        flow_20     1.0
    x_51        flow_16     -1.0
    x_51        link_51     1.0
    x_52        OBJ       68.9
    x_52        flow_22     1.0
    x_52        flow_29     -1.0
    x_52        link_52     1.0
    x_53        OBJ       51.41
    x_53        flow_32     1.0
    x_53        flow_8      -1.0
    x_53        link_53     1.0
    x_54        OBJ       66.56
    x_54        flow_49     1.0
    x_54        flow_11     -1.0
    x_54        link_54     1.0
    x_55        OBJ       53.39
    x_55        flow_30     1.0
    x_55        flow_39     -1.0
    x_55        link_55     1.0
    x_56        OBJ       2.44
    x_56        flow_33     1.0
    x_56        flow_35     -1.0
    x_56        link_56     1.0
    x_57        OBJ       2.43
    x_57        flow_15     1.0
    x_57        flow_12     -1.0
    x_57        link_57     1.0
    x_58        OBJ       23.8
    x_58        flow_1      1.0
    x_58        flow_48     -1.0
    x_58        link_58     1.0
    x_59        OBJ       1.19
    x_59        flow_38     1.0
    x_59        flow_32     -1.0
    x_59        link_59     1.0
    x_60        OBJ       61.95
    x_60        flow_30     1.0
    x_60        flow_32     -1.0
    x_60        link_60     1.0
    x_61        OBJ       28.23
    x_61        flow_35     1.0
    x_61        flow_12     -1.0
    x_61        link_61     1.0
    x_62        OBJ       45.7
    x_62        flow_20     1.0
    x_62        flow_4      -1.0
    x_62        link_62     1.0
    x_63        OBJ       29.27
    x_63        flow_50     1.0
    x_63        flow_7      -1.0
    x_63        link_63     1.0
    x_64        OBJ       33.18
    x_64        flow_16     1.0
    x_64        flow_8      -1.0
    x_64        link_64     1.0
    x_65        OBJ       69.95
    x_65        flow_31     1.0
    x_65        flow_10     -1.0
    x_65        link_65     1.0
    x_66        OBJ       0.99
    x_66        flow_32     1.0
    x_66        flow_25     -1.0
    x_66        link_66     1.0
    x_67        OBJ       1.65
    x_67        flow_23     1.0
    x_67        flow_1      -1.0
    x_67        link_67     1.0
    x_68        OBJ       50.74
    x_68        flow_21     1.0
    x_68        flow_33     -1.0
    x_68        link_68     1.0
    x_69        OBJ       1.18
    x_69        flow_14     1.0
    x_69        flow_6      -1.0
    x_69        link_69     1.0
    x_70        OBJ       1.56
    x_70        flow_17     1.0
    x_70        flow_48     -1.0
    x_70        link_70     1.0
    x_71        OBJ       2.8
    x_71        flow_16     1.0
    x_71        flow_25     -1.0
    x_71        link_71     1.0
    x_72        OBJ       2.5
    x_72        flow_20     1.0
    x_72        flow_5      -1.0
    x_72        link_72     1.0
    x_73        OBJ       68.1
    x_73        flow_17     1.0
    x_73        flow_1      -1.0
    x_73        link_73     1.0
    x_74        OBJ       0.8
    x_74        flow_14     1.0
    x_74        flow_4      -1.0
    x_74        link_74     1.0
    x_75        OBJ       22.59
    x_75        flow_26     1.0
    x_75        flow_17     -1.0
    x_75        link_75     1.0
    x_76        OBJ       1.0
    x_76        flow_10     1.0
    x_76        flow_16     -1.0
    x_76        link_76     1.0
    x_77        OBJ       1.61
    x_77        flow_33     1.0
    x_77        flow_48     -1.0
    x_77        link_77     1.0
    x_78        OBJ       1.13
    x_78        flow_22     1.0
    x_78        flow_51     -1.0
    x_78        link_78     1.0
    x_79        OBJ       50.85
    x_79        flow_32     1.0
    x_79        flow_35     -1.0
    x_79        link_79     1.0
    x_80        OBJ       45.93
    x_80        flow_6      1.0
    x_80        flow_42     -1.0
    x_80        link_80     1.0
    x_81        OBJ       1.04
    x_81        flow_25     1.0
    x_81        flow_32     -1.0
    x_81        link_81     1.0
    x_82        OBJ       28.38
    x_82        flow_53     1.0
    x_82        flow_45     -1.0
    x_82        link_82     1.0
    x_83        OBJ       2.06
    x_83        flow_53     1.0
    x_83        flow_8      -1.0
    x_83        link_83     1.0
    x_84        OBJ       2.6
    x_84        flow_10     1.0
    x_84        flow_3      -1.0
    x_84        link_84     1.0
    x_85        OBJ       1.23
    x_85        flow_18     1.0
    x_85        flow_38     -1.0
    x_85        link_85     1.0
    x_86        OBJ       1.41
    x_86        flow_17     1.0
    x_86        flow_28     -1.0
    x_86        link_86     1.0
    x_87        OBJ       2.71
    x_87        flow_20     1.0
    x_87        flow_15     -1.0
    x_87        link_87     1.0
    x_88        OBJ       1.69
    x_88        flow_0      1.0
    x_88        flow_21     -1.0
    x_88        link_88     1.0
    x_89        OBJ       25.45
    x_89        flow_15     1.0
    x_89        flow_32     -1.0
    x_89        link_89     1.0
    x_90        OBJ       0.56
    x_90        flow_25     1.0
    x_90        flow_37     -1.0
    x_90        link_90     1.0
    x_91        OBJ       71.19
    x_91        flow_5      1.0
    x_91        flow_37     -1.0
    x_91        link_91     1.0
    x_92        OBJ       1.32
    x_92        flow_50     1.0
    x_92        flow_38     -1.0
    x_92        link_92     1.0
    x_93        OBJ       28.69
    x_93        flow_18     1.0
    x_93        flow_46     -1.0
    x_93        link_93     1.0
    x_94        OBJ       2.25
    x_94        flow_32     1.0
    x_94        flow_40     -1.0
    x_94        link_94     1.0
    x_95        OBJ       68.77
    x_95        flow_48     1.0
    x_95        flow_32     -1.0
    x_95        link_95     1.0
    x_96        OBJ       60.97
    x_96        flow_37     1.0
    x_96        flow_51     -1.0
    x_96        link_96     1.0
    x_97        OBJ       2.09
    x_97        flow_5      1.0
    x_97        flow_1      -1.0
    x_97        link_97     1.0
    x_98        OBJ       57.67
    x_98        flow_53     1.0
    x_98        flow_28     -1.0
    x_98        link_98     1.0
    x_99        OBJ       1.64
    x_99        flow_15     1.0
    x_99        flow_31     -1.0
    x_99        link_99     1.0
    x_100       OBJ       23.96
    x_100       flow_34     1.0
    x_100       flow_5      -1.0
    x_100       link_100    1.0
    x_101       OBJ       34.09
    x_101       flow_51     1.0
    x_101       flow_4      -1.0
    x_101       link_101    1.0
    x_102       OBJ       49.64
    x_102       flow_47     1.0
    x_102       flow_41     -1.0
    x_102       link_102    1.0
    x_103       OBJ       57.02
    x_103       flow_43     1.0
    x_103       flow_18     -1.0
    x_103       link_103    1.0
    x_104       OBJ       2.13
    x_104       flow_38     1.0
    x_104       flow_9      -1.0
    x_104       link_104    1.0
    x_105       OBJ       0.65
    x_105       flow_36     1.0
    x_105       flow_8      -1.0
    x_105       link_105    1.0
    x_106       OBJ       1.72
    x_106       flow_6      1.0
    x_106       flow_44     -1.0
    x_106       link_106    1.0
    x_107       OBJ       2.73
    x_107       flow_29     1.0
    x_107       flow_49     -1.0
    x_107       link_107    1.0
    x_108       OBJ       0.69
    x_108       flow_30     1.0
    x_108       flow_1      -1.0
    x_108       link_108    1.0
    x_109       OBJ       2.86
    x_109       flow_17     1.0
    x_109       flow_24     -1.0
    x_109       link_109    1.0
    x_110       OBJ       35.71
    x_110       flow_5      1.0
    x_110       flow_9      -1.0
    x_110       link_110    1.0
    x_111       OBJ       73.21
    x_111       flow_52     1.0
    x_111       flow_40     -1.0
    x_111       link_111    1.0
    x_112       OBJ       2.87
    x_112       flow_25     1.0
    x_112       flow_1      -1.0
    x_112       link_112    1.0
    x_113       OBJ       1.36
    x_113       flow_19     1.0
    x_113       flow_46     -1.0
    x_113       link_113    1.0
    x_114       OBJ       1.35
    x_114       flow_21     1.0
    x_114       flow_0      -1.0
    x_114       link_114    1.0
    x_115       OBJ       37.39
    x_115       flow_45     1.0
    x_115       flow_0      -1.0
    x_115       link_115    1.0
    x_116       OBJ       2.81
    x_116       flow_24     1.0
    x_116       flow_37     -1.0
    x_116       link_116    1.0
    x_117       OBJ       2.59
    x_117       flow_3      1.0
    x_117       flow_17     -1.0
    x_117       link_117    1.0
    x_118       OBJ       1.29
    x_118       flow_15     1.0
    x_118       flow_17     -1.0
    x_118       link_118    1.0
    x_119       OBJ       57.85
    x_119       flow_27     1.0
    x_119       flow_1      -1.0
    x_119       link_119    1.0
    x_120       OBJ       22.97
    x_120       flow_35     1.0
    x_120       flow_13     -1.0
    x_120       link_120    1.0
    x_121       OBJ       2.67
    x_121       flow_39     1.0
    x_121       flow_48     -1.0
    x_121       link_121    1.0
    x_122       OBJ       1.36
    x_122       flow_8      1.0
    x_122       flow_10     -1.0
    x_122       link_122    1.0
    x_123       OBJ       1.89
    x_123       flow_41     1.0
    x_123       flow_15     -1.0
    x_123       link_123    1.0
    x_124       OBJ       1.75
    x_124       flow_41     1.0
    x_124       flow_10     -1.0
    x_124       link_124    1.0
    x_125       OBJ       79.79
    x_125       flow_14     1.0
    x_125       flow_28     -1.0
    x_125       link_125    1.0
    x_126       OBJ       1.89
    x_126       flow_15     1.0
    x_126       flow_5      -1.0
    x_126       link_126    1.0
    x_127       OBJ       73.24
    x_127       flow_16     1.0
    x_127       flow_51     -1.0
    x_127       link_127    1.0
    x_128       OBJ       32.6
    x_128       flow_24     1.0
    x_128       flow_26     -1.0
    x_128       link_128    1.0
    x_129       OBJ       2.92
    x_129       flow_3      1.0
    x_129       flow_31     -1.0
    x_129       link_129    1.0
    x_130       OBJ       70.92
    x_130       flow_33     1.0
    x_130       flow_40     -1.0
    x_130       link_130    1.0
    x_131       OBJ       45.91
    x_131       flow_24     1.0
    x_131       flow_25     -1.0
    x_131       link_131    1.0
    x_132       OBJ       2.27
    x_132       flow_1      1.0
    x_132       flow_8      -1.0
    x_132       link_132    1.0
    x_133       OBJ       1.48
    x_133       flow_37     1.0
    x_133       flow_31     -1.0
    x_133       link_133    1.0
    x_134       OBJ       1.62
    x_134       flow_33     1.0
    x_134       flow_54     -1.0
    x_134       link_134    1.0
    x_135       OBJ       2.56
    x_135       flow_33     1.0
    x_135       flow_43     -1.0
    x_135       link_135    1.0
    x_136       OBJ       2.44
    x_136       flow_48     1.0
    x_136       flow_29     -1.0
    x_136       link_136    1.0
    x_137       OBJ       58.73
    x_137       flow_14     1.0
    x_137       flow_36     -1.0
    x_137       link_137    1.0
    x_138       OBJ       46.25
    x_138       flow_40     1.0
    x_138       flow_16     -1.0
    x_138       link_138    1.0
    x_139       OBJ       54.97
    x_139       flow_4      1.0
    x_139       flow_19     -1.0
    x_139       link_139    1.0
    x_140       OBJ       36.72
    x_140       flow_34     1.0
    x_140       flow_19     -1.0
    x_140       link_140    1.0
    x_141       OBJ       52.82
    x_141       flow_15     1.0
    x_141       flow_30     -1.0
    x_141       link_141    1.0
    x_142       OBJ       0.55
    x_142       flow_45     1.0
    x_142       flow_41     -1.0
    x_142       link_142    1.0
    x_143       OBJ       1.07
    x_143       flow_41     1.0
    x_143       flow_26     -1.0
    x_143       link_143    1.0
    x_144       OBJ       1.35
    x_144       flow_14     1.0
    x_144       flow_31     -1.0
    x_144       link_144    1.0
    x_145       OBJ       1.23
    x_145       flow_25     1.0
    x_145       flow_12     -1.0
    x_145       link_145    1.0
    x_146       OBJ       38.7
    x_146       flow_13     1.0
    x_146       flow_31     -1.0
    x_146       link_146    1.0
    x_147       OBJ       2.72
    x_147       flow_29     1.0
    x_147       flow_14     -1.0
    x_147       link_147    1.0
    x_148       OBJ       1.06
    x_148       flow_31     1.0
    x_148       flow_39     -1.0
    x_148       link_148    1.0
    x_149       OBJ       1.48
    x_149       flow_3      1.0
    x_149       flow_38     -1.0
    x_149       link_149    1.0
    x_150       OBJ       0.65
    x_150       flow_9      1.0
    x_150       flow_26     -1.0
    x_150       link_150    1.0
    x_151       OBJ       0.7
    x_151       flow_20     1.0
    x_151       flow_46     -1.0
    x_151       link_151    1.0
    x_152       OBJ       64.78
    x_152       flow_11     1.0
    x_152       flow_41     -1.0
    x_152       link_152    1.0
    x_153       OBJ       79.1
    x_153       flow_46     1.0
    x_153       flow_24     -1.0
    x_153       link_153    1.0
    x_154       OBJ       1.38
    x_154       flow_0      1.0
    x_154       flow_5      -1.0
    x_154       link_154    1.0
    x_155       OBJ       1.39
    x_155       flow_35     1.0
    x_155       flow_48     -1.0
    x_155       link_155    1.0
    x_156       OBJ       2.26
    x_156       flow_51     1.0
    x_156       flow_27     -1.0
    x_156       link_156    1.0
    x_157       OBJ       2.34
    x_157       flow_28     1.0
    x_157       flow_12     -1.0
    x_157       link_157    1.0
    x_158       OBJ       66.0
    x_158       flow_26     1.0
    x_158       flow_15     -1.0
    x_158       link_158    1.0
    x_159       OBJ       2.37
    x_159       flow_51     1.0
    x_159       flow_3      -1.0
    x_159       link_159    1.0
    x_160       OBJ       2.88
    x_160       flow_23     1.0
    x_160       flow_17     -1.0
    x_160       link_160    1.0
    x_161       OBJ       1.19
    x_161       flow_45     1.0
    x_161       flow_44     -1.0
    x_161       link_161    1.0
    x_162       OBJ       76.6
    x_162       flow_38     1.0
    x_162       flow_51     -1.0
    x_162       link_162    1.0
    x_163       OBJ       47.94
    x_163       flow_6      1.0
    x_163       flow_30     -1.0
    x_163       link_163    1.0
    x_164       OBJ       27.96
    x_164       flow_16     1.0
    x_164       flow_27     -1.0
    x_164       link_164    1.0
    x_165       OBJ       2.23
    x_165       flow_51     1.0
    x_165       flow_47     -1.0
    x_165       link_165    1.0
    x_166       OBJ       55.74
    x_166       flow_29     1.0
    x_166       flow_23     -1.0
    x_166       link_166    1.0
    x_167       OBJ       0.66
    x_167       flow_48     1.0
    x_167       flow_10     -1.0
    x_167       link_167    1.0
    x_168       OBJ       1.57
    x_168       flow_34     1.0
    x_168       flow_20     -1.0
    x_168       link_168    1.0
    x_169       OBJ       0.74
    x_169       flow_16     1.0
    x_169       flow_39     -1.0
    x_169       link_169    1.0
    x_170       OBJ       1.54
    x_170       flow_28     1.0
    x_170       flow_11     -1.0
    x_170       link_170    1.0
    x_171       OBJ       66.43
    x_171       flow_15     1.0
    x_171       flow_47     -1.0
    x_171       link_171    1.0
    x_172       OBJ       1.92
    x_172       flow_53     1.0
    x_172       flow_18     -1.0
    x_172       link_172    1.0
    x_173       OBJ       0.96
    x_173       flow_16     1.0
    x_173       flow_12     -1.0
    x_173       link_173    1.0
    x_174       OBJ       1.49
    x_174       flow_37     1.0
    x_174       flow_12     -1.0
    x_174       link_174    1.0
    x_175       OBJ       26.03
    x_175       flow_33     1.0
    x_175       flow_14     -1.0
    x_175       link_175    1.0
    x_176       OBJ       2.55
    x_176       flow_6      1.0
    x_176       flow_0      -1.0
    x_176       link_176    1.0
    x_177       OBJ       0.63
    x_177       flow_2      1.0
    x_177       flow_18     -1.0
    x_177       link_177    1.0
    x_178       OBJ       30.67
    x_178       flow_4      1.0
    x_178       flow_23     -1.0
    x_178       link_178    1.0
    x_179       OBJ       26.35
    x_179       flow_49     1.0
    x_179       flow_42     -1.0
    x_179       link_179    1.0
    x_180       OBJ       1.35
    x_180       flow_22     1.0
    x_180       flow_13     -1.0
    x_180       link_180    1.0
    x_181       OBJ       74.84
    x_181       flow_2      1.0
    x_181       flow_38     -1.0
    x_181       link_181    1.0
    x_182       OBJ       31.11
    x_182       flow_20     1.0
    x_182       flow_26     -1.0
    x_182       link_182    1.0
    x_183       OBJ       1.71
    x_183       flow_2      1.0
    x_183       flow_50     -1.0
    x_183       link_183    1.0
    x_184       OBJ       58.35
    x_184       flow_25     1.0
    x_184       flow_42     -1.0
    x_184       link_184    1.0
    x_185       OBJ       2.97
    x_185       flow_25     1.0
    x_185       flow_44     -1.0
    x_185       link_185    1.0
    x_186       OBJ       73.02
    x_186       flow_3      1.0
    x_186       flow_19     -1.0
    x_186       link_186    1.0
    x_187       OBJ       0.99
    x_187       flow_49     1.0
    x_187       flow_51     -1.0
    x_187       link_187    1.0
    x_188       OBJ       45.43
    x_188       flow_0      1.0
    x_188       flow_27     -1.0
    x_188       link_188    1.0
    x_189       OBJ       0.91
    x_189       flow_36     1.0
    x_189       flow_23     -1.0
    x_189       link_189    1.0
    x_190       OBJ       43.8
    x_190       flow_9      1.0
    x_190       flow_41     -1.0
    x_190       link_190    1.0
    x_191       OBJ       1.37
    x_191       flow_47     1.0
    x_191       flow_32     -1.0
    x_191       link_191    1.0
    x_192       OBJ       2.38
    x_192       flow_4      1.0
    x_192       flow_6      -1.0
    x_192       link_192    1.0
    x_193       OBJ       2.86
    x_193       flow_12     1.0
    x_193       flow_19     -1.0
    x_193       link_193    1.0
    x_194       OBJ       58.18
    x_194       flow_20     1.0
    x_194       flow_3      -1.0
    x_194       link_194    1.0
    x_195       OBJ       29.62
    x_195       flow_39     1.0
    x_195       flow_44     -1.0
    x_195       link_195    1.0
    x_196       OBJ       31.77
    x_196       flow_39     1.0
    x_196       flow_25     -1.0
    x_196       link_196    1.0
    x_197       OBJ       1.79
    x_197       flow_13     1.0
    x_197       flow_2      -1.0
    x_197       link_197    1.0
    x_198       OBJ       68.94
    x_198       flow_9      1.0
    x_198       flow_15     -1.0
    x_198       link_198    1.0
    x_199       OBJ       60.07
    x_199       flow_53     1.0
    x_199       flow_48     -1.0
    x_199       link_199    1.0
    x_200       OBJ       57.62
    x_200       flow_38     1.0
    x_200       flow_29     -1.0
    x_200       link_200    1.0
    x_201       OBJ       1.47
    x_201       flow_19     1.0
    x_201       flow_37     -1.0
    x_201       link_201    1.0
    x_202       OBJ       49.37
    x_202       flow_1      1.0
    x_202       flow_0      -1.0
    x_202       link_202    1.0
    x_203       OBJ       70.19
    x_203       flow_39     1.0
    x_203       flow_49     -1.0
    x_203       link_203    1.0
    x_204       OBJ       1.58
    x_204       flow_6      1.0
    x_204       flow_4      -1.0
    x_204       link_204    1.0
    x_205       OBJ       0.83
    x_205       flow_42     1.0
    x_205       flow_2      -1.0
    x_205       link_205    1.0
    x_206       OBJ       23.26
    x_206       flow_49     1.0
    x_206       flow_46     -1.0
    x_206       link_206    1.0
    x_207       OBJ       2.64
    x_207       flow_41     1.0
    x_207       flow_50     -1.0
    x_207       link_207    1.0
    x_208       OBJ       0.83
    x_208       flow_44     1.0
    x_208       flow_52     -1.0
    x_208       link_208    1.0
    x_209       OBJ       2.47
    x_209       flow_51     1.0
    x_209       flow_50     -1.0
    x_209       link_209    1.0
    x_210       OBJ       35.13
    x_210       flow_53     1.0
    x_210       flow_22     -1.0
    x_210       link_210    1.0
    x_211       OBJ       1.14
    x_211       flow_17     1.0
    x_211       flow_52     -1.0
    x_211       link_211    1.0
    x_212       OBJ       1.77
    x_212       flow_13     1.0
    x_212       flow_37     -1.0
    x_212       link_212    1.0
    x_213       OBJ       2.09
    x_213       flow_12     1.0
    x_213       flow_11     -1.0
    x_213       link_213    1.0
    x_214       OBJ       35.86
    x_214       flow_24     1.0
    x_214       flow_10     -1.0
    x_214       link_214    1.0
    x_215       OBJ       2.68
    x_215       flow_40     1.0
    x_215       flow_54     -1.0
    x_215       link_215    1.0
    x_216       OBJ       1.84
    x_216       flow_44     1.0
    x_216       flow_6      -1.0
    x_216       link_216    1.0
    x_217       OBJ       2.98
    x_217       flow_51     1.0
    x_217       flow_23     -1.0
    x_217       link_217    1.0
    x_218       OBJ       1.08
    x_218       flow_21     1.0
    x_218       flow_48     -1.0
    x_218       link_218    1.0
    x_219       OBJ       38.6
    x_219       flow_18     1.0
    x_219       flow_52     -1.0
    x_219       link_219    1.0
    x_220       OBJ       63.98
    x_220       flow_37     1.0
    x_220       flow_42     -1.0
    x_220       link_220    1.0
    x_221       OBJ       45.93
    x_221       flow_9      1.0
    x_221       flow_18     -1.0
    x_221       link_221    1.0
    x_222       OBJ       2.13
    x_222       flow_8      1.0
    x_222       flow_31     -1.0
    x_222       link_222    1.0
    x_223       OBJ       1.81
    x_223       flow_36     1.0
    x_223       flow_22     -1.0
    x_223       link_223    1.0
    x_224       OBJ       32.25
    x_224       flow_37     1.0
    x_224       flow_19     -1.0
    x_224       link_224    1.0
    x_225       OBJ       2.5
    x_225       flow_10     1.0
    x_225       flow_8      -1.0
    x_225       link_225    1.0
    x_226       OBJ       66.93
    x_226       flow_40     1.0
    x_226       flow_9      -1.0
    x_226       link_226    1.0
    x_227       OBJ       53.74
    x_227       flow_0      1.0
    x_227       flow_3      -1.0
    x_227       link_227    1.0
    x_228       OBJ       51.05
    x_228       flow_37     1.0
    x_228       flow_28     -1.0
    x_228       link_228    1.0
    x_229       OBJ       0.56
    x_229       flow_0      1.0
    x_229       flow_2      -1.0
    x_229       link_229    1.0
    x_230       OBJ       2.03
    x_230       flow_3      1.0
    x_230       flow_49     -1.0
    x_230       link_230    1.0
    x_231       OBJ       50.42
    x_231       flow_12     1.0
    x_231       flow_33     -1.0
    x_231       link_231    1.0
    x_232       OBJ       23.83
    x_232       flow_39     1.0
    x_232       flow_11     -1.0
    x_232       link_232    1.0
    x_233       OBJ       20.38
    x_233       flow_50     1.0
    x_233       flow_30     -1.0
    x_233       link_233    1.0
    x_234       OBJ       47.15
    x_234       flow_29     1.0
    x_234       flow_5      -1.0
    x_234       link_234    1.0
    x_235       OBJ       27.4
    x_235       flow_16     1.0
    x_235       flow_14     -1.0
    x_235       link_235    1.0
    x_236       OBJ       35.96
    x_236       flow_54     1.0
    x_236       flow_16     -1.0
    x_236       link_236    1.0
    x_237       OBJ       78.31
    x_237       flow_43     1.0
    x_237       flow_50     -1.0
    x_237       link_237    1.0
    x_238       OBJ       1.15
    x_238       flow_5      1.0
    x_238       flow_32     -1.0
    x_238       link_238    1.0
    x_239       OBJ       39.61
    x_239       flow_12     1.0
    x_239       flow_10     -1.0
    x_239       link_239    1.0
    x_240       OBJ       2.63
    x_240       flow_38     1.0
    x_240       flow_15     -1.0
    x_240       link_240    1.0
    x_241       OBJ       2.6
    x_241       flow_53     1.0
    x_241       flow_34     -1.0
    x_241       link_241    1.0
    x_242       OBJ       34.03
    x_242       flow_1      1.0
    x_242       flow_27     -1.0
    x_242       link_242    1.0
    x_243       OBJ       24.67
    x_243       flow_13     1.0
    x_243       flow_25     -1.0
    x_243       link_243    1.0
    x_244       OBJ       2.05
    x_244       flow_2      1.0
    x_244       flow_1      -1.0
    x_244       link_244    1.0
    x_245       OBJ       0.85
    x_245       flow_44     1.0
    x_245       flow_1      -1.0
    x_245       link_245    1.0
    x_246       OBJ       23.95
    x_246       flow_44     1.0
    x_246       flow_4      -1.0
    x_246       link_246    1.0
    x_247       OBJ       52.03
    x_247       flow_12     1.0
    x_247       flow_52     -1.0
    x_247       link_247    1.0
    x_248       OBJ       26.43
    x_248       flow_48     1.0
    x_248       flow_45     -1.0
    x_248       link_248    1.0
    x_249       OBJ       25.25
    x_249       flow_54     1.0
    x_249       flow_51     -1.0
    x_249       link_249    1.0
    x_250       OBJ       0.74
    x_250       flow_18     1.0
    x_250       flow_30     -1.0
    x_250       link_250    1.0
    x_251       OBJ       1.15
    x_251       flow_18     1.0
    x_251       flow_20     -1.0
    x_251       link_251    1.0
    x_252       OBJ       74.62
    x_252       flow_3      1.0
    x_252       flow_45     -1.0
    x_252       link_252    1.0
    x_253       OBJ       57.1
    x_253       flow_32     1.0
    x_253       flow_30     -1.0
    x_253       link_253    1.0
    x_254       OBJ       1.67
    x_254       flow_33     1.0
    x_254       flow_49     -1.0
    x_254       link_254    1.0
    x_255       OBJ       25.45
    x_255       flow_13     1.0
    x_255       flow_45     -1.0
    x_255       link_255    1.0
    x_256       OBJ       37.3
    x_256       flow_27     1.0
    x_256       flow_0      -1.0
    x_256       link_256    1.0
    x_257       OBJ       1.73
    x_257       flow_0      1.0
    x_257       flow_22     -1.0
    x_257       link_257    1.0
    x_258       OBJ       2.58
    x_258       flow_31     1.0
    x_258       flow_37     -1.0
    x_258       link_258    1.0
    x_259       OBJ       0.91
    x_259       flow_13     1.0
    x_259       flow_44     -1.0
    x_259       link_259    1.0
    x_260       OBJ       61.83
    x_260       flow_5      1.0
    x_260       flow_31     -1.0
    x_260       link_260    1.0
    x_261       OBJ       2.82
    x_261       flow_20     1.0
    x_261       flow_22     -1.0
    x_261       link_261    1.0
    x_262       OBJ       21.51
    x_262       flow_5      1.0
    x_262       flow_27     -1.0
    x_262       link_262    1.0
    x_263       OBJ       42.76
    x_263       flow_27     1.0
    x_263       flow_34     -1.0
    x_263       link_263    1.0
    x_264       OBJ       65.27
    x_264       flow_29     1.0
    x_264       flow_8      -1.0
    x_264       link_264    1.0
    x_265       OBJ       51.3
    x_265       flow_2      1.0
    x_265       flow_22     -1.0
    x_265       link_265    1.0
    x_266       OBJ       30.17
    x_266       flow_42     1.0
    x_266       flow_35     -1.0
    x_266       link_266    1.0
    x_267       OBJ       1.34
    x_267       flow_16     1.0
    x_267       flow_37     -1.0
    x_267       link_267    1.0
    x_268       OBJ       2.26
    x_268       flow_12     1.0
    x_268       flow_17     -1.0
    x_268       link_268    1.0
    x_269       OBJ       63.39
    x_269       flow_46     1.0
    x_269       flow_9      -1.0
    x_269       link_269    1.0
    x_270       OBJ       0.97
    x_270       flow_10     1.0
    x_270       flow_15     -1.0
    x_270       link_270    1.0
    x_271       OBJ       26.1
    x_271       flow_6      1.0
    x_271       flow_10     -1.0
    x_271       link_271    1.0
    x_272       OBJ       46.1
    x_272       flow_50     1.0
    x_272       flow_19     -1.0
    x_272       link_272    1.0
    x_273       OBJ       1.47
    x_273       flow_6      1.0
    x_273       flow_17     -1.0
    x_273       link_273    1.0
    x_274       OBJ       1.06
    x_274       flow_54     1.0
    x_274       flow_50     -1.0
    x_274       link_274    1.0
    x_275       OBJ       2.01
    x_275       flow_29     1.0
    x_275       flow_1      -1.0
    x_275       link_275    1.0
    x_276       OBJ       1.93
    x_276       flow_15     1.0
    x_276       flow_54     -1.0
    x_276       link_276    1.0
    x_277       OBJ       59.15
    x_277       flow_54     1.0
    x_277       flow_14     -1.0
    x_277       link_277    1.0
    x_278       OBJ       60.78
    x_278       flow_44     1.0
    x_278       flow_37     -1.0
    x_278       link_278    1.0
    x_279       OBJ       2.25
    x_279       flow_27     1.0
    x_279       flow_20     -1.0
    x_279       link_279    1.0
    x_280       OBJ       57.78
    x_280       flow_50     1.0
    x_280       flow_25     -1.0
    x_280       link_280    1.0
    x_281       OBJ       2.65
    x_281       flow_30     1.0
    x_281       flow_29     -1.0
    x_281       link_281    1.0
    x_282       OBJ       2.58
    x_282       flow_20     1.0
    x_282       flow_49     -1.0
    x_282       link_282    1.0
    x_283       OBJ       29.65
    x_283       flow_2      1.0
    x_283       flow_16     -1.0
    x_283       link_283    1.0
    x_284       OBJ       1.94
    x_284       flow_33     1.0
    x_284       flow_22     -1.0
    x_284       link_284    1.0
    x_285       OBJ       42.19
    x_285       flow_1      1.0
    x_285       flow_40     -1.0
    x_285       link_285    1.0
    x_286       OBJ       31.03
    x_286       flow_29     1.0
    x_286       flow_13     -1.0
    x_286       link_286    1.0
    x_287       OBJ       0.64
    x_287       flow_46     1.0
    x_287       flow_39     -1.0
    x_287       link_287    1.0
    x_288       OBJ       2.79
    x_288       flow_3      1.0
    x_288       flow_0      -1.0
    x_288       link_288    1.0
    x_289       OBJ       1.06
    x_289       flow_22     1.0
    x_289       flow_37     -1.0
    x_289       link_289    1.0
    x_290       OBJ       47.73
    x_290       flow_14     1.0
    x_290       flow_51     -1.0
    x_290       link_290    1.0
    x_291       OBJ       31.59
    x_291       flow_4      1.0
    x_291       flow_51     -1.0
    x_291       link_291    1.0
    x_292       OBJ       41.19
    x_292       flow_14     1.0
    x_292       flow_52     -1.0
    x_292       link_292    1.0
    x_293       OBJ       2.99
    x_293       flow_50     1.0
    x_293       flow_52     -1.0
    x_293       link_293    1.0
    x_294       OBJ       41.28
    x_294       flow_8      1.0
    x_294       flow_49     -1.0
    x_294       link_294    1.0
    x_295       OBJ       78.97
    x_295       flow_45     1.0
    x_295       flow_24     -1.0
    x_295       link_295    1.0
    x_296       OBJ       36.87
    x_296       flow_0      1.0
    x_296       flow_51     -1.0
    x_296       link_296    1.0
    x_297       OBJ       2.06
    x_297       flow_20     1.0
    x_297       flow_30     -1.0
    x_297       link_297    1.0
    x_298       OBJ       23.42
    x_298       flow_9      1.0
    x_298       flow_19     -1.0
    x_298       link_298    1.0
    x_299       OBJ       40.71
    x_299       flow_50     1.0
    x_299       flow_8      -1.0
    x_299       link_299    1.0
    x_300       OBJ       59.36
    x_300       flow_0      1.0
    x_300       flow_13     -1.0
    x_300       link_300    1.0
    x_301       OBJ       31.14
    x_301       flow_37     1.0
    x_301       flow_9      -1.0
    x_301       link_301    1.0
    x_302       OBJ       67.5
    x_302       flow_9      1.0
    x_302       flow_13     -1.0
    x_302       link_302    1.0
    x_303       OBJ       2.75
    x_303       flow_38     1.0
    x_303       flow_50     -1.0
    x_303       link_303    1.0
    x_304       OBJ       2.23
    x_304       flow_53     1.0
    x_304       flow_19     -1.0
    x_304       link_304    1.0
    x_305       OBJ       35.87
    x_305       flow_42     1.0
    x_305       flow_7      -1.0
    x_305       link_305    1.0
    x_306       OBJ       49.06
    x_306       flow_30     1.0
    x_306       flow_31     -1.0
    x_306       link_306    1.0
    x_307       OBJ       1.85
    x_307       flow_31     1.0
    x_307       flow_15     -1.0
    x_307       link_307    1.0
    x_308       OBJ       2.24
    x_308       flow_10     1.0
    x_308       flow_53     -1.0
    x_308       link_308    1.0
    x_309       OBJ       1.55
    x_309       flow_53     1.0
    x_309       flow_29     -1.0
    x_309       link_309    1.0
    x_310       OBJ       2.12
    x_310       flow_11     1.0
    x_310       flow_40     -1.0
    x_310       link_310    1.0
    x_311       OBJ       39.83
    x_311       flow_43     1.0
    x_311       flow_47     -1.0
    x_311       link_311    1.0
    x_312       OBJ       2.3
    x_312       flow_48     1.0
    x_312       flow_9      -1.0
    x_312       link_312    1.0
    x_313       OBJ       1.81
    x_313       flow_23     1.0
    x_313       flow_21     -1.0
    x_313       link_313    1.0
    x_314       OBJ       1.13
    x_314       flow_18     1.0
    x_314       flow_27     -1.0
    x_314       link_314    1.0
    x_315       OBJ       44.22
    x_315       flow_18     1.0
    x_315       flow_22     -1.0
    x_315       link_315    1.0
    x_316       OBJ       59.27
    x_316       flow_32     1.0
    x_316       flow_22     -1.0
    x_316       link_316    1.0
    x_317       OBJ       27.65
    x_317       flow_12     1.0
    x_317       flow_20     -1.0
    x_317       link_317    1.0
    x_318       OBJ       1.89
    x_318       flow_50     1.0
    x_318       flow_2      -1.0
    x_318       link_318    1.0
    x_319       OBJ       0.52
    x_319       flow_3      1.0
    x_319       flow_25     -1.0
    x_319       link_319    1.0
    x_320       OBJ       67.34
    x_320       flow_38     1.0
    x_320       flow_49     -1.0
    x_320       link_320    1.0
    x_321       OBJ       2.18
    x_321       flow_24     1.0
    x_321       flow_39     -1.0
    x_321       link_321    1.0
    x_322       OBJ       2.08
    x_322       flow_5      1.0
    x_322       flow_13     -1.0
    x_322       link_322    1.0
    x_323       OBJ       0.75
    x_323       flow_11     1.0
    x_323       flow_2      -1.0
    x_323       link_323    1.0
    x_324       OBJ       1.27
    x_324       flow_23     1.0
    x_324       flow_52     -1.0
    x_324       link_324    1.0
    x_325       OBJ       1.3
    x_325       flow_19     1.0
    x_325       flow_11     -1.0
    x_325       link_325    1.0
    x_326       OBJ       1.81
    x_326       flow_37     1.0
    x_326       flow_3      -1.0
    x_326       link_326    1.0
    x_327       OBJ       75.12
    x_327       flow_51     1.0
    x_327       flow_26     -1.0
    x_327       link_327    1.0
    x_328       OBJ       79.59
    x_328       flow_43     1.0
    x_328       flow_24     -1.0
    x_328       link_328    1.0
    x_329       OBJ       0.76
    x_329       flow_30     1.0
    x_329       flow_49     -1.0
    x_329       link_329    1.0
    x_330       OBJ       0.51
    x_330       flow_9      1.0
    x_330       flow_40     -1.0
    x_330       link_330    1.0
    x_331       OBJ       0.8
    x_331       flow_54     1.0
    x_331       flow_5      -1.0
    x_331       link_331    1.0
    x_332       OBJ       2.33
    x_332       flow_46     1.0
    x_332       flow_36     -1.0
    x_332       link_332    1.0
    x_333       OBJ       61.69
    x_333       flow_23     1.0
    x_333       flow_49     -1.0
    x_333       link_333    1.0
    x_334       OBJ       62.55
    x_334       flow_5      1.0
    x_334       flow_18     -1.0
    x_334       link_334    1.0
    x_335       OBJ       2.71
    x_335       flow_2      1.0
    x_335       flow_0      -1.0
    x_335       link_335    1.0
    x_336       OBJ       2.32
    x_336       flow_5      1.0
    x_336       flow_24     -1.0
    x_336       link_336    1.0
    x_337       OBJ       38.98
    x_337       flow_53     1.0
    x_337       flow_31     -1.0
    x_337       link_337    1.0
    x_338       OBJ       28.69
    x_338       flow_28     1.0
    x_338       flow_30     -1.0
    x_338       link_338    1.0
    x_339       OBJ       1.46
    x_339       flow_40     1.0
    x_339       flow_51     -1.0
    x_339       link_339    1.0
    x_340       OBJ       37.54
    x_340       flow_50     1.0
    x_340       flow_48     -1.0
    x_340       link_340    1.0
    x_341       OBJ       39.92
    x_341       flow_45     1.0
    x_341       flow_51     -1.0
    x_341       link_341    1.0
    x_342       OBJ       38.52
    x_342       flow_53     1.0
    x_342       flow_9      -1.0
    x_342       link_342    1.0
    x_343       OBJ       39.29
    x_343       flow_28     1.0
    x_343       flow_18     -1.0
    x_343       link_343    1.0
    x_344       OBJ       66.99
    x_344       flow_37     1.0
    x_344       flow_52     -1.0
    x_344       link_344    1.0
    x_345       OBJ       2.94
    x_345       flow_51     1.0
    x_345       flow_36     -1.0
    x_345       link_345    1.0
    x_346       OBJ       40.81
    x_346       flow_43     1.0
    x_346       flow_49     -1.0
    x_346       link_346    1.0
    x_347       OBJ       2.47
    x_347       flow_31     1.0
    x_347       flow_51     -1.0
    x_347       link_347    1.0
    x_348       OBJ       1.49
    x_348       flow_19     1.0
    x_348       flow_38     -1.0
    x_348       link_348    1.0
    x_349       OBJ       1.46
    x_349       flow_37     1.0
    x_349       flow_48     -1.0
    x_349       link_349    1.0
    x_350       OBJ       33.97
    x_350       flow_51     1.0
    x_350       flow_22     -1.0
    x_350       link_350    1.0
    x_351       OBJ       1.77
    x_351       flow_53     1.0
    x_351       flow_33     -1.0
    x_351       link_351    1.0
    x_352       OBJ       2.25
    x_352       flow_12     1.0
    x_352       flow_5      -1.0
    x_352       link_352    1.0
    x_353       OBJ       71.42
    x_353       flow_22     1.0
    x_353       flow_25     -1.0
    x_353       link_353    1.0
    x_354       OBJ       1.66
    x_354       flow_23     1.0
    x_354       flow_6      -1.0
    x_354       link_354    1.0
    x_355       OBJ       1.8
    x_355       flow_38     1.0
    x_355       flow_1      -1.0
    x_355       link_355    1.0
    x_356       OBJ       1.92
    x_356       flow_13     1.0
    x_356       flow_36     -1.0
    x_356       link_356    1.0
    x_357       OBJ       1.62
    x_357       flow_17     1.0
    x_357       flow_27     -1.0
    x_357       link_357    1.0
    x_358       OBJ       40.33
    x_358       flow_8      1.0
    x_358       flow_16     -1.0
    x_358       link_358    1.0
    x_359       OBJ       72.24
    x_359       flow_3      1.0
    x_359       flow_2      -1.0
    x_359       link_359    1.0
    x_360       OBJ       75.33
    x_360       flow_4      1.0
    x_360       flow_38     -1.0
    x_360       link_360    1.0
    x_361       OBJ       58.44
    x_361       flow_16     1.0
    x_361       flow_20     -1.0
    x_361       link_361    1.0
    x_362       OBJ       42.25
    x_362       flow_11     1.0
    x_362       flow_28     -1.0
    x_362       link_362    1.0
    x_363       OBJ       1.14
    x_363       flow_14     1.0
    x_363       flow_11     -1.0
    x_363       link_363    1.0
    x_364       OBJ       35.47
    x_364       flow_1      1.0
    x_364       flow_53     -1.0
    x_364       link_364    1.0
    x_365       OBJ       23.35
    x_365       flow_41     1.0
    x_365       flow_48     -1.0
    x_365       link_365    1.0
    x_366       OBJ       37.93
    x_366       flow_0      1.0
    x_366       flow_12     -1.0
    x_366       link_366    1.0
    x_367       OBJ       1.43
    x_367       flow_41     1.0
    x_367       flow_6      -1.0
    x_367       link_367    1.0
    x_368       OBJ       1.1
    x_368       flow_30     1.0
    x_368       flow_24     -1.0
    x_368       link_368    1.0
    x_369       OBJ       31.71
    x_369       flow_0      1.0
    x_369       flow_29     -1.0
    x_369       link_369    1.0
    x_370       OBJ       28.39
    x_370       flow_39     1.0
    x_370       flow_23     -1.0
    x_370       link_370    1.0
    x_371       OBJ       0.69
    x_371       flow_24     1.0
    x_371       flow_53     -1.0
    x_371       link_371    1.0
    x_372       OBJ       2.07
    x_372       flow_52     1.0
    x_372       flow_14     -1.0
    x_372       link_372    1.0
    x_373       OBJ       1.63
    x_373       flow_47     1.0
    x_373       flow_3      -1.0
    x_373       link_373    1.0
    x_374       OBJ       1.12
    x_374       flow_9      1.0
    x_374       flow_17     -1.0
    x_374       link_374    1.0
    x_375       OBJ       1.73
    x_375       flow_21     1.0
    x_375       flow_51     -1.0
    x_375       link_375    1.0
    x_376       OBJ       23.41
    x_376       flow_7      1.0
    x_376       flow_9      -1.0
    x_376       link_376    1.0
    x_377       OBJ       1.22
    x_377       flow_13     1.0
    x_377       flow_35     -1.0
    x_377       link_377    1.0
    x_378       OBJ       79.89
    x_378       flow_23     1.0
    x_378       flow_27     -1.0
    x_378       link_378    1.0
    x_379       OBJ       0.91
    x_379       flow_24     1.0
    x_379       flow_18     -1.0
    x_379       link_379    1.0
    x_380       OBJ       40.45
    x_380       flow_1      1.0
    x_380       flow_28     -1.0
    x_380       link_380    1.0
    x_381       OBJ       37.18
    x_381       flow_50     1.0
    x_381       flow_53     -1.0
    x_381       link_381    1.0
    x_382       OBJ       0.95
    x_382       flow_26     1.0
    x_382       flow_13     -1.0
    x_382       link_382    1.0
    x_383       OBJ       31.8
    x_383       flow_49     1.0
    x_383       flow_14     -1.0
    x_383       link_383    1.0
    x_384       OBJ       1.18
    x_384       flow_38     1.0
    x_384       flow_46     -1.0
    x_384       link_384    1.0
    x_385       OBJ       31.53
    x_385       flow_42     1.0
    x_385       flow_45     -1.0
    x_385       link_385    1.0
    x_386       OBJ       44.49
    x_386       flow_4      1.0
    x_386       flow_44     -1.0
    x_386       link_386    1.0
    x_387       OBJ       1.2
    x_387       flow_33     1.0
    x_387       flow_51     -1.0
    x_387       link_387    1.0
    x_388       OBJ       2.41
    x_388       flow_5      1.0
    x_388       flow_0      -1.0
    x_388       link_388    1.0
    x_389       OBJ       2.58
    x_389       flow_17     1.0
    x_389       flow_15     -1.0
    x_389       link_389    1.0
    x_390       OBJ       71.48
    x_390       flow_44     1.0
    x_390       flow_23     -1.0
    x_390       link_390    1.0
    x_391       OBJ       2.29
    x_391       flow_33     1.0
    x_391       flow_4      -1.0
    x_391       link_391    1.0
    x_392       OBJ       37.49
    x_392       flow_36     1.0
    x_392       flow_48     -1.0
    x_392       link_392    1.0
    x_393       OBJ       51.83
    x_393       flow_31     1.0
    x_393       flow_28     -1.0
    x_393       link_393    1.0
    x_394       OBJ       1.13
    x_394       flow_11     1.0
    x_394       flow_10     -1.0
    x_394       link_394    1.0
    x_395       OBJ       64.32
    x_395       flow_1      1.0
    x_395       flow_6      -1.0
    x_395       link_395    1.0
    x_396       OBJ       51.37
    x_396       flow_38     1.0
    x_396       flow_40     -1.0
    x_396       link_396    1.0
    x_397       OBJ       22.71
    x_397       flow_22     1.0
    x_397       flow_6      -1.0
    x_397       link_397    1.0
    x_398       OBJ       26.6
    x_398       flow_37     1.0
    x_398       flow_32     -1.0
    x_398       link_398    1.0
    x_399       OBJ       1.07
    x_399       flow_34     1.0
    x_399       flow_37     -1.0
    x_399       link_399    1.0
    x_400       OBJ       2.57
    x_400       flow_47     1.0
    x_400       flow_25     -1.0
    x_400       link_400    1.0
    x_401       OBJ       56.17
    x_401       flow_44     1.0
    x_401       flow_26     -1.0
    x_401       link_401    1.0
    x_402       OBJ       1.1
    x_402       flow_49     1.0
    x_402       flow_23     -1.0
    x_402       link_402    1.0
    x_403       OBJ       74.77
    x_403       flow_53     1.0
    x_403       flow_36     -1.0
    x_403       link_403    1.0
    x_404       OBJ       0.87
    x_404       flow_35     1.0
    x_404       flow_3      -1.0
    x_404       link_404    1.0
    x_405       OBJ       20.69
    x_405       flow_15     1.0
    x_405       flow_27     -1.0
    x_405       link_405    1.0
    x_406       OBJ       1.76
    x_406       flow_4      1.0
    x_406       flow_20     -1.0
    x_406       link_406    1.0
    x_407       OBJ       76.22
    x_407       flow_26     1.0
    x_407       flow_25     -1.0
    x_407       link_407    1.0
    x_408       OBJ       2.2
    x_408       flow_41     1.0
    x_408       flow_39     -1.0
    x_408       link_408    1.0
    x_409       OBJ       35.03
    x_409       flow_51     1.0
    x_409       flow_2      -1.0
    x_409       link_409    1.0
    x_410       OBJ       1.26
    x_410       flow_15     1.0
    x_410       flow_2      -1.0
    x_410       link_410    1.0
    x_411       OBJ       1.98
    x_411       flow_32     1.0
    x_411       flow_17     -1.0
    x_411       link_411    1.0
    x_412       OBJ       54.64
    x_412       flow_8      1.0
    x_412       flow_18     -1.0
    x_412       link_412    1.0
    x_413       OBJ       70.38
    x_413       flow_5      1.0
    x_413       flow_47     -1.0
    x_413       link_413    1.0
    x_414       OBJ       1.87
    x_414       flow_14     1.0
    x_414       flow_41     -1.0
    x_414       link_414    1.0
    x_415       OBJ       2.55
    x_415       flow_19     1.0
    x_415       flow_39     -1.0
    x_415       link_415    1.0
    x_416       OBJ       42.99
    x_416       flow_14     1.0
    x_416       flow_12     -1.0
    x_416       link_416    1.0
    x_417       OBJ       34.31
    x_417       flow_22     1.0
    x_417       flow_10     -1.0
    x_417       link_417    1.0
    x_418       OBJ       32.97
    x_418       flow_17     1.0
    x_418       flow_18     -1.0
    x_418       link_418    1.0
    x_419       OBJ       2.68
    x_419       flow_10     1.0
    x_419       flow_35     -1.0
    x_419       link_419    1.0
    x_420       OBJ       41.25
    x_420       flow_33     1.0
    x_420       flow_24     -1.0
    x_420       link_420    1.0
    x_421       OBJ       29.27
    x_421       flow_14     1.0
    x_421       flow_43     -1.0
    x_421       link_421    1.0
    x_422       OBJ       2.03
    x_422       flow_8      1.0
    x_422       flow_43     -1.0
    x_422       link_422    1.0
    x_423       OBJ       64.6
    x_423       flow_33     1.0
    x_423       flow_6      -1.0
    x_423       link_423    1.0
    x_424       OBJ       57.93
    x_424       flow_17     1.0
    x_424       flow_50     -1.0
    x_424       link_424    1.0
    x_425       OBJ       27.05
    x_425       flow_26     1.0
    x_425       flow_49     -1.0
    x_425       link_425    1.0
    x_426       OBJ       42.77
    x_426       flow_17     1.0
    x_426       flow_39     -1.0
    x_426       link_426    1.0
    x_427       OBJ       1.82
    x_427       flow_22     1.0
    x_427       flow_18     -1.0
    x_427       link_427    1.0
    x_428       OBJ       70.97
    x_428       flow_20     1.0
    x_428       flow_0      -1.0
    x_428       link_428    1.0
    x_429       OBJ       1.44
    x_429       flow_51     1.0
    x_429       flow_9      -1.0
    x_429       link_429    1.0
    x_430       OBJ       56.49
    x_430       flow_21     1.0
    x_430       flow_20     -1.0
    x_430       link_430    1.0
    x_431       OBJ       77.35
    x_431       flow_13     1.0
    x_431       flow_27     -1.0
    x_431       link_431    1.0
    x_432       OBJ       1.84
    x_432       flow_36     1.0
    x_432       flow_31     -1.0
    x_432       link_432    1.0
    x_433       OBJ       63.63
    x_433       flow_27     1.0
    x_433       flow_33     -1.0
    x_433       link_433    1.0
    x_434       OBJ       41.07
    x_434       flow_22     1.0
    x_434       flow_2      -1.0
    x_434       link_434    1.0
    x_435       OBJ       1.52
    x_435       flow_4      1.0
    x_435       flow_33     -1.0
    x_435       link_435    1.0
    x_436       OBJ       0.97
    x_436       flow_35     1.0
    x_436       flow_36     -1.0
    x_436       link_436    1.0
    x_437       OBJ       79.77
    x_437       flow_28     1.0
    x_437       flow_49     -1.0
    x_437       link_437    1.0
    x_438       OBJ       1.41
    x_438       flow_47     1.0
    x_438       flow_52     -1.0
    x_438       link_438    1.0
    x_439       OBJ       26.63
    x_439       flow_52     1.0
    x_439       flow_19     -1.0
    x_439       link_439    1.0
    x_440       OBJ       50.53
    x_440       flow_21     1.0
    x_440       flow_52     -1.0
    x_440       link_440    1.0
    x_441       OBJ       1.78
    x_441       flow_10     1.0
    x_441       flow_33     -1.0
    x_441       link_441    1.0
    x_442       OBJ       1.91
    x_442       flow_26     1.0
    x_442       flow_11     -1.0
    x_442       link_442    1.0
    x_443       OBJ       20.64
    x_443       flow_46     1.0
    x_443       flow_2      -1.0
    x_443       link_443    1.0
    x_444       OBJ       1.26
    x_444       flow_44     1.0
    x_444       flow_35     -1.0
    x_444       link_444    1.0
    x_445       OBJ       0.94
    x_445       flow_0      1.0
    x_445       flow_42     -1.0
    x_445       link_445    1.0
    x_446       OBJ       50.86
    x_446       flow_17     1.0
    x_446       flow_41     -1.0
    x_446       link_446    1.0
    x_447       OBJ       0.89
    x_447       flow_26     1.0
    x_447       flow_38     -1.0
    x_447       link_447    1.0
    x_448       OBJ       49.43
    x_448       flow_4      1.0
    x_448       flow_10     -1.0
    x_448       link_448    1.0
    x_449       OBJ       2.43
    x_449       flow_3      1.0
    x_449       flow_41     -1.0
    x_449       link_449    1.0
    x_450       OBJ       0.58
    x_450       flow_15     1.0
    x_450       flow_22     -1.0
    x_450       link_450    1.0
    x_451       OBJ       1.62
    x_451       flow_37     1.0
    x_451       flow_4      -1.0
    x_451       link_451    1.0
    x_452       OBJ       77.58
    x_452       flow_14     1.0
    x_452       flow_25     -1.0
    x_452       link_452    1.0
    x_453       OBJ       1.97
    x_453       flow_14     1.0
    x_453       flow_2      -1.0
    x_453       link_453    1.0
    x_454       OBJ       2.01
    x_454       flow_52     1.0
    x_454       flow_29     -1.0
    x_454       link_454    1.0
    x_455       OBJ       60.49
    x_455       flow_4      1.0
    x_455       flow_15     -1.0
    x_455       link_455    1.0
    x_456       OBJ       49.06
    x_456       flow_19     1.0
    x_456       flow_25     -1.0
    x_456       link_456    1.0
    x_457       OBJ       1.45
    x_457       flow_5      1.0
    x_457       flow_11     -1.0
    x_457       link_457    1.0
    x_458       OBJ       1.34
    x_458       flow_25     1.0
    x_458       flow_35     -1.0
    x_458       link_458    1.0
    x_459       OBJ       0.81
    x_459       flow_25     1.0
    x_459       flow_41     -1.0
    x_459       link_459    1.0
    x_460       OBJ       1.67
    x_460       flow_35     1.0
    x_460       flow_15     -1.0
    x_460       link_460    1.0
    x_461       OBJ       40.49
    x_461       flow_2      1.0
    x_461       flow_17     -1.0
    x_461       link_461    1.0
    x_462       OBJ       1.86
    x_462       flow_8      1.0
    x_462       flow_5      -1.0
    x_462       link_462    1.0
    x_463       OBJ       68.3
    x_463       flow_28     1.0
    x_463       flow_29     -1.0
    x_463       link_463    1.0
    x_464       OBJ       2.07
    x_464       flow_13     1.0
    x_464       flow_46     -1.0
    x_464       link_464    1.0
    x_465       OBJ       60.52
    x_465       flow_13     1.0
    x_465       flow_14     -1.0
    x_465       link_465    1.0
    x_466       OBJ       42.08
    x_466       flow_38     1.0
    x_466       flow_28     -1.0
    x_466       link_466    1.0
    x_467       OBJ       2.38
    x_467       flow_32     1.0
    x_467       flow_13     -1.0
    x_467       link_467    1.0
    x_468       OBJ       2.43
    x_468       flow_34     1.0
    x_468       flow_54     -1.0
    x_468       link_468    1.0
    x_469       OBJ       0.54
    x_469       flow_45     1.0
    x_469       flow_36     -1.0
    x_469       link_469    1.0
    x_470       OBJ       39.26
    x_470       flow_11     1.0
    x_470       flow_49     -1.0
    x_470       link_470    1.0
    x_471       OBJ       68.31
    x_471       flow_4      1.0
    x_471       flow_35     -1.0
    x_471       link_471    1.0
    x_472       OBJ       1.07
    x_472       flow_4      1.0
    x_472       flow_45     -1.0
    x_472       link_472    1.0
    x_473       OBJ       2.61
    x_473       flow_25     1.0
    x_473       flow_18     -1.0
    x_473       link_473    1.0
    x_474       OBJ       30.58
    x_474       flow_40     1.0
    x_474       flow_8      -1.0
    x_474       link_474    1.0
    x_475       OBJ       1.53
    x_475       flow_42     1.0
    x_475       flow_44     -1.0
    x_475       link_475    1.0
    x_476       OBJ       44.03
    x_476       flow_29     1.0
    x_476       flow_15     -1.0
    x_476       link_476    1.0
    x_477       OBJ       2.78
    x_477       flow_11     1.0
    x_477       flow_18     -1.0
    x_477       link_477    1.0
    x_478       OBJ       2.02
    x_478       flow_43     1.0
    x_478       flow_2      -1.0
    x_478       link_478    1.0
    x_479       OBJ       0.6
    x_479       flow_19     1.0
    x_479       flow_9      -1.0
    x_479       link_479    1.0
    x_480       OBJ       54.21
    x_480       flow_11     1.0
    x_480       flow_36     -1.0
    x_480       link_480    1.0
    x_481       OBJ       40.94
    x_481       flow_27     1.0
    x_481       flow_42     -1.0
    x_481       link_481    1.0
    x_482       OBJ       74.06
    x_482       flow_48     1.0
    x_482       flow_49     -1.0
    x_482       link_482    1.0
    x_483       OBJ       1.11
    x_483       flow_38     1.0
    x_483       flow_44     -1.0
    x_483       link_483    1.0
    x_484       OBJ       40.74
    x_484       flow_20     1.0
    x_484       flow_13     -1.0
    x_484       link_484    1.0
    x_485       OBJ       2.37
    x_485       flow_44     1.0
    x_485       flow_47     -1.0
    x_485       link_485    1.0
    x_486       OBJ       2.87
    x_486       flow_33     1.0
    x_486       flow_5      -1.0
    x_486       link_486    1.0
    x_487       OBJ       69.8
    x_487       flow_44     1.0
    x_487       flow_32     -1.0
    x_487       link_487    1.0
    x_488       OBJ       32.36
    x_488       flow_32     1.0
    x_488       flow_3      -1.0
    x_488       link_488    1.0
    x_489       OBJ       0.97
    x_489       flow_49     1.0
    x_489       flow_8      -1.0
    x_489       link_489    1.0
    x_490       OBJ       1.87
    x_490       flow_51     1.0
    x_490       flow_35     -1.0
    x_490       link_490    1.0
    x_491       OBJ       2.91
    x_491       flow_15     1.0
    x_491       flow_34     -1.0
    x_491       link_491    1.0
    x_492       OBJ       1.28
    x_492       flow_26     1.0
    x_492       flow_5      -1.0
    x_492       link_492    1.0
    x_493       OBJ       2.26
    x_493       flow_31     1.0
    x_493       flow_42     -1.0
    x_493       link_493    1.0
    x_494       OBJ       41.09
    x_494       flow_28     1.0
    x_494       flow_8      -1.0
    x_494       link_494    1.0
    x_495       OBJ       40.01
    x_495       flow_9      1.0
    x_495       flow_37     -1.0
    x_495       link_495    1.0
    x_496       OBJ       60.62
    x_496       flow_27     1.0
    x_496       flow_48     -1.0
    x_496       link_496    1.0
    x_497       OBJ       1.02
    x_497       flow_53     1.0
    x_497       flow_49     -1.0
    x_497       link_497    1.0
    x_498       OBJ       0.65
    x_498       flow_23     1.0
    x_498       flow_31     -1.0
    x_498       link_498    1.0
    x_499       OBJ       2.91
    x_499       flow_7      1.0
    x_499       flow_44     -1.0
    x_499       link_499    1.0
    x_500       OBJ       0.92
    x_500       flow_29     1.0
    x_500       flow_36     -1.0
    x_500       link_500    1.0
    x_501       OBJ       2.37
    x_501       flow_29     1.0
    x_501       flow_48     -1.0
    x_501       link_501    1.0
    x_502       OBJ       1.72
    x_502       flow_36     1.0
    x_502       flow_16     -1.0
    x_502       link_502    1.0
    x_503       OBJ       1.4
    x_503       flow_50     1.0
    x_503       flow_34     -1.0
    x_503       link_503    1.0
    x_504       OBJ       59.16
    x_504       flow_40     1.0
    x_504       flow_39     -1.0
    x_504       link_504    1.0
    x_505       OBJ       21.52
    x_505       flow_5      1.0
    x_505       flow_8      -1.0
    x_505       link_505    1.0
    x_506       OBJ       2.1
    x_506       flow_18     1.0
    x_506       flow_23     -1.0
    x_506       link_506    1.0
    x_507       OBJ       69.82
    x_507       flow_10     1.0
    x_507       flow_6      -1.0
    x_507       link_507    1.0
    x_508       OBJ       41.37
    x_508       flow_24     1.0
    x_508       flow_11     -1.0
    x_508       link_508    1.0
    x_509       OBJ       35.21
    x_509       flow_35     1.0
    x_509       flow_23     -1.0
    x_509       link_509    1.0
    x_510       OBJ       69.18
    x_510       flow_36     1.0
    x_510       flow_51     -1.0
    x_510       link_510    1.0
    x_511       OBJ       79.74
    x_511       flow_27     1.0
    x_511       flow_31     -1.0
    x_511       link_511    1.0
    x_512       OBJ       1.61
    x_512       flow_44     1.0
    x_512       flow_14     -1.0
    x_512       link_512    1.0
    x_513       OBJ       0.98
    x_513       flow_2      1.0
    x_513       flow_54     -1.0
    x_513       link_513    1.0
    x_514       OBJ       70.01
    x_514       flow_2      1.0
    x_514       flow_53     -1.0
    x_514       link_514    1.0
    x_515       OBJ       50.88
    x_515       flow_18     1.0
    x_515       flow_4      -1.0
    x_515       link_515    1.0
    x_516       OBJ       2.89
    x_516       flow_4      1.0
    x_516       flow_28     -1.0
    x_516       link_516    1.0
    x_517       OBJ       1.61
    x_517       flow_10     1.0
    x_517       flow_24     -1.0
    x_517       link_517    1.0
    x_518       OBJ       1.86
    x_518       flow_36     1.0
    x_518       flow_12     -1.0
    x_518       link_518    1.0
    x_519       OBJ       78.46
    x_519       flow_34     1.0
    x_519       flow_40     -1.0
    x_519       link_519    1.0
    x_520       OBJ       63.37
    x_520       flow_5      1.0
    x_520       flow_51     -1.0
    x_520       link_520    1.0
    x_521       OBJ       77.17
    x_521       flow_19     1.0
    x_521       flow_36     -1.0
    x_521       link_521    1.0
    x_522       OBJ       51.82
    x_522       flow_8      1.0
    x_522       flow_19     -1.0
    x_522       link_522    1.0
    x_523       OBJ       46.84
    x_523       flow_12     1.0
    x_523       flow_14     -1.0
    x_523       link_523    1.0
    x_524       OBJ       76.59
    x_524       flow_37     1.0
    x_524       flow_23     -1.0
    x_524       link_524    1.0
    x_525       OBJ       0.79
    x_525       flow_36     1.0
    x_525       flow_28     -1.0
    x_525       link_525    1.0
    x_526       OBJ       2.66
    x_526       flow_35     1.0
    x_526       flow_47     -1.0
    x_526       link_526    1.0
    x_527       OBJ       33.62
    x_527       flow_42     1.0
    x_527       flow_16     -1.0
    x_527       link_527    1.0
    x_528       OBJ       1.78
    x_528       flow_36     1.0
    x_528       flow_44     -1.0
    x_528       link_528    1.0
    x_529       OBJ       68.02
    x_529       flow_54     1.0
    x_529       flow_26     -1.0
    x_529       link_529    1.0
    x_530       OBJ       65.41
    x_530       flow_35     1.0
    x_530       flow_32     -1.0
    x_530       link_530    1.0
    x_531       OBJ       2.21
    x_531       flow_32     1.0
    x_531       flow_6      -1.0
    x_531       link_531    1.0
    x_532       OBJ       28.21
    x_532       flow_36     1.0
    x_532       flow_30     -1.0
    x_532       link_532    1.0
    x_533       OBJ       0.6
    x_533       flow_25     1.0
    x_533       flow_15     -1.0
    x_533       link_533    1.0
    x_534       OBJ       0.84
    x_534       flow_29     1.0
    x_534       flow_19     -1.0
    x_534       link_534    1.0
    x_535       OBJ       75.05
    x_535       flow_39     1.0
    x_535       flow_12     -1.0
    x_535       link_535    1.0
    x_536       OBJ       68.25
    x_536       flow_23     1.0
    x_536       flow_47     -1.0
    x_536       link_536    1.0
    x_537       OBJ       1.43
    x_537       flow_52     1.0
    x_537       flow_16     -1.0
    x_537       link_537    1.0
    x_538       OBJ       2.01
    x_538       flow_46     1.0
    x_538       flow_31     -1.0
    x_538       link_538    1.0
    x_539       OBJ       22.05
    x_539       flow_20     1.0
    x_539       flow_51     -1.0
    x_539       link_539    1.0
    x_540       OBJ       1.62
    x_540       flow_16     1.0
    x_540       flow_22     -1.0
    x_540       link_540    1.0
    x_541       OBJ       49.28
    x_541       flow_28     1.0
    x_541       flow_7      -1.0
    x_541       link_541    1.0
    x_542       OBJ       37.4
    x_542       flow_11     1.0
    x_542       flow_9      -1.0
    x_542       link_542    1.0
    x_543       OBJ       61.37
    x_543       flow_37     1.0
    x_543       flow_16     -1.0
    x_543       link_543    1.0
    x_544       OBJ       0.88
    x_544       flow_0      1.0
    x_544       flow_1      -1.0
    x_544       link_544    1.0
    x_545       OBJ       24.48
    x_545       flow_2      1.0
    x_545       flow_51     -1.0
    x_545       link_545    1.0
    x_546       OBJ       1.69
    x_546       flow_43     1.0
    x_546       flow_38     -1.0
    x_546       link_546    1.0
    x_547       OBJ       2.89
    x_547       flow_28     1.0
    x_547       flow_25     -1.0
    x_547       link_547    1.0
    x_548       OBJ       55.35
    x_548       flow_13     1.0
    x_548       flow_19     -1.0
    x_548       link_548    1.0
    x_549       OBJ       39.88
    x_549       flow_52     1.0
    x_549       flow_23     -1.0
    x_549       link_549    1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       173.19
    y_0         link_0      -2.0
    y_1         OBJ       55.62
    y_1         link_1      -5.0
    y_2         OBJ       58.87
    y_2         link_2      -6.0
    y_3         OBJ       1.25
    y_3         link_3      -6.0
    y_4         OBJ       4.43
    y_4         link_4      -4.0
    y_5         OBJ       3.24
    y_5         link_5      -7.0
    y_6         OBJ       2.49
    y_6         link_6      -6.0
    y_7         OBJ       2.99
    y_7         link_7      -6.0
    y_8         OBJ       117.98
    y_8         link_8      -4.0
    y_9         OBJ       62.28
    y_9         link_9      -4.0
    y_10        OBJ       2.15
    y_10        link_10     -2.0
    y_11        OBJ       72.8
    y_11        link_11     -5.0
    y_12        OBJ       3.23
    y_12        link_12     -8.0
    y_13        OBJ       124.5
    y_13        link_13     -8.0
    y_14        OBJ       2.9
    y_14        link_14     -7.0
    y_15        OBJ       3.31
    y_15        link_15     -7.0
    y_16        OBJ       150.3
    y_16        link_16     -2.0
    y_17        OBJ       58.84
    y_17        link_17     -8.0
    y_18        OBJ       4.67
    y_18        link_18     -5.0
    y_19        OBJ       182.51
    y_19        link_19     -8.0
    y_20        OBJ       103.82
    y_20        link_20     -5.0
    y_21        OBJ       148.78
    y_21        link_21     -2.0
    y_22        OBJ       1.02
    y_22        link_22     -5.0
    y_23        OBJ       1.5
    y_23        link_23     -8.0
    y_24        OBJ       2.83
    y_24        link_24     -8.0
    y_25        OBJ       2.6
    y_25        link_25     -2.0
    y_26        OBJ       197.7
    y_26        link_26     -5.0
    y_27        OBJ       50.03
    y_27        link_27     -3.0
    y_28        OBJ       1.28
    y_28        link_28     -3.0
    y_29        OBJ       102.11
    y_29        link_29     -4.0
    y_30        OBJ       196.67
    y_30        link_30     -5.0
    y_31        OBJ       101.4
    y_31        link_31     -4.0
    y_32        OBJ       1.82
    y_32        link_32     -6.0
    y_33        OBJ       4.03
    y_33        link_33     -4.0
    y_34        OBJ       2.47
    y_34        link_34     -3.0
    y_35        OBJ       125.4
    y_35        link_35     -7.0
    y_36        OBJ       4.41
    y_36        link_36     -8.0
    y_37        OBJ       79.99
    y_37        link_37     -5.0
    y_38        OBJ       91.91
    y_38        link_38     -4.0
    y_39        OBJ       4.23
    y_39        link_39     -7.0
    y_40        OBJ       120.51
    y_40        link_40     -4.0
    y_41        OBJ       4.36
    y_41        link_41     -5.0
    y_42        OBJ       3.64
    y_42        link_42     -5.0
    y_43        OBJ       1.71
    y_43        link_43     -8.0
    y_44        OBJ       158.27
    y_44        link_44     -5.0
    y_45        OBJ       1.68
    y_45        link_45     -3.0
    y_46        OBJ       3.62
    y_46        link_46     -6.0
    y_47        OBJ       2.4
    y_47        link_47     -6.0
    y_48        OBJ       158.96
    y_48        link_48     -2.0
    y_49        OBJ       4.49
    y_49        link_49     -8.0
    y_50        OBJ       86.08
    y_50        link_50     -6.0
    y_51        OBJ       1.24
    y_51        link_51     -7.0
    y_52        OBJ       3.07
    y_52        link_52     -8.0
    y_53        OBJ       1.07
    y_53        link_53     -5.0
    y_54        OBJ       1.6
    y_54        link_54     -3.0
    y_55        OBJ       2.3
    y_55        link_55     -6.0
    y_56        OBJ       182.48
    y_56        link_56     -2.0
    y_57        OBJ       126.16
    y_57        link_57     -6.0
    y_58        OBJ       2.3
    y_58        link_58     -6.0
    y_59        OBJ       126.22
    y_59        link_59     -8.0
    y_60        OBJ       4.51
    y_60        link_60     -4.0
    y_61        OBJ       1.49
    y_61        link_61     -5.0
    y_62        OBJ       1.85
    y_62        link_62     -4.0
    y_63        OBJ       3.86
    y_63        link_63     -7.0
    y_64        OBJ       4.81
    y_64        link_64     -5.0
    y_65        OBJ       1.65
    y_65        link_65     -5.0
    y_66        OBJ       97.78
    y_66        link_66     -7.0
    y_67        OBJ       155.47
    y_67        link_67     -5.0
    y_68        OBJ       1.26
    y_68        link_68     -8.0
    y_69        OBJ       185.88
    y_69        link_69     -3.0
    y_70        OBJ       186.71
    y_70        link_70     -8.0
    y_71        OBJ       135.59
    y_71        link_71     -7.0
    y_72        OBJ       77.5
    y_72        link_72     -2.0
    y_73        OBJ       1.33
    y_73        link_73     -8.0
    y_74        OBJ       51.73
    y_74        link_74     -6.0
    y_75        OBJ       3.84
    y_75        link_75     -2.0
    y_76        OBJ       96.8
    y_76        link_76     -4.0
    y_77        OBJ       150.82
    y_77        link_77     -4.0
    y_78        OBJ       52.3
    y_78        link_78     -7.0
    y_79        OBJ       1.98
    y_79        link_79     -5.0
    y_80        OBJ       2.98
    y_80        link_80     -8.0
    y_81        OBJ       84.43
    y_81        link_81     -3.0
    y_82        OBJ       4.96
    y_82        link_82     -2.0
    y_83        OBJ       181.98
    y_83        link_83     -5.0
    y_84        OBJ       180.58
    y_84        link_84     -7.0
    y_85        OBJ       118.92
    y_85        link_85     -3.0
    y_86        OBJ       99.34
    y_86        link_86     -6.0
    y_87        OBJ       82.68
    y_87        link_87     -3.0
    y_88        OBJ       125.41
    y_88        link_88     -3.0
    y_89        OBJ       4.27
    y_89        link_89     -3.0
    y_90        OBJ       95.64
    y_90        link_90     -3.0
    y_91        OBJ       1.62
    y_91        link_91     -7.0
    y_92        OBJ       197.71
    y_92        link_92     -3.0
    y_93        OBJ       4.3
    y_93        link_93     -7.0
    y_94        OBJ       125.83
    y_94        link_94     -6.0
    y_95        OBJ       1.06
    y_95        link_95     -7.0
    y_96        OBJ       3.77
    y_96        link_96     -3.0
    y_97        OBJ       193.93
    y_97        link_97     -5.0
    y_98        OBJ       3.5
    y_98        link_98     -7.0
    y_99        OBJ       60.52
    y_99        link_99     -6.0
    y_100       OBJ       3.95
    y_100       link_100    -4.0
    y_101       OBJ       4.03
    y_101       link_101    -3.0
    y_102       OBJ       2.53
    y_102       link_102    -5.0
    y_103       OBJ       3.57
    y_103       link_103    -2.0
    y_104       OBJ       153.93
    y_104       link_104    -6.0
    y_105       OBJ       90.32
    y_105       link_105    -7.0
    y_106       OBJ       156.33
    y_106       link_106    -4.0
    y_107       OBJ       79.89
    y_107       link_107    -2.0
    y_108       OBJ       125.99
    y_108       link_108    -5.0
    y_109       OBJ       81.61
    y_109       link_109    -6.0
    y_110       OBJ       2.44
    y_110       link_110    -6.0
    y_111       OBJ       3.81
    y_111       link_111    -3.0
    y_112       OBJ       152.24
    y_112       link_112    -5.0
    y_113       OBJ       97.41
    y_113       link_113    -8.0
    y_114       OBJ       109.74
    y_114       link_114    -3.0
    y_115       OBJ       2.49
    y_115       link_115    -5.0
    y_116       OBJ       163.35
    y_116       link_116    -8.0
    y_117       OBJ       92.84
    y_117       link_117    -3.0
    y_118       OBJ       165.98
    y_118       link_118    -8.0
    y_119       OBJ       4.65
    y_119       link_119    -6.0
    y_120       OBJ       3.93
    y_120       link_120    -5.0
    y_121       OBJ       122.84
    y_121       link_121    -6.0
    y_122       OBJ       94.67
    y_122       link_122    -7.0
    y_123       OBJ       109.16
    y_123       link_123    -3.0
    y_124       OBJ       171.77
    y_124       link_124    -6.0
    y_125       OBJ       2.8
    y_125       link_125    -3.0
    y_126       OBJ       97.89
    y_126       link_126    -4.0
    y_127       OBJ       4.0
    y_127       link_127    -5.0
    y_128       OBJ       2.08
    y_128       link_128    -8.0
    y_129       OBJ       68.88
    y_129       link_129    -6.0
    y_130       OBJ       1.37
    y_130       link_130    -3.0
    y_131       OBJ       2.25
    y_131       link_131    -8.0
    y_132       OBJ       184.35
    y_132       link_132    -5.0
    y_133       OBJ       189.02
    y_133       link_133    -8.0
    y_134       OBJ       167.47
    y_134       link_134    -3.0
    y_135       OBJ       155.15
    y_135       link_135    -8.0
    y_136       OBJ       50.2
    y_136       link_136    -3.0
    y_137       OBJ       2.22
    y_137       link_137    -3.0
    y_138       OBJ       4.06
    y_138       link_138    -2.0
    y_139       OBJ       2.55
    y_139       link_139    -3.0
    y_140       OBJ       2.27
    y_140       link_140    -8.0
    y_141       OBJ       1.12
    y_141       link_141    -5.0
    y_142       OBJ       124.75
    y_142       link_142    -7.0
    y_143       OBJ       113.65
    y_143       link_143    -4.0
    y_144       OBJ       113.08
    y_144       link_144    -7.0
    y_145       OBJ       176.77
    y_145       link_145    -2.0
    y_146       OBJ       4.28
    y_146       link_146    -3.0
    y_147       OBJ       66.35
    y_147       link_147    -6.0
    y_148       OBJ       112.55
    y_148       link_148    -7.0
    y_149       OBJ       81.94
    y_149       link_149    -6.0
    y_150       OBJ       109.0
    y_150       link_150    -7.0
    y_151       OBJ       74.85
    y_151       link_151    -3.0
    y_152       OBJ       1.13
    y_152       link_152    -7.0
    y_153       OBJ       2.77
    y_153       link_153    -2.0
    y_154       OBJ       193.33
    y_154       link_154    -2.0
    y_155       OBJ       173.24
    y_155       link_155    -8.0
    y_156       OBJ       79.36
    y_156       link_156    -6.0
    y_157       OBJ       121.18
    y_157       link_157    -7.0
    y_158       OBJ       1.16
    y_158       link_158    -2.0
    y_159       OBJ       184.78
    y_159       link_159    -4.0
    y_160       OBJ       56.54
    y_160       link_160    -7.0
    y_161       OBJ       50.57
    y_161       link_161    -8.0
    y_162       OBJ       1.1
    y_162       link_162    -3.0
    y_163       OBJ       4.11
    y_163       link_163    -8.0
    y_164       OBJ       2.99
    y_164       link_164    -2.0
    y_165       OBJ       72.7
    y_165       link_165    -3.0
    y_166       OBJ       3.05
    y_166       link_166    -5.0
    y_167       OBJ       55.08
    y_167       link_167    -6.0
    y_168       OBJ       65.78
    y_168       link_168    -2.0
    y_169       OBJ       124.77
    y_169       link_169    -7.0
    y_170       OBJ       143.05
    y_170       link_170    -7.0
    y_171       OBJ       4.04
    y_171       link_171    -8.0
    y_172       OBJ       105.95
    y_172       link_172    -7.0
    y_173       OBJ       85.33
    y_173       link_173    -4.0
    y_174       OBJ       198.87
    y_174       link_174    -6.0
    y_175       OBJ       2.86
    y_175       link_175    -2.0
    y_176       OBJ       176.08
    y_176       link_176    -4.0
    y_177       OBJ       140.07
    y_177       link_177    -8.0
    y_178       OBJ       3.41
    y_178       link_178    -8.0
    y_179       OBJ       3.38
    y_179       link_179    -6.0
    y_180       OBJ       56.62
    y_180       link_180    -4.0
    y_181       OBJ       4.26
    y_181       link_181    -8.0
    y_182       OBJ       2.25
    y_182       link_182    -3.0
    y_183       OBJ       111.23
    y_183       link_183    -8.0
    y_184       OBJ       1.36
    y_184       link_184    -3.0
    y_185       OBJ       150.17
    y_185       link_185    -5.0
    y_186       OBJ       2.66
    y_186       link_186    -2.0
    y_187       OBJ       159.2
    y_187       link_187    -3.0
    y_188       OBJ       4.28
    y_188       link_188    -5.0
    y_189       OBJ       52.23
    y_189       link_189    -6.0
    y_190       OBJ       3.29
    y_190       link_190    -4.0
    y_191       OBJ       74.27
    y_191       link_191    -3.0
    y_192       OBJ       168.82
    y_192       link_192    -8.0
    y_193       OBJ       196.33
    y_193       link_193    -5.0
    y_194       OBJ       1.35
    y_194       link_194    -7.0
    y_195       OBJ       4.14
    y_195       link_195    -3.0
    y_196       OBJ       2.89
    y_196       link_196    -6.0
    y_197       OBJ       107.54
    y_197       link_197    -2.0
    y_198       OBJ       1.77
    y_198       link_198    -6.0
    y_199       OBJ       2.3
    y_199       link_199    -5.0
    y_200       OBJ       2.22
    y_200       link_200    -5.0
    y_201       OBJ       105.12
    y_201       link_201    -6.0
    y_202       OBJ       1.94
    y_202       link_202    -8.0
    y_203       OBJ       4.24
    y_203       link_203    -5.0
    y_204       OBJ       63.76
    y_204       link_204    -5.0
    y_205       OBJ       188.32
    y_205       link_205    -4.0
    y_206       OBJ       3.02
    y_206       link_206    -5.0
    y_207       OBJ       199.42
    y_207       link_207    -7.0
    y_208       OBJ       182.85
    y_208       link_208    -4.0
    y_209       OBJ       189.59
    y_209       link_209    -2.0
    y_210       OBJ       2.3
    y_210       link_210    -6.0
    y_211       OBJ       194.65
    y_211       link_211    -5.0
    y_212       OBJ       97.86
    y_212       link_212    -2.0
    y_213       OBJ       91.73
    y_213       link_213    -4.0
    y_214       OBJ       4.07
    y_214       link_214    -2.0
    y_215       OBJ       133.28
    y_215       link_215    -6.0
    y_216       OBJ       178.49
    y_216       link_216    -7.0
    y_217       OBJ       136.6
    y_217       link_217    -4.0
    y_218       OBJ       142.31
    y_218       link_218    -2.0
    y_219       OBJ       4.86
    y_219       link_219    -8.0
    y_220       OBJ       3.99
    y_220       link_220    -3.0
    y_221       OBJ       3.05
    y_221       link_221    -2.0
    y_222       OBJ       53.34
    y_222       link_222    -2.0
    y_223       OBJ       130.12
    y_223       link_223    -5.0
    y_224       OBJ       3.5
    y_224       link_224    -5.0
    y_225       OBJ       156.12
    y_225       link_225    -5.0
    y_226       OBJ       2.61
    y_226       link_226    -4.0
    y_227       OBJ       2.4
    y_227       link_227    -7.0
    y_228       OBJ       2.97
    y_228       link_228    -3.0
    y_229       OBJ       77.85
    y_229       link_229    -3.0
    y_230       OBJ       148.52
    y_230       link_230    -3.0
    y_231       OBJ       3.57
    y_231       link_231    -8.0
    y_232       OBJ       3.5
    y_232       link_232    -7.0
    y_233       OBJ       4.38
    y_233       link_233    -7.0
    y_234       OBJ       1.9
    y_234       link_234    -2.0
    y_235       OBJ       4.57
    y_235       link_235    -7.0
    y_236       OBJ       3.22
    y_236       link_236    -5.0
    y_237       OBJ       2.18
    y_237       link_237    -3.0
    y_238       OBJ       85.42
    y_238       link_238    -7.0
    y_239       OBJ       4.52
    y_239       link_239    -4.0
    y_240       OBJ       188.25
    y_240       link_240    -7.0
    y_241       OBJ       154.64
    y_241       link_241    -8.0
    y_242       OBJ       4.54
    y_242       link_242    -8.0
    y_243       OBJ       4.64
    y_243       link_243    -3.0
    y_244       OBJ       74.27
    y_244       link_244    -3.0
    y_245       OBJ       146.53
    y_245       link_245    -2.0
    y_246       OBJ       3.36
    y_246       link_246    -4.0
    y_247       OBJ       3.66
    y_247       link_247    -8.0
    y_248       OBJ       1.82
    y_248       link_248    -2.0
    y_249       OBJ       4.01
    y_249       link_249    -7.0
    y_250       OBJ       163.6
    y_250       link_250    -3.0
    y_251       OBJ       102.64
    y_251       link_251    -4.0
    y_252       OBJ       4.08
    y_252       link_252    -6.0
    y_253       OBJ       1.12
    y_253       link_253    -5.0
    y_254       OBJ       57.22
    y_254       link_254    -6.0
    y_255       OBJ       4.28
    y_255       link_255    -3.0
    y_256       OBJ       4.0
    y_256       link_256    -2.0
    y_257       OBJ       169.52
    y_257       link_257    -3.0
    y_258       OBJ       89.09
    y_258       link_258    -3.0
    y_259       OBJ       190.81
    y_259       link_259    -8.0
    y_260       OBJ       4.15
    y_260       link_260    -7.0
    y_261       OBJ       183.78
    y_261       link_261    -7.0
    y_262       OBJ       1.82
    y_262       link_262    -4.0
    y_263       OBJ       4.54
    y_263       link_263    -3.0
    y_264       OBJ       4.01
    y_264       link_264    -7.0
    y_265       OBJ       4.47
    y_265       link_265    -5.0
    y_266       OBJ       2.76
    y_266       link_266    -8.0
    y_267       OBJ       146.41
    y_267       link_267    -7.0
    y_268       OBJ       176.55
    y_268       link_268    -3.0
    y_269       OBJ       3.41
    y_269       link_269    -4.0
    y_270       OBJ       196.27
    y_270       link_270    -7.0
    y_271       OBJ       2.54
    y_271       link_271    -3.0
    y_272       OBJ       1.78
    y_272       link_272    -7.0
    y_273       OBJ       55.09
    y_273       link_273    -5.0
    y_274       OBJ       197.13
    y_274       link_274    -4.0
    y_275       OBJ       110.71
    y_275       link_275    -7.0
    y_276       OBJ       162.37
    y_276       link_276    -5.0
    y_277       OBJ       4.51
    y_277       link_277    -7.0
    y_278       OBJ       3.57
    y_278       link_278    -5.0
    y_279       OBJ       184.21
    y_279       link_279    -3.0
    y_280       OBJ       2.0
    y_280       link_280    -5.0
    y_281       OBJ       127.74
    y_281       link_281    -7.0
    y_282       OBJ       186.23
    y_282       link_282    -2.0
    y_283       OBJ       4.13
    y_283       link_283    -3.0
    y_284       OBJ       131.16
    y_284       link_284    -7.0
    y_285       OBJ       2.37
    y_285       link_285    -7.0
    y_286       OBJ       3.06
    y_286       link_286    -2.0
    y_287       OBJ       91.15
    y_287       link_287    -5.0
    y_288       OBJ       144.28
    y_288       link_288    -7.0
    y_289       OBJ       161.22
    y_289       link_289    -6.0
    y_290       OBJ       1.66
    y_290       link_290    -8.0
    y_291       OBJ       3.57
    y_291       link_291    -7.0
    y_292       OBJ       3.56
    y_292       link_292    -8.0
    y_293       OBJ       163.98
    y_293       link_293    -7.0
    y_294       OBJ       4.4
    y_294       link_294    -4.0
    y_295       OBJ       3.72
    y_295       link_295    -5.0
    y_296       OBJ       1.98
    y_296       link_296    -4.0
    y_297       OBJ       62.81
    y_297       link_297    -4.0
    y_298       OBJ       4.31
    y_298       link_298    -4.0
    y_299       OBJ       3.33
    y_299       link_299    -7.0
    y_300       OBJ       2.0
    y_300       link_300    -2.0
    y_301       OBJ       2.81
    y_301       link_301    -8.0
    y_302       OBJ       1.67
    y_302       link_302    -7.0
    y_303       OBJ       132.28
    y_303       link_303    -7.0
    y_304       OBJ       129.62
    y_304       link_304    -7.0
    y_305       OBJ       1.94
    y_305       link_305    -3.0
    y_306       OBJ       4.62
    y_306       link_306    -7.0
    y_307       OBJ       179.43
    y_307       link_307    -2.0
    y_308       OBJ       124.64
    y_308       link_308    -4.0
    y_309       OBJ       194.09
    y_309       link_309    -2.0
    y_310       OBJ       53.08
    y_310       link_310    -2.0
    y_311       OBJ       4.93
    y_311       link_311    -6.0
    y_312       OBJ       143.79
    y_312       link_312    -4.0
    y_313       OBJ       165.59
    y_313       link_313    -3.0
    y_314       OBJ       57.91
    y_314       link_314    -4.0
    y_315       OBJ       3.01
    y_315       link_315    -4.0
    y_316       OBJ       4.17
    y_316       link_316    -4.0
    y_317       OBJ       4.89
    y_317       link_317    -2.0
    y_318       OBJ       110.9
    y_318       link_318    -6.0
    y_319       OBJ       78.49
    y_319       link_319    -5.0
    y_320       OBJ       4.64
    y_320       link_320    -6.0
    y_321       OBJ       153.37
    y_321       link_321    -7.0
    y_322       OBJ       143.79
    y_322       link_322    -3.0
    y_323       OBJ       189.58
    y_323       link_323    -2.0
    y_324       OBJ       156.52
    y_324       link_324    -8.0
    y_325       OBJ       114.6
    y_325       link_325    -7.0
    y_326       OBJ       173.71
    y_326       link_326    -8.0
    y_327       OBJ       2.79
    y_327       link_327    -2.0
    y_328       OBJ       3.64
    y_328       link_328    -3.0
    y_329       OBJ       146.68
    y_329       link_329    -3.0
    y_330       OBJ       152.56
    y_330       link_330    -2.0
    y_331       OBJ       120.85
    y_331       link_331    -4.0
    y_332       OBJ       78.11
    y_332       link_332    -2.0
    y_333       OBJ       1.58
    y_333       link_333    -8.0
    y_334       OBJ       2.84
    y_334       link_334    -4.0
    y_335       OBJ       153.0
    y_335       link_335    -6.0
    y_336       OBJ       74.9
    y_336       link_336    -8.0
    y_337       OBJ       4.8
    y_337       link_337    -7.0
    y_338       OBJ       4.19
    y_338       link_338    -4.0
    y_339       OBJ       167.94
    y_339       link_339    -4.0
    y_340       OBJ       1.24
    y_340       link_340    -7.0
    y_341       OBJ       3.42
    y_341       link_341    -2.0
    y_342       OBJ       2.71
    y_342       link_342    -3.0
    y_343       OBJ       2.07
    y_343       link_343    -3.0
    y_344       OBJ       2.15
    y_344       link_344    -3.0
    y_345       OBJ       169.59
    y_345       link_345    -6.0
    y_346       OBJ       1.34
    y_346       link_346    -6.0
    y_347       OBJ       158.33
    y_347       link_347    -3.0
    y_348       OBJ       156.25
    y_348       link_348    -4.0
    y_349       OBJ       131.08
    y_349       link_349    -6.0
    y_350       OBJ       3.32
    y_350       link_350    -4.0
    y_351       OBJ       80.28
    y_351       link_351    -3.0
    y_352       OBJ       104.42
    y_352       link_352    -6.0
    y_353       OBJ       1.99
    y_353       link_353    -5.0
    y_354       OBJ       62.26
    y_354       link_354    -4.0
    y_355       OBJ       53.09
    y_355       link_355    -2.0
    y_356       OBJ       89.24
    y_356       link_356    -8.0
    y_357       OBJ       138.97
    y_357       link_357    -6.0
    y_358       OBJ       4.98
    y_358       link_358    -5.0
    y_359       OBJ       2.83
    y_359       link_359    -8.0
    y_360       OBJ       3.83
    y_360       link_360    -2.0
    y_361       OBJ       4.83
    y_361       link_361    -7.0
    y_362       OBJ       1.94
    y_362       link_362    -7.0
    y_363       OBJ       102.8
    y_363       link_363    -6.0
    y_364       OBJ       3.05
    y_364       link_364    -7.0
    y_365       OBJ       1.58
    y_365       link_365    -8.0
    y_366       OBJ       3.37
    y_366       link_366    -8.0
    y_367       OBJ       108.51
    y_367       link_367    -4.0
    y_368       OBJ       71.47
    y_368       link_368    -7.0
    y_369       OBJ       1.14
    y_369       link_369    -8.0
    y_370       OBJ       2.79
    y_370       link_370    -2.0
    y_371       OBJ       195.85
    y_371       link_371    -4.0
    y_372       OBJ       71.42
    y_372       link_372    -3.0
    y_373       OBJ       183.4
    y_373       link_373    -5.0
    y_374       OBJ       53.81
    y_374       link_374    -6.0
    y_375       OBJ       97.71
    y_375       link_375    -5.0
    y_376       OBJ       4.58
    y_376       link_376    -7.0
    y_377       OBJ       88.67
    y_377       link_377    -3.0
    y_378       OBJ       4.7
    y_378       link_378    -2.0
    y_379       OBJ       174.85
    y_379       link_379    -4.0
    y_380       OBJ       1.56
    y_380       link_380    -2.0
    y_381       OBJ       2.44
    y_381       link_381    -2.0
    y_382       OBJ       176.51
    y_382       link_382    -6.0
    y_383       OBJ       1.32
    y_383       link_383    -2.0
    y_384       OBJ       80.9
    y_384       link_384    -6.0
    y_385       OBJ       2.23
    y_385       link_385    -2.0
    y_386       OBJ       3.89
    y_386       link_386    -2.0
    y_387       OBJ       145.88
    y_387       link_387    -5.0
    y_388       OBJ       69.99
    y_388       link_388    -7.0
    y_389       OBJ       105.07
    y_389       link_389    -3.0
    y_390       OBJ       2.42
    y_390       link_390    -5.0
    y_391       OBJ       172.48
    y_391       link_391    -8.0
    y_392       OBJ       1.43
    y_392       link_392    -7.0
    y_393       OBJ       3.15
    y_393       link_393    -2.0
    y_394       OBJ       172.57
    y_394       link_394    -2.0
    y_395       OBJ       2.05
    y_395       link_395    -8.0
    y_396       OBJ       3.81
    y_396       link_396    -2.0
    y_397       OBJ       1.49
    y_397       link_397    -5.0
    y_398       OBJ       1.49
    y_398       link_398    -3.0
    y_399       OBJ       150.32
    y_399       link_399    -5.0
    y_400       OBJ       190.64
    y_400       link_400    -5.0
    y_401       OBJ       1.14
    y_401       link_401    -2.0
    y_402       OBJ       100.26
    y_402       link_402    -5.0
    y_403       OBJ       4.26
    y_403       link_403    -8.0
    y_404       OBJ       152.02
    y_404       link_404    -4.0
    y_405       OBJ       1.44
    y_405       link_405    -3.0
    y_406       OBJ       53.12
    y_406       link_406    -3.0
    y_407       OBJ       3.53
    y_407       link_407    -8.0
    y_408       OBJ       91.01
    y_408       link_408    -6.0
    y_409       OBJ       3.08
    y_409       link_409    -5.0
    y_410       OBJ       147.13
    y_410       link_410    -2.0
    y_411       OBJ       189.79
    y_411       link_411    -5.0
    y_412       OBJ       2.1
    y_412       link_412    -7.0
    y_413       OBJ       3.44
    y_413       link_413    -6.0
    y_414       OBJ       105.02
    y_414       link_414    -6.0
    y_415       OBJ       54.64
    y_415       link_415    -4.0
    y_416       OBJ       3.34
    y_416       link_416    -2.0
    y_417       OBJ       3.23
    y_417       link_417    -5.0
    y_418       OBJ       1.23
    y_418       link_418    -2.0
    y_419       OBJ       116.0
    y_419       link_419    -2.0
    y_420       OBJ       4.05
    y_420       link_420    -6.0
    y_421       OBJ       2.35
    y_421       link_421    -4.0
    y_422       OBJ       91.51
    y_422       link_422    -8.0
    y_423       OBJ       4.04
    y_423       link_423    -5.0
    y_424       OBJ       3.81
    y_424       link_424    -5.0
    y_425       OBJ       2.59
    y_425       link_425    -6.0
    y_426       OBJ       2.81
    y_426       link_426    -5.0
    y_427       OBJ       139.31
    y_427       link_427    -7.0
    y_428       OBJ       3.0
    y_428       link_428    -5.0
    y_429       OBJ       84.79
    y_429       link_429    -8.0
    y_430       OBJ       1.97
    y_430       link_430    -4.0
    y_431       OBJ       1.1
    y_431       link_431    -4.0
    y_432       OBJ       96.86
    y_432       link_432    -6.0
    y_433       OBJ       2.72
    y_433       link_433    -5.0
    y_434       OBJ       4.79
    y_434       link_434    -7.0
    y_435       OBJ       125.14
    y_435       link_435    -7.0
    y_436       OBJ       113.18
    y_436       link_436    -5.0
    y_437       OBJ       2.37
    y_437       link_437    -6.0
    y_438       OBJ       105.0
    y_438       link_438    -2.0
    y_439       OBJ       4.58
    y_439       link_439    -7.0
    y_440       OBJ       4.89
    y_440       link_440    -7.0
    y_441       OBJ       125.73
    y_441       link_441    -3.0
    y_442       OBJ       65.99
    y_442       link_442    -6.0
    y_443       OBJ       1.01
    y_443       link_443    -7.0
    y_444       OBJ       176.32
    y_444       link_444    -6.0
    y_445       OBJ       165.34
    y_445       link_445    -6.0
    y_446       OBJ       1.57
    y_446       link_446    -3.0
    y_447       OBJ       163.92
    y_447       link_447    -2.0
    y_448       OBJ       2.87
    y_448       link_448    -5.0
    y_449       OBJ       98.42
    y_449       link_449    -7.0
    y_450       OBJ       144.3
    y_450       link_450    -8.0
    y_451       OBJ       107.85
    y_451       link_451    -2.0
    y_452       OBJ       2.76
    y_452       link_452    -6.0
    y_453       OBJ       76.03
    y_453       link_453    -2.0
    y_454       OBJ       194.0
    y_454       link_454    -5.0
    y_455       OBJ       3.34
    y_455       link_455    -5.0
    y_456       OBJ       4.17
    y_456       link_456    -3.0
    y_457       OBJ       51.14
    y_457       link_457    -4.0
    y_458       OBJ       180.72
    y_458       link_458    -4.0
    y_459       OBJ       173.87
    y_459       link_459    -4.0
    y_460       OBJ       101.67
    y_460       link_460    -5.0
    y_461       OBJ       1.62
    y_461       link_461    -7.0
    y_462       OBJ       168.12
    y_462       link_462    -6.0
    y_463       OBJ       1.64
    y_463       link_463    -4.0
    y_464       OBJ       137.11
    y_464       link_464    -4.0
    y_465       OBJ       4.77
    y_465       link_465    -4.0
    y_466       OBJ       1.99
    y_466       link_466    -6.0
    y_467       OBJ       151.68
    y_467       link_467    -2.0
    y_468       OBJ       107.72
    y_468       link_468    -7.0
    y_469       OBJ       156.61
    y_469       link_469    -7.0
    y_470       OBJ       3.65
    y_470       link_470    -2.0
    y_471       OBJ       4.03
    y_471       link_471    -3.0
    y_472       OBJ       68.92
    y_472       link_472    -7.0
    y_473       OBJ       119.67
    y_473       link_473    -7.0
    y_474       OBJ       2.47
    y_474       link_474    -8.0
    y_475       OBJ       148.86
    y_475       link_475    -7.0
    y_476       OBJ       4.62
    y_476       link_476    -2.0
    y_477       OBJ       160.11
    y_477       link_477    -7.0
    y_478       OBJ       114.61
    y_478       link_478    -8.0
    y_479       OBJ       96.64
    y_479       link_479    -7.0
    y_480       OBJ       3.87
    y_480       link_480    -4.0
    y_481       OBJ       1.0
    y_481       link_481    -8.0
    y_482       OBJ       4.5
    y_482       link_482    -6.0
    y_483       OBJ       66.68
    y_483       link_483    -8.0
    y_484       OBJ       4.65
    y_484       link_484    -5.0
    y_485       OBJ       174.31
    y_485       link_485    -4.0
    y_486       OBJ       116.38
    y_486       link_486    -4.0
    y_487       OBJ       3.51
    y_487       link_487    -5.0
    y_488       OBJ       3.69
    y_488       link_488    -8.0
    y_489       OBJ       192.84
    y_489       link_489    -8.0
    y_490       OBJ       195.41
    y_490       link_490    -7.0
    y_491       OBJ       75.21
    y_491       link_491    -4.0
    y_492       OBJ       70.48
    y_492       link_492    -7.0
    y_493       OBJ       50.88
    y_493       link_493    -7.0
    y_494       OBJ       2.2
    y_494       link_494    -7.0
    y_495       OBJ       4.26
    y_495       link_495    -6.0
    y_496       OBJ       1.62
    y_496       link_496    -5.0
    y_497       OBJ       153.52
    y_497       link_497    -2.0
    y_498       OBJ       92.13
    y_498       link_498    -3.0
    y_499       OBJ       74.2
    y_499       link_499    -5.0
    y_500       OBJ       60.77
    y_500       link_500    -2.0
    y_501       OBJ       99.76
    y_501       link_501    -7.0
    y_502       OBJ       115.14
    y_502       link_502    -3.0
    y_503       OBJ       63.65
    y_503       link_503    -4.0
    y_504       OBJ       2.01
    y_504       link_504    -3.0
    y_505       OBJ       2.58
    y_505       link_505    -3.0
    y_506       OBJ       176.86
    y_506       link_506    -7.0
    y_507       OBJ       3.97
    y_507       link_507    -4.0
    y_508       OBJ       1.92
    y_508       link_508    -3.0
    y_509       OBJ       1.23
    y_509       link_509    -2.0
    y_510       OBJ       3.82
    y_510       link_510    -2.0
    y_511       OBJ       3.41
    y_511       link_511    -7.0
    y_512       OBJ       195.47
    y_512       link_512    -2.0
    y_513       OBJ       158.44
    y_513       link_513    -2.0
    y_514       OBJ       3.05
    y_514       link_514    -3.0
    y_515       OBJ       2.68
    y_515       link_515    -4.0
    y_516       OBJ       76.44
    y_516       link_516    -7.0
    y_517       OBJ       134.51
    y_517       link_517    -4.0
    y_518       OBJ       127.52
    y_518       link_518    -5.0
    y_519       OBJ       4.85
    y_519       link_519    -6.0
    y_520       OBJ       2.33
    y_520       link_520    -7.0
    y_521       OBJ       2.92
    y_521       link_521    -7.0
    y_522       OBJ       3.53
    y_522       link_522    -8.0
    y_523       OBJ       1.34
    y_523       link_523    -7.0
    y_524       OBJ       2.44
    y_524       link_524    -3.0
    y_525       OBJ       77.08
    y_525       link_525    -3.0
    y_526       OBJ       88.02
    y_526       link_526    -2.0
    y_527       OBJ       2.83
    y_527       link_527    -6.0
    y_528       OBJ       138.27
    y_528       link_528    -2.0
    y_529       OBJ       1.54
    y_529       link_529    -6.0
    y_530       OBJ       1.46
    y_530       link_530    -7.0
    y_531       OBJ       131.64
    y_531       link_531    -3.0
    y_532       OBJ       4.1
    y_532       link_532    -2.0
    y_533       OBJ       155.29
    y_533       link_533    -3.0
    y_534       OBJ       186.28
    y_534       link_534    -2.0
    y_535       OBJ       4.48
    y_535       link_535    -3.0
    y_536       OBJ       3.94
    y_536       link_536    -2.0
    y_537       OBJ       160.59
    y_537       link_537    -4.0
    y_538       OBJ       64.95
    y_538       link_538    -6.0
    y_539       OBJ       4.64
    y_539       link_539    -3.0
    y_540       OBJ       175.72
    y_540       link_540    -6.0
    y_541       OBJ       1.3
    y_541       link_541    -4.0
    y_542       OBJ       3.75
    y_542       link_542    -5.0
    y_543       OBJ       4.23
    y_543       link_543    -5.0
    y_544       OBJ       125.27
    y_544       link_544    -8.0
    y_545       OBJ       3.48
    y_545       link_545    -7.0
    y_546       OBJ       73.74
    y_546       link_546    -8.0
    y_547       OBJ       127.55
    y_547       link_547    -4.0
    y_548       OBJ       1.17
    y_548       link_548    -3.0
    y_549       OBJ       2.87
    y_549       link_549    -4.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_12     -31
    RHS       flow_23     41
    RHS       flow_25     -31
    RHS       flow_31     -31
    RHS       flow_34     42
    RHS       flow_50     -31
    RHS       flow_53     41
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
 BV BOUND     y_84
 BV BOUND     y_85
 BV BOUND     y_86
 BV BOUND     y_87
 BV BOUND     y_88
 BV BOUND     y_89
 BV BOUND     y_90
 BV BOUND     y_91
 BV BOUND     y_92
 BV BOUND     y_93
 BV BOUND     y_94
 BV BOUND     y_95
 BV BOUND     y_96
 BV BOUND     y_97
 BV BOUND     y_98
 BV BOUND     y_99
 BV BOUND     y_100
 BV BOUND     y_101
 BV BOUND     y_102
 BV BOUND     y_103
 BV BOUND     y_104
 BV BOUND     y_105
 BV BOUND     y_106
 BV BOUND     y_107
 BV BOUND     y_108
 BV BOUND     y_109
 BV BOUND     y_110
 BV BOUND     y_111
 BV BOUND     y_112
 BV BOUND     y_113
 BV BOUND     y_114
 BV BOUND     y_115
 BV BOUND     y_116
 BV BOUND     y_117
 BV BOUND     y_118
 BV BOUND     y_119
 BV BOUND     y_120
 BV BOUND     y_121
 BV BOUND     y_122
 BV BOUND     y_123
 BV BOUND     y_124
 BV BOUND     y_125
 BV BOUND     y_126
 BV BOUND     y_127
 BV BOUND     y_128
 BV BOUND     y_129
 BV BOUND     y_130
 BV BOUND     y_131
 BV BOUND     y_132
 BV BOUND     y_133
 BV BOUND     y_134
 BV BOUND     y_135
 BV BOUND     y_136
 BV BOUND     y_137
 BV BOUND     y_138
 BV BOUND     y_139
 BV BOUND     y_140
 BV BOUND     y_141
 BV BOUND     y_142
 BV BOUND     y_143
 BV BOUND     y_144
 BV BOUND     y_145
 BV BOUND     y_146
 BV BOUND     y_147
 BV BOUND     y_148
 BV BOUND     y_149
 BV BOUND     y_150
 BV BOUND     y_151
 BV BOUND     y_152
 BV BOUND     y_153
 BV BOUND     y_154
 BV BOUND     y_155
 BV BOUND     y_156
 BV BOUND     y_157
 BV BOUND     y_158
 BV BOUND     y_159
 BV BOUND     y_160
 BV BOUND     y_161
 BV BOUND     y_162
 BV BOUND     y_163
 BV BOUND     y_164
 BV BOUND     y_165
 BV BOUND     y_166
 BV BOUND     y_167
 BV BOUND     y_168
 BV BOUND     y_169
 BV BOUND     y_170
 BV BOUND     y_171
 BV BOUND     y_172
 BV BOUND     y_173
 BV BOUND     y_174
 BV BOUND     y_175
 BV BOUND     y_176
 BV BOUND     y_177
 BV BOUND     y_178
 BV BOUND     y_179
 BV BOUND     y_180
 BV BOUND     y_181
 BV BOUND     y_182
 BV BOUND     y_183
 BV BOUND     y_184
 BV BOUND     y_185
 BV BOUND     y_186
 BV BOUND     y_187
 BV BOUND     y_188
 BV BOUND     y_189
 BV BOUND     y_190
 BV BOUND     y_191
 BV BOUND     y_192
 BV BOUND     y_193
 BV BOUND     y_194
 BV BOUND     y_195
 BV BOUND     y_196
 BV BOUND     y_197
 BV BOUND     y_198
 BV BOUND     y_199
 BV BOUND     y_200
 BV BOUND     y_201
 BV BOUND     y_202
 BV BOUND     y_203
 BV BOUND     y_204
 BV BOUND     y_205
 BV BOUND     y_206
 BV BOUND     y_207
 BV BOUND     y_208
 BV BOUND     y_209
 BV BOUND     y_210
 BV BOUND     y_211
 BV BOUND     y_212
 BV BOUND     y_213
 BV BOUND     y_214
 BV BOUND     y_215
 BV BOUND     y_216
 BV BOUND     y_217
 BV BOUND     y_218
 BV BOUND     y_219
 BV BOUND     y_220
 BV BOUND     y_221
 BV BOUND     y_222
 BV BOUND     y_223
 BV BOUND     y_224
 BV BOUND     y_225
 BV BOUND     y_226
 BV BOUND     y_227
 BV BOUND     y_228
 BV BOUND     y_229
 BV BOUND     y_230
 BV BOUND     y_231
 BV BOUND     y_232
 BV BOUND     y_233
 BV BOUND     y_234
 BV BOUND     y_235
 BV BOUND     y_236
 BV BOUND     y_237
 BV BOUND     y_238
 BV BOUND     y_239
 BV BOUND     y_240
 BV BOUND     y_241
 BV BOUND     y_242
 BV BOUND     y_243
 BV BOUND     y_244
 BV BOUND     y_245
 BV BOUND     y_246
 BV BOUND     y_247
 BV BOUND     y_248
 BV BOUND     y_249
 BV BOUND     y_250
 BV BOUND     y_251
 BV BOUND     y_252
 BV BOUND     y_253
 BV BOUND     y_254
 BV BOUND     y_255
 BV BOUND     y_256
 BV BOUND     y_257
 BV BOUND     y_258
 BV BOUND     y_259
 BV BOUND     y_260
 BV BOUND     y_261
 BV BOUND     y_262
 BV BOUND     y_263
 BV BOUND     y_264
 BV BOUND     y_265
 BV BOUND     y_266
 BV BOUND     y_267
 BV BOUND     y_268
 BV BOUND     y_269
 BV BOUND     y_270
 BV BOUND     y_271
 BV BOUND     y_272
 BV BOUND     y_273
 BV BOUND     y_274
 BV BOUND     y_275
 BV BOUND     y_276
 BV BOUND     y_277
 BV BOUND     y_278
 BV BOUND     y_279
 BV BOUND     y_280
 BV BOUND     y_281
 BV BOUND     y_282
 BV BOUND     y_283
 BV BOUND     y_284
 BV BOUND     y_285
 BV BOUND     y_286
 BV BOUND     y_287
 BV BOUND     y_288
 BV BOUND     y_289
 BV BOUND     y_290
 BV BOUND     y_291
 BV BOUND     y_292
 BV BOUND     y_293
 BV BOUND     y_294
 BV BOUND     y_295
 BV BOUND     y_296
 BV BOUND     y_297
 BV BOUND     y_298
 BV BOUND     y_299
 BV BOUND     y_300
 BV BOUND     y_301
 BV BOUND     y_302
 BV BOUND     y_303
 BV BOUND     y_304
 BV BOUND     y_305
 BV BOUND     y_306
 BV BOUND     y_307
 BV BOUND     y_308
 BV BOUND     y_309
 BV BOUND     y_310
 BV BOUND     y_311
 BV BOUND     y_312
 BV BOUND     y_313
 BV BOUND     y_314
 BV BOUND     y_315
 BV BOUND     y_316
 BV BOUND     y_317
 BV BOUND     y_318
 BV BOUND     y_319
 BV BOUND     y_320
 BV BOUND     y_321
 BV BOUND     y_322
 BV BOUND     y_323
 BV BOUND     y_324
 BV BOUND     y_325
 BV BOUND     y_326
 BV BOUND     y_327
 BV BOUND     y_328
 BV BOUND     y_329
 BV BOUND     y_330
 BV BOUND     y_331
 BV BOUND     y_332
 BV BOUND     y_333
 BV BOUND     y_334
 BV BOUND     y_335
 BV BOUND     y_336
 BV BOUND     y_337
 BV BOUND     y_338
 BV BOUND     y_339
 BV BOUND     y_340
 BV BOUND     y_341
 BV BOUND     y_342
 BV BOUND     y_343
 BV BOUND     y_344
 BV BOUND     y_345
 BV BOUND     y_346
 BV BOUND     y_347
 BV BOUND     y_348
 BV BOUND     y_349
 BV BOUND     y_350
 BV BOUND     y_351
 BV BOUND     y_352
 BV BOUND     y_353
 BV BOUND     y_354
 BV BOUND     y_355
 BV BOUND     y_356
 BV BOUND     y_357
 BV BOUND     y_358
 BV BOUND     y_359
 BV BOUND     y_360
 BV BOUND     y_361
 BV BOUND     y_362
 BV BOUND     y_363
 BV BOUND     y_364
 BV BOUND     y_365
 BV BOUND     y_366
 BV BOUND     y_367
 BV BOUND     y_368
 BV BOUND     y_369
 BV BOUND     y_370
 BV BOUND     y_371
 BV BOUND     y_372
 BV BOUND     y_373
 BV BOUND     y_374
 BV BOUND     y_375
 BV BOUND     y_376
 BV BOUND     y_377
 BV BOUND     y_378
 BV BOUND     y_379
 BV BOUND     y_380
 BV BOUND     y_381
 BV BOUND     y_382
 BV BOUND     y_383
 BV BOUND     y_384
 BV BOUND     y_385
 BV BOUND     y_386
 BV BOUND     y_387
 BV BOUND     y_388
 BV BOUND     y_389
 BV BOUND     y_390
 BV BOUND     y_391
 BV BOUND     y_392
 BV BOUND     y_393
 BV BOUND     y_394
 BV BOUND     y_395
 BV BOUND     y_396
 BV BOUND     y_397
 BV BOUND     y_398
 BV BOUND     y_399
 BV BOUND     y_400
 BV BOUND     y_401
 BV BOUND     y_402
 BV BOUND     y_403
 BV BOUND     y_404
 BV BOUND     y_405
 BV BOUND     y_406
 BV BOUND     y_407
 BV BOUND     y_408
 BV BOUND     y_409
 BV BOUND     y_410
 BV BOUND     y_411
 BV BOUND     y_412
 BV BOUND     y_413
 BV BOUND     y_414
 BV BOUND     y_415
 BV BOUND     y_416
 BV BOUND     y_417
 BV BOUND     y_418
 BV BOUND     y_419
 BV BOUND     y_420
 BV BOUND     y_421
 BV BOUND     y_422
 BV BOUND     y_423
 BV BOUND     y_424
 BV BOUND     y_425
 BV BOUND     y_426
 BV BOUND     y_427
 BV BOUND     y_428
 BV BOUND     y_429
 BV BOUND     y_430
 BV BOUND     y_431
 BV BOUND     y_432
 BV BOUND     y_433
 BV BOUND     y_434
 BV BOUND     y_435
 BV BOUND     y_436
 BV BOUND     y_437
 BV BOUND     y_438
 BV BOUND     y_439
 BV BOUND     y_440
 BV BOUND     y_441
 BV BOUND     y_442
 BV BOUND     y_443
 BV BOUND     y_444
 BV BOUND     y_445
 BV BOUND     y_446
 BV BOUND     y_447
 BV BOUND     y_448
 BV BOUND     y_449
 BV BOUND     y_450
 BV BOUND     y_451
 BV BOUND     y_452
 BV BOUND     y_453
 BV BOUND     y_454
 BV BOUND     y_455
 BV BOUND     y_456
 BV BOUND     y_457
 BV BOUND     y_458
 BV BOUND     y_459
 BV BOUND     y_460
 BV BOUND     y_461
 BV BOUND     y_462
 BV BOUND     y_463
 BV BOUND     y_464
 BV BOUND     y_465
 BV BOUND     y_466
 BV BOUND     y_467
 BV BOUND     y_468
 BV BOUND     y_469
 BV BOUND     y_470
 BV BOUND     y_471
 BV BOUND     y_472
 BV BOUND     y_473
 BV BOUND     y_474
 BV BOUND     y_475
 BV BOUND     y_476
 BV BOUND     y_477
 BV BOUND     y_478
 BV BOUND     y_479
 BV BOUND     y_480
 BV BOUND     y_481
 BV BOUND     y_482
 BV BOUND     y_483
 BV BOUND     y_484
 BV BOUND     y_485
 BV BOUND     y_486
 BV BOUND     y_487
 BV BOUND     y_488
 BV BOUND     y_489
 BV BOUND     y_490
 BV BOUND     y_491
 BV BOUND     y_492
 BV BOUND     y_493
 BV BOUND     y_494
 BV BOUND     y_495
 BV BOUND     y_496
 BV BOUND     y_497
 BV BOUND     y_498
 BV BOUND     y_499
 BV BOUND     y_500
 BV BOUND     y_501
 BV BOUND     y_502
 BV BOUND     y_503
 BV BOUND     y_504
 BV BOUND     y_505
 BV BOUND     y_506
 BV BOUND     y_507
 BV BOUND     y_508
 BV BOUND     y_509
 BV BOUND     y_510
 BV BOUND     y_511
 BV BOUND     y_512
 BV BOUND     y_513
 BV BOUND     y_514
 BV BOUND     y_515
 BV BOUND     y_516
 BV BOUND     y_517
 BV BOUND     y_518
 BV BOUND     y_519
 BV BOUND     y_520
 BV BOUND     y_521
 BV BOUND     y_522
 BV BOUND     y_523
 BV BOUND     y_524
 BV BOUND     y_525
 BV BOUND     y_526
 BV BOUND     y_527
 BV BOUND     y_528
 BV BOUND     y_529
 BV BOUND     y_530
 BV BOUND     y_531
 BV BOUND     y_532
 BV BOUND     y_533
 BV BOUND     y_534
 BV BOUND     y_535
 BV BOUND     y_536
 BV BOUND     y_537
 BV BOUND     y_538
 BV BOUND     y_539
 BV BOUND     y_540
 BV BOUND     y_541
 BV BOUND     y_542
 BV BOUND     y_543
 BV BOUND     y_544
 BV BOUND     y_545
 BV BOUND     y_546
 BV BOUND     y_547
 BV BOUND     y_548
 BV BOUND     y_549
ENDATA
