NAME          steiner_sparse20_p03_t4
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 L  cap_0_2
 L  cap_0_3
 L  cap_0_7
 L  cap_0_8
 L  cap_0_9
 L  cap_0_16
 L  cap_0_17
 L  cap_0_18
 L  cap_1_2
 L  cap_1_4
 L  cap_1_7
 L  cap_1_18
 L  cap_2_9
 L  cap_2_10
 L  cap_2_13
 L  cap_2_14
 L  cap_2_15
 L  cap_3_7
 L  cap_3_10
 L  cap_3_18
 L  cap_4_11
 L  cap_4_12
 L  cap_4_14
 L  cap_4_17
 L  cap_5_6
 L  cap_5_8
 L  cap_5_9
 L  cap_5_11
 L  cap_5_13
 L  cap_5_17
 L  cap_6_7
 L  cap_6_8
 L  cap_6_10
 L  cap_6_15
 L  cap_6_17
 L  cap_7_9
 L  cap_7_11
 L  cap_7_13
 L  cap_7_15
 L  cap_7_18
 L  cap_8_19
 L  cap_9_12
 L  cap_9_13
 L  cap_9_15
 L  cap_9_16
 L  cap_9_17
 L  cap_9_18
 L  cap_9_19
 L  cap_10_14
 L  cap_10_16
 L  cap_11_13
 L  cap_11_15
 L  cap_11_18
 L  cap_11_19
 L  cap_12_13
 L  cap_12_14
 L  cap_12_16
 L  cap_12_19
 L  cap_13_18
 L  cap_14_17
 L  cap_14_19
 L  cap_15_17
 L  cap_16_19
 L  cap_17_18
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_2     OBJ       5
    x_0_2     cap_0_2   -4
    x_0_3     OBJ       3
    x_0_3     cap_0_3   -4
    x_0_7     OBJ       7
    x_0_7     cap_0_7   -4
    x_0_8     OBJ       2
    x_0_8     cap_0_8   -4
    x_0_9     OBJ       9
    x_0_9     cap_0_9   -4
    x_0_16    OBJ       14
    x_0_16    cap_0_16  -4
    x_0_17    OBJ       13
    x_0_17    cap_0_17  -4
    x_0_18    OBJ       7
    x_0_18    cap_0_18  -4
    x_1_2     OBJ       13
    x_1_2     cap_1_2   -4
    x_1_4     OBJ       2
    x_1_4     cap_1_4   -4
    x_1_7     OBJ       1
    x_1_7     cap_1_7   -4
    x_1_18    OBJ       4
    x_1_18    cap_1_18  -4
    x_2_9     OBJ       6
    x_2_9     cap_2_9   -4
    x_2_10    OBJ       5
    x_2_10    cap_2_10  -4
    x_2_13    OBJ       11
    x_2_13    cap_2_13  -4
    x_2_14    OBJ       12
    x_2_14    cap_2_14  -4
    x_2_15    OBJ       8
    x_2_15    cap_2_15  -4
    x_3_7     OBJ       1
    x_3_7     cap_3_7   -4
    x_3_10    OBJ       15
    x_3_10    cap_3_10  -4
    x_3_18    OBJ       4
    x_3_18    cap_3_18  -4
    x_4_11    OBJ       8
    x_4_11    cap_4_11  -4
    x_4_12    OBJ       1
    x_4_12    cap_4_12  -4
    x_4_14    OBJ       3
    x_4_14    cap_4_14  -4
    x_4_17    OBJ       7
    x_4_17    cap_4_17  -4
    x_5_6     OBJ       9
    x_5_6     cap_5_6   -4
    x_5_8     OBJ       12
    x_5_8     cap_5_8   -4
    x_5_9     OBJ       15
    x_5_9     cap_5_9   -4
    x_5_11    OBJ       11
    x_5_11    cap_5_11  -4
    x_5_13    OBJ       3
    x_5_13    cap_5_13  -4
    x_5_17    OBJ       9
    x_5_17    cap_5_17  -4
    x_6_7     OBJ       11
    x_6_7     cap_6_7   -4
    x_6_8     OBJ       11
    x_6_8     cap_6_8   -4
    x_6_10    OBJ       6
    x_6_10    cap_6_10  -4
    x_6_15    OBJ       6
    x_6_15    cap_6_15  -4
    x_6_17    OBJ       6
    x_6_17    cap_6_17  -4
    x_7_9     OBJ       15
    x_7_9     cap_7_9   -4
    x_7_11    OBJ       12
    x_7_11    cap_7_11  -4
    x_7_13    OBJ       13
    x_7_13    cap_7_13  -4
    x_7_15    OBJ       11
    x_7_15    cap_7_15  -4
    x_7_18    OBJ       14
    x_7_18    cap_7_18  -4
    x_8_19    OBJ       2
    x_8_19    cap_8_19  -4
    x_9_12    OBJ       4
    x_9_12    cap_9_12  -4
    x_9_13    OBJ       12
    x_9_13    cap_9_13  -4
    x_9_15    OBJ       15
    x_9_15    cap_9_15  -4
    x_9_16    OBJ       6
    x_9_16    cap_9_16  -4
    x_9_17    OBJ       4
    x_9_17    cap_9_17  -4
    x_9_18    OBJ       8
    x_9_18    cap_9_18  -4
    x_9_19    OBJ       3
    x_9_19    cap_9_19  -4
    x_10_14   OBJ       8
    x_10_14   cap_10_14  -4
    x_10_16   OBJ       2
    x_10_16   cap_10_16  -4
    x_11_13   OBJ       11
    x_11_13   cap_11_13  -4
    x_11_15   OBJ       7
    x_11_15   cap_11_15  -4
    x_11_18   OBJ       4
    x_11_18   cap_11_18  -4
    x_11_19   OBJ       8
    x_11_19   cap_11_19  -4
    x_12_13   OBJ       3
    x_12_13   cap_12_13  -4
    x_12_14   OBJ       4
    x_12_14   cap_12_14  -4
    x_12_16   OBJ       13
    x_12_16   cap_12_16  -4
    x_12_19   OBJ       9
    x_12_19   cap_12_19  -4
    x_13_18   OBJ       8
    x_13_18   cap_13_18  -4
    x_14_17   OBJ       1
    x_14_17   cap_14_17  -4
    x_14_19   OBJ       13
    x_14_19   cap_14_19  -4
    x_15_17   OBJ       12
    x_15_17   cap_15_17  -4
    x_16_19   OBJ       5
    x_16_19   cap_16_19  -4
    x_17_18   OBJ       1
    x_17_18   cap_17_18  -4
    MARK0001  'MARKER'                 'INTEND'
    f_0_2     flow_0    1.0
    f_0_2     flow_2    -1.0
    f_0_2     cap_0_2   1.0
    f_2_0     flow_0    -1.0
    f_2_0     flow_2    1.0
    f_2_0     cap_0_2   1.0
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_7     flow_0    1.0
    f_0_7     flow_7    -1.0
    f_0_7     cap_0_7   1.0
    f_7_0     flow_0    -1.0
    f_7_0     flow_7    1.0
    f_7_0     cap_0_7   1.0
    f_0_8     flow_0    1.0
    f_0_8     flow_8    -1.0
    f_0_8     cap_0_8   1.0
    f_8_0     flow_0    -1.0
    f_8_0     flow_8    1.0
    f_8_0     cap_0_8   1.0
    f_0_9     flow_0    1.0
    f_0_9     flow_9    -1.0
    f_0_9     cap_0_9   1.0
    f_9_0     flow_0    -1.0
    f_9_0     flow_9    1.0
    f_9_0     cap_0_9   1.0
    f_0_16    flow_0    1.0
    f_0_16    flow_16   -1.0
    f_0_16    cap_0_16  1.0
    f_16_0    flow_0    -1.0
    f_16_0    flow_16   1.0
    f_16_0    cap_0_16  1.0
    f_0_17    flow_0    1.0
    f_0_17    flow_17   -1.0
    f_0_17    cap_0_17  1.0
    f_17_0    flow_0    -1.0
    f_17_0    flow_17   1.0
    f_17_0    cap_0_17  1.0
    f_0_18    flow_0    1.0
    f_0_18    flow_18   -1.0
    f_0_18    cap_0_18  1.0
    f_18_0    flow_0    -1.0
    f_18_0    flow_18   1.0
    f_18_0    cap_0_18  1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_4     flow_1    1.0
    f_1_4     flow_4    -1.0
    f_1_4     cap_1_4   1.0
    f_4_1     flow_1    -1.0
    f_4_1     flow_4    1.0
    f_4_1     cap_1_4   1.0
    f_1_7     flow_1    1.0
    f_1_7     flow_7    -1.0
    f_1_7     cap_1_7   1.0
    f_7_1     flow_1    -1.0
    f_7_1     flow_7    1.0
    f_7_1     cap_1_7   1.0
    f_1_18    flow_1    1.0
    f_1_18    flow_18   -1.0
    f_1_18    cap_1_18  1.0
    f_18_1    flow_1    -1.0
    f_18_1    flow_18   1.0
    f_18_1    cap_1_18  1.0
    f_2_9     flow_2    1.0
    f_2_9     flow_9    -1.0
    f_2_9     cap_2_9   1.0
    f_9_2     flow_2    -1.0
    f_9_2     flow_9    1.0
    f_9_2     cap_2_9   1.0
    f_2_10    flow_2    1.0
    f_2_10    flow_10   -1.0
    f_2_10    cap_2_10  1.0
    f_10_2    flow_2    -1.0
    f_10_2    flow_10   1.0
    f_10_2    cap_2_10  1.0
    f_2_13    flow_2    1.0
    f_2_13    flow_13   -1.0
    f_2_13    cap_2_13  1.0
    f_13_2    flow_2    -1.0
    f_13_2    flow_13   1.0
    f_13_2    cap_2_13  1.0
    f_2_14    flow_2    1.0
    f_2_14    flow_14   -1.0
    f_2_14    cap_2_14  1.0
    f_14_2    flow_2    -1.0
    f_14_2    flow_14   1.0
    f_14_2    cap_2_14  1.0
    f_2_15    flow_2    1.0
    f_2_15    flow_15   -1.0
    f_2_15    cap_2_15  1.0
    f_15_2    flow_2    -1.0
    f_15_2    flow_15   1.0
    f_15_2    cap_2_15  1.0
    f_3_7     flow_3    1.0
    f_3_7     flow_7    -1.0
    f_3_7     cap_3_7   1.0
    f_7_3     flow_3    -1.0
    f_7_3     flow_7    1.0
    f_7_3     cap_3_7   1.0
    f_3_10    flow_3    1.0
    f_3_10    flow_10   -1.0
    f_3_10    cap_3_10  1.0
    f_10_3    flow_3    -1.0
    f_10_3    flow_10   1.0
    f_10_3    cap_3_10  1.0
    f_3_18    flow_3    1.0
    f_3_18    flow_18   -1.0
    f_3_18    cap_3_18  1.0
    f_18_3    flow_3    -1.0
    f_18_3    flow_18   1.0
    f_18_3    cap_3_18  1.0
    f_4_11    flow_4    1.0
    f_4_11    flow_11   -1.0
    f_4_11    cap_4_11  1.0
    f_11_4    flow_4    -1.0
    f_11_4    flow_11   1.0
    f_11_4    cap_4_11  1.0
    f_4_12    flow_4    1.0
    f_4_12    flow_12   -1.0
    f_4_12    cap_4_12  1.0
    f_12_4    flow_4    -1.0
    f_12_4    flow_12   1.0
    f_12_4    cap_4_12  1.0
    f_4_14    flow_4    1.0
    f_4_14    flow_14   -1.0
    f_4_14    cap_4_14  1.0
    f_14_4    flow_4    -1.0
    f_14_4    flow_14   1.0
    f_14_4    cap_4_14  1.0
    f_4_17    flow_4    1.0
    f_4_17    flow_17   -1.0
    f_4_17    cap_4_17  1.0
    f_17_4    flow_4    -1.0
    f_17_4    flow_17   1.0
    f_17_4    cap_4_17  1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_8     flow_5    1.0
    f_5_8     flow_8    -1.0
    f_5_8     cap_5_8   1.0
    f_8_5     flow_5    -1.0
    f_8_5     flow_8    1.0
    f_8_5     cap_5_8   1.0
    f_5_9     flow_5    1.0
    f_5_9     flow_9    -1.0
    f_5_9     cap_5_9   1.0
    f_9_5     flow_5    -1.0
    f_9_5     flow_9    1.0
    f_9_5     cap_5_9   1.0
    f_5_11    flow_5    1.0
    f_5_11    flow_11   -1.0
    f_5_11    cap_5_11  1.0
    f_11_5    flow_5    -1.0
    f_11_5    flow_11   1.0
    f_11_5    cap_5_11  1.0
    f_5_13    flow_5    1.0
    f_5_13    flow_13   -1.0
    f_5_13    cap_5_13  1.0
    f_13_5    flow_5    -1.0
    f_13_5    flow_13   1.0
    f_13_5    cap_5_13  1.0
    f_5_17    flow_5    1.0
    f_5_17    flow_17   -1.0
    f_5_17    cap_5_17  1.0
    f_17_5    flow_5    -1.0
    f_17_5    flow_17   1.0
    f_17_5    cap_5_17  1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_8     flow_6    1.0
    f_6_8     flow_8    -1.0
    f_6_8     cap_6_8   1.0
    f_8_6     flow_6    -1.0
    f_8_6     flow_8    1.0
    f_8_6     cap_6_8   1.0
    f_6_10    flow_6    1.0
    f_6_10    flow_10   -1.0
    f_6_10    cap_6_10  1.0
    f_10_6    flow_6    -1.0
    f_10_6    flow_10   1.0
    f_10_6    cap_6_10  1.0
    f_6_15    flow_6    1.0
    f_6_15    flow_15   -1.0
    f_6_15    cap_6_15  1.0
    f_15_6    flow_6    -1.0
    f_15_6    flow_15   1.0
    f_15_6    cap_6_15  1.0
    f_6_17    flow_6    1.0
    f_6_17    flow_17   -1.0
    f_6_17    cap_6_17  1.0
    f_17_6    flow_6    -1.0
    f_17_6    flow_17   1.0
    f_17_6    cap_6_17  1.0
    f_7_9     flow_7    1.0
    f_7_9     flow_9    -1.0
    f_7_9     cap_7_9   1.0
    f_9_7     flow_7    -1.0
    f_9_7     flow_9    1.0
    f_9_7     cap_7_9   1.0
    f_7_11    flow_7    1.0
    f_7_11    flow_11   -1.0
    f_7_11    cap_7_11  1.0
    f_11_7    flow_7    -1.0
    f_11_7    flow_11   1.0
    f_11_7    cap_7_11  1.0
    f_7_13    flow_7    1.0
    f_7_13    flow_13   -1.0
    f_7_13    cap_7_13  1.0
    f_13_7    flow_7    -1.0
    f_13_7    flow_13   1.0
    f_13_7    cap_7_13  1.0
    f_7_15    flow_7    1.0
    f_7_15    flow_15   -1.0
    f_7_15    cap_7_15  1.0
    f_15_7    flow_7    -1.0
    f_15_7    flow_15   1.0
    f_15_7    cap_7_15  1.0
    f_7_18    flow_7    1.0
    f_7_18    flow_18   -1.0
    f_7_18    cap_7_18  1.0
    f_18_7    flow_7    -1.0
    f_18_7    flow_18   1.0
    f_18_7    cap_7_18  1.0
    f_8_19    flow_8    1.0
    f_8_19    flow_19   -1.0
    f_8_19    cap_8_19  1.0
    f_19_8    flow_8    -1.0
    f_19_8    flow_19   1.0
    f_19_8    cap_8_19  1.0
    f_9_12    flow_9    1.0
    f_9_12    flow_12   -1.0
    f_9_12    cap_9_12  1.0
    f_12_9    flow_9    -1.0
    f_12_9    flow_12   1.0
    f_12_9    cap_9_12  1.0
    f_9_13    flow_9    1.0
    f_9_13    flow_13   -1.0
    f_9_13    cap_9_13  1.0
    f_13_9    flow_9    -1.0
    f_13_9    flow_13   1.0
    f_13_9    cap_9_13  1.0
    f_9_15    flow_9    1.0
    f_9_15    flow_15   -1.0
    f_9_15    cap_9_15  1.0
    f_15_9    flow_9    -1.0
    f_15_9    flow_15   1.0
    f_15_9    cap_9_15  1.0
    f_9_16    flow_9    1.0
    f_9_16    flow_16   -1.0
    f_9_16    cap_9_16  1.0
    f_16_9    flow_9    -1.0
    f_16_9    flow_16   1.0
    f_16_9    cap_9_16  1.0
    f_9_17    flow_9    1.0
    f_9_17    flow_17   -1.0
    f_9_17    cap_9_17  1.0
    f_17_9    flow_9    -1.0
    f_17_9    flow_17   1.0
    f_17_9    cap_9_17  1.0
    f_9_18    flow_9    1.0
    f_9_18    flow_18   -1.0
    f_9_18    cap_9_18  1.0
    f_18_9    flow_9    -1.0
    f_18_9    flow_18   1.0
    f_18_9    cap_9_18  1.0
    f_9_19    flow_9    1.0
    f_9_19    flow_19   -1.0
    f_9_19    cap_9_19  1.0
    f_19_9    flow_9    -1.0
    f_19_9    flow_19   1.0
    f_19_9    cap_9_19  1.0
    f_10_14   flow_10   1.0
    f_10_14   flow_14   -1.0
    f_10_14   cap_10_14  1.0
    f_14_10   flow_10   -1.0
    f_14_10   flow_14   1.0
    f_14_10   cap_10_14  1.0
    f_10_16   flow_10   1.0
    f_10_16   flow_16   -1.0
    f_10_16   cap_10_16  1.0
    f_16_10   flow_10   -1.0
    f_16_10   flow_16   1.0
    f_16_10   cap_10_16  1.0
    f_11_13   flow_11   1.0
    f_11_13   flow_13   -1.0
    f_11_13   cap_11_13  1.0
    f_13_11   flow_11   -1.0
    f_13_11   flow_13   1.0
    f_13_11   cap_11_13  1.0
    f_11_15   flow_11   1.0
    f_11_15   flow_15   -1.0
    f_11_15   cap_11_15  1.0
    f_15_11   flow_11   -1.0
    f_15_11   flow_15   1.0
    f_15_11   cap_11_15  1.0
    f_11_18   flow_11   1.0
    f_11_18   flow_18   -1.0
    f_11_18   cap_11_18  1.0
    f_18_11   flow_11   -1.0
    f_18_11   flow_18   1.0
    f_18_11   cap_11_18  1.0
    f_11_19   flow_11   1.0
    f_11_19   flow_19   -1.0
    f_11_19   cap_11_19  1.0
    f_19_11   flow_11   -1.0
    f_19_11   flow_19   1.0
    f_19_11   cap_11_19  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_12_14   flow_12   1.0
    f_12_14   flow_14   -1.0
    f_12_14   cap_12_14  1.0
    f_14_12   flow_12   -1.0
    f_14_12   flow_14   1.0
    f_14_12   cap_12_14  1.0
    f_12_16   flow_12   1.0
    f_12_16   flow_16   -1.0
    f_12_16   cap_12_16  1.0
    f_16_12   flow_12   -1.0
    f_16_12   flow_16   1.0
    f_16_12   cap_12_16  1.0
    f_12_19   flow_12   1.0
    f_12_19   flow_19   -1.0
    f_12_19   cap_12_19  1.0
    f_19_12   flow_12   -1.0
    f_19_12   flow_19   1.0
    f_19_12   cap_12_19  1.0
    f_13_18   flow_13   1.0
    f_13_18   flow_18   -1.0
    f_13_18   cap_13_18  1.0
    f_18_13   flow_13   -1.0
    f_18_13   flow_18   1.0
    f_18_13   cap_13_18  1.0
    f_14_17   flow_14   1.0
    f_14_17   flow_17   -1.0
    f_14_17   cap_14_17  1.0
    f_17_14   flow_14   -1.0
    f_17_14   flow_17   1.0
    f_17_14   cap_14_17  1.0
    f_14_19   flow_14   1.0
    f_14_19   flow_19   -1.0
    f_14_19   cap_14_19  1.0
    f_19_14   flow_14   -1.0
    f_19_14   flow_19   1.0
    f_19_14   cap_14_19  1.0
    f_15_17   flow_15   1.0
    f_15_17   flow_17   -1.0
    f_15_17   cap_15_17  1.0
    f_17_15   flow_15   -1.0
    f_17_15   flow_17   1.0
    f_17_15   cap_15_17  1.0
    f_16_19   flow_16   1.0
    f_16_19   flow_19   -1.0
    f_16_19   cap_16_19  1.0
    f_19_16   flow_16   -1.0
    f_19_16   flow_19   1.0
    f_19_16   cap_16_19  1.0
    f_17_18   flow_17   1.0
    f_17_18   flow_18   -1.0
    f_17_18   cap_17_18  1.0
    f_18_17   flow_17   -1.0
    f_18_17   flow_18   1.0
    f_18_17   cap_17_18  1.0
RHS
    RHS       flow_0    4
    RHS       flow_1    -1
    RHS       flow_4    -1
    RHS       flow_8    -1
    RHS       flow_9    -1
BOUNDS
 BV BOUND     x_0_2
 BV BOUND     x_0_3
 BV BOUND     x_0_7
 BV BOUND     x_0_8
 BV BOUND     x_0_9
 BV BOUND     x_0_16
 BV BOUND     x_0_17
 BV BOUND     x_0_18
 BV BOUND     x_1_2
 BV BOUND     x_1_4
 BV BOUND     x_1_7
 BV BOUND     x_1_18
 BV BOUND     x_2_9
 BV BOUND     x_2_10
 BV BOUND     x_2_13
 BV BOUND     x_2_14
 BV BOUND     x_2_15
 BV BOUND     x_3_7
 BV BOUND     x_3_10
 BV BOUND     x_3_18
 BV BOUND     x_4_11
 BV BOUND     x_4_12
 BV BOUND     x_4_14
 BV BOUND     x_4_17
 BV BOUND     x_5_6
 BV BOUND     x_5_8
 BV BOUND     x_5_9
 BV BOUND     x_5_11
 BV BOUND     x_5_13
 BV BOUND     x_5_17
 BV BOUND     x_6_7
 BV BOUND     x_6_8
 BV BOUND     x_6_10
 BV BOUND     x_6_15
 BV BOUND     x_6_17
 BV BOUND     x_7_9
 BV BOUND     x_7_11
 BV BOUND     x_7_13
 BV BOUND     x_7_15
 BV BOUND     x_7_18
 BV BOUND     x_8_19
 BV BOUND     x_9_12
 BV BOUND     x_9_13
 BV BOUND     x_9_15
 BV BOUND     x_9_16
 BV BOUND     x_9_17
 BV BOUND     x_9_18
 BV BOUND     x_9_19
 BV BOUND     x_10_14
 BV BOUND     x_10_16
 BV BOUND     x_11_13
 BV BOUND     x_11_15
 BV BOUND     x_11_18
 BV BOUND     x_11_19
 BV BOUND     x_12_13
 BV BOUND     x_12_14
 BV BOUND     x_12_16
 BV BOUND     x_12_19
 BV BOUND     x_13_18
 BV BOUND     x_14_17
 BV BOUND     x_14_19
 BV BOUND     x_15_17
 BV BOUND     x_16_19
 BV BOUND     x_17_18
 UP BOUND     f_0_2     4
 UP BOUND     f_2_0     4
 UP BOUND     f_0_3     4
 UP BOUND     f_3_0     4
 UP BOUND     f_0_7     4
 UP BOUND     f_7_0     4
 UP BOUND     f_0_8     4
 UP BOUND     f_8_0     4
 UP BOUND     f_0_9     4
 UP BOUND     f_9_0     4
 UP BOUND     f_0_16    4
 UP BOUND     f_16_0    4
 UP BOUND     f_0_17    4
 UP BOUND     f_17_0    4
 UP BOUND     f_0_18    4
 UP BOUND     f_18_0    4
 UP BOUND     f_1_2     4
 UP BOUND     f_2_1     4
 UP BOUND     f_1_4     4
 UP BOUND     f_4_1     4
 UP BOUND     f_1_7     4
 UP BOUND     f_7_1     4
 UP BOUND     f_1_18    4
 UP BOUND     f_18_1    4
 UP BOUND     f_2_9     4
 UP BOUND     f_9_2     4
 UP BOUND     f_2_10    4
 UP BOUND     f_10_2    4
 UP BOUND     f_2_13    4
 UP BOUND     f_13_2    4
 UP BOUND     f_2_14    4
 UP BOUND     f_14_2    4
 UP BOUND     f_2_15    4
 UP BOUND     f_15_2    4
 UP BOUND     f_3_7     4
 UP BOUND     f_7_3     4
 UP BOUND     f_3_10    4
 UP BOUND     f_10_3    4
 UP BOUND     f_3_18    4
 UP BOUND     f_18_3    4
 UP BOUND     f_4_11    4
 UP BOUND     f_11_4    4
 UP BOUND     f_4_12    4
 UP BOUND     f_12_4    4
 UP BOUND     f_4_14    4
 UP BOUND     f_14_4    4
 UP BOUND     f_4_17    4
 UP BOUND     f_17_4    4
 UP BOUND     f_5_6     4
 UP BOUND     f_6_5     4
 UP BOUND     f_5_8     4
 UP BOUND     f_8_5     4
 UP BOUND     f_5_9     4
 UP BOUND     f_9_5     4
 UP BOUND     f_5_11    4
 UP BOUND     f_11_5    4
 UP BOUND     f_5_13    4
 UP BOUND     f_13_5    4
 UP BOUND     f_5_17    4
 UP BOUND     f_17_5    4
 UP BOUND     f_6_7     4
 UP BOUND     f_7_6     4
 UP BOUND     f_6_8     4
 UP BOUND     f_8_6     4
 UP BOUND     f_6_10    4
 UP BOUND     f_10_6    4
 UP BOUND     f_6_15    4
 UP BOUND     f_15_6    4
 UP BOUND     f_6_17    4
 UP BOUND     f_17_6    4
 UP BOUND     f_7_9     4
 UP BOUND     f_9_7     4
 UP BOUND     f_7_11    4
 UP BOUND     f_11_7    4
 UP BOUND     f_7_13    4
 UP BOUND     f_13_7    4
 UP BOUND     f_7_15    4
 UP BOUND     f_15_7    4
 UP BOUND     f_7_18    4
 UP BOUND     f_18_7    4
 UP BOUND     f_8_19    4
 UP BOUND     f_19_8    4
 UP BOUND     f_9_12    4
 UP BOUND     f_12_9    4
 UP BOUND     f_9_13    4
 UP BOUND     f_13_9    4
 UP BOUND     f_9_15    4
 UP BOUND     f_15_9    4
 UP BOUND     f_9_16    4
 UP BOUND     f_16_9    4
 UP BOUND     f_9_17    4
 UP BOUND     f_17_9    4
 UP BOUND     f_9_18    4
 UP BOUND     f_18_9    4
 UP BOUND     f_9_19    4
 UP BOUND     f_19_9    4
 UP BOUND     f_10_14   4
 UP BOUND     f_14_10   4
 UP BOUND     f_10_16   4
 UP BOUND     f_16_10   4
 UP BOUND     f_11_13   4
 UP BOUND     f_13_11   4
 UP BOUND     f_11_15   4
 UP BOUND     f_15_11   4
 UP BOUND     f_11_18   4
 UP BOUND     f_18_11   4
 UP BOUND     f_11_19   4
 UP BOUND     f_19_11   4
 UP BOUND     f_12_13   4
 UP BOUND     f_13_12   4
 UP BOUND     f_12_14   4
 UP BOUND     f_14_12   4
 UP BOUND     f_12_16   4
 UP BOUND     f_16_12   4
 UP BOUND     f_12_19   4
 UP BOUND     f_19_12   4
 UP BOUND     f_13_18   4
 UP BOUND     f_18_13   4
 UP BOUND     f_14_17   4
 UP BOUND     f_17_14   4
 UP BOUND     f_14_19   4
 UP BOUND     f_19_14   4
 UP BOUND     f_15_17   4
 UP BOUND     f_17_15   4
 UP BOUND     f_16_19   4
 UP BOUND     f_19_16   4
 UP BOUND     f_17_18   4
 UP BOUND     f_18_17   4
ENDATA
