NAME          fcnf_layered_continuous_loose
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
COLUMNS
    x_0         OBJ       49.85
    x_0         flow_0      1.0
    x_0         flow_3      -1.0
    x_0         link_0      1.0
    x_1         OBJ       34.55
    x_1         flow_0      1.0
    x_1         flow_4      -1.0
    x_1         link_1      1.0
    x_2         OBJ       25.11
    x_2         flow_0      1.0
    x_2         flow_5      -1.0
    x_2         link_2      1.0
    x_3         OBJ       25.11
    x_3         flow_0      1.0
    x_3         flow_6      -1.0
    x_3         link_3      1.0
    x_4         OBJ       78.78
    x_4         flow_0      1.0
    x_4         flow_7      -1.0
    x_4         link_4      1.0
    x_5         OBJ       78.34
    x_5         flow_1      1.0
    x_5         flow_3      -1.0
    x_5         link_5      1.0
    x_6         OBJ       56.45
    x_6         flow_1      1.0
    x_6         flow_4      -1.0
    x_6         link_6      1.0
    x_7         OBJ       77.75
    x_7         flow_1      1.0
    x_7         flow_5      -1.0
    x_7         link_7      1.0
    x_8         OBJ       67.63
    x_8         flow_1      1.0
    x_8         flow_6      -1.0
    x_8         link_8      1.0
    x_9         OBJ       33.63
    x_9         flow_1      1.0
    x_9         flow_7      -1.0
    x_9         link_9      1.0
    x_10        OBJ       62.0
    x_10        flow_2      1.0
    x_10        flow_3      -1.0
    x_10        link_10     1.0
    x_11        OBJ       36.27
    x_11        flow_2      1.0
    x_11        flow_4      -1.0
    x_11        link_11     1.0
    x_12        OBJ       36.18
    x_12        flow_2      1.0
    x_12        flow_5      -1.0
    x_12        link_12     1.0
    x_13        OBJ       44.71
    x_13        flow_2      1.0
    x_13        flow_6      -1.0
    x_13        link_13     1.0
    x_14        OBJ       69.17
    x_14        flow_2      1.0
    x_14        flow_7      -1.0
    x_14        link_14     1.0
    x_15        OBJ       77.98
    x_15        flow_3      1.0
    x_15        flow_8      -1.0
    x_15        link_15     1.0
    x_16        OBJ       68.9
    x_16        flow_3      1.0
    x_16        flow_9      -1.0
    x_16        link_16     1.0
    x_17        OBJ       54.23
    x_17        flow_3      1.0
    x_17        flow_10     -1.0
    x_17        link_17     1.0
    x_18        OBJ       42.06
    x_18        flow_3      1.0
    x_18        flow_11     -1.0
    x_18        link_18     1.0
    x_19        OBJ       20.54
    x_19        flow_3      1.0
    x_19        flow_12     -1.0
    x_19        link_19     1.0
    x_20        OBJ       78.7
    x_20        flow_4      1.0
    x_20        flow_8      -1.0
    x_20        link_20     1.0
    x_21        OBJ       68.17
    x_21        flow_4      1.0
    x_21        flow_9      -1.0
    x_21        link_21     1.0
    x_22        OBJ       25.88
    x_22        flow_4      1.0
    x_22        flow_10     -1.0
    x_22        link_22     1.0
    x_23        OBJ       34.75
    x_23        flow_4      1.0
    x_23        flow_11     -1.0
    x_23        link_23     1.0
    x_24        OBJ       77.95
    x_24        flow_4      1.0
    x_24        flow_12     -1.0
    x_24        link_24     1.0
    x_25        OBJ       75.58
    x_25        flow_5      1.0
    x_25        flow_8      -1.0
    x_25        link_25     1.0
    x_26        OBJ       45.1
    x_26        flow_5      1.0
    x_26        flow_9      -1.0
    x_26        link_26     1.0
    x_27        OBJ       44.19
    x_27        flow_5      1.0
    x_27        flow_10     -1.0
    x_27        link_27     1.0
    x_28        OBJ       21.15
    x_28        flow_5      1.0
    x_28        flow_11     -1.0
    x_28        link_28     1.0
    x_29        OBJ       20.53
    x_29        flow_5      1.0
    x_29        flow_12     -1.0
    x_29        link_29     1.0
    x_30        OBJ       58.7
    x_30        flow_6      1.0
    x_30        flow_8      -1.0
    x_30        link_30     1.0
    x_31        OBJ       38.09
    x_31        flow_6      1.0
    x_31        flow_9      -1.0
    x_31        link_31     1.0
    x_32        OBJ       26.74
    x_32        flow_6      1.0
    x_32        flow_10     -1.0
    x_32        link_32     1.0
    x_33        OBJ       23.01
    x_33        flow_6      1.0
    x_33        flow_11     -1.0
    x_33        link_33     1.0
    x_34        OBJ       64.26
    x_34        flow_6      1.0
    x_34        flow_12     -1.0
    x_34        link_34     1.0
    x_35        OBJ       50.01
    x_35        flow_7      1.0
    x_35        flow_8      -1.0
    x_35        link_35     1.0
    x_36        OBJ       79.75
    x_36        flow_7      1.0
    x_36        flow_9      -1.0
    x_36        link_36     1.0
    x_37        OBJ       49.64
    x_37        flow_7      1.0
    x_37        flow_10     -1.0
    x_37        link_37     1.0
    x_38        OBJ       33.42
    x_38        flow_7      1.0
    x_38        flow_11     -1.0
    x_38        link_38     1.0
    x_39        OBJ       69.59
    x_39        flow_7      1.0
    x_39        flow_12     -1.0
    x_39        link_39     1.0
    x_40        OBJ       22.67
    x_40        flow_8      1.0
    x_40        flow_13     -1.0
    x_40        link_40     1.0
    x_41        OBJ       48.82
    x_41        flow_8      1.0
    x_41        flow_14     -1.0
    x_41        link_41     1.0
    x_42        OBJ       71.0
    x_42        flow_8      1.0
    x_42        flow_15     -1.0
    x_42        link_42     1.0
    x_43        OBJ       50.87
    x_43        flow_9      1.0
    x_43        flow_13     -1.0
    x_43        link_43     1.0
    x_44        OBJ       21.68
    x_44        flow_9      1.0
    x_44        flow_14     -1.0
    x_44        link_44     1.0
    x_45        OBJ       47.94
    x_45        flow_9      1.0
    x_45        flow_15     -1.0
    x_45        link_45     1.0
    x_46        OBJ       34.9
    x_46        flow_10     1.0
    x_46        flow_13     -1.0
    x_46        link_46     1.0
    x_47        OBJ       54.41
    x_47        flow_10     1.0
    x_47        flow_14     -1.0
    x_47        link_47     1.0
    x_48        OBJ       78.6
    x_48        flow_10     1.0
    x_48        flow_15     -1.0
    x_48        link_48     1.0
    x_49        OBJ       31.09
    x_49        flow_11     1.0
    x_49        flow_13     -1.0
    x_49        link_49     1.0
    x_50        OBJ       42.79
    x_50        flow_11     1.0
    x_50        flow_14     -1.0
    x_50        link_50     1.0
    x_51        OBJ       75.4
    x_51        flow_11     1.0
    x_51        flow_15     -1.0
    x_51        link_51     1.0
    x_52        OBJ       77.84
    x_52        flow_12     1.0
    x_52        flow_13     -1.0
    x_52        link_52     1.0
    x_53        OBJ       73.6
    x_53        flow_12     1.0
    x_53        flow_14     -1.0
    x_53        link_53     1.0
    x_54        OBJ       29.44
    x_54        flow_12     1.0
    x_54        flow_15     -1.0
    x_54        link_54     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       1.17
    y_0         link_0      -17.75
    y_1         OBJ       1.68
    y_1         link_1      -24.41
    y_2         OBJ       1.29
    y_2         link_2      -18.53
    y_3         OBJ       0.88
    y_3         link_3      -21.51
    y_4         OBJ       1.3
    y_4         link_4      -8.78
    y_5         OBJ       1.32
    y_5         link_5      -17.08
    y_6         OBJ       2.09
    y_6         link_6      -23.31
    y_7         OBJ       2.23
    y_7         link_7      -21.5
    y_8         OBJ       2.11
    y_8         link_8      -13.61
    y_9         OBJ       1.17
    y_9         link_9      -23.6
    y_10        OBJ       0.76
    y_10        link_10     -23.22
    y_11        OBJ       2.23
    y_11        link_11     -14.2
    y_12        OBJ       1.02
    y_12        link_12     -16.58
    y_13        OBJ       2.06
    y_13        link_13     -18.92
    y_14        OBJ       2.63
    y_14        link_14     -17.51
    y_15        OBJ       1.74
    y_15        link_15     -22.75
    y_16        OBJ       2.54
    y_16        link_16     -7.5
    y_17        OBJ       1.79
    y_17        link_17     -6.86
    y_18        OBJ       1.79
    y_18        link_18     -5.13
    y_19        OBJ       1.97
    y_19        link_19     -13.22
    y_20        OBJ       2.63
    y_20        link_20     -21.58
    y_21        OBJ       1.06
    y_21        link_21     -19.52
    y_22        OBJ       0.84
    y_22        link_22     -12.52
    y_23        OBJ       0.58
    y_23        link_23     -15.36
    y_24        OBJ       0.7
    y_24        link_24     -9.74
    y_25        OBJ       1.82
    y_25        link_25     -14.3
    y_26        OBJ       2.55
    y_26        link_26     -14.4
    y_27        OBJ       1.41
    y_27        link_27     -20.5
    y_28        OBJ       1.61
    y_28        link_28     -17.79
    y_29        OBJ       1.29
    y_29        link_29     -11.94
    y_30        OBJ       1.8
    y_30        link_30     -14.96
    y_31        OBJ       1.57
    y_31        link_31     -23.53
    y_32        OBJ       0.72
    y_32        link_32     -8.19
    y_33        OBJ       0.86
    y_33        link_33     -11.22
    y_34        OBJ       2.9
    y_34        link_34     -5.32
    y_35        OBJ       1.1
    y_35        link_35     -22.99
    y_36        OBJ       2.24
    y_36        link_36     -5.53
    y_37        OBJ       1.58
    y_37        link_37     -15.8
    y_38        OBJ       0.57
    y_38        link_38     -17.1
    y_39        OBJ       1.34
    y_39        link_39     -12.56
    y_40        OBJ       1.83
    y_40        link_40     -21.32
    y_41        OBJ       0.82
    y_41        link_41     -7.28
    y_42        OBJ       2.28
    y_42        link_42     -10.11
    y_43        OBJ       0.81
    y_43        link_43     -16.19
    y_44        OBJ       1.25
    y_44        link_44     -14.69
    y_45        OBJ       1.24
    y_45        link_45     -18.28
    y_46        OBJ       2.46
    y_46        link_46     -21.62
    y_47        OBJ       2.9
    y_47        link_47     -9.98
    y_48        OBJ       0.62
    y_48        link_48     -16.23
    y_49        OBJ       0.79
    y_49        link_49     -10.53
    y_50        OBJ       0.5
    y_50        link_50     -10.64
    y_51        OBJ       2.51
    y_51        link_51     -18.33
    y_52        OBJ       1.71
    y_52        link_52     -20.15
    y_53        OBJ       1.81
    y_53        link_53     -14.89
    y_54        OBJ       2.84
    y_54        link_54     -11.69
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_1      14
    RHS       flow_2      14
    RHS       flow_14     -14
    RHS       flow_15     -14
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
ENDATA
