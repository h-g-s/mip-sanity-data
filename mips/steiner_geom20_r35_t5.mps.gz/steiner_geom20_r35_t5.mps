NAME          steiner_geom20_r35_t5
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 L  cap_0_14
 L  cap_0_15
 L  cap_0_19
 L  cap_1_3
 L  cap_1_8
 L  cap_1_9
 L  cap_1_16
 L  cap_2_6
 L  cap_2_14
 L  cap_2_15
 L  cap_2_17
 L  cap_2_18
 L  cap_3_4
 L  cap_3_9
 L  cap_3_11
 L  cap_3_16
 L  cap_4_10
 L  cap_4_11
 L  cap_4_16
 L  cap_5_12
 L  cap_5_13
 L  cap_6_14
 L  cap_6_15
 L  cap_6_17
 L  cap_6_19
 L  cap_7_12
 L  cap_8_9
 L  cap_10_11
 L  cap_10_17
 L  cap_11_16
 L  cap_12_13
 L  cap_14_15
 L  cap_14_17
 L  cap_14_19
 L  cap_15_18
 L  cap_15_19
 L  cap_18_19
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_14    OBJ       30.21
    x_0_14    cap_0_14  -5
    x_0_15    OBJ       22.52
    x_0_15    cap_0_15  -5
    x_0_19    OBJ       11.0
    x_0_19    cap_0_19  -5
    x_1_3     OBJ       29.82
    x_1_3     cap_1_3   -5
    x_1_8     OBJ       9.08
    x_1_8     cap_1_8   -5
    x_1_9     OBJ       10.91
    x_1_9     cap_1_9   -5
    x_1_16    OBJ       31.57
    x_1_16    cap_1_16  -5
    x_2_6     OBJ       31.23
    x_2_6     cap_2_6   -5
    x_2_14    OBJ       31.03
    x_2_14    cap_2_14  -5
    x_2_15    OBJ       26.98
    x_2_15    cap_2_15  -5
    x_2_17    OBJ       23.23
    x_2_17    cap_2_17  -5
    x_2_18    OBJ       31.21
    x_2_18    cap_2_18  -5
    x_3_4     OBJ       33.02
    x_3_4     cap_3_4   -5
    x_3_9     OBJ       33.77
    x_3_9     cap_3_9   -5
    x_3_11    OBJ       29.28
    x_3_11    cap_3_11  -5
    x_3_16    OBJ       5.47
    x_3_16    cap_3_16  -5
    x_4_10    OBJ       16.98
    x_4_10    cap_4_10  -5
    x_4_11    OBJ       3.81
    x_4_11    cap_4_11  -5
    x_4_16    OBJ       29.63
    x_4_16    cap_4_16  -5
    x_5_12    OBJ       24.22
    x_5_12    cap_5_12  -5
    x_5_13    OBJ       14.36
    x_5_13    cap_5_13  -5
    x_6_14    OBJ       7.03
    x_6_14    cap_6_14  -5
    x_6_15    OBJ       24.27
    x_6_15    cap_6_15  -5
    x_6_17    OBJ       22.38
    x_6_17    cap_6_17  -5
    x_6_19    OBJ       32.83
    x_6_19    cap_6_19  -5
    x_7_12    OBJ       31.73
    x_7_12    cap_7_12  -5
    x_8_9     OBJ       8.68
    x_8_9     cap_8_9   -5
    x_10_11   OBJ       17.81
    x_10_11   cap_10_11  -5
    x_10_17   OBJ       28.79
    x_10_17   cap_10_17  -5
    x_11_16   OBJ       25.82
    x_11_16   cap_11_16  -5
    x_12_13   OBJ       9.89
    x_12_13   cap_12_13  -5
    x_14_15   OBJ       18.17
    x_14_15   cap_14_15  -5
    x_14_17   OBJ       27.42
    x_14_17   cap_14_17  -5
    x_14_19   OBJ       25.85
    x_14_19   cap_14_19  -5
    x_15_18   OBJ       24.68
    x_15_18   cap_15_18  -5
    x_15_19   OBJ       12.73
    x_15_19   cap_15_19  -5
    x_18_19   OBJ       27.58
    x_18_19   cap_18_19  -5
    MARK0001  'MARKER'                 'INTEND'
    f_0_14    flow_0    1.0
    f_0_14    flow_14   -1.0
    f_0_14    cap_0_14  1.0
    f_14_0    flow_0    -1.0
    f_14_0    flow_14   1.0
    f_14_0    cap_0_14  1.0
    f_0_15    flow_0    1.0
    f_0_15    flow_15   -1.0
    f_0_15    cap_0_15  1.0
    f_15_0    flow_0    -1.0
    f_15_0    flow_15   1.0
    f_15_0    cap_0_15  1.0
    f_0_19    flow_0    1.0
    f_0_19    flow_19   -1.0
    f_0_19    cap_0_19  1.0
    f_19_0    flow_0    -1.0
    f_19_0    flow_19   1.0
    f_19_0    cap_0_19  1.0
    f_1_3     flow_1    1.0
    f_1_3     flow_3    -1.0
    f_1_3     cap_1_3   1.0
    f_3_1     flow_1    -1.0
    f_3_1     flow_3    1.0
    f_3_1     cap_1_3   1.0
    f_1_8     flow_1    1.0
    f_1_8     flow_8    -1.0
    f_1_8     cap_1_8   1.0
    f_8_1     flow_1    -1.0
    f_8_1     flow_8    1.0
    f_8_1     cap_1_8   1.0
    f_1_9     flow_1    1.0
    f_1_9     flow_9    -1.0
    f_1_9     cap_1_9   1.0
    f_9_1     flow_1    -1.0
    f_9_1     flow_9    1.0
    f_9_1     cap_1_9   1.0
    f_1_16    flow_1    1.0
    f_1_16    flow_16   -1.0
    f_1_16    cap_1_16  1.0
    f_16_1    flow_1    -1.0
    f_16_1    flow_16   1.0
    f_16_1    cap_1_16  1.0
    f_2_6     flow_2    1.0
    f_2_6     flow_6    -1.0
    f_2_6     cap_2_6   1.0
    f_6_2     flow_2    -1.0
    f_6_2     flow_6    1.0
    f_6_2     cap_2_6   1.0
    f_2_14    flow_2    1.0
    f_2_14    flow_14   -1.0
    f_2_14    cap_2_14  1.0
    f_14_2    flow_2    -1.0
    f_14_2    flow_14   1.0
    f_14_2    cap_2_14  1.0
    f_2_15    flow_2    1.0
    f_2_15    flow_15   -1.0
    f_2_15    cap_2_15  1.0
    f_15_2    flow_2    -1.0
    f_15_2    flow_15   1.0
    f_15_2    cap_2_15  1.0
    f_2_17    flow_2    1.0
    f_2_17    flow_17   -1.0
    f_2_17    cap_2_17  1.0
    f_17_2    flow_2    -1.0
    f_17_2    flow_17   1.0
    f_17_2    cap_2_17  1.0
    f_2_18    flow_2    1.0
    f_2_18    flow_18   -1.0
    f_2_18    cap_2_18  1.0
    f_18_2    flow_2    -1.0
    f_18_2    flow_18   1.0
    f_18_2    cap_2_18  1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_9     flow_3    1.0
    f_3_9     flow_9    -1.0
    f_3_9     cap_3_9   1.0
    f_9_3     flow_3    -1.0
    f_9_3     flow_9    1.0
    f_9_3     cap_3_9   1.0
    f_3_11    flow_3    1.0
    f_3_11    flow_11   -1.0
    f_3_11    cap_3_11  1.0
    f_11_3    flow_3    -1.0
    f_11_3    flow_11   1.0
    f_11_3    cap_3_11  1.0
    f_3_16    flow_3    1.0
    f_3_16    flow_16   -1.0
    f_3_16    cap_3_16  1.0
    f_16_3    flow_3    -1.0
    f_16_3    flow_16   1.0
    f_16_3    cap_3_16  1.0
    f_4_10    flow_4    1.0
    f_4_10    flow_10   -1.0
    f_4_10    cap_4_10  1.0
    f_10_4    flow_4    -1.0
    f_10_4    flow_10   1.0
    f_10_4    cap_4_10  1.0
    f_4_11    flow_4    1.0
    f_4_11    flow_11   -1.0
    f_4_11    cap_4_11  1.0
    f_11_4    flow_4    -1.0
    f_11_4    flow_11   1.0
    f_11_4    cap_4_11  1.0
    f_4_16    flow_4    1.0
    f_4_16    flow_16   -1.0
    f_4_16    cap_4_16  1.0
    f_16_4    flow_4    -1.0
    f_16_4    flow_16   1.0
    f_16_4    cap_4_16  1.0
    f_5_12    flow_5    1.0
    f_5_12    flow_12   -1.0
    f_5_12    cap_5_12  1.0
    f_12_5    flow_5    -1.0
    f_12_5    flow_12   1.0
    f_12_5    cap_5_12  1.0
    f_5_13    flow_5    1.0
    f_5_13    flow_13   -1.0
    f_5_13    cap_5_13  1.0
    f_13_5    flow_5    -1.0
    f_13_5    flow_13   1.0
    f_13_5    cap_5_13  1.0
    f_6_14    flow_6    1.0
    f_6_14    flow_14   -1.0
    f_6_14    cap_6_14  1.0
    f_14_6    flow_6    -1.0
    f_14_6    flow_14   1.0
    f_14_6    cap_6_14  1.0
    f_6_15    flow_6    1.0
    f_6_15    flow_15   -1.0
    f_6_15    cap_6_15  1.0
    f_15_6    flow_6    -1.0
    f_15_6    flow_15   1.0
    f_15_6    cap_6_15  1.0
    f_6_17    flow_6    1.0
    f_6_17    flow_17   -1.0
    f_6_17    cap_6_17  1.0
    f_17_6    flow_6    -1.0
    f_17_6    flow_17   1.0
    f_17_6    cap_6_17  1.0
    f_6_19    flow_6    1.0
    f_6_19    flow_19   -1.0
    f_6_19    cap_6_19  1.0
    f_19_6    flow_6    -1.0
    f_19_6    flow_19   1.0
    f_19_6    cap_6_19  1.0
    f_7_12    flow_7    1.0
    f_7_12    flow_12   -1.0
    f_7_12    cap_7_12  1.0
    f_12_7    flow_7    -1.0
    f_12_7    flow_12   1.0
    f_12_7    cap_7_12  1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
    f_10_17   flow_10   1.0
    f_10_17   flow_17   -1.0
    f_10_17   cap_10_17  1.0
    f_17_10   flow_10   -1.0
    f_17_10   flow_17   1.0
    f_17_10   cap_10_17  1.0
    f_11_16   flow_11   1.0
    f_11_16   flow_16   -1.0
    f_11_16   cap_11_16  1.0
    f_16_11   flow_11   -1.0
    f_16_11   flow_16   1.0
    f_16_11   cap_11_16  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_14_15   flow_14   1.0
    f_14_15   flow_15   -1.0
    f_14_15   cap_14_15  1.0
    f_15_14   flow_14   -1.0
    f_15_14   flow_15   1.0
    f_15_14   cap_14_15  1.0
    f_14_17   flow_14   1.0
    f_14_17   flow_17   -1.0
    f_14_17   cap_14_17  1.0
    f_17_14   flow_14   -1.0
    f_17_14   flow_17   1.0
    f_17_14   cap_14_17  1.0
    f_14_19   flow_14   1.0
    f_14_19   flow_19   -1.0
    f_14_19   cap_14_19  1.0
    f_19_14   flow_14   -1.0
    f_19_14   flow_19   1.0
    f_19_14   cap_14_19  1.0
    f_15_18   flow_15   1.0
    f_15_18   flow_18   -1.0
    f_15_18   cap_15_18  1.0
    f_18_15   flow_15   -1.0
    f_18_15   flow_18   1.0
    f_18_15   cap_15_18  1.0
    f_15_19   flow_15   1.0
    f_15_19   flow_19   -1.0
    f_15_19   cap_15_19  1.0
    f_19_15   flow_15   -1.0
    f_19_15   flow_19   1.0
    f_19_15   cap_15_19  1.0
    f_18_19   flow_18   1.0
    f_18_19   flow_19   -1.0
    f_18_19   cap_18_19  1.0
    f_19_18   flow_18   -1.0
    f_19_18   flow_19   1.0
    f_19_18   cap_18_19  1.0
RHS
    RHS       flow_0    5
    RHS       flow_3    -1
    RHS       flow_4    -1
    RHS       flow_6    -1
    RHS       flow_11   -1
    RHS       flow_14   -1
BOUNDS
 BV BOUND     x_0_14
 BV BOUND     x_0_15
 BV BOUND     x_0_19
 BV BOUND     x_1_3
 BV BOUND     x_1_8
 BV BOUND     x_1_9
 BV BOUND     x_1_16
 BV BOUND     x_2_6
 BV BOUND     x_2_14
 BV BOUND     x_2_15
 BV BOUND     x_2_17
 BV BOUND     x_2_18
 BV BOUND     x_3_4
 BV BOUND     x_3_9
 BV BOUND     x_3_11
 BV BOUND     x_3_16
 BV BOUND     x_4_10
 BV BOUND     x_4_11
 BV BOUND     x_4_16
 BV BOUND     x_5_12
 BV BOUND     x_5_13
 BV BOUND     x_6_14
 BV BOUND     x_6_15
 BV BOUND     x_6_17
 BV BOUND     x_6_19
 BV BOUND     x_7_12
 BV BOUND     x_8_9
 BV BOUND     x_10_11
 BV BOUND     x_10_17
 BV BOUND     x_11_16
 BV BOUND     x_12_13
 BV BOUND     x_14_15
 BV BOUND     x_14_17
 BV BOUND     x_14_19
 BV BOUND     x_15_18
 BV BOUND     x_15_19
 BV BOUND     x_18_19
 UP BOUND     f_0_14    5
 UP BOUND     f_14_0    5
 UP BOUND     f_0_15    5
 UP BOUND     f_15_0    5
 UP BOUND     f_0_19    5
 UP BOUND     f_19_0    5
 UP BOUND     f_1_3     5
 UP BOUND     f_3_1     5
 UP BOUND     f_1_8     5
 UP BOUND     f_8_1     5
 UP BOUND     f_1_9     5
 UP BOUND     f_9_1     5
 UP BOUND     f_1_16    5
 UP BOUND     f_16_1    5
 UP BOUND     f_2_6     5
 UP BOUND     f_6_2     5
 UP BOUND     f_2_14    5
 UP BOUND     f_14_2    5
 UP BOUND     f_2_15    5
 UP BOUND     f_15_2    5
 UP BOUND     f_2_17    5
 UP BOUND     f_17_2    5
 UP BOUND     f_2_18    5
 UP BOUND     f_18_2    5
 UP BOUND     f_3_4     5
 UP BOUND     f_4_3     5
 UP BOUND     f_3_9     5
 UP BOUND     f_9_3     5
 UP BOUND     f_3_11    5
 UP BOUND     f_11_3    5
 UP BOUND     f_3_16    5
 UP BOUND     f_16_3    5
 UP BOUND     f_4_10    5
 UP BOUND     f_10_4    5
 UP BOUND     f_4_11    5
 UP BOUND     f_11_4    5
 UP BOUND     f_4_16    5
 UP BOUND     f_16_4    5
 UP BOUND     f_5_12    5
 UP BOUND     f_12_5    5
 UP BOUND     f_5_13    5
 UP BOUND     f_13_5    5
 UP BOUND     f_6_14    5
 UP BOUND     f_14_6    5
 UP BOUND     f_6_15    5
 UP BOUND     f_15_6    5
 UP BOUND     f_6_17    5
 UP BOUND     f_17_6    5
 UP BOUND     f_6_19    5
 UP BOUND     f_19_6    5
 UP BOUND     f_7_12    5
 UP BOUND     f_12_7    5
 UP BOUND     f_8_9     5
 UP BOUND     f_9_8     5
 UP BOUND     f_10_11   5
 UP BOUND     f_11_10   5
 UP BOUND     f_10_17   5
 UP BOUND     f_17_10   5
 UP BOUND     f_11_16   5
 UP BOUND     f_16_11   5
 UP BOUND     f_12_13   5
 UP BOUND     f_13_12   5
 UP BOUND     f_14_15   5
 UP BOUND     f_15_14   5
 UP BOUND     f_14_17   5
 UP BOUND     f_17_14   5
 UP BOUND     f_14_19   5
 UP BOUND     f_19_14   5
 UP BOUND     f_15_18   5
 UP BOUND     f_18_15   5
 UP BOUND     f_15_19   5
 UP BOUND     f_19_15   5
 UP BOUND     f_18_19   5
 UP BOUND     f_19_18   5
ENDATA
