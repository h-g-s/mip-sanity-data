NAME          orb01
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_0_5
 G  prec_0_6
 G  prec_0_7
 G  prec_0_8
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_1_5
 G  prec_1_6
 G  prec_1_7
 G  prec_1_8
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_2_5
 G  prec_2_6
 G  prec_2_7
 G  prec_2_8
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_3_5
 G  prec_3_6
 G  prec_3_7
 G  prec_3_8
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_4_5
 G  prec_4_6
 G  prec_4_7
 G  prec_4_8
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_5_5
 G  prec_5_6
 G  prec_5_7
 G  prec_5_8
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  prec_6_5
 G  prec_6_6
 G  prec_6_7
 G  prec_6_8
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_7_4
 G  prec_7_5
 G  prec_7_6
 G  prec_7_7
 G  prec_7_8
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_8_4
 G  prec_8_5
 G  prec_8_6
 G  prec_8_7
 G  prec_8_8
 G  prec_9_0
 G  prec_9_1
 G  prec_9_2
 G  prec_9_3
 G  prec_9_4
 G  prec_9_5
 G  prec_9_6
 G  prec_9_7
 G  prec_9_8
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  mksp_9
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_0_9_0
 G  disj2_0_9_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_1_9_0
 G  disj2_1_9_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_2_9_0
 G  disj2_2_9_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_3_9_0
 G  disj2_3_9_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_4_9_0
 G  disj2_4_9_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_5_9_0
 G  disj2_5_9_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_6_9_0
 G  disj2_6_9_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_7_9_0
 G  disj2_7_9_0
 G  disj1_8_9_0
 G  disj2_8_9_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_0_9_1
 G  disj2_0_9_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_1_9_1
 G  disj2_1_9_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_2_9_1
 G  disj2_2_9_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_3_9_1
 G  disj2_3_9_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_4_9_1
 G  disj2_4_9_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_5_9_1
 G  disj2_5_9_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_6_9_1
 G  disj2_6_9_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_7_9_1
 G  disj2_7_9_1
 G  disj1_8_9_1
 G  disj2_8_9_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_0_9_2
 G  disj2_0_9_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_1_9_2
 G  disj2_1_9_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_2_9_2
 G  disj2_2_9_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_3_9_2
 G  disj2_3_9_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_4_9_2
 G  disj2_4_9_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_5_9_2
 G  disj2_5_9_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_6_9_2
 G  disj2_6_9_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_7_9_2
 G  disj2_7_9_2
 G  disj1_8_9_2
 G  disj2_8_9_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_0_9_3
 G  disj2_0_9_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_1_9_3
 G  disj2_1_9_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_2_9_3
 G  disj2_2_9_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_3_9_3
 G  disj2_3_9_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_4_9_3
 G  disj2_4_9_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_5_9_3
 G  disj2_5_9_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_6_9_3
 G  disj2_6_9_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_7_9_3
 G  disj2_7_9_3
 G  disj1_8_9_3
 G  disj2_8_9_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_0_9_4
 G  disj2_0_9_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_1_9_4
 G  disj2_1_9_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_2_9_4
 G  disj2_2_9_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_3_9_4
 G  disj2_3_9_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_4_9_4
 G  disj2_4_9_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_5_9_4
 G  disj2_5_9_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_6_9_4
 G  disj2_6_9_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_7_9_4
 G  disj2_7_9_4
 G  disj1_8_9_4
 G  disj2_8_9_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_0_7_5
 G  disj2_0_7_5
 G  disj1_0_8_5
 G  disj2_0_8_5
 G  disj1_0_9_5
 G  disj2_0_9_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_1_7_5
 G  disj2_1_7_5
 G  disj1_1_8_5
 G  disj2_1_8_5
 G  disj1_1_9_5
 G  disj2_1_9_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_2_7_5
 G  disj2_2_7_5
 G  disj1_2_8_5
 G  disj2_2_8_5
 G  disj1_2_9_5
 G  disj2_2_9_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_3_7_5
 G  disj2_3_7_5
 G  disj1_3_8_5
 G  disj2_3_8_5
 G  disj1_3_9_5
 G  disj2_3_9_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_4_7_5
 G  disj2_4_7_5
 G  disj1_4_8_5
 G  disj2_4_8_5
 G  disj1_4_9_5
 G  disj2_4_9_5
 G  disj1_5_6_5
 G  disj2_5_6_5
 G  disj1_5_7_5
 G  disj2_5_7_5
 G  disj1_5_8_5
 G  disj2_5_8_5
 G  disj1_5_9_5
 G  disj2_5_9_5
 G  disj1_6_7_5
 G  disj2_6_7_5
 G  disj1_6_8_5
 G  disj2_6_8_5
 G  disj1_6_9_5
 G  disj2_6_9_5
 G  disj1_7_8_5
 G  disj2_7_8_5
 G  disj1_7_9_5
 G  disj2_7_9_5
 G  disj1_8_9_5
 G  disj2_8_9_5
 G  disj1_0_1_6
 G  disj2_0_1_6
 G  disj1_0_2_6
 G  disj2_0_2_6
 G  disj1_0_3_6
 G  disj2_0_3_6
 G  disj1_0_4_6
 G  disj2_0_4_6
 G  disj1_0_5_6
 G  disj2_0_5_6
 G  disj1_0_6_6
 G  disj2_0_6_6
 G  disj1_0_7_6
 G  disj2_0_7_6
 G  disj1_0_8_6
 G  disj2_0_8_6
 G  disj1_0_9_6
 G  disj2_0_9_6
 G  disj1_1_2_6
 G  disj2_1_2_6
 G  disj1_1_3_6
 G  disj2_1_3_6
 G  disj1_1_4_6
 G  disj2_1_4_6
 G  disj1_1_5_6
 G  disj2_1_5_6
 G  disj1_1_6_6
 G  disj2_1_6_6
 G  disj1_1_7_6
 G  disj2_1_7_6
 G  disj1_1_8_6
 G  disj2_1_8_6
 G  disj1_1_9_6
 G  disj2_1_9_6
 G  disj1_2_3_6
 G  disj2_2_3_6
 G  disj1_2_4_6
 G  disj2_2_4_6
 G  disj1_2_5_6
 G  disj2_2_5_6
 G  disj1_2_6_6
 G  disj2_2_6_6
 G  disj1_2_7_6
 G  disj2_2_7_6
 G  disj1_2_8_6
 G  disj2_2_8_6
 G  disj1_2_9_6
 G  disj2_2_9_6
 G  disj1_3_4_6
 G  disj2_3_4_6
 G  disj1_3_5_6
 G  disj2_3_5_6
 G  disj1_3_6_6
 G  disj2_3_6_6
 G  disj1_3_7_6
 G  disj2_3_7_6
 G  disj1_3_8_6
 G  disj2_3_8_6
 G  disj1_3_9_6
 G  disj2_3_9_6
 G  disj1_4_5_6
 G  disj2_4_5_6
 G  disj1_4_6_6
 G  disj2_4_6_6
 G  disj1_4_7_6
 G  disj2_4_7_6
 G  disj1_4_8_6
 G  disj2_4_8_6
 G  disj1_4_9_6
 G  disj2_4_9_6
 G  disj1_5_6_6
 G  disj2_5_6_6
 G  disj1_5_7_6
 G  disj2_5_7_6
 G  disj1_5_8_6
 G  disj2_5_8_6
 G  disj1_5_9_6
 G  disj2_5_9_6
 G  disj1_6_7_6
 G  disj2_6_7_6
 G  disj1_6_8_6
 G  disj2_6_8_6
 G  disj1_6_9_6
 G  disj2_6_9_6
 G  disj1_7_8_6
 G  disj2_7_8_6
 G  disj1_7_9_6
 G  disj2_7_9_6
 G  disj1_8_9_6
 G  disj2_8_9_6
 G  disj1_0_1_7
 G  disj2_0_1_7
 G  disj1_0_2_7
 G  disj2_0_2_7
 G  disj1_0_3_7
 G  disj2_0_3_7
 G  disj1_0_4_7
 G  disj2_0_4_7
 G  disj1_0_5_7
 G  disj2_0_5_7
 G  disj1_0_6_7
 G  disj2_0_6_7
 G  disj1_0_7_7
 G  disj2_0_7_7
 G  disj1_0_8_7
 G  disj2_0_8_7
 G  disj1_0_9_7
 G  disj2_0_9_7
 G  disj1_1_2_7
 G  disj2_1_2_7
 G  disj1_1_3_7
 G  disj2_1_3_7
 G  disj1_1_4_7
 G  disj2_1_4_7
 G  disj1_1_5_7
 G  disj2_1_5_7
 G  disj1_1_6_7
 G  disj2_1_6_7
 G  disj1_1_7_7
 G  disj2_1_7_7
 G  disj1_1_8_7
 G  disj2_1_8_7
 G  disj1_1_9_7
 G  disj2_1_9_7
 G  disj1_2_3_7
 G  disj2_2_3_7
 G  disj1_2_4_7
 G  disj2_2_4_7
 G  disj1_2_5_7
 G  disj2_2_5_7
 G  disj1_2_6_7
 G  disj2_2_6_7
 G  disj1_2_7_7
 G  disj2_2_7_7
 G  disj1_2_8_7
 G  disj2_2_8_7
 G  disj1_2_9_7
 G  disj2_2_9_7
 G  disj1_3_4_7
 G  disj2_3_4_7
 G  disj1_3_5_7
 G  disj2_3_5_7
 G  disj1_3_6_7
 G  disj2_3_6_7
 G  disj1_3_7_7
 G  disj2_3_7_7
 G  disj1_3_8_7
 G  disj2_3_8_7
 G  disj1_3_9_7
 G  disj2_3_9_7
 G  disj1_4_5_7
 G  disj2_4_5_7
 G  disj1_4_6_7
 G  disj2_4_6_7
 G  disj1_4_7_7
 G  disj2_4_7_7
 G  disj1_4_8_7
 G  disj2_4_8_7
 G  disj1_4_9_7
 G  disj2_4_9_7
 G  disj1_5_6_7
 G  disj2_5_6_7
 G  disj1_5_7_7
 G  disj2_5_7_7
 G  disj1_5_8_7
 G  disj2_5_8_7
 G  disj1_5_9_7
 G  disj2_5_9_7
 G  disj1_6_7_7
 G  disj2_6_7_7
 G  disj1_6_8_7
 G  disj2_6_8_7
 G  disj1_6_9_7
 G  disj2_6_9_7
 G  disj1_7_8_7
 G  disj2_7_8_7
 G  disj1_7_9_7
 G  disj2_7_9_7
 G  disj1_8_9_7
 G  disj2_8_9_7
 G  disj1_0_1_8
 G  disj2_0_1_8
 G  disj1_0_2_8
 G  disj2_0_2_8
 G  disj1_0_3_8
 G  disj2_0_3_8
 G  disj1_0_4_8
 G  disj2_0_4_8
 G  disj1_0_5_8
 G  disj2_0_5_8
 G  disj1_0_6_8
 G  disj2_0_6_8
 G  disj1_0_7_8
 G  disj2_0_7_8
 G  disj1_0_8_8
 G  disj2_0_8_8
 G  disj1_0_9_8
 G  disj2_0_9_8
 G  disj1_1_2_8
 G  disj2_1_2_8
 G  disj1_1_3_8
 G  disj2_1_3_8
 G  disj1_1_4_8
 G  disj2_1_4_8
 G  disj1_1_5_8
 G  disj2_1_5_8
 G  disj1_1_6_8
 G  disj2_1_6_8
 G  disj1_1_7_8
 G  disj2_1_7_8
 G  disj1_1_8_8
 G  disj2_1_8_8
 G  disj1_1_9_8
 G  disj2_1_9_8
 G  disj1_2_3_8
 G  disj2_2_3_8
 G  disj1_2_4_8
 G  disj2_2_4_8
 G  disj1_2_5_8
 G  disj2_2_5_8
 G  disj1_2_6_8
 G  disj2_2_6_8
 G  disj1_2_7_8
 G  disj2_2_7_8
 G  disj1_2_8_8
 G  disj2_2_8_8
 G  disj1_2_9_8
 G  disj2_2_9_8
 G  disj1_3_4_8
 G  disj2_3_4_8
 G  disj1_3_5_8
 G  disj2_3_5_8
 G  disj1_3_6_8
 G  disj2_3_6_8
 G  disj1_3_7_8
 G  disj2_3_7_8
 G  disj1_3_8_8
 G  disj2_3_8_8
 G  disj1_3_9_8
 G  disj2_3_9_8
 G  disj1_4_5_8
 G  disj2_4_5_8
 G  disj1_4_6_8
 G  disj2_4_6_8
 G  disj1_4_7_8
 G  disj2_4_7_8
 G  disj1_4_8_8
 G  disj2_4_8_8
 G  disj1_4_9_8
 G  disj2_4_9_8
 G  disj1_5_6_8
 G  disj2_5_6_8
 G  disj1_5_7_8
 G  disj2_5_7_8
 G  disj1_5_8_8
 G  disj2_5_8_8
 G  disj1_5_9_8
 G  disj2_5_9_8
 G  disj1_6_7_8
 G  disj2_6_7_8
 G  disj1_6_8_8
 G  disj2_6_8_8
 G  disj1_6_9_8
 G  disj2_6_9_8
 G  disj1_7_8_8
 G  disj2_7_8_8
 G  disj1_7_9_8
 G  disj2_7_9_8
 G  disj1_8_9_8
 G  disj2_8_9_8
 G  disj1_0_1_9
 G  disj2_0_1_9
 G  disj1_0_2_9
 G  disj2_0_2_9
 G  disj1_0_3_9
 G  disj2_0_3_9
 G  disj1_0_4_9
 G  disj2_0_4_9
 G  disj1_0_5_9
 G  disj2_0_5_9
 G  disj1_0_6_9
 G  disj2_0_6_9
 G  disj1_0_7_9
 G  disj2_0_7_9
 G  disj1_0_8_9
 G  disj2_0_8_9
 G  disj1_0_9_9
 G  disj2_0_9_9
 G  disj1_1_2_9
 G  disj2_1_2_9
 G  disj1_1_3_9
 G  disj2_1_3_9
 G  disj1_1_4_9
 G  disj2_1_4_9
 G  disj1_1_5_9
 G  disj2_1_5_9
 G  disj1_1_6_9
 G  disj2_1_6_9
 G  disj1_1_7_9
 G  disj2_1_7_9
 G  disj1_1_8_9
 G  disj2_1_8_9
 G  disj1_1_9_9
 G  disj2_1_9_9
 G  disj1_2_3_9
 G  disj2_2_3_9
 G  disj1_2_4_9
 G  disj2_2_4_9
 G  disj1_2_5_9
 G  disj2_2_5_9
 G  disj1_2_6_9
 G  disj2_2_6_9
 G  disj1_2_7_9
 G  disj2_2_7_9
 G  disj1_2_8_9
 G  disj2_2_8_9
 G  disj1_2_9_9
 G  disj2_2_9_9
 G  disj1_3_4_9
 G  disj2_3_4_9
 G  disj1_3_5_9
 G  disj2_3_5_9
 G  disj1_3_6_9
 G  disj2_3_6_9
 G  disj1_3_7_9
 G  disj2_3_7_9
 G  disj1_3_8_9
 G  disj2_3_8_9
 G  disj1_3_9_9
 G  disj2_3_9_9
 G  disj1_4_5_9
 G  disj2_4_5_9
 G  disj1_4_6_9
 G  disj2_4_6_9
 G  disj1_4_7_9
 G  disj2_4_7_9
 G  disj1_4_8_9
 G  disj2_4_8_9
 G  disj1_4_9_9
 G  disj2_4_9_9
 G  disj1_5_6_9
 G  disj2_5_6_9
 G  disj1_5_7_9
 G  disj2_5_7_9
 G  disj1_5_8_9
 G  disj2_5_8_9
 G  disj1_5_9_9
 G  disj2_5_9_9
 G  disj1_6_7_9
 G  disj2_6_7_9
 G  disj1_6_8_9
 G  disj2_6_8_9
 G  disj1_6_9_9
 G  disj2_6_9_9
 G  disj1_7_8_9
 G  disj2_7_8_9
 G  disj1_7_9_9
 G  disj2_7_9_9
 G  disj1_8_9_9
 G  disj2_8_9_9
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    C         mksp_9    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_0  -1.0
    x_0_0     disj2_0_1_0  1.0
    x_0_0     disj1_0_2_0  -1.0
    x_0_0     disj2_0_2_0  1.0
    x_0_0     disj1_0_3_0  -1.0
    x_0_0     disj2_0_3_0  1.0
    x_0_0     disj1_0_4_0  -1.0
    x_0_0     disj2_0_4_0  1.0
    x_0_0     disj1_0_5_0  -1.0
    x_0_0     disj2_0_5_0  1.0
    x_0_0     disj1_0_6_0  -1.0
    x_0_0     disj2_0_6_0  1.0
    x_0_0     disj1_0_7_0  -1.0
    x_0_0     disj2_0_7_0  1.0
    x_0_0     disj1_0_8_0  -1.0
    x_0_0     disj2_0_8_0  1.0
    x_0_0     disj1_0_9_0  -1.0
    x_0_0     disj2_0_9_0  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_1  -1.0
    x_0_1     disj2_0_1_1  1.0
    x_0_1     disj1_0_2_1  -1.0
    x_0_1     disj2_0_2_1  1.0
    x_0_1     disj1_0_3_1  -1.0
    x_0_1     disj2_0_3_1  1.0
    x_0_1     disj1_0_4_1  -1.0
    x_0_1     disj2_0_4_1  1.0
    x_0_1     disj1_0_5_1  -1.0
    x_0_1     disj2_0_5_1  1.0
    x_0_1     disj1_0_6_1  -1.0
    x_0_1     disj2_0_6_1  1.0
    x_0_1     disj1_0_7_1  -1.0
    x_0_1     disj2_0_7_1  1.0
    x_0_1     disj1_0_8_1  -1.0
    x_0_1     disj2_0_8_1  1.0
    x_0_1     disj1_0_9_1  -1.0
    x_0_1     disj2_0_9_1  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_2  -1.0
    x_0_2     disj2_0_1_2  1.0
    x_0_2     disj1_0_2_2  -1.0
    x_0_2     disj2_0_2_2  1.0
    x_0_2     disj1_0_3_2  -1.0
    x_0_2     disj2_0_3_2  1.0
    x_0_2     disj1_0_4_2  -1.0
    x_0_2     disj2_0_4_2  1.0
    x_0_2     disj1_0_5_2  -1.0
    x_0_2     disj2_0_5_2  1.0
    x_0_2     disj1_0_6_2  -1.0
    x_0_2     disj2_0_6_2  1.0
    x_0_2     disj1_0_7_2  -1.0
    x_0_2     disj2_0_7_2  1.0
    x_0_2     disj1_0_8_2  -1.0
    x_0_2     disj2_0_8_2  1.0
    x_0_2     disj1_0_9_2  -1.0
    x_0_2     disj2_0_9_2  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_3  -1.0
    x_0_3     disj2_0_1_3  1.0
    x_0_3     disj1_0_2_3  -1.0
    x_0_3     disj2_0_2_3  1.0
    x_0_3     disj1_0_3_3  -1.0
    x_0_3     disj2_0_3_3  1.0
    x_0_3     disj1_0_4_3  -1.0
    x_0_3     disj2_0_4_3  1.0
    x_0_3     disj1_0_5_3  -1.0
    x_0_3     disj2_0_5_3  1.0
    x_0_3     disj1_0_6_3  -1.0
    x_0_3     disj2_0_6_3  1.0
    x_0_3     disj1_0_7_3  -1.0
    x_0_3     disj2_0_7_3  1.0
    x_0_3     disj1_0_8_3  -1.0
    x_0_3     disj2_0_8_3  1.0
    x_0_3     disj1_0_9_3  -1.0
    x_0_3     disj2_0_9_3  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_4  -1.0
    x_0_4     disj2_0_1_4  1.0
    x_0_4     disj1_0_2_4  -1.0
    x_0_4     disj2_0_2_4  1.0
    x_0_4     disj1_0_3_4  -1.0
    x_0_4     disj2_0_3_4  1.0
    x_0_4     disj1_0_4_4  -1.0
    x_0_4     disj2_0_4_4  1.0
    x_0_4     disj1_0_5_4  -1.0
    x_0_4     disj2_0_5_4  1.0
    x_0_4     disj1_0_6_4  -1.0
    x_0_4     disj2_0_6_4  1.0
    x_0_4     disj1_0_7_4  -1.0
    x_0_4     disj2_0_7_4  1.0
    x_0_4     disj1_0_8_4  -1.0
    x_0_4     disj2_0_8_4  1.0
    x_0_4     disj1_0_9_4  -1.0
    x_0_4     disj2_0_9_4  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     prec_0_5  -1.0
    x_0_5     disj1_0_1_5  -1.0
    x_0_5     disj2_0_1_5  1.0
    x_0_5     disj1_0_2_5  -1.0
    x_0_5     disj2_0_2_5  1.0
    x_0_5     disj1_0_3_5  -1.0
    x_0_5     disj2_0_3_5  1.0
    x_0_5     disj1_0_4_5  -1.0
    x_0_5     disj2_0_4_5  1.0
    x_0_5     disj1_0_5_5  -1.0
    x_0_5     disj2_0_5_5  1.0
    x_0_5     disj1_0_6_5  -1.0
    x_0_5     disj2_0_6_5  1.0
    x_0_5     disj1_0_7_5  -1.0
    x_0_5     disj2_0_7_5  1.0
    x_0_5     disj1_0_8_5  -1.0
    x_0_5     disj2_0_8_5  1.0
    x_0_5     disj1_0_9_5  -1.0
    x_0_5     disj2_0_9_5  1.0
    x_0_6     prec_0_5  1.0
    x_0_6     prec_0_6  -1.0
    x_0_6     disj1_0_1_6  -1.0
    x_0_6     disj2_0_1_6  1.0
    x_0_6     disj1_0_2_6  -1.0
    x_0_6     disj2_0_2_6  1.0
    x_0_6     disj1_0_3_6  -1.0
    x_0_6     disj2_0_3_6  1.0
    x_0_6     disj1_0_4_6  -1.0
    x_0_6     disj2_0_4_6  1.0
    x_0_6     disj1_0_5_6  -1.0
    x_0_6     disj2_0_5_6  1.0
    x_0_6     disj1_0_6_6  -1.0
    x_0_6     disj2_0_6_6  1.0
    x_0_6     disj1_0_7_6  -1.0
    x_0_6     disj2_0_7_6  1.0
    x_0_6     disj1_0_8_6  -1.0
    x_0_6     disj2_0_8_6  1.0
    x_0_6     disj1_0_9_6  -1.0
    x_0_6     disj2_0_9_6  1.0
    x_0_7     prec_0_6  1.0
    x_0_7     prec_0_7  -1.0
    x_0_7     disj1_0_1_7  -1.0
    x_0_7     disj2_0_1_7  1.0
    x_0_7     disj1_0_2_7  -1.0
    x_0_7     disj2_0_2_7  1.0
    x_0_7     disj1_0_3_7  -1.0
    x_0_7     disj2_0_3_7  1.0
    x_0_7     disj1_0_4_7  -1.0
    x_0_7     disj2_0_4_7  1.0
    x_0_7     disj1_0_5_7  -1.0
    x_0_7     disj2_0_5_7  1.0
    x_0_7     disj1_0_6_7  -1.0
    x_0_7     disj2_0_6_7  1.0
    x_0_7     disj1_0_7_7  -1.0
    x_0_7     disj2_0_7_7  1.0
    x_0_7     disj1_0_8_7  -1.0
    x_0_7     disj2_0_8_7  1.0
    x_0_7     disj1_0_9_7  -1.0
    x_0_7     disj2_0_9_7  1.0
    x_0_8     prec_0_7  1.0
    x_0_8     prec_0_8  -1.0
    x_0_8     disj1_0_1_8  -1.0
    x_0_8     disj2_0_1_8  1.0
    x_0_8     disj1_0_2_8  -1.0
    x_0_8     disj2_0_2_8  1.0
    x_0_8     disj1_0_3_8  -1.0
    x_0_8     disj2_0_3_8  1.0
    x_0_8     disj1_0_4_8  -1.0
    x_0_8     disj2_0_4_8  1.0
    x_0_8     disj1_0_5_8  -1.0
    x_0_8     disj2_0_5_8  1.0
    x_0_8     disj1_0_6_8  -1.0
    x_0_8     disj2_0_6_8  1.0
    x_0_8     disj1_0_7_8  -1.0
    x_0_8     disj2_0_7_8  1.0
    x_0_8     disj1_0_8_8  -1.0
    x_0_8     disj2_0_8_8  1.0
    x_0_8     disj1_0_9_8  -1.0
    x_0_8     disj2_0_9_8  1.0
    x_0_9     prec_0_8  1.0
    x_0_9     mksp_0    -1.0
    x_0_9     disj1_0_1_9  -1.0
    x_0_9     disj2_0_1_9  1.0
    x_0_9     disj1_0_2_9  -1.0
    x_0_9     disj2_0_2_9  1.0
    x_0_9     disj1_0_3_9  -1.0
    x_0_9     disj2_0_3_9  1.0
    x_0_9     disj1_0_4_9  -1.0
    x_0_9     disj2_0_4_9  1.0
    x_0_9     disj1_0_5_9  -1.0
    x_0_9     disj2_0_5_9  1.0
    x_0_9     disj1_0_6_9  -1.0
    x_0_9     disj2_0_6_9  1.0
    x_0_9     disj1_0_7_9  -1.0
    x_0_9     disj2_0_7_9  1.0
    x_0_9     disj1_0_8_9  -1.0
    x_0_9     disj2_0_8_9  1.0
    x_0_9     disj1_0_9_9  -1.0
    x_0_9     disj2_0_9_9  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_0  1.0
    x_1_0     disj2_0_1_0  -1.0
    x_1_0     disj1_1_2_0  -1.0
    x_1_0     disj2_1_2_0  1.0
    x_1_0     disj1_1_3_0  -1.0
    x_1_0     disj2_1_3_0  1.0
    x_1_0     disj1_1_4_0  -1.0
    x_1_0     disj2_1_4_0  1.0
    x_1_0     disj1_1_5_0  -1.0
    x_1_0     disj2_1_5_0  1.0
    x_1_0     disj1_1_6_0  -1.0
    x_1_0     disj2_1_6_0  1.0
    x_1_0     disj1_1_7_0  -1.0
    x_1_0     disj2_1_7_0  1.0
    x_1_0     disj1_1_8_0  -1.0
    x_1_0     disj2_1_8_0  1.0
    x_1_0     disj1_1_9_0  -1.0
    x_1_0     disj2_1_9_0  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_3  1.0
    x_1_1     disj2_0_1_3  -1.0
    x_1_1     disj1_1_2_3  -1.0
    x_1_1     disj2_1_2_3  1.0
    x_1_1     disj1_1_3_3  -1.0
    x_1_1     disj2_1_3_3  1.0
    x_1_1     disj1_1_4_3  -1.0
    x_1_1     disj2_1_4_3  1.0
    x_1_1     disj1_1_5_3  -1.0
    x_1_1     disj2_1_5_3  1.0
    x_1_1     disj1_1_6_3  -1.0
    x_1_1     disj2_1_6_3  1.0
    x_1_1     disj1_1_7_3  -1.0
    x_1_1     disj2_1_7_3  1.0
    x_1_1     disj1_1_8_3  -1.0
    x_1_1     disj2_1_8_3  1.0
    x_1_1     disj1_1_9_3  -1.0
    x_1_1     disj2_1_9_3  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_4  1.0
    x_1_2     disj2_0_1_4  -1.0
    x_1_2     disj1_1_2_4  -1.0
    x_1_2     disj2_1_2_4  1.0
    x_1_2     disj1_1_3_4  -1.0
    x_1_2     disj2_1_3_4  1.0
    x_1_2     disj1_1_4_4  -1.0
    x_1_2     disj2_1_4_4  1.0
    x_1_2     disj1_1_5_4  -1.0
    x_1_2     disj2_1_5_4  1.0
    x_1_2     disj1_1_6_4  -1.0
    x_1_2     disj2_1_6_4  1.0
    x_1_2     disj1_1_7_4  -1.0
    x_1_2     disj2_1_7_4  1.0
    x_1_2     disj1_1_8_4  -1.0
    x_1_2     disj2_1_8_4  1.0
    x_1_2     disj1_1_9_4  -1.0
    x_1_2     disj2_1_9_4  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_2  1.0
    x_1_3     disj2_0_1_2  -1.0
    x_1_3     disj1_1_2_2  -1.0
    x_1_3     disj2_1_2_2  1.0
    x_1_3     disj1_1_3_2  -1.0
    x_1_3     disj2_1_3_2  1.0
    x_1_3     disj1_1_4_2  -1.0
    x_1_3     disj2_1_4_2  1.0
    x_1_3     disj1_1_5_2  -1.0
    x_1_3     disj2_1_5_2  1.0
    x_1_3     disj1_1_6_2  -1.0
    x_1_3     disj2_1_6_2  1.0
    x_1_3     disj1_1_7_2  -1.0
    x_1_3     disj2_1_7_2  1.0
    x_1_3     disj1_1_8_2  -1.0
    x_1_3     disj2_1_8_2  1.0
    x_1_3     disj1_1_9_2  -1.0
    x_1_3     disj2_1_9_2  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_1  1.0
    x_1_4     disj2_0_1_1  -1.0
    x_1_4     disj1_1_2_1  -1.0
    x_1_4     disj2_1_2_1  1.0
    x_1_4     disj1_1_3_1  -1.0
    x_1_4     disj2_1_3_1  1.0
    x_1_4     disj1_1_4_1  -1.0
    x_1_4     disj2_1_4_1  1.0
    x_1_4     disj1_1_5_1  -1.0
    x_1_4     disj2_1_5_1  1.0
    x_1_4     disj1_1_6_1  -1.0
    x_1_4     disj2_1_6_1  1.0
    x_1_4     disj1_1_7_1  -1.0
    x_1_4     disj2_1_7_1  1.0
    x_1_4     disj1_1_8_1  -1.0
    x_1_4     disj2_1_8_1  1.0
    x_1_4     disj1_1_9_1  -1.0
    x_1_4     disj2_1_9_1  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     prec_1_5  -1.0
    x_1_5     disj1_0_1_5  1.0
    x_1_5     disj2_0_1_5  -1.0
    x_1_5     disj1_1_2_5  -1.0
    x_1_5     disj2_1_2_5  1.0
    x_1_5     disj1_1_3_5  -1.0
    x_1_5     disj2_1_3_5  1.0
    x_1_5     disj1_1_4_5  -1.0
    x_1_5     disj2_1_4_5  1.0
    x_1_5     disj1_1_5_5  -1.0
    x_1_5     disj2_1_5_5  1.0
    x_1_5     disj1_1_6_5  -1.0
    x_1_5     disj2_1_6_5  1.0
    x_1_5     disj1_1_7_5  -1.0
    x_1_5     disj2_1_7_5  1.0
    x_1_5     disj1_1_8_5  -1.0
    x_1_5     disj2_1_8_5  1.0
    x_1_5     disj1_1_9_5  -1.0
    x_1_5     disj2_1_9_5  1.0
    x_1_6     prec_1_5  1.0
    x_1_6     prec_1_6  -1.0
    x_1_6     disj1_0_1_8  1.0
    x_1_6     disj2_0_1_8  -1.0
    x_1_6     disj1_1_2_8  -1.0
    x_1_6     disj2_1_2_8  1.0
    x_1_6     disj1_1_3_8  -1.0
    x_1_6     disj2_1_3_8  1.0
    x_1_6     disj1_1_4_8  -1.0
    x_1_6     disj2_1_4_8  1.0
    x_1_6     disj1_1_5_8  -1.0
    x_1_6     disj2_1_5_8  1.0
    x_1_6     disj1_1_6_8  -1.0
    x_1_6     disj2_1_6_8  1.0
    x_1_6     disj1_1_7_8  -1.0
    x_1_6     disj2_1_7_8  1.0
    x_1_6     disj1_1_8_8  -1.0
    x_1_6     disj2_1_8_8  1.0
    x_1_6     disj1_1_9_8  -1.0
    x_1_6     disj2_1_9_8  1.0
    x_1_7     prec_1_6  1.0
    x_1_7     prec_1_7  -1.0
    x_1_7     disj1_0_1_6  1.0
    x_1_7     disj2_0_1_6  -1.0
    x_1_7     disj1_1_2_6  -1.0
    x_1_7     disj2_1_2_6  1.0
    x_1_7     disj1_1_3_6  -1.0
    x_1_7     disj2_1_3_6  1.0
    x_1_7     disj1_1_4_6  -1.0
    x_1_7     disj2_1_4_6  1.0
    x_1_7     disj1_1_5_6  -1.0
    x_1_7     disj2_1_5_6  1.0
    x_1_7     disj1_1_6_6  -1.0
    x_1_7     disj2_1_6_6  1.0
    x_1_7     disj1_1_7_6  -1.0
    x_1_7     disj2_1_7_6  1.0
    x_1_7     disj1_1_8_6  -1.0
    x_1_7     disj2_1_8_6  1.0
    x_1_7     disj1_1_9_6  -1.0
    x_1_7     disj2_1_9_6  1.0
    x_1_8     prec_1_7  1.0
    x_1_8     prec_1_8  -1.0
    x_1_8     disj1_0_1_7  1.0
    x_1_8     disj2_0_1_7  -1.0
    x_1_8     disj1_1_2_7  -1.0
    x_1_8     disj2_1_2_7  1.0
    x_1_8     disj1_1_3_7  -1.0
    x_1_8     disj2_1_3_7  1.0
    x_1_8     disj1_1_4_7  -1.0
    x_1_8     disj2_1_4_7  1.0
    x_1_8     disj1_1_5_7  -1.0
    x_1_8     disj2_1_5_7  1.0
    x_1_8     disj1_1_6_7  -1.0
    x_1_8     disj2_1_6_7  1.0
    x_1_8     disj1_1_7_7  -1.0
    x_1_8     disj2_1_7_7  1.0
    x_1_8     disj1_1_8_7  -1.0
    x_1_8     disj2_1_8_7  1.0
    x_1_8     disj1_1_9_7  -1.0
    x_1_8     disj2_1_9_7  1.0
    x_1_9     prec_1_8  1.0
    x_1_9     mksp_1    -1.0
    x_1_9     disj1_0_1_9  1.0
    x_1_9     disj2_0_1_9  -1.0
    x_1_9     disj1_1_2_9  -1.0
    x_1_9     disj2_1_2_9  1.0
    x_1_9     disj1_1_3_9  -1.0
    x_1_9     disj2_1_3_9  1.0
    x_1_9     disj1_1_4_9  -1.0
    x_1_9     disj2_1_4_9  1.0
    x_1_9     disj1_1_5_9  -1.0
    x_1_9     disj2_1_5_9  1.0
    x_1_9     disj1_1_6_9  -1.0
    x_1_9     disj2_1_6_9  1.0
    x_1_9     disj1_1_7_9  -1.0
    x_1_9     disj2_1_7_9  1.0
    x_1_9     disj1_1_8_9  -1.0
    x_1_9     disj2_1_8_9  1.0
    x_1_9     disj1_1_9_9  -1.0
    x_1_9     disj2_1_9_9  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_0  1.0
    x_2_0     disj2_0_2_0  -1.0
    x_2_0     disj1_1_2_0  1.0
    x_2_0     disj2_1_2_0  -1.0
    x_2_0     disj1_2_3_0  -1.0
    x_2_0     disj2_2_3_0  1.0
    x_2_0     disj1_2_4_0  -1.0
    x_2_0     disj2_2_4_0  1.0
    x_2_0     disj1_2_5_0  -1.0
    x_2_0     disj2_2_5_0  1.0
    x_2_0     disj1_2_6_0  -1.0
    x_2_0     disj2_2_6_0  1.0
    x_2_0     disj1_2_7_0  -1.0
    x_2_0     disj2_2_7_0  1.0
    x_2_0     disj1_2_8_0  -1.0
    x_2_0     disj2_2_8_0  1.0
    x_2_0     disj1_2_9_0  -1.0
    x_2_0     disj2_2_9_0  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_1     disj1_2_6_3  -1.0
    x_2_1     disj2_2_6_3  1.0
    x_2_1     disj1_2_7_3  -1.0
    x_2_1     disj2_2_7_3  1.0
    x_2_1     disj1_2_8_3  -1.0
    x_2_1     disj2_2_8_3  1.0
    x_2_1     disj1_2_9_3  -1.0
    x_2_1     disj2_2_9_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_1  1.0
    x_2_2     disj2_0_2_1  -1.0
    x_2_2     disj1_1_2_1  1.0
    x_2_2     disj2_1_2_1  -1.0
    x_2_2     disj1_2_3_1  -1.0
    x_2_2     disj2_2_3_1  1.0
    x_2_2     disj1_2_4_1  -1.0
    x_2_2     disj2_2_4_1  1.0
    x_2_2     disj1_2_5_1  -1.0
    x_2_2     disj2_2_5_1  1.0
    x_2_2     disj1_2_6_1  -1.0
    x_2_2     disj2_2_6_1  1.0
    x_2_2     disj1_2_7_1  -1.0
    x_2_2     disj2_2_7_1  1.0
    x_2_2     disj1_2_8_1  -1.0
    x_2_2     disj2_2_8_1  1.0
    x_2_2     disj1_2_9_1  -1.0
    x_2_2     disj2_2_9_1  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_2  1.0
    x_2_3     disj2_0_2_2  -1.0
    x_2_3     disj1_1_2_2  1.0
    x_2_3     disj2_1_2_2  -1.0
    x_2_3     disj1_2_3_2  -1.0
    x_2_3     disj2_2_3_2  1.0
    x_2_3     disj1_2_4_2  -1.0
    x_2_3     disj2_2_4_2  1.0
    x_2_3     disj1_2_5_2  -1.0
    x_2_3     disj2_2_5_2  1.0
    x_2_3     disj1_2_6_2  -1.0
    x_2_3     disj2_2_6_2  1.0
    x_2_3     disj1_2_7_2  -1.0
    x_2_3     disj2_2_7_2  1.0
    x_2_3     disj1_2_8_2  -1.0
    x_2_3     disj2_2_8_2  1.0
    x_2_3     disj1_2_9_2  -1.0
    x_2_3     disj2_2_9_2  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_5  1.0
    x_2_4     disj2_0_2_5  -1.0
    x_2_4     disj1_1_2_5  1.0
    x_2_4     disj2_1_2_5  -1.0
    x_2_4     disj1_2_3_5  -1.0
    x_2_4     disj2_2_3_5  1.0
    x_2_4     disj1_2_4_5  -1.0
    x_2_4     disj2_2_4_5  1.0
    x_2_4     disj1_2_5_5  -1.0
    x_2_4     disj2_2_5_5  1.0
    x_2_4     disj1_2_6_5  -1.0
    x_2_4     disj2_2_6_5  1.0
    x_2_4     disj1_2_7_5  -1.0
    x_2_4     disj2_2_7_5  1.0
    x_2_4     disj1_2_8_5  -1.0
    x_2_4     disj2_2_8_5  1.0
    x_2_4     disj1_2_9_5  -1.0
    x_2_4     disj2_2_9_5  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     prec_2_5  -1.0
    x_2_5     disj1_0_2_4  1.0
    x_2_5     disj2_0_2_4  -1.0
    x_2_5     disj1_1_2_4  1.0
    x_2_5     disj2_1_2_4  -1.0
    x_2_5     disj1_2_3_4  -1.0
    x_2_5     disj2_2_3_4  1.0
    x_2_5     disj1_2_4_4  -1.0
    x_2_5     disj2_2_4_4  1.0
    x_2_5     disj1_2_5_4  -1.0
    x_2_5     disj2_2_5_4  1.0
    x_2_5     disj1_2_6_4  -1.0
    x_2_5     disj2_2_6_4  1.0
    x_2_5     disj1_2_7_4  -1.0
    x_2_5     disj2_2_7_4  1.0
    x_2_5     disj1_2_8_4  -1.0
    x_2_5     disj2_2_8_4  1.0
    x_2_5     disj1_2_9_4  -1.0
    x_2_5     disj2_2_9_4  1.0
    x_2_6     prec_2_5  1.0
    x_2_6     prec_2_6  -1.0
    x_2_6     disj1_0_2_6  1.0
    x_2_6     disj2_0_2_6  -1.0
    x_2_6     disj1_1_2_6  1.0
    x_2_6     disj2_1_2_6  -1.0
    x_2_6     disj1_2_3_6  -1.0
    x_2_6     disj2_2_3_6  1.0
    x_2_6     disj1_2_4_6  -1.0
    x_2_6     disj2_2_4_6  1.0
    x_2_6     disj1_2_5_6  -1.0
    x_2_6     disj2_2_5_6  1.0
    x_2_6     disj1_2_6_6  -1.0
    x_2_6     disj2_2_6_6  1.0
    x_2_6     disj1_2_7_6  -1.0
    x_2_6     disj2_2_7_6  1.0
    x_2_6     disj1_2_8_6  -1.0
    x_2_6     disj2_2_8_6  1.0
    x_2_6     disj1_2_9_6  -1.0
    x_2_6     disj2_2_9_6  1.0
    x_2_7     prec_2_6  1.0
    x_2_7     prec_2_7  -1.0
    x_2_7     disj1_0_2_7  1.0
    x_2_7     disj2_0_2_7  -1.0
    x_2_7     disj1_1_2_7  1.0
    x_2_7     disj2_1_2_7  -1.0
    x_2_7     disj1_2_3_7  -1.0
    x_2_7     disj2_2_3_7  1.0
    x_2_7     disj1_2_4_7  -1.0
    x_2_7     disj2_2_4_7  1.0
    x_2_7     disj1_2_5_7  -1.0
    x_2_7     disj2_2_5_7  1.0
    x_2_7     disj1_2_6_7  -1.0
    x_2_7     disj2_2_6_7  1.0
    x_2_7     disj1_2_7_7  -1.0
    x_2_7     disj2_2_7_7  1.0
    x_2_7     disj1_2_8_7  -1.0
    x_2_7     disj2_2_8_7  1.0
    x_2_7     disj1_2_9_7  -1.0
    x_2_7     disj2_2_9_7  1.0
    x_2_8     prec_2_7  1.0
    x_2_8     prec_2_8  -1.0
    x_2_8     disj1_0_2_9  1.0
    x_2_8     disj2_0_2_9  -1.0
    x_2_8     disj1_1_2_9  1.0
    x_2_8     disj2_1_2_9  -1.0
    x_2_8     disj1_2_3_9  -1.0
    x_2_8     disj2_2_3_9  1.0
    x_2_8     disj1_2_4_9  -1.0
    x_2_8     disj2_2_4_9  1.0
    x_2_8     disj1_2_5_9  -1.0
    x_2_8     disj2_2_5_9  1.0
    x_2_8     disj1_2_6_9  -1.0
    x_2_8     disj2_2_6_9  1.0
    x_2_8     disj1_2_7_9  -1.0
    x_2_8     disj2_2_7_9  1.0
    x_2_8     disj1_2_8_9  -1.0
    x_2_8     disj2_2_8_9  1.0
    x_2_8     disj1_2_9_9  -1.0
    x_2_8     disj2_2_9_9  1.0
    x_2_9     prec_2_8  1.0
    x_2_9     mksp_2    -1.0
    x_2_9     disj1_0_2_8  1.0
    x_2_9     disj2_0_2_8  -1.0
    x_2_9     disj1_1_2_8  1.0
    x_2_9     disj2_1_2_8  -1.0
    x_2_9     disj1_2_3_8  -1.0
    x_2_9     disj2_2_3_8  1.0
    x_2_9     disj1_2_4_8  -1.0
    x_2_9     disj2_2_4_8  1.0
    x_2_9     disj1_2_5_8  -1.0
    x_2_9     disj2_2_5_8  1.0
    x_2_9     disj1_2_6_8  -1.0
    x_2_9     disj2_2_6_8  1.0
    x_2_9     disj1_2_7_8  -1.0
    x_2_9     disj2_2_7_8  1.0
    x_2_9     disj1_2_8_8  -1.0
    x_2_9     disj2_2_8_8  1.0
    x_2_9     disj1_2_9_8  -1.0
    x_2_9     disj2_2_9_8  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_0  1.0
    x_3_0     disj2_0_3_0  -1.0
    x_3_0     disj1_1_3_0  1.0
    x_3_0     disj2_1_3_0  -1.0
    x_3_0     disj1_2_3_0  1.0
    x_3_0     disj2_2_3_0  -1.0
    x_3_0     disj1_3_4_0  -1.0
    x_3_0     disj2_3_4_0  1.0
    x_3_0     disj1_3_5_0  -1.0
    x_3_0     disj2_3_5_0  1.0
    x_3_0     disj1_3_6_0  -1.0
    x_3_0     disj2_3_6_0  1.0
    x_3_0     disj1_3_7_0  -1.0
    x_3_0     disj2_3_7_0  1.0
    x_3_0     disj1_3_8_0  -1.0
    x_3_0     disj2_3_8_0  1.0
    x_3_0     disj1_3_9_0  -1.0
    x_3_0     disj2_3_9_0  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_1  1.0
    x_3_1     disj2_0_3_1  -1.0
    x_3_1     disj1_1_3_1  1.0
    x_3_1     disj2_1_3_1  -1.0
    x_3_1     disj1_2_3_1  1.0
    x_3_1     disj2_2_3_1  -1.0
    x_3_1     disj1_3_4_1  -1.0
    x_3_1     disj2_3_4_1  1.0
    x_3_1     disj1_3_5_1  -1.0
    x_3_1     disj2_3_5_1  1.0
    x_3_1     disj1_3_6_1  -1.0
    x_3_1     disj2_3_6_1  1.0
    x_3_1     disj1_3_7_1  -1.0
    x_3_1     disj2_3_7_1  1.0
    x_3_1     disj1_3_8_1  -1.0
    x_3_1     disj2_3_8_1  1.0
    x_3_1     disj1_3_9_1  -1.0
    x_3_1     disj2_3_9_1  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_4  1.0
    x_3_2     disj2_0_3_4  -1.0
    x_3_2     disj1_1_3_4  1.0
    x_3_2     disj2_1_3_4  -1.0
    x_3_2     disj1_2_3_4  1.0
    x_3_2     disj2_2_3_4  -1.0
    x_3_2     disj1_3_4_4  -1.0
    x_3_2     disj2_3_4_4  1.0
    x_3_2     disj1_3_5_4  -1.0
    x_3_2     disj2_3_5_4  1.0
    x_3_2     disj1_3_6_4  -1.0
    x_3_2     disj2_3_6_4  1.0
    x_3_2     disj1_3_7_4  -1.0
    x_3_2     disj2_3_7_4  1.0
    x_3_2     disj1_3_8_4  -1.0
    x_3_2     disj2_3_8_4  1.0
    x_3_2     disj1_3_9_4  -1.0
    x_3_2     disj2_3_9_4  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_3  1.0
    x_3_3     disj2_0_3_3  -1.0
    x_3_3     disj1_1_3_3  1.0
    x_3_3     disj2_1_3_3  -1.0
    x_3_3     disj1_2_3_3  1.0
    x_3_3     disj2_2_3_3  -1.0
    x_3_3     disj1_3_4_3  -1.0
    x_3_3     disj2_3_4_3  1.0
    x_3_3     disj1_3_5_3  -1.0
    x_3_3     disj2_3_5_3  1.0
    x_3_3     disj1_3_6_3  -1.0
    x_3_3     disj2_3_6_3  1.0
    x_3_3     disj1_3_7_3  -1.0
    x_3_3     disj2_3_7_3  1.0
    x_3_3     disj1_3_8_3  -1.0
    x_3_3     disj2_3_8_3  1.0
    x_3_3     disj1_3_9_3  -1.0
    x_3_3     disj2_3_9_3  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_6  1.0
    x_3_4     disj2_0_3_6  -1.0
    x_3_4     disj1_1_3_6  1.0
    x_3_4     disj2_1_3_6  -1.0
    x_3_4     disj1_2_3_6  1.0
    x_3_4     disj2_2_3_6  -1.0
    x_3_4     disj1_3_4_6  -1.0
    x_3_4     disj2_3_4_6  1.0
    x_3_4     disj1_3_5_6  -1.0
    x_3_4     disj2_3_5_6  1.0
    x_3_4     disj1_3_6_6  -1.0
    x_3_4     disj2_3_6_6  1.0
    x_3_4     disj1_3_7_6  -1.0
    x_3_4     disj2_3_7_6  1.0
    x_3_4     disj1_3_8_6  -1.0
    x_3_4     disj2_3_8_6  1.0
    x_3_4     disj1_3_9_6  -1.0
    x_3_4     disj2_3_9_6  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     prec_3_5  -1.0
    x_3_5     disj1_0_3_5  1.0
    x_3_5     disj2_0_3_5  -1.0
    x_3_5     disj1_1_3_5  1.0
    x_3_5     disj2_1_3_5  -1.0
    x_3_5     disj1_2_3_5  1.0
    x_3_5     disj2_2_3_5  -1.0
    x_3_5     disj1_3_4_5  -1.0
    x_3_5     disj2_3_4_5  1.0
    x_3_5     disj1_3_5_5  -1.0
    x_3_5     disj2_3_5_5  1.0
    x_3_5     disj1_3_6_5  -1.0
    x_3_5     disj2_3_6_5  1.0
    x_3_5     disj1_3_7_5  -1.0
    x_3_5     disj2_3_7_5  1.0
    x_3_5     disj1_3_8_5  -1.0
    x_3_5     disj2_3_8_5  1.0
    x_3_5     disj1_3_9_5  -1.0
    x_3_5     disj2_3_9_5  1.0
    x_3_6     prec_3_5  1.0
    x_3_6     prec_3_6  -1.0
    x_3_6     disj1_0_3_2  1.0
    x_3_6     disj2_0_3_2  -1.0
    x_3_6     disj1_1_3_2  1.0
    x_3_6     disj2_1_3_2  -1.0
    x_3_6     disj1_2_3_2  1.0
    x_3_6     disj2_2_3_2  -1.0
    x_3_6     disj1_3_4_2  -1.0
    x_3_6     disj2_3_4_2  1.0
    x_3_6     disj1_3_5_2  -1.0
    x_3_6     disj2_3_5_2  1.0
    x_3_6     disj1_3_6_2  -1.0
    x_3_6     disj2_3_6_2  1.0
    x_3_6     disj1_3_7_2  -1.0
    x_3_6     disj2_3_7_2  1.0
    x_3_6     disj1_3_8_2  -1.0
    x_3_6     disj2_3_8_2  1.0
    x_3_6     disj1_3_9_2  -1.0
    x_3_6     disj2_3_9_2  1.0
    x_3_7     prec_3_6  1.0
    x_3_7     prec_3_7  -1.0
    x_3_7     disj1_0_3_9  1.0
    x_3_7     disj2_0_3_9  -1.0
    x_3_7     disj1_1_3_9  1.0
    x_3_7     disj2_1_3_9  -1.0
    x_3_7     disj1_2_3_9  1.0
    x_3_7     disj2_2_3_9  -1.0
    x_3_7     disj1_3_4_9  -1.0
    x_3_7     disj2_3_4_9  1.0
    x_3_7     disj1_3_5_9  -1.0
    x_3_7     disj2_3_5_9  1.0
    x_3_7     disj1_3_6_9  -1.0
    x_3_7     disj2_3_6_9  1.0
    x_3_7     disj1_3_7_9  -1.0
    x_3_7     disj2_3_7_9  1.0
    x_3_7     disj1_3_8_9  -1.0
    x_3_7     disj2_3_8_9  1.0
    x_3_7     disj1_3_9_9  -1.0
    x_3_7     disj2_3_9_9  1.0
    x_3_8     prec_3_7  1.0
    x_3_8     prec_3_8  -1.0
    x_3_8     disj1_0_3_7  1.0
    x_3_8     disj2_0_3_7  -1.0
    x_3_8     disj1_1_3_7  1.0
    x_3_8     disj2_1_3_7  -1.0
    x_3_8     disj1_2_3_7  1.0
    x_3_8     disj2_2_3_7  -1.0
    x_3_8     disj1_3_4_7  -1.0
    x_3_8     disj2_3_4_7  1.0
    x_3_8     disj1_3_5_7  -1.0
    x_3_8     disj2_3_5_7  1.0
    x_3_8     disj1_3_6_7  -1.0
    x_3_8     disj2_3_6_7  1.0
    x_3_8     disj1_3_7_7  -1.0
    x_3_8     disj2_3_7_7  1.0
    x_3_8     disj1_3_8_7  -1.0
    x_3_8     disj2_3_8_7  1.0
    x_3_8     disj1_3_9_7  -1.0
    x_3_8     disj2_3_9_7  1.0
    x_3_9     prec_3_8  1.0
    x_3_9     mksp_3    -1.0
    x_3_9     disj1_0_3_8  1.0
    x_3_9     disj2_0_3_8  -1.0
    x_3_9     disj1_1_3_8  1.0
    x_3_9     disj2_1_3_8  -1.0
    x_3_9     disj1_2_3_8  1.0
    x_3_9     disj2_2_3_8  -1.0
    x_3_9     disj1_3_4_8  -1.0
    x_3_9     disj2_3_4_8  1.0
    x_3_9     disj1_3_5_8  -1.0
    x_3_9     disj2_3_5_8  1.0
    x_3_9     disj1_3_6_8  -1.0
    x_3_9     disj2_3_6_8  1.0
    x_3_9     disj1_3_7_8  -1.0
    x_3_9     disj2_3_7_8  1.0
    x_3_9     disj1_3_8_8  -1.0
    x_3_9     disj2_3_8_8  1.0
    x_3_9     disj1_3_9_8  -1.0
    x_3_9     disj2_3_9_8  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_1  1.0
    x_4_0     disj2_0_4_1  -1.0
    x_4_0     disj1_1_4_1  1.0
    x_4_0     disj2_1_4_1  -1.0
    x_4_0     disj1_2_4_1  1.0
    x_4_0     disj2_2_4_1  -1.0
    x_4_0     disj1_3_4_1  1.0
    x_4_0     disj2_3_4_1  -1.0
    x_4_0     disj1_4_5_1  -1.0
    x_4_0     disj2_4_5_1  1.0
    x_4_0     disj1_4_6_1  -1.0
    x_4_0     disj2_4_6_1  1.0
    x_4_0     disj1_4_7_1  -1.0
    x_4_0     disj2_4_7_1  1.0
    x_4_0     disj1_4_8_1  -1.0
    x_4_0     disj2_4_8_1  1.0
    x_4_0     disj1_4_9_1  -1.0
    x_4_0     disj2_4_9_1  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_0  1.0
    x_4_1     disj2_0_4_0  -1.0
    x_4_1     disj1_1_4_0  1.0
    x_4_1     disj2_1_4_0  -1.0
    x_4_1     disj1_2_4_0  1.0
    x_4_1     disj2_2_4_0  -1.0
    x_4_1     disj1_3_4_0  1.0
    x_4_1     disj2_3_4_0  -1.0
    x_4_1     disj1_4_5_0  -1.0
    x_4_1     disj2_4_5_0  1.0
    x_4_1     disj1_4_6_0  -1.0
    x_4_1     disj2_4_6_0  1.0
    x_4_1     disj1_4_7_0  -1.0
    x_4_1     disj2_4_7_0  1.0
    x_4_1     disj1_4_8_0  -1.0
    x_4_1     disj2_4_8_0  1.0
    x_4_1     disj1_4_9_0  -1.0
    x_4_1     disj2_4_9_0  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_5  1.0
    x_4_2     disj2_0_4_5  -1.0
    x_4_2     disj1_1_4_5  1.0
    x_4_2     disj2_1_4_5  -1.0
    x_4_2     disj1_2_4_5  1.0
    x_4_2     disj2_2_4_5  -1.0
    x_4_2     disj1_3_4_5  1.0
    x_4_2     disj2_3_4_5  -1.0
    x_4_2     disj1_4_5_5  -1.0
    x_4_2     disj2_4_5_5  1.0
    x_4_2     disj1_4_6_5  -1.0
    x_4_2     disj2_4_6_5  1.0
    x_4_2     disj1_4_7_5  -1.0
    x_4_2     disj2_4_7_5  1.0
    x_4_2     disj1_4_8_5  -1.0
    x_4_2     disj2_4_8_5  1.0
    x_4_2     disj1_4_9_5  -1.0
    x_4_2     disj2_4_9_5  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_3  1.0
    x_4_3     disj2_0_4_3  -1.0
    x_4_3     disj1_1_4_3  1.0
    x_4_3     disj2_1_4_3  -1.0
    x_4_3     disj1_2_4_3  1.0
    x_4_3     disj2_2_4_3  -1.0
    x_4_3     disj1_3_4_3  1.0
    x_4_3     disj2_3_4_3  -1.0
    x_4_3     disj1_4_5_3  -1.0
    x_4_3     disj2_4_5_3  1.0
    x_4_3     disj1_4_6_3  -1.0
    x_4_3     disj2_4_6_3  1.0
    x_4_3     disj1_4_7_3  -1.0
    x_4_3     disj2_4_7_3  1.0
    x_4_3     disj1_4_8_3  -1.0
    x_4_3     disj2_4_8_3  1.0
    x_4_3     disj1_4_9_3  -1.0
    x_4_3     disj2_4_9_3  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_4  1.0
    x_4_4     disj2_0_4_4  -1.0
    x_4_4     disj1_1_4_4  1.0
    x_4_4     disj2_1_4_4  -1.0
    x_4_4     disj1_2_4_4  1.0
    x_4_4     disj2_2_4_4  -1.0
    x_4_4     disj1_3_4_4  1.0
    x_4_4     disj2_3_4_4  -1.0
    x_4_4     disj1_4_5_4  -1.0
    x_4_4     disj2_4_5_4  1.0
    x_4_4     disj1_4_6_4  -1.0
    x_4_4     disj2_4_6_4  1.0
    x_4_4     disj1_4_7_4  -1.0
    x_4_4     disj2_4_7_4  1.0
    x_4_4     disj1_4_8_4  -1.0
    x_4_4     disj2_4_8_4  1.0
    x_4_4     disj1_4_9_4  -1.0
    x_4_4     disj2_4_9_4  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     prec_4_5  -1.0
    x_4_5     disj1_0_4_7  1.0
    x_4_5     disj2_0_4_7  -1.0
    x_4_5     disj1_1_4_7  1.0
    x_4_5     disj2_1_4_7  -1.0
    x_4_5     disj1_2_4_7  1.0
    x_4_5     disj2_2_4_7  -1.0
    x_4_5     disj1_3_4_7  1.0
    x_4_5     disj2_3_4_7  -1.0
    x_4_5     disj1_4_5_7  -1.0
    x_4_5     disj2_4_5_7  1.0
    x_4_5     disj1_4_6_7  -1.0
    x_4_5     disj2_4_6_7  1.0
    x_4_5     disj1_4_7_7  -1.0
    x_4_5     disj2_4_7_7  1.0
    x_4_5     disj1_4_8_7  -1.0
    x_4_5     disj2_4_8_7  1.0
    x_4_5     disj1_4_9_7  -1.0
    x_4_5     disj2_4_9_7  1.0
    x_4_6     prec_4_5  1.0
    x_4_6     prec_4_6  -1.0
    x_4_6     disj1_0_4_2  1.0
    x_4_6     disj2_0_4_2  -1.0
    x_4_6     disj1_1_4_2  1.0
    x_4_6     disj2_1_4_2  -1.0
    x_4_6     disj1_2_4_2  1.0
    x_4_6     disj2_2_4_2  -1.0
    x_4_6     disj1_3_4_2  1.0
    x_4_6     disj2_3_4_2  -1.0
    x_4_6     disj1_4_5_2  -1.0
    x_4_6     disj2_4_5_2  1.0
    x_4_6     disj1_4_6_2  -1.0
    x_4_6     disj2_4_6_2  1.0
    x_4_6     disj1_4_7_2  -1.0
    x_4_6     disj2_4_7_2  1.0
    x_4_6     disj1_4_8_2  -1.0
    x_4_6     disj2_4_8_2  1.0
    x_4_6     disj1_4_9_2  -1.0
    x_4_6     disj2_4_9_2  1.0
    x_4_7     prec_4_6  1.0
    x_4_7     prec_4_7  -1.0
    x_4_7     disj1_0_4_8  1.0
    x_4_7     disj2_0_4_8  -1.0
    x_4_7     disj1_1_4_8  1.0
    x_4_7     disj2_1_4_8  -1.0
    x_4_7     disj1_2_4_8  1.0
    x_4_7     disj2_2_4_8  -1.0
    x_4_7     disj1_3_4_8  1.0
    x_4_7     disj2_3_4_8  -1.0
    x_4_7     disj1_4_5_8  -1.0
    x_4_7     disj2_4_5_8  1.0
    x_4_7     disj1_4_6_8  -1.0
    x_4_7     disj2_4_6_8  1.0
    x_4_7     disj1_4_7_8  -1.0
    x_4_7     disj2_4_7_8  1.0
    x_4_7     disj1_4_8_8  -1.0
    x_4_7     disj2_4_8_8  1.0
    x_4_7     disj1_4_9_8  -1.0
    x_4_7     disj2_4_9_8  1.0
    x_4_8     prec_4_7  1.0
    x_4_8     prec_4_8  -1.0
    x_4_8     disj1_0_4_9  1.0
    x_4_8     disj2_0_4_9  -1.0
    x_4_8     disj1_1_4_9  1.0
    x_4_8     disj2_1_4_9  -1.0
    x_4_8     disj1_2_4_9  1.0
    x_4_8     disj2_2_4_9  -1.0
    x_4_8     disj1_3_4_9  1.0
    x_4_8     disj2_3_4_9  -1.0
    x_4_8     disj1_4_5_9  -1.0
    x_4_8     disj2_4_5_9  1.0
    x_4_8     disj1_4_6_9  -1.0
    x_4_8     disj2_4_6_9  1.0
    x_4_8     disj1_4_7_9  -1.0
    x_4_8     disj2_4_7_9  1.0
    x_4_8     disj1_4_8_9  -1.0
    x_4_8     disj2_4_8_9  1.0
    x_4_8     disj1_4_9_9  -1.0
    x_4_8     disj2_4_9_9  1.0
    x_4_9     prec_4_8  1.0
    x_4_9     mksp_4    -1.0
    x_4_9     disj1_0_4_6  1.0
    x_4_9     disj2_0_4_6  -1.0
    x_4_9     disj1_1_4_6  1.0
    x_4_9     disj2_1_4_6  -1.0
    x_4_9     disj1_2_4_6  1.0
    x_4_9     disj2_2_4_6  -1.0
    x_4_9     disj1_3_4_6  1.0
    x_4_9     disj2_3_4_6  -1.0
    x_4_9     disj1_4_5_6  -1.0
    x_4_9     disj2_4_5_6  1.0
    x_4_9     disj1_4_6_6  -1.0
    x_4_9     disj2_4_6_6  1.0
    x_4_9     disj1_4_7_6  -1.0
    x_4_9     disj2_4_7_6  1.0
    x_4_9     disj1_4_8_6  -1.0
    x_4_9     disj2_4_8_6  1.0
    x_4_9     disj1_4_9_6  -1.0
    x_4_9     disj2_4_9_6  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_0  1.0
    x_5_0     disj2_0_5_0  -1.0
    x_5_0     disj1_1_5_0  1.0
    x_5_0     disj2_1_5_0  -1.0
    x_5_0     disj1_2_5_0  1.0
    x_5_0     disj2_2_5_0  -1.0
    x_5_0     disj1_3_5_0  1.0
    x_5_0     disj2_3_5_0  -1.0
    x_5_0     disj1_4_5_0  1.0
    x_5_0     disj2_4_5_0  -1.0
    x_5_0     disj1_5_6_0  -1.0
    x_5_0     disj2_5_6_0  1.0
    x_5_0     disj1_5_7_0  -1.0
    x_5_0     disj2_5_7_0  1.0
    x_5_0     disj1_5_8_0  -1.0
    x_5_0     disj2_5_8_0  1.0
    x_5_0     disj1_5_9_0  -1.0
    x_5_0     disj2_5_9_0  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_6  1.0
    x_5_1     disj2_0_5_6  -1.0
    x_5_1     disj1_1_5_6  1.0
    x_5_1     disj2_1_5_6  -1.0
    x_5_1     disj1_2_5_6  1.0
    x_5_1     disj2_2_5_6  -1.0
    x_5_1     disj1_3_5_6  1.0
    x_5_1     disj2_3_5_6  -1.0
    x_5_1     disj1_4_5_6  1.0
    x_5_1     disj2_4_5_6  -1.0
    x_5_1     disj1_5_6_6  -1.0
    x_5_1     disj2_5_6_6  1.0
    x_5_1     disj1_5_7_6  -1.0
    x_5_1     disj2_5_7_6  1.0
    x_5_1     disj1_5_8_6  -1.0
    x_5_1     disj2_5_8_6  1.0
    x_5_1     disj1_5_9_6  -1.0
    x_5_1     disj2_5_9_6  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_2  1.0
    x_5_2     disj2_0_5_2  -1.0
    x_5_2     disj1_1_5_2  1.0
    x_5_2     disj2_1_5_2  -1.0
    x_5_2     disj1_2_5_2  1.0
    x_5_2     disj2_2_5_2  -1.0
    x_5_2     disj1_3_5_2  1.0
    x_5_2     disj2_3_5_2  -1.0
    x_5_2     disj1_4_5_2  1.0
    x_5_2     disj2_4_5_2  -1.0
    x_5_2     disj1_5_6_2  -1.0
    x_5_2     disj2_5_6_2  1.0
    x_5_2     disj1_5_7_2  -1.0
    x_5_2     disj2_5_7_2  1.0
    x_5_2     disj1_5_8_2  -1.0
    x_5_2     disj2_5_8_2  1.0
    x_5_2     disj1_5_9_2  -1.0
    x_5_2     disj2_5_9_2  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_3  1.0
    x_5_3     disj2_0_5_3  -1.0
    x_5_3     disj1_1_5_3  1.0
    x_5_3     disj2_1_5_3  -1.0
    x_5_3     disj1_2_5_3  1.0
    x_5_3     disj2_2_5_3  -1.0
    x_5_3     disj1_3_5_3  1.0
    x_5_3     disj2_3_5_3  -1.0
    x_5_3     disj1_4_5_3  1.0
    x_5_3     disj2_4_5_3  -1.0
    x_5_3     disj1_5_6_3  -1.0
    x_5_3     disj2_5_6_3  1.0
    x_5_3     disj1_5_7_3  -1.0
    x_5_3     disj2_5_7_3  1.0
    x_5_3     disj1_5_8_3  -1.0
    x_5_3     disj2_5_8_3  1.0
    x_5_3     disj1_5_9_3  -1.0
    x_5_3     disj2_5_9_3  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_1  1.0
    x_5_4     disj2_0_5_1  -1.0
    x_5_4     disj1_1_5_1  1.0
    x_5_4     disj2_1_5_1  -1.0
    x_5_4     disj1_2_5_1  1.0
    x_5_4     disj2_2_5_1  -1.0
    x_5_4     disj1_3_5_1  1.0
    x_5_4     disj2_3_5_1  -1.0
    x_5_4     disj1_4_5_1  1.0
    x_5_4     disj2_4_5_1  -1.0
    x_5_4     disj1_5_6_1  -1.0
    x_5_4     disj2_5_6_1  1.0
    x_5_4     disj1_5_7_1  -1.0
    x_5_4     disj2_5_7_1  1.0
    x_5_4     disj1_5_8_1  -1.0
    x_5_4     disj2_5_8_1  1.0
    x_5_4     disj1_5_9_1  -1.0
    x_5_4     disj2_5_9_1  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     prec_5_5  -1.0
    x_5_5     disj1_0_5_8  1.0
    x_5_5     disj2_0_5_8  -1.0
    x_5_5     disj1_1_5_8  1.0
    x_5_5     disj2_1_5_8  -1.0
    x_5_5     disj1_2_5_8  1.0
    x_5_5     disj2_2_5_8  -1.0
    x_5_5     disj1_3_5_8  1.0
    x_5_5     disj2_3_5_8  -1.0
    x_5_5     disj1_4_5_8  1.0
    x_5_5     disj2_4_5_8  -1.0
    x_5_5     disj1_5_6_8  -1.0
    x_5_5     disj2_5_6_8  1.0
    x_5_5     disj1_5_7_8  -1.0
    x_5_5     disj2_5_7_8  1.0
    x_5_5     disj1_5_8_8  -1.0
    x_5_5     disj2_5_8_8  1.0
    x_5_5     disj1_5_9_8  -1.0
    x_5_5     disj2_5_9_8  1.0
    x_5_6     prec_5_5  1.0
    x_5_6     prec_5_6  -1.0
    x_5_6     disj1_0_5_4  1.0
    x_5_6     disj2_0_5_4  -1.0
    x_5_6     disj1_1_5_4  1.0
    x_5_6     disj2_1_5_4  -1.0
    x_5_6     disj1_2_5_4  1.0
    x_5_6     disj2_2_5_4  -1.0
    x_5_6     disj1_3_5_4  1.0
    x_5_6     disj2_3_5_4  -1.0
    x_5_6     disj1_4_5_4  1.0
    x_5_6     disj2_4_5_4  -1.0
    x_5_6     disj1_5_6_4  -1.0
    x_5_6     disj2_5_6_4  1.0
    x_5_6     disj1_5_7_4  -1.0
    x_5_6     disj2_5_7_4  1.0
    x_5_6     disj1_5_8_4  -1.0
    x_5_6     disj2_5_8_4  1.0
    x_5_6     disj1_5_9_4  -1.0
    x_5_6     disj2_5_9_4  1.0
    x_5_7     prec_5_6  1.0
    x_5_7     prec_5_7  -1.0
    x_5_7     disj1_0_5_9  1.0
    x_5_7     disj2_0_5_9  -1.0
    x_5_7     disj1_1_5_9  1.0
    x_5_7     disj2_1_5_9  -1.0
    x_5_7     disj1_2_5_9  1.0
    x_5_7     disj2_2_5_9  -1.0
    x_5_7     disj1_3_5_9  1.0
    x_5_7     disj2_3_5_9  -1.0
    x_5_7     disj1_4_5_9  1.0
    x_5_7     disj2_4_5_9  -1.0
    x_5_7     disj1_5_6_9  -1.0
    x_5_7     disj2_5_6_9  1.0
    x_5_7     disj1_5_7_9  -1.0
    x_5_7     disj2_5_7_9  1.0
    x_5_7     disj1_5_8_9  -1.0
    x_5_7     disj2_5_8_9  1.0
    x_5_7     disj1_5_9_9  -1.0
    x_5_7     disj2_5_9_9  1.0
    x_5_8     prec_5_7  1.0
    x_5_8     prec_5_8  -1.0
    x_5_8     disj1_0_5_7  1.0
    x_5_8     disj2_0_5_7  -1.0
    x_5_8     disj1_1_5_7  1.0
    x_5_8     disj2_1_5_7  -1.0
    x_5_8     disj1_2_5_7  1.0
    x_5_8     disj2_2_5_7  -1.0
    x_5_8     disj1_3_5_7  1.0
    x_5_8     disj2_3_5_7  -1.0
    x_5_8     disj1_4_5_7  1.0
    x_5_8     disj2_4_5_7  -1.0
    x_5_8     disj1_5_6_7  -1.0
    x_5_8     disj2_5_6_7  1.0
    x_5_8     disj1_5_7_7  -1.0
    x_5_8     disj2_5_7_7  1.0
    x_5_8     disj1_5_8_7  -1.0
    x_5_8     disj2_5_8_7  1.0
    x_5_8     disj1_5_9_7  -1.0
    x_5_8     disj2_5_9_7  1.0
    x_5_9     prec_5_8  1.0
    x_5_9     mksp_5    -1.0
    x_5_9     disj1_0_5_5  1.0
    x_5_9     disj2_0_5_5  -1.0
    x_5_9     disj1_1_5_5  1.0
    x_5_9     disj2_1_5_5  -1.0
    x_5_9     disj1_2_5_5  1.0
    x_5_9     disj2_2_5_5  -1.0
    x_5_9     disj1_3_5_5  1.0
    x_5_9     disj2_3_5_5  -1.0
    x_5_9     disj1_4_5_5  1.0
    x_5_9     disj2_4_5_5  -1.0
    x_5_9     disj1_5_6_5  -1.0
    x_5_9     disj2_5_6_5  1.0
    x_5_9     disj1_5_7_5  -1.0
    x_5_9     disj2_5_7_5  1.0
    x_5_9     disj1_5_8_5  -1.0
    x_5_9     disj2_5_8_5  1.0
    x_5_9     disj1_5_9_5  -1.0
    x_5_9     disj2_5_9_5  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_2  1.0
    x_6_0     disj2_0_6_2  -1.0
    x_6_0     disj1_1_6_2  1.0
    x_6_0     disj2_1_6_2  -1.0
    x_6_0     disj1_2_6_2  1.0
    x_6_0     disj2_2_6_2  -1.0
    x_6_0     disj1_3_6_2  1.0
    x_6_0     disj2_3_6_2  -1.0
    x_6_0     disj1_4_6_2  1.0
    x_6_0     disj2_4_6_2  -1.0
    x_6_0     disj1_5_6_2  1.0
    x_6_0     disj2_5_6_2  -1.0
    x_6_0     disj1_6_7_2  -1.0
    x_6_0     disj2_6_7_2  1.0
    x_6_0     disj1_6_8_2  -1.0
    x_6_0     disj2_6_8_2  1.0
    x_6_0     disj1_6_9_2  -1.0
    x_6_0     disj2_6_9_2  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_3  1.0
    x_6_1     disj2_0_6_3  -1.0
    x_6_1     disj1_1_6_3  1.0
    x_6_1     disj2_1_6_3  -1.0
    x_6_1     disj1_2_6_3  1.0
    x_6_1     disj2_2_6_3  -1.0
    x_6_1     disj1_3_6_3  1.0
    x_6_1     disj2_3_6_3  -1.0
    x_6_1     disj1_4_6_3  1.0
    x_6_1     disj2_4_6_3  -1.0
    x_6_1     disj1_5_6_3  1.0
    x_6_1     disj2_5_6_3  -1.0
    x_6_1     disj1_6_7_3  -1.0
    x_6_1     disj2_6_7_3  1.0
    x_6_1     disj1_6_8_3  -1.0
    x_6_1     disj2_6_8_3  1.0
    x_6_1     disj1_6_9_3  -1.0
    x_6_1     disj2_6_9_3  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_0  1.0
    x_6_2     disj2_0_6_0  -1.0
    x_6_2     disj1_1_6_0  1.0
    x_6_2     disj2_1_6_0  -1.0
    x_6_2     disj1_2_6_0  1.0
    x_6_2     disj2_2_6_0  -1.0
    x_6_2     disj1_3_6_0  1.0
    x_6_2     disj2_3_6_0  -1.0
    x_6_2     disj1_4_6_0  1.0
    x_6_2     disj2_4_6_0  -1.0
    x_6_2     disj1_5_6_0  1.0
    x_6_2     disj2_5_6_0  -1.0
    x_6_2     disj1_6_7_0  -1.0
    x_6_2     disj2_6_7_0  1.0
    x_6_2     disj1_6_8_0  -1.0
    x_6_2     disj2_6_8_0  1.0
    x_6_2     disj1_6_9_0  -1.0
    x_6_2     disj2_6_9_0  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_1  1.0
    x_6_3     disj2_0_6_1  -1.0
    x_6_3     disj1_1_6_1  1.0
    x_6_3     disj2_1_6_1  -1.0
    x_6_3     disj1_2_6_1  1.0
    x_6_3     disj2_2_6_1  -1.0
    x_6_3     disj1_3_6_1  1.0
    x_6_3     disj2_3_6_1  -1.0
    x_6_3     disj1_4_6_1  1.0
    x_6_3     disj2_4_6_1  -1.0
    x_6_3     disj1_5_6_1  1.0
    x_6_3     disj2_5_6_1  -1.0
    x_6_3     disj1_6_7_1  -1.0
    x_6_3     disj2_6_7_1  1.0
    x_6_3     disj1_6_8_1  -1.0
    x_6_3     disj2_6_8_1  1.0
    x_6_3     disj1_6_9_1  -1.0
    x_6_3     disj2_6_9_1  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_4  1.0
    x_6_4     disj2_0_6_4  -1.0
    x_6_4     disj1_1_6_4  1.0
    x_6_4     disj2_1_6_4  -1.0
    x_6_4     disj1_2_6_4  1.0
    x_6_4     disj2_2_6_4  -1.0
    x_6_4     disj1_3_6_4  1.0
    x_6_4     disj2_3_6_4  -1.0
    x_6_4     disj1_4_6_4  1.0
    x_6_4     disj2_4_6_4  -1.0
    x_6_4     disj1_5_6_4  1.0
    x_6_4     disj2_5_6_4  -1.0
    x_6_4     disj1_6_7_4  -1.0
    x_6_4     disj2_6_7_4  1.0
    x_6_4     disj1_6_8_4  -1.0
    x_6_4     disj2_6_8_4  1.0
    x_6_4     disj1_6_9_4  -1.0
    x_6_4     disj2_6_9_4  1.0
    x_6_5     prec_6_4  1.0
    x_6_5     prec_6_5  -1.0
    x_6_5     disj1_0_6_7  1.0
    x_6_5     disj2_0_6_7  -1.0
    x_6_5     disj1_1_6_7  1.0
    x_6_5     disj2_1_6_7  -1.0
    x_6_5     disj1_2_6_7  1.0
    x_6_5     disj2_2_6_7  -1.0
    x_6_5     disj1_3_6_7  1.0
    x_6_5     disj2_3_6_7  -1.0
    x_6_5     disj1_4_6_7  1.0
    x_6_5     disj2_4_6_7  -1.0
    x_6_5     disj1_5_6_7  1.0
    x_6_5     disj2_5_6_7  -1.0
    x_6_5     disj1_6_7_7  -1.0
    x_6_5     disj2_6_7_7  1.0
    x_6_5     disj1_6_8_7  -1.0
    x_6_5     disj2_6_8_7  1.0
    x_6_5     disj1_6_9_7  -1.0
    x_6_5     disj2_6_9_7  1.0
    x_6_6     prec_6_5  1.0
    x_6_6     prec_6_6  -1.0
    x_6_6     disj1_0_6_5  1.0
    x_6_6     disj2_0_6_5  -1.0
    x_6_6     disj1_1_6_5  1.0
    x_6_6     disj2_1_6_5  -1.0
    x_6_6     disj1_2_6_5  1.0
    x_6_6     disj2_2_6_5  -1.0
    x_6_6     disj1_3_6_5  1.0
    x_6_6     disj2_3_6_5  -1.0
    x_6_6     disj1_4_6_5  1.0
    x_6_6     disj2_4_6_5  -1.0
    x_6_6     disj1_5_6_5  1.0
    x_6_6     disj2_5_6_5  -1.0
    x_6_6     disj1_6_7_5  -1.0
    x_6_6     disj2_6_7_5  1.0
    x_6_6     disj1_6_8_5  -1.0
    x_6_6     disj2_6_8_5  1.0
    x_6_6     disj1_6_9_5  -1.0
    x_6_6     disj2_6_9_5  1.0
    x_6_7     prec_6_6  1.0
    x_6_7     prec_6_7  -1.0
    x_6_7     disj1_0_6_6  1.0
    x_6_7     disj2_0_6_6  -1.0
    x_6_7     disj1_1_6_6  1.0
    x_6_7     disj2_1_6_6  -1.0
    x_6_7     disj1_2_6_6  1.0
    x_6_7     disj2_2_6_6  -1.0
    x_6_7     disj1_3_6_6  1.0
    x_6_7     disj2_3_6_6  -1.0
    x_6_7     disj1_4_6_6  1.0
    x_6_7     disj2_4_6_6  -1.0
    x_6_7     disj1_5_6_6  1.0
    x_6_7     disj2_5_6_6  -1.0
    x_6_7     disj1_6_7_6  -1.0
    x_6_7     disj2_6_7_6  1.0
    x_6_7     disj1_6_8_6  -1.0
    x_6_7     disj2_6_8_6  1.0
    x_6_7     disj1_6_9_6  -1.0
    x_6_7     disj2_6_9_6  1.0
    x_6_8     prec_6_7  1.0
    x_6_8     prec_6_8  -1.0
    x_6_8     disj1_0_6_8  1.0
    x_6_8     disj2_0_6_8  -1.0
    x_6_8     disj1_1_6_8  1.0
    x_6_8     disj2_1_6_8  -1.0
    x_6_8     disj1_2_6_8  1.0
    x_6_8     disj2_2_6_8  -1.0
    x_6_8     disj1_3_6_8  1.0
    x_6_8     disj2_3_6_8  -1.0
    x_6_8     disj1_4_6_8  1.0
    x_6_8     disj2_4_6_8  -1.0
    x_6_8     disj1_5_6_8  1.0
    x_6_8     disj2_5_6_8  -1.0
    x_6_8     disj1_6_7_8  -1.0
    x_6_8     disj2_6_7_8  1.0
    x_6_8     disj1_6_8_8  -1.0
    x_6_8     disj2_6_8_8  1.0
    x_6_8     disj1_6_9_8  -1.0
    x_6_8     disj2_6_9_8  1.0
    x_6_9     prec_6_8  1.0
    x_6_9     mksp_6    -1.0
    x_6_9     disj1_0_6_9  1.0
    x_6_9     disj2_0_6_9  -1.0
    x_6_9     disj1_1_6_9  1.0
    x_6_9     disj2_1_6_9  -1.0
    x_6_9     disj1_2_6_9  1.0
    x_6_9     disj2_2_6_9  -1.0
    x_6_9     disj1_3_6_9  1.0
    x_6_9     disj2_3_6_9  -1.0
    x_6_9     disj1_4_6_9  1.0
    x_6_9     disj2_4_6_9  -1.0
    x_6_9     disj1_5_6_9  1.0
    x_6_9     disj2_5_6_9  -1.0
    x_6_9     disj1_6_7_9  -1.0
    x_6_9     disj2_6_7_9  1.0
    x_6_9     disj1_6_8_9  -1.0
    x_6_9     disj2_6_8_9  1.0
    x_6_9     disj1_6_9_9  -1.0
    x_6_9     disj2_6_9_9  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_2  1.0
    x_7_0     disj2_0_7_2  -1.0
    x_7_0     disj1_1_7_2  1.0
    x_7_0     disj2_1_7_2  -1.0
    x_7_0     disj1_2_7_2  1.0
    x_7_0     disj2_2_7_2  -1.0
    x_7_0     disj1_3_7_2  1.0
    x_7_0     disj2_3_7_2  -1.0
    x_7_0     disj1_4_7_2  1.0
    x_7_0     disj2_4_7_2  -1.0
    x_7_0     disj1_5_7_2  1.0
    x_7_0     disj2_5_7_2  -1.0
    x_7_0     disj1_6_7_2  1.0
    x_7_0     disj2_6_7_2  -1.0
    x_7_0     disj1_7_8_2  -1.0
    x_7_0     disj2_7_8_2  1.0
    x_7_0     disj1_7_9_2  -1.0
    x_7_0     disj2_7_9_2  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_0  1.0
    x_7_1     disj2_0_7_0  -1.0
    x_7_1     disj1_1_7_0  1.0
    x_7_1     disj2_1_7_0  -1.0
    x_7_1     disj1_2_7_0  1.0
    x_7_1     disj2_2_7_0  -1.0
    x_7_1     disj1_3_7_0  1.0
    x_7_1     disj2_3_7_0  -1.0
    x_7_1     disj1_4_7_0  1.0
    x_7_1     disj2_4_7_0  -1.0
    x_7_1     disj1_5_7_0  1.0
    x_7_1     disj2_5_7_0  -1.0
    x_7_1     disj1_6_7_0  1.0
    x_7_1     disj2_6_7_0  -1.0
    x_7_1     disj1_7_8_0  -1.0
    x_7_1     disj2_7_8_0  1.0
    x_7_1     disj1_7_9_0  -1.0
    x_7_1     disj2_7_9_0  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_3  1.0
    x_7_2     disj2_0_7_3  -1.0
    x_7_2     disj1_1_7_3  1.0
    x_7_2     disj2_1_7_3  -1.0
    x_7_2     disj1_2_7_3  1.0
    x_7_2     disj2_2_7_3  -1.0
    x_7_2     disj1_3_7_3  1.0
    x_7_2     disj2_3_7_3  -1.0
    x_7_2     disj1_4_7_3  1.0
    x_7_2     disj2_4_7_3  -1.0
    x_7_2     disj1_5_7_3  1.0
    x_7_2     disj2_5_7_3  -1.0
    x_7_2     disj1_6_7_3  1.0
    x_7_2     disj2_6_7_3  -1.0
    x_7_2     disj1_7_8_3  -1.0
    x_7_2     disj2_7_8_3  1.0
    x_7_2     disj1_7_9_3  -1.0
    x_7_2     disj2_7_9_3  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_4  1.0
    x_7_3     disj2_0_7_4  -1.0
    x_7_3     disj1_1_7_4  1.0
    x_7_3     disj2_1_7_4  -1.0
    x_7_3     disj1_2_7_4  1.0
    x_7_3     disj2_2_7_4  -1.0
    x_7_3     disj1_3_7_4  1.0
    x_7_3     disj2_3_7_4  -1.0
    x_7_3     disj1_4_7_4  1.0
    x_7_3     disj2_4_7_4  -1.0
    x_7_3     disj1_5_7_4  1.0
    x_7_3     disj2_5_7_4  -1.0
    x_7_3     disj1_6_7_4  1.0
    x_7_3     disj2_6_7_4  -1.0
    x_7_3     disj1_7_8_4  -1.0
    x_7_3     disj2_7_8_4  1.0
    x_7_3     disj1_7_9_4  -1.0
    x_7_3     disj2_7_9_4  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     prec_7_4  -1.0
    x_7_4     disj1_0_7_1  1.0
    x_7_4     disj2_0_7_1  -1.0
    x_7_4     disj1_1_7_1  1.0
    x_7_4     disj2_1_7_1  -1.0
    x_7_4     disj1_2_7_1  1.0
    x_7_4     disj2_2_7_1  -1.0
    x_7_4     disj1_3_7_1  1.0
    x_7_4     disj2_3_7_1  -1.0
    x_7_4     disj1_4_7_1  1.0
    x_7_4     disj2_4_7_1  -1.0
    x_7_4     disj1_5_7_1  1.0
    x_7_4     disj2_5_7_1  -1.0
    x_7_4     disj1_6_7_1  1.0
    x_7_4     disj2_6_7_1  -1.0
    x_7_4     disj1_7_8_1  -1.0
    x_7_4     disj2_7_8_1  1.0
    x_7_4     disj1_7_9_1  -1.0
    x_7_4     disj2_7_9_1  1.0
    x_7_5     prec_7_4  1.0
    x_7_5     prec_7_5  -1.0
    x_7_5     disj1_0_7_5  1.0
    x_7_5     disj2_0_7_5  -1.0
    x_7_5     disj1_1_7_5  1.0
    x_7_5     disj2_1_7_5  -1.0
    x_7_5     disj1_2_7_5  1.0
    x_7_5     disj2_2_7_5  -1.0
    x_7_5     disj1_3_7_5  1.0
    x_7_5     disj2_3_7_5  -1.0
    x_7_5     disj1_4_7_5  1.0
    x_7_5     disj2_4_7_5  -1.0
    x_7_5     disj1_5_7_5  1.0
    x_7_5     disj2_5_7_5  -1.0
    x_7_5     disj1_6_7_5  1.0
    x_7_5     disj2_6_7_5  -1.0
    x_7_5     disj1_7_8_5  -1.0
    x_7_5     disj2_7_8_5  1.0
    x_7_5     disj1_7_9_5  -1.0
    x_7_5     disj2_7_9_5  1.0
    x_7_6     prec_7_5  1.0
    x_7_6     prec_7_6  -1.0
    x_7_6     disj1_0_7_9  1.0
    x_7_6     disj2_0_7_9  -1.0
    x_7_6     disj1_1_7_9  1.0
    x_7_6     disj2_1_7_9  -1.0
    x_7_6     disj1_2_7_9  1.0
    x_7_6     disj2_2_7_9  -1.0
    x_7_6     disj1_3_7_9  1.0
    x_7_6     disj2_3_7_9  -1.0
    x_7_6     disj1_4_7_9  1.0
    x_7_6     disj2_4_7_9  -1.0
    x_7_6     disj1_5_7_9  1.0
    x_7_6     disj2_5_7_9  -1.0
    x_7_6     disj1_6_7_9  1.0
    x_7_6     disj2_6_7_9  -1.0
    x_7_6     disj1_7_8_9  -1.0
    x_7_6     disj2_7_8_9  1.0
    x_7_6     disj1_7_9_9  -1.0
    x_7_6     disj2_7_9_9  1.0
    x_7_7     prec_7_6  1.0
    x_7_7     prec_7_7  -1.0
    x_7_7     disj1_0_7_6  1.0
    x_7_7     disj2_0_7_6  -1.0
    x_7_7     disj1_1_7_6  1.0
    x_7_7     disj2_1_7_6  -1.0
    x_7_7     disj1_2_7_6  1.0
    x_7_7     disj2_2_7_6  -1.0
    x_7_7     disj1_3_7_6  1.0
    x_7_7     disj2_3_7_6  -1.0
    x_7_7     disj1_4_7_6  1.0
    x_7_7     disj2_4_7_6  -1.0
    x_7_7     disj1_5_7_6  1.0
    x_7_7     disj2_5_7_6  -1.0
    x_7_7     disj1_6_7_6  1.0
    x_7_7     disj2_6_7_6  -1.0
    x_7_7     disj1_7_8_6  -1.0
    x_7_7     disj2_7_8_6  1.0
    x_7_7     disj1_7_9_6  -1.0
    x_7_7     disj2_7_9_6  1.0
    x_7_8     prec_7_7  1.0
    x_7_8     prec_7_8  -1.0
    x_7_8     disj1_0_7_7  1.0
    x_7_8     disj2_0_7_7  -1.0
    x_7_8     disj1_1_7_7  1.0
    x_7_8     disj2_1_7_7  -1.0
    x_7_8     disj1_2_7_7  1.0
    x_7_8     disj2_2_7_7  -1.0
    x_7_8     disj1_3_7_7  1.0
    x_7_8     disj2_3_7_7  -1.0
    x_7_8     disj1_4_7_7  1.0
    x_7_8     disj2_4_7_7  -1.0
    x_7_8     disj1_5_7_7  1.0
    x_7_8     disj2_5_7_7  -1.0
    x_7_8     disj1_6_7_7  1.0
    x_7_8     disj2_6_7_7  -1.0
    x_7_8     disj1_7_8_7  -1.0
    x_7_8     disj2_7_8_7  1.0
    x_7_8     disj1_7_9_7  -1.0
    x_7_8     disj2_7_9_7  1.0
    x_7_9     prec_7_8  1.0
    x_7_9     mksp_7    -1.0
    x_7_9     disj1_0_7_8  1.0
    x_7_9     disj2_0_7_8  -1.0
    x_7_9     disj1_1_7_8  1.0
    x_7_9     disj2_1_7_8  -1.0
    x_7_9     disj1_2_7_8  1.0
    x_7_9     disj2_2_7_8  -1.0
    x_7_9     disj1_3_7_8  1.0
    x_7_9     disj2_3_7_8  -1.0
    x_7_9     disj1_4_7_8  1.0
    x_7_9     disj2_4_7_8  -1.0
    x_7_9     disj1_5_7_8  1.0
    x_7_9     disj2_5_7_8  -1.0
    x_7_9     disj1_6_7_8  1.0
    x_7_9     disj2_6_7_8  -1.0
    x_7_9     disj1_7_8_8  -1.0
    x_7_9     disj2_7_8_8  1.0
    x_7_9     disj1_7_9_8  -1.0
    x_7_9     disj2_7_9_8  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_2  1.0
    x_8_0     disj2_0_8_2  -1.0
    x_8_0     disj1_1_8_2  1.0
    x_8_0     disj2_1_8_2  -1.0
    x_8_0     disj1_2_8_2  1.0
    x_8_0     disj2_2_8_2  -1.0
    x_8_0     disj1_3_8_2  1.0
    x_8_0     disj2_3_8_2  -1.0
    x_8_0     disj1_4_8_2  1.0
    x_8_0     disj2_4_8_2  -1.0
    x_8_0     disj1_5_8_2  1.0
    x_8_0     disj2_5_8_2  -1.0
    x_8_0     disj1_6_8_2  1.0
    x_8_0     disj2_6_8_2  -1.0
    x_8_0     disj1_7_8_2  1.0
    x_8_0     disj2_7_8_2  -1.0
    x_8_0     disj1_8_9_2  -1.0
    x_8_0     disj2_8_9_2  1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_1  1.0
    x_8_1     disj2_0_8_1  -1.0
    x_8_1     disj1_1_8_1  1.0
    x_8_1     disj2_1_8_1  -1.0
    x_8_1     disj1_2_8_1  1.0
    x_8_1     disj2_2_8_1  -1.0
    x_8_1     disj1_3_8_1  1.0
    x_8_1     disj2_3_8_1  -1.0
    x_8_1     disj1_4_8_1  1.0
    x_8_1     disj2_4_8_1  -1.0
    x_8_1     disj1_5_8_1  1.0
    x_8_1     disj2_5_8_1  -1.0
    x_8_1     disj1_6_8_1  1.0
    x_8_1     disj2_6_8_1  -1.0
    x_8_1     disj1_7_8_1  1.0
    x_8_1     disj2_7_8_1  -1.0
    x_8_1     disj1_8_9_1  -1.0
    x_8_1     disj2_8_9_1  1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_4  1.0
    x_8_2     disj2_0_8_4  -1.0
    x_8_2     disj1_1_8_4  1.0
    x_8_2     disj2_1_8_4  -1.0
    x_8_2     disj1_2_8_4  1.0
    x_8_2     disj2_2_8_4  -1.0
    x_8_2     disj1_3_8_4  1.0
    x_8_2     disj2_3_8_4  -1.0
    x_8_2     disj1_4_8_4  1.0
    x_8_2     disj2_4_8_4  -1.0
    x_8_2     disj1_5_8_4  1.0
    x_8_2     disj2_5_8_4  -1.0
    x_8_2     disj1_6_8_4  1.0
    x_8_2     disj2_6_8_4  -1.0
    x_8_2     disj1_7_8_4  1.0
    x_8_2     disj2_7_8_4  -1.0
    x_8_2     disj1_8_9_4  -1.0
    x_8_2     disj2_8_9_4  1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_0  1.0
    x_8_3     disj2_0_8_0  -1.0
    x_8_3     disj1_1_8_0  1.0
    x_8_3     disj2_1_8_0  -1.0
    x_8_3     disj1_2_8_0  1.0
    x_8_3     disj2_2_8_0  -1.0
    x_8_3     disj1_3_8_0  1.0
    x_8_3     disj2_3_8_0  -1.0
    x_8_3     disj1_4_8_0  1.0
    x_8_3     disj2_4_8_0  -1.0
    x_8_3     disj1_5_8_0  1.0
    x_8_3     disj2_5_8_0  -1.0
    x_8_3     disj1_6_8_0  1.0
    x_8_3     disj2_6_8_0  -1.0
    x_8_3     disj1_7_8_0  1.0
    x_8_3     disj2_7_8_0  -1.0
    x_8_3     disj1_8_9_0  -1.0
    x_8_3     disj2_8_9_0  1.0
    x_8_4     prec_8_3  1.0
    x_8_4     prec_8_4  -1.0
    x_8_4     disj1_0_8_7  1.0
    x_8_4     disj2_0_8_7  -1.0
    x_8_4     disj1_1_8_7  1.0
    x_8_4     disj2_1_8_7  -1.0
    x_8_4     disj1_2_8_7  1.0
    x_8_4     disj2_2_8_7  -1.0
    x_8_4     disj1_3_8_7  1.0
    x_8_4     disj2_3_8_7  -1.0
    x_8_4     disj1_4_8_7  1.0
    x_8_4     disj2_4_8_7  -1.0
    x_8_4     disj1_5_8_7  1.0
    x_8_4     disj2_5_8_7  -1.0
    x_8_4     disj1_6_8_7  1.0
    x_8_4     disj2_6_8_7  -1.0
    x_8_4     disj1_7_8_7  1.0
    x_8_4     disj2_7_8_7  -1.0
    x_8_4     disj1_8_9_7  -1.0
    x_8_4     disj2_8_9_7  1.0
    x_8_5     prec_8_4  1.0
    x_8_5     prec_8_5  -1.0
    x_8_5     disj1_0_8_5  1.0
    x_8_5     disj2_0_8_5  -1.0
    x_8_5     disj1_1_8_5  1.0
    x_8_5     disj2_1_8_5  -1.0
    x_8_5     disj1_2_8_5  1.0
    x_8_5     disj2_2_8_5  -1.0
    x_8_5     disj1_3_8_5  1.0
    x_8_5     disj2_3_8_5  -1.0
    x_8_5     disj1_4_8_5  1.0
    x_8_5     disj2_4_8_5  -1.0
    x_8_5     disj1_5_8_5  1.0
    x_8_5     disj2_5_8_5  -1.0
    x_8_5     disj1_6_8_5  1.0
    x_8_5     disj2_6_8_5  -1.0
    x_8_5     disj1_7_8_5  1.0
    x_8_5     disj2_7_8_5  -1.0
    x_8_5     disj1_8_9_5  -1.0
    x_8_5     disj2_8_9_5  1.0
    x_8_6     prec_8_5  1.0
    x_8_6     prec_8_6  -1.0
    x_8_6     disj1_0_8_3  1.0
    x_8_6     disj2_0_8_3  -1.0
    x_8_6     disj1_1_8_3  1.0
    x_8_6     disj2_1_8_3  -1.0
    x_8_6     disj1_2_8_3  1.0
    x_8_6     disj2_2_8_3  -1.0
    x_8_6     disj1_3_8_3  1.0
    x_8_6     disj2_3_8_3  -1.0
    x_8_6     disj1_4_8_3  1.0
    x_8_6     disj2_4_8_3  -1.0
    x_8_6     disj1_5_8_3  1.0
    x_8_6     disj2_5_8_3  -1.0
    x_8_6     disj1_6_8_3  1.0
    x_8_6     disj2_6_8_3  -1.0
    x_8_6     disj1_7_8_3  1.0
    x_8_6     disj2_7_8_3  -1.0
    x_8_6     disj1_8_9_3  -1.0
    x_8_6     disj2_8_9_3  1.0
    x_8_7     prec_8_6  1.0
    x_8_7     prec_8_7  -1.0
    x_8_7     disj1_0_8_9  1.0
    x_8_7     disj2_0_8_9  -1.0
    x_8_7     disj1_1_8_9  1.0
    x_8_7     disj2_1_8_9  -1.0
    x_8_7     disj1_2_8_9  1.0
    x_8_7     disj2_2_8_9  -1.0
    x_8_7     disj1_3_8_9  1.0
    x_8_7     disj2_3_8_9  -1.0
    x_8_7     disj1_4_8_9  1.0
    x_8_7     disj2_4_8_9  -1.0
    x_8_7     disj1_5_8_9  1.0
    x_8_7     disj2_5_8_9  -1.0
    x_8_7     disj1_6_8_9  1.0
    x_8_7     disj2_6_8_9  -1.0
    x_8_7     disj1_7_8_9  1.0
    x_8_7     disj2_7_8_9  -1.0
    x_8_7     disj1_8_9_9  -1.0
    x_8_7     disj2_8_9_9  1.0
    x_8_8     prec_8_7  1.0
    x_8_8     prec_8_8  -1.0
    x_8_8     disj1_0_8_6  1.0
    x_8_8     disj2_0_8_6  -1.0
    x_8_8     disj1_1_8_6  1.0
    x_8_8     disj2_1_8_6  -1.0
    x_8_8     disj1_2_8_6  1.0
    x_8_8     disj2_2_8_6  -1.0
    x_8_8     disj1_3_8_6  1.0
    x_8_8     disj2_3_8_6  -1.0
    x_8_8     disj1_4_8_6  1.0
    x_8_8     disj2_4_8_6  -1.0
    x_8_8     disj1_5_8_6  1.0
    x_8_8     disj2_5_8_6  -1.0
    x_8_8     disj1_6_8_6  1.0
    x_8_8     disj2_6_8_6  -1.0
    x_8_8     disj1_7_8_6  1.0
    x_8_8     disj2_7_8_6  -1.0
    x_8_8     disj1_8_9_6  -1.0
    x_8_8     disj2_8_9_6  1.0
    x_8_9     prec_8_8  1.0
    x_8_9     mksp_8    -1.0
    x_8_9     disj1_0_8_8  1.0
    x_8_9     disj2_0_8_8  -1.0
    x_8_9     disj1_1_8_8  1.0
    x_8_9     disj2_1_8_8  -1.0
    x_8_9     disj1_2_8_8  1.0
    x_8_9     disj2_2_8_8  -1.0
    x_8_9     disj1_3_8_8  1.0
    x_8_9     disj2_3_8_8  -1.0
    x_8_9     disj1_4_8_8  1.0
    x_8_9     disj2_4_8_8  -1.0
    x_8_9     disj1_5_8_8  1.0
    x_8_9     disj2_5_8_8  -1.0
    x_8_9     disj1_6_8_8  1.0
    x_8_9     disj2_6_8_8  -1.0
    x_8_9     disj1_7_8_8  1.0
    x_8_9     disj2_7_8_8  -1.0
    x_8_9     disj1_8_9_8  -1.0
    x_8_9     disj2_8_9_8  1.0
    x_9_0     prec_9_0  -1.0
    x_9_0     disj1_0_9_2  1.0
    x_9_0     disj2_0_9_2  -1.0
    x_9_0     disj1_1_9_2  1.0
    x_9_0     disj2_1_9_2  -1.0
    x_9_0     disj1_2_9_2  1.0
    x_9_0     disj2_2_9_2  -1.0
    x_9_0     disj1_3_9_2  1.0
    x_9_0     disj2_3_9_2  -1.0
    x_9_0     disj1_4_9_2  1.0
    x_9_0     disj2_4_9_2  -1.0
    x_9_0     disj1_5_9_2  1.0
    x_9_0     disj2_5_9_2  -1.0
    x_9_0     disj1_6_9_2  1.0
    x_9_0     disj2_6_9_2  -1.0
    x_9_0     disj1_7_9_2  1.0
    x_9_0     disj2_7_9_2  -1.0
    x_9_0     disj1_8_9_2  1.0
    x_9_0     disj2_8_9_2  -1.0
    x_9_1     prec_9_0  1.0
    x_9_1     prec_9_1  -1.0
    x_9_1     disj1_0_9_0  1.0
    x_9_1     disj2_0_9_0  -1.0
    x_9_1     disj1_1_9_0  1.0
    x_9_1     disj2_1_9_0  -1.0
    x_9_1     disj1_2_9_0  1.0
    x_9_1     disj2_2_9_0  -1.0
    x_9_1     disj1_3_9_0  1.0
    x_9_1     disj2_3_9_0  -1.0
    x_9_1     disj1_4_9_0  1.0
    x_9_1     disj2_4_9_0  -1.0
    x_9_1     disj1_5_9_0  1.0
    x_9_1     disj2_5_9_0  -1.0
    x_9_1     disj1_6_9_0  1.0
    x_9_1     disj2_6_9_0  -1.0
    x_9_1     disj1_7_9_0  1.0
    x_9_1     disj2_7_9_0  -1.0
    x_9_1     disj1_8_9_0  1.0
    x_9_1     disj2_8_9_0  -1.0
    x_9_2     prec_9_1  1.0
    x_9_2     prec_9_2  -1.0
    x_9_2     disj1_0_9_8  1.0
    x_9_2     disj2_0_9_8  -1.0
    x_9_2     disj1_1_9_8  1.0
    x_9_2     disj2_1_9_8  -1.0
    x_9_2     disj1_2_9_8  1.0
    x_9_2     disj2_2_9_8  -1.0
    x_9_2     disj1_3_9_8  1.0
    x_9_2     disj2_3_9_8  -1.0
    x_9_2     disj1_4_9_8  1.0
    x_9_2     disj2_4_9_8  -1.0
    x_9_2     disj1_5_9_8  1.0
    x_9_2     disj2_5_9_8  -1.0
    x_9_2     disj1_6_9_8  1.0
    x_9_2     disj2_6_9_8  -1.0
    x_9_2     disj1_7_9_8  1.0
    x_9_2     disj2_7_9_8  -1.0
    x_9_2     disj1_8_9_8  1.0
    x_9_2     disj2_8_9_8  -1.0
    x_9_3     prec_9_2  1.0
    x_9_3     prec_9_3  -1.0
    x_9_3     disj1_0_9_3  1.0
    x_9_3     disj2_0_9_3  -1.0
    x_9_3     disj1_1_9_3  1.0
    x_9_3     disj2_1_9_3  -1.0
    x_9_3     disj1_2_9_3  1.0
    x_9_3     disj2_2_9_3  -1.0
    x_9_3     disj1_3_9_3  1.0
    x_9_3     disj2_3_9_3  -1.0
    x_9_3     disj1_4_9_3  1.0
    x_9_3     disj2_4_9_3  -1.0
    x_9_3     disj1_5_9_3  1.0
    x_9_3     disj2_5_9_3  -1.0
    x_9_3     disj1_6_9_3  1.0
    x_9_3     disj2_6_9_3  -1.0
    x_9_3     disj1_7_9_3  1.0
    x_9_3     disj2_7_9_3  -1.0
    x_9_3     disj1_8_9_3  1.0
    x_9_3     disj2_8_9_3  -1.0
    x_9_4     prec_9_3  1.0
    x_9_4     prec_9_4  -1.0
    x_9_4     disj1_0_9_6  1.0
    x_9_4     disj2_0_9_6  -1.0
    x_9_4     disj1_1_9_6  1.0
    x_9_4     disj2_1_9_6  -1.0
    x_9_4     disj1_2_9_6  1.0
    x_9_4     disj2_2_9_6  -1.0
    x_9_4     disj1_3_9_6  1.0
    x_9_4     disj2_3_9_6  -1.0
    x_9_4     disj1_4_9_6  1.0
    x_9_4     disj2_4_9_6  -1.0
    x_9_4     disj1_5_9_6  1.0
    x_9_4     disj2_5_9_6  -1.0
    x_9_4     disj1_6_9_6  1.0
    x_9_4     disj2_6_9_6  -1.0
    x_9_4     disj1_7_9_6  1.0
    x_9_4     disj2_7_9_6  -1.0
    x_9_4     disj1_8_9_6  1.0
    x_9_4     disj2_8_9_6  -1.0
    x_9_5     prec_9_4  1.0
    x_9_5     prec_9_5  -1.0
    x_9_5     disj1_0_9_1  1.0
    x_9_5     disj2_0_9_1  -1.0
    x_9_5     disj1_1_9_1  1.0
    x_9_5     disj2_1_9_1  -1.0
    x_9_5     disj1_2_9_1  1.0
    x_9_5     disj2_2_9_1  -1.0
    x_9_5     disj1_3_9_1  1.0
    x_9_5     disj2_3_9_1  -1.0
    x_9_5     disj1_4_9_1  1.0
    x_9_5     disj2_4_9_1  -1.0
    x_9_5     disj1_5_9_1  1.0
    x_9_5     disj2_5_9_1  -1.0
    x_9_5     disj1_6_9_1  1.0
    x_9_5     disj2_6_9_1  -1.0
    x_9_5     disj1_7_9_1  1.0
    x_9_5     disj2_7_9_1  -1.0
    x_9_5     disj1_8_9_1  1.0
    x_9_5     disj2_8_9_1  -1.0
    x_9_6     prec_9_5  1.0
    x_9_6     prec_9_6  -1.0
    x_9_6     disj1_0_9_4  1.0
    x_9_6     disj2_0_9_4  -1.0
    x_9_6     disj1_1_9_4  1.0
    x_9_6     disj2_1_9_4  -1.0
    x_9_6     disj1_2_9_4  1.0
    x_9_6     disj2_2_9_4  -1.0
    x_9_6     disj1_3_9_4  1.0
    x_9_6     disj2_3_9_4  -1.0
    x_9_6     disj1_4_9_4  1.0
    x_9_6     disj2_4_9_4  -1.0
    x_9_6     disj1_5_9_4  1.0
    x_9_6     disj2_5_9_4  -1.0
    x_9_6     disj1_6_9_4  1.0
    x_9_6     disj2_6_9_4  -1.0
    x_9_6     disj1_7_9_4  1.0
    x_9_6     disj2_7_9_4  -1.0
    x_9_6     disj1_8_9_4  1.0
    x_9_6     disj2_8_9_4  -1.0
    x_9_7     prec_9_6  1.0
    x_9_7     prec_9_7  -1.0
    x_9_7     disj1_0_9_7  1.0
    x_9_7     disj2_0_9_7  -1.0
    x_9_7     disj1_1_9_7  1.0
    x_9_7     disj2_1_9_7  -1.0
    x_9_7     disj1_2_9_7  1.0
    x_9_7     disj2_2_9_7  -1.0
    x_9_7     disj1_3_9_7  1.0
    x_9_7     disj2_3_9_7  -1.0
    x_9_7     disj1_4_9_7  1.0
    x_9_7     disj2_4_9_7  -1.0
    x_9_7     disj1_5_9_7  1.0
    x_9_7     disj2_5_9_7  -1.0
    x_9_7     disj1_6_9_7  1.0
    x_9_7     disj2_6_9_7  -1.0
    x_9_7     disj1_7_9_7  1.0
    x_9_7     disj2_7_9_7  -1.0
    x_9_7     disj1_8_9_7  1.0
    x_9_7     disj2_8_9_7  -1.0
    x_9_8     prec_9_7  1.0
    x_9_8     prec_9_8  -1.0
    x_9_8     disj1_0_9_9  1.0
    x_9_8     disj2_0_9_9  -1.0
    x_9_8     disj1_1_9_9  1.0
    x_9_8     disj2_1_9_9  -1.0
    x_9_8     disj1_2_9_9  1.0
    x_9_8     disj2_2_9_9  -1.0
    x_9_8     disj1_3_9_9  1.0
    x_9_8     disj2_3_9_9  -1.0
    x_9_8     disj1_4_9_9  1.0
    x_9_8     disj2_4_9_9  -1.0
    x_9_8     disj1_5_9_9  1.0
    x_9_8     disj2_5_9_9  -1.0
    x_9_8     disj1_6_9_9  1.0
    x_9_8     disj2_6_9_9  -1.0
    x_9_8     disj1_7_9_9  1.0
    x_9_8     disj2_7_9_9  -1.0
    x_9_8     disj1_8_9_9  1.0
    x_9_8     disj2_8_9_9  -1.0
    x_9_9     prec_9_8  1.0
    x_9_9     mksp_9    -1.0
    x_9_9     disj1_0_9_5  1.0
    x_9_9     disj2_0_9_5  -1.0
    x_9_9     disj1_1_9_5  1.0
    x_9_9     disj2_1_9_5  -1.0
    x_9_9     disj1_2_9_5  1.0
    x_9_9     disj2_2_9_5  -1.0
    x_9_9     disj1_3_9_5  1.0
    x_9_9     disj2_3_9_5  -1.0
    x_9_9     disj1_4_9_5  1.0
    x_9_9     disj2_4_9_5  -1.0
    x_9_9     disj1_5_9_5  1.0
    x_9_9     disj2_5_9_5  -1.0
    x_9_9     disj1_6_9_5  1.0
    x_9_9     disj2_6_9_5  -1.0
    x_9_9     disj1_7_9_5  1.0
    x_9_9     disj2_7_9_5  -1.0
    x_9_9     disj1_8_9_5  1.0
    x_9_9     disj2_8_9_5  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  5409
    y_0_1_0   disj2_0_1_0  -5409
    y_0_1_1   disj1_0_1_1  5409
    y_0_1_1   disj2_0_1_1  -5409
    y_0_1_2   disj1_0_1_2  5409
    y_0_1_2   disj2_0_1_2  -5409
    y_0_1_3   disj1_0_1_3  5409
    y_0_1_3   disj2_0_1_3  -5409
    y_0_1_4   disj1_0_1_4  5409
    y_0_1_4   disj2_0_1_4  -5409
    y_0_1_5   disj1_0_1_5  5409
    y_0_1_5   disj2_0_1_5  -5409
    y_0_1_6   disj1_0_1_6  5409
    y_0_1_6   disj2_0_1_6  -5409
    y_0_1_7   disj1_0_1_7  5409
    y_0_1_7   disj2_0_1_7  -5409
    y_0_1_8   disj1_0_1_8  5409
    y_0_1_8   disj2_0_1_8  -5409
    y_0_1_9   disj1_0_1_9  5409
    y_0_1_9   disj2_0_1_9  -5409
    y_0_2_0   disj1_0_2_0  5409
    y_0_2_0   disj2_0_2_0  -5409
    y_0_2_1   disj1_0_2_1  5409
    y_0_2_1   disj2_0_2_1  -5409
    y_0_2_2   disj1_0_2_2  5409
    y_0_2_2   disj2_0_2_2  -5409
    y_0_2_3   disj1_0_2_3  5409
    y_0_2_3   disj2_0_2_3  -5409
    y_0_2_4   disj1_0_2_4  5409
    y_0_2_4   disj2_0_2_4  -5409
    y_0_2_5   disj1_0_2_5  5409
    y_0_2_5   disj2_0_2_5  -5409
    y_0_2_6   disj1_0_2_6  5409
    y_0_2_6   disj2_0_2_6  -5409
    y_0_2_7   disj1_0_2_7  5409
    y_0_2_7   disj2_0_2_7  -5409
    y_0_2_8   disj1_0_2_8  5409
    y_0_2_8   disj2_0_2_8  -5409
    y_0_2_9   disj1_0_2_9  5409
    y_0_2_9   disj2_0_2_9  -5409
    y_0_3_0   disj1_0_3_0  5409
    y_0_3_0   disj2_0_3_0  -5409
    y_0_3_1   disj1_0_3_1  5409
    y_0_3_1   disj2_0_3_1  -5409
    y_0_3_2   disj1_0_3_2  5409
    y_0_3_2   disj2_0_3_2  -5409
    y_0_3_3   disj1_0_3_3  5409
    y_0_3_3   disj2_0_3_3  -5409
    y_0_3_4   disj1_0_3_4  5409
    y_0_3_4   disj2_0_3_4  -5409
    y_0_3_5   disj1_0_3_5  5409
    y_0_3_5   disj2_0_3_5  -5409
    y_0_3_6   disj1_0_3_6  5409
    y_0_3_6   disj2_0_3_6  -5409
    y_0_3_7   disj1_0_3_7  5409
    y_0_3_7   disj2_0_3_7  -5409
    y_0_3_8   disj1_0_3_8  5409
    y_0_3_8   disj2_0_3_8  -5409
    y_0_3_9   disj1_0_3_9  5409
    y_0_3_9   disj2_0_3_9  -5409
    y_0_4_0   disj1_0_4_0  5409
    y_0_4_0   disj2_0_4_0  -5409
    y_0_4_1   disj1_0_4_1  5409
    y_0_4_1   disj2_0_4_1  -5409
    y_0_4_2   disj1_0_4_2  5409
    y_0_4_2   disj2_0_4_2  -5409
    y_0_4_3   disj1_0_4_3  5409
    y_0_4_3   disj2_0_4_3  -5409
    y_0_4_4   disj1_0_4_4  5409
    y_0_4_4   disj2_0_4_4  -5409
    y_0_4_5   disj1_0_4_5  5409
    y_0_4_5   disj2_0_4_5  -5409
    y_0_4_6   disj1_0_4_6  5409
    y_0_4_6   disj2_0_4_6  -5409
    y_0_4_7   disj1_0_4_7  5409
    y_0_4_7   disj2_0_4_7  -5409
    y_0_4_8   disj1_0_4_8  5409
    y_0_4_8   disj2_0_4_8  -5409
    y_0_4_9   disj1_0_4_9  5409
    y_0_4_9   disj2_0_4_9  -5409
    y_0_5_0   disj1_0_5_0  5409
    y_0_5_0   disj2_0_5_0  -5409
    y_0_5_1   disj1_0_5_1  5409
    y_0_5_1   disj2_0_5_1  -5409
    y_0_5_2   disj1_0_5_2  5409
    y_0_5_2   disj2_0_5_2  -5409
    y_0_5_3   disj1_0_5_3  5409
    y_0_5_3   disj2_0_5_3  -5409
    y_0_5_4   disj1_0_5_4  5409
    y_0_5_4   disj2_0_5_4  -5409
    y_0_5_5   disj1_0_5_5  5409
    y_0_5_5   disj2_0_5_5  -5409
    y_0_5_6   disj1_0_5_6  5409
    y_0_5_6   disj2_0_5_6  -5409
    y_0_5_7   disj1_0_5_7  5409
    y_0_5_7   disj2_0_5_7  -5409
    y_0_5_8   disj1_0_5_8  5409
    y_0_5_8   disj2_0_5_8  -5409
    y_0_5_9   disj1_0_5_9  5409
    y_0_5_9   disj2_0_5_9  -5409
    y_0_6_0   disj1_0_6_0  5409
    y_0_6_0   disj2_0_6_0  -5409
    y_0_6_1   disj1_0_6_1  5409
    y_0_6_1   disj2_0_6_1  -5409
    y_0_6_2   disj1_0_6_2  5409
    y_0_6_2   disj2_0_6_2  -5409
    y_0_6_3   disj1_0_6_3  5409
    y_0_6_3   disj2_0_6_3  -5409
    y_0_6_4   disj1_0_6_4  5409
    y_0_6_4   disj2_0_6_4  -5409
    y_0_6_5   disj1_0_6_5  5409
    y_0_6_5   disj2_0_6_5  -5409
    y_0_6_6   disj1_0_6_6  5409
    y_0_6_6   disj2_0_6_6  -5409
    y_0_6_7   disj1_0_6_7  5409
    y_0_6_7   disj2_0_6_7  -5409
    y_0_6_8   disj1_0_6_8  5409
    y_0_6_8   disj2_0_6_8  -5409
    y_0_6_9   disj1_0_6_9  5409
    y_0_6_9   disj2_0_6_9  -5409
    y_0_7_0   disj1_0_7_0  5409
    y_0_7_0   disj2_0_7_0  -5409
    y_0_7_1   disj1_0_7_1  5409
    y_0_7_1   disj2_0_7_1  -5409
    y_0_7_2   disj1_0_7_2  5409
    y_0_7_2   disj2_0_7_2  -5409
    y_0_7_3   disj1_0_7_3  5409
    y_0_7_3   disj2_0_7_3  -5409
    y_0_7_4   disj1_0_7_4  5409
    y_0_7_4   disj2_0_7_4  -5409
    y_0_7_5   disj1_0_7_5  5409
    y_0_7_5   disj2_0_7_5  -5409
    y_0_7_6   disj1_0_7_6  5409
    y_0_7_6   disj2_0_7_6  -5409
    y_0_7_7   disj1_0_7_7  5409
    y_0_7_7   disj2_0_7_7  -5409
    y_0_7_8   disj1_0_7_8  5409
    y_0_7_8   disj2_0_7_8  -5409
    y_0_7_9   disj1_0_7_9  5409
    y_0_7_9   disj2_0_7_9  -5409
    y_0_8_0   disj1_0_8_0  5409
    y_0_8_0   disj2_0_8_0  -5409
    y_0_8_1   disj1_0_8_1  5409
    y_0_8_1   disj2_0_8_1  -5409
    y_0_8_2   disj1_0_8_2  5409
    y_0_8_2   disj2_0_8_2  -5409
    y_0_8_3   disj1_0_8_3  5409
    y_0_8_3   disj2_0_8_3  -5409
    y_0_8_4   disj1_0_8_4  5409
    y_0_8_4   disj2_0_8_4  -5409
    y_0_8_5   disj1_0_8_5  5409
    y_0_8_5   disj2_0_8_5  -5409
    y_0_8_6   disj1_0_8_6  5409
    y_0_8_6   disj2_0_8_6  -5409
    y_0_8_7   disj1_0_8_7  5409
    y_0_8_7   disj2_0_8_7  -5409
    y_0_8_8   disj1_0_8_8  5409
    y_0_8_8   disj2_0_8_8  -5409
    y_0_8_9   disj1_0_8_9  5409
    y_0_8_9   disj2_0_8_9  -5409
    y_0_9_0   disj1_0_9_0  5409
    y_0_9_0   disj2_0_9_0  -5409
    y_0_9_1   disj1_0_9_1  5409
    y_0_9_1   disj2_0_9_1  -5409
    y_0_9_2   disj1_0_9_2  5409
    y_0_9_2   disj2_0_9_2  -5409
    y_0_9_3   disj1_0_9_3  5409
    y_0_9_3   disj2_0_9_3  -5409
    y_0_9_4   disj1_0_9_4  5409
    y_0_9_4   disj2_0_9_4  -5409
    y_0_9_5   disj1_0_9_5  5409
    y_0_9_5   disj2_0_9_5  -5409
    y_0_9_6   disj1_0_9_6  5409
    y_0_9_6   disj2_0_9_6  -5409
    y_0_9_7   disj1_0_9_7  5409
    y_0_9_7   disj2_0_9_7  -5409
    y_0_9_8   disj1_0_9_8  5409
    y_0_9_8   disj2_0_9_8  -5409
    y_0_9_9   disj1_0_9_9  5409
    y_0_9_9   disj2_0_9_9  -5409
    y_1_2_0   disj1_1_2_0  5409
    y_1_2_0   disj2_1_2_0  -5409
    y_1_2_1   disj1_1_2_1  5409
    y_1_2_1   disj2_1_2_1  -5409
    y_1_2_2   disj1_1_2_2  5409
    y_1_2_2   disj2_1_2_2  -5409
    y_1_2_3   disj1_1_2_3  5409
    y_1_2_3   disj2_1_2_3  -5409
    y_1_2_4   disj1_1_2_4  5409
    y_1_2_4   disj2_1_2_4  -5409
    y_1_2_5   disj1_1_2_5  5409
    y_1_2_5   disj2_1_2_5  -5409
    y_1_2_6   disj1_1_2_6  5409
    y_1_2_6   disj2_1_2_6  -5409
    y_1_2_7   disj1_1_2_7  5409
    y_1_2_7   disj2_1_2_7  -5409
    y_1_2_8   disj1_1_2_8  5409
    y_1_2_8   disj2_1_2_8  -5409
    y_1_2_9   disj1_1_2_9  5409
    y_1_2_9   disj2_1_2_9  -5409
    y_1_3_0   disj1_1_3_0  5409
    y_1_3_0   disj2_1_3_0  -5409
    y_1_3_1   disj1_1_3_1  5409
    y_1_3_1   disj2_1_3_1  -5409
    y_1_3_2   disj1_1_3_2  5409
    y_1_3_2   disj2_1_3_2  -5409
    y_1_3_3   disj1_1_3_3  5409
    y_1_3_3   disj2_1_3_3  -5409
    y_1_3_4   disj1_1_3_4  5409
    y_1_3_4   disj2_1_3_4  -5409
    y_1_3_5   disj1_1_3_5  5409
    y_1_3_5   disj2_1_3_5  -5409
    y_1_3_6   disj1_1_3_6  5409
    y_1_3_6   disj2_1_3_6  -5409
    y_1_3_7   disj1_1_3_7  5409
    y_1_3_7   disj2_1_3_7  -5409
    y_1_3_8   disj1_1_3_8  5409
    y_1_3_8   disj2_1_3_8  -5409
    y_1_3_9   disj1_1_3_9  5409
    y_1_3_9   disj2_1_3_9  -5409
    y_1_4_0   disj1_1_4_0  5409
    y_1_4_0   disj2_1_4_0  -5409
    y_1_4_1   disj1_1_4_1  5409
    y_1_4_1   disj2_1_4_1  -5409
    y_1_4_2   disj1_1_4_2  5409
    y_1_4_2   disj2_1_4_2  -5409
    y_1_4_3   disj1_1_4_3  5409
    y_1_4_3   disj2_1_4_3  -5409
    y_1_4_4   disj1_1_4_4  5409
    y_1_4_4   disj2_1_4_4  -5409
    y_1_4_5   disj1_1_4_5  5409
    y_1_4_5   disj2_1_4_5  -5409
    y_1_4_6   disj1_1_4_6  5409
    y_1_4_6   disj2_1_4_6  -5409
    y_1_4_7   disj1_1_4_7  5409
    y_1_4_7   disj2_1_4_7  -5409
    y_1_4_8   disj1_1_4_8  5409
    y_1_4_8   disj2_1_4_8  -5409
    y_1_4_9   disj1_1_4_9  5409
    y_1_4_9   disj2_1_4_9  -5409
    y_1_5_0   disj1_1_5_0  5409
    y_1_5_0   disj2_1_5_0  -5409
    y_1_5_1   disj1_1_5_1  5409
    y_1_5_1   disj2_1_5_1  -5409
    y_1_5_2   disj1_1_5_2  5409
    y_1_5_2   disj2_1_5_2  -5409
    y_1_5_3   disj1_1_5_3  5409
    y_1_5_3   disj2_1_5_3  -5409
    y_1_5_4   disj1_1_5_4  5409
    y_1_5_4   disj2_1_5_4  -5409
    y_1_5_5   disj1_1_5_5  5409
    y_1_5_5   disj2_1_5_5  -5409
    y_1_5_6   disj1_1_5_6  5409
    y_1_5_6   disj2_1_5_6  -5409
    y_1_5_7   disj1_1_5_7  5409
    y_1_5_7   disj2_1_5_7  -5409
    y_1_5_8   disj1_1_5_8  5409
    y_1_5_8   disj2_1_5_8  -5409
    y_1_5_9   disj1_1_5_9  5409
    y_1_5_9   disj2_1_5_9  -5409
    y_1_6_0   disj1_1_6_0  5409
    y_1_6_0   disj2_1_6_0  -5409
    y_1_6_1   disj1_1_6_1  5409
    y_1_6_1   disj2_1_6_1  -5409
    y_1_6_2   disj1_1_6_2  5409
    y_1_6_2   disj2_1_6_2  -5409
    y_1_6_3   disj1_1_6_3  5409
    y_1_6_3   disj2_1_6_3  -5409
    y_1_6_4   disj1_1_6_4  5409
    y_1_6_4   disj2_1_6_4  -5409
    y_1_6_5   disj1_1_6_5  5409
    y_1_6_5   disj2_1_6_5  -5409
    y_1_6_6   disj1_1_6_6  5409
    y_1_6_6   disj2_1_6_6  -5409
    y_1_6_7   disj1_1_6_7  5409
    y_1_6_7   disj2_1_6_7  -5409
    y_1_6_8   disj1_1_6_8  5409
    y_1_6_8   disj2_1_6_8  -5409
    y_1_6_9   disj1_1_6_9  5409
    y_1_6_9   disj2_1_6_9  -5409
    y_1_7_0   disj1_1_7_0  5409
    y_1_7_0   disj2_1_7_0  -5409
    y_1_7_1   disj1_1_7_1  5409
    y_1_7_1   disj2_1_7_1  -5409
    y_1_7_2   disj1_1_7_2  5409
    y_1_7_2   disj2_1_7_2  -5409
    y_1_7_3   disj1_1_7_3  5409
    y_1_7_3   disj2_1_7_3  -5409
    y_1_7_4   disj1_1_7_4  5409
    y_1_7_4   disj2_1_7_4  -5409
    y_1_7_5   disj1_1_7_5  5409
    y_1_7_5   disj2_1_7_5  -5409
    y_1_7_6   disj1_1_7_6  5409
    y_1_7_6   disj2_1_7_6  -5409
    y_1_7_7   disj1_1_7_7  5409
    y_1_7_7   disj2_1_7_7  -5409
    y_1_7_8   disj1_1_7_8  5409
    y_1_7_8   disj2_1_7_8  -5409
    y_1_7_9   disj1_1_7_9  5409
    y_1_7_9   disj2_1_7_9  -5409
    y_1_8_0   disj1_1_8_0  5409
    y_1_8_0   disj2_1_8_0  -5409
    y_1_8_1   disj1_1_8_1  5409
    y_1_8_1   disj2_1_8_1  -5409
    y_1_8_2   disj1_1_8_2  5409
    y_1_8_2   disj2_1_8_2  -5409
    y_1_8_3   disj1_1_8_3  5409
    y_1_8_3   disj2_1_8_3  -5409
    y_1_8_4   disj1_1_8_4  5409
    y_1_8_4   disj2_1_8_4  -5409
    y_1_8_5   disj1_1_8_5  5409
    y_1_8_5   disj2_1_8_5  -5409
    y_1_8_6   disj1_1_8_6  5409
    y_1_8_6   disj2_1_8_6  -5409
    y_1_8_7   disj1_1_8_7  5409
    y_1_8_7   disj2_1_8_7  -5409
    y_1_8_8   disj1_1_8_8  5409
    y_1_8_8   disj2_1_8_8  -5409
    y_1_8_9   disj1_1_8_9  5409
    y_1_8_9   disj2_1_8_9  -5409
    y_1_9_0   disj1_1_9_0  5409
    y_1_9_0   disj2_1_9_0  -5409
    y_1_9_1   disj1_1_9_1  5409
    y_1_9_1   disj2_1_9_1  -5409
    y_1_9_2   disj1_1_9_2  5409
    y_1_9_2   disj2_1_9_2  -5409
    y_1_9_3   disj1_1_9_3  5409
    y_1_9_3   disj2_1_9_3  -5409
    y_1_9_4   disj1_1_9_4  5409
    y_1_9_4   disj2_1_9_4  -5409
    y_1_9_5   disj1_1_9_5  5409
    y_1_9_5   disj2_1_9_5  -5409
    y_1_9_6   disj1_1_9_6  5409
    y_1_9_6   disj2_1_9_6  -5409
    y_1_9_7   disj1_1_9_7  5409
    y_1_9_7   disj2_1_9_7  -5409
    y_1_9_8   disj1_1_9_8  5409
    y_1_9_8   disj2_1_9_8  -5409
    y_1_9_9   disj1_1_9_9  5409
    y_1_9_9   disj2_1_9_9  -5409
    y_2_3_0   disj1_2_3_0  5409
    y_2_3_0   disj2_2_3_0  -5409
    y_2_3_1   disj1_2_3_1  5409
    y_2_3_1   disj2_2_3_1  -5409
    y_2_3_2   disj1_2_3_2  5409
    y_2_3_2   disj2_2_3_2  -5409
    y_2_3_3   disj1_2_3_3  5409
    y_2_3_3   disj2_2_3_3  -5409
    y_2_3_4   disj1_2_3_4  5409
    y_2_3_4   disj2_2_3_4  -5409
    y_2_3_5   disj1_2_3_5  5409
    y_2_3_5   disj2_2_3_5  -5409
    y_2_3_6   disj1_2_3_6  5409
    y_2_3_6   disj2_2_3_6  -5409
    y_2_3_7   disj1_2_3_7  5409
    y_2_3_7   disj2_2_3_7  -5409
    y_2_3_8   disj1_2_3_8  5409
    y_2_3_8   disj2_2_3_8  -5409
    y_2_3_9   disj1_2_3_9  5409
    y_2_3_9   disj2_2_3_9  -5409
    y_2_4_0   disj1_2_4_0  5409
    y_2_4_0   disj2_2_4_0  -5409
    y_2_4_1   disj1_2_4_1  5409
    y_2_4_1   disj2_2_4_1  -5409
    y_2_4_2   disj1_2_4_2  5409
    y_2_4_2   disj2_2_4_2  -5409
    y_2_4_3   disj1_2_4_3  5409
    y_2_4_3   disj2_2_4_3  -5409
    y_2_4_4   disj1_2_4_4  5409
    y_2_4_4   disj2_2_4_4  -5409
    y_2_4_5   disj1_2_4_5  5409
    y_2_4_5   disj2_2_4_5  -5409
    y_2_4_6   disj1_2_4_6  5409
    y_2_4_6   disj2_2_4_6  -5409
    y_2_4_7   disj1_2_4_7  5409
    y_2_4_7   disj2_2_4_7  -5409
    y_2_4_8   disj1_2_4_8  5409
    y_2_4_8   disj2_2_4_8  -5409
    y_2_4_9   disj1_2_4_9  5409
    y_2_4_9   disj2_2_4_9  -5409
    y_2_5_0   disj1_2_5_0  5409
    y_2_5_0   disj2_2_5_0  -5409
    y_2_5_1   disj1_2_5_1  5409
    y_2_5_1   disj2_2_5_1  -5409
    y_2_5_2   disj1_2_5_2  5409
    y_2_5_2   disj2_2_5_2  -5409
    y_2_5_3   disj1_2_5_3  5409
    y_2_5_3   disj2_2_5_3  -5409
    y_2_5_4   disj1_2_5_4  5409
    y_2_5_4   disj2_2_5_4  -5409
    y_2_5_5   disj1_2_5_5  5409
    y_2_5_5   disj2_2_5_5  -5409
    y_2_5_6   disj1_2_5_6  5409
    y_2_5_6   disj2_2_5_6  -5409
    y_2_5_7   disj1_2_5_7  5409
    y_2_5_7   disj2_2_5_7  -5409
    y_2_5_8   disj1_2_5_8  5409
    y_2_5_8   disj2_2_5_8  -5409
    y_2_5_9   disj1_2_5_9  5409
    y_2_5_9   disj2_2_5_9  -5409
    y_2_6_0   disj1_2_6_0  5409
    y_2_6_0   disj2_2_6_0  -5409
    y_2_6_1   disj1_2_6_1  5409
    y_2_6_1   disj2_2_6_1  -5409
    y_2_6_2   disj1_2_6_2  5409
    y_2_6_2   disj2_2_6_2  -5409
    y_2_6_3   disj1_2_6_3  5409
    y_2_6_3   disj2_2_6_3  -5409
    y_2_6_4   disj1_2_6_4  5409
    y_2_6_4   disj2_2_6_4  -5409
    y_2_6_5   disj1_2_6_5  5409
    y_2_6_5   disj2_2_6_5  -5409
    y_2_6_6   disj1_2_6_6  5409
    y_2_6_6   disj2_2_6_6  -5409
    y_2_6_7   disj1_2_6_7  5409
    y_2_6_7   disj2_2_6_7  -5409
    y_2_6_8   disj1_2_6_8  5409
    y_2_6_8   disj2_2_6_8  -5409
    y_2_6_9   disj1_2_6_9  5409
    y_2_6_9   disj2_2_6_9  -5409
    y_2_7_0   disj1_2_7_0  5409
    y_2_7_0   disj2_2_7_0  -5409
    y_2_7_1   disj1_2_7_1  5409
    y_2_7_1   disj2_2_7_1  -5409
    y_2_7_2   disj1_2_7_2  5409
    y_2_7_2   disj2_2_7_2  -5409
    y_2_7_3   disj1_2_7_3  5409
    y_2_7_3   disj2_2_7_3  -5409
    y_2_7_4   disj1_2_7_4  5409
    y_2_7_4   disj2_2_7_4  -5409
    y_2_7_5   disj1_2_7_5  5409
    y_2_7_5   disj2_2_7_5  -5409
    y_2_7_6   disj1_2_7_6  5409
    y_2_7_6   disj2_2_7_6  -5409
    y_2_7_7   disj1_2_7_7  5409
    y_2_7_7   disj2_2_7_7  -5409
    y_2_7_8   disj1_2_7_8  5409
    y_2_7_8   disj2_2_7_8  -5409
    y_2_7_9   disj1_2_7_9  5409
    y_2_7_9   disj2_2_7_9  -5409
    y_2_8_0   disj1_2_8_0  5409
    y_2_8_0   disj2_2_8_0  -5409
    y_2_8_1   disj1_2_8_1  5409
    y_2_8_1   disj2_2_8_1  -5409
    y_2_8_2   disj1_2_8_2  5409
    y_2_8_2   disj2_2_8_2  -5409
    y_2_8_3   disj1_2_8_3  5409
    y_2_8_3   disj2_2_8_3  -5409
    y_2_8_4   disj1_2_8_4  5409
    y_2_8_4   disj2_2_8_4  -5409
    y_2_8_5   disj1_2_8_5  5409
    y_2_8_5   disj2_2_8_5  -5409
    y_2_8_6   disj1_2_8_6  5409
    y_2_8_6   disj2_2_8_6  -5409
    y_2_8_7   disj1_2_8_7  5409
    y_2_8_7   disj2_2_8_7  -5409
    y_2_8_8   disj1_2_8_8  5409
    y_2_8_8   disj2_2_8_8  -5409
    y_2_8_9   disj1_2_8_9  5409
    y_2_8_9   disj2_2_8_9  -5409
    y_2_9_0   disj1_2_9_0  5409
    y_2_9_0   disj2_2_9_0  -5409
    y_2_9_1   disj1_2_9_1  5409
    y_2_9_1   disj2_2_9_1  -5409
    y_2_9_2   disj1_2_9_2  5409
    y_2_9_2   disj2_2_9_2  -5409
    y_2_9_3   disj1_2_9_3  5409
    y_2_9_3   disj2_2_9_3  -5409
    y_2_9_4   disj1_2_9_4  5409
    y_2_9_4   disj2_2_9_4  -5409
    y_2_9_5   disj1_2_9_5  5409
    y_2_9_5   disj2_2_9_5  -5409
    y_2_9_6   disj1_2_9_6  5409
    y_2_9_6   disj2_2_9_6  -5409
    y_2_9_7   disj1_2_9_7  5409
    y_2_9_7   disj2_2_9_7  -5409
    y_2_9_8   disj1_2_9_8  5409
    y_2_9_8   disj2_2_9_8  -5409
    y_2_9_9   disj1_2_9_9  5409
    y_2_9_9   disj2_2_9_9  -5409
    y_3_4_0   disj1_3_4_0  5409
    y_3_4_0   disj2_3_4_0  -5409
    y_3_4_1   disj1_3_4_1  5409
    y_3_4_1   disj2_3_4_1  -5409
    y_3_4_2   disj1_3_4_2  5409
    y_3_4_2   disj2_3_4_2  -5409
    y_3_4_3   disj1_3_4_3  5409
    y_3_4_3   disj2_3_4_3  -5409
    y_3_4_4   disj1_3_4_4  5409
    y_3_4_4   disj2_3_4_4  -5409
    y_3_4_5   disj1_3_4_5  5409
    y_3_4_5   disj2_3_4_5  -5409
    y_3_4_6   disj1_3_4_6  5409
    y_3_4_6   disj2_3_4_6  -5409
    y_3_4_7   disj1_3_4_7  5409
    y_3_4_7   disj2_3_4_7  -5409
    y_3_4_8   disj1_3_4_8  5409
    y_3_4_8   disj2_3_4_8  -5409
    y_3_4_9   disj1_3_4_9  5409
    y_3_4_9   disj2_3_4_9  -5409
    y_3_5_0   disj1_3_5_0  5409
    y_3_5_0   disj2_3_5_0  -5409
    y_3_5_1   disj1_3_5_1  5409
    y_3_5_1   disj2_3_5_1  -5409
    y_3_5_2   disj1_3_5_2  5409
    y_3_5_2   disj2_3_5_2  -5409
    y_3_5_3   disj1_3_5_3  5409
    y_3_5_3   disj2_3_5_3  -5409
    y_3_5_4   disj1_3_5_4  5409
    y_3_5_4   disj2_3_5_4  -5409
    y_3_5_5   disj1_3_5_5  5409
    y_3_5_5   disj2_3_5_5  -5409
    y_3_5_6   disj1_3_5_6  5409
    y_3_5_6   disj2_3_5_6  -5409
    y_3_5_7   disj1_3_5_7  5409
    y_3_5_7   disj2_3_5_7  -5409
    y_3_5_8   disj1_3_5_8  5409
    y_3_5_8   disj2_3_5_8  -5409
    y_3_5_9   disj1_3_5_9  5409
    y_3_5_9   disj2_3_5_9  -5409
    y_3_6_0   disj1_3_6_0  5409
    y_3_6_0   disj2_3_6_0  -5409
    y_3_6_1   disj1_3_6_1  5409
    y_3_6_1   disj2_3_6_1  -5409
    y_3_6_2   disj1_3_6_2  5409
    y_3_6_2   disj2_3_6_2  -5409
    y_3_6_3   disj1_3_6_3  5409
    y_3_6_3   disj2_3_6_3  -5409
    y_3_6_4   disj1_3_6_4  5409
    y_3_6_4   disj2_3_6_4  -5409
    y_3_6_5   disj1_3_6_5  5409
    y_3_6_5   disj2_3_6_5  -5409
    y_3_6_6   disj1_3_6_6  5409
    y_3_6_6   disj2_3_6_6  -5409
    y_3_6_7   disj1_3_6_7  5409
    y_3_6_7   disj2_3_6_7  -5409
    y_3_6_8   disj1_3_6_8  5409
    y_3_6_8   disj2_3_6_8  -5409
    y_3_6_9   disj1_3_6_9  5409
    y_3_6_9   disj2_3_6_9  -5409
    y_3_7_0   disj1_3_7_0  5409
    y_3_7_0   disj2_3_7_0  -5409
    y_3_7_1   disj1_3_7_1  5409
    y_3_7_1   disj2_3_7_1  -5409
    y_3_7_2   disj1_3_7_2  5409
    y_3_7_2   disj2_3_7_2  -5409
    y_3_7_3   disj1_3_7_3  5409
    y_3_7_3   disj2_3_7_3  -5409
    y_3_7_4   disj1_3_7_4  5409
    y_3_7_4   disj2_3_7_4  -5409
    y_3_7_5   disj1_3_7_5  5409
    y_3_7_5   disj2_3_7_5  -5409
    y_3_7_6   disj1_3_7_6  5409
    y_3_7_6   disj2_3_7_6  -5409
    y_3_7_7   disj1_3_7_7  5409
    y_3_7_7   disj2_3_7_7  -5409
    y_3_7_8   disj1_3_7_8  5409
    y_3_7_8   disj2_3_7_8  -5409
    y_3_7_9   disj1_3_7_9  5409
    y_3_7_9   disj2_3_7_9  -5409
    y_3_8_0   disj1_3_8_0  5409
    y_3_8_0   disj2_3_8_0  -5409
    y_3_8_1   disj1_3_8_1  5409
    y_3_8_1   disj2_3_8_1  -5409
    y_3_8_2   disj1_3_8_2  5409
    y_3_8_2   disj2_3_8_2  -5409
    y_3_8_3   disj1_3_8_3  5409
    y_3_8_3   disj2_3_8_3  -5409
    y_3_8_4   disj1_3_8_4  5409
    y_3_8_4   disj2_3_8_4  -5409
    y_3_8_5   disj1_3_8_5  5409
    y_3_8_5   disj2_3_8_5  -5409
    y_3_8_6   disj1_3_8_6  5409
    y_3_8_6   disj2_3_8_6  -5409
    y_3_8_7   disj1_3_8_7  5409
    y_3_8_7   disj2_3_8_7  -5409
    y_3_8_8   disj1_3_8_8  5409
    y_3_8_8   disj2_3_8_8  -5409
    y_3_8_9   disj1_3_8_9  5409
    y_3_8_9   disj2_3_8_9  -5409
    y_3_9_0   disj1_3_9_0  5409
    y_3_9_0   disj2_3_9_0  -5409
    y_3_9_1   disj1_3_9_1  5409
    y_3_9_1   disj2_3_9_1  -5409
    y_3_9_2   disj1_3_9_2  5409
    y_3_9_2   disj2_3_9_2  -5409
    y_3_9_3   disj1_3_9_3  5409
    y_3_9_3   disj2_3_9_3  -5409
    y_3_9_4   disj1_3_9_4  5409
    y_3_9_4   disj2_3_9_4  -5409
    y_3_9_5   disj1_3_9_5  5409
    y_3_9_5   disj2_3_9_5  -5409
    y_3_9_6   disj1_3_9_6  5409
    y_3_9_6   disj2_3_9_6  -5409
    y_3_9_7   disj1_3_9_7  5409
    y_3_9_7   disj2_3_9_7  -5409
    y_3_9_8   disj1_3_9_8  5409
    y_3_9_8   disj2_3_9_8  -5409
    y_3_9_9   disj1_3_9_9  5409
    y_3_9_9   disj2_3_9_9  -5409
    y_4_5_0   disj1_4_5_0  5409
    y_4_5_0   disj2_4_5_0  -5409
    y_4_5_1   disj1_4_5_1  5409
    y_4_5_1   disj2_4_5_1  -5409
    y_4_5_2   disj1_4_5_2  5409
    y_4_5_2   disj2_4_5_2  -5409
    y_4_5_3   disj1_4_5_3  5409
    y_4_5_3   disj2_4_5_3  -5409
    y_4_5_4   disj1_4_5_4  5409
    y_4_5_4   disj2_4_5_4  -5409
    y_4_5_5   disj1_4_5_5  5409
    y_4_5_5   disj2_4_5_5  -5409
    y_4_5_6   disj1_4_5_6  5409
    y_4_5_6   disj2_4_5_6  -5409
    y_4_5_7   disj1_4_5_7  5409
    y_4_5_7   disj2_4_5_7  -5409
    y_4_5_8   disj1_4_5_8  5409
    y_4_5_8   disj2_4_5_8  -5409
    y_4_5_9   disj1_4_5_9  5409
    y_4_5_9   disj2_4_5_9  -5409
    y_4_6_0   disj1_4_6_0  5409
    y_4_6_0   disj2_4_6_0  -5409
    y_4_6_1   disj1_4_6_1  5409
    y_4_6_1   disj2_4_6_1  -5409
    y_4_6_2   disj1_4_6_2  5409
    y_4_6_2   disj2_4_6_2  -5409
    y_4_6_3   disj1_4_6_3  5409
    y_4_6_3   disj2_4_6_3  -5409
    y_4_6_4   disj1_4_6_4  5409
    y_4_6_4   disj2_4_6_4  -5409
    y_4_6_5   disj1_4_6_5  5409
    y_4_6_5   disj2_4_6_5  -5409
    y_4_6_6   disj1_4_6_6  5409
    y_4_6_6   disj2_4_6_6  -5409
    y_4_6_7   disj1_4_6_7  5409
    y_4_6_7   disj2_4_6_7  -5409
    y_4_6_8   disj1_4_6_8  5409
    y_4_6_8   disj2_4_6_8  -5409
    y_4_6_9   disj1_4_6_9  5409
    y_4_6_9   disj2_4_6_9  -5409
    y_4_7_0   disj1_4_7_0  5409
    y_4_7_0   disj2_4_7_0  -5409
    y_4_7_1   disj1_4_7_1  5409
    y_4_7_1   disj2_4_7_1  -5409
    y_4_7_2   disj1_4_7_2  5409
    y_4_7_2   disj2_4_7_2  -5409
    y_4_7_3   disj1_4_7_3  5409
    y_4_7_3   disj2_4_7_3  -5409
    y_4_7_4   disj1_4_7_4  5409
    y_4_7_4   disj2_4_7_4  -5409
    y_4_7_5   disj1_4_7_5  5409
    y_4_7_5   disj2_4_7_5  -5409
    y_4_7_6   disj1_4_7_6  5409
    y_4_7_6   disj2_4_7_6  -5409
    y_4_7_7   disj1_4_7_7  5409
    y_4_7_7   disj2_4_7_7  -5409
    y_4_7_8   disj1_4_7_8  5409
    y_4_7_8   disj2_4_7_8  -5409
    y_4_7_9   disj1_4_7_9  5409
    y_4_7_9   disj2_4_7_9  -5409
    y_4_8_0   disj1_4_8_0  5409
    y_4_8_0   disj2_4_8_0  -5409
    y_4_8_1   disj1_4_8_1  5409
    y_4_8_1   disj2_4_8_1  -5409
    y_4_8_2   disj1_4_8_2  5409
    y_4_8_2   disj2_4_8_2  -5409
    y_4_8_3   disj1_4_8_3  5409
    y_4_8_3   disj2_4_8_3  -5409
    y_4_8_4   disj1_4_8_4  5409
    y_4_8_4   disj2_4_8_4  -5409
    y_4_8_5   disj1_4_8_5  5409
    y_4_8_5   disj2_4_8_5  -5409
    y_4_8_6   disj1_4_8_6  5409
    y_4_8_6   disj2_4_8_6  -5409
    y_4_8_7   disj1_4_8_7  5409
    y_4_8_7   disj2_4_8_7  -5409
    y_4_8_8   disj1_4_8_8  5409
    y_4_8_8   disj2_4_8_8  -5409
    y_4_8_9   disj1_4_8_9  5409
    y_4_8_9   disj2_4_8_9  -5409
    y_4_9_0   disj1_4_9_0  5409
    y_4_9_0   disj2_4_9_0  -5409
    y_4_9_1   disj1_4_9_1  5409
    y_4_9_1   disj2_4_9_1  -5409
    y_4_9_2   disj1_4_9_2  5409
    y_4_9_2   disj2_4_9_2  -5409
    y_4_9_3   disj1_4_9_3  5409
    y_4_9_3   disj2_4_9_3  -5409
    y_4_9_4   disj1_4_9_4  5409
    y_4_9_4   disj2_4_9_4  -5409
    y_4_9_5   disj1_4_9_5  5409
    y_4_9_5   disj2_4_9_5  -5409
    y_4_9_6   disj1_4_9_6  5409
    y_4_9_6   disj2_4_9_6  -5409
    y_4_9_7   disj1_4_9_7  5409
    y_4_9_7   disj2_4_9_7  -5409
    y_4_9_8   disj1_4_9_8  5409
    y_4_9_8   disj2_4_9_8  -5409
    y_4_9_9   disj1_4_9_9  5409
    y_4_9_9   disj2_4_9_9  -5409
    y_5_6_0   disj1_5_6_0  5409
    y_5_6_0   disj2_5_6_0  -5409
    y_5_6_1   disj1_5_6_1  5409
    y_5_6_1   disj2_5_6_1  -5409
    y_5_6_2   disj1_5_6_2  5409
    y_5_6_2   disj2_5_6_2  -5409
    y_5_6_3   disj1_5_6_3  5409
    y_5_6_3   disj2_5_6_3  -5409
    y_5_6_4   disj1_5_6_4  5409
    y_5_6_4   disj2_5_6_4  -5409
    y_5_6_5   disj1_5_6_5  5409
    y_5_6_5   disj2_5_6_5  -5409
    y_5_6_6   disj1_5_6_6  5409
    y_5_6_6   disj2_5_6_6  -5409
    y_5_6_7   disj1_5_6_7  5409
    y_5_6_7   disj2_5_6_7  -5409
    y_5_6_8   disj1_5_6_8  5409
    y_5_6_8   disj2_5_6_8  -5409
    y_5_6_9   disj1_5_6_9  5409
    y_5_6_9   disj2_5_6_9  -5409
    y_5_7_0   disj1_5_7_0  5409
    y_5_7_0   disj2_5_7_0  -5409
    y_5_7_1   disj1_5_7_1  5409
    y_5_7_1   disj2_5_7_1  -5409
    y_5_7_2   disj1_5_7_2  5409
    y_5_7_2   disj2_5_7_2  -5409
    y_5_7_3   disj1_5_7_3  5409
    y_5_7_3   disj2_5_7_3  -5409
    y_5_7_4   disj1_5_7_4  5409
    y_5_7_4   disj2_5_7_4  -5409
    y_5_7_5   disj1_5_7_5  5409
    y_5_7_5   disj2_5_7_5  -5409
    y_5_7_6   disj1_5_7_6  5409
    y_5_7_6   disj2_5_7_6  -5409
    y_5_7_7   disj1_5_7_7  5409
    y_5_7_7   disj2_5_7_7  -5409
    y_5_7_8   disj1_5_7_8  5409
    y_5_7_8   disj2_5_7_8  -5409
    y_5_7_9   disj1_5_7_9  5409
    y_5_7_9   disj2_5_7_9  -5409
    y_5_8_0   disj1_5_8_0  5409
    y_5_8_0   disj2_5_8_0  -5409
    y_5_8_1   disj1_5_8_1  5409
    y_5_8_1   disj2_5_8_1  -5409
    y_5_8_2   disj1_5_8_2  5409
    y_5_8_2   disj2_5_8_2  -5409
    y_5_8_3   disj1_5_8_3  5409
    y_5_8_3   disj2_5_8_3  -5409
    y_5_8_4   disj1_5_8_4  5409
    y_5_8_4   disj2_5_8_4  -5409
    y_5_8_5   disj1_5_8_5  5409
    y_5_8_5   disj2_5_8_5  -5409
    y_5_8_6   disj1_5_8_6  5409
    y_5_8_6   disj2_5_8_6  -5409
    y_5_8_7   disj1_5_8_7  5409
    y_5_8_7   disj2_5_8_7  -5409
    y_5_8_8   disj1_5_8_8  5409
    y_5_8_8   disj2_5_8_8  -5409
    y_5_8_9   disj1_5_8_9  5409
    y_5_8_9   disj2_5_8_9  -5409
    y_5_9_0   disj1_5_9_0  5409
    y_5_9_0   disj2_5_9_0  -5409
    y_5_9_1   disj1_5_9_1  5409
    y_5_9_1   disj2_5_9_1  -5409
    y_5_9_2   disj1_5_9_2  5409
    y_5_9_2   disj2_5_9_2  -5409
    y_5_9_3   disj1_5_9_3  5409
    y_5_9_3   disj2_5_9_3  -5409
    y_5_9_4   disj1_5_9_4  5409
    y_5_9_4   disj2_5_9_4  -5409
    y_5_9_5   disj1_5_9_5  5409
    y_5_9_5   disj2_5_9_5  -5409
    y_5_9_6   disj1_5_9_6  5409
    y_5_9_6   disj2_5_9_6  -5409
    y_5_9_7   disj1_5_9_7  5409
    y_5_9_7   disj2_5_9_7  -5409
    y_5_9_8   disj1_5_9_8  5409
    y_5_9_8   disj2_5_9_8  -5409
    y_5_9_9   disj1_5_9_9  5409
    y_5_9_9   disj2_5_9_9  -5409
    y_6_7_0   disj1_6_7_0  5409
    y_6_7_0   disj2_6_7_0  -5409
    y_6_7_1   disj1_6_7_1  5409
    y_6_7_1   disj2_6_7_1  -5409
    y_6_7_2   disj1_6_7_2  5409
    y_6_7_2   disj2_6_7_2  -5409
    y_6_7_3   disj1_6_7_3  5409
    y_6_7_3   disj2_6_7_3  -5409
    y_6_7_4   disj1_6_7_4  5409
    y_6_7_4   disj2_6_7_4  -5409
    y_6_7_5   disj1_6_7_5  5409
    y_6_7_5   disj2_6_7_5  -5409
    y_6_7_6   disj1_6_7_6  5409
    y_6_7_6   disj2_6_7_6  -5409
    y_6_7_7   disj1_6_7_7  5409
    y_6_7_7   disj2_6_7_7  -5409
    y_6_7_8   disj1_6_7_8  5409
    y_6_7_8   disj2_6_7_8  -5409
    y_6_7_9   disj1_6_7_9  5409
    y_6_7_9   disj2_6_7_9  -5409
    y_6_8_0   disj1_6_8_0  5409
    y_6_8_0   disj2_6_8_0  -5409
    y_6_8_1   disj1_6_8_1  5409
    y_6_8_1   disj2_6_8_1  -5409
    y_6_8_2   disj1_6_8_2  5409
    y_6_8_2   disj2_6_8_2  -5409
    y_6_8_3   disj1_6_8_3  5409
    y_6_8_3   disj2_6_8_3  -5409
    y_6_8_4   disj1_6_8_4  5409
    y_6_8_4   disj2_6_8_4  -5409
    y_6_8_5   disj1_6_8_5  5409
    y_6_8_5   disj2_6_8_5  -5409
    y_6_8_6   disj1_6_8_6  5409
    y_6_8_6   disj2_6_8_6  -5409
    y_6_8_7   disj1_6_8_7  5409
    y_6_8_7   disj2_6_8_7  -5409
    y_6_8_8   disj1_6_8_8  5409
    y_6_8_8   disj2_6_8_8  -5409
    y_6_8_9   disj1_6_8_9  5409
    y_6_8_9   disj2_6_8_9  -5409
    y_6_9_0   disj1_6_9_0  5409
    y_6_9_0   disj2_6_9_0  -5409
    y_6_9_1   disj1_6_9_1  5409
    y_6_9_1   disj2_6_9_1  -5409
    y_6_9_2   disj1_6_9_2  5409
    y_6_9_2   disj2_6_9_2  -5409
    y_6_9_3   disj1_6_9_3  5409
    y_6_9_3   disj2_6_9_3  -5409
    y_6_9_4   disj1_6_9_4  5409
    y_6_9_4   disj2_6_9_4  -5409
    y_6_9_5   disj1_6_9_5  5409
    y_6_9_5   disj2_6_9_5  -5409
    y_6_9_6   disj1_6_9_6  5409
    y_6_9_6   disj2_6_9_6  -5409
    y_6_9_7   disj1_6_9_7  5409
    y_6_9_7   disj2_6_9_7  -5409
    y_6_9_8   disj1_6_9_8  5409
    y_6_9_8   disj2_6_9_8  -5409
    y_6_9_9   disj1_6_9_9  5409
    y_6_9_9   disj2_6_9_9  -5409
    y_7_8_0   disj1_7_8_0  5409
    y_7_8_0   disj2_7_8_0  -5409
    y_7_8_1   disj1_7_8_1  5409
    y_7_8_1   disj2_7_8_1  -5409
    y_7_8_2   disj1_7_8_2  5409
    y_7_8_2   disj2_7_8_2  -5409
    y_7_8_3   disj1_7_8_3  5409
    y_7_8_3   disj2_7_8_3  -5409
    y_7_8_4   disj1_7_8_4  5409
    y_7_8_4   disj2_7_8_4  -5409
    y_7_8_5   disj1_7_8_5  5409
    y_7_8_5   disj2_7_8_5  -5409
    y_7_8_6   disj1_7_8_6  5409
    y_7_8_6   disj2_7_8_6  -5409
    y_7_8_7   disj1_7_8_7  5409
    y_7_8_7   disj2_7_8_7  -5409
    y_7_8_8   disj1_7_8_8  5409
    y_7_8_8   disj2_7_8_8  -5409
    y_7_8_9   disj1_7_8_9  5409
    y_7_8_9   disj2_7_8_9  -5409
    y_7_9_0   disj1_7_9_0  5409
    y_7_9_0   disj2_7_9_0  -5409
    y_7_9_1   disj1_7_9_1  5409
    y_7_9_1   disj2_7_9_1  -5409
    y_7_9_2   disj1_7_9_2  5409
    y_7_9_2   disj2_7_9_2  -5409
    y_7_9_3   disj1_7_9_3  5409
    y_7_9_3   disj2_7_9_3  -5409
    y_7_9_4   disj1_7_9_4  5409
    y_7_9_4   disj2_7_9_4  -5409
    y_7_9_5   disj1_7_9_5  5409
    y_7_9_5   disj2_7_9_5  -5409
    y_7_9_6   disj1_7_9_6  5409
    y_7_9_6   disj2_7_9_6  -5409
    y_7_9_7   disj1_7_9_7  5409
    y_7_9_7   disj2_7_9_7  -5409
    y_7_9_8   disj1_7_9_8  5409
    y_7_9_8   disj2_7_9_8  -5409
    y_7_9_9   disj1_7_9_9  5409
    y_7_9_9   disj2_7_9_9  -5409
    y_8_9_0   disj1_8_9_0  5409
    y_8_9_0   disj2_8_9_0  -5409
    y_8_9_1   disj1_8_9_1  5409
    y_8_9_1   disj2_8_9_1  -5409
    y_8_9_2   disj1_8_9_2  5409
    y_8_9_2   disj2_8_9_2  -5409
    y_8_9_3   disj1_8_9_3  5409
    y_8_9_3   disj2_8_9_3  -5409
    y_8_9_4   disj1_8_9_4  5409
    y_8_9_4   disj2_8_9_4  -5409
    y_8_9_5   disj1_8_9_5  5409
    y_8_9_5   disj2_8_9_5  -5409
    y_8_9_6   disj1_8_9_6  5409
    y_8_9_6   disj2_8_9_6  -5409
    y_8_9_7   disj1_8_9_7  5409
    y_8_9_7   disj2_8_9_7  -5409
    y_8_9_8   disj1_8_9_8  5409
    y_8_9_8   disj2_8_9_8  -5409
    y_8_9_9   disj1_8_9_9  5409
    y_8_9_9   disj2_8_9_9  -5409
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  72
    RHS       prec_0_1  64
    RHS       prec_0_2  55
    RHS       prec_0_3  31
    RHS       prec_0_4  53
    RHS       prec_0_5  95
    RHS       prec_0_6  11
    RHS       prec_0_7  52
    RHS       prec_0_8  6
    RHS       prec_1_0  61
    RHS       prec_1_1  27
    RHS       prec_1_2  88
    RHS       prec_1_3  78
    RHS       prec_1_4  49
    RHS       prec_1_5  83
    RHS       prec_1_6  91
    RHS       prec_1_7  74
    RHS       prec_1_8  29
    RHS       prec_2_0  86
    RHS       prec_2_1  32
    RHS       prec_2_2  35
    RHS       prec_2_3  37
    RHS       prec_2_4  18
    RHS       prec_2_5  48
    RHS       prec_2_6  91
    RHS       prec_2_7  52
    RHS       prec_2_8  60
    RHS       prec_3_0  8
    RHS       prec_3_1  82
    RHS       prec_3_2  27
    RHS       prec_3_3  99
    RHS       prec_3_4  74
    RHS       prec_3_5  9
    RHS       prec_3_6  33
    RHS       prec_3_7  20
    RHS       prec_3_8  59
    RHS       prec_4_0  50
    RHS       prec_4_1  94
    RHS       prec_4_2  43
    RHS       prec_4_3  62
    RHS       prec_4_4  55
    RHS       prec_4_5  48
    RHS       prec_4_6  5
    RHS       prec_4_7  36
    RHS       prec_4_8  47
    RHS       prec_5_0  53
    RHS       prec_5_1  30
    RHS       prec_5_2  7
    RHS       prec_5_3  12
    RHS       prec_5_4  68
    RHS       prec_5_5  87
    RHS       prec_5_6  28
    RHS       prec_5_7  70
    RHS       prec_5_8  45
    RHS       prec_6_0  29
    RHS       prec_6_1  96
    RHS       prec_6_2  99
    RHS       prec_6_3  14
    RHS       prec_6_4  34
    RHS       prec_6_5  14
    RHS       prec_6_6  7
    RHS       prec_6_7  76
    RHS       prec_6_8  57
    RHS       prec_7_0  90
    RHS       prec_7_1  19
    RHS       prec_7_2  87
    RHS       prec_7_3  51
    RHS       prec_7_4  84
    RHS       prec_7_5  45
    RHS       prec_7_6  84
    RHS       prec_7_7  58
    RHS       prec_7_8  81
    RHS       prec_8_0  97
    RHS       prec_8_1  99
    RHS       prec_8_2  93
    RHS       prec_8_3  38
    RHS       prec_8_4  13
    RHS       prec_8_5  96
    RHS       prec_8_6  40
    RHS       prec_8_7  64
    RHS       prec_8_8  32
    RHS       prec_9_0  44
    RHS       prec_9_1  60
    RHS       prec_9_2  29
    RHS       prec_9_3  5
    RHS       prec_9_4  74
    RHS       prec_9_5  85
    RHS       prec_9_6  34
    RHS       prec_9_7  95
    RHS       prec_9_8  51
    RHS       mksp_0    84
    RHS       mksp_1    87
    RHS       mksp_2    30
    RHS       mksp_3    98
    RHS       mksp_4    36
    RHS       mksp_5    7
    RHS       mksp_6    76
    RHS       mksp_7    96
    RHS       mksp_8    45
    RHS       mksp_9    47
    RHS       disj1_0_1_0  72
    RHS       disj2_0_1_0  -5348
    RHS       disj1_0_2_0  72
    RHS       disj2_0_2_0  -5323
    RHS       disj1_0_3_0  72
    RHS       disj2_0_3_0  -5401
    RHS       disj1_0_4_0  72
    RHS       disj2_0_4_0  -5315
    RHS       disj1_0_5_0  72
    RHS       disj2_0_5_0  -5356
    RHS       disj1_0_6_0  72
    RHS       disj2_0_6_0  -5310
    RHS       disj1_0_7_0  72
    RHS       disj2_0_7_0  -5390
    RHS       disj1_0_8_0  72
    RHS       disj2_0_8_0  -5371
    RHS       disj1_0_9_0  72
    RHS       disj2_0_9_0  -5349
    RHS       disj1_1_2_0  61
    RHS       disj2_1_2_0  -5323
    RHS       disj1_1_3_0  61
    RHS       disj2_1_3_0  -5401
    RHS       disj1_1_4_0  61
    RHS       disj2_1_4_0  -5315
    RHS       disj1_1_5_0  61
    RHS       disj2_1_5_0  -5356
    RHS       disj1_1_6_0  61
    RHS       disj2_1_6_0  -5310
    RHS       disj1_1_7_0  61
    RHS       disj2_1_7_0  -5390
    RHS       disj1_1_8_0  61
    RHS       disj2_1_8_0  -5371
    RHS       disj1_1_9_0  61
    RHS       disj2_1_9_0  -5349
    RHS       disj1_2_3_0  86
    RHS       disj2_2_3_0  -5401
    RHS       disj1_2_4_0  86
    RHS       disj2_2_4_0  -5315
    RHS       disj1_2_5_0  86
    RHS       disj2_2_5_0  -5356
    RHS       disj1_2_6_0  86
    RHS       disj2_2_6_0  -5310
    RHS       disj1_2_7_0  86
    RHS       disj2_2_7_0  -5390
    RHS       disj1_2_8_0  86
    RHS       disj2_2_8_0  -5371
    RHS       disj1_2_9_0  86
    RHS       disj2_2_9_0  -5349
    RHS       disj1_3_4_0  8
    RHS       disj2_3_4_0  -5315
    RHS       disj1_3_5_0  8
    RHS       disj2_3_5_0  -5356
    RHS       disj1_3_6_0  8
    RHS       disj2_3_6_0  -5310
    RHS       disj1_3_7_0  8
    RHS       disj2_3_7_0  -5390
    RHS       disj1_3_8_0  8
    RHS       disj2_3_8_0  -5371
    RHS       disj1_3_9_0  8
    RHS       disj2_3_9_0  -5349
    RHS       disj1_4_5_0  94
    RHS       disj2_4_5_0  -5356
    RHS       disj1_4_6_0  94
    RHS       disj2_4_6_0  -5310
    RHS       disj1_4_7_0  94
    RHS       disj2_4_7_0  -5390
    RHS       disj1_4_8_0  94
    RHS       disj2_4_8_0  -5371
    RHS       disj1_4_9_0  94
    RHS       disj2_4_9_0  -5349
    RHS       disj1_5_6_0  53
    RHS       disj2_5_6_0  -5310
    RHS       disj1_5_7_0  53
    RHS       disj2_5_7_0  -5390
    RHS       disj1_5_8_0  53
    RHS       disj2_5_8_0  -5371
    RHS       disj1_5_9_0  53
    RHS       disj2_5_9_0  -5349
    RHS       disj1_6_7_0  99
    RHS       disj2_6_7_0  -5390
    RHS       disj1_6_8_0  99
    RHS       disj2_6_8_0  -5371
    RHS       disj1_6_9_0  99
    RHS       disj2_6_9_0  -5349
    RHS       disj1_7_8_0  19
    RHS       disj2_7_8_0  -5371
    RHS       disj1_7_9_0  19
    RHS       disj2_7_9_0  -5349
    RHS       disj1_8_9_0  38
    RHS       disj2_8_9_0  -5349
    RHS       disj1_0_1_1  64
    RHS       disj2_0_1_1  -5360
    RHS       disj1_0_2_1  64
    RHS       disj2_0_2_1  -5374
    RHS       disj1_0_3_1  64
    RHS       disj2_0_3_1  -5327
    RHS       disj1_0_4_1  64
    RHS       disj2_0_4_1  -5359
    RHS       disj1_0_5_1  64
    RHS       disj2_0_5_1  -5341
    RHS       disj1_0_6_1  64
    RHS       disj2_0_6_1  -5395
    RHS       disj1_0_7_1  64
    RHS       disj2_0_7_1  -5325
    RHS       disj1_0_8_1  64
    RHS       disj2_0_8_1  -5310
    RHS       disj1_0_9_1  64
    RHS       disj2_0_9_1  -5324
    RHS       disj1_1_2_1  49
    RHS       disj2_1_2_1  -5374
    RHS       disj1_1_3_1  49
    RHS       disj2_1_3_1  -5327
    RHS       disj1_1_4_1  49
    RHS       disj2_1_4_1  -5359
    RHS       disj1_1_5_1  49
    RHS       disj2_1_5_1  -5341
    RHS       disj1_1_6_1  49
    RHS       disj2_1_6_1  -5395
    RHS       disj1_1_7_1  49
    RHS       disj2_1_7_1  -5325
    RHS       disj1_1_8_1  49
    RHS       disj2_1_8_1  -5310
    RHS       disj1_1_9_1  49
    RHS       disj2_1_9_1  -5324
    RHS       disj1_2_3_1  35
    RHS       disj2_2_3_1  -5327
    RHS       disj1_2_4_1  35
    RHS       disj2_2_4_1  -5359
    RHS       disj1_2_5_1  35
    RHS       disj2_2_5_1  -5341
    RHS       disj1_2_6_1  35
    RHS       disj2_2_6_1  -5395
    RHS       disj1_2_7_1  35
    RHS       disj2_2_7_1  -5325
    RHS       disj1_2_8_1  35
    RHS       disj2_2_8_1  -5310
    RHS       disj1_2_9_1  35
    RHS       disj2_2_9_1  -5324
    RHS       disj1_3_4_1  82
    RHS       disj2_3_4_1  -5359
    RHS       disj1_3_5_1  82
    RHS       disj2_3_5_1  -5341
    RHS       disj1_3_6_1  82
    RHS       disj2_3_6_1  -5395
    RHS       disj1_3_7_1  82
    RHS       disj2_3_7_1  -5325
    RHS       disj1_3_8_1  82
    RHS       disj2_3_8_1  -5310
    RHS       disj1_3_9_1  82
    RHS       disj2_3_9_1  -5324
    RHS       disj1_4_5_1  50
    RHS       disj2_4_5_1  -5341
    RHS       disj1_4_6_1  50
    RHS       disj2_4_6_1  -5395
    RHS       disj1_4_7_1  50
    RHS       disj2_4_7_1  -5325
    RHS       disj1_4_8_1  50
    RHS       disj2_4_8_1  -5310
    RHS       disj1_4_9_1  50
    RHS       disj2_4_9_1  -5324
    RHS       disj1_5_6_1  68
    RHS       disj2_5_6_1  -5395
    RHS       disj1_5_7_1  68
    RHS       disj2_5_7_1  -5325
    RHS       disj1_5_8_1  68
    RHS       disj2_5_8_1  -5310
    RHS       disj1_5_9_1  68
    RHS       disj2_5_9_1  -5324
    RHS       disj1_6_7_1  14
    RHS       disj2_6_7_1  -5325
    RHS       disj1_6_8_1  14
    RHS       disj2_6_8_1  -5310
    RHS       disj1_6_9_1  14
    RHS       disj2_6_9_1  -5324
    RHS       disj1_7_8_1  84
    RHS       disj2_7_8_1  -5310
    RHS       disj1_7_9_1  84
    RHS       disj2_7_9_1  -5324
    RHS       disj1_8_9_1  99
    RHS       disj2_8_9_1  -5324
    RHS       disj1_0_1_2  55
    RHS       disj2_0_1_2  -5331
    RHS       disj1_0_2_2  55
    RHS       disj2_0_2_2  -5372
    RHS       disj1_0_3_2  55
    RHS       disj2_0_3_2  -5376
    RHS       disj1_0_4_2  55
    RHS       disj2_0_4_2  -5404
    RHS       disj1_0_5_2  55
    RHS       disj2_0_5_2  -5402
    RHS       disj1_0_6_2  55
    RHS       disj2_0_6_2  -5380
    RHS       disj1_0_7_2  55
    RHS       disj2_0_7_2  -5319
    RHS       disj1_0_8_2  55
    RHS       disj2_0_8_2  -5312
    RHS       disj1_0_9_2  55
    RHS       disj2_0_9_2  -5365
    RHS       disj1_1_2_2  78
    RHS       disj2_1_2_2  -5372
    RHS       disj1_1_3_2  78
    RHS       disj2_1_3_2  -5376
    RHS       disj1_1_4_2  78
    RHS       disj2_1_4_2  -5404
    RHS       disj1_1_5_2  78
    RHS       disj2_1_5_2  -5402
    RHS       disj1_1_6_2  78
    RHS       disj2_1_6_2  -5380
    RHS       disj1_1_7_2  78
    RHS       disj2_1_7_2  -5319
    RHS       disj1_1_8_2  78
    RHS       disj2_1_8_2  -5312
    RHS       disj1_1_9_2  78
    RHS       disj2_1_9_2  -5365
    RHS       disj1_2_3_2  37
    RHS       disj2_2_3_2  -5376
    RHS       disj1_2_4_2  37
    RHS       disj2_2_4_2  -5404
    RHS       disj1_2_5_2  37
    RHS       disj2_2_5_2  -5402
    RHS       disj1_2_6_2  37
    RHS       disj2_2_6_2  -5380
    RHS       disj1_2_7_2  37
    RHS       disj2_2_7_2  -5319
    RHS       disj1_2_8_2  37
    RHS       disj2_2_8_2  -5312
    RHS       disj1_2_9_2  37
    RHS       disj2_2_9_2  -5365
    RHS       disj1_3_4_2  33
    RHS       disj2_3_4_2  -5404
    RHS       disj1_3_5_2  33
    RHS       disj2_3_5_2  -5402
    RHS       disj1_3_6_2  33
    RHS       disj2_3_6_2  -5380
    RHS       disj1_3_7_2  33
    RHS       disj2_3_7_2  -5319
    RHS       disj1_3_8_2  33
    RHS       disj2_3_8_2  -5312
    RHS       disj1_3_9_2  33
    RHS       disj2_3_9_2  -5365
    RHS       disj1_4_5_2  5
    RHS       disj2_4_5_2  -5402
    RHS       disj1_4_6_2  5
    RHS       disj2_4_6_2  -5380
    RHS       disj1_4_7_2  5
    RHS       disj2_4_7_2  -5319
    RHS       disj1_4_8_2  5
    RHS       disj2_4_8_2  -5312
    RHS       disj1_4_9_2  5
    RHS       disj2_4_9_2  -5365
    RHS       disj1_5_6_2  7
    RHS       disj2_5_6_2  -5380
    RHS       disj1_5_7_2  7
    RHS       disj2_5_7_2  -5319
    RHS       disj1_5_8_2  7
    RHS       disj2_5_8_2  -5312
    RHS       disj1_5_9_2  7
    RHS       disj2_5_9_2  -5365
    RHS       disj1_6_7_2  29
    RHS       disj2_6_7_2  -5319
    RHS       disj1_6_8_2  29
    RHS       disj2_6_8_2  -5312
    RHS       disj1_6_9_2  29
    RHS       disj2_6_9_2  -5365
    RHS       disj1_7_8_2  90
    RHS       disj2_7_8_2  -5312
    RHS       disj1_7_9_2  90
    RHS       disj2_7_9_2  -5365
    RHS       disj1_8_9_2  97
    RHS       disj2_8_9_2  -5365
    RHS       disj1_0_1_3  31
    RHS       disj2_0_1_3  -5382
    RHS       disj1_0_2_3  31
    RHS       disj2_0_2_3  -5377
    RHS       disj1_0_3_3  31
    RHS       disj2_0_3_3  -5310
    RHS       disj1_0_4_3  31
    RHS       disj2_0_4_3  -5347
    RHS       disj1_0_5_3  31
    RHS       disj2_0_5_3  -5397
    RHS       disj1_0_6_3  31
    RHS       disj2_0_6_3  -5313
    RHS       disj1_0_7_3  31
    RHS       disj2_0_7_3  -5322
    RHS       disj1_0_8_3  31
    RHS       disj2_0_8_3  -5369
    RHS       disj1_0_9_3  31
    RHS       disj2_0_9_3  -5404
    RHS       disj1_1_2_3  27
    RHS       disj2_1_2_3  -5377
    RHS       disj1_1_3_3  27
    RHS       disj2_1_3_3  -5310
    RHS       disj1_1_4_3  27
    RHS       disj2_1_4_3  -5347
    RHS       disj1_1_5_3  27
    RHS       disj2_1_5_3  -5397
    RHS       disj1_1_6_3  27
    RHS       disj2_1_6_3  -5313
    RHS       disj1_1_7_3  27
    RHS       disj2_1_7_3  -5322
    RHS       disj1_1_8_3  27
    RHS       disj2_1_8_3  -5369
    RHS       disj1_1_9_3  27
    RHS       disj2_1_9_3  -5404
    RHS       disj1_2_3_3  32
    RHS       disj2_2_3_3  -5310
    RHS       disj1_2_4_3  32
    RHS       disj2_2_4_3  -5347
    RHS       disj1_2_5_3  32
    RHS       disj2_2_5_3  -5397
    RHS       disj1_2_6_3  32
    RHS       disj2_2_6_3  -5313
    RHS       disj1_2_7_3  32
    RHS       disj2_2_7_3  -5322
    RHS       disj1_2_8_3  32
    RHS       disj2_2_8_3  -5369
    RHS       disj1_2_9_3  32
    RHS       disj2_2_9_3  -5404
    RHS       disj1_3_4_3  99
    RHS       disj2_3_4_3  -5347
    RHS       disj1_3_5_3  99
    RHS       disj2_3_5_3  -5397
    RHS       disj1_3_6_3  99
    RHS       disj2_3_6_3  -5313
    RHS       disj1_3_7_3  99
    RHS       disj2_3_7_3  -5322
    RHS       disj1_3_8_3  99
    RHS       disj2_3_8_3  -5369
    RHS       disj1_3_9_3  99
    RHS       disj2_3_9_3  -5404
    RHS       disj1_4_5_3  62
    RHS       disj2_4_5_3  -5397
    RHS       disj1_4_6_3  62
    RHS       disj2_4_6_3  -5313
    RHS       disj1_4_7_3  62
    RHS       disj2_4_7_3  -5322
    RHS       disj1_4_8_3  62
    RHS       disj2_4_8_3  -5369
    RHS       disj1_4_9_3  62
    RHS       disj2_4_9_3  -5404
    RHS       disj1_5_6_3  12
    RHS       disj2_5_6_3  -5313
    RHS       disj1_5_7_3  12
    RHS       disj2_5_7_3  -5322
    RHS       disj1_5_8_3  12
    RHS       disj2_5_8_3  -5369
    RHS       disj1_5_9_3  12
    RHS       disj2_5_9_3  -5404
    RHS       disj1_6_7_3  96
    RHS       disj2_6_7_3  -5322
    RHS       disj1_6_8_3  96
    RHS       disj2_6_8_3  -5369
    RHS       disj1_6_9_3  96
    RHS       disj2_6_9_3  -5404
    RHS       disj1_7_8_3  87
    RHS       disj2_7_8_3  -5369
    RHS       disj1_7_9_3  87
    RHS       disj2_7_9_3  -5404
    RHS       disj1_8_9_3  40
    RHS       disj2_8_9_3  -5404
    RHS       disj1_0_1_4  53
    RHS       disj2_0_1_4  -5321
    RHS       disj1_0_2_4  53
    RHS       disj2_0_2_4  -5361
    RHS       disj1_0_3_4  53
    RHS       disj2_0_3_4  -5382
    RHS       disj1_0_4_4  53
    RHS       disj2_0_4_4  -5354
    RHS       disj1_0_5_4  53
    RHS       disj2_0_5_4  -5381
    RHS       disj1_0_6_4  53
    RHS       disj2_0_6_4  -5375
    RHS       disj1_0_7_4  53
    RHS       disj2_0_7_4  -5358
    RHS       disj1_0_8_4  53
    RHS       disj2_0_8_4  -5316
    RHS       disj1_0_9_4  53
    RHS       disj2_0_9_4  -5375
    RHS       disj1_1_2_4  88
    RHS       disj2_1_2_4  -5361
    RHS       disj1_1_3_4  88
    RHS       disj2_1_3_4  -5382
    RHS       disj1_1_4_4  88
    RHS       disj2_1_4_4  -5354
    RHS       disj1_1_5_4  88
    RHS       disj2_1_5_4  -5381
    RHS       disj1_1_6_4  88
    RHS       disj2_1_6_4  -5375
    RHS       disj1_1_7_4  88
    RHS       disj2_1_7_4  -5358
    RHS       disj1_1_8_4  88
    RHS       disj2_1_8_4  -5316
    RHS       disj1_1_9_4  88
    RHS       disj2_1_9_4  -5375
    RHS       disj1_2_3_4  48
    RHS       disj2_2_3_4  -5382
    RHS       disj1_2_4_4  48
    RHS       disj2_2_4_4  -5354
    RHS       disj1_2_5_4  48
    RHS       disj2_2_5_4  -5381
    RHS       disj1_2_6_4  48
    RHS       disj2_2_6_4  -5375
    RHS       disj1_2_7_4  48
    RHS       disj2_2_7_4  -5358
    RHS       disj1_2_8_4  48
    RHS       disj2_2_8_4  -5316
    RHS       disj1_2_9_4  48
    RHS       disj2_2_9_4  -5375
    RHS       disj1_3_4_4  27
    RHS       disj2_3_4_4  -5354
    RHS       disj1_3_5_4  27
    RHS       disj2_3_5_4  -5381
    RHS       disj1_3_6_4  27
    RHS       disj2_3_6_4  -5375
    RHS       disj1_3_7_4  27
    RHS       disj2_3_7_4  -5358
    RHS       disj1_3_8_4  27
    RHS       disj2_3_8_4  -5316
    RHS       disj1_3_9_4  27
    RHS       disj2_3_9_4  -5375
    RHS       disj1_4_5_4  55
    RHS       disj2_4_5_4  -5381
    RHS       disj1_4_6_4  55
    RHS       disj2_4_6_4  -5375
    RHS       disj1_4_7_4  55
    RHS       disj2_4_7_4  -5358
    RHS       disj1_4_8_4  55
    RHS       disj2_4_8_4  -5316
    RHS       disj1_4_9_4  55
    RHS       disj2_4_9_4  -5375
    RHS       disj1_5_6_4  28
    RHS       disj2_5_6_4  -5375
    RHS       disj1_5_7_4  28
    RHS       disj2_5_7_4  -5358
    RHS       disj1_5_8_4  28
    RHS       disj2_5_8_4  -5316
    RHS       disj1_5_9_4  28
    RHS       disj2_5_9_4  -5375
    RHS       disj1_6_7_4  34
    RHS       disj2_6_7_4  -5358
    RHS       disj1_6_8_4  34
    RHS       disj2_6_8_4  -5316
    RHS       disj1_6_9_4  34
    RHS       disj2_6_9_4  -5375
    RHS       disj1_7_8_4  51
    RHS       disj2_7_8_4  -5316
    RHS       disj1_7_9_4  51
    RHS       disj2_7_9_4  -5375
    RHS       disj1_8_9_4  93
    RHS       disj2_8_9_4  -5375
    RHS       disj1_0_1_5  95
    RHS       disj2_0_1_5  -5326
    RHS       disj1_0_2_5  95
    RHS       disj2_0_2_5  -5391
    RHS       disj1_0_3_5  95
    RHS       disj2_0_3_5  -5400
    RHS       disj1_0_4_5  95
    RHS       disj2_0_4_5  -5366
    RHS       disj1_0_5_5  95
    RHS       disj2_0_5_5  -5402
    RHS       disj1_0_6_5  95
    RHS       disj2_0_6_5  -5402
    RHS       disj1_0_7_5  95
    RHS       disj2_0_7_5  -5364
    RHS       disj1_0_8_5  95
    RHS       disj2_0_8_5  -5313
    RHS       disj1_0_9_5  95
    RHS       disj2_0_9_5  -5362
    RHS       disj1_1_2_5  83
    RHS       disj2_1_2_5  -5391
    RHS       disj1_1_3_5  83
    RHS       disj2_1_3_5  -5400
    RHS       disj1_1_4_5  83
    RHS       disj2_1_4_5  -5366
    RHS       disj1_1_5_5  83
    RHS       disj2_1_5_5  -5402
    RHS       disj1_1_6_5  83
    RHS       disj2_1_6_5  -5402
    RHS       disj1_1_7_5  83
    RHS       disj2_1_7_5  -5364
    RHS       disj1_1_8_5  83
    RHS       disj2_1_8_5  -5313
    RHS       disj1_1_9_5  83
    RHS       disj2_1_9_5  -5362
    RHS       disj1_2_3_5  18
    RHS       disj2_2_3_5  -5400
    RHS       disj1_2_4_5  18
    RHS       disj2_2_4_5  -5366
    RHS       disj1_2_5_5  18
    RHS       disj2_2_5_5  -5402
    RHS       disj1_2_6_5  18
    RHS       disj2_2_6_5  -5402
    RHS       disj1_2_7_5  18
    RHS       disj2_2_7_5  -5364
    RHS       disj1_2_8_5  18
    RHS       disj2_2_8_5  -5313
    RHS       disj1_2_9_5  18
    RHS       disj2_2_9_5  -5362
    RHS       disj1_3_4_5  9
    RHS       disj2_3_4_5  -5366
    RHS       disj1_3_5_5  9
    RHS       disj2_3_5_5  -5402
    RHS       disj1_3_6_5  9
    RHS       disj2_3_6_5  -5402
    RHS       disj1_3_7_5  9
    RHS       disj2_3_7_5  -5364
    RHS       disj1_3_8_5  9
    RHS       disj2_3_8_5  -5313
    RHS       disj1_3_9_5  9
    RHS       disj2_3_9_5  -5362
    RHS       disj1_4_5_5  43
    RHS       disj2_4_5_5  -5402
    RHS       disj1_4_6_5  43
    RHS       disj2_4_6_5  -5402
    RHS       disj1_4_7_5  43
    RHS       disj2_4_7_5  -5364
    RHS       disj1_4_8_5  43
    RHS       disj2_4_8_5  -5313
    RHS       disj1_4_9_5  43
    RHS       disj2_4_9_5  -5362
    RHS       disj1_5_6_5  7
    RHS       disj2_5_6_5  -5402
    RHS       disj1_5_7_5  7
    RHS       disj2_5_7_5  -5364
    RHS       disj1_5_8_5  7
    RHS       disj2_5_8_5  -5313
    RHS       disj1_5_9_5  7
    RHS       disj2_5_9_5  -5362
    RHS       disj1_6_7_5  7
    RHS       disj2_6_7_5  -5364
    RHS       disj1_6_8_5  7
    RHS       disj2_6_8_5  -5313
    RHS       disj1_6_9_5  7
    RHS       disj2_6_9_5  -5362
    RHS       disj1_7_8_5  45
    RHS       disj2_7_8_5  -5313
    RHS       disj1_7_9_5  45
    RHS       disj2_7_9_5  -5362
    RHS       disj1_8_9_5  96
    RHS       disj2_8_9_5  -5362
    RHS       disj1_0_1_6  11
    RHS       disj2_0_1_6  -5335
    RHS       disj1_0_2_6  11
    RHS       disj2_0_2_6  -5318
    RHS       disj1_0_3_6  11
    RHS       disj2_0_3_6  -5335
    RHS       disj1_0_4_6  11
    RHS       disj2_0_4_6  -5373
    RHS       disj1_0_5_6  11
    RHS       disj2_0_5_6  -5379
    RHS       disj1_0_6_6  11
    RHS       disj2_0_6_6  -5333
    RHS       disj1_0_7_6  11
    RHS       disj2_0_7_6  -5351
    RHS       disj1_0_8_6  11
    RHS       disj2_0_8_6  -5377
    RHS       disj1_0_9_6  11
    RHS       disj2_0_9_6  -5335
    RHS       disj1_1_2_6  74
    RHS       disj2_1_2_6  -5318
    RHS       disj1_1_3_6  74
    RHS       disj2_1_3_6  -5335
    RHS       disj1_1_4_6  74
    RHS       disj2_1_4_6  -5373
    RHS       disj1_1_5_6  74
    RHS       disj2_1_5_6  -5379
    RHS       disj1_1_6_6  74
    RHS       disj2_1_6_6  -5333
    RHS       disj1_1_7_6  74
    RHS       disj2_1_7_6  -5351
    RHS       disj1_1_8_6  74
    RHS       disj2_1_8_6  -5377
    RHS       disj1_1_9_6  74
    RHS       disj2_1_9_6  -5335
    RHS       disj1_2_3_6  91
    RHS       disj2_2_3_6  -5335
    RHS       disj1_2_4_6  91
    RHS       disj2_2_4_6  -5373
    RHS       disj1_2_5_6  91
    RHS       disj2_2_5_6  -5379
    RHS       disj1_2_6_6  91
    RHS       disj2_2_6_6  -5333
    RHS       disj1_2_7_6  91
    RHS       disj2_2_7_6  -5351
    RHS       disj1_2_8_6  91
    RHS       disj2_2_8_6  -5377
    RHS       disj1_2_9_6  91
    RHS       disj2_2_9_6  -5335
    RHS       disj1_3_4_6  74
    RHS       disj2_3_4_6  -5373
    RHS       disj1_3_5_6  74
    RHS       disj2_3_5_6  -5379
    RHS       disj1_3_6_6  74
    RHS       disj2_3_6_6  -5333
    RHS       disj1_3_7_6  74
    RHS       disj2_3_7_6  -5351
    RHS       disj1_3_8_6  74
    RHS       disj2_3_8_6  -5377
    RHS       disj1_3_9_6  74
    RHS       disj2_3_9_6  -5335
    RHS       disj1_4_5_6  36
    RHS       disj2_4_5_6  -5379
    RHS       disj1_4_6_6  36
    RHS       disj2_4_6_6  -5333
    RHS       disj1_4_7_6  36
    RHS       disj2_4_7_6  -5351
    RHS       disj1_4_8_6  36
    RHS       disj2_4_8_6  -5377
    RHS       disj1_4_9_6  36
    RHS       disj2_4_9_6  -5335
    RHS       disj1_5_6_6  30
    RHS       disj2_5_6_6  -5333
    RHS       disj1_5_7_6  30
    RHS       disj2_5_7_6  -5351
    RHS       disj1_5_8_6  30
    RHS       disj2_5_8_6  -5377
    RHS       disj1_5_9_6  30
    RHS       disj2_5_9_6  -5335
    RHS       disj1_6_7_6  76
    RHS       disj2_6_7_6  -5351
    RHS       disj1_6_8_6  76
    RHS       disj2_6_8_6  -5377
    RHS       disj1_6_9_6  76
    RHS       disj2_6_9_6  -5335
    RHS       disj1_7_8_6  58
    RHS       disj2_7_8_6  -5377
    RHS       disj1_7_9_6  58
    RHS       disj2_7_9_6  -5335
    RHS       disj1_8_9_6  32
    RHS       disj2_8_9_6  -5335
    RHS       disj1_0_1_7  52
    RHS       disj2_0_1_7  -5380
    RHS       disj1_0_2_7  52
    RHS       disj2_0_2_7  -5357
    RHS       disj1_0_3_7  52
    RHS       disj2_0_3_7  -5350
    RHS       disj1_0_4_7  52
    RHS       disj2_0_4_7  -5361
    RHS       disj1_0_5_7  52
    RHS       disj2_0_5_7  -5364
    RHS       disj1_0_6_7  52
    RHS       disj2_0_6_7  -5395
    RHS       disj1_0_7_7  52
    RHS       disj2_0_7_7  -5328
    RHS       disj1_0_8_7  52
    RHS       disj2_0_8_7  -5396
    RHS       disj1_0_9_7  52
    RHS       disj2_0_9_7  -5314
    RHS       disj1_1_2_7  29
    RHS       disj2_1_2_7  -5357
    RHS       disj1_1_3_7  29
    RHS       disj2_1_3_7  -5350
    RHS       disj1_1_4_7  29
    RHS       disj2_1_4_7  -5361
    RHS       disj1_1_5_7  29
    RHS       disj2_1_5_7  -5364
    RHS       disj1_1_6_7  29
    RHS       disj2_1_6_7  -5395
    RHS       disj1_1_7_7  29
    RHS       disj2_1_7_7  -5328
    RHS       disj1_1_8_7  29
    RHS       disj2_1_8_7  -5396
    RHS       disj1_1_9_7  29
    RHS       disj2_1_9_7  -5314
    RHS       disj1_2_3_7  52
    RHS       disj2_2_3_7  -5350
    RHS       disj1_2_4_7  52
    RHS       disj2_2_4_7  -5361
    RHS       disj1_2_5_7  52
    RHS       disj2_2_5_7  -5364
    RHS       disj1_2_6_7  52
    RHS       disj2_2_6_7  -5395
    RHS       disj1_2_7_7  52
    RHS       disj2_2_7_7  -5328
    RHS       disj1_2_8_7  52
    RHS       disj2_2_8_7  -5396
    RHS       disj1_2_9_7  52
    RHS       disj2_2_9_7  -5314
    RHS       disj1_3_4_7  59
    RHS       disj2_3_4_7  -5361
    RHS       disj1_3_5_7  59
    RHS       disj2_3_5_7  -5364
    RHS       disj1_3_6_7  59
    RHS       disj2_3_6_7  -5395
    RHS       disj1_3_7_7  59
    RHS       disj2_3_7_7  -5328
    RHS       disj1_3_8_7  59
    RHS       disj2_3_8_7  -5396
    RHS       disj1_3_9_7  59
    RHS       disj2_3_9_7  -5314
    RHS       disj1_4_5_7  48
    RHS       disj2_4_5_7  -5364
    RHS       disj1_4_6_7  48
    RHS       disj2_4_6_7  -5395
    RHS       disj1_4_7_7  48
    RHS       disj2_4_7_7  -5328
    RHS       disj1_4_8_7  48
    RHS       disj2_4_8_7  -5396
    RHS       disj1_4_9_7  48
    RHS       disj2_4_9_7  -5314
    RHS       disj1_5_6_7  45
    RHS       disj2_5_6_7  -5395
    RHS       disj1_5_7_7  45
    RHS       disj2_5_7_7  -5328
    RHS       disj1_5_8_7  45
    RHS       disj2_5_8_7  -5396
    RHS       disj1_5_9_7  45
    RHS       disj2_5_9_7  -5314
    RHS       disj1_6_7_7  14
    RHS       disj2_6_7_7  -5328
    RHS       disj1_6_8_7  14
    RHS       disj2_6_8_7  -5396
    RHS       disj1_6_9_7  14
    RHS       disj2_6_9_7  -5314
    RHS       disj1_7_8_7  81
    RHS       disj2_7_8_7  -5396
    RHS       disj1_7_9_7  81
    RHS       disj2_7_9_7  -5314
    RHS       disj1_8_9_7  13
    RHS       disj2_8_9_7  -5314
    RHS       disj1_0_1_8  6
    RHS       disj2_0_1_8  -5318
    RHS       disj1_0_2_8  6
    RHS       disj2_0_2_8  -5379
    RHS       disj1_0_3_8  6
    RHS       disj2_0_3_8  -5311
    RHS       disj1_0_4_8  6
    RHS       disj2_0_4_8  -5373
    RHS       disj1_0_5_8  6
    RHS       disj2_0_5_8  -5322
    RHS       disj1_0_6_8  6
    RHS       disj2_0_6_8  -5352
    RHS       disj1_0_7_8  6
    RHS       disj2_0_7_8  -5313
    RHS       disj1_0_8_8  6
    RHS       disj2_0_8_8  -5364
    RHS       disj1_0_9_8  6
    RHS       disj2_0_9_8  -5380
    RHS       disj1_1_2_8  91
    RHS       disj2_1_2_8  -5379
    RHS       disj1_1_3_8  91
    RHS       disj2_1_3_8  -5311
    RHS       disj1_1_4_8  91
    RHS       disj2_1_4_8  -5373
    RHS       disj1_1_5_8  91
    RHS       disj2_1_5_8  -5322
    RHS       disj1_1_6_8  91
    RHS       disj2_1_6_8  -5352
    RHS       disj1_1_7_8  91
    RHS       disj2_1_7_8  -5313
    RHS       disj1_1_8_8  91
    RHS       disj2_1_8_8  -5364
    RHS       disj1_1_9_8  91
    RHS       disj2_1_9_8  -5380
    RHS       disj1_2_3_8  30
    RHS       disj2_2_3_8  -5311
    RHS       disj1_2_4_8  30
    RHS       disj2_2_4_8  -5373
    RHS       disj1_2_5_8  30
    RHS       disj2_2_5_8  -5322
    RHS       disj1_2_6_8  30
    RHS       disj2_2_6_8  -5352
    RHS       disj1_2_7_8  30
    RHS       disj2_2_7_8  -5313
    RHS       disj1_2_8_8  30
    RHS       disj2_2_8_8  -5364
    RHS       disj1_2_9_8  30
    RHS       disj2_2_9_8  -5380
    RHS       disj1_3_4_8  98
    RHS       disj2_3_4_8  -5373
    RHS       disj1_3_5_8  98
    RHS       disj2_3_5_8  -5322
    RHS       disj1_3_6_8  98
    RHS       disj2_3_6_8  -5352
    RHS       disj1_3_7_8  98
    RHS       disj2_3_7_8  -5313
    RHS       disj1_3_8_8  98
    RHS       disj2_3_8_8  -5364
    RHS       disj1_3_9_8  98
    RHS       disj2_3_9_8  -5380
    RHS       disj1_4_5_8  36
    RHS       disj2_4_5_8  -5322
    RHS       disj1_4_6_8  36
    RHS       disj2_4_6_8  -5352
    RHS       disj1_4_7_8  36
    RHS       disj2_4_7_8  -5313
    RHS       disj1_4_8_8  36
    RHS       disj2_4_8_8  -5364
    RHS       disj1_4_9_8  36
    RHS       disj2_4_9_8  -5380
    RHS       disj1_5_6_8  87
    RHS       disj2_5_6_8  -5352
    RHS       disj1_5_7_8  87
    RHS       disj2_5_7_8  -5313
    RHS       disj1_5_8_8  87
    RHS       disj2_5_8_8  -5364
    RHS       disj1_5_9_8  87
    RHS       disj2_5_9_8  -5380
    RHS       disj1_6_7_8  57
    RHS       disj2_6_7_8  -5313
    RHS       disj1_6_8_8  57
    RHS       disj2_6_8_8  -5364
    RHS       disj1_6_9_8  57
    RHS       disj2_6_9_8  -5380
    RHS       disj1_7_8_8  96
    RHS       disj2_7_8_8  -5364
    RHS       disj1_7_9_8  96
    RHS       disj2_7_9_8  -5380
    RHS       disj1_8_9_8  45
    RHS       disj2_8_9_8  -5380
    RHS       disj1_0_1_9  84
    RHS       disj2_0_1_9  -5322
    RHS       disj1_0_2_9  84
    RHS       disj2_0_2_9  -5349
    RHS       disj1_0_3_9  84
    RHS       disj2_0_3_9  -5389
    RHS       disj1_0_4_9  84
    RHS       disj2_0_4_9  -5362
    RHS       disj1_0_5_9  84
    RHS       disj2_0_5_9  -5339
    RHS       disj1_0_6_9  84
    RHS       disj2_0_6_9  -5333
    RHS       disj1_0_7_9  84
    RHS       disj2_0_7_9  -5325
    RHS       disj1_0_8_9  84
    RHS       disj2_0_8_9  -5345
    RHS       disj1_0_9_9  84
    RHS       disj2_0_9_9  -5358
    RHS       disj1_1_2_9  87
    RHS       disj2_1_2_9  -5349
    RHS       disj1_1_3_9  87
    RHS       disj2_1_3_9  -5389
    RHS       disj1_1_4_9  87
    RHS       disj2_1_4_9  -5362
    RHS       disj1_1_5_9  87
    RHS       disj2_1_5_9  -5339
    RHS       disj1_1_6_9  87
    RHS       disj2_1_6_9  -5333
    RHS       disj1_1_7_9  87
    RHS       disj2_1_7_9  -5325
    RHS       disj1_1_8_9  87
    RHS       disj2_1_8_9  -5345
    RHS       disj1_1_9_9  87
    RHS       disj2_1_9_9  -5358
    RHS       disj1_2_3_9  60
    RHS       disj2_2_3_9  -5389
    RHS       disj1_2_4_9  60
    RHS       disj2_2_4_9  -5362
    RHS       disj1_2_5_9  60
    RHS       disj2_2_5_9  -5339
    RHS       disj1_2_6_9  60
    RHS       disj2_2_6_9  -5333
    RHS       disj1_2_7_9  60
    RHS       disj2_2_7_9  -5325
    RHS       disj1_2_8_9  60
    RHS       disj2_2_8_9  -5345
    RHS       disj1_2_9_9  60
    RHS       disj2_2_9_9  -5358
    RHS       disj1_3_4_9  20
    RHS       disj2_3_4_9  -5362
    RHS       disj1_3_5_9  20
    RHS       disj2_3_5_9  -5339
    RHS       disj1_3_6_9  20
    RHS       disj2_3_6_9  -5333
    RHS       disj1_3_7_9  20
    RHS       disj2_3_7_9  -5325
    RHS       disj1_3_8_9  20
    RHS       disj2_3_8_9  -5345
    RHS       disj1_3_9_9  20
    RHS       disj2_3_9_9  -5358
    RHS       disj1_4_5_9  47
    RHS       disj2_4_5_9  -5339
    RHS       disj1_4_6_9  47
    RHS       disj2_4_6_9  -5333
    RHS       disj1_4_7_9  47
    RHS       disj2_4_7_9  -5325
    RHS       disj1_4_8_9  47
    RHS       disj2_4_8_9  -5345
    RHS       disj1_4_9_9  47
    RHS       disj2_4_9_9  -5358
    RHS       disj1_5_6_9  70
    RHS       disj2_5_6_9  -5333
    RHS       disj1_5_7_9  70
    RHS       disj2_5_7_9  -5325
    RHS       disj1_5_8_9  70
    RHS       disj2_5_8_9  -5345
    RHS       disj1_5_9_9  70
    RHS       disj2_5_9_9  -5358
    RHS       disj1_6_7_9  76
    RHS       disj2_6_7_9  -5325
    RHS       disj1_6_8_9  76
    RHS       disj2_6_8_9  -5345
    RHS       disj1_6_9_9  76
    RHS       disj2_6_9_9  -5358
    RHS       disj1_7_8_9  84
    RHS       disj2_7_8_9  -5345
    RHS       disj1_7_9_9  84
    RHS       disj2_7_9_9  -5358
    RHS       disj1_8_9_9  64
    RHS       disj2_8_9_9  -5358
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_1_6
 BV BOUND     y_0_1_7
 BV BOUND     y_0_1_8
 BV BOUND     y_0_1_9
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_2_6
 BV BOUND     y_0_2_7
 BV BOUND     y_0_2_8
 BV BOUND     y_0_2_9
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_3_6
 BV BOUND     y_0_3_7
 BV BOUND     y_0_3_8
 BV BOUND     y_0_3_9
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_4_6
 BV BOUND     y_0_4_7
 BV BOUND     y_0_4_8
 BV BOUND     y_0_4_9
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_5_6
 BV BOUND     y_0_5_7
 BV BOUND     y_0_5_8
 BV BOUND     y_0_5_9
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_0_6_6
 BV BOUND     y_0_6_7
 BV BOUND     y_0_6_8
 BV BOUND     y_0_6_9
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_7_5
 BV BOUND     y_0_7_6
 BV BOUND     y_0_7_7
 BV BOUND     y_0_7_8
 BV BOUND     y_0_7_9
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_8_5
 BV BOUND     y_0_8_6
 BV BOUND     y_0_8_7
 BV BOUND     y_0_8_8
 BV BOUND     y_0_8_9
 BV BOUND     y_0_9_0
 BV BOUND     y_0_9_1
 BV BOUND     y_0_9_2
 BV BOUND     y_0_9_3
 BV BOUND     y_0_9_4
 BV BOUND     y_0_9_5
 BV BOUND     y_0_9_6
 BV BOUND     y_0_9_7
 BV BOUND     y_0_9_8
 BV BOUND     y_0_9_9
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_2_6
 BV BOUND     y_1_2_7
 BV BOUND     y_1_2_8
 BV BOUND     y_1_2_9
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_3_6
 BV BOUND     y_1_3_7
 BV BOUND     y_1_3_8
 BV BOUND     y_1_3_9
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_4_6
 BV BOUND     y_1_4_7
 BV BOUND     y_1_4_8
 BV BOUND     y_1_4_9
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_5_6
 BV BOUND     y_1_5_7
 BV BOUND     y_1_5_8
 BV BOUND     y_1_5_9
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_1_6_6
 BV BOUND     y_1_6_7
 BV BOUND     y_1_6_8
 BV BOUND     y_1_6_9
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_7_5
 BV BOUND     y_1_7_6
 BV BOUND     y_1_7_7
 BV BOUND     y_1_7_8
 BV BOUND     y_1_7_9
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_8_5
 BV BOUND     y_1_8_6
 BV BOUND     y_1_8_7
 BV BOUND     y_1_8_8
 BV BOUND     y_1_8_9
 BV BOUND     y_1_9_0
 BV BOUND     y_1_9_1
 BV BOUND     y_1_9_2
 BV BOUND     y_1_9_3
 BV BOUND     y_1_9_4
 BV BOUND     y_1_9_5
 BV BOUND     y_1_9_6
 BV BOUND     y_1_9_7
 BV BOUND     y_1_9_8
 BV BOUND     y_1_9_9
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_3_6
 BV BOUND     y_2_3_7
 BV BOUND     y_2_3_8
 BV BOUND     y_2_3_9
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_4_6
 BV BOUND     y_2_4_7
 BV BOUND     y_2_4_8
 BV BOUND     y_2_4_9
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_5_6
 BV BOUND     y_2_5_7
 BV BOUND     y_2_5_8
 BV BOUND     y_2_5_9
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_2_6_6
 BV BOUND     y_2_6_7
 BV BOUND     y_2_6_8
 BV BOUND     y_2_6_9
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_7_5
 BV BOUND     y_2_7_6
 BV BOUND     y_2_7_7
 BV BOUND     y_2_7_8
 BV BOUND     y_2_7_9
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_8_5
 BV BOUND     y_2_8_6
 BV BOUND     y_2_8_7
 BV BOUND     y_2_8_8
 BV BOUND     y_2_8_9
 BV BOUND     y_2_9_0
 BV BOUND     y_2_9_1
 BV BOUND     y_2_9_2
 BV BOUND     y_2_9_3
 BV BOUND     y_2_9_4
 BV BOUND     y_2_9_5
 BV BOUND     y_2_9_6
 BV BOUND     y_2_9_7
 BV BOUND     y_2_9_8
 BV BOUND     y_2_9_9
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_4_6
 BV BOUND     y_3_4_7
 BV BOUND     y_3_4_8
 BV BOUND     y_3_4_9
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_5_6
 BV BOUND     y_3_5_7
 BV BOUND     y_3_5_8
 BV BOUND     y_3_5_9
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_3_6_6
 BV BOUND     y_3_6_7
 BV BOUND     y_3_6_8
 BV BOUND     y_3_6_9
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_7_5
 BV BOUND     y_3_7_6
 BV BOUND     y_3_7_7
 BV BOUND     y_3_7_8
 BV BOUND     y_3_7_9
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_8_5
 BV BOUND     y_3_8_6
 BV BOUND     y_3_8_7
 BV BOUND     y_3_8_8
 BV BOUND     y_3_8_9
 BV BOUND     y_3_9_0
 BV BOUND     y_3_9_1
 BV BOUND     y_3_9_2
 BV BOUND     y_3_9_3
 BV BOUND     y_3_9_4
 BV BOUND     y_3_9_5
 BV BOUND     y_3_9_6
 BV BOUND     y_3_9_7
 BV BOUND     y_3_9_8
 BV BOUND     y_3_9_9
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_5_6
 BV BOUND     y_4_5_7
 BV BOUND     y_4_5_8
 BV BOUND     y_4_5_9
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_4_6_6
 BV BOUND     y_4_6_7
 BV BOUND     y_4_6_8
 BV BOUND     y_4_6_9
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_7_5
 BV BOUND     y_4_7_6
 BV BOUND     y_4_7_7
 BV BOUND     y_4_7_8
 BV BOUND     y_4_7_9
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_8_5
 BV BOUND     y_4_8_6
 BV BOUND     y_4_8_7
 BV BOUND     y_4_8_8
 BV BOUND     y_4_8_9
 BV BOUND     y_4_9_0
 BV BOUND     y_4_9_1
 BV BOUND     y_4_9_2
 BV BOUND     y_4_9_3
 BV BOUND     y_4_9_4
 BV BOUND     y_4_9_5
 BV BOUND     y_4_9_6
 BV BOUND     y_4_9_7
 BV BOUND     y_4_9_8
 BV BOUND     y_4_9_9
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
 BV BOUND     y_5_6_6
 BV BOUND     y_5_6_7
 BV BOUND     y_5_6_8
 BV BOUND     y_5_6_9
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_7_5
 BV BOUND     y_5_7_6
 BV BOUND     y_5_7_7
 BV BOUND     y_5_7_8
 BV BOUND     y_5_7_9
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_8_5
 BV BOUND     y_5_8_6
 BV BOUND     y_5_8_7
 BV BOUND     y_5_8_8
 BV BOUND     y_5_8_9
 BV BOUND     y_5_9_0
 BV BOUND     y_5_9_1
 BV BOUND     y_5_9_2
 BV BOUND     y_5_9_3
 BV BOUND     y_5_9_4
 BV BOUND     y_5_9_5
 BV BOUND     y_5_9_6
 BV BOUND     y_5_9_7
 BV BOUND     y_5_9_8
 BV BOUND     y_5_9_9
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_7_5
 BV BOUND     y_6_7_6
 BV BOUND     y_6_7_7
 BV BOUND     y_6_7_8
 BV BOUND     y_6_7_9
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_8_5
 BV BOUND     y_6_8_6
 BV BOUND     y_6_8_7
 BV BOUND     y_6_8_8
 BV BOUND     y_6_8_9
 BV BOUND     y_6_9_0
 BV BOUND     y_6_9_1
 BV BOUND     y_6_9_2
 BV BOUND     y_6_9_3
 BV BOUND     y_6_9_4
 BV BOUND     y_6_9_5
 BV BOUND     y_6_9_6
 BV BOUND     y_6_9_7
 BV BOUND     y_6_9_8
 BV BOUND     y_6_9_9
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_8_5
 BV BOUND     y_7_8_6
 BV BOUND     y_7_8_7
 BV BOUND     y_7_8_8
 BV BOUND     y_7_8_9
 BV BOUND     y_7_9_0
 BV BOUND     y_7_9_1
 BV BOUND     y_7_9_2
 BV BOUND     y_7_9_3
 BV BOUND     y_7_9_4
 BV BOUND     y_7_9_5
 BV BOUND     y_7_9_6
 BV BOUND     y_7_9_7
 BV BOUND     y_7_9_8
 BV BOUND     y_7_9_9
 BV BOUND     y_8_9_0
 BV BOUND     y_8_9_1
 BV BOUND     y_8_9_2
 BV BOUND     y_8_9_3
 BV BOUND     y_8_9_4
 BV BOUND     y_8_9_5
 BV BOUND     y_8_9_6
 BV BOUND     y_8_9_7
 BV BOUND     y_8_9_8
 BV BOUND     y_8_9_9
ENDATA
