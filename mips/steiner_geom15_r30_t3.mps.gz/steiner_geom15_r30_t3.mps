NAME          steiner_geom15_r30_t3
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 L  cap_0_3
 L  cap_0_4
 L  cap_0_9
 L  cap_1_4
 L  cap_1_5
 L  cap_1_6
 L  cap_1_11
 L  cap_1_13
 L  cap_2_7
 L  cap_2_10
 L  cap_2_14
 L  cap_3_9
 L  cap_3_12
 L  cap_4_11
 L  cap_5_8
 L  cap_6_13
 L  cap_7_10
 L  cap_7_14
 L  cap_10_14
 L  cap_11_13
 L  cap_12_14
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_3     OBJ       26.02
    x_0_3     cap_0_3   -3
    x_0_4     OBJ       21.76
    x_0_4     cap_0_4   -3
    x_0_9     OBJ       17.1
    x_0_9     cap_0_9   -3
    x_1_4     OBJ       24.29
    x_1_4     cap_1_4   -3
    x_1_5     OBJ       28.77
    x_1_5     cap_1_5   -3
    x_1_6     OBJ       24.97
    x_1_6     cap_1_6   -3
    x_1_11    OBJ       9.4
    x_1_11    cap_1_11  -3
    x_1_13    OBJ       22.19
    x_1_13    cap_1_13  -3
    x_2_7     OBJ       15.77
    x_2_7     cap_2_7   -3
    x_2_10    OBJ       7.26
    x_2_10    cap_2_10  -3
    x_2_14    OBJ       13.29
    x_2_14    cap_2_14  -3
    x_3_9     OBJ       11.54
    x_3_9     cap_3_9   -3
    x_3_12    OBJ       25.8
    x_3_12    cap_3_12  -3
    x_4_11    OBJ       14.99
    x_4_11    cap_4_11  -3
    x_5_8     OBJ       8.39
    x_5_8     cap_5_8   -3
    x_6_13    OBJ       12.17
    x_6_13    cap_6_13  -3
    x_7_10    OBJ       21.86
    x_7_10    cap_7_10  -3
    x_7_14    OBJ       20.62
    x_7_14    cap_7_14  -3
    x_10_14   OBJ       10.32
    x_10_14   cap_10_14  -3
    x_11_13   OBJ       25.44
    x_11_13   cap_11_13  -3
    x_12_14   OBJ       28.88
    x_12_14   cap_12_14  -3
    MARK0001  'MARKER'                 'INTEND'
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_4     flow_0    1.0
    f_0_4     flow_4    -1.0
    f_0_4     cap_0_4   1.0
    f_4_0     flow_0    -1.0
    f_4_0     flow_4    1.0
    f_4_0     cap_0_4   1.0
    f_0_9     flow_0    1.0
    f_0_9     flow_9    -1.0
    f_0_9     cap_0_9   1.0
    f_9_0     flow_0    -1.0
    f_9_0     flow_9    1.0
    f_9_0     cap_0_9   1.0
    f_1_4     flow_1    1.0
    f_1_4     flow_4    -1.0
    f_1_4     cap_1_4   1.0
    f_4_1     flow_1    -1.0
    f_4_1     flow_4    1.0
    f_4_1     cap_1_4   1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_1_6     flow_1    1.0
    f_1_6     flow_6    -1.0
    f_1_6     cap_1_6   1.0
    f_6_1     flow_1    -1.0
    f_6_1     flow_6    1.0
    f_6_1     cap_1_6   1.0
    f_1_11    flow_1    1.0
    f_1_11    flow_11   -1.0
    f_1_11    cap_1_11  1.0
    f_11_1    flow_1    -1.0
    f_11_1    flow_11   1.0
    f_11_1    cap_1_11  1.0
    f_1_13    flow_1    1.0
    f_1_13    flow_13   -1.0
    f_1_13    cap_1_13  1.0
    f_13_1    flow_1    -1.0
    f_13_1    flow_13   1.0
    f_13_1    cap_1_13  1.0
    f_2_7     flow_2    1.0
    f_2_7     flow_7    -1.0
    f_2_7     cap_2_7   1.0
    f_7_2     flow_2    -1.0
    f_7_2     flow_7    1.0
    f_7_2     cap_2_7   1.0
    f_2_10    flow_2    1.0
    f_2_10    flow_10   -1.0
    f_2_10    cap_2_10  1.0
    f_10_2    flow_2    -1.0
    f_10_2    flow_10   1.0
    f_10_2    cap_2_10  1.0
    f_2_14    flow_2    1.0
    f_2_14    flow_14   -1.0
    f_2_14    cap_2_14  1.0
    f_14_2    flow_2    -1.0
    f_14_2    flow_14   1.0
    f_14_2    cap_2_14  1.0
    f_3_9     flow_3    1.0
    f_3_9     flow_9    -1.0
    f_3_9     cap_3_9   1.0
    f_9_3     flow_3    -1.0
    f_9_3     flow_9    1.0
    f_9_3     cap_3_9   1.0
    f_3_12    flow_3    1.0
    f_3_12    flow_12   -1.0
    f_3_12    cap_3_12  1.0
    f_12_3    flow_3    -1.0
    f_12_3    flow_12   1.0
    f_12_3    cap_3_12  1.0
    f_4_11    flow_4    1.0
    f_4_11    flow_11   -1.0
    f_4_11    cap_4_11  1.0
    f_11_4    flow_4    -1.0
    f_11_4    flow_11   1.0
    f_11_4    cap_4_11  1.0
    f_5_8     flow_5    1.0
    f_5_8     flow_8    -1.0
    f_5_8     cap_5_8   1.0
    f_8_5     flow_5    -1.0
    f_8_5     flow_8    1.0
    f_8_5     cap_5_8   1.0
    f_6_13    flow_6    1.0
    f_6_13    flow_13   -1.0
    f_6_13    cap_6_13  1.0
    f_13_6    flow_6    -1.0
    f_13_6    flow_13   1.0
    f_13_6    cap_6_13  1.0
    f_7_10    flow_7    1.0
    f_7_10    flow_10   -1.0
    f_7_10    cap_7_10  1.0
    f_10_7    flow_7    -1.0
    f_10_7    flow_10   1.0
    f_10_7    cap_7_10  1.0
    f_7_14    flow_7    1.0
    f_7_14    flow_14   -1.0
    f_7_14    cap_7_14  1.0
    f_14_7    flow_7    -1.0
    f_14_7    flow_14   1.0
    f_14_7    cap_7_14  1.0
    f_10_14   flow_10   1.0
    f_10_14   flow_14   -1.0
    f_10_14   cap_10_14  1.0
    f_14_10   flow_10   -1.0
    f_14_10   flow_14   1.0
    f_14_10   cap_10_14  1.0
    f_11_13   flow_11   1.0
    f_11_13   flow_13   -1.0
    f_11_13   cap_11_13  1.0
    f_13_11   flow_11   -1.0
    f_13_11   flow_13   1.0
    f_13_11   cap_11_13  1.0
    f_12_14   flow_12   1.0
    f_12_14   flow_14   -1.0
    f_12_14   cap_12_14  1.0
    f_14_12   flow_12   -1.0
    f_14_12   flow_14   1.0
    f_14_12   cap_12_14  1.0
RHS
    RHS       flow_0    3
    RHS       flow_1    -1
    RHS       flow_2    -1
    RHS       flow_11   -1
BOUNDS
 BV BOUND     x_0_3
 BV BOUND     x_0_4
 BV BOUND     x_0_9
 BV BOUND     x_1_4
 BV BOUND     x_1_5
 BV BOUND     x_1_6
 BV BOUND     x_1_11
 BV BOUND     x_1_13
 BV BOUND     x_2_7
 BV BOUND     x_2_10
 BV BOUND     x_2_14
 BV BOUND     x_3_9
 BV BOUND     x_3_12
 BV BOUND     x_4_11
 BV BOUND     x_5_8
 BV BOUND     x_6_13
 BV BOUND     x_7_10
 BV BOUND     x_7_14
 BV BOUND     x_10_14
 BV BOUND     x_11_13
 BV BOUND     x_12_14
 UP BOUND     f_0_3     3
 UP BOUND     f_3_0     3
 UP BOUND     f_0_4     3
 UP BOUND     f_4_0     3
 UP BOUND     f_0_9     3
 UP BOUND     f_9_0     3
 UP BOUND     f_1_4     3
 UP BOUND     f_4_1     3
 UP BOUND     f_1_5     3
 UP BOUND     f_5_1     3
 UP BOUND     f_1_6     3
 UP BOUND     f_6_1     3
 UP BOUND     f_1_11    3
 UP BOUND     f_11_1    3
 UP BOUND     f_1_13    3
 UP BOUND     f_13_1    3
 UP BOUND     f_2_7     3
 UP BOUND     f_7_2     3
 UP BOUND     f_2_10    3
 UP BOUND     f_10_2    3
 UP BOUND     f_2_14    3
 UP BOUND     f_14_2    3
 UP BOUND     f_3_9     3
 UP BOUND     f_9_3     3
 UP BOUND     f_3_12    3
 UP BOUND     f_12_3    3
 UP BOUND     f_4_11    3
 UP BOUND     f_11_4    3
 UP BOUND     f_5_8     3
 UP BOUND     f_8_5     3
 UP BOUND     f_6_13    3
 UP BOUND     f_13_6    3
 UP BOUND     f_7_10    3
 UP BOUND     f_10_7    3
 UP BOUND     f_7_14    3
 UP BOUND     f_14_7    3
 UP BOUND     f_10_14   3
 UP BOUND     f_14_10   3
 UP BOUND     f_11_13   3
 UP BOUND     f_13_11   3
 UP BOUND     f_12_14   3
 UP BOUND     f_14_12   3
ENDATA
