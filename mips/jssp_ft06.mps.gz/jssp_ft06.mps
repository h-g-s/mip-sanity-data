NAME          ft06
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_4_5_5
 G  disj2_4_5_5
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_2  -1.0
    x_0_0     disj2_0_1_2  1.0
    x_0_0     disj1_0_2_2  -1.0
    x_0_0     disj2_0_2_2  1.0
    x_0_0     disj1_0_3_2  -1.0
    x_0_0     disj2_0_3_2  1.0
    x_0_0     disj1_0_4_2  -1.0
    x_0_0     disj2_0_4_2  1.0
    x_0_0     disj1_0_5_2  -1.0
    x_0_0     disj2_0_5_2  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_0  -1.0
    x_0_1     disj2_0_1_0  1.0
    x_0_1     disj1_0_2_0  -1.0
    x_0_1     disj2_0_2_0  1.0
    x_0_1     disj1_0_3_0  -1.0
    x_0_1     disj2_0_3_0  1.0
    x_0_1     disj1_0_4_0  -1.0
    x_0_1     disj2_0_4_0  1.0
    x_0_1     disj1_0_5_0  -1.0
    x_0_1     disj2_0_5_0  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_1  -1.0
    x_0_2     disj2_0_1_1  1.0
    x_0_2     disj1_0_2_1  -1.0
    x_0_2     disj2_0_2_1  1.0
    x_0_2     disj1_0_3_1  -1.0
    x_0_2     disj2_0_3_1  1.0
    x_0_2     disj1_0_4_1  -1.0
    x_0_2     disj2_0_4_1  1.0
    x_0_2     disj1_0_5_1  -1.0
    x_0_2     disj2_0_5_1  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_3  -1.0
    x_0_3     disj2_0_1_3  1.0
    x_0_3     disj1_0_2_3  -1.0
    x_0_3     disj2_0_2_3  1.0
    x_0_3     disj1_0_3_3  -1.0
    x_0_3     disj2_0_3_3  1.0
    x_0_3     disj1_0_4_3  -1.0
    x_0_3     disj2_0_4_3  1.0
    x_0_3     disj1_0_5_3  -1.0
    x_0_3     disj2_0_5_3  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_5  -1.0
    x_0_4     disj2_0_1_5  1.0
    x_0_4     disj1_0_2_5  -1.0
    x_0_4     disj2_0_2_5  1.0
    x_0_4     disj1_0_3_5  -1.0
    x_0_4     disj2_0_3_5  1.0
    x_0_4     disj1_0_4_5  -1.0
    x_0_4     disj2_0_4_5  1.0
    x_0_4     disj1_0_5_5  -1.0
    x_0_4     disj2_0_5_5  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     mksp_0    -1.0
    x_0_5     disj1_0_1_4  -1.0
    x_0_5     disj2_0_1_4  1.0
    x_0_5     disj1_0_2_4  -1.0
    x_0_5     disj2_0_2_4  1.0
    x_0_5     disj1_0_3_4  -1.0
    x_0_5     disj2_0_3_4  1.0
    x_0_5     disj1_0_4_4  -1.0
    x_0_5     disj2_0_4_4  1.0
    x_0_5     disj1_0_5_4  -1.0
    x_0_5     disj2_0_5_4  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_2  1.0
    x_1_1     disj2_0_1_2  -1.0
    x_1_1     disj1_1_2_2  -1.0
    x_1_1     disj2_1_2_2  1.0
    x_1_1     disj1_1_3_2  -1.0
    x_1_1     disj2_1_3_2  1.0
    x_1_1     disj1_1_4_2  -1.0
    x_1_1     disj2_1_4_2  1.0
    x_1_1     disj1_1_5_2  -1.0
    x_1_1     disj2_1_5_2  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_4  1.0
    x_1_2     disj2_0_1_4  -1.0
    x_1_2     disj1_1_2_4  -1.0
    x_1_2     disj2_1_2_4  1.0
    x_1_2     disj1_1_3_4  -1.0
    x_1_2     disj2_1_3_4  1.0
    x_1_2     disj1_1_4_4  -1.0
    x_1_2     disj2_1_4_4  1.0
    x_1_2     disj1_1_5_4  -1.0
    x_1_2     disj2_1_5_4  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_5  1.0
    x_1_3     disj2_0_1_5  -1.0
    x_1_3     disj1_1_2_5  -1.0
    x_1_3     disj2_1_2_5  1.0
    x_1_3     disj1_1_3_5  -1.0
    x_1_3     disj2_1_3_5  1.0
    x_1_3     disj1_1_4_5  -1.0
    x_1_3     disj2_1_4_5  1.0
    x_1_3     disj1_1_5_5  -1.0
    x_1_3     disj2_1_5_5  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_0  1.0
    x_1_4     disj2_0_1_0  -1.0
    x_1_4     disj1_1_2_0  -1.0
    x_1_4     disj2_1_2_0  1.0
    x_1_4     disj1_1_3_0  -1.0
    x_1_4     disj2_1_3_0  1.0
    x_1_4     disj1_1_4_0  -1.0
    x_1_4     disj2_1_4_0  1.0
    x_1_4     disj1_1_5_0  -1.0
    x_1_4     disj2_1_5_0  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     mksp_1    -1.0
    x_1_5     disj1_0_1_3  1.0
    x_1_5     disj2_0_1_3  -1.0
    x_1_5     disj1_1_2_3  -1.0
    x_1_5     disj2_1_2_3  1.0
    x_1_5     disj1_1_3_3  -1.0
    x_1_5     disj2_1_3_3  1.0
    x_1_5     disj1_1_4_3  -1.0
    x_1_5     disj2_1_4_3  1.0
    x_1_5     disj1_1_5_3  -1.0
    x_1_5     disj2_1_5_3  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_2  1.0
    x_2_0     disj2_0_2_2  -1.0
    x_2_0     disj1_1_2_2  1.0
    x_2_0     disj2_1_2_2  -1.0
    x_2_0     disj1_2_3_2  -1.0
    x_2_0     disj2_2_3_2  1.0
    x_2_0     disj1_2_4_2  -1.0
    x_2_0     disj2_2_4_2  1.0
    x_2_0     disj1_2_5_2  -1.0
    x_2_0     disj2_2_5_2  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_5  1.0
    x_2_2     disj2_0_2_5  -1.0
    x_2_2     disj1_1_2_5  1.0
    x_2_2     disj2_1_2_5  -1.0
    x_2_2     disj1_2_3_5  -1.0
    x_2_2     disj2_2_3_5  1.0
    x_2_2     disj1_2_4_5  -1.0
    x_2_2     disj2_2_4_5  1.0
    x_2_2     disj1_2_5_5  -1.0
    x_2_2     disj2_2_5_5  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_0  1.0
    x_2_3     disj2_0_2_0  -1.0
    x_2_3     disj1_1_2_0  1.0
    x_2_3     disj2_1_2_0  -1.0
    x_2_3     disj1_2_3_0  -1.0
    x_2_3     disj2_2_3_0  1.0
    x_2_3     disj1_2_4_0  -1.0
    x_2_3     disj2_2_4_0  1.0
    x_2_3     disj1_2_5_0  -1.0
    x_2_3     disj2_2_5_0  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_1  1.0
    x_2_4     disj2_0_2_1  -1.0
    x_2_4     disj1_1_2_1  1.0
    x_2_4     disj2_1_2_1  -1.0
    x_2_4     disj1_2_3_1  -1.0
    x_2_4     disj2_2_3_1  1.0
    x_2_4     disj1_2_4_1  -1.0
    x_2_4     disj2_2_4_1  1.0
    x_2_4     disj1_2_5_1  -1.0
    x_2_4     disj2_2_5_1  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     mksp_2    -1.0
    x_2_5     disj1_0_2_4  1.0
    x_2_5     disj2_0_2_4  -1.0
    x_2_5     disj1_1_2_4  1.0
    x_2_5     disj2_1_2_4  -1.0
    x_2_5     disj1_2_3_4  -1.0
    x_2_5     disj2_2_3_4  1.0
    x_2_5     disj1_2_4_4  -1.0
    x_2_5     disj2_2_4_4  1.0
    x_2_5     disj1_2_5_4  -1.0
    x_2_5     disj2_2_5_4  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_1  1.0
    x_3_0     disj2_0_3_1  -1.0
    x_3_0     disj1_1_3_1  1.0
    x_3_0     disj2_1_3_1  -1.0
    x_3_0     disj1_2_3_1  1.0
    x_3_0     disj2_2_3_1  -1.0
    x_3_0     disj1_3_4_1  -1.0
    x_3_0     disj2_3_4_1  1.0
    x_3_0     disj1_3_5_1  -1.0
    x_3_0     disj2_3_5_1  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_0  1.0
    x_3_1     disj2_0_3_0  -1.0
    x_3_1     disj1_1_3_0  1.0
    x_3_1     disj2_1_3_0  -1.0
    x_3_1     disj1_2_3_0  1.0
    x_3_1     disj2_2_3_0  -1.0
    x_3_1     disj1_3_4_0  -1.0
    x_3_1     disj2_3_4_0  1.0
    x_3_1     disj1_3_5_0  -1.0
    x_3_1     disj2_3_5_0  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_2  1.0
    x_3_2     disj2_0_3_2  -1.0
    x_3_2     disj1_1_3_2  1.0
    x_3_2     disj2_1_3_2  -1.0
    x_3_2     disj1_2_3_2  1.0
    x_3_2     disj2_2_3_2  -1.0
    x_3_2     disj1_3_4_2  -1.0
    x_3_2     disj2_3_4_2  1.0
    x_3_2     disj1_3_5_2  -1.0
    x_3_2     disj2_3_5_2  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_3  1.0
    x_3_3     disj2_0_3_3  -1.0
    x_3_3     disj1_1_3_3  1.0
    x_3_3     disj2_1_3_3  -1.0
    x_3_3     disj1_2_3_3  1.0
    x_3_3     disj2_2_3_3  -1.0
    x_3_3     disj1_3_4_3  -1.0
    x_3_3     disj2_3_4_3  1.0
    x_3_3     disj1_3_5_3  -1.0
    x_3_3     disj2_3_5_3  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_4  1.0
    x_3_4     disj2_0_3_4  -1.0
    x_3_4     disj1_1_3_4  1.0
    x_3_4     disj2_1_3_4  -1.0
    x_3_4     disj1_2_3_4  1.0
    x_3_4     disj2_2_3_4  -1.0
    x_3_4     disj1_3_4_4  -1.0
    x_3_4     disj2_3_4_4  1.0
    x_3_4     disj1_3_5_4  -1.0
    x_3_4     disj2_3_5_4  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     mksp_3    -1.0
    x_3_5     disj1_0_3_5  1.0
    x_3_5     disj2_0_3_5  -1.0
    x_3_5     disj1_1_3_5  1.0
    x_3_5     disj2_1_3_5  -1.0
    x_3_5     disj1_2_3_5  1.0
    x_3_5     disj2_2_3_5  -1.0
    x_3_5     disj1_3_4_5  -1.0
    x_3_5     disj2_3_4_5  1.0
    x_3_5     disj1_3_5_5  -1.0
    x_3_5     disj2_3_5_5  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_2  1.0
    x_4_0     disj2_0_4_2  -1.0
    x_4_0     disj1_1_4_2  1.0
    x_4_0     disj2_1_4_2  -1.0
    x_4_0     disj1_2_4_2  1.0
    x_4_0     disj2_2_4_2  -1.0
    x_4_0     disj1_3_4_2  1.0
    x_4_0     disj2_3_4_2  -1.0
    x_4_0     disj1_4_5_2  -1.0
    x_4_0     disj2_4_5_2  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_1  1.0
    x_4_1     disj2_0_4_1  -1.0
    x_4_1     disj1_1_4_1  1.0
    x_4_1     disj2_1_4_1  -1.0
    x_4_1     disj1_2_4_1  1.0
    x_4_1     disj2_2_4_1  -1.0
    x_4_1     disj1_3_4_1  1.0
    x_4_1     disj2_3_4_1  -1.0
    x_4_1     disj1_4_5_1  -1.0
    x_4_1     disj2_4_5_1  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_4  1.0
    x_4_2     disj2_0_4_4  -1.0
    x_4_2     disj1_1_4_4  1.0
    x_4_2     disj2_1_4_4  -1.0
    x_4_2     disj1_2_4_4  1.0
    x_4_2     disj2_2_4_4  -1.0
    x_4_2     disj1_3_4_4  1.0
    x_4_2     disj2_3_4_4  -1.0
    x_4_2     disj1_4_5_4  -1.0
    x_4_2     disj2_4_5_4  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_5  1.0
    x_4_3     disj2_0_4_5  -1.0
    x_4_3     disj1_1_4_5  1.0
    x_4_3     disj2_1_4_5  -1.0
    x_4_3     disj1_2_4_5  1.0
    x_4_3     disj2_2_4_5  -1.0
    x_4_3     disj1_3_4_5  1.0
    x_4_3     disj2_3_4_5  -1.0
    x_4_3     disj1_4_5_5  -1.0
    x_4_3     disj2_4_5_5  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_0  1.0
    x_4_4     disj2_0_4_0  -1.0
    x_4_4     disj1_1_4_0  1.0
    x_4_4     disj2_1_4_0  -1.0
    x_4_4     disj1_2_4_0  1.0
    x_4_4     disj2_2_4_0  -1.0
    x_4_4     disj1_3_4_0  1.0
    x_4_4     disj2_3_4_0  -1.0
    x_4_4     disj1_4_5_0  -1.0
    x_4_4     disj2_4_5_0  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     mksp_4    -1.0
    x_4_5     disj1_0_4_3  1.0
    x_4_5     disj2_0_4_3  -1.0
    x_4_5     disj1_1_4_3  1.0
    x_4_5     disj2_1_4_3  -1.0
    x_4_5     disj1_2_4_3  1.0
    x_4_5     disj2_2_4_3  -1.0
    x_4_5     disj1_3_4_3  1.0
    x_4_5     disj2_3_4_3  -1.0
    x_4_5     disj1_4_5_3  -1.0
    x_4_5     disj2_4_5_3  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_1  1.0
    x_5_0     disj2_0_5_1  -1.0
    x_5_0     disj1_1_5_1  1.0
    x_5_0     disj2_1_5_1  -1.0
    x_5_0     disj1_2_5_1  1.0
    x_5_0     disj2_2_5_1  -1.0
    x_5_0     disj1_3_5_1  1.0
    x_5_0     disj2_3_5_1  -1.0
    x_5_0     disj1_4_5_1  1.0
    x_5_0     disj2_4_5_1  -1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_3  1.0
    x_5_1     disj2_0_5_3  -1.0
    x_5_1     disj1_1_5_3  1.0
    x_5_1     disj2_1_5_3  -1.0
    x_5_1     disj1_2_5_3  1.0
    x_5_1     disj2_2_5_3  -1.0
    x_5_1     disj1_3_5_3  1.0
    x_5_1     disj2_3_5_3  -1.0
    x_5_1     disj1_4_5_3  1.0
    x_5_1     disj2_4_5_3  -1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_5  1.0
    x_5_2     disj2_0_5_5  -1.0
    x_5_2     disj1_1_5_5  1.0
    x_5_2     disj2_1_5_5  -1.0
    x_5_2     disj1_2_5_5  1.0
    x_5_2     disj2_2_5_5  -1.0
    x_5_2     disj1_3_5_5  1.0
    x_5_2     disj2_3_5_5  -1.0
    x_5_2     disj1_4_5_5  1.0
    x_5_2     disj2_4_5_5  -1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_0  1.0
    x_5_3     disj2_0_5_0  -1.0
    x_5_3     disj1_1_5_0  1.0
    x_5_3     disj2_1_5_0  -1.0
    x_5_3     disj1_2_5_0  1.0
    x_5_3     disj2_2_5_0  -1.0
    x_5_3     disj1_3_5_0  1.0
    x_5_3     disj2_3_5_0  -1.0
    x_5_3     disj1_4_5_0  1.0
    x_5_3     disj2_4_5_0  -1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_4  1.0
    x_5_4     disj2_0_5_4  -1.0
    x_5_4     disj1_1_5_4  1.0
    x_5_4     disj2_1_5_4  -1.0
    x_5_4     disj1_2_5_4  1.0
    x_5_4     disj2_2_5_4  -1.0
    x_5_4     disj1_3_5_4  1.0
    x_5_4     disj2_3_5_4  -1.0
    x_5_4     disj1_4_5_4  1.0
    x_5_4     disj2_4_5_4  -1.0
    x_5_5     prec_5_4  1.0
    x_5_5     mksp_5    -1.0
    x_5_5     disj1_0_5_2  1.0
    x_5_5     disj2_0_5_2  -1.0
    x_5_5     disj1_1_5_2  1.0
    x_5_5     disj2_1_5_2  -1.0
    x_5_5     disj1_2_5_2  1.0
    x_5_5     disj2_2_5_2  -1.0
    x_5_5     disj1_3_5_2  1.0
    x_5_5     disj2_3_5_2  -1.0
    x_5_5     disj1_4_5_2  1.0
    x_5_5     disj2_4_5_2  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  197
    y_0_1_0   disj2_0_1_0  -197
    y_0_1_1   disj1_0_1_1  197
    y_0_1_1   disj2_0_1_1  -197
    y_0_1_2   disj1_0_1_2  197
    y_0_1_2   disj2_0_1_2  -197
    y_0_1_3   disj1_0_1_3  197
    y_0_1_3   disj2_0_1_3  -197
    y_0_1_4   disj1_0_1_4  197
    y_0_1_4   disj2_0_1_4  -197
    y_0_1_5   disj1_0_1_5  197
    y_0_1_5   disj2_0_1_5  -197
    y_0_2_0   disj1_0_2_0  197
    y_0_2_0   disj2_0_2_0  -197
    y_0_2_1   disj1_0_2_1  197
    y_0_2_1   disj2_0_2_1  -197
    y_0_2_2   disj1_0_2_2  197
    y_0_2_2   disj2_0_2_2  -197
    y_0_2_3   disj1_0_2_3  197
    y_0_2_3   disj2_0_2_3  -197
    y_0_2_4   disj1_0_2_4  197
    y_0_2_4   disj2_0_2_4  -197
    y_0_2_5   disj1_0_2_5  197
    y_0_2_5   disj2_0_2_5  -197
    y_0_3_0   disj1_0_3_0  197
    y_0_3_0   disj2_0_3_0  -197
    y_0_3_1   disj1_0_3_1  197
    y_0_3_1   disj2_0_3_1  -197
    y_0_3_2   disj1_0_3_2  197
    y_0_3_2   disj2_0_3_2  -197
    y_0_3_3   disj1_0_3_3  197
    y_0_3_3   disj2_0_3_3  -197
    y_0_3_4   disj1_0_3_4  197
    y_0_3_4   disj2_0_3_4  -197
    y_0_3_5   disj1_0_3_5  197
    y_0_3_5   disj2_0_3_5  -197
    y_0_4_0   disj1_0_4_0  197
    y_0_4_0   disj2_0_4_0  -197
    y_0_4_1   disj1_0_4_1  197
    y_0_4_1   disj2_0_4_1  -197
    y_0_4_2   disj1_0_4_2  197
    y_0_4_2   disj2_0_4_2  -197
    y_0_4_3   disj1_0_4_3  197
    y_0_4_3   disj2_0_4_3  -197
    y_0_4_4   disj1_0_4_4  197
    y_0_4_4   disj2_0_4_4  -197
    y_0_4_5   disj1_0_4_5  197
    y_0_4_5   disj2_0_4_5  -197
    y_0_5_0   disj1_0_5_0  197
    y_0_5_0   disj2_0_5_0  -197
    y_0_5_1   disj1_0_5_1  197
    y_0_5_1   disj2_0_5_1  -197
    y_0_5_2   disj1_0_5_2  197
    y_0_5_2   disj2_0_5_2  -197
    y_0_5_3   disj1_0_5_3  197
    y_0_5_3   disj2_0_5_3  -197
    y_0_5_4   disj1_0_5_4  197
    y_0_5_4   disj2_0_5_4  -197
    y_0_5_5   disj1_0_5_5  197
    y_0_5_5   disj2_0_5_5  -197
    y_1_2_0   disj1_1_2_0  197
    y_1_2_0   disj2_1_2_0  -197
    y_1_2_1   disj1_1_2_1  197
    y_1_2_1   disj2_1_2_1  -197
    y_1_2_2   disj1_1_2_2  197
    y_1_2_2   disj2_1_2_2  -197
    y_1_2_3   disj1_1_2_3  197
    y_1_2_3   disj2_1_2_3  -197
    y_1_2_4   disj1_1_2_4  197
    y_1_2_4   disj2_1_2_4  -197
    y_1_2_5   disj1_1_2_5  197
    y_1_2_5   disj2_1_2_5  -197
    y_1_3_0   disj1_1_3_0  197
    y_1_3_0   disj2_1_3_0  -197
    y_1_3_1   disj1_1_3_1  197
    y_1_3_1   disj2_1_3_1  -197
    y_1_3_2   disj1_1_3_2  197
    y_1_3_2   disj2_1_3_2  -197
    y_1_3_3   disj1_1_3_3  197
    y_1_3_3   disj2_1_3_3  -197
    y_1_3_4   disj1_1_3_4  197
    y_1_3_4   disj2_1_3_4  -197
    y_1_3_5   disj1_1_3_5  197
    y_1_3_5   disj2_1_3_5  -197
    y_1_4_0   disj1_1_4_0  197
    y_1_4_0   disj2_1_4_0  -197
    y_1_4_1   disj1_1_4_1  197
    y_1_4_1   disj2_1_4_1  -197
    y_1_4_2   disj1_1_4_2  197
    y_1_4_2   disj2_1_4_2  -197
    y_1_4_3   disj1_1_4_3  197
    y_1_4_3   disj2_1_4_3  -197
    y_1_4_4   disj1_1_4_4  197
    y_1_4_4   disj2_1_4_4  -197
    y_1_4_5   disj1_1_4_5  197
    y_1_4_5   disj2_1_4_5  -197
    y_1_5_0   disj1_1_5_0  197
    y_1_5_0   disj2_1_5_0  -197
    y_1_5_1   disj1_1_5_1  197
    y_1_5_1   disj2_1_5_1  -197
    y_1_5_2   disj1_1_5_2  197
    y_1_5_2   disj2_1_5_2  -197
    y_1_5_3   disj1_1_5_3  197
    y_1_5_3   disj2_1_5_3  -197
    y_1_5_4   disj1_1_5_4  197
    y_1_5_4   disj2_1_5_4  -197
    y_1_5_5   disj1_1_5_5  197
    y_1_5_5   disj2_1_5_5  -197
    y_2_3_0   disj1_2_3_0  197
    y_2_3_0   disj2_2_3_0  -197
    y_2_3_1   disj1_2_3_1  197
    y_2_3_1   disj2_2_3_1  -197
    y_2_3_2   disj1_2_3_2  197
    y_2_3_2   disj2_2_3_2  -197
    y_2_3_3   disj1_2_3_3  197
    y_2_3_3   disj2_2_3_3  -197
    y_2_3_4   disj1_2_3_4  197
    y_2_3_4   disj2_2_3_4  -197
    y_2_3_5   disj1_2_3_5  197
    y_2_3_5   disj2_2_3_5  -197
    y_2_4_0   disj1_2_4_0  197
    y_2_4_0   disj2_2_4_0  -197
    y_2_4_1   disj1_2_4_1  197
    y_2_4_1   disj2_2_4_1  -197
    y_2_4_2   disj1_2_4_2  197
    y_2_4_2   disj2_2_4_2  -197
    y_2_4_3   disj1_2_4_3  197
    y_2_4_3   disj2_2_4_3  -197
    y_2_4_4   disj1_2_4_4  197
    y_2_4_4   disj2_2_4_4  -197
    y_2_4_5   disj1_2_4_5  197
    y_2_4_5   disj2_2_4_5  -197
    y_2_5_0   disj1_2_5_0  197
    y_2_5_0   disj2_2_5_0  -197
    y_2_5_1   disj1_2_5_1  197
    y_2_5_1   disj2_2_5_1  -197
    y_2_5_2   disj1_2_5_2  197
    y_2_5_2   disj2_2_5_2  -197
    y_2_5_3   disj1_2_5_3  197
    y_2_5_3   disj2_2_5_3  -197
    y_2_5_4   disj1_2_5_4  197
    y_2_5_4   disj2_2_5_4  -197
    y_2_5_5   disj1_2_5_5  197
    y_2_5_5   disj2_2_5_5  -197
    y_3_4_0   disj1_3_4_0  197
    y_3_4_0   disj2_3_4_0  -197
    y_3_4_1   disj1_3_4_1  197
    y_3_4_1   disj2_3_4_1  -197
    y_3_4_2   disj1_3_4_2  197
    y_3_4_2   disj2_3_4_2  -197
    y_3_4_3   disj1_3_4_3  197
    y_3_4_3   disj2_3_4_3  -197
    y_3_4_4   disj1_3_4_4  197
    y_3_4_4   disj2_3_4_4  -197
    y_3_4_5   disj1_3_4_5  197
    y_3_4_5   disj2_3_4_5  -197
    y_3_5_0   disj1_3_5_0  197
    y_3_5_0   disj2_3_5_0  -197
    y_3_5_1   disj1_3_5_1  197
    y_3_5_1   disj2_3_5_1  -197
    y_3_5_2   disj1_3_5_2  197
    y_3_5_2   disj2_3_5_2  -197
    y_3_5_3   disj1_3_5_3  197
    y_3_5_3   disj2_3_5_3  -197
    y_3_5_4   disj1_3_5_4  197
    y_3_5_4   disj2_3_5_4  -197
    y_3_5_5   disj1_3_5_5  197
    y_3_5_5   disj2_3_5_5  -197
    y_4_5_0   disj1_4_5_0  197
    y_4_5_0   disj2_4_5_0  -197
    y_4_5_1   disj1_4_5_1  197
    y_4_5_1   disj2_4_5_1  -197
    y_4_5_2   disj1_4_5_2  197
    y_4_5_2   disj2_4_5_2  -197
    y_4_5_3   disj1_4_5_3  197
    y_4_5_3   disj2_4_5_3  -197
    y_4_5_4   disj1_4_5_4  197
    y_4_5_4   disj2_4_5_4  -197
    y_4_5_5   disj1_4_5_5  197
    y_4_5_5   disj2_4_5_5  -197
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  1
    RHS       prec_0_1  3
    RHS       prec_0_2  6
    RHS       prec_0_3  7
    RHS       prec_0_4  3
    RHS       prec_1_0  8
    RHS       prec_1_1  5
    RHS       prec_1_2  10
    RHS       prec_1_3  10
    RHS       prec_1_4  10
    RHS       prec_2_0  5
    RHS       prec_2_1  4
    RHS       prec_2_2  8
    RHS       prec_2_3  9
    RHS       prec_2_4  1
    RHS       prec_3_0  5
    RHS       prec_3_1  5
    RHS       prec_3_2  5
    RHS       prec_3_3  3
    RHS       prec_3_4  8
    RHS       prec_4_0  9
    RHS       prec_4_1  3
    RHS       prec_4_2  5
    RHS       prec_4_3  4
    RHS       prec_4_4  3
    RHS       prec_5_0  3
    RHS       prec_5_1  3
    RHS       prec_5_2  9
    RHS       prec_5_3  10
    RHS       prec_5_4  4
    RHS       mksp_0    6
    RHS       mksp_1    4
    RHS       mksp_2    7
    RHS       mksp_3    9
    RHS       mksp_4    1
    RHS       mksp_5    1
    RHS       disj1_0_1_0  3
    RHS       disj2_0_1_0  -187
    RHS       disj1_0_2_0  3
    RHS       disj2_0_2_0  -188
    RHS       disj1_0_3_0  3
    RHS       disj2_0_3_0  -192
    RHS       disj1_0_4_0  3
    RHS       disj2_0_4_0  -194
    RHS       disj1_0_5_0  3
    RHS       disj2_0_5_0  -187
    RHS       disj1_1_2_0  10
    RHS       disj2_1_2_0  -188
    RHS       disj1_1_3_0  10
    RHS       disj2_1_3_0  -192
    RHS       disj1_1_4_0  10
    RHS       disj2_1_4_0  -194
    RHS       disj1_1_5_0  10
    RHS       disj2_1_5_0  -187
    RHS       disj1_2_3_0  9
    RHS       disj2_2_3_0  -192
    RHS       disj1_2_4_0  9
    RHS       disj2_2_4_0  -194
    RHS       disj1_2_5_0  9
    RHS       disj2_2_5_0  -187
    RHS       disj1_3_4_0  5
    RHS       disj2_3_4_0  -194
    RHS       disj1_3_5_0  5
    RHS       disj2_3_5_0  -187
    RHS       disj1_4_5_0  3
    RHS       disj2_4_5_0  -187
    RHS       disj1_0_1_1  6
    RHS       disj2_0_1_1  -189
    RHS       disj1_0_2_1  6
    RHS       disj2_0_2_1  -196
    RHS       disj1_0_3_1  6
    RHS       disj2_0_3_1  -192
    RHS       disj1_0_4_1  6
    RHS       disj2_0_4_1  -194
    RHS       disj1_0_5_1  6
    RHS       disj2_0_5_1  -194
    RHS       disj1_1_2_1  8
    RHS       disj2_1_2_1  -196
    RHS       disj1_1_3_1  8
    RHS       disj2_1_3_1  -192
    RHS       disj1_1_4_1  8
    RHS       disj2_1_4_1  -194
    RHS       disj1_1_5_1  8
    RHS       disj2_1_5_1  -194
    RHS       disj1_2_3_1  1
    RHS       disj2_2_3_1  -192
    RHS       disj1_2_4_1  1
    RHS       disj2_2_4_1  -194
    RHS       disj1_2_5_1  1
    RHS       disj2_2_5_1  -194
    RHS       disj1_3_4_1  5
    RHS       disj2_3_4_1  -194
    RHS       disj1_3_5_1  5
    RHS       disj2_3_5_1  -194
    RHS       disj1_4_5_1  3
    RHS       disj2_4_5_1  -194
    RHS       disj1_0_1_2  1
    RHS       disj2_0_1_2  -192
    RHS       disj1_0_2_2  1
    RHS       disj2_0_2_2  -192
    RHS       disj1_0_3_2  1
    RHS       disj2_0_3_2  -192
    RHS       disj1_0_4_2  1
    RHS       disj2_0_4_2  -188
    RHS       disj1_0_5_2  1
    RHS       disj2_0_5_2  -196
    RHS       disj1_1_2_2  5
    RHS       disj2_1_2_2  -192
    RHS       disj1_1_3_2  5
    RHS       disj2_1_3_2  -192
    RHS       disj1_1_4_2  5
    RHS       disj2_1_4_2  -188
    RHS       disj1_1_5_2  5
    RHS       disj2_1_5_2  -196
    RHS       disj1_2_3_2  5
    RHS       disj2_2_3_2  -192
    RHS       disj1_2_4_2  5
    RHS       disj2_2_4_2  -188
    RHS       disj1_2_5_2  5
    RHS       disj2_2_5_2  -196
    RHS       disj1_3_4_2  5
    RHS       disj2_3_4_2  -188
    RHS       disj1_3_5_2  5
    RHS       disj2_3_5_2  -196
    RHS       disj1_4_5_2  9
    RHS       disj2_4_5_2  -196
    RHS       disj1_0_1_3  7
    RHS       disj2_0_1_3  -193
    RHS       disj1_0_2_3  7
    RHS       disj2_0_2_3  -193
    RHS       disj1_0_3_3  7
    RHS       disj2_0_3_3  -194
    RHS       disj1_0_4_3  7
    RHS       disj2_0_4_3  -196
    RHS       disj1_0_5_3  7
    RHS       disj2_0_5_3  -194
    RHS       disj1_1_2_3  4
    RHS       disj2_1_2_3  -193
    RHS       disj1_1_3_3  4
    RHS       disj2_1_3_3  -194
    RHS       disj1_1_4_3  4
    RHS       disj2_1_4_3  -196
    RHS       disj1_1_5_3  4
    RHS       disj2_1_5_3  -194
    RHS       disj1_2_3_3  4
    RHS       disj2_2_3_3  -194
    RHS       disj1_2_4_3  4
    RHS       disj2_2_4_3  -196
    RHS       disj1_2_5_3  4
    RHS       disj2_2_5_3  -194
    RHS       disj1_3_4_3  3
    RHS       disj2_3_4_3  -196
    RHS       disj1_3_5_3  3
    RHS       disj2_3_5_3  -194
    RHS       disj1_4_5_3  1
    RHS       disj2_4_5_3  -194
    RHS       disj1_0_1_4  6
    RHS       disj2_0_1_4  -187
    RHS       disj1_0_2_4  6
    RHS       disj2_0_2_4  -190
    RHS       disj1_0_3_4  6
    RHS       disj2_0_3_4  -189
    RHS       disj1_0_4_4  6
    RHS       disj2_0_4_4  -192
    RHS       disj1_0_5_4  6
    RHS       disj2_0_5_4  -193
    RHS       disj1_1_2_4  10
    RHS       disj2_1_2_4  -190
    RHS       disj1_1_3_4  10
    RHS       disj2_1_3_4  -189
    RHS       disj1_1_4_4  10
    RHS       disj2_1_4_4  -192
    RHS       disj1_1_5_4  10
    RHS       disj2_1_5_4  -193
    RHS       disj1_2_3_4  7
    RHS       disj2_2_3_4  -189
    RHS       disj1_2_4_4  7
    RHS       disj2_2_4_4  -192
    RHS       disj1_2_5_4  7
    RHS       disj2_2_5_4  -193
    RHS       disj1_3_4_4  8
    RHS       disj2_3_4_4  -192
    RHS       disj1_3_5_4  8
    RHS       disj2_3_5_4  -193
    RHS       disj1_4_5_4  5
    RHS       disj2_4_5_4  -193
    RHS       disj1_0_1_5  3
    RHS       disj2_0_1_5  -187
    RHS       disj1_0_2_5  3
    RHS       disj2_0_2_5  -189
    RHS       disj1_0_3_5  3
    RHS       disj2_0_3_5  -188
    RHS       disj1_0_4_5  3
    RHS       disj2_0_4_5  -193
    RHS       disj1_0_5_5  3
    RHS       disj2_0_5_5  -188
    RHS       disj1_1_2_5  10
    RHS       disj2_1_2_5  -189
    RHS       disj1_1_3_5  10
    RHS       disj2_1_3_5  -188
    RHS       disj1_1_4_5  10
    RHS       disj2_1_4_5  -193
    RHS       disj1_1_5_5  10
    RHS       disj2_1_5_5  -188
    RHS       disj1_2_3_5  8
    RHS       disj2_2_3_5  -188
    RHS       disj1_2_4_5  8
    RHS       disj2_2_4_5  -193
    RHS       disj1_2_5_5  8
    RHS       disj2_2_5_5  -188
    RHS       disj1_3_4_5  9
    RHS       disj2_3_4_5  -193
    RHS       disj1_3_5_5  9
    RHS       disj2_3_5_5  -188
    RHS       disj1_4_5_5  4
    RHS       disj2_4_5_5  -188
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
ENDATA
