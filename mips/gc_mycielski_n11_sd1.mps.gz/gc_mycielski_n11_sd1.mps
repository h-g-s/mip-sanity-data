NAME          gc_mycielski_n11_sd1
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 L  LINK_1_0
 L  LINK_2_0
 L  LINK_2_1
 L  LINK_3_0
 L  LINK_3_1
 L  LINK_3_2
 L  LINK_4_0
 L  LINK_4_1
 L  LINK_4_2
 L  LINK_4_3
 L  LINK_5_0
 L  LINK_5_1
 L  LINK_5_2
 L  LINK_5_3
 L  LINK_5_4
 L  LINK_6_0
 L  LINK_6_1
 L  LINK_6_2
 L  LINK_6_3
 L  LINK_6_4
 L  LINK_6_5
 L  LINK_7_0
 L  LINK_7_1
 L  LINK_7_2
 L  LINK_7_3
 L  LINK_7_4
 L  LINK_7_5
 L  LINK_7_6
 L  LINK_8_0
 L  LINK_8_1
 L  LINK_8_2
 L  LINK_8_3
 L  LINK_8_4
 L  LINK_8_5
 L  LINK_8_6
 L  LINK_8_7
 L  LINK_9_0
 L  LINK_9_1
 L  LINK_9_2
 L  LINK_9_3
 L  LINK_9_4
 L  LINK_9_5
 L  LINK_9_6
 L  LINK_9_7
 L  LINK_9_8
 L  LINK_10_0
 L  LINK_10_1
 L  LINK_10_2
 L  LINK_10_3
 L  LINK_10_4
 L  LINK_10_5
 L  LINK_10_6
 L  LINK_10_7
 L  LINK_10_8
 L  LINK_10_9
 L  EDGE_0_6_0
 L  EDGE_0_7_0
 L  EDGE_0_8_0
 L  EDGE_0_9_0
 L  EDGE_0_10_0
 L  EDGE_1_2_0
 L  EDGE_1_2_1
 L  EDGE_1_5_0
 L  EDGE_1_5_1
 L  EDGE_1_7_0
 L  EDGE_1_7_1
 L  EDGE_1_10_0
 L  EDGE_1_10_1
 L  EDGE_2_3_0
 L  EDGE_2_3_1
 L  EDGE_2_3_2
 L  EDGE_2_6_0
 L  EDGE_2_6_1
 L  EDGE_2_6_2
 L  EDGE_2_8_0
 L  EDGE_2_8_1
 L  EDGE_2_8_2
 L  EDGE_3_4_0
 L  EDGE_3_4_1
 L  EDGE_3_4_2
 L  EDGE_3_4_3
 L  EDGE_3_7_0
 L  EDGE_3_7_1
 L  EDGE_3_7_2
 L  EDGE_3_7_3
 L  EDGE_3_9_0
 L  EDGE_3_9_1
 L  EDGE_3_9_2
 L  EDGE_3_9_3
 L  EDGE_4_5_0
 L  EDGE_4_5_1
 L  EDGE_4_5_2
 L  EDGE_4_5_3
 L  EDGE_4_5_4
 L  EDGE_4_8_0
 L  EDGE_4_8_1
 L  EDGE_4_8_2
 L  EDGE_4_8_3
 L  EDGE_4_8_4
 L  EDGE_4_10_0
 L  EDGE_4_10_1
 L  EDGE_4_10_2
 L  EDGE_4_10_3
 L  EDGE_4_10_4
 L  EDGE_5_6_0
 L  EDGE_5_6_1
 L  EDGE_5_6_2
 L  EDGE_5_6_3
 L  EDGE_5_6_4
 L  EDGE_5_6_5
 L  EDGE_5_9_0
 L  EDGE_5_9_1
 L  EDGE_5_9_2
 L  EDGE_5_9_3
 L  EDGE_5_9_4
 L  EDGE_5_9_5
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_0           OBJ           1.0
    x_0_0           ASSIGN_0        1.0
    x_0_0           LINK_1_0        -1.0
    x_0_0           LINK_2_0        -1.0
    x_0_0           LINK_3_0        -1.0
    x_0_0           LINK_4_0        -1.0
    x_0_0           LINK_5_0        -1.0
    x_0_0           LINK_6_0        -1.0
    x_0_0           LINK_7_0        -1.0
    x_0_0           LINK_8_0        -1.0
    x_0_0           LINK_9_0        -1.0
    x_0_0           LINK_10_0       -1.0
    x_0_0           EDGE_0_6_0      1.0
    x_0_0           EDGE_0_7_0      1.0
    x_0_0           EDGE_0_8_0      1.0
    x_0_0           EDGE_0_9_0      1.0
    x_0_0           EDGE_0_10_0     1.0
    x_0_0           EDGE_1_2_0      -1.0
    x_0_0           EDGE_1_5_0      -1.0
    x_0_0           EDGE_1_7_0      -1.0
    x_0_0           EDGE_1_10_0     -1.0
    x_0_0           EDGE_2_3_0      -1.0
    x_0_0           EDGE_2_6_0      -1.0
    x_0_0           EDGE_2_8_0      -1.0
    x_0_0           EDGE_3_4_0      -1.0
    x_0_0           EDGE_3_7_0      -1.0
    x_0_0           EDGE_3_9_0      -1.0
    x_0_0           EDGE_4_5_0      -1.0
    x_0_0           EDGE_4_8_0      -1.0
    x_0_0           EDGE_4_10_0     -1.0
    x_0_0           EDGE_5_6_0      -1.0
    x_0_0           EDGE_5_9_0      -1.0
    x_1_0           ASSIGN_1        1.0
    x_1_0           LINK_1_0        1.0
    x_1_0           EDGE_1_2_0      1.0
    x_1_0           EDGE_1_5_0      1.0
    x_1_0           EDGE_1_7_0      1.0
    x_1_0           EDGE_1_10_0     1.0
    x_1_1           OBJ           1.0
    x_1_1           ASSIGN_1        1.0
    x_1_1           LINK_2_1        -1.0
    x_1_1           LINK_3_1        -1.0
    x_1_1           LINK_4_1        -1.0
    x_1_1           LINK_5_1        -1.0
    x_1_1           LINK_6_1        -1.0
    x_1_1           LINK_7_1        -1.0
    x_1_1           LINK_8_1        -1.0
    x_1_1           LINK_9_1        -1.0
    x_1_1           LINK_10_1       -1.0
    x_1_1           EDGE_1_2_1      1.0
    x_1_1           EDGE_1_5_1      1.0
    x_1_1           EDGE_1_7_1      1.0
    x_1_1           EDGE_1_10_1     1.0
    x_1_1           EDGE_2_3_1      -1.0
    x_1_1           EDGE_2_6_1      -1.0
    x_1_1           EDGE_2_8_1      -1.0
    x_1_1           EDGE_3_4_1      -1.0
    x_1_1           EDGE_3_7_1      -1.0
    x_1_1           EDGE_3_9_1      -1.0
    x_1_1           EDGE_4_5_1      -1.0
    x_1_1           EDGE_4_8_1      -1.0
    x_1_1           EDGE_4_10_1     -1.0
    x_1_1           EDGE_5_6_1      -1.0
    x_1_1           EDGE_5_9_1      -1.0
    x_2_0           ASSIGN_2        1.0
    x_2_0           LINK_2_0        1.0
    x_2_0           EDGE_1_2_0      1.0
    x_2_0           EDGE_2_3_0      1.0
    x_2_0           EDGE_2_6_0      1.0
    x_2_0           EDGE_2_8_0      1.0
    x_2_1           ASSIGN_2        1.0
    x_2_1           LINK_2_1        1.0
    x_2_1           EDGE_1_2_1      1.0
    x_2_1           EDGE_2_3_1      1.0
    x_2_1           EDGE_2_6_1      1.0
    x_2_1           EDGE_2_8_1      1.0
    x_2_2           OBJ           1.0
    x_2_2           ASSIGN_2        1.0
    x_2_2           LINK_3_2        -1.0
    x_2_2           LINK_4_2        -1.0
    x_2_2           LINK_5_2        -1.0
    x_2_2           LINK_6_2        -1.0
    x_2_2           LINK_7_2        -1.0
    x_2_2           LINK_8_2        -1.0
    x_2_2           LINK_9_2        -1.0
    x_2_2           LINK_10_2       -1.0
    x_2_2           EDGE_2_3_2      1.0
    x_2_2           EDGE_2_6_2      1.0
    x_2_2           EDGE_2_8_2      1.0
    x_2_2           EDGE_3_4_2      -1.0
    x_2_2           EDGE_3_7_2      -1.0
    x_2_2           EDGE_3_9_2      -1.0
    x_2_2           EDGE_4_5_2      -1.0
    x_2_2           EDGE_4_8_2      -1.0
    x_2_2           EDGE_4_10_2     -1.0
    x_2_2           EDGE_5_6_2      -1.0
    x_2_2           EDGE_5_9_2      -1.0
    x_3_0           ASSIGN_3        1.0
    x_3_0           LINK_3_0        1.0
    x_3_0           EDGE_2_3_0      1.0
    x_3_0           EDGE_3_4_0      1.0
    x_3_0           EDGE_3_7_0      1.0
    x_3_0           EDGE_3_9_0      1.0
    x_3_1           ASSIGN_3        1.0
    x_3_1           LINK_3_1        1.0
    x_3_1           EDGE_2_3_1      1.0
    x_3_1           EDGE_3_4_1      1.0
    x_3_1           EDGE_3_7_1      1.0
    x_3_1           EDGE_3_9_1      1.0
    x_3_2           ASSIGN_3        1.0
    x_3_2           LINK_3_2        1.0
    x_3_2           EDGE_2_3_2      1.0
    x_3_2           EDGE_3_4_2      1.0
    x_3_2           EDGE_3_7_2      1.0
    x_3_2           EDGE_3_9_2      1.0
    x_3_3           OBJ           1.0
    x_3_3           ASSIGN_3        1.0
    x_3_3           LINK_4_3        -1.0
    x_3_3           LINK_5_3        -1.0
    x_3_3           LINK_6_3        -1.0
    x_3_3           LINK_7_3        -1.0
    x_3_3           LINK_8_3        -1.0
    x_3_3           LINK_9_3        -1.0
    x_3_3           LINK_10_3       -1.0
    x_3_3           EDGE_3_4_3      1.0
    x_3_3           EDGE_3_7_3      1.0
    x_3_3           EDGE_3_9_3      1.0
    x_3_3           EDGE_4_5_3      -1.0
    x_3_3           EDGE_4_8_3      -1.0
    x_3_3           EDGE_4_10_3     -1.0
    x_3_3           EDGE_5_6_3      -1.0
    x_3_3           EDGE_5_9_3      -1.0
    x_4_0           ASSIGN_4        1.0
    x_4_0           LINK_4_0        1.0
    x_4_0           EDGE_3_4_0      1.0
    x_4_0           EDGE_4_5_0      1.0
    x_4_0           EDGE_4_8_0      1.0
    x_4_0           EDGE_4_10_0     1.0
    x_4_1           ASSIGN_4        1.0
    x_4_1           LINK_4_1        1.0
    x_4_1           EDGE_3_4_1      1.0
    x_4_1           EDGE_4_5_1      1.0
    x_4_1           EDGE_4_8_1      1.0
    x_4_1           EDGE_4_10_1     1.0
    x_4_2           ASSIGN_4        1.0
    x_4_2           LINK_4_2        1.0
    x_4_2           EDGE_3_4_2      1.0
    x_4_2           EDGE_4_5_2      1.0
    x_4_2           EDGE_4_8_2      1.0
    x_4_2           EDGE_4_10_2     1.0
    x_4_3           ASSIGN_4        1.0
    x_4_3           LINK_4_3        1.0
    x_4_3           EDGE_3_4_3      1.0
    x_4_3           EDGE_4_5_3      1.0
    x_4_3           EDGE_4_8_3      1.0
    x_4_3           EDGE_4_10_3     1.0
    x_4_4           OBJ           1.0
    x_4_4           ASSIGN_4        1.0
    x_4_4           LINK_5_4        -1.0
    x_4_4           LINK_6_4        -1.0
    x_4_4           LINK_7_4        -1.0
    x_4_4           LINK_8_4        -1.0
    x_4_4           LINK_9_4        -1.0
    x_4_4           LINK_10_4       -1.0
    x_4_4           EDGE_4_5_4      1.0
    x_4_4           EDGE_4_8_4      1.0
    x_4_4           EDGE_4_10_4     1.0
    x_4_4           EDGE_5_6_4      -1.0
    x_4_4           EDGE_5_9_4      -1.0
    x_5_0           ASSIGN_5        1.0
    x_5_0           LINK_5_0        1.0
    x_5_0           EDGE_1_5_0      1.0
    x_5_0           EDGE_4_5_0      1.0
    x_5_0           EDGE_5_6_0      1.0
    x_5_0           EDGE_5_9_0      1.0
    x_5_1           ASSIGN_5        1.0
    x_5_1           LINK_5_1        1.0
    x_5_1           EDGE_1_5_1      1.0
    x_5_1           EDGE_4_5_1      1.0
    x_5_1           EDGE_5_6_1      1.0
    x_5_1           EDGE_5_9_1      1.0
    x_5_2           ASSIGN_5        1.0
    x_5_2           LINK_5_2        1.0
    x_5_2           EDGE_4_5_2      1.0
    x_5_2           EDGE_5_6_2      1.0
    x_5_2           EDGE_5_9_2      1.0
    x_5_3           ASSIGN_5        1.0
    x_5_3           LINK_5_3        1.0
    x_5_3           EDGE_4_5_3      1.0
    x_5_3           EDGE_5_6_3      1.0
    x_5_3           EDGE_5_9_3      1.0
    x_5_4           ASSIGN_5        1.0
    x_5_4           LINK_5_4        1.0
    x_5_4           EDGE_4_5_4      1.0
    x_5_4           EDGE_5_6_4      1.0
    x_5_4           EDGE_5_9_4      1.0
    x_5_5           OBJ           1.0
    x_5_5           ASSIGN_5        1.0
    x_5_5           LINK_6_5        -1.0
    x_5_5           LINK_7_5        -1.0
    x_5_5           LINK_8_5        -1.0
    x_5_5           LINK_9_5        -1.0
    x_5_5           LINK_10_5       -1.0
    x_5_5           EDGE_5_6_5      1.0
    x_5_5           EDGE_5_9_5      1.0
    x_6_0           ASSIGN_6        1.0
    x_6_0           LINK_6_0        1.0
    x_6_0           EDGE_0_6_0      1.0
    x_6_0           EDGE_2_6_0      1.0
    x_6_0           EDGE_5_6_0      1.0
    x_6_1           ASSIGN_6        1.0
    x_6_1           LINK_6_1        1.0
    x_6_1           EDGE_2_6_1      1.0
    x_6_1           EDGE_5_6_1      1.0
    x_6_2           ASSIGN_6        1.0
    x_6_2           LINK_6_2        1.0
    x_6_2           EDGE_2_6_2      1.0
    x_6_2           EDGE_5_6_2      1.0
    x_6_3           ASSIGN_6        1.0
    x_6_3           LINK_6_3        1.0
    x_6_3           EDGE_5_6_3      1.0
    x_6_4           ASSIGN_6        1.0
    x_6_4           LINK_6_4        1.0
    x_6_4           EDGE_5_6_4      1.0
    x_6_5           ASSIGN_6        1.0
    x_6_5           LINK_6_5        1.0
    x_6_5           EDGE_5_6_5      1.0
    x_6_6           OBJ           1.0
    x_6_6           ASSIGN_6        1.0
    x_6_6           LINK_7_6        -1.0
    x_6_6           LINK_8_6        -1.0
    x_6_6           LINK_9_6        -1.0
    x_6_6           LINK_10_6       -1.0
    x_7_0           ASSIGN_7        1.0
    x_7_0           LINK_7_0        1.0
    x_7_0           EDGE_0_7_0      1.0
    x_7_0           EDGE_1_7_0      1.0
    x_7_0           EDGE_3_7_0      1.0
    x_7_1           ASSIGN_7        1.0
    x_7_1           LINK_7_1        1.0
    x_7_1           EDGE_1_7_1      1.0
    x_7_1           EDGE_3_7_1      1.0
    x_7_2           ASSIGN_7        1.0
    x_7_2           LINK_7_2        1.0
    x_7_2           EDGE_3_7_2      1.0
    x_7_3           ASSIGN_7        1.0
    x_7_3           LINK_7_3        1.0
    x_7_3           EDGE_3_7_3      1.0
    x_7_4           ASSIGN_7        1.0
    x_7_4           LINK_7_4        1.0
    x_7_5           ASSIGN_7        1.0
    x_7_5           LINK_7_5        1.0
    x_7_6           ASSIGN_7        1.0
    x_7_6           LINK_7_6        1.0
    x_7_7           OBJ           1.0
    x_7_7           ASSIGN_7        1.0
    x_7_7           LINK_8_7        -1.0
    x_7_7           LINK_9_7        -1.0
    x_7_7           LINK_10_7       -1.0
    x_8_0           ASSIGN_8        1.0
    x_8_0           LINK_8_0        1.0
    x_8_0           EDGE_0_8_0      1.0
    x_8_0           EDGE_2_8_0      1.0
    x_8_0           EDGE_4_8_0      1.0
    x_8_1           ASSIGN_8        1.0
    x_8_1           LINK_8_1        1.0
    x_8_1           EDGE_2_8_1      1.0
    x_8_1           EDGE_4_8_1      1.0
    x_8_2           ASSIGN_8        1.0
    x_8_2           LINK_8_2        1.0
    x_8_2           EDGE_2_8_2      1.0
    x_8_2           EDGE_4_8_2      1.0
    x_8_3           ASSIGN_8        1.0
    x_8_3           LINK_8_3        1.0
    x_8_3           EDGE_4_8_3      1.0
    x_8_4           ASSIGN_8        1.0
    x_8_4           LINK_8_4        1.0
    x_8_4           EDGE_4_8_4      1.0
    x_8_5           ASSIGN_8        1.0
    x_8_5           LINK_8_5        1.0
    x_8_6           ASSIGN_8        1.0
    x_8_6           LINK_8_6        1.0
    x_8_7           ASSIGN_8        1.0
    x_8_7           LINK_8_7        1.0
    x_8_8           OBJ           1.0
    x_8_8           ASSIGN_8        1.0
    x_8_8           LINK_9_8        -1.0
    x_8_8           LINK_10_8       -1.0
    x_9_0           ASSIGN_9        1.0
    x_9_0           LINK_9_0        1.0
    x_9_0           EDGE_0_9_0      1.0
    x_9_0           EDGE_3_9_0      1.0
    x_9_0           EDGE_5_9_0      1.0
    x_9_1           ASSIGN_9        1.0
    x_9_1           LINK_9_1        1.0
    x_9_1           EDGE_3_9_1      1.0
    x_9_1           EDGE_5_9_1      1.0
    x_9_2           ASSIGN_9        1.0
    x_9_2           LINK_9_2        1.0
    x_9_2           EDGE_3_9_2      1.0
    x_9_2           EDGE_5_9_2      1.0
    x_9_3           ASSIGN_9        1.0
    x_9_3           LINK_9_3        1.0
    x_9_3           EDGE_3_9_3      1.0
    x_9_3           EDGE_5_9_3      1.0
    x_9_4           ASSIGN_9        1.0
    x_9_4           LINK_9_4        1.0
    x_9_4           EDGE_5_9_4      1.0
    x_9_5           ASSIGN_9        1.0
    x_9_5           LINK_9_5        1.0
    x_9_5           EDGE_5_9_5      1.0
    x_9_6           ASSIGN_9        1.0
    x_9_6           LINK_9_6        1.0
    x_9_7           ASSIGN_9        1.0
    x_9_7           LINK_9_7        1.0
    x_9_8           ASSIGN_9        1.0
    x_9_8           LINK_9_8        1.0
    x_9_9           OBJ           1.0
    x_9_9           ASSIGN_9        1.0
    x_9_9           LINK_10_9       -1.0
    x_10_0          ASSIGN_10       1.0
    x_10_0          LINK_10_0       1.0
    x_10_0          EDGE_0_10_0     1.0
    x_10_0          EDGE_1_10_0     1.0
    x_10_0          EDGE_4_10_0     1.0
    x_10_1          ASSIGN_10       1.0
    x_10_1          LINK_10_1       1.0
    x_10_1          EDGE_1_10_1     1.0
    x_10_1          EDGE_4_10_1     1.0
    x_10_2          ASSIGN_10       1.0
    x_10_2          LINK_10_2       1.0
    x_10_2          EDGE_4_10_2     1.0
    x_10_3          ASSIGN_10       1.0
    x_10_3          LINK_10_3       1.0
    x_10_3          EDGE_4_10_3     1.0
    x_10_4          ASSIGN_10       1.0
    x_10_4          LINK_10_4       1.0
    x_10_4          EDGE_4_10_4     1.0
    x_10_5          ASSIGN_10       1.0
    x_10_5          LINK_10_5       1.0
    x_10_6          ASSIGN_10       1.0
    x_10_6          LINK_10_6       1.0
    x_10_7          ASSIGN_10       1.0
    x_10_7          LINK_10_7       1.0
    x_10_8          ASSIGN_10       1.0
    x_10_8          LINK_10_8       1.0
    x_10_9          ASSIGN_10       1.0
    x_10_9          LINK_10_9       1.0
    x_10_10         OBJ           1.0
    x_10_10         ASSIGN_10       1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           ASSIGN_0        1.0
    RHS           ASSIGN_1        1.0
    RHS           ASSIGN_2        1.0
    RHS           ASSIGN_3        1.0
    RHS           ASSIGN_4        1.0
    RHS           ASSIGN_5        1.0
    RHS           ASSIGN_6        1.0
    RHS           ASSIGN_7        1.0
    RHS           ASSIGN_8        1.0
    RHS           ASSIGN_9        1.0
    RHS           ASSIGN_10       1.0
    RHS           EDGE_0_6_0      1.0
    RHS           EDGE_0_7_0      1.0
    RHS           EDGE_0_8_0      1.0
    RHS           EDGE_0_9_0      1.0
    RHS           EDGE_0_10_0     1.0
    RHS           EDGE_1_2_1      1.0
    RHS           EDGE_1_5_1      1.0
    RHS           EDGE_1_7_1      1.0
    RHS           EDGE_1_10_1     1.0
    RHS           EDGE_2_3_2      1.0
    RHS           EDGE_2_6_2      1.0
    RHS           EDGE_2_8_2      1.0
    RHS           EDGE_3_4_3      1.0
    RHS           EDGE_3_7_3      1.0
    RHS           EDGE_3_9_3      1.0
    RHS           EDGE_4_5_4      1.0
    RHS           EDGE_4_8_4      1.0
    RHS           EDGE_4_10_4     1.0
    RHS           EDGE_5_6_5      1.0
    RHS           EDGE_5_9_5      1.0
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_2
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_3
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_4
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_5
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_6
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 BV BOUND         x_7_7
 BV BOUND         x_8_0
 BV BOUND         x_8_1
 BV BOUND         x_8_2
 BV BOUND         x_8_3
 BV BOUND         x_8_4
 BV BOUND         x_8_5
 BV BOUND         x_8_6
 BV BOUND         x_8_7
 BV BOUND         x_8_8
 BV BOUND         x_9_0
 BV BOUND         x_9_1
 BV BOUND         x_9_2
 BV BOUND         x_9_3
 BV BOUND         x_9_4
 BV BOUND         x_9_5
 BV BOUND         x_9_6
 BV BOUND         x_9_7
 BV BOUND         x_9_8
 BV BOUND         x_9_9
 BV BOUND         x_10_0
 BV BOUND         x_10_1
 BV BOUND         x_10_2
 BV BOUND         x_10_3
 BV BOUND         x_10_4
 BV BOUND         x_10_5
 BV BOUND         x_10_6
 BV BOUND         x_10_7
 BV BOUND         x_10_8
 BV BOUND         x_10_9
 BV BOUND         x_10_10
ENDATA
