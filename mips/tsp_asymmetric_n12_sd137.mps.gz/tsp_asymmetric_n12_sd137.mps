NAME          tsp_asymmetric_n12_sd137
ROWS
 N  OBJ
 E  OUT_0
 E  OUT_1
 E  OUT_2
 E  OUT_3
 E  OUT_4
 E  OUT_5
 E  OUT_6
 E  OUT_7
 E  OUT_8
 E  OUT_9
 E  OUT_10
 E  OUT_11
 E  IN_0
 E  IN_1
 E  IN_2
 E  IN_3
 E  IN_4
 E  IN_5
 E  IN_6
 E  IN_7
 E  IN_8
 E  IN_9
 E  IN_10
 E  IN_11
 L  MTZ_1_2
 L  MTZ_1_3
 L  MTZ_1_4
 L  MTZ_1_5
 L  MTZ_1_6
 L  MTZ_1_7
 L  MTZ_1_8
 L  MTZ_1_9
 L  MTZ_1_10
 L  MTZ_1_11
 L  MTZ_2_1
 L  MTZ_2_3
 L  MTZ_2_4
 L  MTZ_2_5
 L  MTZ_2_6
 L  MTZ_2_7
 L  MTZ_2_8
 L  MTZ_2_9
 L  MTZ_2_10
 L  MTZ_2_11
 L  MTZ_3_1
 L  MTZ_3_2
 L  MTZ_3_4
 L  MTZ_3_5
 L  MTZ_3_6
 L  MTZ_3_7
 L  MTZ_3_8
 L  MTZ_3_9
 L  MTZ_3_10
 L  MTZ_3_11
 L  MTZ_4_1
 L  MTZ_4_2
 L  MTZ_4_3
 L  MTZ_4_5
 L  MTZ_4_6
 L  MTZ_4_7
 L  MTZ_4_8
 L  MTZ_4_9
 L  MTZ_4_10
 L  MTZ_4_11
 L  MTZ_5_1
 L  MTZ_5_2
 L  MTZ_5_3
 L  MTZ_5_4
 L  MTZ_5_6
 L  MTZ_5_7
 L  MTZ_5_8
 L  MTZ_5_9
 L  MTZ_5_10
 L  MTZ_5_11
 L  MTZ_6_1
 L  MTZ_6_2
 L  MTZ_6_3
 L  MTZ_6_4
 L  MTZ_6_5
 L  MTZ_6_7
 L  MTZ_6_8
 L  MTZ_6_9
 L  MTZ_6_10
 L  MTZ_6_11
 L  MTZ_7_1
 L  MTZ_7_2
 L  MTZ_7_3
 L  MTZ_7_4
 L  MTZ_7_5
 L  MTZ_7_6
 L  MTZ_7_8
 L  MTZ_7_9
 L  MTZ_7_10
 L  MTZ_7_11
 L  MTZ_8_1
 L  MTZ_8_2
 L  MTZ_8_3
 L  MTZ_8_4
 L  MTZ_8_5
 L  MTZ_8_6
 L  MTZ_8_7
 L  MTZ_8_9
 L  MTZ_8_10
 L  MTZ_8_11
 L  MTZ_9_1
 L  MTZ_9_2
 L  MTZ_9_3
 L  MTZ_9_4
 L  MTZ_9_5
 L  MTZ_9_6
 L  MTZ_9_7
 L  MTZ_9_8
 L  MTZ_9_10
 L  MTZ_9_11
 L  MTZ_10_1
 L  MTZ_10_2
 L  MTZ_10_3
 L  MTZ_10_4
 L  MTZ_10_5
 L  MTZ_10_6
 L  MTZ_10_7
 L  MTZ_10_8
 L  MTZ_10_9
 L  MTZ_10_11
 L  MTZ_11_1
 L  MTZ_11_2
 L  MTZ_11_3
 L  MTZ_11_4
 L  MTZ_11_5
 L  MTZ_11_6
 L  MTZ_11_7
 L  MTZ_11_8
 L  MTZ_11_9
 L  MTZ_11_10
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_1           OBJ           695
    x_0_1           OUT_0           1.0
    x_0_1           IN_1            1.0
    x_0_2           OBJ           468
    x_0_2           OUT_0           1.0
    x_0_2           IN_2            1.0
    x_0_3           OBJ           1079
    x_0_3           OUT_0           1.0
    x_0_3           IN_3            1.0
    x_0_4           OBJ           828
    x_0_4           OUT_0           1.0
    x_0_4           IN_4            1.0
    x_0_5           OBJ           481
    x_0_5           OUT_0           1.0
    x_0_5           IN_5            1.0
    x_0_6           OBJ           442
    x_0_6           OUT_0           1.0
    x_0_6           IN_6            1.0
    x_0_7           OBJ           485
    x_0_7           OUT_0           1.0
    x_0_7           IN_7            1.0
    x_0_8           OBJ           950
    x_0_8           OUT_0           1.0
    x_0_8           IN_8            1.0
    x_0_9           OBJ           1092
    x_0_9           OUT_0           1.0
    x_0_9           IN_9            1.0
    x_0_10          OBJ           1023
    x_0_10          OUT_0           1.0
    x_0_10          IN_10           1.0
    x_0_11          OBJ           986
    x_0_11          OUT_0           1.0
    x_0_11          IN_11           1.0
    x_1_0           OBJ           731
    x_1_0           OUT_1           1.0
    x_1_0           IN_0            1.0
    x_1_2           OBJ           833
    x_1_2           OUT_1           1.0
    x_1_2           IN_2            1.0
    x_1_2           MTZ_1_2         11.0
    x_1_3           OBJ           301
    x_1_3           OUT_1           1.0
    x_1_3           IN_3            1.0
    x_1_3           MTZ_1_3         11.0
    x_1_4           OBJ           427
    x_1_4           OUT_1           1.0
    x_1_4           IN_4            1.0
    x_1_4           MTZ_1_4         11.0
    x_1_5           OBJ           339
    x_1_5           OUT_1           1.0
    x_1_5           IN_5            1.0
    x_1_5           MTZ_1_5         11.0
    x_1_6           OBJ           812
    x_1_6           OUT_1           1.0
    x_1_6           IN_6            1.0
    x_1_6           MTZ_1_6         11.0
    x_1_7           OBJ           792
    x_1_7           OUT_1           1.0
    x_1_7           IN_7            1.0
    x_1_7           MTZ_1_7         11.0
    x_1_8           OBJ           113
    x_1_8           OUT_1           1.0
    x_1_8           IN_8            1.0
    x_1_8           MTZ_1_8         11.0
    x_1_9           OBJ           88
    x_1_9           OUT_1           1.0
    x_1_9           IN_9            1.0
    x_1_9           MTZ_1_9         11.0
    x_1_10          OBJ           775
    x_1_10          OUT_1           1.0
    x_1_10          IN_10           1.0
    x_1_10          MTZ_1_10        11.0
    x_1_11          OBJ           694
    x_1_11          OUT_1           1.0
    x_1_11          IN_11           1.0
    x_1_11          MTZ_1_11        11.0
    x_2_0           OBJ           632
    x_2_0           OUT_2           1.0
    x_2_0           IN_0            1.0
    x_2_1           OBJ           1028
    x_2_1           OUT_2           1.0
    x_2_1           IN_1            1.0
    x_2_1           MTZ_2_1         11.0
    x_2_3           OBJ           562
    x_2_3           OUT_2           1.0
    x_2_3           IN_3            1.0
    x_2_3           MTZ_2_3         11.0
    x_2_4           OBJ           433
    x_2_4           OUT_2           1.0
    x_2_4           IN_4            1.0
    x_2_4           MTZ_2_4         11.0
    x_2_5           OBJ           664
    x_2_5           OUT_2           1.0
    x_2_5           IN_5            1.0
    x_2_5           MTZ_2_5         11.0
    x_2_6           OBJ           231
    x_2_6           OUT_2           1.0
    x_2_6           IN_6            1.0
    x_2_6           MTZ_2_6         11.0
    x_2_7           OBJ           793
    x_2_7           OUT_2           1.0
    x_2_7           IN_7            1.0
    x_2_7           MTZ_2_7         11.0
    x_2_8           OBJ           929
    x_2_8           OUT_2           1.0
    x_2_8           IN_8            1.0
    x_2_8           MTZ_2_8         11.0
    x_2_9           OBJ           691
    x_2_9           OUT_2           1.0
    x_2_9           IN_9            1.0
    x_2_9           MTZ_2_9         11.0
    x_2_10          OBJ           472
    x_2_10          OUT_2           1.0
    x_2_10          IN_10           1.0
    x_2_10          MTZ_2_10        11.0
    x_2_11          OBJ           777
    x_2_11          OUT_2           1.0
    x_2_11          IN_11           1.0
    x_2_11          MTZ_2_11        11.0
    x_3_0           OBJ           856
    x_3_0           OUT_3           1.0
    x_3_0           IN_0            1.0
    x_3_1           OBJ           307
    x_3_1           OUT_3           1.0
    x_3_1           IN_1            1.0
    x_3_1           MTZ_3_1         11.0
    x_3_2           OBJ           708
    x_3_2           OUT_3           1.0
    x_3_2           IN_2            1.0
    x_3_2           MTZ_3_2         11.0
    x_3_4           OBJ           239
    x_3_4           OUT_3           1.0
    x_3_4           IN_4            1.0
    x_3_4           MTZ_3_4         11.0
    x_3_5           OBJ           624
    x_3_5           OUT_3           1.0
    x_3_5           IN_5            1.0
    x_3_5           MTZ_3_5         11.0
    x_3_6           OBJ           359
    x_3_6           OUT_3           1.0
    x_3_6           IN_6            1.0
    x_3_6           MTZ_3_6         11.0
    x_3_7           OBJ           1033
    x_3_7           OUT_3           1.0
    x_3_7           IN_7            1.0
    x_3_7           MTZ_3_7         11.0
    x_3_8           OBJ           451
    x_3_8           OUT_3           1.0
    x_3_8           IN_8            1.0
    x_3_8           MTZ_3_8         11.0
    x_3_9           OBJ           237
    x_3_9           OUT_3           1.0
    x_3_9           IN_9            1.0
    x_3_9           MTZ_3_9         11.0
    x_3_10          OBJ           408
    x_3_10          OUT_3           1.0
    x_3_10          IN_10           1.0
    x_3_10          MTZ_3_10        11.0
    x_3_11          OBJ           354
    x_3_11          OUT_3           1.0
    x_3_11          IN_11           1.0
    x_3_11          MTZ_3_11        11.0
    x_4_0           OBJ           838
    x_4_0           OUT_4           1.0
    x_4_0           IN_0            1.0
    x_4_1           OBJ           757
    x_4_1           OUT_4           1.0
    x_4_1           IN_1            1.0
    x_4_1           MTZ_4_1         11.0
    x_4_2           OBJ           776
    x_4_2           OUT_4           1.0
    x_4_2           IN_2            1.0
    x_4_2           MTZ_4_2         11.0
    x_4_3           OBJ           257
    x_4_3           OUT_4           1.0
    x_4_3           IN_3            1.0
    x_4_3           MTZ_4_3         11.0
    x_4_5           OBJ           949
    x_4_5           OUT_4           1.0
    x_4_5           IN_5            1.0
    x_4_5           MTZ_4_5         11.0
    x_4_6           OBJ           748
    x_4_6           OUT_4           1.0
    x_4_6           IN_6            1.0
    x_4_6           MTZ_4_6         11.0
    x_4_7           OBJ           1055
    x_4_7           OUT_4           1.0
    x_4_7           IN_7            1.0
    x_4_7           MTZ_4_7         11.0
    x_4_8           OBJ           815
    x_4_8           OUT_4           1.0
    x_4_8           IN_8            1.0
    x_4_8           MTZ_4_8         11.0
    x_4_9           OBJ           575
    x_4_9           OUT_4           1.0
    x_4_9           IN_9            1.0
    x_4_9           MTZ_4_9         11.0
    x_4_10          OBJ           186
    x_4_10          OUT_4           1.0
    x_4_10          IN_10           1.0
    x_4_10          MTZ_4_10        11.0
    x_4_11          OBJ           37
    x_4_11          OUT_4           1.0
    x_4_11          IN_11           1.0
    x_4_11          MTZ_4_11        11.0
    x_5_0           OBJ           418
    x_5_0           OUT_5           1.0
    x_5_0           IN_0            1.0
    x_5_1           OBJ           564
    x_5_1           OUT_5           1.0
    x_5_1           IN_1            1.0
    x_5_1           MTZ_5_1         11.0
    x_5_2           OBJ           800
    x_5_2           OUT_5           1.0
    x_5_2           IN_2            1.0
    x_5_2           MTZ_5_2         11.0
    x_5_3           OBJ           602
    x_5_3           OUT_5           1.0
    x_5_3           IN_3            1.0
    x_5_3           MTZ_5_3         11.0
    x_5_4           OBJ           1021
    x_5_4           OUT_5           1.0
    x_5_4           IN_4            1.0
    x_5_4           MTZ_5_4         11.0
    x_5_6           OBJ           369
    x_5_6           OUT_5           1.0
    x_5_6           IN_6            1.0
    x_5_6           MTZ_5_6         11.0
    x_5_7           OBJ           664
    x_5_7           OUT_5           1.0
    x_5_7           IN_7            1.0
    x_5_7           MTZ_5_7         11.0
    x_5_8           OBJ           454
    x_5_8           OUT_5           1.0
    x_5_8           IN_8            1.0
    x_5_8           MTZ_5_8         11.0
    x_5_9           OBJ           469
    x_5_9           OUT_5           1.0
    x_5_9           IN_9            1.0
    x_5_9           MTZ_5_9         11.0
    x_5_10          OBJ           609
    x_5_10          OUT_5           1.0
    x_5_10          IN_10           1.0
    x_5_10          MTZ_5_10        11.0
    x_5_11          OBJ           604
    x_5_11          OUT_5           1.0
    x_5_11          IN_11           1.0
    x_5_11          MTZ_5_11        11.0
    x_6_0           OBJ           407
    x_6_0           OUT_6           1.0
    x_6_0           IN_0            1.0
    x_6_1           OBJ           494
    x_6_1           OUT_6           1.0
    x_6_1           IN_1            1.0
    x_6_1           MTZ_6_1         11.0
    x_6_2           OBJ           363
    x_6_2           OUT_6           1.0
    x_6_2           IN_2            1.0
    x_6_2           MTZ_6_2         11.0
    x_6_3           OBJ           516
    x_6_3           OUT_6           1.0
    x_6_3           IN_3            1.0
    x_6_3           MTZ_6_3         11.0
    x_6_4           OBJ           658
    x_6_4           OUT_6           1.0
    x_6_4           IN_4            1.0
    x_6_4           MTZ_6_4         11.0
    x_6_5           OBJ           480
    x_6_5           OUT_6           1.0
    x_6_5           IN_5            1.0
    x_6_5           MTZ_6_5         11.0
    x_6_7           OBJ           573
    x_6_7           OUT_6           1.0
    x_6_7           IN_7            1.0
    x_6_7           MTZ_6_7         11.0
    x_6_8           OBJ           807
    x_6_8           OUT_6           1.0
    x_6_8           IN_8            1.0
    x_6_8           MTZ_6_8         11.0
    x_6_9           OBJ           747
    x_6_9           OUT_6           1.0
    x_6_9           IN_9            1.0
    x_6_9           MTZ_6_9         11.0
    x_6_10          OBJ           413
    x_6_10          OUT_6           1.0
    x_6_10          IN_10           1.0
    x_6_10          MTZ_6_10        11.0
    x_6_11          OBJ           675
    x_6_11          OUT_6           1.0
    x_6_11          IN_11           1.0
    x_6_11          MTZ_6_11        11.0
    x_7_0           OBJ           319
    x_7_0           OUT_7           1.0
    x_7_0           IN_0            1.0
    x_7_1           OBJ           1047
    x_7_1           OUT_7           1.0
    x_7_1           IN_1            1.0
    x_7_1           MTZ_7_1         11.0
    x_7_2           OBJ           1022
    x_7_2           OUT_7           1.0
    x_7_2           IN_2            1.0
    x_7_2           MTZ_7_2         11.0
    x_7_3           OBJ           958
    x_7_3           OUT_7           1.0
    x_7_3           IN_3            1.0
    x_7_3           MTZ_7_3         11.0
    x_7_4           OBJ           1467
    x_7_4           OUT_7           1.0
    x_7_4           IN_4            1.0
    x_7_4           MTZ_7_4         11.0
    x_7_5           OBJ           498
    x_7_5           OUT_7           1.0
    x_7_5           IN_5            1.0
    x_7_5           MTZ_7_5         11.0
    x_7_6           OBJ           565
    x_7_6           OUT_7           1.0
    x_7_6           IN_6            1.0
    x_7_6           MTZ_7_6         11.0
    x_7_8           OBJ           1266
    x_7_8           OUT_7           1.0
    x_7_8           IN_8            1.0
    x_7_8           MTZ_7_8         11.0
    x_7_9           OBJ           840
    x_7_9           OUT_7           1.0
    x_7_9           IN_9            1.0
    x_7_9           MTZ_7_9         11.0
    x_7_10          OBJ           1286
    x_7_10          OUT_7           1.0
    x_7_10          IN_10           1.0
    x_7_10          MTZ_7_10        11.0
    x_7_11          OBJ           1398
    x_7_11          OUT_7           1.0
    x_7_11          IN_11           1.0
    x_7_11          MTZ_7_11        11.0
    x_8_0           OBJ           683
    x_8_0           OUT_8           1.0
    x_8_0           IN_0            1.0
    x_8_1           OBJ           106
    x_8_1           OUT_8           1.0
    x_8_1           IN_1            1.0
    x_8_1           MTZ_8_1         11.0
    x_8_2           OBJ           1079
    x_8_2           OUT_8           1.0
    x_8_2           IN_2            1.0
    x_8_2           MTZ_8_2         11.0
    x_8_3           OBJ           474
    x_8_3           OUT_8           1.0
    x_8_3           IN_3            1.0
    x_8_3           MTZ_8_3         11.0
    x_8_4           OBJ           529
    x_8_4           OUT_8           1.0
    x_8_4           IN_4            1.0
    x_8_4           MTZ_8_4         11.0
    x_8_5           OBJ           396
    x_8_5           OUT_8           1.0
    x_8_5           IN_5            1.0
    x_8_5           MTZ_8_5         11.0
    x_8_6           OBJ           844
    x_8_6           OUT_8           1.0
    x_8_6           IN_6            1.0
    x_8_6           MTZ_8_6         11.0
    x_8_7           OBJ           1132
    x_8_7           OUT_8           1.0
    x_8_7           IN_7            1.0
    x_8_7           MTZ_8_7         11.0
    x_8_9           OBJ           62
    x_8_9           OUT_8           1.0
    x_8_9           IN_9            1.0
    x_8_9           MTZ_8_9         11.0
    x_8_10          OBJ           839
    x_8_10          OUT_8           1.0
    x_8_10          IN_10           1.0
    x_8_10          MTZ_8_10        11.0
    x_8_11          OBJ           588
    x_8_11          OUT_8           1.0
    x_8_11          IN_11           1.0
    x_8_11          MTZ_8_11        11.0
    x_9_0           OBJ           604
    x_9_0           OUT_9           1.0
    x_9_0           IN_0            1.0
    x_9_1           OBJ           80
    x_9_1           OUT_9           1.0
    x_9_1           IN_1            1.0
    x_9_1           MTZ_9_1         11.0
    x_9_2           OBJ           689
    x_9_2           OUT_9           1.0
    x_9_2           IN_2            1.0
    x_9_2           MTZ_9_2         11.0
    x_9_3           OBJ           415
    x_9_3           OUT_9           1.0
    x_9_3           IN_3            1.0
    x_9_3           MTZ_9_3         11.0
    x_9_4           OBJ           683
    x_9_4           OUT_9           1.0
    x_9_4           IN_4            1.0
    x_9_4           MTZ_9_4         11.0
    x_9_5           OBJ           365
    x_9_5           OUT_9           1.0
    x_9_5           IN_5            1.0
    x_9_5           MTZ_9_5         11.0
    x_9_6           OBJ           625
    x_9_6           OUT_9           1.0
    x_9_6           IN_6            1.0
    x_9_6           MTZ_9_6         11.0
    x_9_7           OBJ           971
    x_9_7           OUT_9           1.0
    x_9_7           IN_7            1.0
    x_9_7           MTZ_9_7         11.0
    x_9_8           OBJ           68
    x_9_8           OUT_9           1.0
    x_9_8           IN_8            1.0
    x_9_8           MTZ_9_8         11.0
    x_9_10          OBJ           886
    x_9_10          OUT_9           1.0
    x_9_10          IN_10           1.0
    x_9_10          MTZ_9_10        11.0
    x_9_11          OBJ           450
    x_9_11          OUT_9           1.0
    x_9_11          IN_11           1.0
    x_9_11          MTZ_9_11        11.0
    x_10_0          OBJ           695
    x_10_0          OUT_10          1.0
    x_10_0          IN_0            1.0
    x_10_1          OBJ           792
    x_10_1          OUT_10          1.0
    x_10_1          IN_1            1.0
    x_10_1          MTZ_10_1        11.0
    x_10_2          OBJ           331
    x_10_2          OUT_10          1.0
    x_10_2          IN_2            1.0
    x_10_2          MTZ_10_2        11.0
    x_10_3          OBJ           359
    x_10_3          OUT_10          1.0
    x_10_3          IN_3            1.0
    x_10_3          MTZ_10_3        11.0
    x_10_4          OBJ           197
    x_10_4          OUT_10          1.0
    x_10_4          IN_4            1.0
    x_10_4          MTZ_10_4        11.0
    x_10_5          OBJ           605
    x_10_5          OUT_10          1.0
    x_10_5          IN_5            1.0
    x_10_5          MTZ_10_5        11.0
    x_10_6          OBJ           585
    x_10_6          OUT_10          1.0
    x_10_6          IN_6            1.0
    x_10_6          MTZ_10_6        11.0
    x_10_7          OBJ           1094
    x_10_7          OUT_10          1.0
    x_10_7          IN_7            1.0
    x_10_7          MTZ_10_7        11.0
    x_10_8          OBJ           685
    x_10_8          OUT_10          1.0
    x_10_8          IN_8            1.0
    x_10_8          MTZ_10_8        11.0
    x_10_9          OBJ           699
    x_10_9          OUT_10          1.0
    x_10_9          IN_9            1.0
    x_10_9          MTZ_10_9        11.0
    x_10_11         OBJ           149
    x_10_11         OUT_10          1.0
    x_10_11         IN_11           1.0
    x_10_11         MTZ_10_11       11.0
    x_11_0          OBJ           856
    x_11_0          OUT_11          1.0
    x_11_0          IN_0            1.0
    x_11_1          OBJ           727
    x_11_1          OUT_11          1.0
    x_11_1          IN_1            1.0
    x_11_1          MTZ_11_1        11.0
    x_11_2          OBJ           724
    x_11_2          OUT_11          1.0
    x_11_2          IN_2            1.0
    x_11_2          MTZ_11_2        11.0
    x_11_3          OBJ           259
    x_11_3          OUT_11          1.0
    x_11_3          IN_3            1.0
    x_11_3          MTZ_11_3        11.0
    x_11_4          OBJ           45
    x_11_4          OUT_11          1.0
    x_11_4          IN_4            1.0
    x_11_4          MTZ_11_4        11.0
    x_11_5          OBJ           800
    x_11_5          OUT_11          1.0
    x_11_5          IN_5            1.0
    x_11_5          MTZ_11_5        11.0
    x_11_6          OBJ           697
    x_11_6          OUT_11          1.0
    x_11_6          IN_6            1.0
    x_11_6          MTZ_11_6        11.0
    x_11_7          OBJ           1077
    x_11_7          OUT_11          1.0
    x_11_7          IN_7            1.0
    x_11_7          MTZ_11_7        11.0
    x_11_8          OBJ           614
    x_11_8          OUT_11          1.0
    x_11_8          IN_8            1.0
    x_11_8          MTZ_11_8        11.0
    x_11_9          OBJ           581
    x_11_9          OUT_11          1.0
    x_11_9          IN_9            1.0
    x_11_9          MTZ_11_9        11.0
    x_11_10         OBJ           164
    x_11_10         OUT_11          1.0
    x_11_10         IN_10           1.0
    x_11_10         MTZ_11_10       11.0
    MARK0001  'MARKER'                 'INTEND'
    u_1             MTZ_1_2         1.0
    u_1             MTZ_1_3         1.0
    u_1             MTZ_1_4         1.0
    u_1             MTZ_1_5         1.0
    u_1             MTZ_1_6         1.0
    u_1             MTZ_1_7         1.0
    u_1             MTZ_1_8         1.0
    u_1             MTZ_1_9         1.0
    u_1             MTZ_1_10        1.0
    u_1             MTZ_1_11        1.0
    u_1             MTZ_2_1         -1.0
    u_1             MTZ_3_1         -1.0
    u_1             MTZ_4_1         -1.0
    u_1             MTZ_5_1         -1.0
    u_1             MTZ_6_1         -1.0
    u_1             MTZ_7_1         -1.0
    u_1             MTZ_8_1         -1.0
    u_1             MTZ_9_1         -1.0
    u_1             MTZ_10_1        -1.0
    u_1             MTZ_11_1        -1.0
    u_2             MTZ_1_2         -1.0
    u_2             MTZ_2_1         1.0
    u_2             MTZ_2_3         1.0
    u_2             MTZ_2_4         1.0
    u_2             MTZ_2_5         1.0
    u_2             MTZ_2_6         1.0
    u_2             MTZ_2_7         1.0
    u_2             MTZ_2_8         1.0
    u_2             MTZ_2_9         1.0
    u_2             MTZ_2_10        1.0
    u_2             MTZ_2_11        1.0
    u_2             MTZ_3_2         -1.0
    u_2             MTZ_4_2         -1.0
    u_2             MTZ_5_2         -1.0
    u_2             MTZ_6_2         -1.0
    u_2             MTZ_7_2         -1.0
    u_2             MTZ_8_2         -1.0
    u_2             MTZ_9_2         -1.0
    u_2             MTZ_10_2        -1.0
    u_2             MTZ_11_2        -1.0
    u_3             MTZ_1_3         -1.0
    u_3             MTZ_2_3         -1.0
    u_3             MTZ_3_1         1.0
    u_3             MTZ_3_2         1.0
    u_3             MTZ_3_4         1.0
    u_3             MTZ_3_5         1.0
    u_3             MTZ_3_6         1.0
    u_3             MTZ_3_7         1.0
    u_3             MTZ_3_8         1.0
    u_3             MTZ_3_9         1.0
    u_3             MTZ_3_10        1.0
    u_3             MTZ_3_11        1.0
    u_3             MTZ_4_3         -1.0
    u_3             MTZ_5_3         -1.0
    u_3             MTZ_6_3         -1.0
    u_3             MTZ_7_3         -1.0
    u_3             MTZ_8_3         -1.0
    u_3             MTZ_9_3         -1.0
    u_3             MTZ_10_3        -1.0
    u_3             MTZ_11_3        -1.0
    u_4             MTZ_1_4         -1.0
    u_4             MTZ_2_4         -1.0
    u_4             MTZ_3_4         -1.0
    u_4             MTZ_4_1         1.0
    u_4             MTZ_4_2         1.0
    u_4             MTZ_4_3         1.0
    u_4             MTZ_4_5         1.0
    u_4             MTZ_4_6         1.0
    u_4             MTZ_4_7         1.0
    u_4             MTZ_4_8         1.0
    u_4             MTZ_4_9         1.0
    u_4             MTZ_4_10        1.0
    u_4             MTZ_4_11        1.0
    u_4             MTZ_5_4         -1.0
    u_4             MTZ_6_4         -1.0
    u_4             MTZ_7_4         -1.0
    u_4             MTZ_8_4         -1.0
    u_4             MTZ_9_4         -1.0
    u_4             MTZ_10_4        -1.0
    u_4             MTZ_11_4        -1.0
    u_5             MTZ_1_5         -1.0
    u_5             MTZ_2_5         -1.0
    u_5             MTZ_3_5         -1.0
    u_5             MTZ_4_5         -1.0
    u_5             MTZ_5_1         1.0
    u_5             MTZ_5_2         1.0
    u_5             MTZ_5_3         1.0
    u_5             MTZ_5_4         1.0
    u_5             MTZ_5_6         1.0
    u_5             MTZ_5_7         1.0
    u_5             MTZ_5_8         1.0
    u_5             MTZ_5_9         1.0
    u_5             MTZ_5_10        1.0
    u_5             MTZ_5_11        1.0
    u_5             MTZ_6_5         -1.0
    u_5             MTZ_7_5         -1.0
    u_5             MTZ_8_5         -1.0
    u_5             MTZ_9_5         -1.0
    u_5             MTZ_10_5        -1.0
    u_5             MTZ_11_5        -1.0
    u_6             MTZ_1_6         -1.0
    u_6             MTZ_2_6         -1.0
    u_6             MTZ_3_6         -1.0
    u_6             MTZ_4_6         -1.0
    u_6             MTZ_5_6         -1.0
    u_6             MTZ_6_1         1.0
    u_6             MTZ_6_2         1.0
    u_6             MTZ_6_3         1.0
    u_6             MTZ_6_4         1.0
    u_6             MTZ_6_5         1.0
    u_6             MTZ_6_7         1.0
    u_6             MTZ_6_8         1.0
    u_6             MTZ_6_9         1.0
    u_6             MTZ_6_10        1.0
    u_6             MTZ_6_11        1.0
    u_6             MTZ_7_6         -1.0
    u_6             MTZ_8_6         -1.0
    u_6             MTZ_9_6         -1.0
    u_6             MTZ_10_6        -1.0
    u_6             MTZ_11_6        -1.0
    u_7             MTZ_1_7         -1.0
    u_7             MTZ_2_7         -1.0
    u_7             MTZ_3_7         -1.0
    u_7             MTZ_4_7         -1.0
    u_7             MTZ_5_7         -1.0
    u_7             MTZ_6_7         -1.0
    u_7             MTZ_7_1         1.0
    u_7             MTZ_7_2         1.0
    u_7             MTZ_7_3         1.0
    u_7             MTZ_7_4         1.0
    u_7             MTZ_7_5         1.0
    u_7             MTZ_7_6         1.0
    u_7             MTZ_7_8         1.0
    u_7             MTZ_7_9         1.0
    u_7             MTZ_7_10        1.0
    u_7             MTZ_7_11        1.0
    u_7             MTZ_8_7         -1.0
    u_7             MTZ_9_7         -1.0
    u_7             MTZ_10_7        -1.0
    u_7             MTZ_11_7        -1.0
    u_8             MTZ_1_8         -1.0
    u_8             MTZ_2_8         -1.0
    u_8             MTZ_3_8         -1.0
    u_8             MTZ_4_8         -1.0
    u_8             MTZ_5_8         -1.0
    u_8             MTZ_6_8         -1.0
    u_8             MTZ_7_8         -1.0
    u_8             MTZ_8_1         1.0
    u_8             MTZ_8_2         1.0
    u_8             MTZ_8_3         1.0
    u_8             MTZ_8_4         1.0
    u_8             MTZ_8_5         1.0
    u_8             MTZ_8_6         1.0
    u_8             MTZ_8_7         1.0
    u_8             MTZ_8_9         1.0
    u_8             MTZ_8_10        1.0
    u_8             MTZ_8_11        1.0
    u_8             MTZ_9_8         -1.0
    u_8             MTZ_10_8        -1.0
    u_8             MTZ_11_8        -1.0
    u_9             MTZ_1_9         -1.0
    u_9             MTZ_2_9         -1.0
    u_9             MTZ_3_9         -1.0
    u_9             MTZ_4_9         -1.0
    u_9             MTZ_5_9         -1.0
    u_9             MTZ_6_9         -1.0
    u_9             MTZ_7_9         -1.0
    u_9             MTZ_8_9         -1.0
    u_9             MTZ_9_1         1.0
    u_9             MTZ_9_2         1.0
    u_9             MTZ_9_3         1.0
    u_9             MTZ_9_4         1.0
    u_9             MTZ_9_5         1.0
    u_9             MTZ_9_6         1.0
    u_9             MTZ_9_7         1.0
    u_9             MTZ_9_8         1.0
    u_9             MTZ_9_10        1.0
    u_9             MTZ_9_11        1.0
    u_9             MTZ_10_9        -1.0
    u_9             MTZ_11_9        -1.0
    u_10            MTZ_1_10        -1.0
    u_10            MTZ_2_10        -1.0
    u_10            MTZ_3_10        -1.0
    u_10            MTZ_4_10        -1.0
    u_10            MTZ_5_10        -1.0
    u_10            MTZ_6_10        -1.0
    u_10            MTZ_7_10        -1.0
    u_10            MTZ_8_10        -1.0
    u_10            MTZ_9_10        -1.0
    u_10            MTZ_10_1        1.0
    u_10            MTZ_10_2        1.0
    u_10            MTZ_10_3        1.0
    u_10            MTZ_10_4        1.0
    u_10            MTZ_10_5        1.0
    u_10            MTZ_10_6        1.0
    u_10            MTZ_10_7        1.0
    u_10            MTZ_10_8        1.0
    u_10            MTZ_10_9        1.0
    u_10            MTZ_10_11       1.0
    u_10            MTZ_11_10       -1.0
    u_11            MTZ_1_11        -1.0
    u_11            MTZ_2_11        -1.0
    u_11            MTZ_3_11        -1.0
    u_11            MTZ_4_11        -1.0
    u_11            MTZ_5_11        -1.0
    u_11            MTZ_6_11        -1.0
    u_11            MTZ_7_11        -1.0
    u_11            MTZ_8_11        -1.0
    u_11            MTZ_9_11        -1.0
    u_11            MTZ_10_11       -1.0
    u_11            MTZ_11_1        1.0
    u_11            MTZ_11_2        1.0
    u_11            MTZ_11_3        1.0
    u_11            MTZ_11_4        1.0
    u_11            MTZ_11_5        1.0
    u_11            MTZ_11_6        1.0
    u_11            MTZ_11_7        1.0
    u_11            MTZ_11_8        1.0
    u_11            MTZ_11_9        1.0
    u_11            MTZ_11_10       1.0
RHS
    RHS           OUT_0           1.0
    RHS           OUT_1           1.0
    RHS           OUT_2           1.0
    RHS           OUT_3           1.0
    RHS           OUT_4           1.0
    RHS           OUT_5           1.0
    RHS           OUT_6           1.0
    RHS           OUT_7           1.0
    RHS           OUT_8           1.0
    RHS           OUT_9           1.0
    RHS           OUT_10          1.0
    RHS           OUT_11          1.0
    RHS           IN_0            1.0
    RHS           IN_1            1.0
    RHS           IN_2            1.0
    RHS           IN_3            1.0
    RHS           IN_4            1.0
    RHS           IN_5            1.0
    RHS           IN_6            1.0
    RHS           IN_7            1.0
    RHS           IN_8            1.0
    RHS           IN_9            1.0
    RHS           IN_10           1.0
    RHS           IN_11           1.0
    RHS           MTZ_1_2         10.0
    RHS           MTZ_1_3         10.0
    RHS           MTZ_1_4         10.0
    RHS           MTZ_1_5         10.0
    RHS           MTZ_1_6         10.0
    RHS           MTZ_1_7         10.0
    RHS           MTZ_1_8         10.0
    RHS           MTZ_1_9         10.0
    RHS           MTZ_1_10        10.0
    RHS           MTZ_1_11        10.0
    RHS           MTZ_2_1         10.0
    RHS           MTZ_2_3         10.0
    RHS           MTZ_2_4         10.0
    RHS           MTZ_2_5         10.0
    RHS           MTZ_2_6         10.0
    RHS           MTZ_2_7         10.0
    RHS           MTZ_2_8         10.0
    RHS           MTZ_2_9         10.0
    RHS           MTZ_2_10        10.0
    RHS           MTZ_2_11        10.0
    RHS           MTZ_3_1         10.0
    RHS           MTZ_3_2         10.0
    RHS           MTZ_3_4         10.0
    RHS           MTZ_3_5         10.0
    RHS           MTZ_3_6         10.0
    RHS           MTZ_3_7         10.0
    RHS           MTZ_3_8         10.0
    RHS           MTZ_3_9         10.0
    RHS           MTZ_3_10        10.0
    RHS           MTZ_3_11        10.0
    RHS           MTZ_4_1         10.0
    RHS           MTZ_4_2         10.0
    RHS           MTZ_4_3         10.0
    RHS           MTZ_4_5         10.0
    RHS           MTZ_4_6         10.0
    RHS           MTZ_4_7         10.0
    RHS           MTZ_4_8         10.0
    RHS           MTZ_4_9         10.0
    RHS           MTZ_4_10        10.0
    RHS           MTZ_4_11        10.0
    RHS           MTZ_5_1         10.0
    RHS           MTZ_5_2         10.0
    RHS           MTZ_5_3         10.0
    RHS           MTZ_5_4         10.0
    RHS           MTZ_5_6         10.0
    RHS           MTZ_5_7         10.0
    RHS           MTZ_5_8         10.0
    RHS           MTZ_5_9         10.0
    RHS           MTZ_5_10        10.0
    RHS           MTZ_5_11        10.0
    RHS           MTZ_6_1         10.0
    RHS           MTZ_6_2         10.0
    RHS           MTZ_6_3         10.0
    RHS           MTZ_6_4         10.0
    RHS           MTZ_6_5         10.0
    RHS           MTZ_6_7         10.0
    RHS           MTZ_6_8         10.0
    RHS           MTZ_6_9         10.0
    RHS           MTZ_6_10        10.0
    RHS           MTZ_6_11        10.0
    RHS           MTZ_7_1         10.0
    RHS           MTZ_7_2         10.0
    RHS           MTZ_7_3         10.0
    RHS           MTZ_7_4         10.0
    RHS           MTZ_7_5         10.0
    RHS           MTZ_7_6         10.0
    RHS           MTZ_7_8         10.0
    RHS           MTZ_7_9         10.0
    RHS           MTZ_7_10        10.0
    RHS           MTZ_7_11        10.0
    RHS           MTZ_8_1         10.0
    RHS           MTZ_8_2         10.0
    RHS           MTZ_8_3         10.0
    RHS           MTZ_8_4         10.0
    RHS           MTZ_8_5         10.0
    RHS           MTZ_8_6         10.0
    RHS           MTZ_8_7         10.0
    RHS           MTZ_8_9         10.0
    RHS           MTZ_8_10        10.0
    RHS           MTZ_8_11        10.0
    RHS           MTZ_9_1         10.0
    RHS           MTZ_9_2         10.0
    RHS           MTZ_9_3         10.0
    RHS           MTZ_9_4         10.0
    RHS           MTZ_9_5         10.0
    RHS           MTZ_9_6         10.0
    RHS           MTZ_9_7         10.0
    RHS           MTZ_9_8         10.0
    RHS           MTZ_9_10        10.0
    RHS           MTZ_9_11        10.0
    RHS           MTZ_10_1        10.0
    RHS           MTZ_10_2        10.0
    RHS           MTZ_10_3        10.0
    RHS           MTZ_10_4        10.0
    RHS           MTZ_10_5        10.0
    RHS           MTZ_10_6        10.0
    RHS           MTZ_10_7        10.0
    RHS           MTZ_10_8        10.0
    RHS           MTZ_10_9        10.0
    RHS           MTZ_10_11       10.0
    RHS           MTZ_11_1        10.0
    RHS           MTZ_11_2        10.0
    RHS           MTZ_11_3        10.0
    RHS           MTZ_11_4        10.0
    RHS           MTZ_11_5        10.0
    RHS           MTZ_11_6        10.0
    RHS           MTZ_11_7        10.0
    RHS           MTZ_11_8        10.0
    RHS           MTZ_11_9        10.0
    RHS           MTZ_11_10       10.0
BOUNDS
 BV BOUND         x_0_1
 BV BOUND         x_0_2
 BV BOUND         x_0_3
 BV BOUND         x_0_4
 BV BOUND         x_0_5
 BV BOUND         x_0_6
 BV BOUND         x_0_7
 BV BOUND         x_0_8
 BV BOUND         x_0_9
 BV BOUND         x_0_10
 BV BOUND         x_0_11
 BV BOUND         x_1_0
 BV BOUND         x_1_2
 BV BOUND         x_1_3
 BV BOUND         x_1_4
 BV BOUND         x_1_5
 BV BOUND         x_1_6
 BV BOUND         x_1_7
 BV BOUND         x_1_8
 BV BOUND         x_1_9
 BV BOUND         x_1_10
 BV BOUND         x_1_11
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_3
 BV BOUND         x_2_4
 BV BOUND         x_2_5
 BV BOUND         x_2_6
 BV BOUND         x_2_7
 BV BOUND         x_2_8
 BV BOUND         x_2_9
 BV BOUND         x_2_10
 BV BOUND         x_2_11
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_4
 BV BOUND         x_3_5
 BV BOUND         x_3_6
 BV BOUND         x_3_7
 BV BOUND         x_3_8
 BV BOUND         x_3_9
 BV BOUND         x_3_10
 BV BOUND         x_3_11
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_5
 BV BOUND         x_4_6
 BV BOUND         x_4_7
 BV BOUND         x_4_8
 BV BOUND         x_4_9
 BV BOUND         x_4_10
 BV BOUND         x_4_11
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_6
 BV BOUND         x_5_7
 BV BOUND         x_5_8
 BV BOUND         x_5_9
 BV BOUND         x_5_10
 BV BOUND         x_5_11
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_7
 BV BOUND         x_6_8
 BV BOUND         x_6_9
 BV BOUND         x_6_10
 BV BOUND         x_6_11
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 BV BOUND         x_7_8
 BV BOUND         x_7_9
 BV BOUND         x_7_10
 BV BOUND         x_7_11
 BV BOUND         x_8_0
 BV BOUND         x_8_1
 BV BOUND         x_8_2
 BV BOUND         x_8_3
 BV BOUND         x_8_4
 BV BOUND         x_8_5
 BV BOUND         x_8_6
 BV BOUND         x_8_7
 BV BOUND         x_8_9
 BV BOUND         x_8_10
 BV BOUND         x_8_11
 BV BOUND         x_9_0
 BV BOUND         x_9_1
 BV BOUND         x_9_2
 BV BOUND         x_9_3
 BV BOUND         x_9_4
 BV BOUND         x_9_5
 BV BOUND         x_9_6
 BV BOUND         x_9_7
 BV BOUND         x_9_8
 BV BOUND         x_9_10
 BV BOUND         x_9_11
 BV BOUND         x_10_0
 BV BOUND         x_10_1
 BV BOUND         x_10_2
 BV BOUND         x_10_3
 BV BOUND         x_10_4
 BV BOUND         x_10_5
 BV BOUND         x_10_6
 BV BOUND         x_10_7
 BV BOUND         x_10_8
 BV BOUND         x_10_9
 BV BOUND         x_10_11
 BV BOUND         x_11_0
 BV BOUND         x_11_1
 BV BOUND         x_11_2
 BV BOUND         x_11_3
 BV BOUND         x_11_4
 BV BOUND         x_11_5
 BV BOUND         x_11_6
 BV BOUND         x_11_7
 BV BOUND         x_11_8
 BV BOUND         x_11_9
 BV BOUND         x_11_10
 LO BOUND         u_1       1.0
 UP BOUND         u_1       11.0
 LO BOUND         u_2       1.0
 UP BOUND         u_2       11.0
 LO BOUND         u_3       1.0
 UP BOUND         u_3       11.0
 LO BOUND         u_4       1.0
 UP BOUND         u_4       11.0
 LO BOUND         u_5       1.0
 UP BOUND         u_5       11.0
 LO BOUND         u_6       1.0
 UP BOUND         u_6       11.0
 LO BOUND         u_7       1.0
 UP BOUND         u_7       11.0
 LO BOUND         u_8       1.0
 UP BOUND         u_8       11.0
 LO BOUND         u_9       1.0
 UP BOUND         u_9       11.0
 LO BOUND         u_10       1.0
 UP BOUND         u_10       11.0
 LO BOUND         u_11       1.0
 UP BOUND         u_11       11.0
ENDATA
