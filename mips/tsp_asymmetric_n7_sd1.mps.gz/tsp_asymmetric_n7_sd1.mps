NAME          tsp_asymmetric_n7_sd1
ROWS
 N  OBJ
 E  OUT_0
 E  OUT_1
 E  OUT_2
 E  OUT_3
 E  OUT_4
 E  OUT_5
 E  OUT_6
 E  IN_0
 E  IN_1
 E  IN_2
 E  IN_3
 E  IN_4
 E  IN_5
 E  IN_6
 L  MTZ_1_2
 L  MTZ_1_3
 L  MTZ_1_4
 L  MTZ_1_5
 L  MTZ_1_6
 L  MTZ_2_1
 L  MTZ_2_3
 L  MTZ_2_4
 L  MTZ_2_5
 L  MTZ_2_6
 L  MTZ_3_1
 L  MTZ_3_2
 L  MTZ_3_4
 L  MTZ_3_5
 L  MTZ_3_6
 L  MTZ_4_1
 L  MTZ_4_2
 L  MTZ_4_3
 L  MTZ_4_5
 L  MTZ_4_6
 L  MTZ_5_1
 L  MTZ_5_2
 L  MTZ_5_3
 L  MTZ_5_4
 L  MTZ_5_6
 L  MTZ_6_1
 L  MTZ_6_2
 L  MTZ_6_3
 L  MTZ_6_4
 L  MTZ_6_5
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_1           OBJ           674
    x_0_1           OUT_0           1.0
    x_0_1           IN_1            1.0
    x_0_2           OBJ           649
    x_0_2           OUT_0           1.0
    x_0_2           IN_2            1.0
    x_0_3           OBJ           603
    x_0_3           OUT_0           1.0
    x_0_3           IN_3            1.0
    x_0_4           OBJ           699
    x_0_4           OUT_0           1.0
    x_0_4           IN_4            1.0
    x_0_5           OBJ           813
    x_0_5           OUT_0           1.0
    x_0_5           IN_5            1.0
    x_0_6           OBJ           1021
    x_0_6           OUT_0           1.0
    x_0_6           IN_6            1.0
    x_1_0           OBJ           943
    x_1_0           OUT_1           1.0
    x_1_0           IN_0            1.0
    x_1_2           OBJ           388
    x_1_2           OUT_1           1.0
    x_1_2           IN_2            1.0
    x_1_2           MTZ_1_2         6.0
    x_1_3           OBJ           412
    x_1_3           OUT_1           1.0
    x_1_3           IN_3            1.0
    x_1_3           MTZ_1_3         6.0
    x_1_4           OBJ           507
    x_1_4           OUT_1           1.0
    x_1_4           IN_4            1.0
    x_1_4           MTZ_1_4         6.0
    x_1_5           OBJ           231
    x_1_5           OUT_1           1.0
    x_1_5           IN_5            1.0
    x_1_5           MTZ_1_5         6.0
    x_1_6           OBJ           243
    x_1_6           OUT_1           1.0
    x_1_6           IN_6            1.0
    x_1_6           MTZ_1_6         6.0
    x_2_0           OBJ           622
    x_2_0           OUT_2           1.0
    x_2_0           IN_0            1.0
    x_2_1           OBJ           232
    x_2_1           OUT_2           1.0
    x_2_1           IN_1            1.0
    x_2_1           MTZ_2_1         6.0
    x_2_3           OBJ           361
    x_2_3           OUT_2           1.0
    x_2_3           IN_3            1.0
    x_2_3           MTZ_2_3         6.0
    x_2_4           OBJ           659
    x_2_4           OUT_2           1.0
    x_2_4           IN_4            1.0
    x_2_4           MTZ_2_4         6.0
    x_2_5           OBJ           286
    x_2_5           OUT_2           1.0
    x_2_5           IN_5            1.0
    x_2_5           MTZ_2_5         6.0
    x_2_6           OBJ           660
    x_2_6           OUT_2           1.0
    x_2_6           IN_6            1.0
    x_2_6           MTZ_2_6         6.0
    x_3_0           OBJ           646
    x_3_0           OUT_3           1.0
    x_3_0           IN_0            1.0
    x_3_1           OBJ           392
    x_3_1           OUT_3           1.0
    x_3_1           IN_1            1.0
    x_3_1           MTZ_3_1         6.0
    x_3_2           OBJ           267
    x_3_2           OUT_3           1.0
    x_3_2           IN_2            1.0
    x_3_2           MTZ_3_2         6.0
    x_3_4           OBJ           966
    x_3_4           OUT_3           1.0
    x_3_4           IN_4            1.0
    x_3_4           MTZ_3_4         6.0
    x_3_5           OBJ           507
    x_3_5           OUT_3           1.0
    x_3_5           IN_5            1.0
    x_3_5           MTZ_3_5         6.0
    x_3_6           OBJ           737
    x_3_6           OUT_3           1.0
    x_3_6           IN_6            1.0
    x_3_6           MTZ_3_6         6.0
    x_4_0           OBJ           681
    x_4_0           OUT_4           1.0
    x_4_0           IN_0            1.0
    x_4_1           OBJ           674
    x_4_1           OUT_4           1.0
    x_4_1           IN_1            1.0
    x_4_1           MTZ_4_1         6.0
    x_4_2           OBJ           418
    x_4_2           OUT_4           1.0
    x_4_2           IN_2            1.0
    x_4_2           MTZ_4_2         6.0
    x_4_3           OBJ           786
    x_4_3           OUT_4           1.0
    x_4_3           IN_3            1.0
    x_4_3           MTZ_4_3         6.0
    x_4_5           OBJ           814
    x_4_5           OUT_4           1.0
    x_4_5           IN_5            1.0
    x_4_5           MTZ_4_5         6.0
    x_4_6           OBJ           667
    x_4_6           OUT_4           1.0
    x_4_6           IN_6            1.0
    x_4_6           MTZ_4_6         6.0
    x_5_0           OBJ           684
    x_5_0           OUT_5           1.0
    x_5_0           IN_0            1.0
    x_5_1           OBJ           161
    x_5_1           OUT_5           1.0
    x_5_1           IN_1            1.0
    x_5_1           MTZ_5_1         6.0
    x_5_2           OBJ           283
    x_5_2           OUT_5           1.0
    x_5_2           IN_2            1.0
    x_5_2           MTZ_5_2         6.0
    x_5_3           OBJ           391
    x_5_3           OUT_5           1.0
    x_5_3           IN_3            1.0
    x_5_3           MTZ_5_3         6.0
    x_5_4           OBJ           738
    x_5_4           OUT_5           1.0
    x_5_4           IN_4            1.0
    x_5_4           MTZ_5_4         6.0
    x_5_6           OBJ           312
    x_5_6           OUT_5           1.0
    x_5_6           IN_6            1.0
    x_5_6           MTZ_5_6         6.0
    x_6_0           OBJ           1266
    x_6_0           OUT_6           1.0
    x_6_0           IN_0            1.0
    x_6_1           OBJ           262
    x_6_1           OUT_6           1.0
    x_6_1           IN_1            1.0
    x_6_1           MTZ_6_1         6.0
    x_6_2           OBJ           565
    x_6_2           OUT_6           1.0
    x_6_2           IN_2            1.0
    x_6_2           MTZ_6_2         6.0
    x_6_3           OBJ           644
    x_6_3           OUT_6           1.0
    x_6_3           IN_3            1.0
    x_6_3           MTZ_6_3         6.0
    x_6_4           OBJ           867
    x_6_4           OUT_6           1.0
    x_6_4           IN_4            1.0
    x_6_4           MTZ_6_4         6.0
    x_6_5           OBJ           531
    x_6_5           OUT_6           1.0
    x_6_5           IN_5            1.0
    x_6_5           MTZ_6_5         6.0
    MARK0001  'MARKER'                 'INTEND'
    u_1             MTZ_1_2         1.0
    u_1             MTZ_1_3         1.0
    u_1             MTZ_1_4         1.0
    u_1             MTZ_1_5         1.0
    u_1             MTZ_1_6         1.0
    u_1             MTZ_2_1         -1.0
    u_1             MTZ_3_1         -1.0
    u_1             MTZ_4_1         -1.0
    u_1             MTZ_5_1         -1.0
    u_1             MTZ_6_1         -1.0
    u_2             MTZ_1_2         -1.0
    u_2             MTZ_2_1         1.0
    u_2             MTZ_2_3         1.0
    u_2             MTZ_2_4         1.0
    u_2             MTZ_2_5         1.0
    u_2             MTZ_2_6         1.0
    u_2             MTZ_3_2         -1.0
    u_2             MTZ_4_2         -1.0
    u_2             MTZ_5_2         -1.0
    u_2             MTZ_6_2         -1.0
    u_3             MTZ_1_3         -1.0
    u_3             MTZ_2_3         -1.0
    u_3             MTZ_3_1         1.0
    u_3             MTZ_3_2         1.0
    u_3             MTZ_3_4         1.0
    u_3             MTZ_3_5         1.0
    u_3             MTZ_3_6         1.0
    u_3             MTZ_4_3         -1.0
    u_3             MTZ_5_3         -1.0
    u_3             MTZ_6_3         -1.0
    u_4             MTZ_1_4         -1.0
    u_4             MTZ_2_4         -1.0
    u_4             MTZ_3_4         -1.0
    u_4             MTZ_4_1         1.0
    u_4             MTZ_4_2         1.0
    u_4             MTZ_4_3         1.0
    u_4             MTZ_4_5         1.0
    u_4             MTZ_4_6         1.0
    u_4             MTZ_5_4         -1.0
    u_4             MTZ_6_4         -1.0
    u_5             MTZ_1_5         -1.0
    u_5             MTZ_2_5         -1.0
    u_5             MTZ_3_5         -1.0
    u_5             MTZ_4_5         -1.0
    u_5             MTZ_5_1         1.0
    u_5             MTZ_5_2         1.0
    u_5             MTZ_5_3         1.0
    u_5             MTZ_5_4         1.0
    u_5             MTZ_5_6         1.0
    u_5             MTZ_6_5         -1.0
    u_6             MTZ_1_6         -1.0
    u_6             MTZ_2_6         -1.0
    u_6             MTZ_3_6         -1.0
    u_6             MTZ_4_6         -1.0
    u_6             MTZ_5_6         -1.0
    u_6             MTZ_6_1         1.0
    u_6             MTZ_6_2         1.0
    u_6             MTZ_6_3         1.0
    u_6             MTZ_6_4         1.0
    u_6             MTZ_6_5         1.0
RHS
    RHS           OUT_0           1.0
    RHS           OUT_1           1.0
    RHS           OUT_2           1.0
    RHS           OUT_3           1.0
    RHS           OUT_4           1.0
    RHS           OUT_5           1.0
    RHS           OUT_6           1.0
    RHS           IN_0            1.0
    RHS           IN_1            1.0
    RHS           IN_2            1.0
    RHS           IN_3            1.0
    RHS           IN_4            1.0
    RHS           IN_5            1.0
    RHS           IN_6            1.0
    RHS           MTZ_1_2         5.0
    RHS           MTZ_1_3         5.0
    RHS           MTZ_1_4         5.0
    RHS           MTZ_1_5         5.0
    RHS           MTZ_1_6         5.0
    RHS           MTZ_2_1         5.0
    RHS           MTZ_2_3         5.0
    RHS           MTZ_2_4         5.0
    RHS           MTZ_2_5         5.0
    RHS           MTZ_2_6         5.0
    RHS           MTZ_3_1         5.0
    RHS           MTZ_3_2         5.0
    RHS           MTZ_3_4         5.0
    RHS           MTZ_3_5         5.0
    RHS           MTZ_3_6         5.0
    RHS           MTZ_4_1         5.0
    RHS           MTZ_4_2         5.0
    RHS           MTZ_4_3         5.0
    RHS           MTZ_4_5         5.0
    RHS           MTZ_4_6         5.0
    RHS           MTZ_5_1         5.0
    RHS           MTZ_5_2         5.0
    RHS           MTZ_5_3         5.0
    RHS           MTZ_5_4         5.0
    RHS           MTZ_5_6         5.0
    RHS           MTZ_6_1         5.0
    RHS           MTZ_6_2         5.0
    RHS           MTZ_6_3         5.0
    RHS           MTZ_6_4         5.0
    RHS           MTZ_6_5         5.0
BOUNDS
 BV BOUND         x_0_1
 BV BOUND         x_0_2
 BV BOUND         x_0_3
 BV BOUND         x_0_4
 BV BOUND         x_0_5
 BV BOUND         x_0_6
 BV BOUND         x_1_0
 BV BOUND         x_1_2
 BV BOUND         x_1_3
 BV BOUND         x_1_4
 BV BOUND         x_1_5
 BV BOUND         x_1_6
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_3
 BV BOUND         x_2_4
 BV BOUND         x_2_5
 BV BOUND         x_2_6
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_4
 BV BOUND         x_3_5
 BV BOUND         x_3_6
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_5
 BV BOUND         x_4_6
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_6
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 LO BOUND         u_1       1.0
 UP BOUND         u_1       6.0
 LO BOUND         u_2       1.0
 UP BOUND         u_2       6.0
 LO BOUND         u_3       1.0
 UP BOUND         u_3       6.0
 LO BOUND         u_4       1.0
 UP BOUND         u_4       6.0
 LO BOUND         u_5       1.0
 UP BOUND         u_5       6.0
 LO BOUND         u_6       1.0
 UP BOUND         u_6       6.0
ENDATA
