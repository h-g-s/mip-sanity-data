NAME          hcnd_small_sparse
ROWS
 N  OBJ
 L  CAP_0_2
 L  CAP_0_4
 L  CAP_0_5
 L  CAP_3_4
 L  CAP_0_1
 E  SUP_0
 E  DEM_0
 E  CONS_0_0_1
 E  CONS_0_4_2
 E  CONS_0_5_2
 E  CONS_0_1_1
 E  CONS_0_0_2
 E  SUP_1
 E  DEM_1
 E  CONS_1_0_1
 E  CONS_1_4_2
 E  CONS_1_5_1
 E  CONS_1_0_2
 E  CONS_1_1_2
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_2           OBJ           520
    y_0_2           CAP_0_2         -7.0
    y_0_4           OBJ           730
    y_0_4           CAP_0_4         -4.0
    y_0_5           OBJ           835
    y_0_5           CAP_0_5         -10.0
    y_3_4           OBJ           1043
    y_3_4           CAP_3_4         -11.0
    y_0_1           OBJ           821
    y_0_1           CAP_0_1         -12.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_1_0_0       CAP_0_1         1.0
    f_0_1_0_0       SUP_0           1.0
    f_0_1_0_0       CONS_0_0_1      -1.0
    f_0_0_2_1       CAP_0_2         1.0
    f_0_0_2_1       CONS_0_0_1      1.0
    f_0_0_2_1       DEM_0           1.0
    f_0_0_4_1       CAP_0_4         1.0
    f_0_0_4_1       CONS_0_0_1      1.0
    f_0_0_4_1       CONS_0_4_2      -1.0
    f_0_0_5_1       CAP_0_5         1.0
    f_0_0_5_1       CONS_0_0_1      1.0
    f_0_0_5_1       CONS_0_5_2      -1.0
    f_0_1_0_1       CAP_0_1         1.0
    f_0_1_0_1       CONS_0_1_1      1.0
    f_0_1_0_1       CONS_0_0_2      -1.0
    f_0_0_2_2       CAP_0_2         1.0
    f_0_0_2_2       CONS_0_0_2      1.0
    f_0_0_2_2       DEM_0           1.0
    f_1_5_0_0       CAP_0_5         1.0
    f_1_5_0_0       SUP_1           1.0
    f_1_5_0_0       CONS_1_0_1      -1.0
    f_1_0_2_1       CAP_0_2         1.0
    f_1_0_2_1       CONS_1_0_1      1.0
    f_1_0_2_1       DEM_1           1.0
    f_1_0_4_1       CAP_0_4         1.0
    f_1_0_4_1       CONS_1_0_1      1.0
    f_1_0_4_1       CONS_1_4_2      -1.0
    f_1_5_0_1       CAP_0_5         1.0
    f_1_5_0_1       CONS_1_5_1      1.0
    f_1_5_0_1       CONS_1_0_2      -1.0
    f_1_0_1_1       CAP_0_1         1.0
    f_1_0_1_1       CONS_1_0_1      1.0
    f_1_0_1_1       CONS_1_1_2      -1.0
    f_1_0_2_2       CAP_0_2         1.0
    f_1_0_2_2       CONS_1_0_2      1.0
    f_1_0_2_2       DEM_1           1.0
RHS
    RHS           SUP_0           1.0
    RHS           DEM_0           1.0
    RHS           SUP_1           4.0
    RHS           DEM_1           4.0
BOUNDS
 BV BOUND         y_0_2
 BV BOUND         y_0_4
 BV BOUND         y_0_5
 BV BOUND         y_3_4
 BV BOUND         y_0_1
 UP BOUND         f_0_1_0_0       1.0
 UP BOUND         f_0_0_2_1       1.0
 UP BOUND         f_0_0_4_1       1.0
 UP BOUND         f_0_0_5_1       1.0
 UP BOUND         f_0_1_0_1       1.0
 UP BOUND         f_0_0_2_2       1.0
 UP BOUND         f_1_5_0_0       4.0
 UP BOUND         f_1_0_2_1       4.0
 UP BOUND         f_1_0_4_1       4.0
 UP BOUND         f_1_5_0_1       4.0
 UP BOUND         f_1_0_1_1       4.0
 UP BOUND         f_1_0_2_2       4.0
ENDATA
