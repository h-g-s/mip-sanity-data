NAME          hcnd_tiny_hop1
ROWS
 N  OBJ
 L  CAP_0_1
 L  CAP_1_2
 L  CAP_2_3
 L  CAP_0_3
 L  CAP_0_2
 L  CAP_1_3
 E  SUP_0
 E  DEM_0
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_1           OBJ           5
    y_0_1           CAP_0_1         -10.0
    y_1_2           OBJ           5
    y_1_2           CAP_1_2         -10.0
    y_2_3           OBJ           5
    y_2_3           CAP_2_3         -10.0
    y_0_3           OBJ           100
    y_0_3           CAP_0_3         -10.0
    y_0_2           OBJ           8
    y_0_2           CAP_0_2         -10.0
    y_1_3           OBJ           8
    y_1_3           CAP_1_3         -10.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_0_3_0       CAP_0_3         1.0
    f_0_0_3_0       SUP_0           1.0
    f_0_0_3_0       DEM_0           1.0
RHS
    RHS           SUP_0           5.0
    RHS           DEM_0           5.0
BOUNDS
 BV BOUND         y_0_1
 BV BOUND         y_1_2
 BV BOUND         y_2_3
 BV BOUND         y_0_3
 BV BOUND         y_0_2
 BV BOUND         y_1_3
 UP BOUND         f_0_0_3_0       5.0
ENDATA
