NAME          MIS
ROWS
 N  OBJ
 L  EDGE_36_71
 L  EDGE_29_32
 L  EDGE_8_9
 L  EDGE_29_68
 L  EDGE_41_42
 L  EDGE_73_74
 L  EDGE_25_34
 L  EDGE_10_54
 L  EDGE_14_24
 L  EDGE_74_75
 L  EDGE_32_78
 L  EDGE_35_83
 L  EDGE_15_25
 L  EDGE_47_57
 L  EDGE_70_77
 L  EDGE_36_84
 L  EDGE_9_67
 L  EDGE_28_80
 L  EDGE_29_45
 L  EDGE_48_58
 L  EDGE_2_27
 L  EDGE_54_74
 L  EDGE_73_87
 L  EDGE_51_68
 L  EDGE_43_64
 L  EDGE_1_67
 L  EDGE_66_84
 L  EDGE_13_78
 L  EDGE_24_87
 L  EDGE_16_83
 L  EDGE_17_48
 L  EDGE_28_57
 L  EDGE_5_73
 L  EDGE_6_38
 L  EDGE_58_85
 L  EDGE_42_77
 L  EDGE_21_54
 L  EDGE_31_67
 L  EDGE_2_40
 L  EDGE_3_5
 L  EDGE_54_87
 L  EDGE_51_81
 L  EDGE_35_73
 L  EDGE_1_80
 L  EDGE_5_50
 L  EDGE_6_15
 L  EDGE_46_88
 L  EDGE_38_84
 L  EDGE_17_61
 L  EDGE_9_57
 L  EDGE_29_35
 L  EDGE_69_71
 L  EDGE_2_17
 L  EDGE_13_32
 L  EDGE_31_80
 L  EDGE_4_63
 L  EDGE_32_45
 L  EDGE_35_50
 L  EDGE_13_68
 L  EDGE_5_27
 L  EDGE_16_73
 L  EDGE_76_87
 L  EDGE_9_34
 L  EDGE_68_83
 L  EDGE_6_28
 L  EDGE_58_75
 L  EDGE_50_71
 L  EDGE_69_84
 L  EDGE_42_67
 L  EDGE_61_80
 L  EDGE_0_70
 L  EDGE_12_44
 L  EDGE_23_53
 L  EDGE_2_30
 L  EDGE_12_80
 L  EDGE_4_76
 L  EDGE_24_54
 L  EDGE_16_50
 L  EDGE_7_86
 L  EDGE_19_60
 L  EDGE_20_61
 L  EDGE_4_53
 L  EDGE_23_66
 L  EDGE_16_27
 L  EDGE_35_40
 L  EDGE_34_81
 L  EDGE_38_51
 L  EDGE_17_28
 L  EDGE_57_64
 L  EDGE_76_77
 L  EDGE_15_67
 L  EDGE_26_76
 L  EDGE_79_88
 L  EDGE_50_61
 L  EDGE_42_57
 L  EDGE_20_38
 L  EDGE_11_69
 L  EDGE_12_34
 L  EDGE_30_82
 L  EDGE_31_47
 L  EDGE_1_24
 L  EDGE_4_66
 L  EDGE_64_80
 L  EDGE_14_79
 L  EDGE_26_53
 L  EDGE_46_68
 L  EDGE_7_76
 L  EDGE_26_89
 L  EDGE_30_59
 L  EDGE_60_87
 L  EDGE_33_70
 L  EDGE_44_79
 L  EDGE_10_86
 L  EDGE_16_17
 L  EDGE_22_60
 L  EDGE_1_37
 L  EDGE_34_71
 L  EDGE_45_80
 L  EDGE_38_41
 L  EDGE_56_89
 L  EDGE_49_50
 L  EDGE_15_57
 L  EDGE_7_53
 L  EDGE_19_27
 L  EDGE_71_74
 L  EDGE_63_70
 L  EDGE_29_77
 L  EDGE_40_86
 L  EDGE_19_63
 L  EDGE_4_20
 L  EDGE_23_33
 L  EDGE_75_80
 L  EDGE_41_87
 L  EDGE_34_48
 L  EDGE_53_61
 L  EDGE_72_74
 L  EDGE_64_70
 L  EDGE_22_73
 L  EDGE_67_81
 L  EDGE_59_77
 L  EDGE_38_54
 L  EDGE_15_70
 L  EDGE_7_66
 L  EDGE_8_31
 L  EDGE_27_44
 L  EDGE_11_36
 L  EDGE_30_49
 L  EDGE_71_87
 L  EDGE_21_86
 L  EDGE_41_64
 L  EDGE_25_56
 L  EDGE_4_33
 L  EDGE_44_69
 L  EDGE_14_46
 L  EDGE_45_70
 L  EDGE_37_66
 L  EDGE_14_82
 L  EDGE_15_47
 L  EDGE_7_43
 L  EDGE_0_4
 L  EDGE_21_63
 L  EDGE_11_49
 L  EDGE_4_10
 L  EDGE_44_46
 L  EDGE_34_38
 L  EDGE_45_47
 L  EDGE_10_89
 L  EDGE_2_85
 L  EDGE_3_50
 L  EDGE_15_24
 L  EDGE_26_33
 L  EDGE_70_76
 L  EDGE_36_83
 L  EDGE_40_53
 L  EDGE_11_26
 L  EDGE_21_76
 L  EDGE_40_89
 L  EDGE_41_54
 L  EDGE_60_67
 L  EDGE_34_51
 L  EDGE_13_77
 L  EDGE_36_60
 L  EDGE_59_80
 L  EDGE_17_83
 L  EDGE_9_79
 L  EDGE_21_53
 L  EDGE_6_73
 L  EDGE_33_63
 L  EDGE_32_67
 L  EDGE_35_72
 L  EDGE_14_49
 L  EDGE_17_60
 L  EDGE_47_82
 L  EDGE_40_43
 L  EDGE_5_85
 L  EDGE_6_50
 L  EDGE_29_70
 L  EDGE_33_40
 L  EDGE_73_76
 L  EDGE_25_36
 L  EDGE_39_83
 L  EDGE_44_49
 L  EDGE_31_79
 L  EDGE_10_56
 L  EDGE_51_57
 L  EDGE_14_26
 L  EDGE_85_86
 L  EDGE_13_67
 L  EDGE_24_76
 L  EDGE_43_89
 L  EDGE_35_85
 L  EDGE_55_63
 L  EDGE_28_46
 L  EDGE_47_59
 L  EDGE_5_62
 L  EDGE_6_27
 L  EDGE_17_73
 L  EDGE_29_47
 L  EDGE_69_83
 L  EDGE_61_79
 L  EDGE_6_63
 L  EDGE_54_76
 L  EDGE_4_75
 L  EDGE_13_80
 L  EDGE_47_72
 L  EDGE_6_40
 L  EDGE_42_79
 L  EDGE_8_86
 L  EDGE_0_82
 L  EDGE_31_69
 L  EDGE_2_42
 L  EDGE_13_57
 L  EDGE_24_66
 L  EDGE_43_79
 L  EDGE_16_62
 L  EDGE_17_27
 L  EDGE_47_49
 L  EDGE_5_52
 L  EDGE_6_17
 L  EDGE_38_86
 L  EDGE_29_37
 L  EDGE_69_73
 L  EDGE_80_82
 L  EDGE_27_76
 L  EDGE_19_72
 L  EDGE_39_50
 L  EDGE_30_81
 L  EDGE_54_66
 L  EDGE_39_86
 L  EDGE_12_69
 L  EDGE_72_83
 L  EDGE_23_78
 L  EDGE_51_60
 L  EDGE_35_52
 L  EDGE_9_36
 L  EDGE_28_49
 L  EDGE_68_85
 L  EDGE_26_88
 L  EDGE_61_82
 L  EDGE_23_55
 L  EDGE_1_36
 L  EDGE_12_82
 L  EDGE_45_79
 L  EDGE_16_52
 L  EDGE_9_13
 L  EDGE_5_42
 L  EDGE_57_89
 L  EDGE_21_23
 L  EDGE_19_62
 L  EDGE_41_86
 L  EDGE_12_59
 L  EDGE_13_24
 L  EDGE_24_33
 L  EDGE_1_49
 L  EDGE_87_89
 L  EDGE_57_66
 L  EDGE_9_26
 L  EDGE_7_65
 L  EDGE_6_20
 L  EDGE_30_48
 L  EDGE_50_63
 L  EDGE_42_59
 L  EDGE_8_66
 L  EDGE_19_75
 L  EDGE_11_71
 L  EDGE_34_60
 L  EDGE_13_37
 L  EDGE_53_73
 L  EDGE_72_86
 L  EDGE_37_65
 L  EDGE_16_42
 L  EDGE_56_78
 L  EDGE_22_85
 L  EDGE_14_81
 L  EDGE_15_46
 L  EDGE_49_75
 L  EDGE_15_82
 L  EDGE_18_87
 L  EDGE_41_76
 L  EDGE_1_3
 L  EDGE_33_72
 L  EDGE_12_49
 L  EDGE_25_68
 L  EDGE_52_85
 L  EDGE_16_19
 L  EDGE_37_78
 L  EDGE_78_79
 L  EDGE_3_85
 L  EDGE_18_64
 L  EDGE_11_25
 L  EDGE_63_72
 L  EDGE_41_53
 L  EDGE_11_61
 L  EDGE_52_62
 L  EDGE_75_82
 L  EDGE_74_86
 L  EDGE_64_72
 L  EDGE_37_55
 L  EDGE_56_68
 L  EDGE_3_62
 L  EDGE_22_75
 L  EDGE_67_83
 L  EDGE_38_56
 L  EDGE_70_88
 L  EDGE_48_69
 L  EDGE_0_29
 L  EDGE_40_65
 L  EDGE_6_72
 L  EDGE_11_38
 L  EDGE_30_51
 L  EDGE_63_85
 L  EDGE_60_79
 L  EDGE_52_75
 L  EDGE_25_58
 L  EDGE_10_78
 L  EDGE_36_72
 L  EDGE_18_54
 L  EDGE_11_15
 L  EDGE_48_82
 L  EDGE_40_78
 L  EDGE_41_43
 L  EDGE_6_85
 L  EDGE_34_40
 L  EDGE_25_71
 L  EDGE_45_49
 L  EDGE_32_79
 L  EDGE_43_88
 L  EDGE_22_65
 L  EDGE_15_26
 L  EDGE_55_62
 L  EDGE_40_55
 L  EDGE_63_75
 L  EDGE_21_78
 L  EDGE_62_79
 L  EDGE_10_68
 L  EDGE_15_39
 L  EDGE_7_35
 L  EDGE_47_71
 L  EDGE_18_44
 L  EDGE_17_85
 L  EDGE_58_86
 L  EDGE_29_59
 L  EDGE_40_68
 L  EDGE_54_88
 L  EDGE_14_15
 L  EDGE_4_87
 L  EDGE_32_69
 L  EDGE_24_65
 L  EDGE_17_62
 L  EDGE_21_32
 L  EDGE_5_87
 L  EDGE_62_69
 L  EDGE_2_54
 L  EDGE_43_55
 L  EDGE_66_75
 L  EDGE_17_39
 L  EDGE_36_52
 L  EDGE_55_65
 L  EDGE_28_48
 L  EDGE_69_85
 L  EDGE_19_84
 L  EDGE_39_62
 L  EDGE_62_82
 L  EDGE_4_77
 L  EDGE_16_51
 L  EDGE_5_41
 L  EDGE_36_65
 L  EDGE_49_84
 L  EDGE_2_8
 L  EDGE_39_75
 L  EDGE_3_9
 L  EDGE_1_48
 L  EDGE_87_88
 L  EDGE_65_69
 L  EDGE_16_64
 L  EDGE_1_84
 L  EDGE_5_54
 L  EDGE_58_66
 L  EDGE_42_58
 L  EDGE_61_71
 L  EDGE_80_84
 L  EDGE_19_74
 L  EDGE_20_39
 L  EDGE_11_70
 L  EDGE_2_21
 L  EDGE_13_36
 L  EDGE_31_84
 L  EDGE_72_85
 L  EDGE_23_80
 L  EDGE_1_61
 L  EDGE_46_69
 L  EDGE_65_82
 L  EDGE_57_78
 L  EDGE_49_74
 L  EDGE_68_87
 L  EDGE_15_81
 L  EDGE_30_60
 L  EDGE_50_75
 L  EDGE_42_71
 L  EDGE_61_84
 L  EDGE_8_78
 L  EDGE_20_52
 L  EDGE_11_83
 L  EDGE_12_48
 L  EDGE_31_61
 L  EDGE_16_18
 L  EDGE_53_85
 L  EDGE_37_77
 L  EDGE_3_84
 L  EDGE_49_51
 L  EDGE_5_44
 L  EDGE_6_9
 L  EDGE_46_82
 L  EDGE_50_52
 L  EDGE_42_48
 L  EDGE_8_55
 L  EDGE_19_64
 L  EDGE_12_25
 L  EDGE_1_15
 L  EDGE_13_26
 L  EDGE_53_62
 L  EDGE_4_57
 L  EDGE_24_35
 L  EDGE_22_74
 L  EDGE_65_72
 L  EDGE_38_55
 L  EDGE_57_68
 L  EDGE_9_28
 L  EDGE_7_67
 L  EDGE_0_64
 L  EDGE_11_73
 L  EDGE_52_74
 L  EDGE_23_47
 L  EDGE_1_28
 L  EDGE_64_84
 L  EDGE_56_80
 L  EDGE_3_74
 L  EDGE_22_87
 L  EDGE_7_44
 L  EDGE_38_68
 L  EDGE_8_45
 L  EDGE_27_58
 L  EDGE_19_54
 L  EDGE_30_63
 L  EDGE_4_11
 L  EDGE_23_24
 L  EDGE_1_5
 L  EDGE_33_74
 L  EDGE_34_39
 L  EDGE_52_87
 L  EDGE_45_48
 L  EDGE_56_57
 L  EDGE_67_72
 L  EDGE_57_58
 L  EDGE_49_54
 L  EDGE_19_31
 L  EDGE_63_74
 L  EDGE_82_87
 L  EDGE_41_55
 L  EDGE_20_32
 L  EDGE_4_24
 L  EDGE_10_67
 L  EDGE_22_77
 L  EDGE_14_73
 L  EDGE_15_38
 L  EDGE_59_81
 L  EDGE_0_31
 L  EDGE_33_64
 L  EDGE_52_77
 L  EDGE_2_76
 L  EDGE_15_51
 L  EDGE_0_8
 L  EDGE_11_17
 L  EDGE_21_67
 L  EDGE_6_87
 L  EDGE_10_57
 L  EDGE_22_31
 L  EDGE_14_27
 L  EDGE_34_42
 L  EDGE_25_73
 L  EDGE_45_51
 L  EDGE_37_47
 L  EDGE_70_80
 L  EDGE_36_87
 L  EDGE_21_44
 L  EDGE_0_21
 L  EDGE_3_31
 L  EDGE_14_40
 L  EDGE_66_87
 L  EDGE_17_51
 L  EDGE_6_41
 L  EDGE_17_87
 L  EDGE_29_61
 L  EDGE_40_70
 L  EDGE_10_47
 L  EDGE_2_43
 L  EDGE_13_58
 L  EDGE_24_67
 L  EDGE_36_41
 L  EDGE_1_83
 L  EDGE_7_14
 L  EDGE_17_64
 L  EDGE_77_78
 L  EDGE_48_51
 L  EDGE_2_20
 L  EDGE_62_71
 L  EDGE_73_80
 L  EDGE_20_74
 L  EDGE_2_56
 L  EDGE_43_57
 L  EDGE_66_77
 L  EDGE_28_50
 L  EDGE_58_78
 L  EDGE_9_73
 L  EDGE_50_74
 L  EDGE_29_51
 L  EDGE_69_87
 L  EDGE_21_47
 L  EDGE_11_82
 L  EDGE_2_33
 L  EDGE_54_80
 L  EDGE_20_87
 L  EDGE_51_74
 L  EDGE_35_66
 L  EDGE_1_73
 L  EDGE_6_8
 L  EDGE_38_77
 L  EDGE_28_63
 L  EDGE_27_67
 L  EDGE_2_10
 L  EDGE_54_57
 L  EDGE_0_86
 L  EDGE_20_64
 L  EDGE_12_60
 L  EDGE_13_25
 L  EDGE_4_56
 L  EDGE_32_38
 L  EDGE_3_11
 L  EDGE_34_84
 L  EDGE_5_20
 L  EDGE_37_89
 L  EDGE_50_64
 L  EDGE_69_77
 L  EDGE_42_60
 L  EDGE_0_63
 L  EDGE_19_76
 L  EDGE_20_41
 L  EDGE_39_54
 L  EDGE_30_85
 L  EDGE_13_38
 L  EDGE_23_82
 L  EDGE_35_56
 L  EDGE_1_63
 L  EDGE_65_84
 L  EDGE_38_67
 L  EDGE_49_76
 L  EDGE_68_89
 L  EDGE_15_83
 L  EDGE_7_79
 L  EDGE_50_77
 L  EDGE_12_50
 L  EDGE_13_15
 L  EDGE_4_46
 L  EDGE_23_59
 L  EDGE_53_87
 L  EDGE_38_44
 L  EDGE_6_11
 L  EDGE_79_81
 L  EDGE_42_50
 L  EDGE_61_63
 L  EDGE_8_57
 L  EDGE_20_31
 L  EDGE_11_62
 L  EDGE_1_17
 L  EDGE_33_86
 L  EDGE_13_28
 L  EDGE_53_64
 L  EDGE_4_59
 L  EDGE_24_37
 L  EDGE_64_73
 L  EDGE_14_72
 L  EDGE_34_87
 L  EDGE_38_57
 L  EDGE_7_69
 L  EDGE_8_34
 L  EDGE_27_47
 L  EDGE_0_30
 L  EDGE_18_78
 L  EDGE_19_43
 L  EDGE_11_39
 L  EDGE_63_86
 L  EDGE_0_66
 L  EDGE_20_44
 L  EDGE_12_40
 L  EDGE_44_72
 L  EDGE_1_30
 L  EDGE_34_64
 L  EDGE_53_77
 L  EDGE_45_73
 L  EDGE_64_86
 L  EDGE_3_76
 L  EDGE_7_46
 L  EDGE_18_55
 L  EDGE_6_86
 L  EDGE_12_17
 L  EDGE_4_13
 L  EDGE_33_76
 L  EDGE_52_89
 L  EDGE_13_18
 L  EDGE_53_54
 L  EDGE_45_50
 L  EDGE_37_46
 L  EDGE_16_23
 L  EDGE_2_88
 L  EDGE_14_62
 L  EDGE_86_87
 L  EDGE_18_32
 L  EDGE_49_56
 L  EDGE_7_59
 L  EDGE_48_60
 L  EDGE_0_20
 L  EDGE_18_68
 L  EDGE_30_42
 L  EDGE_82_89
 L  EDGE_29_83
 L  EDGE_21_79
 L  EDGE_41_57
 L  EDGE_60_70
 L  EDGE_12_30
 L  EDGE_14_39
 L  EDGE_25_85
 L  EDGE_37_59
 L  EDGE_67_87
 L  EDGE_59_83
 L  EDGE_21_56
 L  EDGE_11_42
 L  EDGE_51_83
 L  EDGE_14_52
 L  EDGE_15_17
 L  EDGE_7_13
 L  EDGE_17_63
 L  EDGE_36_76
 L  EDGE_28_72
 L  EDGE_7_49
 L  EDGE_48_50
 L  EDGE_6_53
 L  EDGE_41_47
 L  EDGE_73_79
 L  EDGE_25_39
 L  EDGE_2_55
 L  EDGE_3_20
 L  EDGE_34_44
 L  EDGE_66_76
 L  EDGE_37_49
 L  EDGE_3_56
 L  EDGE_55_66
 L  EDGE_26_39
 L  EDGE_5_65
 L  EDGE_70_82
 L  EDGE_36_89
 L  EDGE_9_72
 L  EDGE_48_63
 L  EDGE_21_46
 L  EDGE_6_66
 L  EDGE_2_32
 L  EDGE_62_83
 L  EDGE_33_56
 L  EDGE_32_60
 L  EDGE_3_33
 L  EDGE_66_89
 L  EDGE_17_53
 L  EDGE_36_66
 L  EDGE_55_79
 L  EDGE_28_62
 L  EDGE_29_63
 L  EDGE_42_82
 L  EDGE_10_49
 L  EDGE_3_10
 L  EDGE_55_56
 L  EDGE_28_39
 L  EDGE_58_67
 L  EDGE_9_62
 L  EDGE_28_75
 L  EDGE_29_40
 L  EDGE_61_72
 L  EDGE_80_85
 L  EDGE_73_82
 L  EDGE_39_89
 L  EDGE_12_72
 L  EDGE_4_68
 L  EDGE_23_81
 L  EDGE_24_46
 L  EDGE_3_23
 L  EDGE_24_82
 L  EDGE_16_78
 L  EDGE_47_65
 L  EDGE_50_76
 L  EDGE_8_79
 L  EDGE_20_53
 L  EDGE_11_84
 L  EDGE_31_62
 L  EDGE_23_58
 L  EDGE_54_82
 L  EDGE_20_89
 L  EDGE_12_85
 L  EDGE_13_50
 L  EDGE_32_63
 L  EDGE_28_29
 L  EDGE_1_75
 L  EDGE_5_45
 L  EDGE_17_56
 L  EDGE_61_62
 L  EDGE_50_89
 L  EDGE_42_85
 L  EDGE_62_63
 L  EDGE_0_88
 L  EDGE_51_53
 L  EDGE_84_87
 L  EDGE_35_45
 L  EDGE_1_52
 L  EDGE_16_68
 L  EDGE_57_69
 L  EDGE_76_82
 L  EDGE_9_29
 L  EDGE_49_65
 L  EDGE_28_42
 L  EDGE_15_72
 L  EDGE_5_58
 L  EDGE_18_77
 L  EDGE_58_70
 L  EDGE_50_66
 L  EDGE_42_62
 L  EDGE_8_69
 L  EDGE_27_82
 L  EDGE_20_43
 L  EDGE_11_74
 L  EDGE_12_39
 L  EDGE_30_87
 L  EDGE_12_75
 L  EDGE_13_40
 L  EDGE_1_65
 L  EDGE_65_86
 L  EDGE_49_78
 L  EDGE_8_46
 L  EDGE_30_64
 L  EDGE_42_75
 L  EDGE_0_78
 L  EDGE_13_17
 L  EDGE_24_26
 L  EDGE_34_76
 L  EDGE_45_85
 L  EDGE_46_50
 L  EDGE_17_23
 L  EDGE_7_58
 L  EDGE_26_71
 L  EDGE_27_36
 L  EDGE_18_67
 L  EDGE_38_82
 L  EDGE_79_83
 L  EDGE_71_79
 L  EDGE_50_56
 L  EDGE_82_88
 L  EDGE_20_33
 L  EDGE_11_64
 L  EDGE_31_42
 L  EDGE_4_25
 L  EDGE_23_38
 L  EDGE_1_19
 L  EDGE_25_84
 L  EDGE_72_79
 L  EDGE_56_71
 L  EDGE_22_78
 L  EDGE_14_74
 L  EDGE_34_89
 L  EDGE_67_86
 L  EDGE_5_25
 L  EDGE_57_72
 L  EDGE_26_84
 L  EDGE_0_32
 L  EDGE_18_80
 L  EDGE_19_45
 L  EDGE_0_68
 L  EDGE_4_38
 L  EDGE_2_77
 L  EDGE_1_32
 L  EDGE_55_88
 L  EDGE_29_72
 L  EDGE_8_49
 L  EDGE_40_81
 L  EDGE_41_46
 L  EDGE_20_23
 L  EDGE_11_54
 L  EDGE_12_19
 L  EDGE_1_9
 L  EDGE_25_74
 L  EDGE_44_87
 L  EDGE_85_88
 L  EDGE_64_65
 L  EDGE_22_68
 L  EDGE_15_29
 L  EDGE_7_25
 L  EDGE_26_38
 L  EDGE_67_76
 L  EDGE_18_34
 L  EDGE_59_72
 L  EDGE_70_81
 L  EDGE_28_84
 L  EDGE_7_61
 L  EDGE_0_22
 L  EDGE_19_35
 L  EDGE_30_44
 L  EDGE_63_78
 L  EDGE_29_85
 L  EDGE_21_81
 L  EDGE_34_56
 L  EDGE_66_88
 L  EDGE_37_61
 L  EDGE_3_68
 L  EDGE_15_42
 L  EDGE_55_78
 L  EDGE_67_89
 L  EDGE_18_47
 L  EDGE_17_88
 L  EDGE_40_71
 L  EDGE_33_68
 L  EDGE_37_38
 L  EDGE_51_85
 L  EDGE_3_45
 L  EDGE_14_54
 L  EDGE_26_28
 L  EDGE_36_78
 L  EDGE_47_87
 L  EDGE_8_16
 L  EDGE_0_12
 L  EDGE_6_55
 L  EDGE_11_21
 L  EDGE_29_75
 L  EDGE_21_71
 L  EDGE_81_85
 L  EDGE_39_88
 L  EDGE_14_31
 L  EDGE_36_55
 L  EDGE_55_68
 L  EDGE_18_37
 L  EDGE_59_75
 L  EDGE_28_87
 L  EDGE_54_81
 L  EDGE_25_54
 L  EDGE_24_58
 L  EDGE_43_71
 L  EDGE_17_55
 L  EDGE_50_88
 L  EDGE_42_84
 L  EDGE_39_78
 L  EDGE_31_74
 L  EDGE_23_70
 L  EDGE_13_62
 L  EDGE_32_75
 L  EDGE_43_84
 L  EDGE_16_67
 L  EDGE_35_80
 L  EDGE_36_45
 L  EDGE_76_81
 L  EDGE_28_41
 L  EDGE_47_54
 L  EDGE_5_57
 L  EDGE_6_22
 L  EDGE_80_87
 L  EDGE_39_55
 L  EDGE_30_86
 L  EDGE_62_75
 L  EDGE_13_39
 L  EDGE_32_52
 L  EDGE_23_83
 L  EDGE_43_61
 L  EDGE_35_57
 L  EDGE_1_64
 L  EDGE_46_72
 L  EDGE_17_45
 L  EDGE_57_81
 L  EDGE_9_41
 L  EDGE_49_77
 L  EDGE_15_84
 L  EDGE_50_78
 L  EDGE_8_81
 L  EDGE_0_77
 L  EDGE_12_51
 L  EDGE_31_64
 L  EDGE_23_60
 L  EDGE_12_87
 L  EDGE_13_52
 L  EDGE_53_88
 L  EDGE_35_70
 L  EDGE_9_18
 L  EDGE_5_47
 L  EDGE_6_12
 L  EDGE_27_71
 L  EDGE_42_87
 L  EDGE_83_88
 L  EDGE_75_84
 L  EDGE_20_68
 L  EDGE_31_77
 L  EDGE_72_78
 L  EDGE_23_73
 L  EDGE_24_38
 L  EDGE_16_34
 L  EDGE_65_75
 L  EDGE_17_35
 L  EDGE_9_31
 L  EDGE_49_67
 L  EDGE_26_83
 L  EDGE_6_25
 L  EDGE_30_53
 L  EDGE_42_64
 L  EDGE_60_81
 L  EDGE_39_58
 L  EDGE_23_50
 L  EDGE_1_31
 L  EDGE_34_65
 L  EDGE_24_51
 L  EDGE_37_70
 L  EDGE_14_86
 L  EDGE_26_60
 L  EDGE_46_75
 L  EDGE_38_71
 L  EDGE_49_80
 L  EDGE_15_87
 L  EDGE_8_48
 L  EDGE_19_57
 L  EDGE_2_4
 L  EDGE_1_8
 L  EDGE_20_58
 L  EDGE_13_19
 L  EDGE_53_55
 L  EDGE_23_63
 L  EDGE_56_60
 L  EDGE_34_78
 L  EDGE_37_83
 L  EDGE_57_61
 L  EDGE_9_21
 L  EDGE_18_69
 L  EDGE_8_61
 L  EDGE_11_66
 L  EDGE_12_31
 L  EDGE_52_67
 L  EDGE_1_21
 L  EDGE_22_80
 L  EDGE_15_41
 L  EDGE_18_46
 L  EDGE_15_77
 L  EDGE_7_73
 L  EDGE_8_38
 L  EDGE_19_47
 L  EDGE_60_84
 L  EDGE_52_80
 L  EDGE_4_40
 L  EDGE_10_83
 L  EDGE_2_79
 L  EDGE_22_57
 L  EDGE_7_50
 L  EDGE_8_15
 L  EDGE_26_63
 L  EDGE_27_28
 L  EDGE_63_67
 L  EDGE_21_70
 L  EDGE_40_83
 L  EDGE_60_61
 L  EDGE_41_84
 L  EDGE_33_80
 L  EDGE_34_45
 L  EDGE_53_58
 L  EDGE_44_89
 L  EDGE_45_54
 L  EDGE_56_63
 L  EDGE_22_70
 L  EDGE_15_31
 L  EDGE_7_27
 L  EDGE_18_36
 L  EDGE_28_86
 L  EDGE_8_28
 L  EDGE_48_64
 L  EDGE_0_24
 L  EDGE_40_60
 L  EDGE_11_33
 L  EDGE_63_80
 L  EDGE_41_61
 L  EDGE_44_66
 L  EDGE_2_69
 L  EDGE_13_84
 L  EDGE_15_44
 L  EDGE_55_80
 L  EDGE_18_49
 L  EDGE_29_64
 L  EDGE_40_73
 L  EDGE_6_80
 L  EDGE_4_7
 L  EDGE_2_46
 L  EDGE_22_24
 L  EDGE_32_74
 L  EDGE_14_56
 L  EDGE_1_86
 L  EDGE_7_17
 L  EDGE_67_68
 L  EDGE_59_64
 L  EDGE_70_73
 L  EDGE_17_67
 L  EDGE_36_80
 L  EDGE_48_54
 L  EDGE_21_37
 L  EDGE_25_43
 L  EDGE_31_86
 L  EDGE_10_63
 L  EDGE_51_64
 L  EDGE_43_60
 L  EDGE_22_37
 L  EDGE_14_33
 L  EDGE_74_84
 L  EDGE_24_83
 L  EDGE_28_53
 L  EDGE_7_30
 L  EDGE_47_66
 L  EDGE_6_34
 L  EDGE_21_50
 L  EDGE_6_70
 L  EDGE_2_36
 L  EDGE_54_83
 L  EDGE_12_86
 L  EDGE_4_82
 L  EDGE_51_77
 L  EDGE_5_46
 L  EDGE_9_53
 L  EDGE_29_31
 L  EDGE_10_17
 L  EDGE_12_63
 L  EDGE_32_41
 L  EDGE_23_72
 L  EDGE_22_27
 L  EDGE_35_46
 L  EDGE_76_83
 L  EDGE_9_30
 L  EDGE_1_89
 L  EDGE_58_71
 L  EDGE_9_66
 L  EDGE_27_83
 L  EDGE_10_30
 L  EDGE_62_77
 L  EDGE_13_41
 L  EDGE_31_89
 L  EDGE_51_67
 L  EDGE_24_50
 L  EDGE_43_63
 L  EDGE_16_46
 L  EDGE_35_59
 L  EDGE_1_66
 L  EDGE_5_36
 L  EDGE_17_47
 L  EDGE_57_83
 L  EDGE_49_79
 L  EDGE_6_37
 L  EDGE_30_65
 L  EDGE_50_80
 L  EDGE_2_3
 L  EDGE_31_66
 L  EDGE_3_4
 L  EDGE_35_36
 L  EDGE_24_63
 L  EDGE_57_60
 L  EDGE_36_37
 L  EDGE_9_20
 L  EDGE_5_49
 L  EDGE_6_14
 L  EDGE_46_87
 L  EDGE_50_57
 L  EDGE_69_70
 L  EDGE_21_30
 L  EDGE_61_66
 L  EDGE_8_60
 L  EDGE_20_34
 L  EDGE_75_86
 L  EDGE_54_63
 L  EDGE_20_70
 L  EDGE_72_80
 L  EDGE_23_75
 L  EDGE_56_72
 L  EDGE_22_79
 L  EDGE_1_56
 L  EDGE_46_64
 L  EDGE_65_77
 L  EDGE_76_86
 L  EDGE_49_69
 L  EDGE_68_82
 L  EDGE_15_76
 L  EDGE_50_70
 L  EDGE_63_89
 L  EDGE_19_82
 L  EDGE_39_60
 L  EDGE_52_79
 L  EDGE_13_44
 L  EDGE_3_79
 L  EDGE_5_39
 L  EDGE_46_77
 L  EDGE_49_82
 L  EDGE_8_50
 L  EDGE_48_86
 L  EDGE_0_46
 L  EDGE_19_59
 L  EDGE_11_55
 L  EDGE_12_20
 L  EDGE_31_33
 L  EDGE_75_76
 L  EDGE_12_56
 L  EDGE_53_57
 L  EDGE_45_53
 L  EDGE_24_30
 L  EDGE_16_26
 L  EDGE_1_46
 L  EDGE_46_54
 L  EDGE_38_50
 L  EDGE_78_86
 L  EDGE_49_59
 L  EDGE_7_62
 L  EDGE_8_27
 L  EDGE_18_71
 L  EDGE_11_32
 L  EDGE_30_45
 L  EDGE_71_83
 L  EDGE_63_79
 L  EDGE_29_86
 L  EDGE_20_37
 L  EDGE_60_73
 L  EDGE_23_42
 L  EDGE_34_57
 L  EDGE_25_88
 L  EDGE_64_79
 L  EDGE_56_75
 L  EDGE_26_52
 L  EDGE_59_86
 L  EDGE_17_89
 L  EDGE_7_75
 L  EDGE_27_53
 L  EDGE_0_36
 L  EDGE_40_72
 L  EDGE_41_73
 L  EDGE_33_69
 L  EDGE_37_39
 L  EDGE_22_59
 L  EDGE_34_70
 L  EDGE_38_40
 L  EDGE_3_82
 L  EDGE_36_79
 L  EDGE_15_56
 L  EDGE_8_17
 L  EDGE_26_65
 L  EDGE_30_35
 L  EDGE_71_73
 L  EDGE_29_76
 L  EDGE_40_85
 L  EDGE_41_50
 L  EDGE_52_59
 L  EDGE_44_55
 L  EDGE_10_62
 L  EDGE_1_13
 L  EDGE_33_82
 L  EDGE_74_83
 L  EDGE_25_78
 L  EDGE_32_86
 L  EDGE_37_52
 L  EDGE_22_72
 L  EDGE_55_69
 L  EDGE_7_29
 L  EDGE_70_85
 L  EDGE_17_79
 L  EDGE_40_62
 L  EDGE_11_35
 L  EDGE_63_82
 L  EDGE_29_89
 L  EDGE_21_85
 L  EDGE_33_59
 L  EDGE_52_72
 L  EDGE_44_68
 L  EDGE_10_75
 L  EDGE_51_76
 L  EDGE_3_36
 L  EDGE_13_86
 L  EDGE_47_78
 L  EDGE_0_3
 L  EDGE_11_12
 L  EDGE_21_62
 L  EDGE_40_75
 L  EDGE_33_36
 L  EDGE_2_48
 L  EDGE_22_26
 L  EDGE_66_69
 L  EDGE_32_76
 L  EDGE_24_72
 L  EDGE_15_23
 L  EDGE_55_59
 L  EDGE_1_88
 L  EDGE_47_55
 L  EDGE_18_28
 L  EDGE_70_75
 L  EDGE_29_43
 L  EDGE_10_29
 L  EDGE_81_89
 L  EDGE_54_72
 L  EDGE_73_85
 L  EDGE_25_45
 L  EDGE_23_84
 L  EDGE_51_66
 L  EDGE_2_61
 L  EDGE_43_62
 L  EDGE_14_35
 L  EDGE_66_82
 L  EDGE_36_59
 L  EDGE_47_68
 L  EDGE_6_36
 L  EDGE_17_82
 L  EDGE_58_83
 L  EDGE_29_56
 L  EDGE_21_52
 L  EDGE_35_71
 L  EDGE_9_55
 L  EDGE_21_29
 L  EDGE_40_42
 L  EDGE_5_84
 L  EDGE_6_49
 L  EDGE_73_75
 L  EDGE_20_69
 L  EDGE_39_82
 L  EDGE_32_43
 L  EDGE_23_74
 L  EDGE_3_16
 L  EDGE_43_52
 L  EDGE_35_48
 L  EDGE_14_25
 L  EDGE_47_58
 L  EDGE_61_78
 L  EDGE_20_46
 L  EDGE_39_59
 L  EDGE_31_55
 L  EDGE_54_75
 L  EDGE_4_74
 L  EDGE_23_87
 L  EDGE_24_52
 L  EDGE_64_88
 L  EDGE_16_48
 L  EDGE_15_88
 L  EDGE_27_62
 L  EDGE_6_39
 L  EDGE_50_82
 L  EDGE_42_78
 L  EDGE_2_5
 L  EDGE_31_68
 L  EDGE_23_64
 L  EDGE_16_25
 L  EDGE_35_38
 L  EDGE_34_79
 L  EDGE_13_56
 L  EDGE_45_88
 L  EDGE_5_15
 L  EDGE_37_84
 L  EDGE_16_61
 L  EDGE_57_62
 L  EDGE_36_39
 L  EDGE_26_74
 L  EDGE_5_51
 L  EDGE_50_59
 L  EDGE_69_72
 L  EDGE_19_71
 L  EDGE_75_88
 L  EDGE_1_22
 L  EDGE_12_68
 L  EDGE_13_33
 L  EDGE_53_69
 L  EDGE_4_64
 L  EDGE_16_38
 L  EDGE_35_51
 L  EDGE_1_58
 L  EDGE_5_28
 L  EDGE_65_79
 L  EDGE_38_62
 L  EDGE_26_87
 L  EDGE_27_52
 L  EDGE_18_83
 L  EDGE_19_48
 L  EDGE_11_44
 L  EDGE_20_49
 L  EDGE_11_80
 L  EDGE_44_77
 L  EDGE_1_35
 L  EDGE_53_82
 L  EDGE_45_78
 L  EDGE_38_39
 L  EDGE_9_12
 L  EDGE_15_55
 L  EDGE_38_75
 L  EDGE_7_87
 L  EDGE_20_26
 L  EDGE_11_57
 L  EDGE_30_70
 L  EDGE_23_31
 L  EDGE_34_46
 L  EDGE_13_23
 L  EDGE_25_77
 L  EDGE_4_54
 L  EDGE_64_68
 L  EDGE_46_56
 L  EDGE_38_52
 L  EDGE_7_64
 L  EDGE_18_73
 L  EDGE_19_38
 L  EDGE_21_84
 L  EDGE_41_62
 L  EDGE_52_71
 L  EDGE_1_25
 L  EDGE_34_59
 L  EDGE_3_71
 L  EDGE_22_84
 L  EDGE_14_80
 L  EDGE_15_45
 L  EDGE_55_81
 L  EDGE_7_41
 L  EDGE_11_47
 L  EDGE_4_8
 L  EDGE_1_2
 L  EDGE_22_61
 L  EDGE_15_22
 L  EDGE_67_69
 L  EDGE_18_27
 L  EDGE_8_19
 L  EDGE_30_37
 L  EDGE_71_75
 L  EDGE_63_71
 L  EDGE_82_84
 L  EDGE_29_78
 L  EDGE_33_48
 L  EDGE_25_44
 L  EDGE_4_21
 L  EDGE_10_64
 L  EDGE_14_34
 L  EDGE_34_49
 L  EDGE_66_81
 L  EDGE_32_88
 L  EDGE_24_84
 L  EDGE_15_35
 L  EDGE_29_55
 L  EDGE_48_68
 L  EDGE_21_51
 L  EDGE_25_57
 L  EDGE_10_77
 L  EDGE_51_78
 L  EDGE_43_74
 L  EDGE_14_47
 L  EDGE_7_8
COLUMNS
    x_0         OBJ       -1
    x_0         EDGE_0_70  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_82  1.0
    x_0         EDGE_0_29  1.0
    x_0         EDGE_0_64  1.0
    x_0         EDGE_0_31  1.0
    x_0         EDGE_0_8  1.0
    x_0         EDGE_0_21  1.0
    x_0         EDGE_0_86  1.0
    x_0         EDGE_0_63  1.0
    x_0         EDGE_0_30  1.0
    x_0         EDGE_0_66  1.0
    x_0         EDGE_0_20  1.0
    x_0         EDGE_0_88  1.0
    x_0         EDGE_0_78  1.0
    x_0         EDGE_0_32  1.0
    x_0         EDGE_0_68  1.0
    x_0         EDGE_0_22  1.0
    x_0         EDGE_0_12  1.0
    x_0         EDGE_0_77  1.0
    x_0         EDGE_0_24  1.0
    x_0         EDGE_0_46  1.0
    x_0         EDGE_0_36  1.0
    x_0         EDGE_0_3  1.0
    x_1         OBJ       -1
    x_1         EDGE_1_67  1.0
    x_1         EDGE_1_80  1.0
    x_1         EDGE_1_24  1.0
    x_1         EDGE_1_37  1.0
    x_1         EDGE_1_36  1.0
    x_1         EDGE_1_49  1.0
    x_1         EDGE_1_3  1.0
    x_1         EDGE_1_48  1.0
    x_1         EDGE_1_84  1.0
    x_1         EDGE_1_61  1.0
    x_1         EDGE_1_15  1.0
    x_1         EDGE_1_28  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_83  1.0
    x_1         EDGE_1_73  1.0
    x_1         EDGE_1_63  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_30  1.0
    x_1         EDGE_1_75  1.0
    x_1         EDGE_1_52  1.0
    x_1         EDGE_1_65  1.0
    x_1         EDGE_1_19  1.0
    x_1         EDGE_1_32  1.0
    x_1         EDGE_1_9  1.0
    x_1         EDGE_1_64  1.0
    x_1         EDGE_1_31  1.0
    x_1         EDGE_1_8  1.0
    x_1         EDGE_1_21  1.0
    x_1         EDGE_1_86  1.0
    x_1         EDGE_1_89  1.0
    x_1         EDGE_1_66  1.0
    x_1         EDGE_1_56  1.0
    x_1         EDGE_1_46  1.0
    x_1         EDGE_1_13  1.0
    x_1         EDGE_1_88  1.0
    x_1         EDGE_1_22  1.0
    x_1         EDGE_1_58  1.0
    x_1         EDGE_1_35  1.0
    x_1         EDGE_1_25  1.0
    x_1         EDGE_1_2  1.0
    x_2         OBJ       -1
    x_2         EDGE_2_27  1.0
    x_2         EDGE_2_40  1.0
    x_2         EDGE_2_17  1.0
    x_2         EDGE_2_30  1.0
    x_2         EDGE_2_85  1.0
    x_2         EDGE_2_42  1.0
    x_2         EDGE_2_54  1.0
    x_2         EDGE_2_8  1.0
    x_2         EDGE_2_21  1.0
    x_2         EDGE_2_76  1.0
    x_2         EDGE_2_43  1.0
    x_2         EDGE_2_20  1.0
    x_2         EDGE_2_56  1.0
    x_2         EDGE_2_33  1.0
    x_2         EDGE_2_10  1.0
    x_2         EDGE_2_88  1.0
    x_2         EDGE_2_55  1.0
    x_2         EDGE_2_32  1.0
    x_2         EDGE_2_77  1.0
    x_2         EDGE_2_4  1.0
    x_2         EDGE_2_79  1.0
    x_2         EDGE_2_69  1.0
    x_2         EDGE_2_46  1.0
    x_2         EDGE_2_36  1.0
    x_2         EDGE_2_3  1.0
    x_2         EDGE_2_48  1.0
    x_2         EDGE_2_61  1.0
    x_2         EDGE_2_5  1.0
    x_2         EDGE_1_2  1.0
    x_3         OBJ       -1
    x_3         EDGE_3_5  1.0
    x_3         EDGE_3_50  1.0
    x_3         EDGE_1_3  1.0
    x_3         EDGE_3_85  1.0
    x_3         EDGE_3_62  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_3_84  1.0
    x_3         EDGE_3_74  1.0
    x_3         EDGE_3_31  1.0
    x_3         EDGE_3_11  1.0
    x_3         EDGE_3_76  1.0
    x_3         EDGE_3_20  1.0
    x_3         EDGE_3_56  1.0
    x_3         EDGE_3_33  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_23  1.0
    x_3         EDGE_3_68  1.0
    x_3         EDGE_3_45  1.0
    x_3         EDGE_2_3  1.0
    x_3         EDGE_3_4  1.0
    x_3         EDGE_3_79  1.0
    x_3         EDGE_3_82  1.0
    x_3         EDGE_3_36  1.0
    x_3         EDGE_0_3  1.0
    x_3         EDGE_3_16  1.0
    x_3         EDGE_3_71  1.0
    x_4         OBJ       -1
    x_4         EDGE_4_63  1.0
    x_4         EDGE_4_76  1.0
    x_4         EDGE_4_53  1.0
    x_4         EDGE_4_66  1.0
    x_4         EDGE_4_20  1.0
    x_4         EDGE_4_33  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_4_10  1.0
    x_4         EDGE_4_75  1.0
    x_4         EDGE_4_87  1.0
    x_4         EDGE_4_77  1.0
    x_4         EDGE_4_57  1.0
    x_4         EDGE_4_11  1.0
    x_4         EDGE_4_24  1.0
    x_4         EDGE_4_56  1.0
    x_4         EDGE_4_46  1.0
    x_4         EDGE_4_59  1.0
    x_4         EDGE_4_13  1.0
    x_4         EDGE_4_68  1.0
    x_4         EDGE_4_25  1.0
    x_4         EDGE_4_38  1.0
    x_4         EDGE_2_4  1.0
    x_4         EDGE_4_40  1.0
    x_4         EDGE_4_7  1.0
    x_4         EDGE_4_82  1.0
    x_4         EDGE_3_4  1.0
    x_4         EDGE_4_74  1.0
    x_4         EDGE_4_64  1.0
    x_4         EDGE_4_54  1.0
    x_4         EDGE_4_8  1.0
    x_4         EDGE_4_21  1.0
    x_5         OBJ       -1
    x_5         EDGE_5_73  1.0
    x_5         EDGE_3_5  1.0
    x_5         EDGE_5_50  1.0
    x_5         EDGE_5_27  1.0
    x_5         EDGE_5_85  1.0
    x_5         EDGE_5_62  1.0
    x_5         EDGE_5_52  1.0
    x_5         EDGE_5_42  1.0
    x_5         EDGE_5_87  1.0
    x_5         EDGE_5_41  1.0
    x_5         EDGE_5_54  1.0
    x_5         EDGE_5_44  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_20  1.0
    x_5         EDGE_5_65  1.0
    x_5         EDGE_5_45  1.0
    x_5         EDGE_5_58  1.0
    x_5         EDGE_5_25  1.0
    x_5         EDGE_5_57  1.0
    x_5         EDGE_5_47  1.0
    x_5         EDGE_5_46  1.0
    x_5         EDGE_5_36  1.0
    x_5         EDGE_5_49  1.0
    x_5         EDGE_5_39  1.0
    x_5         EDGE_5_84  1.0
    x_5         EDGE_2_5  1.0
    x_5         EDGE_5_15  1.0
    x_5         EDGE_5_51  1.0
    x_5         EDGE_5_28  1.0
    x_6         OBJ       -1
    x_6         EDGE_6_38  1.0
    x_6         EDGE_6_15  1.0
    x_6         EDGE_6_28  1.0
    x_6         EDGE_6_73  1.0
    x_6         EDGE_6_50  1.0
    x_6         EDGE_6_27  1.0
    x_6         EDGE_6_63  1.0
    x_6         EDGE_6_40  1.0
    x_6         EDGE_6_17  1.0
    x_6         EDGE_6_20  1.0
    x_6         EDGE_6_72  1.0
    x_6         EDGE_6_85  1.0
    x_6         EDGE_6_9  1.0
    x_6         EDGE_6_87  1.0
    x_6         EDGE_6_41  1.0
    x_6         EDGE_6_8  1.0
    x_6         EDGE_6_11  1.0
    x_6         EDGE_6_86  1.0
    x_6         EDGE_6_53  1.0
    x_6         EDGE_6_66  1.0
    x_6         EDGE_6_55  1.0
    x_6         EDGE_6_22  1.0
    x_6         EDGE_6_12  1.0
    x_6         EDGE_6_25  1.0
    x_6         EDGE_6_80  1.0
    x_6         EDGE_6_34  1.0
    x_6         EDGE_6_70  1.0
    x_6         EDGE_6_37  1.0
    x_6         EDGE_6_14  1.0
    x_6         EDGE_6_36  1.0
    x_6         EDGE_6_49  1.0
    x_6         EDGE_6_39  1.0
    x_7         OBJ       -1
    x_7         EDGE_7_86  1.0
    x_7         EDGE_7_76  1.0
    x_7         EDGE_7_53  1.0
    x_7         EDGE_7_66  1.0
    x_7         EDGE_7_43  1.0
    x_7         EDGE_7_65  1.0
    x_7         EDGE_7_35  1.0
    x_7         EDGE_7_67  1.0
    x_7         EDGE_7_44  1.0
    x_7         EDGE_7_14  1.0
    x_7         EDGE_7_79  1.0
    x_7         EDGE_7_69  1.0
    x_7         EDGE_7_46  1.0
    x_7         EDGE_7_59  1.0
    x_7         EDGE_7_13  1.0
    x_7         EDGE_7_49  1.0
    x_7         EDGE_7_58  1.0
    x_7         EDGE_7_25  1.0
    x_7         EDGE_7_61  1.0
    x_7         EDGE_7_73  1.0
    x_7         EDGE_7_50  1.0
    x_7         EDGE_7_27  1.0
    x_7         EDGE_4_7  1.0
    x_7         EDGE_7_17  1.0
    x_7         EDGE_7_30  1.0
    x_7         EDGE_7_62  1.0
    x_7         EDGE_7_75  1.0
    x_7         EDGE_7_29  1.0
    x_7         EDGE_7_87  1.0
    x_7         EDGE_7_64  1.0
    x_7         EDGE_7_41  1.0
    x_7         EDGE_7_8  1.0
    x_8         OBJ       -1
    x_8         EDGE_8_9  1.0
    x_8         EDGE_8_31  1.0
    x_8         EDGE_8_86  1.0
    x_8         EDGE_8_66  1.0
    x_8         EDGE_2_8  1.0
    x_8         EDGE_8_78  1.0
    x_8         EDGE_8_55  1.0
    x_8         EDGE_8_45  1.0
    x_8         EDGE_0_8  1.0
    x_8         EDGE_6_8  1.0
    x_8         EDGE_8_57  1.0
    x_8         EDGE_8_34  1.0
    x_8         EDGE_8_79  1.0
    x_8         EDGE_8_69  1.0
    x_8         EDGE_8_46  1.0
    x_8         EDGE_8_49  1.0
    x_8         EDGE_8_16  1.0
    x_8         EDGE_8_81  1.0
    x_8         EDGE_8_48  1.0
    x_8         EDGE_1_8  1.0
    x_8         EDGE_8_61  1.0
    x_8         EDGE_8_38  1.0
    x_8         EDGE_8_15  1.0
    x_8         EDGE_8_28  1.0
    x_8         EDGE_8_60  1.0
    x_8         EDGE_8_50  1.0
    x_8         EDGE_8_27  1.0
    x_8         EDGE_8_17  1.0
    x_8         EDGE_4_8  1.0
    x_8         EDGE_8_19  1.0
    x_8         EDGE_7_8  1.0
    x_9         OBJ       -1
    x_9         EDGE_8_9  1.0
    x_9         EDGE_9_67  1.0
    x_9         EDGE_9_57  1.0
    x_9         EDGE_9_34  1.0
    x_9         EDGE_9_79  1.0
    x_9         EDGE_9_36  1.0
    x_9         EDGE_9_13  1.0
    x_9         EDGE_9_26  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_6_9  1.0
    x_9         EDGE_9_28  1.0
    x_9         EDGE_9_73  1.0
    x_9         EDGE_9_72  1.0
    x_9         EDGE_9_62  1.0
    x_9         EDGE_9_29  1.0
    x_9         EDGE_1_9  1.0
    x_9         EDGE_9_41  1.0
    x_9         EDGE_9_18  1.0
    x_9         EDGE_9_31  1.0
    x_9         EDGE_9_21  1.0
    x_9         EDGE_9_53  1.0
    x_9         EDGE_9_30  1.0
    x_9         EDGE_9_66  1.0
    x_9         EDGE_9_20  1.0
    x_9         EDGE_9_55  1.0
    x_9         EDGE_9_12  1.0
    x_10        OBJ       -1
    x_10        EDGE_10_54  1.0
    x_10        EDGE_10_86  1.0
    x_10        EDGE_4_10  1.0
    x_10        EDGE_10_89  1.0
    x_10        EDGE_10_56  1.0
    x_10        EDGE_10_78  1.0
    x_10        EDGE_10_68  1.0
    x_10        EDGE_10_67  1.0
    x_10        EDGE_10_57  1.0
    x_10        EDGE_10_47  1.0
    x_10        EDGE_2_10  1.0
    x_10        EDGE_10_49  1.0
    x_10        EDGE_3_10  1.0
    x_10        EDGE_10_83  1.0
    x_10        EDGE_10_63  1.0
    x_10        EDGE_10_17  1.0
    x_10        EDGE_10_30  1.0
    x_10        EDGE_10_62  1.0
    x_10        EDGE_10_75  1.0
    x_10        EDGE_10_29  1.0
    x_10        EDGE_10_64  1.0
    x_10        EDGE_10_77  1.0
    x_11        OBJ       -1
    x_11        EDGE_11_69  1.0
    x_11        EDGE_11_36  1.0
    x_11        EDGE_11_49  1.0
    x_11        EDGE_11_26  1.0
    x_11        EDGE_11_71  1.0
    x_11        EDGE_11_25  1.0
    x_11        EDGE_11_61  1.0
    x_11        EDGE_11_38  1.0
    x_11        EDGE_11_15  1.0
    x_11        EDGE_11_70  1.0
    x_11        EDGE_11_83  1.0
    x_11        EDGE_11_73  1.0
    x_11        EDGE_4_11  1.0
    x_11        EDGE_11_17  1.0
    x_11        EDGE_11_82  1.0
    x_11        EDGE_3_11  1.0
    x_11        EDGE_6_11  1.0
    x_11        EDGE_11_62  1.0
    x_11        EDGE_11_39  1.0
    x_11        EDGE_11_42  1.0
    x_11        EDGE_11_84  1.0
    x_11        EDGE_11_74  1.0
    x_11        EDGE_11_64  1.0
    x_11        EDGE_11_54  1.0
    x_11        EDGE_11_21  1.0
    x_11        EDGE_11_66  1.0
    x_11        EDGE_11_33  1.0
    x_11        EDGE_11_55  1.0
    x_11        EDGE_11_32  1.0
    x_11        EDGE_11_35  1.0
    x_11        EDGE_11_12  1.0
    x_11        EDGE_11_44  1.0
    x_11        EDGE_11_80  1.0
    x_11        EDGE_11_57  1.0
    x_11        EDGE_11_47  1.0
    x_12        OBJ       -1
    x_12        EDGE_12_44  1.0
    x_12        EDGE_12_80  1.0
    x_12        EDGE_12_34  1.0
    x_12        EDGE_12_69  1.0
    x_12        EDGE_12_82  1.0
    x_12        EDGE_12_59  1.0
    x_12        EDGE_12_49  1.0
    x_12        EDGE_12_48  1.0
    x_12        EDGE_12_25  1.0
    x_12        EDGE_12_60  1.0
    x_12        EDGE_12_50  1.0
    x_12        EDGE_12_40  1.0
    x_12        EDGE_12_17  1.0
    x_12        EDGE_12_30  1.0
    x_12        EDGE_12_72  1.0
    x_12        EDGE_12_85  1.0
    x_12        EDGE_12_39  1.0
    x_12        EDGE_12_75  1.0
    x_12        EDGE_12_19  1.0
    x_12        EDGE_0_12  1.0
    x_12        EDGE_12_51  1.0
    x_12        EDGE_12_87  1.0
    x_12        EDGE_6_12  1.0
    x_12        EDGE_12_31  1.0
    x_12        EDGE_12_86  1.0
    x_12        EDGE_12_63  1.0
    x_12        EDGE_12_20  1.0
    x_12        EDGE_12_56  1.0
    x_12        EDGE_11_12  1.0
    x_12        EDGE_12_68  1.0
    x_12        EDGE_9_12  1.0
    x_13        OBJ       -1
    x_13        EDGE_13_78  1.0
    x_13        EDGE_13_32  1.0
    x_13        EDGE_13_68  1.0
    x_13        EDGE_13_77  1.0
    x_13        EDGE_13_67  1.0
    x_13        EDGE_13_80  1.0
    x_13        EDGE_13_57  1.0
    x_13        EDGE_9_13  1.0
    x_13        EDGE_13_24  1.0
    x_13        EDGE_13_37  1.0
    x_13        EDGE_13_36  1.0
    x_13        EDGE_13_26  1.0
    x_13        EDGE_13_58  1.0
    x_13        EDGE_13_25  1.0
    x_13        EDGE_13_38  1.0
    x_13        EDGE_13_15  1.0
    x_13        EDGE_13_28  1.0
    x_13        EDGE_4_13  1.0
    x_13        EDGE_13_18  1.0
    x_13        EDGE_7_13  1.0
    x_13        EDGE_13_50  1.0
    x_13        EDGE_13_40  1.0
    x_13        EDGE_13_17  1.0
    x_13        EDGE_13_62  1.0
    x_13        EDGE_13_39  1.0
    x_13        EDGE_13_52  1.0
    x_13        EDGE_13_19  1.0
    x_13        EDGE_13_84  1.0
    x_13        EDGE_13_41  1.0
    x_13        EDGE_13_44  1.0
    x_13        EDGE_1_13  1.0
    x_13        EDGE_13_86  1.0
    x_13        EDGE_13_56  1.0
    x_13        EDGE_13_33  1.0
    x_13        EDGE_13_23  1.0
    x_14        OBJ       -1
    x_14        EDGE_14_24  1.0
    x_14        EDGE_14_79  1.0
    x_14        EDGE_14_46  1.0
    x_14        EDGE_14_82  1.0
    x_14        EDGE_14_49  1.0
    x_14        EDGE_14_26  1.0
    x_14        EDGE_14_81  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_14_73  1.0
    x_14        EDGE_14_27  1.0
    x_14        EDGE_14_40  1.0
    x_14        EDGE_7_14  1.0
    x_14        EDGE_14_72  1.0
    x_14        EDGE_14_62  1.0
    x_14        EDGE_14_39  1.0
    x_14        EDGE_14_52  1.0
    x_14        EDGE_14_74  1.0
    x_14        EDGE_14_54  1.0
    x_14        EDGE_14_31  1.0
    x_14        EDGE_14_86  1.0
    x_14        EDGE_14_56  1.0
    x_14        EDGE_14_33  1.0
    x_14        EDGE_6_14  1.0
    x_14        EDGE_14_35  1.0
    x_14        EDGE_14_25  1.0
    x_14        EDGE_14_80  1.0
    x_14        EDGE_14_34  1.0
    x_14        EDGE_14_47  1.0
    x_15        OBJ       -1
    x_15        EDGE_15_25  1.0
    x_15        EDGE_6_15  1.0
    x_15        EDGE_15_67  1.0
    x_15        EDGE_15_57  1.0
    x_15        EDGE_15_70  1.0
    x_15        EDGE_15_47  1.0
    x_15        EDGE_15_24  1.0
    x_15        EDGE_15_46  1.0
    x_15        EDGE_15_82  1.0
    x_15        EDGE_11_15  1.0
    x_15        EDGE_15_26  1.0
    x_15        EDGE_15_39  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_81  1.0
    x_15        EDGE_1_15  1.0
    x_15        EDGE_15_38  1.0
    x_15        EDGE_15_51  1.0
    x_15        EDGE_15_83  1.0
    x_15        EDGE_13_15  1.0
    x_15        EDGE_15_17  1.0
    x_15        EDGE_15_72  1.0
    x_15        EDGE_15_29  1.0
    x_15        EDGE_15_42  1.0
    x_15        EDGE_15_84  1.0
    x_15        EDGE_15_87  1.0
    x_15        EDGE_15_41  1.0
    x_15        EDGE_15_77  1.0
    x_15        EDGE_8_15  1.0
    x_15        EDGE_15_31  1.0
    x_15        EDGE_15_44  1.0
    x_15        EDGE_15_76  1.0
    x_15        EDGE_15_56  1.0
    x_15        EDGE_15_23  1.0
    x_15        EDGE_15_88  1.0
    x_15        EDGE_5_15  1.0
    x_15        EDGE_15_55  1.0
    x_15        EDGE_15_45  1.0
    x_15        EDGE_15_22  1.0
    x_15        EDGE_15_35  1.0
    x_16        OBJ       -1
    x_16        EDGE_16_83  1.0
    x_16        EDGE_16_73  1.0
    x_16        EDGE_16_50  1.0
    x_16        EDGE_16_27  1.0
    x_16        EDGE_16_17  1.0
    x_16        EDGE_16_62  1.0
    x_16        EDGE_16_52  1.0
    x_16        EDGE_16_42  1.0
    x_16        EDGE_16_19  1.0
    x_16        EDGE_16_51  1.0
    x_16        EDGE_16_64  1.0
    x_16        EDGE_16_18  1.0
    x_16        EDGE_16_23  1.0
    x_16        EDGE_16_78  1.0
    x_16        EDGE_16_68  1.0
    x_16        EDGE_8_16  1.0
    x_16        EDGE_16_67  1.0
    x_16        EDGE_16_34  1.0
    x_16        EDGE_16_46  1.0
    x_16        EDGE_16_26  1.0
    x_16        EDGE_3_16  1.0
    x_16        EDGE_16_48  1.0
    x_16        EDGE_16_25  1.0
    x_16        EDGE_16_61  1.0
    x_16        EDGE_16_38  1.0
    x_17        OBJ       -1
    x_17        EDGE_17_48  1.0
    x_17        EDGE_17_61  1.0
    x_17        EDGE_2_17  1.0
    x_17        EDGE_17_28  1.0
    x_17        EDGE_16_17  1.0
    x_17        EDGE_17_83  1.0
    x_17        EDGE_17_60  1.0
    x_17        EDGE_17_73  1.0
    x_17        EDGE_17_27  1.0
    x_17        EDGE_6_17  1.0
    x_17        EDGE_17_85  1.0
    x_17        EDGE_17_62  1.0
    x_17        EDGE_17_39  1.0
    x_17        EDGE_11_17  1.0
    x_17        EDGE_17_51  1.0
    x_17        EDGE_17_87  1.0
    x_17        EDGE_17_64  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_12_17  1.0
    x_17        EDGE_15_17  1.0
    x_17        EDGE_17_63  1.0
    x_17        EDGE_17_53  1.0
    x_17        EDGE_17_56  1.0
    x_17        EDGE_13_17  1.0
    x_17        EDGE_17_23  1.0
    x_17        EDGE_17_88  1.0
    x_17        EDGE_17_55  1.0
    x_17        EDGE_17_45  1.0
    x_17        EDGE_17_35  1.0
    x_17        EDGE_7_17  1.0
    x_17        EDGE_17_67  1.0
    x_17        EDGE_10_17  1.0
    x_17        EDGE_17_47  1.0
    x_17        EDGE_17_89  1.0
    x_17        EDGE_8_17  1.0
    x_17        EDGE_17_79  1.0
    x_17        EDGE_17_82  1.0
    x_18        OBJ       -1
    x_18        EDGE_18_87  1.0
    x_18        EDGE_18_64  1.0
    x_18        EDGE_18_54  1.0
    x_18        EDGE_18_44  1.0
    x_18        EDGE_16_18  1.0
    x_18        EDGE_18_78  1.0
    x_18        EDGE_18_55  1.0
    x_18        EDGE_13_18  1.0
    x_18        EDGE_18_32  1.0
    x_18        EDGE_18_68  1.0
    x_18        EDGE_18_77  1.0
    x_18        EDGE_18_67  1.0
    x_18        EDGE_18_80  1.0
    x_18        EDGE_18_34  1.0
    x_18        EDGE_18_47  1.0
    x_18        EDGE_18_37  1.0
    x_18        EDGE_9_18  1.0
    x_18        EDGE_18_69  1.0
    x_18        EDGE_18_46  1.0
    x_18        EDGE_18_36  1.0
    x_18        EDGE_18_49  1.0
    x_18        EDGE_18_71  1.0
    x_18        EDGE_18_28  1.0
    x_18        EDGE_18_83  1.0
    x_18        EDGE_18_73  1.0
    x_18        EDGE_18_27  1.0
    x_19        OBJ       -1
    x_19        EDGE_19_60  1.0
    x_19        EDGE_19_27  1.0
    x_19        EDGE_19_63  1.0
    x_19        EDGE_19_72  1.0
    x_19        EDGE_19_62  1.0
    x_19        EDGE_19_75  1.0
    x_19        EDGE_16_19  1.0
    x_19        EDGE_19_84  1.0
    x_19        EDGE_19_74  1.0
    x_19        EDGE_19_64  1.0
    x_19        EDGE_19_54  1.0
    x_19        EDGE_19_31  1.0
    x_19        EDGE_19_76  1.0
    x_19        EDGE_19_43  1.0
    x_19        EDGE_1_19  1.0
    x_19        EDGE_19_45  1.0
    x_19        EDGE_12_19  1.0
    x_19        EDGE_19_35  1.0
    x_19        EDGE_19_57  1.0
    x_19        EDGE_13_19  1.0
    x_19        EDGE_19_47  1.0
    x_19        EDGE_19_82  1.0
    x_19        EDGE_19_59  1.0
    x_19        EDGE_19_71  1.0
    x_19        EDGE_19_48  1.0
    x_19        EDGE_19_38  1.0
    x_19        EDGE_8_19  1.0
    x_20        OBJ       -1
    x_20        EDGE_20_61  1.0
    x_20        EDGE_20_38  1.0
    x_20        EDGE_4_20  1.0
    x_20        EDGE_6_20  1.0
    x_20        EDGE_20_39  1.0
    x_20        EDGE_20_52  1.0
    x_20        EDGE_20_32  1.0
    x_20        EDGE_2_20  1.0
    x_20        EDGE_20_74  1.0
    x_20        EDGE_20_87  1.0
    x_20        EDGE_20_64  1.0
    x_20        EDGE_5_20  1.0
    x_20        EDGE_20_41  1.0
    x_20        EDGE_20_31  1.0
    x_20        EDGE_20_44  1.0
    x_20        EDGE_0_20  1.0
    x_20        EDGE_3_20  1.0
    x_20        EDGE_20_53  1.0
    x_20        EDGE_20_89  1.0
    x_20        EDGE_20_43  1.0
    x_20        EDGE_20_33  1.0
    x_20        EDGE_20_23  1.0
    x_20        EDGE_20_68  1.0
    x_20        EDGE_20_58  1.0
    x_20        EDGE_9_20  1.0
    x_20        EDGE_20_34  1.0
    x_20        EDGE_20_70  1.0
    x_20        EDGE_12_20  1.0
    x_20        EDGE_20_37  1.0
    x_20        EDGE_20_69  1.0
    x_20        EDGE_20_46  1.0
    x_20        EDGE_20_49  1.0
    x_20        EDGE_20_26  1.0
    x_21        OBJ       -1
    x_21        EDGE_21_54  1.0
    x_21        EDGE_21_86  1.0
    x_21        EDGE_21_63  1.0
    x_21        EDGE_21_76  1.0
    x_21        EDGE_21_53  1.0
    x_21        EDGE_21_23  1.0
    x_21        EDGE_21_78  1.0
    x_21        EDGE_21_32  1.0
    x_21        EDGE_2_21  1.0
    x_21        EDGE_21_67  1.0
    x_21        EDGE_21_44  1.0
    x_21        EDGE_0_21  1.0
    x_21        EDGE_21_47  1.0
    x_21        EDGE_21_79  1.0
    x_21        EDGE_21_56  1.0
    x_21        EDGE_21_46  1.0
    x_21        EDGE_21_81  1.0
    x_21        EDGE_11_21  1.0
    x_21        EDGE_21_71  1.0
    x_21        EDGE_9_21  1.0
    x_21        EDGE_1_21  1.0
    x_21        EDGE_21_70  1.0
    x_21        EDGE_21_37  1.0
    x_21        EDGE_21_50  1.0
    x_21        EDGE_21_30  1.0
    x_21        EDGE_21_85  1.0
    x_21        EDGE_21_62  1.0
    x_21        EDGE_21_52  1.0
    x_21        EDGE_21_29  1.0
    x_21        EDGE_21_84  1.0
    x_21        EDGE_4_21  1.0
    x_21        EDGE_21_51  1.0
    x_22        OBJ       -1
    x_22        EDGE_22_60  1.0
    x_22        EDGE_22_73  1.0
    x_22        EDGE_22_85  1.0
    x_22        EDGE_22_75  1.0
    x_22        EDGE_22_65  1.0
    x_22        EDGE_22_74  1.0
    x_22        EDGE_22_87  1.0
    x_22        EDGE_22_77  1.0
    x_22        EDGE_22_31  1.0
    x_22        EDGE_22_78  1.0
    x_22        EDGE_22_68  1.0
    x_22        EDGE_0_22  1.0
    x_22        EDGE_6_22  1.0
    x_22        EDGE_22_80  1.0
    x_22        EDGE_22_57  1.0
    x_22        EDGE_22_70  1.0
    x_22        EDGE_22_24  1.0
    x_22        EDGE_22_37  1.0
    x_22        EDGE_22_27  1.0
    x_22        EDGE_22_79  1.0
    x_22        EDGE_22_59  1.0
    x_22        EDGE_22_72  1.0
    x_22        EDGE_22_26  1.0
    x_22        EDGE_1_22  1.0
    x_22        EDGE_22_84  1.0
    x_22        EDGE_22_61  1.0
    x_22        EDGE_15_22  1.0
    x_23        OBJ       -1
    x_23        EDGE_23_53  1.0
    x_23        EDGE_23_66  1.0
    x_23        EDGE_23_33  1.0
    x_23        EDGE_23_78  1.0
    x_23        EDGE_23_55  1.0
    x_23        EDGE_21_23  1.0
    x_23        EDGE_23_80  1.0
    x_23        EDGE_23_47  1.0
    x_23        EDGE_23_24  1.0
    x_23        EDGE_23_82  1.0
    x_23        EDGE_23_59  1.0
    x_23        EDGE_16_23  1.0
    x_23        EDGE_23_81  1.0
    x_23        EDGE_3_23  1.0
    x_23        EDGE_23_58  1.0
    x_23        EDGE_17_23  1.0
    x_23        EDGE_23_38  1.0
    x_23        EDGE_20_23  1.0
    x_23        EDGE_23_70  1.0
    x_23        EDGE_23_83  1.0
    x_23        EDGE_23_60  1.0
    x_23        EDGE_23_73  1.0
    x_23        EDGE_23_50  1.0
    x_23        EDGE_23_63  1.0
    x_23        EDGE_23_72  1.0
    x_23        EDGE_23_75  1.0
    x_23        EDGE_23_42  1.0
    x_23        EDGE_15_23  1.0
    x_23        EDGE_23_84  1.0
    x_23        EDGE_23_74  1.0
    x_23        EDGE_23_87  1.0
    x_23        EDGE_23_64  1.0
    x_23        EDGE_23_31  1.0
    x_23        EDGE_13_23  1.0
    x_24        OBJ       -1
    x_24        EDGE_14_24  1.0
    x_24        EDGE_24_87  1.0
    x_24        EDGE_24_54  1.0
    x_24        EDGE_1_24  1.0
    x_24        EDGE_15_24  1.0
    x_24        EDGE_24_76  1.0
    x_24        EDGE_24_66  1.0
    x_24        EDGE_13_24  1.0
    x_24        EDGE_24_33  1.0
    x_24        EDGE_24_65  1.0
    x_24        EDGE_24_35  1.0
    x_24        EDGE_23_24  1.0
    x_24        EDGE_4_24  1.0
    x_24        EDGE_24_67  1.0
    x_24        EDGE_24_37  1.0
    x_24        EDGE_24_46  1.0
    x_24        EDGE_24_82  1.0
    x_24        EDGE_24_26  1.0
    x_24        EDGE_24_58  1.0
    x_24        EDGE_24_38  1.0
    x_24        EDGE_24_51  1.0
    x_24        EDGE_0_24  1.0
    x_24        EDGE_22_24  1.0
    x_24        EDGE_24_83  1.0
    x_24        EDGE_24_50  1.0
    x_24        EDGE_24_63  1.0
    x_24        EDGE_24_30  1.0
    x_24        EDGE_24_72  1.0
    x_24        EDGE_24_52  1.0
    x_24        EDGE_24_84  1.0
    x_25        OBJ       -1
    x_25        EDGE_25_34  1.0
    x_25        EDGE_15_25  1.0
    x_25        EDGE_25_56  1.0
    x_25        EDGE_25_36  1.0
    x_25        EDGE_25_68  1.0
    x_25        EDGE_11_25  1.0
    x_25        EDGE_25_58  1.0
    x_25        EDGE_25_71  1.0
    x_25        EDGE_12_25  1.0
    x_25        EDGE_25_73  1.0
    x_25        EDGE_13_25  1.0
    x_25        EDGE_25_85  1.0
    x_25        EDGE_25_39  1.0
    x_25        EDGE_4_25  1.0
    x_25        EDGE_25_84  1.0
    x_25        EDGE_5_25  1.0
    x_25        EDGE_25_74  1.0
    x_25        EDGE_7_25  1.0
    x_25        EDGE_25_54  1.0
    x_25        EDGE_6_25  1.0
    x_25        EDGE_25_43  1.0
    x_25        EDGE_25_88  1.0
    x_25        EDGE_25_78  1.0
    x_25        EDGE_25_45  1.0
    x_25        EDGE_14_25  1.0
    x_25        EDGE_16_25  1.0
    x_25        EDGE_25_77  1.0
    x_25        EDGE_1_25  1.0
    x_25        EDGE_25_44  1.0
    x_25        EDGE_25_57  1.0
    x_26        OBJ       -1
    x_26        EDGE_26_76  1.0
    x_26        EDGE_26_53  1.0
    x_26        EDGE_26_89  1.0
    x_26        EDGE_26_33  1.0
    x_26        EDGE_11_26  1.0
    x_26        EDGE_14_26  1.0
    x_26        EDGE_26_88  1.0
    x_26        EDGE_9_26  1.0
    x_26        EDGE_15_26  1.0
    x_26        EDGE_13_26  1.0
    x_26        EDGE_26_39  1.0
    x_26        EDGE_24_26  1.0
    x_26        EDGE_26_71  1.0
    x_26        EDGE_26_84  1.0
    x_26        EDGE_26_38  1.0
    x_26        EDGE_26_28  1.0
    x_26        EDGE_26_83  1.0
    x_26        EDGE_26_60  1.0
    x_26        EDGE_26_63  1.0
    x_26        EDGE_16_26  1.0
    x_26        EDGE_26_52  1.0
    x_26        EDGE_26_65  1.0
    x_26        EDGE_22_26  1.0
    x_26        EDGE_26_74  1.0
    x_26        EDGE_26_87  1.0
    x_26        EDGE_20_26  1.0
    x_27        OBJ       -1
    x_27        EDGE_2_27  1.0
    x_27        EDGE_5_27  1.0
    x_27        EDGE_16_27  1.0
    x_27        EDGE_19_27  1.0
    x_27        EDGE_27_44  1.0
    x_27        EDGE_6_27  1.0
    x_27        EDGE_17_27  1.0
    x_27        EDGE_27_76  1.0
    x_27        EDGE_27_58  1.0
    x_27        EDGE_14_27  1.0
    x_27        EDGE_27_67  1.0
    x_27        EDGE_27_47  1.0
    x_27        EDGE_27_82  1.0
    x_27        EDGE_27_36  1.0
    x_27        EDGE_27_71  1.0
    x_27        EDGE_27_28  1.0
    x_27        EDGE_7_27  1.0
    x_27        EDGE_22_27  1.0
    x_27        EDGE_27_83  1.0
    x_27        EDGE_8_27  1.0
    x_27        EDGE_27_53  1.0
    x_27        EDGE_27_62  1.0
    x_27        EDGE_27_52  1.0
    x_27        EDGE_18_27  1.0
    x_28        OBJ       -1
    x_28        EDGE_28_80  1.0
    x_28        EDGE_28_57  1.0
    x_28        EDGE_6_28  1.0
    x_28        EDGE_17_28  1.0
    x_28        EDGE_28_46  1.0
    x_28        EDGE_28_49  1.0
    x_28        EDGE_28_48  1.0
    x_28        EDGE_9_28  1.0
    x_28        EDGE_1_28  1.0
    x_28        EDGE_28_50  1.0
    x_28        EDGE_28_63  1.0
    x_28        EDGE_13_28  1.0
    x_28        EDGE_28_72  1.0
    x_28        EDGE_28_62  1.0
    x_28        EDGE_28_39  1.0
    x_28        EDGE_28_75  1.0
    x_28        EDGE_28_29  1.0
    x_28        EDGE_28_42  1.0
    x_28        EDGE_28_84  1.0
    x_28        EDGE_26_28  1.0
    x_28        EDGE_28_87  1.0
    x_28        EDGE_28_41  1.0
    x_28        EDGE_27_28  1.0
    x_28        EDGE_28_86  1.0
    x_28        EDGE_8_28  1.0
    x_28        EDGE_28_53  1.0
    x_28        EDGE_18_28  1.0
    x_28        EDGE_5_28  1.0
    x_29        OBJ       -1
    x_29        EDGE_29_32  1.0
    x_29        EDGE_29_68  1.0
    x_29        EDGE_29_45  1.0
    x_29        EDGE_29_35  1.0
    x_29        EDGE_29_77  1.0
    x_29        EDGE_29_70  1.0
    x_29        EDGE_29_47  1.0
    x_29        EDGE_29_37  1.0
    x_29        EDGE_0_29  1.0
    x_29        EDGE_29_59  1.0
    x_29        EDGE_29_61  1.0
    x_29        EDGE_29_51  1.0
    x_29        EDGE_29_83  1.0
    x_29        EDGE_29_63  1.0
    x_29        EDGE_29_40  1.0
    x_29        EDGE_28_29  1.0
    x_29        EDGE_9_29  1.0
    x_29        EDGE_29_72  1.0
    x_29        EDGE_15_29  1.0
    x_29        EDGE_29_85  1.0
    x_29        EDGE_29_75  1.0
    x_29        EDGE_29_64  1.0
    x_29        EDGE_29_31  1.0
    x_29        EDGE_29_86  1.0
    x_29        EDGE_29_76  1.0
    x_29        EDGE_7_29  1.0
    x_29        EDGE_29_89  1.0
    x_29        EDGE_29_43  1.0
    x_29        EDGE_10_29  1.0
    x_29        EDGE_29_56  1.0
    x_29        EDGE_21_29  1.0
    x_29        EDGE_29_78  1.0
    x_29        EDGE_29_55  1.0
    x_30        OBJ       -1
    x_30        EDGE_2_30  1.0
    x_30        EDGE_30_82  1.0
    x_30        EDGE_30_59  1.0
    x_30        EDGE_30_49  1.0
    x_30        EDGE_30_81  1.0
    x_30        EDGE_30_48  1.0
    x_30        EDGE_30_51  1.0
    x_30        EDGE_30_60  1.0
    x_30        EDGE_30_63  1.0
    x_30        EDGE_30_85  1.0
    x_30        EDGE_0_30  1.0
    x_30        EDGE_1_30  1.0
    x_30        EDGE_30_42  1.0
    x_30        EDGE_12_30  1.0
    x_30        EDGE_30_87  1.0
    x_30        EDGE_30_64  1.0
    x_30        EDGE_30_44  1.0
    x_30        EDGE_30_86  1.0
    x_30        EDGE_30_53  1.0
    x_30        EDGE_7_30  1.0
    x_30        EDGE_9_30  1.0
    x_30        EDGE_10_30  1.0
    x_30        EDGE_30_65  1.0
    x_30        EDGE_21_30  1.0
    x_30        EDGE_24_30  1.0
    x_30        EDGE_30_45  1.0
    x_30        EDGE_30_35  1.0
    x_30        EDGE_30_70  1.0
    x_30        EDGE_30_37  1.0
    x_31        OBJ       -1
    x_31        EDGE_31_67  1.0
    x_31        EDGE_31_80  1.0
    x_31        EDGE_31_47  1.0
    x_31        EDGE_8_31  1.0
    x_31        EDGE_31_79  1.0
    x_31        EDGE_31_69  1.0
    x_31        EDGE_31_84  1.0
    x_31        EDGE_31_61  1.0
    x_31        EDGE_19_31  1.0
    x_31        EDGE_0_31  1.0
    x_31        EDGE_22_31  1.0
    x_31        EDGE_3_31  1.0
    x_31        EDGE_20_31  1.0
    x_31        EDGE_31_62  1.0
    x_31        EDGE_31_42  1.0
    x_31        EDGE_14_31  1.0
    x_31        EDGE_31_74  1.0
    x_31        EDGE_31_64  1.0
    x_31        EDGE_31_77  1.0
    x_31        EDGE_9_31  1.0
    x_31        EDGE_1_31  1.0
    x_31        EDGE_12_31  1.0
    x_31        EDGE_15_31  1.0
    x_31        EDGE_31_86  1.0
    x_31        EDGE_29_31  1.0
    x_31        EDGE_31_89  1.0
    x_31        EDGE_31_66  1.0
    x_31        EDGE_31_33  1.0
    x_31        EDGE_31_55  1.0
    x_31        EDGE_31_68  1.0
    x_31        EDGE_23_31  1.0
    x_32        OBJ       -1
    x_32        EDGE_29_32  1.0
    x_32        EDGE_32_78  1.0
    x_32        EDGE_13_32  1.0
    x_32        EDGE_32_45  1.0
    x_32        EDGE_32_67  1.0
    x_32        EDGE_32_79  1.0
    x_32        EDGE_32_69  1.0
    x_32        EDGE_21_32  1.0
    x_32        EDGE_20_32  1.0
    x_32        EDGE_32_38  1.0
    x_32        EDGE_18_32  1.0
    x_32        EDGE_2_32  1.0
    x_32        EDGE_32_60  1.0
    x_32        EDGE_32_63  1.0
    x_32        EDGE_0_32  1.0
    x_32        EDGE_1_32  1.0
    x_32        EDGE_32_75  1.0
    x_32        EDGE_32_52  1.0
    x_32        EDGE_32_74  1.0
    x_32        EDGE_32_41  1.0
    x_32        EDGE_11_32  1.0
    x_32        EDGE_32_86  1.0
    x_32        EDGE_32_76  1.0
    x_32        EDGE_32_43  1.0
    x_32        EDGE_32_88  1.0
    x_33        OBJ       -1
    x_33        EDGE_33_70  1.0
    x_33        EDGE_23_33  1.0
    x_33        EDGE_4_33  1.0
    x_33        EDGE_26_33  1.0
    x_33        EDGE_33_63  1.0
    x_33        EDGE_33_40  1.0
    x_33        EDGE_24_33  1.0
    x_33        EDGE_33_72  1.0
    x_33        EDGE_33_74  1.0
    x_33        EDGE_33_64  1.0
    x_33        EDGE_2_33  1.0
    x_33        EDGE_33_86  1.0
    x_33        EDGE_33_76  1.0
    x_33        EDGE_33_56  1.0
    x_33        EDGE_3_33  1.0
    x_33        EDGE_20_33  1.0
    x_33        EDGE_33_68  1.0
    x_33        EDGE_33_80  1.0
    x_33        EDGE_11_33  1.0
    x_33        EDGE_14_33  1.0
    x_33        EDGE_31_33  1.0
    x_33        EDGE_33_69  1.0
    x_33        EDGE_33_82  1.0
    x_33        EDGE_33_59  1.0
    x_33        EDGE_33_36  1.0
    x_33        EDGE_13_33  1.0
    x_33        EDGE_33_48  1.0
    x_34        OBJ       -1
    x_34        EDGE_25_34  1.0
    x_34        EDGE_9_34  1.0
    x_34        EDGE_34_81  1.0
    x_34        EDGE_12_34  1.0
    x_34        EDGE_34_71  1.0
    x_34        EDGE_34_48  1.0
    x_34        EDGE_34_38  1.0
    x_34        EDGE_34_51  1.0
    x_34        EDGE_34_60  1.0
    x_34        EDGE_34_40  1.0
    x_34        EDGE_34_39  1.0
    x_34        EDGE_34_42  1.0
    x_34        EDGE_34_84  1.0
    x_34        EDGE_34_87  1.0
    x_34        EDGE_8_34  1.0
    x_34        EDGE_34_64  1.0
    x_34        EDGE_34_44  1.0
    x_34        EDGE_34_76  1.0
    x_34        EDGE_34_89  1.0
    x_34        EDGE_18_34  1.0
    x_34        EDGE_34_56  1.0
    x_34        EDGE_16_34  1.0
    x_34        EDGE_34_65  1.0
    x_34        EDGE_34_78  1.0
    x_34        EDGE_34_45  1.0
    x_34        EDGE_6_34  1.0
    x_34        EDGE_20_34  1.0
    x_34        EDGE_34_57  1.0
    x_34        EDGE_34_70  1.0
    x_34        EDGE_34_79  1.0
    x_34        EDGE_34_46  1.0
    x_34        EDGE_34_59  1.0
    x_34        EDGE_14_34  1.0
    x_34        EDGE_34_49  1.0
    x_35        OBJ       -1
    x_35        EDGE_35_83  1.0
    x_35        EDGE_35_73  1.0
    x_35        EDGE_29_35  1.0
    x_35        EDGE_35_50  1.0
    x_35        EDGE_35_40  1.0
    x_35        EDGE_35_72  1.0
    x_35        EDGE_35_85  1.0
    x_35        EDGE_35_52  1.0
    x_35        EDGE_7_35  1.0
    x_35        EDGE_24_35  1.0
    x_35        EDGE_35_66  1.0
    x_35        EDGE_35_56  1.0
    x_35        EDGE_35_45  1.0
    x_35        EDGE_19_35  1.0
    x_35        EDGE_35_80  1.0
    x_35        EDGE_35_57  1.0
    x_35        EDGE_35_70  1.0
    x_35        EDGE_17_35  1.0
    x_35        EDGE_35_46  1.0
    x_35        EDGE_35_59  1.0
    x_35        EDGE_35_36  1.0
    x_35        EDGE_30_35  1.0
    x_35        EDGE_11_35  1.0
    x_35        EDGE_14_35  1.0
    x_35        EDGE_35_71  1.0
    x_35        EDGE_35_48  1.0
    x_35        EDGE_35_38  1.0
    x_35        EDGE_35_51  1.0
    x_35        EDGE_1_35  1.0
    x_35        EDGE_15_35  1.0
    x_36        OBJ       -1
    x_36        EDGE_36_71  1.0
    x_36        EDGE_36_84  1.0
    x_36        EDGE_11_36  1.0
    x_36        EDGE_36_83  1.0
    x_36        EDGE_36_60  1.0
    x_36        EDGE_25_36  1.0
    x_36        EDGE_9_36  1.0
    x_36        EDGE_1_36  1.0
    x_36        EDGE_36_72  1.0
    x_36        EDGE_36_52  1.0
    x_36        EDGE_36_65  1.0
    x_36        EDGE_13_36  1.0
    x_36        EDGE_36_87  1.0
    x_36        EDGE_36_41  1.0
    x_36        EDGE_36_76  1.0
    x_36        EDGE_36_89  1.0
    x_36        EDGE_36_66  1.0
    x_36        EDGE_27_36  1.0
    x_36        EDGE_36_78  1.0
    x_36        EDGE_36_55  1.0
    x_36        EDGE_36_45  1.0
    x_36        EDGE_18_36  1.0
    x_36        EDGE_36_80  1.0
    x_36        EDGE_2_36  1.0
    x_36        EDGE_5_36  1.0
    x_36        EDGE_35_36  1.0
    x_36        EDGE_36_37  1.0
    x_36        EDGE_0_36  1.0
    x_36        EDGE_36_79  1.0
    x_36        EDGE_3_36  1.0
    x_36        EDGE_33_36  1.0
    x_36        EDGE_36_59  1.0
    x_36        EDGE_6_36  1.0
    x_36        EDGE_36_39  1.0
    x_37        OBJ       -1
    x_37        EDGE_1_37  1.0
    x_37        EDGE_37_66  1.0
    x_37        EDGE_29_37  1.0
    x_37        EDGE_13_37  1.0
    x_37        EDGE_37_65  1.0
    x_37        EDGE_37_78  1.0
    x_37        EDGE_37_55  1.0
    x_37        EDGE_37_77  1.0
    x_37        EDGE_37_47  1.0
    x_37        EDGE_37_89  1.0
    x_37        EDGE_24_37  1.0
    x_37        EDGE_37_46  1.0
    x_37        EDGE_37_59  1.0
    x_37        EDGE_37_49  1.0
    x_37        EDGE_37_61  1.0
    x_37        EDGE_37_38  1.0
    x_37        EDGE_18_37  1.0
    x_37        EDGE_37_70  1.0
    x_37        EDGE_37_83  1.0
    x_37        EDGE_21_37  1.0
    x_37        EDGE_22_37  1.0
    x_37        EDGE_6_37  1.0
    x_37        EDGE_36_37  1.0
    x_37        EDGE_20_37  1.0
    x_37        EDGE_37_39  1.0
    x_37        EDGE_37_52  1.0
    x_37        EDGE_37_84  1.0
    x_37        EDGE_30_37  1.0
    x_38        OBJ       -1
    x_38        EDGE_6_38  1.0
    x_38        EDGE_38_84  1.0
    x_38        EDGE_38_51  1.0
    x_38        EDGE_20_38  1.0
    x_38        EDGE_38_41  1.0
    x_38        EDGE_38_54  1.0
    x_38        EDGE_34_38  1.0
    x_38        EDGE_38_86  1.0
    x_38        EDGE_38_56  1.0
    x_38        EDGE_11_38  1.0
    x_38        EDGE_38_55  1.0
    x_38        EDGE_38_68  1.0
    x_38        EDGE_15_38  1.0
    x_38        EDGE_38_77  1.0
    x_38        EDGE_32_38  1.0
    x_38        EDGE_13_38  1.0
    x_38        EDGE_38_67  1.0
    x_38        EDGE_38_44  1.0
    x_38        EDGE_38_57  1.0
    x_38        EDGE_38_82  1.0
    x_38        EDGE_23_38  1.0
    x_38        EDGE_4_38  1.0
    x_38        EDGE_26_38  1.0
    x_38        EDGE_37_38  1.0
    x_38        EDGE_24_38  1.0
    x_38        EDGE_38_71  1.0
    x_38        EDGE_8_38  1.0
    x_38        EDGE_38_50  1.0
    x_38        EDGE_38_40  1.0
    x_38        EDGE_35_38  1.0
    x_38        EDGE_16_38  1.0
    x_38        EDGE_38_62  1.0
    x_38        EDGE_38_39  1.0
    x_38        EDGE_38_75  1.0
    x_38        EDGE_38_52  1.0
    x_38        EDGE_19_38  1.0
    x_39        OBJ       -1
    x_39        EDGE_39_83  1.0
    x_39        EDGE_39_50  1.0
    x_39        EDGE_39_86  1.0
    x_39        EDGE_15_39  1.0
    x_39        EDGE_17_39  1.0
    x_39        EDGE_39_62  1.0
    x_39        EDGE_39_75  1.0
    x_39        EDGE_20_39  1.0
    x_39        EDGE_34_39  1.0
    x_39        EDGE_39_54  1.0
    x_39        EDGE_11_39  1.0
    x_39        EDGE_14_39  1.0
    x_39        EDGE_25_39  1.0
    x_39        EDGE_26_39  1.0
    x_39        EDGE_28_39  1.0
    x_39        EDGE_39_89  1.0
    x_39        EDGE_12_39  1.0
    x_39        EDGE_39_88  1.0
    x_39        EDGE_39_78  1.0
    x_39        EDGE_39_55  1.0
    x_39        EDGE_13_39  1.0
    x_39        EDGE_39_58  1.0
    x_39        EDGE_39_60  1.0
    x_39        EDGE_5_39  1.0
    x_39        EDGE_37_39  1.0
    x_39        EDGE_39_82  1.0
    x_39        EDGE_39_59  1.0
    x_39        EDGE_6_39  1.0
    x_39        EDGE_36_39  1.0
    x_39        EDGE_38_39  1.0
    x_40        OBJ       -1
    x_40        EDGE_2_40  1.0
    x_40        EDGE_35_40  1.0
    x_40        EDGE_40_86  1.0
    x_40        EDGE_40_53  1.0
    x_40        EDGE_40_89  1.0
    x_40        EDGE_40_43  1.0
    x_40        EDGE_33_40  1.0
    x_40        EDGE_6_40  1.0
    x_40        EDGE_40_65  1.0
    x_40        EDGE_40_78  1.0
    x_40        EDGE_34_40  1.0
    x_40        EDGE_40_55  1.0
    x_40        EDGE_40_68  1.0
    x_40        EDGE_14_40  1.0
    x_40        EDGE_40_70  1.0
    x_40        EDGE_12_40  1.0
    x_40        EDGE_29_40  1.0
    x_40        EDGE_13_40  1.0
    x_40        EDGE_40_81  1.0
    x_40        EDGE_40_71  1.0
    x_40        EDGE_4_40  1.0
    x_40        EDGE_40_83  1.0
    x_40        EDGE_40_60  1.0
    x_40        EDGE_40_73  1.0
    x_40        EDGE_40_72  1.0
    x_40        EDGE_38_40  1.0
    x_40        EDGE_40_85  1.0
    x_40        EDGE_40_62  1.0
    x_40        EDGE_40_75  1.0
    x_40        EDGE_40_42  1.0
    x_41        OBJ       -1
    x_41        EDGE_41_42  1.0
    x_41        EDGE_38_41  1.0
    x_41        EDGE_41_87  1.0
    x_41        EDGE_41_64  1.0
    x_41        EDGE_41_54  1.0
    x_41        EDGE_41_86  1.0
    x_41        EDGE_41_76  1.0
    x_41        EDGE_41_53  1.0
    x_41        EDGE_41_43  1.0
    x_41        EDGE_5_41  1.0
    x_41        EDGE_41_55  1.0
    x_41        EDGE_6_41  1.0
    x_41        EDGE_36_41  1.0
    x_41        EDGE_20_41  1.0
    x_41        EDGE_41_57  1.0
    x_41        EDGE_41_47  1.0
    x_41        EDGE_41_46  1.0
    x_41        EDGE_28_41  1.0
    x_41        EDGE_9_41  1.0
    x_41        EDGE_15_41  1.0
    x_41        EDGE_41_84  1.0
    x_41        EDGE_41_61  1.0
    x_41        EDGE_32_41  1.0
    x_41        EDGE_13_41  1.0
    x_41        EDGE_41_73  1.0
    x_41        EDGE_41_50  1.0
    x_41        EDGE_41_62  1.0
    x_41        EDGE_7_41  1.0
    x_42        OBJ       -1
    x_42        EDGE_41_42  1.0
    x_42        EDGE_42_77  1.0
    x_42        EDGE_42_67  1.0
    x_42        EDGE_42_57  1.0
    x_42        EDGE_42_79  1.0
    x_42        EDGE_2_42  1.0
    x_42        EDGE_5_42  1.0
    x_42        EDGE_42_59  1.0
    x_42        EDGE_16_42  1.0
    x_42        EDGE_42_58  1.0
    x_42        EDGE_42_71  1.0
    x_42        EDGE_42_48  1.0
    x_42        EDGE_34_42  1.0
    x_42        EDGE_42_60  1.0
    x_42        EDGE_42_50  1.0
    x_42        EDGE_30_42  1.0
    x_42        EDGE_11_42  1.0
    x_42        EDGE_42_82  1.0
    x_42        EDGE_42_85  1.0
    x_42        EDGE_28_42  1.0
    x_42        EDGE_42_62  1.0
    x_42        EDGE_42_75  1.0
    x_42        EDGE_31_42  1.0
    x_42        EDGE_15_42  1.0
    x_42        EDGE_42_84  1.0
    x_42        EDGE_42_87  1.0
    x_42        EDGE_42_64  1.0
    x_42        EDGE_23_42  1.0
    x_42        EDGE_40_42  1.0
    x_42        EDGE_42_78  1.0
    x_43        OBJ       -1
    x_43        EDGE_43_64  1.0
    x_43        EDGE_7_43  1.0
    x_43        EDGE_40_43  1.0
    x_43        EDGE_43_89  1.0
    x_43        EDGE_43_79  1.0
    x_43        EDGE_41_43  1.0
    x_43        EDGE_43_88  1.0
    x_43        EDGE_43_55  1.0
    x_43        EDGE_2_43  1.0
    x_43        EDGE_43_57  1.0
    x_43        EDGE_19_43  1.0
    x_43        EDGE_20_43  1.0
    x_43        EDGE_43_71  1.0
    x_43        EDGE_43_84  1.0
    x_43        EDGE_43_61  1.0
    x_43        EDGE_25_43  1.0
    x_43        EDGE_43_60  1.0
    x_43        EDGE_43_63  1.0
    x_43        EDGE_29_43  1.0
    x_43        EDGE_43_62  1.0
    x_43        EDGE_32_43  1.0
    x_43        EDGE_43_52  1.0
    x_43        EDGE_43_74  1.0
    x_44        OBJ       -1
    x_44        EDGE_12_44  1.0
    x_44        EDGE_44_79  1.0
    x_44        EDGE_27_44  1.0
    x_44        EDGE_44_69  1.0
    x_44        EDGE_44_46  1.0
    x_44        EDGE_44_49  1.0
    x_44        EDGE_18_44  1.0
    x_44        EDGE_5_44  1.0
    x_44        EDGE_7_44  1.0
    x_44        EDGE_21_44  1.0
    x_44        EDGE_38_44  1.0
    x_44        EDGE_20_44  1.0
    x_44        EDGE_44_72  1.0
    x_44        EDGE_34_44  1.0
    x_44        EDGE_44_87  1.0
    x_44        EDGE_30_44  1.0
    x_44        EDGE_44_89  1.0
    x_44        EDGE_44_66  1.0
    x_44        EDGE_15_44  1.0
    x_44        EDGE_13_44  1.0
    x_44        EDGE_44_55  1.0
    x_44        EDGE_44_68  1.0
    x_44        EDGE_11_44  1.0
    x_44        EDGE_44_77  1.0
    x_44        EDGE_25_44  1.0
    x_45        OBJ       -1
    x_45        EDGE_29_45  1.0
    x_45        EDGE_32_45  1.0
    x_45        EDGE_45_80  1.0
    x_45        EDGE_45_70  1.0
    x_45        EDGE_45_47  1.0
    x_45        EDGE_45_79  1.0
    x_45        EDGE_45_49  1.0
    x_45        EDGE_8_45  1.0
    x_45        EDGE_45_48  1.0
    x_45        EDGE_45_51  1.0
    x_45        EDGE_45_73  1.0
    x_45        EDGE_45_50  1.0
    x_45        EDGE_5_45  1.0
    x_45        EDGE_35_45  1.0
    x_45        EDGE_45_85  1.0
    x_45        EDGE_19_45  1.0
    x_45        EDGE_3_45  1.0
    x_45        EDGE_36_45  1.0
    x_45        EDGE_17_45  1.0
    x_45        EDGE_34_45  1.0
    x_45        EDGE_45_54  1.0
    x_45        EDGE_45_53  1.0
    x_45        EDGE_30_45  1.0
    x_45        EDGE_25_45  1.0
    x_45        EDGE_45_88  1.0
    x_45        EDGE_45_78  1.0
    x_45        EDGE_15_45  1.0
    x_46        OBJ       -1
    x_46        EDGE_46_88  1.0
    x_46        EDGE_46_68  1.0
    x_46        EDGE_14_46  1.0
    x_46        EDGE_44_46  1.0
    x_46        EDGE_28_46  1.0
    x_46        EDGE_15_46  1.0
    x_46        EDGE_46_69  1.0
    x_46        EDGE_46_82  1.0
    x_46        EDGE_4_46  1.0
    x_46        EDGE_7_46  1.0
    x_46        EDGE_37_46  1.0
    x_46        EDGE_21_46  1.0
    x_46        EDGE_24_46  1.0
    x_46        EDGE_8_46  1.0
    x_46        EDGE_46_50  1.0
    x_46        EDGE_41_46  1.0
    x_46        EDGE_46_72  1.0
    x_46        EDGE_46_75  1.0
    x_46        EDGE_18_46  1.0
    x_46        EDGE_2_46  1.0
    x_46        EDGE_5_46  1.0
    x_46        EDGE_35_46  1.0
    x_46        EDGE_16_46  1.0
    x_46        EDGE_46_87  1.0
    x_46        EDGE_46_64  1.0
    x_46        EDGE_46_77  1.0
    x_46        EDGE_0_46  1.0
    x_46        EDGE_1_46  1.0
    x_46        EDGE_46_54  1.0
    x_46        EDGE_20_46  1.0
    x_46        EDGE_34_46  1.0
    x_46        EDGE_46_56  1.0
    x_47        OBJ       -1
    x_47        EDGE_47_57  1.0
    x_47        EDGE_31_47  1.0
    x_47        EDGE_15_47  1.0
    x_47        EDGE_45_47  1.0
    x_47        EDGE_47_82  1.0
    x_47        EDGE_47_59  1.0
    x_47        EDGE_29_47  1.0
    x_47        EDGE_47_72  1.0
    x_47        EDGE_47_49  1.0
    x_47        EDGE_47_71  1.0
    x_47        EDGE_23_47  1.0
    x_47        EDGE_37_47  1.0
    x_47        EDGE_10_47  1.0
    x_47        EDGE_21_47  1.0
    x_47        EDGE_27_47  1.0
    x_47        EDGE_41_47  1.0
    x_47        EDGE_47_65  1.0
    x_47        EDGE_18_47  1.0
    x_47        EDGE_47_87  1.0
    x_47        EDGE_47_54  1.0
    x_47        EDGE_5_47  1.0
    x_47        EDGE_19_47  1.0
    x_47        EDGE_47_66  1.0
    x_47        EDGE_17_47  1.0
    x_47        EDGE_47_78  1.0
    x_47        EDGE_47_55  1.0
    x_47        EDGE_47_68  1.0
    x_47        EDGE_47_58  1.0
    x_47        EDGE_11_47  1.0
    x_47        EDGE_14_47  1.0
    x_48        OBJ       -1
    x_48        EDGE_48_58  1.0
    x_48        EDGE_17_48  1.0
    x_48        EDGE_34_48  1.0
    x_48        EDGE_30_48  1.0
    x_48        EDGE_48_69  1.0
    x_48        EDGE_48_82  1.0
    x_48        EDGE_28_48  1.0
    x_48        EDGE_1_48  1.0
    x_48        EDGE_12_48  1.0
    x_48        EDGE_42_48  1.0
    x_48        EDGE_45_48  1.0
    x_48        EDGE_48_51  1.0
    x_48        EDGE_48_60  1.0
    x_48        EDGE_48_50  1.0
    x_48        EDGE_48_63  1.0
    x_48        EDGE_8_48  1.0
    x_48        EDGE_48_64  1.0
    x_48        EDGE_48_54  1.0
    x_48        EDGE_48_86  1.0
    x_48        EDGE_2_48  1.0
    x_48        EDGE_35_48  1.0
    x_48        EDGE_16_48  1.0
    x_48        EDGE_19_48  1.0
    x_48        EDGE_33_48  1.0
    x_48        EDGE_48_68  1.0
    x_49        OBJ       -1
    x_49        EDGE_49_50  1.0
    x_49        EDGE_30_49  1.0
    x_49        EDGE_11_49  1.0
    x_49        EDGE_14_49  1.0
    x_49        EDGE_44_49  1.0
    x_49        EDGE_47_49  1.0
    x_49        EDGE_28_49  1.0
    x_49        EDGE_1_49  1.0
    x_49        EDGE_49_75  1.0
    x_49        EDGE_12_49  1.0
    x_49        EDGE_45_49  1.0
    x_49        EDGE_49_84  1.0
    x_49        EDGE_49_74  1.0
    x_49        EDGE_49_51  1.0
    x_49        EDGE_49_54  1.0
    x_49        EDGE_49_76  1.0
    x_49        EDGE_49_56  1.0
    x_49        EDGE_7_49  1.0
    x_49        EDGE_37_49  1.0
    x_49        EDGE_10_49  1.0
    x_49        EDGE_49_65  1.0
    x_49        EDGE_49_78  1.0
    x_49        EDGE_8_49  1.0
    x_49        EDGE_49_77  1.0
    x_49        EDGE_49_67  1.0
    x_49        EDGE_49_80  1.0
    x_49        EDGE_18_49  1.0
    x_49        EDGE_49_79  1.0
    x_49        EDGE_5_49  1.0
    x_49        EDGE_49_69  1.0
    x_49        EDGE_49_82  1.0
    x_49        EDGE_49_59  1.0
    x_49        EDGE_6_49  1.0
    x_49        EDGE_20_49  1.0
    x_49        EDGE_34_49  1.0
    x_50        OBJ       -1
    x_50        EDGE_5_50  1.0
    x_50        EDGE_35_50  1.0
    x_50        EDGE_50_71  1.0
    x_50        EDGE_16_50  1.0
    x_50        EDGE_50_61  1.0
    x_50        EDGE_49_50  1.0
    x_50        EDGE_3_50  1.0
    x_50        EDGE_6_50  1.0
    x_50        EDGE_39_50  1.0
    x_50        EDGE_50_63  1.0
    x_50        EDGE_50_75  1.0
    x_50        EDGE_50_52  1.0
    x_50        EDGE_28_50  1.0
    x_50        EDGE_50_74  1.0
    x_50        EDGE_50_64  1.0
    x_50        EDGE_50_77  1.0
    x_50        EDGE_12_50  1.0
    x_50        EDGE_42_50  1.0
    x_50        EDGE_45_50  1.0
    x_50        EDGE_48_50  1.0
    x_50        EDGE_50_76  1.0
    x_50        EDGE_13_50  1.0
    x_50        EDGE_50_89  1.0
    x_50        EDGE_50_66  1.0
    x_50        EDGE_46_50  1.0
    x_50        EDGE_50_56  1.0
    x_50        EDGE_50_88  1.0
    x_50        EDGE_50_78  1.0
    x_50        EDGE_23_50  1.0
    x_50        EDGE_7_50  1.0
    x_50        EDGE_21_50  1.0
    x_50        EDGE_24_50  1.0
    x_50        EDGE_50_80  1.0
    x_50        EDGE_50_57  1.0
    x_50        EDGE_50_70  1.0
    x_50        EDGE_8_50  1.0
    x_50        EDGE_38_50  1.0
    x_50        EDGE_41_50  1.0
    x_50        EDGE_50_82  1.0
    x_50        EDGE_50_59  1.0
    x_51        OBJ       -1
    x_51        EDGE_51_68  1.0
    x_51        EDGE_51_81  1.0
    x_51        EDGE_38_51  1.0
    x_51        EDGE_34_51  1.0
    x_51        EDGE_51_57  1.0
    x_51        EDGE_51_60  1.0
    x_51        EDGE_30_51  1.0
    x_51        EDGE_16_51  1.0
    x_51        EDGE_49_51  1.0
    x_51        EDGE_15_51  1.0
    x_51        EDGE_45_51  1.0
    x_51        EDGE_17_51  1.0
    x_51        EDGE_48_51  1.0
    x_51        EDGE_29_51  1.0
    x_51        EDGE_51_74  1.0
    x_51        EDGE_51_83  1.0
    x_51        EDGE_51_53  1.0
    x_51        EDGE_51_85  1.0
    x_51        EDGE_12_51  1.0
    x_51        EDGE_24_51  1.0
    x_51        EDGE_51_64  1.0
    x_51        EDGE_51_77  1.0
    x_51        EDGE_51_67  1.0
    x_51        EDGE_51_76  1.0
    x_51        EDGE_51_66  1.0
    x_51        EDGE_5_51  1.0
    x_51        EDGE_35_51  1.0
    x_51        EDGE_21_51  1.0
    x_51        EDGE_51_78  1.0
    x_52        OBJ       -1
    x_52        EDGE_5_52  1.0
    x_52        EDGE_35_52  1.0
    x_52        EDGE_16_52  1.0
    x_52        EDGE_52_85  1.0
    x_52        EDGE_52_62  1.0
    x_52        EDGE_52_75  1.0
    x_52        EDGE_36_52  1.0
    x_52        EDGE_20_52  1.0
    x_52        EDGE_50_52  1.0
    x_52        EDGE_52_74  1.0
    x_52        EDGE_52_87  1.0
    x_52        EDGE_52_77  1.0
    x_52        EDGE_52_89  1.0
    x_52        EDGE_14_52  1.0
    x_52        EDGE_1_52  1.0
    x_52        EDGE_32_52  1.0
    x_52        EDGE_13_52  1.0
    x_52        EDGE_52_67  1.0
    x_52        EDGE_52_80  1.0
    x_52        EDGE_52_79  1.0
    x_52        EDGE_26_52  1.0
    x_52        EDGE_52_59  1.0
    x_52        EDGE_37_52  1.0
    x_52        EDGE_52_72  1.0
    x_52        EDGE_21_52  1.0
    x_52        EDGE_43_52  1.0
    x_52        EDGE_24_52  1.0
    x_52        EDGE_27_52  1.0
    x_52        EDGE_38_52  1.0
    x_52        EDGE_52_71  1.0
    x_53        OBJ       -1
    x_53        EDGE_23_53  1.0
    x_53        EDGE_4_53  1.0
    x_53        EDGE_26_53  1.0
    x_53        EDGE_7_53  1.0
    x_53        EDGE_53_61  1.0
    x_53        EDGE_40_53  1.0
    x_53        EDGE_21_53  1.0
    x_53        EDGE_53_73  1.0
    x_53        EDGE_41_53  1.0
    x_53        EDGE_53_85  1.0
    x_53        EDGE_53_62  1.0
    x_53        EDGE_53_87  1.0
    x_53        EDGE_53_64  1.0
    x_53        EDGE_53_77  1.0
    x_53        EDGE_53_54  1.0
    x_53        EDGE_6_53  1.0
    x_53        EDGE_17_53  1.0
    x_53        EDGE_20_53  1.0
    x_53        EDGE_51_53  1.0
    x_53        EDGE_53_88  1.0
    x_53        EDGE_30_53  1.0
    x_53        EDGE_53_55  1.0
    x_53        EDGE_53_58  1.0
    x_53        EDGE_28_53  1.0
    x_53        EDGE_9_53  1.0
    x_53        EDGE_53_57  1.0
    x_53        EDGE_45_53  1.0
    x_53        EDGE_27_53  1.0
    x_53        EDGE_53_69  1.0
    x_53        EDGE_53_82  1.0
    x_54        OBJ       -1
    x_54        EDGE_10_54  1.0
    x_54        EDGE_54_74  1.0
    x_54        EDGE_21_54  1.0
    x_54        EDGE_54_87  1.0
    x_54        EDGE_24_54  1.0
    x_54        EDGE_38_54  1.0
    x_54        EDGE_41_54  1.0
    x_54        EDGE_54_76  1.0
    x_54        EDGE_54_66  1.0
    x_54        EDGE_18_54  1.0
    x_54        EDGE_54_88  1.0
    x_54        EDGE_2_54  1.0
    x_54        EDGE_5_54  1.0
    x_54        EDGE_19_54  1.0
    x_54        EDGE_49_54  1.0
    x_54        EDGE_54_80  1.0
    x_54        EDGE_54_57  1.0
    x_54        EDGE_39_54  1.0
    x_54        EDGE_53_54  1.0
    x_54        EDGE_54_82  1.0
    x_54        EDGE_11_54  1.0
    x_54        EDGE_14_54  1.0
    x_54        EDGE_54_81  1.0
    x_54        EDGE_25_54  1.0
    x_54        EDGE_47_54  1.0
    x_54        EDGE_45_54  1.0
    x_54        EDGE_48_54  1.0
    x_54        EDGE_54_83  1.0
    x_54        EDGE_54_63  1.0
    x_54        EDGE_46_54  1.0
    x_54        EDGE_54_72  1.0
    x_54        EDGE_54_75  1.0
    x_54        EDGE_4_54  1.0
    x_55        OBJ       -1
    x_55        EDGE_55_63  1.0
    x_55        EDGE_23_55  1.0
    x_55        EDGE_37_55  1.0
    x_55        EDGE_55_62  1.0
    x_55        EDGE_40_55  1.0
    x_55        EDGE_43_55  1.0
    x_55        EDGE_55_65  1.0
    x_55        EDGE_8_55  1.0
    x_55        EDGE_38_55  1.0
    x_55        EDGE_41_55  1.0
    x_55        EDGE_18_55  1.0
    x_55        EDGE_2_55  1.0
    x_55        EDGE_55_66  1.0
    x_55        EDGE_55_79  1.0
    x_55        EDGE_55_56  1.0
    x_55        EDGE_55_88  1.0
    x_55        EDGE_55_78  1.0
    x_55        EDGE_6_55  1.0
    x_55        EDGE_36_55  1.0
    x_55        EDGE_55_68  1.0
    x_55        EDGE_17_55  1.0
    x_55        EDGE_39_55  1.0
    x_55        EDGE_53_55  1.0
    x_55        EDGE_55_80  1.0
    x_55        EDGE_11_55  1.0
    x_55        EDGE_44_55  1.0
    x_55        EDGE_55_69  1.0
    x_55        EDGE_55_59  1.0
    x_55        EDGE_47_55  1.0
    x_55        EDGE_9_55  1.0
    x_55        EDGE_31_55  1.0
    x_55        EDGE_15_55  1.0
    x_55        EDGE_55_81  1.0
    x_55        EDGE_29_55  1.0
    x_56        OBJ       -1
    x_56        EDGE_56_89  1.0
    x_56        EDGE_25_56  1.0
    x_56        EDGE_10_56  1.0
    x_56        EDGE_56_78  1.0
    x_56        EDGE_56_68  1.0
    x_56        EDGE_38_56  1.0
    x_56        EDGE_56_80  1.0
    x_56        EDGE_56_57  1.0
    x_56        EDGE_2_56  1.0
    x_56        EDGE_4_56  1.0
    x_56        EDGE_35_56  1.0
    x_56        EDGE_49_56  1.0
    x_56        EDGE_21_56  1.0
    x_56        EDGE_3_56  1.0
    x_56        EDGE_33_56  1.0
    x_56        EDGE_55_56  1.0
    x_56        EDGE_17_56  1.0
    x_56        EDGE_50_56  1.0
    x_56        EDGE_56_71  1.0
    x_56        EDGE_34_56  1.0
    x_56        EDGE_56_60  1.0
    x_56        EDGE_56_63  1.0
    x_56        EDGE_14_56  1.0
    x_56        EDGE_56_72  1.0
    x_56        EDGE_1_56  1.0
    x_56        EDGE_12_56  1.0
    x_56        EDGE_56_75  1.0
    x_56        EDGE_15_56  1.0
    x_56        EDGE_29_56  1.0
    x_56        EDGE_13_56  1.0
    x_56        EDGE_46_56  1.0
    x_57        OBJ       -1
    x_57        EDGE_47_57  1.0
    x_57        EDGE_28_57  1.0
    x_57        EDGE_9_57  1.0
    x_57        EDGE_57_64  1.0
    x_57        EDGE_42_57  1.0
    x_57        EDGE_15_57  1.0
    x_57        EDGE_51_57  1.0
    x_57        EDGE_13_57  1.0
    x_57        EDGE_57_89  1.0
    x_57        EDGE_57_66  1.0
    x_57        EDGE_57_78  1.0
    x_57        EDGE_4_57  1.0
    x_57        EDGE_57_68  1.0
    x_57        EDGE_56_57  1.0
    x_57        EDGE_57_58  1.0
    x_57        EDGE_10_57  1.0
    x_57        EDGE_43_57  1.0
    x_57        EDGE_54_57  1.0
    x_57        EDGE_8_57  1.0
    x_57        EDGE_38_57  1.0
    x_57        EDGE_41_57  1.0
    x_57        EDGE_57_69  1.0
    x_57        EDGE_57_72  1.0
    x_57        EDGE_5_57  1.0
    x_57        EDGE_35_57  1.0
    x_57        EDGE_57_81  1.0
    x_57        EDGE_19_57  1.0
    x_57        EDGE_57_61  1.0
    x_57        EDGE_22_57  1.0
    x_57        EDGE_57_83  1.0
    x_57        EDGE_57_60  1.0
    x_57        EDGE_50_57  1.0
    x_57        EDGE_53_57  1.0
    x_57        EDGE_34_57  1.0
    x_57        EDGE_57_62  1.0
    x_57        EDGE_11_57  1.0
    x_57        EDGE_25_57  1.0
    x_58        OBJ       -1
    x_58        EDGE_48_58  1.0
    x_58        EDGE_58_85  1.0
    x_58        EDGE_58_75  1.0
    x_58        EDGE_25_58  1.0
    x_58        EDGE_58_86  1.0
    x_58        EDGE_58_66  1.0
    x_58        EDGE_42_58  1.0
    x_58        EDGE_27_58  1.0
    x_58        EDGE_57_58  1.0
    x_58        EDGE_13_58  1.0
    x_58        EDGE_58_78  1.0
    x_58        EDGE_58_67  1.0
    x_58        EDGE_23_58  1.0
    x_58        EDGE_5_58  1.0
    x_58        EDGE_58_70  1.0
    x_58        EDGE_7_58  1.0
    x_58        EDGE_24_58  1.0
    x_58        EDGE_39_58  1.0
    x_58        EDGE_20_58  1.0
    x_58        EDGE_53_58  1.0
    x_58        EDGE_58_71  1.0
    x_58        EDGE_58_83  1.0
    x_58        EDGE_47_58  1.0
    x_58        EDGE_1_58  1.0
    x_59        OBJ       -1
    x_59        EDGE_30_59  1.0
    x_59        EDGE_59_77  1.0
    x_59        EDGE_59_80  1.0
    x_59        EDGE_47_59  1.0
    x_59        EDGE_12_59  1.0
    x_59        EDGE_42_59  1.0
    x_59        EDGE_29_59  1.0
    x_59        EDGE_59_81  1.0
    x_59        EDGE_23_59  1.0
    x_59        EDGE_4_59  1.0
    x_59        EDGE_7_59  1.0
    x_59        EDGE_37_59  1.0
    x_59        EDGE_59_83  1.0
    x_59        EDGE_59_72  1.0
    x_59        EDGE_59_75  1.0
    x_59        EDGE_59_64  1.0
    x_59        EDGE_35_59  1.0
    x_59        EDGE_19_59  1.0
    x_59        EDGE_49_59  1.0
    x_59        EDGE_59_86  1.0
    x_59        EDGE_22_59  1.0
    x_59        EDGE_52_59  1.0
    x_59        EDGE_33_59  1.0
    x_59        EDGE_55_59  1.0
    x_59        EDGE_36_59  1.0
    x_59        EDGE_39_59  1.0
    x_59        EDGE_50_59  1.0
    x_59        EDGE_34_59  1.0
    x_60        OBJ       -1
    x_60        EDGE_19_60  1.0
    x_60        EDGE_60_87  1.0
    x_60        EDGE_22_60  1.0
    x_60        EDGE_60_67  1.0
    x_60        EDGE_36_60  1.0
    x_60        EDGE_17_60  1.0
    x_60        EDGE_51_60  1.0
    x_60        EDGE_34_60  1.0
    x_60        EDGE_60_79  1.0
    x_60        EDGE_30_60  1.0
    x_60        EDGE_12_60  1.0
    x_60        EDGE_42_60  1.0
    x_60        EDGE_48_60  1.0
    x_60        EDGE_60_70  1.0
    x_60        EDGE_32_60  1.0
    x_60        EDGE_23_60  1.0
    x_60        EDGE_60_81  1.0
    x_60        EDGE_26_60  1.0
    x_60        EDGE_56_60  1.0
    x_60        EDGE_60_84  1.0
    x_60        EDGE_60_61  1.0
    x_60        EDGE_40_60  1.0
    x_60        EDGE_43_60  1.0
    x_60        EDGE_57_60  1.0
    x_60        EDGE_8_60  1.0
    x_60        EDGE_39_60  1.0
    x_60        EDGE_60_73  1.0
    x_61        OBJ       -1
    x_61        EDGE_17_61  1.0
    x_61        EDGE_61_80  1.0
    x_61        EDGE_20_61  1.0
    x_61        EDGE_50_61  1.0
    x_61        EDGE_53_61  1.0
    x_61        EDGE_61_79  1.0
    x_61        EDGE_61_82  1.0
    x_61        EDGE_11_61  1.0
    x_61        EDGE_61_71  1.0
    x_61        EDGE_1_61  1.0
    x_61        EDGE_61_84  1.0
    x_61        EDGE_31_61  1.0
    x_61        EDGE_29_61  1.0
    x_61        EDGE_61_63  1.0
    x_61        EDGE_61_72  1.0
    x_61        EDGE_61_62  1.0
    x_61        EDGE_7_61  1.0
    x_61        EDGE_37_61  1.0
    x_61        EDGE_43_61  1.0
    x_61        EDGE_57_61  1.0
    x_61        EDGE_8_61  1.0
    x_61        EDGE_60_61  1.0
    x_61        EDGE_41_61  1.0
    x_61        EDGE_61_66  1.0
    x_61        EDGE_2_61  1.0
    x_61        EDGE_61_78  1.0
    x_61        EDGE_16_61  1.0
    x_61        EDGE_22_61  1.0
    x_62        OBJ       -1
    x_62        EDGE_5_62  1.0
    x_62        EDGE_16_62  1.0
    x_62        EDGE_19_62  1.0
    x_62        EDGE_52_62  1.0
    x_62        EDGE_3_62  1.0
    x_62        EDGE_55_62  1.0
    x_62        EDGE_62_79  1.0
    x_62        EDGE_17_62  1.0
    x_62        EDGE_62_69  1.0
    x_62        EDGE_39_62  1.0
    x_62        EDGE_62_82  1.0
    x_62        EDGE_53_62  1.0
    x_62        EDGE_62_71  1.0
    x_62        EDGE_11_62  1.0
    x_62        EDGE_14_62  1.0
    x_62        EDGE_62_83  1.0
    x_62        EDGE_28_62  1.0
    x_62        EDGE_9_62  1.0
    x_62        EDGE_31_62  1.0
    x_62        EDGE_61_62  1.0
    x_62        EDGE_62_63  1.0
    x_62        EDGE_42_62  1.0
    x_62        EDGE_13_62  1.0
    x_62        EDGE_62_75  1.0
    x_62        EDGE_62_77  1.0
    x_62        EDGE_7_62  1.0
    x_62        EDGE_10_62  1.0
    x_62        EDGE_40_62  1.0
    x_62        EDGE_21_62  1.0
    x_62        EDGE_43_62  1.0
    x_62        EDGE_27_62  1.0
    x_62        EDGE_57_62  1.0
    x_62        EDGE_38_62  1.0
    x_62        EDGE_41_62  1.0
    x_63        OBJ       -1
    x_63        EDGE_4_63  1.0
    x_63        EDGE_63_70  1.0
    x_63        EDGE_19_63  1.0
    x_63        EDGE_21_63  1.0
    x_63        EDGE_33_63  1.0
    x_63        EDGE_55_63  1.0
    x_63        EDGE_6_63  1.0
    x_63        EDGE_50_63  1.0
    x_63        EDGE_63_72  1.0
    x_63        EDGE_63_85  1.0
    x_63        EDGE_63_75  1.0
    x_63        EDGE_30_63  1.0
    x_63        EDGE_63_74  1.0
    x_63        EDGE_28_63  1.0
    x_63        EDGE_0_63  1.0
    x_63        EDGE_1_63  1.0
    x_63        EDGE_61_63  1.0
    x_63        EDGE_63_86  1.0
    x_63        EDGE_17_63  1.0
    x_63        EDGE_48_63  1.0
    x_63        EDGE_29_63  1.0
    x_63        EDGE_32_63  1.0
    x_63        EDGE_62_63  1.0
    x_63        EDGE_63_78  1.0
    x_63        EDGE_23_63  1.0
    x_63        EDGE_26_63  1.0
    x_63        EDGE_63_67  1.0
    x_63        EDGE_56_63  1.0
    x_63        EDGE_63_80  1.0
    x_63        EDGE_10_63  1.0
    x_63        EDGE_12_63  1.0
    x_63        EDGE_43_63  1.0
    x_63        EDGE_24_63  1.0
    x_63        EDGE_54_63  1.0
    x_63        EDGE_63_89  1.0
    x_63        EDGE_63_79  1.0
    x_63        EDGE_63_82  1.0
    x_63        EDGE_63_71  1.0
    x_64        OBJ       -1
    x_64        EDGE_43_64  1.0
    x_64        EDGE_57_64  1.0
    x_64        EDGE_64_80  1.0
    x_64        EDGE_64_70  1.0
    x_64        EDGE_41_64  1.0
    x_64        EDGE_18_64  1.0
    x_64        EDGE_64_72  1.0
    x_64        EDGE_16_64  1.0
    x_64        EDGE_19_64  1.0
    x_64        EDGE_0_64  1.0
    x_64        EDGE_64_84  1.0
    x_64        EDGE_33_64  1.0
    x_64        EDGE_17_64  1.0
    x_64        EDGE_20_64  1.0
    x_64        EDGE_50_64  1.0
    x_64        EDGE_53_64  1.0
    x_64        EDGE_64_73  1.0
    x_64        EDGE_34_64  1.0
    x_64        EDGE_64_86  1.0
    x_64        EDGE_30_64  1.0
    x_64        EDGE_11_64  1.0
    x_64        EDGE_64_65  1.0
    x_64        EDGE_1_64  1.0
    x_64        EDGE_31_64  1.0
    x_64        EDGE_42_64  1.0
    x_64        EDGE_48_64  1.0
    x_64        EDGE_29_64  1.0
    x_64        EDGE_59_64  1.0
    x_64        EDGE_51_64  1.0
    x_64        EDGE_46_64  1.0
    x_64        EDGE_64_79  1.0
    x_64        EDGE_64_88  1.0
    x_64        EDGE_23_64  1.0
    x_64        EDGE_4_64  1.0
    x_64        EDGE_64_68  1.0
    x_64        EDGE_7_64  1.0
    x_64        EDGE_10_64  1.0
    x_65        OBJ       -1
    x_65        EDGE_7_65  1.0
    x_65        EDGE_37_65  1.0
    x_65        EDGE_40_65  1.0
    x_65        EDGE_22_65  1.0
    x_65        EDGE_24_65  1.0
    x_65        EDGE_55_65  1.0
    x_65        EDGE_36_65  1.0
    x_65        EDGE_65_69  1.0
    x_65        EDGE_65_82  1.0
    x_65        EDGE_65_72  1.0
    x_65        EDGE_65_84  1.0
    x_65        EDGE_5_65  1.0
    x_65        EDGE_47_65  1.0
    x_65        EDGE_49_65  1.0
    x_65        EDGE_1_65  1.0
    x_65        EDGE_65_86  1.0
    x_65        EDGE_64_65  1.0
    x_65        EDGE_65_75  1.0
    x_65        EDGE_34_65  1.0
    x_65        EDGE_30_65  1.0
    x_65        EDGE_65_77  1.0
    x_65        EDGE_26_65  1.0
    x_65        EDGE_65_79  1.0
    x_66        OBJ       -1
    x_66        EDGE_66_84  1.0
    x_66        EDGE_23_66  1.0
    x_66        EDGE_4_66  1.0
    x_66        EDGE_7_66  1.0
    x_66        EDGE_37_66  1.0
    x_66        EDGE_24_66  1.0
    x_66        EDGE_54_66  1.0
    x_66        EDGE_57_66  1.0
    x_66        EDGE_8_66  1.0
    x_66        EDGE_66_75  1.0
    x_66        EDGE_58_66  1.0
    x_66        EDGE_66_87  1.0
    x_66        EDGE_66_77  1.0
    x_66        EDGE_35_66  1.0
    x_66        EDGE_0_66  1.0
    x_66        EDGE_66_76  1.0
    x_66        EDGE_55_66  1.0
    x_66        EDGE_6_66  1.0
    x_66        EDGE_66_89  1.0
    x_66        EDGE_36_66  1.0
    x_66        EDGE_50_66  1.0
    x_66        EDGE_66_88  1.0
    x_66        EDGE_11_66  1.0
    x_66        EDGE_44_66  1.0
    x_66        EDGE_47_66  1.0
    x_66        EDGE_9_66  1.0
    x_66        EDGE_1_66  1.0
    x_66        EDGE_31_66  1.0
    x_66        EDGE_61_66  1.0
    x_66        EDGE_66_69  1.0
    x_66        EDGE_51_66  1.0
    x_66        EDGE_66_82  1.0
    x_66        EDGE_66_81  1.0
    x_67        OBJ       -1
    x_67        EDGE_9_67  1.0
    x_67        EDGE_1_67  1.0
    x_67        EDGE_31_67  1.0
    x_67        EDGE_42_67  1.0
    x_67        EDGE_15_67  1.0
    x_67        EDGE_67_81  1.0
    x_67        EDGE_60_67  1.0
    x_67        EDGE_32_67  1.0
    x_67        EDGE_13_67  1.0
    x_67        EDGE_67_83  1.0
    x_67        EDGE_7_67  1.0
    x_67        EDGE_67_72  1.0
    x_67        EDGE_10_67  1.0
    x_67        EDGE_21_67  1.0
    x_67        EDGE_24_67  1.0
    x_67        EDGE_27_67  1.0
    x_67        EDGE_38_67  1.0
    x_67        EDGE_67_87  1.0
    x_67        EDGE_58_67  1.0
    x_67        EDGE_18_67  1.0
    x_67        EDGE_67_86  1.0
    x_67        EDGE_67_76  1.0
    x_67        EDGE_67_89  1.0
    x_67        EDGE_16_67  1.0
    x_67        EDGE_49_67  1.0
    x_67        EDGE_52_67  1.0
    x_67        EDGE_63_67  1.0
    x_67        EDGE_67_68  1.0
    x_67        EDGE_17_67  1.0
    x_67        EDGE_51_67  1.0
    x_67        EDGE_67_69  1.0
    x_68        OBJ       -1
    x_68        EDGE_29_68  1.0
    x_68        EDGE_51_68  1.0
    x_68        EDGE_13_68  1.0
    x_68        EDGE_68_83  1.0
    x_68        EDGE_46_68  1.0
    x_68        EDGE_68_85  1.0
    x_68        EDGE_25_68  1.0
    x_68        EDGE_56_68  1.0
    x_68        EDGE_10_68  1.0
    x_68        EDGE_40_68  1.0
    x_68        EDGE_68_87  1.0
    x_68        EDGE_57_68  1.0
    x_68        EDGE_38_68  1.0
    x_68        EDGE_68_89  1.0
    x_68        EDGE_18_68  1.0
    x_68        EDGE_4_68  1.0
    x_68        EDGE_16_68  1.0
    x_68        EDGE_0_68  1.0
    x_68        EDGE_22_68  1.0
    x_68        EDGE_3_68  1.0
    x_68        EDGE_33_68  1.0
    x_68        EDGE_55_68  1.0
    x_68        EDGE_20_68  1.0
    x_68        EDGE_67_68  1.0
    x_68        EDGE_68_82  1.0
    x_68        EDGE_44_68  1.0
    x_68        EDGE_47_68  1.0
    x_68        EDGE_31_68  1.0
    x_68        EDGE_12_68  1.0
    x_68        EDGE_64_68  1.0
    x_68        EDGE_48_68  1.0
    x_69        OBJ       -1
    x_69        EDGE_69_71  1.0
    x_69        EDGE_69_84  1.0
    x_69        EDGE_11_69  1.0
    x_69        EDGE_44_69  1.0
    x_69        EDGE_69_83  1.0
    x_69        EDGE_31_69  1.0
    x_69        EDGE_69_73  1.0
    x_69        EDGE_12_69  1.0
    x_69        EDGE_48_69  1.0
    x_69        EDGE_32_69  1.0
    x_69        EDGE_62_69  1.0
    x_69        EDGE_69_85  1.0
    x_69        EDGE_65_69  1.0
    x_69        EDGE_46_69  1.0
    x_69        EDGE_69_87  1.0
    x_69        EDGE_69_77  1.0
    x_69        EDGE_7_69  1.0
    x_69        EDGE_57_69  1.0
    x_69        EDGE_8_69  1.0
    x_69        EDGE_18_69  1.0
    x_69        EDGE_2_69  1.0
    x_69        EDGE_69_70  1.0
    x_69        EDGE_49_69  1.0
    x_69        EDGE_33_69  1.0
    x_69        EDGE_55_69  1.0
    x_69        EDGE_66_69  1.0
    x_69        EDGE_20_69  1.0
    x_69        EDGE_69_72  1.0
    x_69        EDGE_53_69  1.0
    x_69        EDGE_67_69  1.0
    x_70        OBJ       -1
    x_70        EDGE_70_77  1.0
    x_70        EDGE_0_70  1.0
    x_70        EDGE_33_70  1.0
    x_70        EDGE_63_70  1.0
    x_70        EDGE_64_70  1.0
    x_70        EDGE_15_70  1.0
    x_70        EDGE_45_70  1.0
    x_70        EDGE_70_76  1.0
    x_70        EDGE_29_70  1.0
    x_70        EDGE_70_88  1.0
    x_70        EDGE_11_70  1.0
    x_70        EDGE_70_80  1.0
    x_70        EDGE_40_70  1.0
    x_70        EDGE_60_70  1.0
    x_70        EDGE_70_82  1.0
    x_70        EDGE_58_70  1.0
    x_70        EDGE_70_81  1.0
    x_70        EDGE_23_70  1.0
    x_70        EDGE_35_70  1.0
    x_70        EDGE_37_70  1.0
    x_70        EDGE_21_70  1.0
    x_70        EDGE_22_70  1.0
    x_70        EDGE_70_73  1.0
    x_70        EDGE_6_70  1.0
    x_70        EDGE_69_70  1.0
    x_70        EDGE_20_70  1.0
    x_70        EDGE_50_70  1.0
    x_70        EDGE_34_70  1.0
    x_70        EDGE_70_85  1.0
    x_70        EDGE_70_75  1.0
    x_70        EDGE_30_70  1.0
    x_71        OBJ       -1
    x_71        EDGE_36_71  1.0
    x_71        EDGE_69_71  1.0
    x_71        EDGE_50_71  1.0
    x_71        EDGE_34_71  1.0
    x_71        EDGE_71_74  1.0
    x_71        EDGE_71_87  1.0
    x_71        EDGE_11_71  1.0
    x_71        EDGE_25_71  1.0
    x_71        EDGE_47_71  1.0
    x_71        EDGE_61_71  1.0
    x_71        EDGE_42_71  1.0
    x_71        EDGE_62_71  1.0
    x_71        EDGE_26_71  1.0
    x_71        EDGE_71_79  1.0
    x_71        EDGE_56_71  1.0
    x_71        EDGE_40_71  1.0
    x_71        EDGE_21_71  1.0
    x_71        EDGE_43_71  1.0
    x_71        EDGE_27_71  1.0
    x_71        EDGE_38_71  1.0
    x_71        EDGE_58_71  1.0
    x_71        EDGE_18_71  1.0
    x_71        EDGE_71_83  1.0
    x_71        EDGE_71_73  1.0
    x_71        EDGE_35_71  1.0
    x_71        EDGE_19_71  1.0
    x_71        EDGE_52_71  1.0
    x_71        EDGE_3_71  1.0
    x_71        EDGE_71_75  1.0
    x_71        EDGE_63_71  1.0
    x_72        OBJ       -1
    x_72        EDGE_72_74  1.0
    x_72        EDGE_35_72  1.0
    x_72        EDGE_47_72  1.0
    x_72        EDGE_19_72  1.0
    x_72        EDGE_72_83  1.0
    x_72        EDGE_72_86  1.0
    x_72        EDGE_33_72  1.0
    x_72        EDGE_63_72  1.0
    x_72        EDGE_64_72  1.0
    x_72        EDGE_6_72  1.0
    x_72        EDGE_36_72  1.0
    x_72        EDGE_72_85  1.0
    x_72        EDGE_65_72  1.0
    x_72        EDGE_67_72  1.0
    x_72        EDGE_14_72  1.0
    x_72        EDGE_44_72  1.0
    x_72        EDGE_28_72  1.0
    x_72        EDGE_9_72  1.0
    x_72        EDGE_61_72  1.0
    x_72        EDGE_12_72  1.0
    x_72        EDGE_15_72  1.0
    x_72        EDGE_72_79  1.0
    x_72        EDGE_57_72  1.0
    x_72        EDGE_29_72  1.0
    x_72        EDGE_59_72  1.0
    x_72        EDGE_46_72  1.0
    x_72        EDGE_72_78  1.0
    x_72        EDGE_23_72  1.0
    x_72        EDGE_72_80  1.0
    x_72        EDGE_56_72  1.0
    x_72        EDGE_40_72  1.0
    x_72        EDGE_22_72  1.0
    x_72        EDGE_52_72  1.0
    x_72        EDGE_24_72  1.0
    x_72        EDGE_54_72  1.0
    x_72        EDGE_69_72  1.0
    x_73        OBJ       -1
    x_73        EDGE_73_74  1.0
    x_73        EDGE_73_87  1.0
    x_73        EDGE_5_73  1.0
    x_73        EDGE_35_73  1.0
    x_73        EDGE_16_73  1.0
    x_73        EDGE_22_73  1.0
    x_73        EDGE_6_73  1.0
    x_73        EDGE_73_76  1.0
    x_73        EDGE_17_73  1.0
    x_73        EDGE_69_73  1.0
    x_73        EDGE_53_73  1.0
    x_73        EDGE_11_73  1.0
    x_73        EDGE_14_73  1.0
    x_73        EDGE_25_73  1.0
    x_73        EDGE_73_80  1.0
    x_73        EDGE_9_73  1.0
    x_73        EDGE_1_73  1.0
    x_73        EDGE_64_73  1.0
    x_73        EDGE_45_73  1.0
    x_73        EDGE_73_79  1.0
    x_73        EDGE_73_82  1.0
    x_73        EDGE_23_73  1.0
    x_73        EDGE_7_73  1.0
    x_73        EDGE_40_73  1.0
    x_73        EDGE_70_73  1.0
    x_73        EDGE_60_73  1.0
    x_73        EDGE_41_73  1.0
    x_73        EDGE_71_73  1.0
    x_73        EDGE_73_85  1.0
    x_73        EDGE_73_75  1.0
    x_73        EDGE_18_73  1.0
    x_74        OBJ       -1
    x_74        EDGE_73_74  1.0
    x_74        EDGE_74_75  1.0
    x_74        EDGE_54_74  1.0
    x_74        EDGE_71_74  1.0
    x_74        EDGE_72_74  1.0
    x_74        EDGE_74_86  1.0
    x_74        EDGE_19_74  1.0
    x_74        EDGE_49_74  1.0
    x_74        EDGE_22_74  1.0
    x_74        EDGE_52_74  1.0
    x_74        EDGE_3_74  1.0
    x_74        EDGE_33_74  1.0
    x_74        EDGE_63_74  1.0
    x_74        EDGE_20_74  1.0
    x_74        EDGE_50_74  1.0
    x_74        EDGE_51_74  1.0
    x_74        EDGE_11_74  1.0
    x_74        EDGE_14_74  1.0
    x_74        EDGE_25_74  1.0
    x_74        EDGE_31_74  1.0
    x_74        EDGE_32_74  1.0
    x_74        EDGE_74_84  1.0
    x_74        EDGE_74_83  1.0
    x_74        EDGE_23_74  1.0
    x_74        EDGE_4_74  1.0
    x_74        EDGE_26_74  1.0
    x_74        EDGE_43_74  1.0
    x_75        OBJ       -1
    x_75        EDGE_74_75  1.0
    x_75        EDGE_58_75  1.0
    x_75        EDGE_75_80  1.0
    x_75        EDGE_4_75  1.0
    x_75        EDGE_19_75  1.0
    x_75        EDGE_49_75  1.0
    x_75        EDGE_75_82  1.0
    x_75        EDGE_22_75  1.0
    x_75        EDGE_52_75  1.0
    x_75        EDGE_63_75  1.0
    x_75        EDGE_66_75  1.0
    x_75        EDGE_39_75  1.0
    x_75        EDGE_50_75  1.0
    x_75        EDGE_28_75  1.0
    x_75        EDGE_1_75  1.0
    x_75        EDGE_12_75  1.0
    x_75        EDGE_42_75  1.0
    x_75        EDGE_29_75  1.0
    x_75        EDGE_59_75  1.0
    x_75        EDGE_32_75  1.0
    x_75        EDGE_62_75  1.0
    x_75        EDGE_75_84  1.0
    x_75        EDGE_65_75  1.0
    x_75        EDGE_46_75  1.0
    x_75        EDGE_75_86  1.0
    x_75        EDGE_23_75  1.0
    x_75        EDGE_75_76  1.0
    x_75        EDGE_56_75  1.0
    x_75        EDGE_7_75  1.0
    x_75        EDGE_10_75  1.0
    x_75        EDGE_40_75  1.0
    x_75        EDGE_70_75  1.0
    x_75        EDGE_73_75  1.0
    x_75        EDGE_54_75  1.0
    x_75        EDGE_75_88  1.0
    x_75        EDGE_38_75  1.0
    x_75        EDGE_71_75  1.0
    x_76        OBJ       -1
    x_76        EDGE_76_87  1.0
    x_76        EDGE_4_76  1.0
    x_76        EDGE_76_77  1.0
    x_76        EDGE_26_76  1.0
    x_76        EDGE_7_76  1.0
    x_76        EDGE_70_76  1.0
    x_76        EDGE_21_76  1.0
    x_76        EDGE_73_76  1.0
    x_76        EDGE_24_76  1.0
    x_76        EDGE_54_76  1.0
    x_76        EDGE_27_76  1.0
    x_76        EDGE_41_76  1.0
    x_76        EDGE_2_76  1.0
    x_76        EDGE_19_76  1.0
    x_76        EDGE_49_76  1.0
    x_76        EDGE_3_76  1.0
    x_76        EDGE_33_76  1.0
    x_76        EDGE_36_76  1.0
    x_76        EDGE_66_76  1.0
    x_76        EDGE_50_76  1.0
    x_76        EDGE_76_82  1.0
    x_76        EDGE_34_76  1.0
    x_76        EDGE_67_76  1.0
    x_76        EDGE_76_81  1.0
    x_76        EDGE_76_83  1.0
    x_76        EDGE_76_86  1.0
    x_76        EDGE_15_76  1.0
    x_76        EDGE_75_76  1.0
    x_76        EDGE_29_76  1.0
    x_76        EDGE_51_76  1.0
    x_76        EDGE_32_76  1.0
    x_77        OBJ       -1
    x_77        EDGE_70_77  1.0
    x_77        EDGE_42_77  1.0
    x_77        EDGE_76_77  1.0
    x_77        EDGE_29_77  1.0
    x_77        EDGE_59_77  1.0
    x_77        EDGE_13_77  1.0
    x_77        EDGE_4_77  1.0
    x_77        EDGE_37_77  1.0
    x_77        EDGE_22_77  1.0
    x_77        EDGE_52_77  1.0
    x_77        EDGE_77_78  1.0
    x_77        EDGE_66_77  1.0
    x_77        EDGE_38_77  1.0
    x_77        EDGE_69_77  1.0
    x_77        EDGE_50_77  1.0
    x_77        EDGE_53_77  1.0
    x_77        EDGE_18_77  1.0
    x_77        EDGE_2_77  1.0
    x_77        EDGE_49_77  1.0
    x_77        EDGE_0_77  1.0
    x_77        EDGE_31_77  1.0
    x_77        EDGE_15_77  1.0
    x_77        EDGE_51_77  1.0
    x_77        EDGE_62_77  1.0
    x_77        EDGE_65_77  1.0
    x_77        EDGE_46_77  1.0
    x_77        EDGE_44_77  1.0
    x_77        EDGE_25_77  1.0
    x_77        EDGE_10_77  1.0
    x_78        OBJ       -1
    x_78        EDGE_32_78  1.0
    x_78        EDGE_13_78  1.0
    x_78        EDGE_23_78  1.0
    x_78        EDGE_56_78  1.0
    x_78        EDGE_37_78  1.0
    x_78        EDGE_78_79  1.0
    x_78        EDGE_10_78  1.0
    x_78        EDGE_40_78  1.0
    x_78        EDGE_21_78  1.0
    x_78        EDGE_57_78  1.0
    x_78        EDGE_8_78  1.0
    x_78        EDGE_77_78  1.0
    x_78        EDGE_58_78  1.0
    x_78        EDGE_18_78  1.0
    x_78        EDGE_16_78  1.0
    x_78        EDGE_49_78  1.0
    x_78        EDGE_0_78  1.0
    x_78        EDGE_22_78  1.0
    x_78        EDGE_63_78  1.0
    x_78        EDGE_55_78  1.0
    x_78        EDGE_36_78  1.0
    x_78        EDGE_39_78  1.0
    x_78        EDGE_50_78  1.0
    x_78        EDGE_72_78  1.0
    x_78        EDGE_34_78  1.0
    x_78        EDGE_78_86  1.0
    x_78        EDGE_25_78  1.0
    x_78        EDGE_47_78  1.0
    x_78        EDGE_61_78  1.0
    x_78        EDGE_42_78  1.0
    x_78        EDGE_45_78  1.0
    x_78        EDGE_29_78  1.0
    x_78        EDGE_51_78  1.0
    x_79        OBJ       -1
    x_79        EDGE_79_88  1.0
    x_79        EDGE_14_79  1.0
    x_79        EDGE_44_79  1.0
    x_79        EDGE_9_79  1.0
    x_79        EDGE_31_79  1.0
    x_79        EDGE_61_79  1.0
    x_79        EDGE_42_79  1.0
    x_79        EDGE_43_79  1.0
    x_79        EDGE_45_79  1.0
    x_79        EDGE_78_79  1.0
    x_79        EDGE_60_79  1.0
    x_79        EDGE_32_79  1.0
    x_79        EDGE_62_79  1.0
    x_79        EDGE_7_79  1.0
    x_79        EDGE_79_81  1.0
    x_79        EDGE_21_79  1.0
    x_79        EDGE_73_79  1.0
    x_79        EDGE_55_79  1.0
    x_79        EDGE_8_79  1.0
    x_79        EDGE_79_83  1.0
    x_79        EDGE_71_79  1.0
    x_79        EDGE_72_79  1.0
    x_79        EDGE_2_79  1.0
    x_79        EDGE_49_79  1.0
    x_79        EDGE_22_79  1.0
    x_79        EDGE_52_79  1.0
    x_79        EDGE_3_79  1.0
    x_79        EDGE_63_79  1.0
    x_79        EDGE_64_79  1.0
    x_79        EDGE_36_79  1.0
    x_79        EDGE_17_79  1.0
    x_79        EDGE_34_79  1.0
    x_79        EDGE_65_79  1.0
    x_80        OBJ       -1
    x_80        EDGE_28_80  1.0
    x_80        EDGE_1_80  1.0
    x_80        EDGE_31_80  1.0
    x_80        EDGE_61_80  1.0
    x_80        EDGE_12_80  1.0
    x_80        EDGE_64_80  1.0
    x_80        EDGE_45_80  1.0
    x_80        EDGE_75_80  1.0
    x_80        EDGE_59_80  1.0
    x_80        EDGE_13_80  1.0
    x_80        EDGE_80_82  1.0
    x_80        EDGE_80_84  1.0
    x_80        EDGE_23_80  1.0
    x_80        EDGE_56_80  1.0
    x_80        EDGE_70_80  1.0
    x_80        EDGE_73_80  1.0
    x_80        EDGE_54_80  1.0
    x_80        EDGE_80_85  1.0
    x_80        EDGE_18_80  1.0
    x_80        EDGE_35_80  1.0
    x_80        EDGE_80_87  1.0
    x_80        EDGE_49_80  1.0
    x_80        EDGE_22_80  1.0
    x_80        EDGE_52_80  1.0
    x_80        EDGE_33_80  1.0
    x_80        EDGE_63_80  1.0
    x_80        EDGE_55_80  1.0
    x_80        EDGE_6_80  1.0
    x_80        EDGE_36_80  1.0
    x_80        EDGE_50_80  1.0
    x_80        EDGE_72_80  1.0
    x_80        EDGE_11_80  1.0
    x_80        EDGE_14_80  1.0
    x_81        OBJ       -1
    x_81        EDGE_51_81  1.0
    x_81        EDGE_34_81  1.0
    x_81        EDGE_67_81  1.0
    x_81        EDGE_30_81  1.0
    x_81        EDGE_14_81  1.0
    x_81        EDGE_15_81  1.0
    x_81        EDGE_59_81  1.0
    x_81        EDGE_79_81  1.0
    x_81        EDGE_23_81  1.0
    x_81        EDGE_40_81  1.0
    x_81        EDGE_70_81  1.0
    x_81        EDGE_21_81  1.0
    x_81        EDGE_81_85  1.0
    x_81        EDGE_54_81  1.0
    x_81        EDGE_76_81  1.0
    x_81        EDGE_57_81  1.0
    x_81        EDGE_8_81  1.0
    x_81        EDGE_60_81  1.0
    x_81        EDGE_81_89  1.0
    x_81        EDGE_55_81  1.0
    x_81        EDGE_66_81  1.0
    x_82        OBJ       -1
    x_82        EDGE_30_82  1.0
    x_82        EDGE_14_82  1.0
    x_82        EDGE_47_82  1.0
    x_82        EDGE_0_82  1.0
    x_82        EDGE_80_82  1.0
    x_82        EDGE_61_82  1.0
    x_82        EDGE_12_82  1.0
    x_82        EDGE_15_82  1.0
    x_82        EDGE_75_82  1.0
    x_82        EDGE_48_82  1.0
    x_82        EDGE_62_82  1.0
    x_82        EDGE_65_82  1.0
    x_82        EDGE_46_82  1.0
    x_82        EDGE_82_87  1.0
    x_82        EDGE_11_82  1.0
    x_82        EDGE_23_82  1.0
    x_82        EDGE_82_89  1.0
    x_82        EDGE_70_82  1.0
    x_82        EDGE_42_82  1.0
    x_82        EDGE_73_82  1.0
    x_82        EDGE_24_82  1.0
    x_82        EDGE_54_82  1.0
    x_82        EDGE_76_82  1.0
    x_82        EDGE_27_82  1.0
    x_82        EDGE_38_82  1.0
    x_82        EDGE_82_88  1.0
    x_82        EDGE_4_82  1.0
    x_82        EDGE_68_82  1.0
    x_82        EDGE_19_82  1.0
    x_82        EDGE_49_82  1.0
    x_82        EDGE_3_82  1.0
    x_82        EDGE_33_82  1.0
    x_82        EDGE_63_82  1.0
    x_82        EDGE_66_82  1.0
    x_82        EDGE_17_82  1.0
    x_82        EDGE_39_82  1.0
    x_82        EDGE_50_82  1.0
    x_82        EDGE_53_82  1.0
    x_82        EDGE_82_84  1.0
    x_83        OBJ       -1
    x_83        EDGE_35_83  1.0
    x_83        EDGE_16_83  1.0
    x_83        EDGE_68_83  1.0
    x_83        EDGE_36_83  1.0
    x_83        EDGE_17_83  1.0
    x_83        EDGE_39_83  1.0
    x_83        EDGE_69_83  1.0
    x_83        EDGE_72_83  1.0
    x_83        EDGE_67_83  1.0
    x_83        EDGE_11_83  1.0
    x_83        EDGE_1_83  1.0
    x_83        EDGE_15_83  1.0
    x_83        EDGE_29_83  1.0
    x_83        EDGE_59_83  1.0
    x_83        EDGE_51_83  1.0
    x_83        EDGE_62_83  1.0
    x_83        EDGE_79_83  1.0
    x_83        EDGE_23_83  1.0
    x_83        EDGE_83_88  1.0
    x_83        EDGE_26_83  1.0
    x_83        EDGE_37_83  1.0
    x_83        EDGE_10_83  1.0
    x_83        EDGE_40_83  1.0
    x_83        EDGE_24_83  1.0
    x_83        EDGE_54_83  1.0
    x_83        EDGE_76_83  1.0
    x_83        EDGE_27_83  1.0
    x_83        EDGE_57_83  1.0
    x_83        EDGE_71_83  1.0
    x_83        EDGE_74_83  1.0
    x_83        EDGE_58_83  1.0
    x_83        EDGE_18_83  1.0
    x_84        OBJ       -1
    x_84        EDGE_36_84  1.0
    x_84        EDGE_66_84  1.0
    x_84        EDGE_38_84  1.0
    x_84        EDGE_69_84  1.0
    x_84        EDGE_19_84  1.0
    x_84        EDGE_49_84  1.0
    x_84        EDGE_1_84  1.0
    x_84        EDGE_80_84  1.0
    x_84        EDGE_31_84  1.0
    x_84        EDGE_61_84  1.0
    x_84        EDGE_3_84  1.0
    x_84        EDGE_64_84  1.0
    x_84        EDGE_34_84  1.0
    x_84        EDGE_65_84  1.0
    x_84        EDGE_11_84  1.0
    x_84        EDGE_84_87  1.0
    x_84        EDGE_25_84  1.0
    x_84        EDGE_26_84  1.0
    x_84        EDGE_28_84  1.0
    x_84        EDGE_42_84  1.0
    x_84        EDGE_43_84  1.0
    x_84        EDGE_15_84  1.0
    x_84        EDGE_75_84  1.0
    x_84        EDGE_60_84  1.0
    x_84        EDGE_41_84  1.0
    x_84        EDGE_13_84  1.0
    x_84        EDGE_74_84  1.0
    x_84        EDGE_23_84  1.0
    x_84        EDGE_5_84  1.0
    x_84        EDGE_37_84  1.0
    x_84        EDGE_21_84  1.0
    x_84        EDGE_22_84  1.0
    x_84        EDGE_82_84  1.0
    x_84        EDGE_24_84  1.0
    x_85        OBJ       -1
    x_85        EDGE_58_85  1.0
    x_85        EDGE_2_85  1.0
    x_85        EDGE_5_85  1.0
    x_85        EDGE_85_86  1.0
    x_85        EDGE_35_85  1.0
    x_85        EDGE_68_85  1.0
    x_85        EDGE_22_85  1.0
    x_85        EDGE_52_85  1.0
    x_85        EDGE_3_85  1.0
    x_85        EDGE_63_85  1.0
    x_85        EDGE_6_85  1.0
    x_85        EDGE_17_85  1.0
    x_85        EDGE_69_85  1.0
    x_85        EDGE_72_85  1.0
    x_85        EDGE_53_85  1.0
    x_85        EDGE_30_85  1.0
    x_85        EDGE_25_85  1.0
    x_85        EDGE_80_85  1.0
    x_85        EDGE_12_85  1.0
    x_85        EDGE_42_85  1.0
    x_85        EDGE_45_85  1.0
    x_85        EDGE_85_88  1.0
    x_85        EDGE_29_85  1.0
    x_85        EDGE_51_85  1.0
    x_85        EDGE_81_85  1.0
    x_85        EDGE_40_85  1.0
    x_85        EDGE_70_85  1.0
    x_85        EDGE_21_85  1.0
    x_85        EDGE_73_85  1.0
    x_86        OBJ       -1
    x_86        EDGE_7_86  1.0
    x_86        EDGE_10_86  1.0
    x_86        EDGE_40_86  1.0
    x_86        EDGE_21_86  1.0
    x_86        EDGE_85_86  1.0
    x_86        EDGE_8_86  1.0
    x_86        EDGE_38_86  1.0
    x_86        EDGE_39_86  1.0
    x_86        EDGE_41_86  1.0
    x_86        EDGE_72_86  1.0
    x_86        EDGE_74_86  1.0
    x_86        EDGE_58_86  1.0
    x_86        EDGE_0_86  1.0
    x_86        EDGE_33_86  1.0
    x_86        EDGE_63_86  1.0
    x_86        EDGE_64_86  1.0
    x_86        EDGE_6_86  1.0
    x_86        EDGE_86_87  1.0
    x_86        EDGE_65_86  1.0
    x_86        EDGE_67_86  1.0
    x_86        EDGE_30_86  1.0
    x_86        EDGE_14_86  1.0
    x_86        EDGE_28_86  1.0
    x_86        EDGE_1_86  1.0
    x_86        EDGE_31_86  1.0
    x_86        EDGE_12_86  1.0
    x_86        EDGE_75_86  1.0
    x_86        EDGE_76_86  1.0
    x_86        EDGE_48_86  1.0
    x_86        EDGE_78_86  1.0
    x_86        EDGE_29_86  1.0
    x_86        EDGE_59_86  1.0
    x_86        EDGE_32_86  1.0
    x_86        EDGE_13_86  1.0
    x_87        OBJ       -1
    x_87        EDGE_73_87  1.0
    x_87        EDGE_24_87  1.0
    x_87        EDGE_54_87  1.0
    x_87        EDGE_76_87  1.0
    x_87        EDGE_60_87  1.0
    x_87        EDGE_41_87  1.0
    x_87        EDGE_71_87  1.0
    x_87        EDGE_87_89  1.0
    x_87        EDGE_18_87  1.0
    x_87        EDGE_4_87  1.0
    x_87        EDGE_5_87  1.0
    x_87        EDGE_87_88  1.0
    x_87        EDGE_68_87  1.0
    x_87        EDGE_22_87  1.0
    x_87        EDGE_52_87  1.0
    x_87        EDGE_82_87  1.0
    x_87        EDGE_6_87  1.0
    x_87        EDGE_36_87  1.0
    x_87        EDGE_66_87  1.0
    x_87        EDGE_17_87  1.0
    x_87        EDGE_69_87  1.0
    x_87        EDGE_20_87  1.0
    x_87        EDGE_53_87  1.0
    x_87        EDGE_34_87  1.0
    x_87        EDGE_86_87  1.0
    x_87        EDGE_67_87  1.0
    x_87        EDGE_84_87  1.0
    x_87        EDGE_30_87  1.0
    x_87        EDGE_44_87  1.0
    x_87        EDGE_47_87  1.0
    x_87        EDGE_28_87  1.0
    x_87        EDGE_80_87  1.0
    x_87        EDGE_12_87  1.0
    x_87        EDGE_42_87  1.0
    x_87        EDGE_15_87  1.0
    x_87        EDGE_46_87  1.0
    x_87        EDGE_23_87  1.0
    x_87        EDGE_26_87  1.0
    x_87        EDGE_7_87  1.0
    x_88        OBJ       -1
    x_88        EDGE_46_88  1.0
    x_88        EDGE_79_88  1.0
    x_88        EDGE_26_88  1.0
    x_88        EDGE_70_88  1.0
    x_88        EDGE_43_88  1.0
    x_88        EDGE_54_88  1.0
    x_88        EDGE_87_88  1.0
    x_88        EDGE_2_88  1.0
    x_88        EDGE_0_88  1.0
    x_88        EDGE_82_88  1.0
    x_88        EDGE_55_88  1.0
    x_88        EDGE_85_88  1.0
    x_88        EDGE_66_88  1.0
    x_88        EDGE_17_88  1.0
    x_88        EDGE_39_88  1.0
    x_88        EDGE_50_88  1.0
    x_88        EDGE_53_88  1.0
    x_88        EDGE_83_88  1.0
    x_88        EDGE_25_88  1.0
    x_88        EDGE_1_88  1.0
    x_88        EDGE_64_88  1.0
    x_88        EDGE_15_88  1.0
    x_88        EDGE_45_88  1.0
    x_88        EDGE_75_88  1.0
    x_88        EDGE_32_88  1.0
    x_89        OBJ       -1
    x_89        EDGE_26_89  1.0
    x_89        EDGE_56_89  1.0
    x_89        EDGE_10_89  1.0
    x_89        EDGE_40_89  1.0
    x_89        EDGE_43_89  1.0
    x_89        EDGE_57_89  1.0
    x_89        EDGE_87_89  1.0
    x_89        EDGE_37_89  1.0
    x_89        EDGE_68_89  1.0
    x_89        EDGE_52_89  1.0
    x_89        EDGE_82_89  1.0
    x_89        EDGE_36_89  1.0
    x_89        EDGE_66_89  1.0
    x_89        EDGE_39_89  1.0
    x_89        EDGE_20_89  1.0
    x_89        EDGE_50_89  1.0
    x_89        EDGE_34_89  1.0
    x_89        EDGE_67_89  1.0
    x_89        EDGE_44_89  1.0
    x_89        EDGE_1_89  1.0
    x_89        EDGE_31_89  1.0
    x_89        EDGE_63_89  1.0
    x_89        EDGE_17_89  1.0
    x_89        EDGE_29_89  1.0
    x_89        EDGE_81_89  1.0
RHS
    RHS1      EDGE_36_71  1.0
    RHS1      EDGE_29_32  1.0
    RHS1      EDGE_8_9  1.0
    RHS1      EDGE_29_68  1.0
    RHS1      EDGE_41_42  1.0
    RHS1      EDGE_73_74  1.0
    RHS1      EDGE_25_34  1.0
    RHS1      EDGE_10_54  1.0
    RHS1      EDGE_14_24  1.0
    RHS1      EDGE_74_75  1.0
    RHS1      EDGE_32_78  1.0
    RHS1      EDGE_35_83  1.0
    RHS1      EDGE_15_25  1.0
    RHS1      EDGE_47_57  1.0
    RHS1      EDGE_70_77  1.0
    RHS1      EDGE_36_84  1.0
    RHS1      EDGE_9_67  1.0
    RHS1      EDGE_28_80  1.0
    RHS1      EDGE_29_45  1.0
    RHS1      EDGE_48_58  1.0
    RHS1      EDGE_2_27  1.0
    RHS1      EDGE_54_74  1.0
    RHS1      EDGE_73_87  1.0
    RHS1      EDGE_51_68  1.0
    RHS1      EDGE_43_64  1.0
    RHS1      EDGE_1_67  1.0
    RHS1      EDGE_66_84  1.0
    RHS1      EDGE_13_78  1.0
    RHS1      EDGE_24_87  1.0
    RHS1      EDGE_16_83  1.0
    RHS1      EDGE_17_48  1.0
    RHS1      EDGE_28_57  1.0
    RHS1      EDGE_5_73  1.0
    RHS1      EDGE_6_38  1.0
    RHS1      EDGE_58_85  1.0
    RHS1      EDGE_42_77  1.0
    RHS1      EDGE_21_54  1.0
    RHS1      EDGE_31_67  1.0
    RHS1      EDGE_2_40  1.0
    RHS1      EDGE_3_5  1.0
    RHS1      EDGE_54_87  1.0
    RHS1      EDGE_51_81  1.0
    RHS1      EDGE_35_73  1.0
    RHS1      EDGE_1_80  1.0
    RHS1      EDGE_5_50  1.0
    RHS1      EDGE_6_15  1.0
    RHS1      EDGE_46_88  1.0
    RHS1      EDGE_38_84  1.0
    RHS1      EDGE_17_61  1.0
    RHS1      EDGE_9_57  1.0
    RHS1      EDGE_29_35  1.0
    RHS1      EDGE_69_71  1.0
    RHS1      EDGE_2_17  1.0
    RHS1      EDGE_13_32  1.0
    RHS1      EDGE_31_80  1.0
    RHS1      EDGE_4_63  1.0
    RHS1      EDGE_32_45  1.0
    RHS1      EDGE_35_50  1.0
    RHS1      EDGE_13_68  1.0
    RHS1      EDGE_5_27  1.0
    RHS1      EDGE_16_73  1.0
    RHS1      EDGE_76_87  1.0
    RHS1      EDGE_9_34  1.0
    RHS1      EDGE_68_83  1.0
    RHS1      EDGE_6_28  1.0
    RHS1      EDGE_58_75  1.0
    RHS1      EDGE_50_71  1.0
    RHS1      EDGE_69_84  1.0
    RHS1      EDGE_42_67  1.0
    RHS1      EDGE_61_80  1.0
    RHS1      EDGE_0_70  1.0
    RHS1      EDGE_12_44  1.0
    RHS1      EDGE_23_53  1.0
    RHS1      EDGE_2_30  1.0
    RHS1      EDGE_12_80  1.0
    RHS1      EDGE_4_76  1.0
    RHS1      EDGE_24_54  1.0
    RHS1      EDGE_16_50  1.0
    RHS1      EDGE_7_86  1.0
    RHS1      EDGE_19_60  1.0
    RHS1      EDGE_20_61  1.0
    RHS1      EDGE_4_53  1.0
    RHS1      EDGE_23_66  1.0
    RHS1      EDGE_16_27  1.0
    RHS1      EDGE_35_40  1.0
    RHS1      EDGE_34_81  1.0
    RHS1      EDGE_38_51  1.0
    RHS1      EDGE_17_28  1.0
    RHS1      EDGE_57_64  1.0
    RHS1      EDGE_76_77  1.0
    RHS1      EDGE_15_67  1.0
    RHS1      EDGE_26_76  1.0
    RHS1      EDGE_79_88  1.0
    RHS1      EDGE_50_61  1.0
    RHS1      EDGE_42_57  1.0
    RHS1      EDGE_20_38  1.0
    RHS1      EDGE_11_69  1.0
    RHS1      EDGE_12_34  1.0
    RHS1      EDGE_30_82  1.0
    RHS1      EDGE_31_47  1.0
    RHS1      EDGE_1_24  1.0
    RHS1      EDGE_4_66  1.0
    RHS1      EDGE_64_80  1.0
    RHS1      EDGE_14_79  1.0
    RHS1      EDGE_26_53  1.0
    RHS1      EDGE_46_68  1.0
    RHS1      EDGE_7_76  1.0
    RHS1      EDGE_26_89  1.0
    RHS1      EDGE_30_59  1.0
    RHS1      EDGE_60_87  1.0
    RHS1      EDGE_33_70  1.0
    RHS1      EDGE_44_79  1.0
    RHS1      EDGE_10_86  1.0
    RHS1      EDGE_16_17  1.0
    RHS1      EDGE_22_60  1.0
    RHS1      EDGE_1_37  1.0
    RHS1      EDGE_34_71  1.0
    RHS1      EDGE_45_80  1.0
    RHS1      EDGE_38_41  1.0
    RHS1      EDGE_56_89  1.0
    RHS1      EDGE_49_50  1.0
    RHS1      EDGE_15_57  1.0
    RHS1      EDGE_7_53  1.0
    RHS1      EDGE_19_27  1.0
    RHS1      EDGE_71_74  1.0
    RHS1      EDGE_63_70  1.0
    RHS1      EDGE_29_77  1.0
    RHS1      EDGE_40_86  1.0
    RHS1      EDGE_19_63  1.0
    RHS1      EDGE_4_20  1.0
    RHS1      EDGE_23_33  1.0
    RHS1      EDGE_75_80  1.0
    RHS1      EDGE_41_87  1.0
    RHS1      EDGE_34_48  1.0
    RHS1      EDGE_53_61  1.0
    RHS1      EDGE_72_74  1.0
    RHS1      EDGE_64_70  1.0
    RHS1      EDGE_22_73  1.0
    RHS1      EDGE_67_81  1.0
    RHS1      EDGE_59_77  1.0
    RHS1      EDGE_38_54  1.0
    RHS1      EDGE_15_70  1.0
    RHS1      EDGE_7_66  1.0
    RHS1      EDGE_8_31  1.0
    RHS1      EDGE_27_44  1.0
    RHS1      EDGE_11_36  1.0
    RHS1      EDGE_30_49  1.0
    RHS1      EDGE_71_87  1.0
    RHS1      EDGE_21_86  1.0
    RHS1      EDGE_41_64  1.0
    RHS1      EDGE_25_56  1.0
    RHS1      EDGE_4_33  1.0
    RHS1      EDGE_44_69  1.0
    RHS1      EDGE_14_46  1.0
    RHS1      EDGE_45_70  1.0
    RHS1      EDGE_37_66  1.0
    RHS1      EDGE_14_82  1.0
    RHS1      EDGE_15_47  1.0
    RHS1      EDGE_7_43  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_21_63  1.0
    RHS1      EDGE_11_49  1.0
    RHS1      EDGE_4_10  1.0
    RHS1      EDGE_44_46  1.0
    RHS1      EDGE_34_38  1.0
    RHS1      EDGE_45_47  1.0
    RHS1      EDGE_10_89  1.0
    RHS1      EDGE_2_85  1.0
    RHS1      EDGE_3_50  1.0
    RHS1      EDGE_15_24  1.0
    RHS1      EDGE_26_33  1.0
    RHS1      EDGE_70_76  1.0
    RHS1      EDGE_36_83  1.0
    RHS1      EDGE_40_53  1.0
    RHS1      EDGE_11_26  1.0
    RHS1      EDGE_21_76  1.0
    RHS1      EDGE_40_89  1.0
    RHS1      EDGE_41_54  1.0
    RHS1      EDGE_60_67  1.0
    RHS1      EDGE_34_51  1.0
    RHS1      EDGE_13_77  1.0
    RHS1      EDGE_36_60  1.0
    RHS1      EDGE_59_80  1.0
    RHS1      EDGE_17_83  1.0
    RHS1      EDGE_9_79  1.0
    RHS1      EDGE_21_53  1.0
    RHS1      EDGE_6_73  1.0
    RHS1      EDGE_33_63  1.0
    RHS1      EDGE_32_67  1.0
    RHS1      EDGE_35_72  1.0
    RHS1      EDGE_14_49  1.0
    RHS1      EDGE_17_60  1.0
    RHS1      EDGE_47_82  1.0
    RHS1      EDGE_40_43  1.0
    RHS1      EDGE_5_85  1.0
    RHS1      EDGE_6_50  1.0
    RHS1      EDGE_29_70  1.0
    RHS1      EDGE_33_40  1.0
    RHS1      EDGE_73_76  1.0
    RHS1      EDGE_25_36  1.0
    RHS1      EDGE_39_83  1.0
    RHS1      EDGE_44_49  1.0
    RHS1      EDGE_31_79  1.0
    RHS1      EDGE_10_56  1.0
    RHS1      EDGE_51_57  1.0
    RHS1      EDGE_14_26  1.0
    RHS1      EDGE_85_86  1.0
    RHS1      EDGE_13_67  1.0
    RHS1      EDGE_24_76  1.0
    RHS1      EDGE_43_89  1.0
    RHS1      EDGE_35_85  1.0
    RHS1      EDGE_55_63  1.0
    RHS1      EDGE_28_46  1.0
    RHS1      EDGE_47_59  1.0
    RHS1      EDGE_5_62  1.0
    RHS1      EDGE_6_27  1.0
    RHS1      EDGE_17_73  1.0
    RHS1      EDGE_29_47  1.0
    RHS1      EDGE_69_83  1.0
    RHS1      EDGE_61_79  1.0
    RHS1      EDGE_6_63  1.0
    RHS1      EDGE_54_76  1.0
    RHS1      EDGE_4_75  1.0
    RHS1      EDGE_13_80  1.0
    RHS1      EDGE_47_72  1.0
    RHS1      EDGE_6_40  1.0
    RHS1      EDGE_42_79  1.0
    RHS1      EDGE_8_86  1.0
    RHS1      EDGE_0_82  1.0
    RHS1      EDGE_31_69  1.0
    RHS1      EDGE_2_42  1.0
    RHS1      EDGE_13_57  1.0
    RHS1      EDGE_24_66  1.0
    RHS1      EDGE_43_79  1.0
    RHS1      EDGE_16_62  1.0
    RHS1      EDGE_17_27  1.0
    RHS1      EDGE_47_49  1.0
    RHS1      EDGE_5_52  1.0
    RHS1      EDGE_6_17  1.0
    RHS1      EDGE_38_86  1.0
    RHS1      EDGE_29_37  1.0
    RHS1      EDGE_69_73  1.0
    RHS1      EDGE_80_82  1.0
    RHS1      EDGE_27_76  1.0
    RHS1      EDGE_19_72  1.0
    RHS1      EDGE_39_50  1.0
    RHS1      EDGE_30_81  1.0
    RHS1      EDGE_54_66  1.0
    RHS1      EDGE_39_86  1.0
    RHS1      EDGE_12_69  1.0
    RHS1      EDGE_72_83  1.0
    RHS1      EDGE_23_78  1.0
    RHS1      EDGE_51_60  1.0
    RHS1      EDGE_35_52  1.0
    RHS1      EDGE_9_36  1.0
    RHS1      EDGE_28_49  1.0
    RHS1      EDGE_68_85  1.0
    RHS1      EDGE_26_88  1.0
    RHS1      EDGE_61_82  1.0
    RHS1      EDGE_23_55  1.0
    RHS1      EDGE_1_36  1.0
    RHS1      EDGE_12_82  1.0
    RHS1      EDGE_45_79  1.0
    RHS1      EDGE_16_52  1.0
    RHS1      EDGE_9_13  1.0
    RHS1      EDGE_5_42  1.0
    RHS1      EDGE_57_89  1.0
    RHS1      EDGE_21_23  1.0
    RHS1      EDGE_19_62  1.0
    RHS1      EDGE_41_86  1.0
    RHS1      EDGE_12_59  1.0
    RHS1      EDGE_13_24  1.0
    RHS1      EDGE_24_33  1.0
    RHS1      EDGE_1_49  1.0
    RHS1      EDGE_87_89  1.0
    RHS1      EDGE_57_66  1.0
    RHS1      EDGE_9_26  1.0
    RHS1      EDGE_7_65  1.0
    RHS1      EDGE_6_20  1.0
    RHS1      EDGE_30_48  1.0
    RHS1      EDGE_50_63  1.0
    RHS1      EDGE_42_59  1.0
    RHS1      EDGE_8_66  1.0
    RHS1      EDGE_19_75  1.0
    RHS1      EDGE_11_71  1.0
    RHS1      EDGE_34_60  1.0
    RHS1      EDGE_13_37  1.0
    RHS1      EDGE_53_73  1.0
    RHS1      EDGE_72_86  1.0
    RHS1      EDGE_37_65  1.0
    RHS1      EDGE_16_42  1.0
    RHS1      EDGE_56_78  1.0
    RHS1      EDGE_22_85  1.0
    RHS1      EDGE_14_81  1.0
    RHS1      EDGE_15_46  1.0
    RHS1      EDGE_49_75  1.0
    RHS1      EDGE_15_82  1.0
    RHS1      EDGE_18_87  1.0
    RHS1      EDGE_41_76  1.0
    RHS1      EDGE_1_3  1.0
    RHS1      EDGE_33_72  1.0
    RHS1      EDGE_12_49  1.0
    RHS1      EDGE_25_68  1.0
    RHS1      EDGE_52_85  1.0
    RHS1      EDGE_16_19  1.0
    RHS1      EDGE_37_78  1.0
    RHS1      EDGE_78_79  1.0
    RHS1      EDGE_3_85  1.0
    RHS1      EDGE_18_64  1.0
    RHS1      EDGE_11_25  1.0
    RHS1      EDGE_63_72  1.0
    RHS1      EDGE_41_53  1.0
    RHS1      EDGE_11_61  1.0
    RHS1      EDGE_52_62  1.0
    RHS1      EDGE_75_82  1.0
    RHS1      EDGE_74_86  1.0
    RHS1      EDGE_64_72  1.0
    RHS1      EDGE_37_55  1.0
    RHS1      EDGE_56_68  1.0
    RHS1      EDGE_3_62  1.0
    RHS1      EDGE_22_75  1.0
    RHS1      EDGE_67_83  1.0
    RHS1      EDGE_38_56  1.0
    RHS1      EDGE_70_88  1.0
    RHS1      EDGE_48_69  1.0
    RHS1      EDGE_0_29  1.0
    RHS1      EDGE_40_65  1.0
    RHS1      EDGE_6_72  1.0
    RHS1      EDGE_11_38  1.0
    RHS1      EDGE_30_51  1.0
    RHS1      EDGE_63_85  1.0
    RHS1      EDGE_60_79  1.0
    RHS1      EDGE_52_75  1.0
    RHS1      EDGE_25_58  1.0
    RHS1      EDGE_10_78  1.0
    RHS1      EDGE_36_72  1.0
    RHS1      EDGE_18_54  1.0
    RHS1      EDGE_11_15  1.0
    RHS1      EDGE_48_82  1.0
    RHS1      EDGE_40_78  1.0
    RHS1      EDGE_41_43  1.0
    RHS1      EDGE_6_85  1.0
    RHS1      EDGE_34_40  1.0
    RHS1      EDGE_25_71  1.0
    RHS1      EDGE_45_49  1.0
    RHS1      EDGE_32_79  1.0
    RHS1      EDGE_43_88  1.0
    RHS1      EDGE_22_65  1.0
    RHS1      EDGE_15_26  1.0
    RHS1      EDGE_55_62  1.0
    RHS1      EDGE_40_55  1.0
    RHS1      EDGE_63_75  1.0
    RHS1      EDGE_21_78  1.0
    RHS1      EDGE_62_79  1.0
    RHS1      EDGE_10_68  1.0
    RHS1      EDGE_15_39  1.0
    RHS1      EDGE_7_35  1.0
    RHS1      EDGE_47_71  1.0
    RHS1      EDGE_18_44  1.0
    RHS1      EDGE_17_85  1.0
    RHS1      EDGE_58_86  1.0
    RHS1      EDGE_29_59  1.0
    RHS1      EDGE_40_68  1.0
    RHS1      EDGE_54_88  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_4_87  1.0
    RHS1      EDGE_32_69  1.0
    RHS1      EDGE_24_65  1.0
    RHS1      EDGE_17_62  1.0
    RHS1      EDGE_21_32  1.0
    RHS1      EDGE_5_87  1.0
    RHS1      EDGE_62_69  1.0
    RHS1      EDGE_2_54  1.0
    RHS1      EDGE_43_55  1.0
    RHS1      EDGE_66_75  1.0
    RHS1      EDGE_17_39  1.0
    RHS1      EDGE_36_52  1.0
    RHS1      EDGE_55_65  1.0
    RHS1      EDGE_28_48  1.0
    RHS1      EDGE_69_85  1.0
    RHS1      EDGE_19_84  1.0
    RHS1      EDGE_39_62  1.0
    RHS1      EDGE_62_82  1.0
    RHS1      EDGE_4_77  1.0
    RHS1      EDGE_16_51  1.0
    RHS1      EDGE_5_41  1.0
    RHS1      EDGE_36_65  1.0
    RHS1      EDGE_49_84  1.0
    RHS1      EDGE_2_8  1.0
    RHS1      EDGE_39_75  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_1_48  1.0
    RHS1      EDGE_87_88  1.0
    RHS1      EDGE_65_69  1.0
    RHS1      EDGE_16_64  1.0
    RHS1      EDGE_1_84  1.0
    RHS1      EDGE_5_54  1.0
    RHS1      EDGE_58_66  1.0
    RHS1      EDGE_42_58  1.0
    RHS1      EDGE_61_71  1.0
    RHS1      EDGE_80_84  1.0
    RHS1      EDGE_19_74  1.0
    RHS1      EDGE_20_39  1.0
    RHS1      EDGE_11_70  1.0
    RHS1      EDGE_2_21  1.0
    RHS1      EDGE_13_36  1.0
    RHS1      EDGE_31_84  1.0
    RHS1      EDGE_72_85  1.0
    RHS1      EDGE_23_80  1.0
    RHS1      EDGE_1_61  1.0
    RHS1      EDGE_46_69  1.0
    RHS1      EDGE_65_82  1.0
    RHS1      EDGE_57_78  1.0
    RHS1      EDGE_49_74  1.0
    RHS1      EDGE_68_87  1.0
    RHS1      EDGE_15_81  1.0
    RHS1      EDGE_30_60  1.0
    RHS1      EDGE_50_75  1.0
    RHS1      EDGE_42_71  1.0
    RHS1      EDGE_61_84  1.0
    RHS1      EDGE_8_78  1.0
    RHS1      EDGE_20_52  1.0
    RHS1      EDGE_11_83  1.0
    RHS1      EDGE_12_48  1.0
    RHS1      EDGE_31_61  1.0
    RHS1      EDGE_16_18  1.0
    RHS1      EDGE_53_85  1.0
    RHS1      EDGE_37_77  1.0
    RHS1      EDGE_3_84  1.0
    RHS1      EDGE_49_51  1.0
    RHS1      EDGE_5_44  1.0
    RHS1      EDGE_6_9  1.0
    RHS1      EDGE_46_82  1.0
    RHS1      EDGE_50_52  1.0
    RHS1      EDGE_42_48  1.0
    RHS1      EDGE_8_55  1.0
    RHS1      EDGE_19_64  1.0
    RHS1      EDGE_12_25  1.0
    RHS1      EDGE_1_15  1.0
    RHS1      EDGE_13_26  1.0
    RHS1      EDGE_53_62  1.0
    RHS1      EDGE_4_57  1.0
    RHS1      EDGE_24_35  1.0
    RHS1      EDGE_22_74  1.0
    RHS1      EDGE_65_72  1.0
    RHS1      EDGE_38_55  1.0
    RHS1      EDGE_57_68  1.0
    RHS1      EDGE_9_28  1.0
    RHS1      EDGE_7_67  1.0
    RHS1      EDGE_0_64  1.0
    RHS1      EDGE_11_73  1.0
    RHS1      EDGE_52_74  1.0
    RHS1      EDGE_23_47  1.0
    RHS1      EDGE_1_28  1.0
    RHS1      EDGE_64_84  1.0
    RHS1      EDGE_56_80  1.0
    RHS1      EDGE_3_74  1.0
    RHS1      EDGE_22_87  1.0
    RHS1      EDGE_7_44  1.0
    RHS1      EDGE_38_68  1.0
    RHS1      EDGE_8_45  1.0
    RHS1      EDGE_27_58  1.0
    RHS1      EDGE_19_54  1.0
    RHS1      EDGE_30_63  1.0
    RHS1      EDGE_4_11  1.0
    RHS1      EDGE_23_24  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_33_74  1.0
    RHS1      EDGE_34_39  1.0
    RHS1      EDGE_52_87  1.0
    RHS1      EDGE_45_48  1.0
    RHS1      EDGE_56_57  1.0
    RHS1      EDGE_67_72  1.0
    RHS1      EDGE_57_58  1.0
    RHS1      EDGE_49_54  1.0
    RHS1      EDGE_19_31  1.0
    RHS1      EDGE_63_74  1.0
    RHS1      EDGE_82_87  1.0
    RHS1      EDGE_41_55  1.0
    RHS1      EDGE_20_32  1.0
    RHS1      EDGE_4_24  1.0
    RHS1      EDGE_10_67  1.0
    RHS1      EDGE_22_77  1.0
    RHS1      EDGE_14_73  1.0
    RHS1      EDGE_15_38  1.0
    RHS1      EDGE_59_81  1.0
    RHS1      EDGE_0_31  1.0
    RHS1      EDGE_33_64  1.0
    RHS1      EDGE_52_77  1.0
    RHS1      EDGE_2_76  1.0
    RHS1      EDGE_15_51  1.0
    RHS1      EDGE_0_8  1.0
    RHS1      EDGE_11_17  1.0
    RHS1      EDGE_21_67  1.0
    RHS1      EDGE_6_87  1.0
    RHS1      EDGE_10_57  1.0
    RHS1      EDGE_22_31  1.0
    RHS1      EDGE_14_27  1.0
    RHS1      EDGE_34_42  1.0
    RHS1      EDGE_25_73  1.0
    RHS1      EDGE_45_51  1.0
    RHS1      EDGE_37_47  1.0
    RHS1      EDGE_70_80  1.0
    RHS1      EDGE_36_87  1.0
    RHS1      EDGE_21_44  1.0
    RHS1      EDGE_0_21  1.0
    RHS1      EDGE_3_31  1.0
    RHS1      EDGE_14_40  1.0
    RHS1      EDGE_66_87  1.0
    RHS1      EDGE_17_51  1.0
    RHS1      EDGE_6_41  1.0
    RHS1      EDGE_17_87  1.0
    RHS1      EDGE_29_61  1.0
    RHS1      EDGE_40_70  1.0
    RHS1      EDGE_10_47  1.0
    RHS1      EDGE_2_43  1.0
    RHS1      EDGE_13_58  1.0
    RHS1      EDGE_24_67  1.0
    RHS1      EDGE_36_41  1.0
    RHS1      EDGE_1_83  1.0
    RHS1      EDGE_7_14  1.0
    RHS1      EDGE_17_64  1.0
    RHS1      EDGE_77_78  1.0
    RHS1      EDGE_48_51  1.0
    RHS1      EDGE_2_20  1.0
    RHS1      EDGE_62_71  1.0
    RHS1      EDGE_73_80  1.0
    RHS1      EDGE_20_74  1.0
    RHS1      EDGE_2_56  1.0
    RHS1      EDGE_43_57  1.0
    RHS1      EDGE_66_77  1.0
    RHS1      EDGE_28_50  1.0
    RHS1      EDGE_58_78  1.0
    RHS1      EDGE_9_73  1.0
    RHS1      EDGE_50_74  1.0
    RHS1      EDGE_29_51  1.0
    RHS1      EDGE_69_87  1.0
    RHS1      EDGE_21_47  1.0
    RHS1      EDGE_11_82  1.0
    RHS1      EDGE_2_33  1.0
    RHS1      EDGE_54_80  1.0
    RHS1      EDGE_20_87  1.0
    RHS1      EDGE_51_74  1.0
    RHS1      EDGE_35_66  1.0
    RHS1      EDGE_1_73  1.0
    RHS1      EDGE_6_8  1.0
    RHS1      EDGE_38_77  1.0
    RHS1      EDGE_28_63  1.0
    RHS1      EDGE_27_67  1.0
    RHS1      EDGE_2_10  1.0
    RHS1      EDGE_54_57  1.0
    RHS1      EDGE_0_86  1.0
    RHS1      EDGE_20_64  1.0
    RHS1      EDGE_12_60  1.0
    RHS1      EDGE_13_25  1.0
    RHS1      EDGE_4_56  1.0
    RHS1      EDGE_32_38  1.0
    RHS1      EDGE_3_11  1.0
    RHS1      EDGE_34_84  1.0
    RHS1      EDGE_5_20  1.0
    RHS1      EDGE_37_89  1.0
    RHS1      EDGE_50_64  1.0
    RHS1      EDGE_69_77  1.0
    RHS1      EDGE_42_60  1.0
    RHS1      EDGE_0_63  1.0
    RHS1      EDGE_19_76  1.0
    RHS1      EDGE_20_41  1.0
    RHS1      EDGE_39_54  1.0
    RHS1      EDGE_30_85  1.0
    RHS1      EDGE_13_38  1.0
    RHS1      EDGE_23_82  1.0
    RHS1      EDGE_35_56  1.0
    RHS1      EDGE_1_63  1.0
    RHS1      EDGE_65_84  1.0
    RHS1      EDGE_38_67  1.0
    RHS1      EDGE_49_76  1.0
    RHS1      EDGE_68_89  1.0
    RHS1      EDGE_15_83  1.0
    RHS1      EDGE_7_79  1.0
    RHS1      EDGE_50_77  1.0
    RHS1      EDGE_12_50  1.0
    RHS1      EDGE_13_15  1.0
    RHS1      EDGE_4_46  1.0
    RHS1      EDGE_23_59  1.0
    RHS1      EDGE_53_87  1.0
    RHS1      EDGE_38_44  1.0
    RHS1      EDGE_6_11  1.0
    RHS1      EDGE_79_81  1.0
    RHS1      EDGE_42_50  1.0
    RHS1      EDGE_61_63  1.0
    RHS1      EDGE_8_57  1.0
    RHS1      EDGE_20_31  1.0
    RHS1      EDGE_11_62  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_33_86  1.0
    RHS1      EDGE_13_28  1.0
    RHS1      EDGE_53_64  1.0
    RHS1      EDGE_4_59  1.0
    RHS1      EDGE_24_37  1.0
    RHS1      EDGE_64_73  1.0
    RHS1      EDGE_14_72  1.0
    RHS1      EDGE_34_87  1.0
    RHS1      EDGE_38_57  1.0
    RHS1      EDGE_7_69  1.0
    RHS1      EDGE_8_34  1.0
    RHS1      EDGE_27_47  1.0
    RHS1      EDGE_0_30  1.0
    RHS1      EDGE_18_78  1.0
    RHS1      EDGE_19_43  1.0
    RHS1      EDGE_11_39  1.0
    RHS1      EDGE_63_86  1.0
    RHS1      EDGE_0_66  1.0
    RHS1      EDGE_20_44  1.0
    RHS1      EDGE_12_40  1.0
    RHS1      EDGE_44_72  1.0
    RHS1      EDGE_1_30  1.0
    RHS1      EDGE_34_64  1.0
    RHS1      EDGE_53_77  1.0
    RHS1      EDGE_45_73  1.0
    RHS1      EDGE_64_86  1.0
    RHS1      EDGE_3_76  1.0
    RHS1      EDGE_7_46  1.0
    RHS1      EDGE_18_55  1.0
    RHS1      EDGE_6_86  1.0
    RHS1      EDGE_12_17  1.0
    RHS1      EDGE_4_13  1.0
    RHS1      EDGE_33_76  1.0
    RHS1      EDGE_52_89  1.0
    RHS1      EDGE_13_18  1.0
    RHS1      EDGE_53_54  1.0
    RHS1      EDGE_45_50  1.0
    RHS1      EDGE_37_46  1.0
    RHS1      EDGE_16_23  1.0
    RHS1      EDGE_2_88  1.0
    RHS1      EDGE_14_62  1.0
    RHS1      EDGE_86_87  1.0
    RHS1      EDGE_18_32  1.0
    RHS1      EDGE_49_56  1.0
    RHS1      EDGE_7_59  1.0
    RHS1      EDGE_48_60  1.0
    RHS1      EDGE_0_20  1.0
    RHS1      EDGE_18_68  1.0
    RHS1      EDGE_30_42  1.0
    RHS1      EDGE_82_89  1.0
    RHS1      EDGE_29_83  1.0
    RHS1      EDGE_21_79  1.0
    RHS1      EDGE_41_57  1.0
    RHS1      EDGE_60_70  1.0
    RHS1      EDGE_12_30  1.0
    RHS1      EDGE_14_39  1.0
    RHS1      EDGE_25_85  1.0
    RHS1      EDGE_37_59  1.0
    RHS1      EDGE_67_87  1.0
    RHS1      EDGE_59_83  1.0
    RHS1      EDGE_21_56  1.0
    RHS1      EDGE_11_42  1.0
    RHS1      EDGE_51_83  1.0
    RHS1      EDGE_14_52  1.0
    RHS1      EDGE_15_17  1.0
    RHS1      EDGE_7_13  1.0
    RHS1      EDGE_17_63  1.0
    RHS1      EDGE_36_76  1.0
    RHS1      EDGE_28_72  1.0
    RHS1      EDGE_7_49  1.0
    RHS1      EDGE_48_50  1.0
    RHS1      EDGE_6_53  1.0
    RHS1      EDGE_41_47  1.0
    RHS1      EDGE_73_79  1.0
    RHS1      EDGE_25_39  1.0
    RHS1      EDGE_2_55  1.0
    RHS1      EDGE_3_20  1.0
    RHS1      EDGE_34_44  1.0
    RHS1      EDGE_66_76  1.0
    RHS1      EDGE_37_49  1.0
    RHS1      EDGE_3_56  1.0
    RHS1      EDGE_55_66  1.0
    RHS1      EDGE_26_39  1.0
    RHS1      EDGE_5_65  1.0
    RHS1      EDGE_70_82  1.0
    RHS1      EDGE_36_89  1.0
    RHS1      EDGE_9_72  1.0
    RHS1      EDGE_48_63  1.0
    RHS1      EDGE_21_46  1.0
    RHS1      EDGE_6_66  1.0
    RHS1      EDGE_2_32  1.0
    RHS1      EDGE_62_83  1.0
    RHS1      EDGE_33_56  1.0
    RHS1      EDGE_32_60  1.0
    RHS1      EDGE_3_33  1.0
    RHS1      EDGE_66_89  1.0
    RHS1      EDGE_17_53  1.0
    RHS1      EDGE_36_66  1.0
    RHS1      EDGE_55_79  1.0
    RHS1      EDGE_28_62  1.0
    RHS1      EDGE_29_63  1.0
    RHS1      EDGE_42_82  1.0
    RHS1      EDGE_10_49  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_55_56  1.0
    RHS1      EDGE_28_39  1.0
    RHS1      EDGE_58_67  1.0
    RHS1      EDGE_9_62  1.0
    RHS1      EDGE_28_75  1.0
    RHS1      EDGE_29_40  1.0
    RHS1      EDGE_61_72  1.0
    RHS1      EDGE_80_85  1.0
    RHS1      EDGE_73_82  1.0
    RHS1      EDGE_39_89  1.0
    RHS1      EDGE_12_72  1.0
    RHS1      EDGE_4_68  1.0
    RHS1      EDGE_23_81  1.0
    RHS1      EDGE_24_46  1.0
    RHS1      EDGE_3_23  1.0
    RHS1      EDGE_24_82  1.0
    RHS1      EDGE_16_78  1.0
    RHS1      EDGE_47_65  1.0
    RHS1      EDGE_50_76  1.0
    RHS1      EDGE_8_79  1.0
    RHS1      EDGE_20_53  1.0
    RHS1      EDGE_11_84  1.0
    RHS1      EDGE_31_62  1.0
    RHS1      EDGE_23_58  1.0
    RHS1      EDGE_54_82  1.0
    RHS1      EDGE_20_89  1.0
    RHS1      EDGE_12_85  1.0
    RHS1      EDGE_13_50  1.0
    RHS1      EDGE_32_63  1.0
    RHS1      EDGE_28_29  1.0
    RHS1      EDGE_1_75  1.0
    RHS1      EDGE_5_45  1.0
    RHS1      EDGE_17_56  1.0
    RHS1      EDGE_61_62  1.0
    RHS1      EDGE_50_89  1.0
    RHS1      EDGE_42_85  1.0
    RHS1      EDGE_62_63  1.0
    RHS1      EDGE_0_88  1.0
    RHS1      EDGE_51_53  1.0
    RHS1      EDGE_84_87  1.0
    RHS1      EDGE_35_45  1.0
    RHS1      EDGE_1_52  1.0
    RHS1      EDGE_16_68  1.0
    RHS1      EDGE_57_69  1.0
    RHS1      EDGE_76_82  1.0
    RHS1      EDGE_9_29  1.0
    RHS1      EDGE_49_65  1.0
    RHS1      EDGE_28_42  1.0
    RHS1      EDGE_15_72  1.0
    RHS1      EDGE_5_58  1.0
    RHS1      EDGE_18_77  1.0
    RHS1      EDGE_58_70  1.0
    RHS1      EDGE_50_66  1.0
    RHS1      EDGE_42_62  1.0
    RHS1      EDGE_8_69  1.0
    RHS1      EDGE_27_82  1.0
    RHS1      EDGE_20_43  1.0
    RHS1      EDGE_11_74  1.0
    RHS1      EDGE_12_39  1.0
    RHS1      EDGE_30_87  1.0
    RHS1      EDGE_12_75  1.0
    RHS1      EDGE_13_40  1.0
    RHS1      EDGE_1_65  1.0
    RHS1      EDGE_65_86  1.0
    RHS1      EDGE_49_78  1.0
    RHS1      EDGE_8_46  1.0
    RHS1      EDGE_30_64  1.0
    RHS1      EDGE_42_75  1.0
    RHS1      EDGE_0_78  1.0
    RHS1      EDGE_13_17  1.0
    RHS1      EDGE_24_26  1.0
    RHS1      EDGE_34_76  1.0
    RHS1      EDGE_45_85  1.0
    RHS1      EDGE_46_50  1.0
    RHS1      EDGE_17_23  1.0
    RHS1      EDGE_7_58  1.0
    RHS1      EDGE_26_71  1.0
    RHS1      EDGE_27_36  1.0
    RHS1      EDGE_18_67  1.0
    RHS1      EDGE_38_82  1.0
    RHS1      EDGE_79_83  1.0
    RHS1      EDGE_71_79  1.0
    RHS1      EDGE_50_56  1.0
    RHS1      EDGE_82_88  1.0
    RHS1      EDGE_20_33  1.0
    RHS1      EDGE_11_64  1.0
    RHS1      EDGE_31_42  1.0
    RHS1      EDGE_4_25  1.0
    RHS1      EDGE_23_38  1.0
    RHS1      EDGE_1_19  1.0
    RHS1      EDGE_25_84  1.0
    RHS1      EDGE_72_79  1.0
    RHS1      EDGE_56_71  1.0
    RHS1      EDGE_22_78  1.0
    RHS1      EDGE_14_74  1.0
    RHS1      EDGE_34_89  1.0
    RHS1      EDGE_67_86  1.0
    RHS1      EDGE_5_25  1.0
    RHS1      EDGE_57_72  1.0
    RHS1      EDGE_26_84  1.0
    RHS1      EDGE_0_32  1.0
    RHS1      EDGE_18_80  1.0
    RHS1      EDGE_19_45  1.0
    RHS1      EDGE_0_68  1.0
    RHS1      EDGE_4_38  1.0
    RHS1      EDGE_2_77  1.0
    RHS1      EDGE_1_32  1.0
    RHS1      EDGE_55_88  1.0
    RHS1      EDGE_29_72  1.0
    RHS1      EDGE_8_49  1.0
    RHS1      EDGE_40_81  1.0
    RHS1      EDGE_41_46  1.0
    RHS1      EDGE_20_23  1.0
    RHS1      EDGE_11_54  1.0
    RHS1      EDGE_12_19  1.0
    RHS1      EDGE_1_9  1.0
    RHS1      EDGE_25_74  1.0
    RHS1      EDGE_44_87  1.0
    RHS1      EDGE_85_88  1.0
    RHS1      EDGE_64_65  1.0
    RHS1      EDGE_22_68  1.0
    RHS1      EDGE_15_29  1.0
    RHS1      EDGE_7_25  1.0
    RHS1      EDGE_26_38  1.0
    RHS1      EDGE_67_76  1.0
    RHS1      EDGE_18_34  1.0
    RHS1      EDGE_59_72  1.0
    RHS1      EDGE_70_81  1.0
    RHS1      EDGE_28_84  1.0
    RHS1      EDGE_7_61  1.0
    RHS1      EDGE_0_22  1.0
    RHS1      EDGE_19_35  1.0
    RHS1      EDGE_30_44  1.0
    RHS1      EDGE_63_78  1.0
    RHS1      EDGE_29_85  1.0
    RHS1      EDGE_21_81  1.0
    RHS1      EDGE_34_56  1.0
    RHS1      EDGE_66_88  1.0
    RHS1      EDGE_37_61  1.0
    RHS1      EDGE_3_68  1.0
    RHS1      EDGE_15_42  1.0
    RHS1      EDGE_55_78  1.0
    RHS1      EDGE_67_89  1.0
    RHS1      EDGE_18_47  1.0
    RHS1      EDGE_17_88  1.0
    RHS1      EDGE_40_71  1.0
    RHS1      EDGE_33_68  1.0
    RHS1      EDGE_37_38  1.0
    RHS1      EDGE_51_85  1.0
    RHS1      EDGE_3_45  1.0
    RHS1      EDGE_14_54  1.0
    RHS1      EDGE_26_28  1.0
    RHS1      EDGE_36_78  1.0
    RHS1      EDGE_47_87  1.0
    RHS1      EDGE_8_16  1.0
    RHS1      EDGE_0_12  1.0
    RHS1      EDGE_6_55  1.0
    RHS1      EDGE_11_21  1.0
    RHS1      EDGE_29_75  1.0
    RHS1      EDGE_21_71  1.0
    RHS1      EDGE_81_85  1.0
    RHS1      EDGE_39_88  1.0
    RHS1      EDGE_14_31  1.0
    RHS1      EDGE_36_55  1.0
    RHS1      EDGE_55_68  1.0
    RHS1      EDGE_18_37  1.0
    RHS1      EDGE_59_75  1.0
    RHS1      EDGE_28_87  1.0
    RHS1      EDGE_54_81  1.0
    RHS1      EDGE_25_54  1.0
    RHS1      EDGE_24_58  1.0
    RHS1      EDGE_43_71  1.0
    RHS1      EDGE_17_55  1.0
    RHS1      EDGE_50_88  1.0
    RHS1      EDGE_42_84  1.0
    RHS1      EDGE_39_78  1.0
    RHS1      EDGE_31_74  1.0
    RHS1      EDGE_23_70  1.0
    RHS1      EDGE_13_62  1.0
    RHS1      EDGE_32_75  1.0
    RHS1      EDGE_43_84  1.0
    RHS1      EDGE_16_67  1.0
    RHS1      EDGE_35_80  1.0
    RHS1      EDGE_36_45  1.0
    RHS1      EDGE_76_81  1.0
    RHS1      EDGE_28_41  1.0
    RHS1      EDGE_47_54  1.0
    RHS1      EDGE_5_57  1.0
    RHS1      EDGE_6_22  1.0
    RHS1      EDGE_80_87  1.0
    RHS1      EDGE_39_55  1.0
    RHS1      EDGE_30_86  1.0
    RHS1      EDGE_62_75  1.0
    RHS1      EDGE_13_39  1.0
    RHS1      EDGE_32_52  1.0
    RHS1      EDGE_23_83  1.0
    RHS1      EDGE_43_61  1.0
    RHS1      EDGE_35_57  1.0
    RHS1      EDGE_1_64  1.0
    RHS1      EDGE_46_72  1.0
    RHS1      EDGE_17_45  1.0
    RHS1      EDGE_57_81  1.0
    RHS1      EDGE_9_41  1.0
    RHS1      EDGE_49_77  1.0
    RHS1      EDGE_15_84  1.0
    RHS1      EDGE_50_78  1.0
    RHS1      EDGE_8_81  1.0
    RHS1      EDGE_0_77  1.0
    RHS1      EDGE_12_51  1.0
    RHS1      EDGE_31_64  1.0
    RHS1      EDGE_23_60  1.0
    RHS1      EDGE_12_87  1.0
    RHS1      EDGE_13_52  1.0
    RHS1      EDGE_53_88  1.0
    RHS1      EDGE_35_70  1.0
    RHS1      EDGE_9_18  1.0
    RHS1      EDGE_5_47  1.0
    RHS1      EDGE_6_12  1.0
    RHS1      EDGE_27_71  1.0
    RHS1      EDGE_42_87  1.0
    RHS1      EDGE_83_88  1.0
    RHS1      EDGE_75_84  1.0
    RHS1      EDGE_20_68  1.0
    RHS1      EDGE_31_77  1.0
    RHS1      EDGE_72_78  1.0
    RHS1      EDGE_23_73  1.0
    RHS1      EDGE_24_38  1.0
    RHS1      EDGE_16_34  1.0
    RHS1      EDGE_65_75  1.0
    RHS1      EDGE_17_35  1.0
    RHS1      EDGE_9_31  1.0
    RHS1      EDGE_49_67  1.0
    RHS1      EDGE_26_83  1.0
    RHS1      EDGE_6_25  1.0
    RHS1      EDGE_30_53  1.0
    RHS1      EDGE_42_64  1.0
    RHS1      EDGE_60_81  1.0
    RHS1      EDGE_39_58  1.0
    RHS1      EDGE_23_50  1.0
    RHS1      EDGE_1_31  1.0
    RHS1      EDGE_34_65  1.0
    RHS1      EDGE_24_51  1.0
    RHS1      EDGE_37_70  1.0
    RHS1      EDGE_14_86  1.0
    RHS1      EDGE_26_60  1.0
    RHS1      EDGE_46_75  1.0
    RHS1      EDGE_38_71  1.0
    RHS1      EDGE_49_80  1.0
    RHS1      EDGE_15_87  1.0
    RHS1      EDGE_8_48  1.0
    RHS1      EDGE_19_57  1.0
    RHS1      EDGE_2_4  1.0
    RHS1      EDGE_1_8  1.0
    RHS1      EDGE_20_58  1.0
    RHS1      EDGE_13_19  1.0
    RHS1      EDGE_53_55  1.0
    RHS1      EDGE_23_63  1.0
    RHS1      EDGE_56_60  1.0
    RHS1      EDGE_34_78  1.0
    RHS1      EDGE_37_83  1.0
    RHS1      EDGE_57_61  1.0
    RHS1      EDGE_9_21  1.0
    RHS1      EDGE_18_69  1.0
    RHS1      EDGE_8_61  1.0
    RHS1      EDGE_11_66  1.0
    RHS1      EDGE_12_31  1.0
    RHS1      EDGE_52_67  1.0
    RHS1      EDGE_1_21  1.0
    RHS1      EDGE_22_80  1.0
    RHS1      EDGE_15_41  1.0
    RHS1      EDGE_18_46  1.0
    RHS1      EDGE_15_77  1.0
    RHS1      EDGE_7_73  1.0
    RHS1      EDGE_8_38  1.0
    RHS1      EDGE_19_47  1.0
    RHS1      EDGE_60_84  1.0
    RHS1      EDGE_52_80  1.0
    RHS1      EDGE_4_40  1.0
    RHS1      EDGE_10_83  1.0
    RHS1      EDGE_2_79  1.0
    RHS1      EDGE_22_57  1.0
    RHS1      EDGE_7_50  1.0
    RHS1      EDGE_8_15  1.0
    RHS1      EDGE_26_63  1.0
    RHS1      EDGE_27_28  1.0
    RHS1      EDGE_63_67  1.0
    RHS1      EDGE_21_70  1.0
    RHS1      EDGE_40_83  1.0
    RHS1      EDGE_60_61  1.0
    RHS1      EDGE_41_84  1.0
    RHS1      EDGE_33_80  1.0
    RHS1      EDGE_34_45  1.0
    RHS1      EDGE_53_58  1.0
    RHS1      EDGE_44_89  1.0
    RHS1      EDGE_45_54  1.0
    RHS1      EDGE_56_63  1.0
    RHS1      EDGE_22_70  1.0
    RHS1      EDGE_15_31  1.0
    RHS1      EDGE_7_27  1.0
    RHS1      EDGE_18_36  1.0
    RHS1      EDGE_28_86  1.0
    RHS1      EDGE_8_28  1.0
    RHS1      EDGE_48_64  1.0
    RHS1      EDGE_0_24  1.0
    RHS1      EDGE_40_60  1.0
    RHS1      EDGE_11_33  1.0
    RHS1      EDGE_63_80  1.0
    RHS1      EDGE_41_61  1.0
    RHS1      EDGE_44_66  1.0
    RHS1      EDGE_2_69  1.0
    RHS1      EDGE_13_84  1.0
    RHS1      EDGE_15_44  1.0
    RHS1      EDGE_55_80  1.0
    RHS1      EDGE_18_49  1.0
    RHS1      EDGE_29_64  1.0
    RHS1      EDGE_40_73  1.0
    RHS1      EDGE_6_80  1.0
    RHS1      EDGE_4_7  1.0
    RHS1      EDGE_2_46  1.0
    RHS1      EDGE_22_24  1.0
    RHS1      EDGE_32_74  1.0
    RHS1      EDGE_14_56  1.0
    RHS1      EDGE_1_86  1.0
    RHS1      EDGE_7_17  1.0
    RHS1      EDGE_67_68  1.0
    RHS1      EDGE_59_64  1.0
    RHS1      EDGE_70_73  1.0
    RHS1      EDGE_17_67  1.0
    RHS1      EDGE_36_80  1.0
    RHS1      EDGE_48_54  1.0
    RHS1      EDGE_21_37  1.0
    RHS1      EDGE_25_43  1.0
    RHS1      EDGE_31_86  1.0
    RHS1      EDGE_10_63  1.0
    RHS1      EDGE_51_64  1.0
    RHS1      EDGE_43_60  1.0
    RHS1      EDGE_22_37  1.0
    RHS1      EDGE_14_33  1.0
    RHS1      EDGE_74_84  1.0
    RHS1      EDGE_24_83  1.0
    RHS1      EDGE_28_53  1.0
    RHS1      EDGE_7_30  1.0
    RHS1      EDGE_47_66  1.0
    RHS1      EDGE_6_34  1.0
    RHS1      EDGE_21_50  1.0
    RHS1      EDGE_6_70  1.0
    RHS1      EDGE_2_36  1.0
    RHS1      EDGE_54_83  1.0
    RHS1      EDGE_12_86  1.0
    RHS1      EDGE_4_82  1.0
    RHS1      EDGE_51_77  1.0
    RHS1      EDGE_5_46  1.0
    RHS1      EDGE_9_53  1.0
    RHS1      EDGE_29_31  1.0
    RHS1      EDGE_10_17  1.0
    RHS1      EDGE_12_63  1.0
    RHS1      EDGE_32_41  1.0
    RHS1      EDGE_23_72  1.0
    RHS1      EDGE_22_27  1.0
    RHS1      EDGE_35_46  1.0
    RHS1      EDGE_76_83  1.0
    RHS1      EDGE_9_30  1.0
    RHS1      EDGE_1_89  1.0
    RHS1      EDGE_58_71  1.0
    RHS1      EDGE_9_66  1.0
    RHS1      EDGE_27_83  1.0
    RHS1      EDGE_10_30  1.0
    RHS1      EDGE_62_77  1.0
    RHS1      EDGE_13_41  1.0
    RHS1      EDGE_31_89  1.0
    RHS1      EDGE_51_67  1.0
    RHS1      EDGE_24_50  1.0
    RHS1      EDGE_43_63  1.0
    RHS1      EDGE_16_46  1.0
    RHS1      EDGE_35_59  1.0
    RHS1      EDGE_1_66  1.0
    RHS1      EDGE_5_36  1.0
    RHS1      EDGE_17_47  1.0
    RHS1      EDGE_57_83  1.0
    RHS1      EDGE_49_79  1.0
    RHS1      EDGE_6_37  1.0
    RHS1      EDGE_30_65  1.0
    RHS1      EDGE_50_80  1.0
    RHS1      EDGE_2_3  1.0
    RHS1      EDGE_31_66  1.0
    RHS1      EDGE_3_4  1.0
    RHS1      EDGE_35_36  1.0
    RHS1      EDGE_24_63  1.0
    RHS1      EDGE_57_60  1.0
    RHS1      EDGE_36_37  1.0
    RHS1      EDGE_9_20  1.0
    RHS1      EDGE_5_49  1.0
    RHS1      EDGE_6_14  1.0
    RHS1      EDGE_46_87  1.0
    RHS1      EDGE_50_57  1.0
    RHS1      EDGE_69_70  1.0
    RHS1      EDGE_21_30  1.0
    RHS1      EDGE_61_66  1.0
    RHS1      EDGE_8_60  1.0
    RHS1      EDGE_20_34  1.0
    RHS1      EDGE_75_86  1.0
    RHS1      EDGE_54_63  1.0
    RHS1      EDGE_20_70  1.0
    RHS1      EDGE_72_80  1.0
    RHS1      EDGE_23_75  1.0
    RHS1      EDGE_56_72  1.0
    RHS1      EDGE_22_79  1.0
    RHS1      EDGE_1_56  1.0
    RHS1      EDGE_46_64  1.0
    RHS1      EDGE_65_77  1.0
    RHS1      EDGE_76_86  1.0
    RHS1      EDGE_49_69  1.0
    RHS1      EDGE_68_82  1.0
    RHS1      EDGE_15_76  1.0
    RHS1      EDGE_50_70  1.0
    RHS1      EDGE_63_89  1.0
    RHS1      EDGE_19_82  1.0
    RHS1      EDGE_39_60  1.0
    RHS1      EDGE_52_79  1.0
    RHS1      EDGE_13_44  1.0
    RHS1      EDGE_3_79  1.0
    RHS1      EDGE_5_39  1.0
    RHS1      EDGE_46_77  1.0
    RHS1      EDGE_49_82  1.0
    RHS1      EDGE_8_50  1.0
    RHS1      EDGE_48_86  1.0
    RHS1      EDGE_0_46  1.0
    RHS1      EDGE_19_59  1.0
    RHS1      EDGE_11_55  1.0
    RHS1      EDGE_12_20  1.0
    RHS1      EDGE_31_33  1.0
    RHS1      EDGE_75_76  1.0
    RHS1      EDGE_12_56  1.0
    RHS1      EDGE_53_57  1.0
    RHS1      EDGE_45_53  1.0
    RHS1      EDGE_24_30  1.0
    RHS1      EDGE_16_26  1.0
    RHS1      EDGE_1_46  1.0
    RHS1      EDGE_46_54  1.0
    RHS1      EDGE_38_50  1.0
    RHS1      EDGE_78_86  1.0
    RHS1      EDGE_49_59  1.0
    RHS1      EDGE_7_62  1.0
    RHS1      EDGE_8_27  1.0
    RHS1      EDGE_18_71  1.0
    RHS1      EDGE_11_32  1.0
    RHS1      EDGE_30_45  1.0
    RHS1      EDGE_71_83  1.0
    RHS1      EDGE_63_79  1.0
    RHS1      EDGE_29_86  1.0
    RHS1      EDGE_20_37  1.0
    RHS1      EDGE_60_73  1.0
    RHS1      EDGE_23_42  1.0
    RHS1      EDGE_34_57  1.0
    RHS1      EDGE_25_88  1.0
    RHS1      EDGE_64_79  1.0
    RHS1      EDGE_56_75  1.0
    RHS1      EDGE_26_52  1.0
    RHS1      EDGE_59_86  1.0
    RHS1      EDGE_17_89  1.0
    RHS1      EDGE_7_75  1.0
    RHS1      EDGE_27_53  1.0
    RHS1      EDGE_0_36  1.0
    RHS1      EDGE_40_72  1.0
    RHS1      EDGE_41_73  1.0
    RHS1      EDGE_33_69  1.0
    RHS1      EDGE_37_39  1.0
    RHS1      EDGE_22_59  1.0
    RHS1      EDGE_34_70  1.0
    RHS1      EDGE_38_40  1.0
    RHS1      EDGE_3_82  1.0
    RHS1      EDGE_36_79  1.0
    RHS1      EDGE_15_56  1.0
    RHS1      EDGE_8_17  1.0
    RHS1      EDGE_26_65  1.0
    RHS1      EDGE_30_35  1.0
    RHS1      EDGE_71_73  1.0
    RHS1      EDGE_29_76  1.0
    RHS1      EDGE_40_85  1.0
    RHS1      EDGE_41_50  1.0
    RHS1      EDGE_52_59  1.0
    RHS1      EDGE_44_55  1.0
    RHS1      EDGE_10_62  1.0
    RHS1      EDGE_1_13  1.0
    RHS1      EDGE_33_82  1.0
    RHS1      EDGE_74_83  1.0
    RHS1      EDGE_25_78  1.0
    RHS1      EDGE_32_86  1.0
    RHS1      EDGE_37_52  1.0
    RHS1      EDGE_22_72  1.0
    RHS1      EDGE_55_69  1.0
    RHS1      EDGE_7_29  1.0
    RHS1      EDGE_70_85  1.0
    RHS1      EDGE_17_79  1.0
    RHS1      EDGE_40_62  1.0
    RHS1      EDGE_11_35  1.0
    RHS1      EDGE_63_82  1.0
    RHS1      EDGE_29_89  1.0
    RHS1      EDGE_21_85  1.0
    RHS1      EDGE_33_59  1.0
    RHS1      EDGE_52_72  1.0
    RHS1      EDGE_44_68  1.0
    RHS1      EDGE_10_75  1.0
    RHS1      EDGE_51_76  1.0
    RHS1      EDGE_3_36  1.0
    RHS1      EDGE_13_86  1.0
    RHS1      EDGE_47_78  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_11_12  1.0
    RHS1      EDGE_21_62  1.0
    RHS1      EDGE_40_75  1.0
    RHS1      EDGE_33_36  1.0
    RHS1      EDGE_2_48  1.0
    RHS1      EDGE_22_26  1.0
    RHS1      EDGE_66_69  1.0
    RHS1      EDGE_32_76  1.0
    RHS1      EDGE_24_72  1.0
    RHS1      EDGE_15_23  1.0
    RHS1      EDGE_55_59  1.0
    RHS1      EDGE_1_88  1.0
    RHS1      EDGE_47_55  1.0
    RHS1      EDGE_18_28  1.0
    RHS1      EDGE_70_75  1.0
    RHS1      EDGE_29_43  1.0
    RHS1      EDGE_10_29  1.0
    RHS1      EDGE_81_89  1.0
    RHS1      EDGE_54_72  1.0
    RHS1      EDGE_73_85  1.0
    RHS1      EDGE_25_45  1.0
    RHS1      EDGE_23_84  1.0
    RHS1      EDGE_51_66  1.0
    RHS1      EDGE_2_61  1.0
    RHS1      EDGE_43_62  1.0
    RHS1      EDGE_14_35  1.0
    RHS1      EDGE_66_82  1.0
    RHS1      EDGE_36_59  1.0
    RHS1      EDGE_47_68  1.0
    RHS1      EDGE_6_36  1.0
    RHS1      EDGE_17_82  1.0
    RHS1      EDGE_58_83  1.0
    RHS1      EDGE_29_56  1.0
    RHS1      EDGE_21_52  1.0
    RHS1      EDGE_35_71  1.0
    RHS1      EDGE_9_55  1.0
    RHS1      EDGE_21_29  1.0
    RHS1      EDGE_40_42  1.0
    RHS1      EDGE_5_84  1.0
    RHS1      EDGE_6_49  1.0
    RHS1      EDGE_73_75  1.0
    RHS1      EDGE_20_69  1.0
    RHS1      EDGE_39_82  1.0
    RHS1      EDGE_32_43  1.0
    RHS1      EDGE_23_74  1.0
    RHS1      EDGE_3_16  1.0
    RHS1      EDGE_43_52  1.0
    RHS1      EDGE_35_48  1.0
    RHS1      EDGE_14_25  1.0
    RHS1      EDGE_47_58  1.0
    RHS1      EDGE_61_78  1.0
    RHS1      EDGE_20_46  1.0
    RHS1      EDGE_39_59  1.0
    RHS1      EDGE_31_55  1.0
    RHS1      EDGE_54_75  1.0
    RHS1      EDGE_4_74  1.0
    RHS1      EDGE_23_87  1.0
    RHS1      EDGE_24_52  1.0
    RHS1      EDGE_64_88  1.0
    RHS1      EDGE_16_48  1.0
    RHS1      EDGE_15_88  1.0
    RHS1      EDGE_27_62  1.0
    RHS1      EDGE_6_39  1.0
    RHS1      EDGE_50_82  1.0
    RHS1      EDGE_42_78  1.0
    RHS1      EDGE_2_5  1.0
    RHS1      EDGE_31_68  1.0
    RHS1      EDGE_23_64  1.0
    RHS1      EDGE_16_25  1.0
    RHS1      EDGE_35_38  1.0
    RHS1      EDGE_34_79  1.0
    RHS1      EDGE_13_56  1.0
    RHS1      EDGE_45_88  1.0
    RHS1      EDGE_5_15  1.0
    RHS1      EDGE_37_84  1.0
    RHS1      EDGE_16_61  1.0
    RHS1      EDGE_57_62  1.0
    RHS1      EDGE_36_39  1.0
    RHS1      EDGE_26_74  1.0
    RHS1      EDGE_5_51  1.0
    RHS1      EDGE_50_59  1.0
    RHS1      EDGE_69_72  1.0
    RHS1      EDGE_19_71  1.0
    RHS1      EDGE_75_88  1.0
    RHS1      EDGE_1_22  1.0
    RHS1      EDGE_12_68  1.0
    RHS1      EDGE_13_33  1.0
    RHS1      EDGE_53_69  1.0
    RHS1      EDGE_4_64  1.0
    RHS1      EDGE_16_38  1.0
    RHS1      EDGE_35_51  1.0
    RHS1      EDGE_1_58  1.0
    RHS1      EDGE_5_28  1.0
    RHS1      EDGE_65_79  1.0
    RHS1      EDGE_38_62  1.0
    RHS1      EDGE_26_87  1.0
    RHS1      EDGE_27_52  1.0
    RHS1      EDGE_18_83  1.0
    RHS1      EDGE_19_48  1.0
    RHS1      EDGE_11_44  1.0
    RHS1      EDGE_20_49  1.0
    RHS1      EDGE_11_80  1.0
    RHS1      EDGE_44_77  1.0
    RHS1      EDGE_1_35  1.0
    RHS1      EDGE_53_82  1.0
    RHS1      EDGE_45_78  1.0
    RHS1      EDGE_38_39  1.0
    RHS1      EDGE_9_12  1.0
    RHS1      EDGE_15_55  1.0
    RHS1      EDGE_38_75  1.0
    RHS1      EDGE_7_87  1.0
    RHS1      EDGE_20_26  1.0
    RHS1      EDGE_11_57  1.0
    RHS1      EDGE_30_70  1.0
    RHS1      EDGE_23_31  1.0
    RHS1      EDGE_34_46  1.0
    RHS1      EDGE_13_23  1.0
    RHS1      EDGE_25_77  1.0
    RHS1      EDGE_4_54  1.0
    RHS1      EDGE_64_68  1.0
    RHS1      EDGE_46_56  1.0
    RHS1      EDGE_38_52  1.0
    RHS1      EDGE_7_64  1.0
    RHS1      EDGE_18_73  1.0
    RHS1      EDGE_19_38  1.0
    RHS1      EDGE_21_84  1.0
    RHS1      EDGE_41_62  1.0
    RHS1      EDGE_52_71  1.0
    RHS1      EDGE_1_25  1.0
    RHS1      EDGE_34_59  1.0
    RHS1      EDGE_3_71  1.0
    RHS1      EDGE_22_84  1.0
    RHS1      EDGE_14_80  1.0
    RHS1      EDGE_15_45  1.0
    RHS1      EDGE_55_81  1.0
    RHS1      EDGE_7_41  1.0
    RHS1      EDGE_11_47  1.0
    RHS1      EDGE_4_8  1.0
    RHS1      EDGE_1_2  1.0
    RHS1      EDGE_22_61  1.0
    RHS1      EDGE_15_22  1.0
    RHS1      EDGE_67_69  1.0
    RHS1      EDGE_18_27  1.0
    RHS1      EDGE_8_19  1.0
    RHS1      EDGE_30_37  1.0
    RHS1      EDGE_71_75  1.0
    RHS1      EDGE_63_71  1.0
    RHS1      EDGE_82_84  1.0
    RHS1      EDGE_29_78  1.0
    RHS1      EDGE_33_48  1.0
    RHS1      EDGE_25_44  1.0
    RHS1      EDGE_4_21  1.0
    RHS1      EDGE_10_64  1.0
    RHS1      EDGE_14_34  1.0
    RHS1      EDGE_34_49  1.0
    RHS1      EDGE_66_81  1.0
    RHS1      EDGE_32_88  1.0
    RHS1      EDGE_24_84  1.0
    RHS1      EDGE_15_35  1.0
    RHS1      EDGE_29_55  1.0
    RHS1      EDGE_48_68  1.0
    RHS1      EDGE_21_51  1.0
    RHS1      EDGE_25_57  1.0
    RHS1      EDGE_10_77  1.0
    RHS1      EDGE_51_78  1.0
    RHS1      EDGE_43_74  1.0
    RHS1      EDGE_14_47  1.0
    RHS1      EDGE_7_8  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
 BV BND1      x_80
 BV BND1      x_81
 BV BND1      x_82
 BV BND1      x_83
 BV BND1      x_84
 BV BND1      x_85
 BV BND1      x_86
 BV BND1      x_87
 BV BND1      x_88
 BV BND1      x_89
ENDATA
