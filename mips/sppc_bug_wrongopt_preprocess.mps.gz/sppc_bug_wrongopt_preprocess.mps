NAME          sppc_bug_wrongopt_preprocess
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 L  PACK_0
 L  PACK_1
 G  COVER_0
 G  COVER_1
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0             OBJ           13
    x_0             PART_0          1.0
    x_0             COVER_0         1.0
    x_1             OBJ           8
    x_1             PART_0          1.0
    x_1             PACK_0          1.0
    x_1             PACK_1          1.0
    x_2             OBJ           20
    x_2             PART_1          1.0
    x_3             OBJ           25
    x_3             PART_1          1.0
    x_3             COVER_1         1.0
    x_4             OBJ           17
    x_4             PART_1          1.0
    x_4             PACK_0          1.0
    x_4             COVER_0         1.0
    x_4             COVER_1         1.0
    x_5             OBJ           20
    x_5             PART_2          1.0
    x_5             COVER_0         1.0
    x_6             OBJ           5
    x_6             PART_2          1.0
    x_6             PACK_0          1.0
    x_6             PACK_1          1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           PART_0          1.0
    RHS           PART_1          1.0
    RHS           PART_2          1.0
    RHS           PACK_0          1.0
    RHS           PACK_1          1.0
    RHS           COVER_0         1.0
    RHS           COVER_1         1.0
BOUNDS
 BV BOUND         x_0
 BV BOUND         x_1
 BV BOUND         x_2
 BV BOUND         x_3
 BV BOUND         x_4
 BV BOUND         x_5
 BV BOUND         x_6
ENDATA
