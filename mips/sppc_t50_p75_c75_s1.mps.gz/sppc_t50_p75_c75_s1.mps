NAME          sppc_t50_p75_c75_s1
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 E  PART_4
 E  PART_5
 E  PART_6
 E  PART_7
 E  PART_8
 E  PART_9
 E  PART_10
 E  PART_11
 E  PART_12
 E  PART_13
 E  PART_14
 E  PART_15
 E  PART_16
 E  PART_17
 E  PART_18
 E  PART_19
 E  PART_20
 E  PART_21
 E  PART_22
 E  PART_23
 E  PART_24
 E  PART_25
 E  PART_26
 E  PART_27
 E  PART_28
 E  PART_29
 E  PART_30
 E  PART_31
 E  PART_32
 E  PART_33
 E  PART_34
 E  PART_35
 E  PART_36
 E  PART_37
 E  PART_38
 E  PART_39
 E  PART_40
 E  PART_41
 E  PART_42
 E  PART_43
 E  PART_44
 E  PART_45
 E  PART_46
 E  PART_47
 E  PART_48
 E  PART_49
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
 L  PACK_20
 L  PACK_21
 L  PACK_22
 L  PACK_23
 L  PACK_24
 L  PACK_25
 L  PACK_26
 L  PACK_27
 L  PACK_28
 L  PACK_29
 L  PACK_30
 L  PACK_31
 L  PACK_32
 L  PACK_33
 L  PACK_34
 L  PACK_35
 L  PACK_36
 L  PACK_37
 L  PACK_38
 L  PACK_39
 L  PACK_40
 L  PACK_41
 L  PACK_42
 L  PACK_43
 L  PACK_44
 L  PACK_45
 L  PACK_46
 L  PACK_47
 L  PACK_48
 L  PACK_49
 L  PACK_50
 L  PACK_51
 L  PACK_52
 L  PACK_53
 L  PACK_54
 L  PACK_55
 L  PACK_56
 L  PACK_57
 L  PACK_58
 L  PACK_59
 L  PACK_60
 L  PACK_61
 L  PACK_62
 L  PACK_63
 L  PACK_64
 L  PACK_65
 L  PACK_66
 L  PACK_67
 L  PACK_68
 L  PACK_69
 L  PACK_70
 L  PACK_71
 L  PACK_72
 L  PACK_73
 L  PACK_74
 G  COVER_0
 G  COVER_1
 G  COVER_2
 G  COVER_3
 G  COVER_4
 G  COVER_5
 G  COVER_6
 G  COVER_7
 G  COVER_8
 G  COVER_9
 G  COVER_10
 G  COVER_11
 G  COVER_12
 G  COVER_13
 G  COVER_14
 G  COVER_15
 G  COVER_16
 G  COVER_17
 G  COVER_18
 G  COVER_19
 G  COVER_20
 G  COVER_21
 G  COVER_22
 G  COVER_23
 G  COVER_24
 G  COVER_25
 G  COVER_26
 G  COVER_27
 G  COVER_28
 G  COVER_29
 G  COVER_30
 G  COVER_31
 G  COVER_32
 G  COVER_33
 G  COVER_34
 G  COVER_35
 G  COVER_36
 G  COVER_37
 G  COVER_38
 G  COVER_39
 G  COVER_40
 G  COVER_41
 G  COVER_42
 G  COVER_43
 G  COVER_44
 G  COVER_45
 G  COVER_46
 G  COVER_47
 G  COVER_48
 G  COVER_49
 G  COVER_50
 G  COVER_51
 G  COVER_52
 G  COVER_53
 G  COVER_54
 G  COVER_55
 G  COVER_56
 G  COVER_57
 G  COVER_58
 G  COVER_59
 G  COVER_60
 G  COVER_61
 G  COVER_62
 G  COVER_63
 G  COVER_64
 G  COVER_65
 G  COVER_66
 G  COVER_67
 G  COVER_68
 G  COVER_69
 G  COVER_70
 G  COVER_71
 G  COVER_72
 G  COVER_73
 G  COVER_74
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0             OBJ           26
    x_0             PART_0          1.0
    x_0             COVER_4         1.0
    x_0             COVER_12        1.0
    x_0             COVER_24        1.0
    x_0             COVER_44        1.0
    x_0             COVER_58        1.0
    x_1             OBJ           8
    x_1             PART_0          1.0
    x_1             PACK_19         1.0
    x_1             PACK_30         1.0
    x_1             COVER_16        1.0
    x_1             COVER_35        1.0
    x_1             COVER_39        1.0
    x_1             COVER_64        1.0
    x_1             COVER_70        1.0
    x_2             OBJ           20
    x_2             PART_0          1.0
    x_2             PACK_36         1.0
    x_2             PACK_55         1.0
    x_3             OBJ           19
    x_3             PART_0          1.0
    x_3             COVER_60        1.0
    x_3             COVER_74        1.0
    x_4             OBJ           17
    x_4             PART_1          1.0
    x_4             PACK_57         1.0
    x_4             COVER_22        1.0
    x_5             OBJ           11
    x_5             PART_1          1.0
    x_5             PACK_27         1.0
    x_5             PACK_59         1.0
    x_5             PACK_61         1.0
    x_5             PACK_68         1.0
    x_5             COVER_16        1.0
    x_5             COVER_25        1.0
    x_5             COVER_66        1.0
    x_6             OBJ           8
    x_6             PART_1          1.0
    x_6             PACK_13         1.0
    x_6             PACK_26         1.0
    x_6             PACK_49         1.0
    x_6             PACK_70         1.0
    x_6             COVER_48        1.0
    x_6             COVER_67        1.0
    x_7             OBJ           20
    x_7             PART_1          1.0
    x_7             PACK_15         1.0
    x_7             COVER_51        1.0
    x_7             COVER_69        1.0
    x_8             OBJ           5
    x_8             PART_1          1.0
    x_8             PACK_22         1.0
    x_8             PACK_41         1.0
    x_8             PACK_69         1.0
    x_8             PACK_73         1.0
    x_8             COVER_45        1.0
    x_8             COVER_58        1.0
    x_9             OBJ           28
    x_9             PART_1          1.0
    x_9             PACK_47         1.0
    x_9             COVER_26        1.0
    x_9             COVER_27        1.0
    x_9             COVER_41        1.0
    x_10            OBJ           5
    x_10            PART_2          1.0
    x_10            PACK_13         1.0
    x_10            PACK_21         1.0
    x_10            PACK_36         1.0
    x_10            PACK_59         1.0
    x_11            OBJ           19
    x_11            PART_2          1.0
    x_11            PACK_58         1.0
    x_11            PACK_65         1.0
    x_11            COVER_55        1.0
    x_12            OBJ           13
    x_12            PART_2          1.0
    x_12            PACK_5          1.0
    x_12            PACK_15         1.0
    x_12            PACK_68         1.0
    x_12            COVER_5         1.0
    x_12            COVER_21        1.0
    x_13            OBJ           12
    x_13            PART_2          1.0
    x_13            COVER_11        1.0
    x_13            COVER_48        1.0
    x_14            OBJ           23
    x_14            PART_2          1.0
    x_14            COVER_17        1.0
    x_14            COVER_21        1.0
    x_14            COVER_49        1.0
    x_14            COVER_53        1.0
    x_15            OBJ           15
    x_15            PART_2          1.0
    x_15            COVER_36        1.0
    x_16            OBJ           22
    x_16            PART_3          1.0
    x_16            PACK_67         1.0
    x_16            COVER_1         1.0
    x_16            COVER_41        1.0
    x_17            OBJ           22
    x_17            PART_3          1.0
    x_17            PACK_9          1.0
    x_17            COVER_32        1.0
    x_18            OBJ           5
    x_18            PART_3          1.0
    x_18            COVER_35        1.0
    x_19            OBJ           11
    x_19            PART_4          1.0
    x_19            PACK_44         1.0
    x_19            PACK_45         1.0
    x_20            OBJ           18
    x_20            PART_4          1.0
    x_20            PACK_31         1.0
    x_20            COVER_0         1.0
    x_21            OBJ           5
    x_21            PART_4          1.0
    x_21            PACK_14         1.0
    x_21            PACK_46         1.0
    x_21            PACK_57         1.0
    x_21            COVER_0         1.0
    x_21            COVER_22        1.0
    x_22            OBJ           21
    x_22            PART_4          1.0
    x_22            PACK_13         1.0
    x_22            PACK_35         1.0
    x_22            PACK_42         1.0
    x_22            COVER_29        1.0
    x_23            OBJ           12
    x_23            PART_4          1.0
    x_23            PACK_20         1.0
    x_23            COVER_32        1.0
    x_23            COVER_72        1.0
    x_24            OBJ           29
    x_24            PART_4          1.0
    x_24            PACK_25         1.0
    x_24            PACK_73         1.0
    x_24            COVER_5         1.0
    x_24            COVER_26        1.0
    x_24            COVER_72        1.0
    x_25            OBJ           12
    x_25            PART_5          1.0
    x_25            COVER_54        1.0
    x_26            OBJ           16
    x_26            PART_5          1.0
    x_26            PACK_6          1.0
    x_26            PACK_7          1.0
    x_26            PACK_48         1.0
    x_26            COVER_48        1.0
    x_27            OBJ           12
    x_27            PART_5          1.0
    x_27            COVER_74        1.0
    x_28            OBJ           12
    x_28            PART_5          1.0
    x_28            PACK_15         1.0
    x_28            PACK_53         1.0
    x_28            COVER_21        1.0
    x_28            COVER_34        1.0
    x_29            OBJ           29
    x_29            PART_5          1.0
    x_29            PACK_16         1.0
    x_29            COVER_41        1.0
    x_30            OBJ           14
    x_30            PART_5          1.0
    x_30            PACK_9          1.0
    x_30            PACK_30         1.0
    x_30            PACK_68         1.0
    x_31            OBJ           22
    x_31            PART_6          1.0
    x_31            PACK_19         1.0
    x_31            PACK_31         1.0
    x_31            PACK_49         1.0
    x_31            PACK_51         1.0
    x_31            COVER_23        1.0
    x_31            COVER_34        1.0
    x_32            OBJ           23
    x_32            PART_6          1.0
    x_32            PACK_37         1.0
    x_32            COVER_27        1.0
    x_32            COVER_59        1.0
    x_33            OBJ           10
    x_33            PART_6          1.0
    x_33            PACK_18         1.0
    x_33            PACK_32         1.0
    x_33            COVER_61        1.0
    x_34            OBJ           27
    x_34            PART_7          1.0
    x_34            PACK_49         1.0
    x_34            PACK_70         1.0
    x_34            COVER_29        1.0
    x_34            COVER_61        1.0
    x_35            OBJ           21
    x_35            PART_7          1.0
    x_35            PACK_2          1.0
    x_35            PACK_3          1.0
    x_35            COVER_15        1.0
    x_35            COVER_18        1.0
    x_36            OBJ           18
    x_36            PART_7          1.0
    x_36            PACK_59         1.0
    x_36            COVER_13        1.0
    x_36            COVER_20        1.0
    x_36            COVER_45        1.0
    x_36            COVER_52        1.0
    x_37            OBJ           21
    x_37            PART_7          1.0
    x_37            PACK_19         1.0
    x_37            PACK_23         1.0
    x_37            PACK_41         1.0
    x_37            COVER_17        1.0
    x_37            COVER_63        1.0
    x_38            OBJ           11
    x_38            PART_7          1.0
    x_38            PACK_20         1.0
    x_39            OBJ           20
    x_39            PART_8          1.0
    x_39            PACK_4          1.0
    x_39            PACK_21         1.0
    x_39            PACK_62         1.0
    x_39            PACK_71         1.0
    x_39            COVER_13        1.0
    x_39            COVER_17        1.0
    x_39            COVER_28        1.0
    x_39            COVER_31        1.0
    x_39            COVER_59        1.0
    x_39            COVER_60        1.0
    x_39            COVER_73        1.0
    x_40            OBJ           21
    x_40            PART_8          1.0
    x_40            PACK_31         1.0
    x_40            PACK_73         1.0
    x_41            OBJ           28
    x_41            PART_8          1.0
    x_41            COVER_49        1.0
    x_42            OBJ           6
    x_42            PART_8          1.0
    x_42            COVER_46        1.0
    x_43            OBJ           20
    x_43            PART_8          1.0
    x_43            PACK_54         1.0
    x_43            PACK_56         1.0
    x_43            PACK_59         1.0
    x_43            COVER_5         1.0
    x_43            COVER_44        1.0
    x_44            OBJ           18
    x_44            PART_9          1.0
    x_44            PACK_17         1.0
    x_44            COVER_65        1.0
    x_45            OBJ           10
    x_45            PART_9          1.0
    x_45            PACK_71         1.0
    x_45            COVER_70        1.0
    x_46            OBJ           16
    x_46            PART_9          1.0
    x_46            PACK_52         1.0
    x_46            COVER_24        1.0
    x_47            OBJ           30
    x_47            PART_9          1.0
    x_47            PACK_28         1.0
    x_47            PACK_36         1.0
    x_47            COVER_7         1.0
    x_47            COVER_17        1.0
    x_47            COVER_47        1.0
    x_47            COVER_66        1.0
    x_48            OBJ           29
    x_48            PART_10         1.0
    x_48            COVER_10        1.0
    x_48            COVER_28        1.0
    x_48            COVER_37        1.0
    x_48            COVER_45        1.0
    x_48            COVER_46        1.0
    x_48            COVER_67        1.0
    x_49            OBJ           21
    x_49            PART_10         1.0
    x_49            PACK_36         1.0
    x_50            OBJ           8
    x_50            PART_10         1.0
    x_50            PACK_41         1.0
    x_50            COVER_22        1.0
    x_51            OBJ           10
    x_51            PART_10         1.0
    x_51            PACK_25         1.0
    x_51            COVER_1         1.0
    x_52            OBJ           21
    x_52            PART_10         1.0
    x_52            PACK_4          1.0
    x_52            PACK_8          1.0
    x_52            PACK_34         1.0
    x_52            COVER_14        1.0
    x_53            OBJ           20
    x_53            PART_11         1.0
    x_53            PACK_20         1.0
    x_53            PACK_42         1.0
    x_53            PACK_43         1.0
    x_53            COVER_44        1.0
    x_54            OBJ           5
    x_54            PART_11         1.0
    x_54            PACK_37         1.0
    x_54            COVER_20        1.0
    x_55            OBJ           29
    x_55            PART_11         1.0
    x_55            COVER_22        1.0
    x_55            COVER_38        1.0
    x_55            COVER_65        1.0
    x_56            OBJ           6
    x_56            PART_11         1.0
    x_56            COVER_19        1.0
    x_56            COVER_42        1.0
    x_57            OBJ           14
    x_57            PART_11         1.0
    x_57            PACK_6          1.0
    x_57            PACK_54         1.0
    x_57            PACK_71         1.0
    x_57            COVER_39        1.0
    x_58            OBJ           17
    x_58            PART_11         1.0
    x_58            PACK_39         1.0
    x_58            PACK_45         1.0
    x_58            PACK_73         1.0
    x_58            COVER_54        1.0
    x_58            COVER_63        1.0
    x_59            OBJ           21
    x_59            PART_12         1.0
    x_59            PACK_40         1.0
    x_60            OBJ           25
    x_60            PART_12         1.0
    x_60            PACK_54         1.0
    x_60            COVER_25        1.0
    x_60            COVER_45        1.0
    x_60            COVER_46        1.0
    x_60            COVER_50        1.0
    x_60            COVER_51        1.0
    x_60            COVER_61        1.0
    x_61            OBJ           5
    x_61            PART_12         1.0
    x_61            PACK_63         1.0
    x_61            COVER_59        1.0
    x_62            OBJ           11
    x_62            PART_12         1.0
    x_62            PACK_2          1.0
    x_62            PACK_52         1.0
    x_62            PACK_56         1.0
    x_62            COVER_30        1.0
    x_62            COVER_73        1.0
    x_63            OBJ           21
    x_63            PART_13         1.0
    x_63            PACK_24         1.0
    x_63            PACK_32         1.0
    x_63            PACK_49         1.0
    x_63            PACK_50         1.0
    x_63            PACK_60         1.0
    x_63            COVER_36        1.0
    x_63            COVER_52        1.0
    x_64            OBJ           16
    x_64            PART_13         1.0
    x_64            PACK_51         1.0
    x_64            PACK_55         1.0
    x_64            COVER_50        1.0
    x_65            OBJ           16
    x_65            PART_13         1.0
    x_65            PACK_18         1.0
    x_65            PACK_61         1.0
    x_65            COVER_5         1.0
    x_65            COVER_32        1.0
    x_66            OBJ           29
    x_66            PART_13         1.0
    x_66            PACK_19         1.0
    x_66            COVER_6         1.0
    x_66            COVER_19        1.0
    x_66            COVER_24        1.0
    x_66            COVER_31        1.0
    x_66            COVER_33        1.0
    x_66            COVER_67        1.0
    x_66            COVER_72        1.0
    x_67            OBJ           5
    x_67            PART_14         1.0
    x_67            COVER_6         1.0
    x_67            COVER_36        1.0
    x_68            OBJ           17
    x_68            PART_14         1.0
    x_68            PACK_60         1.0
    x_68            PACK_65         1.0
    x_68            COVER_40        1.0
    x_69            OBJ           21
    x_69            PART_14         1.0
    x_69            PACK_30         1.0
    x_69            PACK_42         1.0
    x_69            PACK_45         1.0
    x_70            OBJ           9
    x_70            PART_14         1.0
    x_70            PACK_7          1.0
    x_70            PACK_38         1.0
    x_70            PACK_41         1.0
    x_70            COVER_54        1.0
    x_70            COVER_74        1.0
    x_71            OBJ           30
    x_71            PART_14         1.0
    x_71            PACK_18         1.0
    x_71            COVER_1         1.0
    x_71            COVER_51        1.0
    x_71            COVER_52        1.0
    x_71            COVER_60        1.0
    x_72            OBJ           6
    x_72            PART_15         1.0
    x_72            PACK_22         1.0
    x_72            PACK_48         1.0
    x_72            COVER_34        1.0
    x_72            COVER_37        1.0
    x_73            OBJ           20
    x_73            PART_15         1.0
    x_73            PACK_47         1.0
    x_73            COVER_9         1.0
    x_73            COVER_55        1.0
    x_74            OBJ           16
    x_74            PART_15         1.0
    x_74            PACK_14         1.0
    x_74            PACK_20         1.0
    x_74            PACK_26         1.0
    x_74            PACK_28         1.0
    x_75            OBJ           30
    x_75            PART_15         1.0
    x_75            COVER_42        1.0
    x_76            OBJ           20
    x_76            PART_16         1.0
    x_76            PACK_33         1.0
    x_76            PACK_38         1.0
    x_76            PACK_49         1.0
    x_76            PACK_56         1.0
    x_76            COVER_72        1.0
    x_77            OBJ           16
    x_77            PART_16         1.0
    x_78            OBJ           18
    x_78            PART_16         1.0
    x_78            PACK_52         1.0
    x_78            PACK_63         1.0
    x_78            PACK_66         1.0
    x_78            PACK_67         1.0
    x_78            PACK_71         1.0
    x_78            COVER_20        1.0
    x_78            COVER_21        1.0
    x_79            OBJ           27
    x_79            PART_16         1.0
    x_79            PACK_43         1.0
    x_79            COVER_4         1.0
    x_80            OBJ           22
    x_80            PART_17         1.0
    x_80            PACK_14         1.0
    x_80            PACK_16         1.0
    x_80            PACK_46         1.0
    x_80            PACK_67         1.0
    x_81            OBJ           15
    x_81            PART_17         1.0
    x_81            PACK_17         1.0
    x_81            PACK_29         1.0
    x_81            PACK_64         1.0
    x_81            COVER_62        1.0
    x_82            OBJ           29
    x_82            PART_17         1.0
    x_82            COVER_11        1.0
    x_82            COVER_57        1.0
    x_82            COVER_65        1.0
    x_83            OBJ           24
    x_83            PART_18         1.0
    x_83            COVER_26        1.0
    x_83            COVER_47        1.0
    x_83            COVER_50        1.0
    x_84            OBJ           22
    x_84            PART_18         1.0
    x_84            PACK_51         1.0
    x_84            PACK_65         1.0
    x_84            COVER_2         1.0
    x_84            COVER_48        1.0
    x_84            COVER_56        1.0
    x_84            COVER_71        1.0
    x_85            OBJ           10
    x_85            PART_18         1.0
    x_85            PACK_72         1.0
    x_85            COVER_0         1.0
    x_86            OBJ           13
    x_86            PART_19         1.0
    x_86            PACK_40         1.0
    x_86            COVER_32        1.0
    x_86            COVER_42        1.0
    x_86            COVER_59        1.0
    x_87            OBJ           6
    x_87            PART_19         1.0
    x_87            PACK_32         1.0
    x_87            PACK_63         1.0
    x_88            OBJ           23
    x_88            PART_19         1.0
    x_88            PACK_8          1.0
    x_88            PACK_55         1.0
    x_88            COVER_26        1.0
    x_88            COVER_28        1.0
    x_88            COVER_43        1.0
    x_89            OBJ           29
    x_89            PART_20         1.0
    x_89            PACK_60         1.0
    x_89            COVER_3         1.0
    x_89            COVER_8         1.0
    x_89            COVER_11        1.0
    x_89            COVER_36        1.0
    x_90            OBJ           5
    x_90            PART_20         1.0
    x_90            PACK_16         1.0
    x_90            PACK_33         1.0
    x_90            PACK_52         1.0
    x_90            COVER_3         1.0
    x_90            COVER_24        1.0
    x_90            COVER_73        1.0
    x_91            OBJ           13
    x_91            PART_20         1.0
    x_91            COVER_8         1.0
    x_91            COVER_72        1.0
    x_92            OBJ           8
    x_92            PART_21         1.0
    x_92            PACK_18         1.0
    x_92            PACK_57         1.0
    x_92            PACK_72         1.0
    x_92            COVER_55        1.0
    x_93            OBJ           10
    x_93            PART_21         1.0
    x_93            PACK_0          1.0
    x_93            PACK_3          1.0
    x_93            PACK_4          1.0
    x_93            PACK_29         1.0
    x_93            PACK_68         1.0
    x_94            OBJ           27
    x_94            PART_21         1.0
    x_94            PACK_5          1.0
    x_94            COVER_15        1.0
    x_94            COVER_40        1.0
    x_95            OBJ           14
    x_95            PART_21         1.0
    x_95            PACK_19         1.0
    x_95            COVER_25        1.0
    x_95            COVER_53        1.0
    x_96            OBJ           24
    x_96            PART_22         1.0
    x_96            COVER_35        1.0
    x_96            COVER_48        1.0
    x_97            OBJ           13
    x_97            PART_22         1.0
    x_97            PACK_16         1.0
    x_97            PACK_29         1.0
    x_97            PACK_30         1.0
    x_97            COVER_0         1.0
    x_98            OBJ           21
    x_98            PART_22         1.0
    x_98            PACK_37         1.0
    x_98            PACK_41         1.0
    x_98            PACK_68         1.0
    x_99            OBJ           14
    x_99            PART_23         1.0
    x_99            PACK_9          1.0
    x_99            PACK_10         1.0
    x_99            PACK_61         1.0
    x_99            COVER_23        1.0
    x_100           OBJ           19
    x_100           PART_23         1.0
    x_100           PACK_36         1.0
    x_100           PACK_46         1.0
    x_100           PACK_55         1.0
    x_100           PACK_60         1.0
    x_100           PACK_73         1.0
    x_101           OBJ           27
    x_101           PART_23         1.0
    x_101           PACK_14         1.0
    x_101           COVER_38        1.0
    x_101           COVER_55        1.0
    x_101           COVER_73        1.0
    x_102           OBJ           20
    x_102           PART_23         1.0
    x_102           COVER_40        1.0
    x_103           OBJ           22
    x_103           PART_24         1.0
    x_103           PACK_11         1.0
    x_103           PACK_12         1.0
    x_104           OBJ           14
    x_104           PART_24         1.0
    x_104           PACK_1          1.0
    x_104           PACK_72         1.0
    x_105           OBJ           17
    x_105           PART_24         1.0
    x_105           PACK_26         1.0
    x_105           PACK_28         1.0
    x_105           PACK_66         1.0
    x_105           PACK_74         1.0
    x_106           OBJ           15
    x_106           PART_24         1.0
    x_106           PACK_2          1.0
    x_106           COVER_29        1.0
    x_106           COVER_66        1.0
    x_107           OBJ           18
    x_107           PART_24         1.0
    x_107           PACK_0          1.0
    x_107           COVER_63        1.0
    x_108           OBJ           11
    x_108           PART_24         1.0
    x_108           COVER_28        1.0
    x_108           COVER_31        1.0
    x_108           COVER_41        1.0
    x_108           COVER_55        1.0
    x_109           OBJ           26
    x_109           PART_25         1.0
    x_110           OBJ           21
    x_110           PART_25         1.0
    x_110           PACK_0          1.0
    x_110           PACK_23         1.0
    x_110           PACK_58         1.0
    x_110           COVER_41        1.0
    x_111           OBJ           11
    x_111           PART_25         1.0
    x_111           PACK_74         1.0
    x_112           OBJ           18
    x_112           PART_25         1.0
    x_112           PACK_62         1.0
    x_112           PACK_65         1.0
    x_112           PACK_66         1.0
    x_112           PACK_72         1.0
    x_112           COVER_68        1.0
    x_113           OBJ           5
    x_113           PART_25         1.0
    x_113           PACK_29         1.0
    x_113           PACK_57         1.0
    x_113           COVER_47        1.0
    x_114           OBJ           28
    x_114           PART_26         1.0
    x_114           COVER_20        1.0
    x_114           COVER_32        1.0
    x_114           COVER_60        1.0
    x_114           COVER_69        1.0
    x_115           OBJ           9
    x_115           PART_26         1.0
    x_115           PACK_24         1.0
    x_115           COVER_38        1.0
    x_115           COVER_43        1.0
    x_116           OBJ           6
    x_116           PART_26         1.0
    x_116           PACK_18         1.0
    x_116           PACK_32         1.0
    x_117           OBJ           10
    x_117           PART_26         1.0
    x_117           PACK_51         1.0
    x_117           COVER_9         1.0
    x_117           COVER_69        1.0
    x_118           OBJ           21
    x_118           PART_27         1.0
    x_118           PACK_23         1.0
    x_118           PACK_39         1.0
    x_118           COVER_3         1.0
    x_118           COVER_48        1.0
    x_118           COVER_71        1.0
    x_119           OBJ           18
    x_119           PART_27         1.0
    x_119           PACK_14         1.0
    x_119           COVER_43        1.0
    x_120           OBJ           22
    x_120           PART_27         1.0
    x_120           PACK_18         1.0
    x_120           PACK_35         1.0
    x_120           COVER_12        1.0
    x_121           OBJ           12
    x_121           PART_27         1.0
    x_121           PACK_47         1.0
    x_121           COVER_49        1.0
    x_122           OBJ           21
    x_122           PART_27         1.0
    x_122           PACK_44         1.0
    x_122           PACK_49         1.0
    x_122           COVER_22        1.0
    x_122           COVER_39        1.0
    x_123           OBJ           29
    x_123           PART_27         1.0
    x_123           COVER_16        1.0
    x_123           COVER_23        1.0
    x_123           COVER_34        1.0
    x_123           COVER_40        1.0
    x_123           COVER_66        1.0
    x_124           OBJ           28
    x_124           PART_28         1.0
    x_124           COVER_25        1.0
    x_125           OBJ           15
    x_125           PART_28         1.0
    x_125           PACK_4          1.0
    x_125           PACK_13         1.0
    x_125           PACK_48         1.0
    x_125           COVER_33        1.0
    x_126           OBJ           18
    x_126           PART_28         1.0
    x_126           PACK_33         1.0
    x_126           PACK_72         1.0
    x_126           COVER_16        1.0
    x_127           OBJ           6
    x_127           PART_28         1.0
    x_127           PACK_10         1.0
    x_127           PACK_61         1.0
    x_127           COVER_15        1.0
    x_127           COVER_58        1.0
    x_128           OBJ           11
    x_128           PART_29         1.0
    x_128           PACK_60         1.0
    x_128           COVER_68        1.0
    x_129           OBJ           22
    x_129           PART_29         1.0
    x_129           COVER_1         1.0
    x_129           COVER_2         1.0
    x_129           COVER_23        1.0
    x_129           COVER_72        1.0
    x_129           COVER_74        1.0
    x_130           OBJ           14
    x_130           PART_29         1.0
    x_130           PACK_61         1.0
    x_130           PACK_68         1.0
    x_130           COVER_13        1.0
    x_130           COVER_43        1.0
    x_130           COVER_51        1.0
    x_130           COVER_62        1.0
    x_131           OBJ           7
    x_131           PART_29         1.0
    x_131           PACK_13         1.0
    x_131           PACK_37         1.0
    x_131           PACK_48         1.0
    x_132           OBJ           7
    x_132           PART_29         1.0
    x_132           COVER_19        1.0
    x_133           OBJ           10
    x_133           PART_30         1.0
    x_133           PACK_17         1.0
    x_133           PACK_38         1.0
    x_134           OBJ           18
    x_134           PART_30         1.0
    x_134           PACK_0          1.0
    x_134           PACK_25         1.0
    x_134           PACK_42         1.0
    x_135           OBJ           26
    x_135           PART_30         1.0
    x_135           COVER_10        1.0
    x_135           COVER_42        1.0
    x_135           COVER_57        1.0
    x_135           COVER_64        1.0
    x_135           COVER_66        1.0
    x_136           OBJ           9
    x_136           PART_30         1.0
    x_136           PACK_13         1.0
    x_136           COVER_14        1.0
    x_136           COVER_67        1.0
    x_137           OBJ           5
    x_137           PART_30         1.0
    x_137           COVER_69        1.0
    x_138           OBJ           11
    x_138           PART_31         1.0
    x_138           COVER_19        1.0
    x_139           OBJ           19
    x_139           PART_31         1.0
    x_139           PACK_7          1.0
    x_139           PACK_9          1.0
    x_139           PACK_35         1.0
    x_139           PACK_40         1.0
    x_139           COVER_0         1.0
    x_139           COVER_51        1.0
    x_140           OBJ           24
    x_140           PART_31         1.0
    x_140           PACK_13         1.0
    x_140           PACK_26         1.0
    x_140           PACK_29         1.0
    x_140           PACK_64         1.0
    x_140           COVER_30        1.0
    x_140           COVER_31        1.0
    x_140           COVER_33        1.0
    x_140           COVER_43        1.0
    x_141           OBJ           11
    x_141           PART_32         1.0
    x_141           PACK_8          1.0
    x_141           PACK_12         1.0
    x_141           PACK_21         1.0
    x_142           OBJ           27
    x_142           PART_32         1.0
    x_142           COVER_54        1.0
    x_143           OBJ           8
    x_143           PART_32         1.0
    x_143           PACK_22         1.0
    x_144           OBJ           11
    x_144           PART_33         1.0
    x_144           PACK_39         1.0
    x_144           PACK_43         1.0
    x_145           OBJ           20
    x_145           PART_33         1.0
    x_146           OBJ           8
    x_146           PART_33         1.0
    x_147           OBJ           28
    x_147           PART_33         1.0
    x_147           PACK_3          1.0
    x_147           PACK_53         1.0
    x_147           COVER_7         1.0
    x_147           COVER_14        1.0
    x_147           COVER_59        1.0
    x_148           OBJ           20
    x_148           PART_34         1.0
    x_148           PACK_8          1.0
    x_148           PACK_10         1.0
    x_148           COVER_30        1.0
    x_148           COVER_47        1.0
    x_149           OBJ           5
    x_149           PART_34         1.0
    x_149           PACK_6          1.0
    x_149           PACK_24         1.0
    x_149           PACK_29         1.0
    x_149           PACK_36         1.0
    x_149           PACK_53         1.0
    x_150           OBJ           15
    x_150           PART_34         1.0
    x_150           PACK_5          1.0
    x_150           COVER_18        1.0
    x_151           OBJ           17
    x_151           PART_34         1.0
    x_151           PACK_11         1.0
    x_151           PACK_25         1.0
    x_151           PACK_58         1.0
    x_151           PACK_62         1.0
    x_151           COVER_16        1.0
    x_152           OBJ           26
    x_152           PART_34         1.0
    x_152           COVER_16        1.0
    x_152           COVER_46        1.0
    x_153           OBJ           25
    x_153           PART_35         1.0
    x_153           COVER_8         1.0
    x_153           COVER_39        1.0
    x_153           COVER_60        1.0
    x_153           COVER_71        1.0
    x_154           OBJ           15
    x_154           PART_35         1.0
    x_154           PACK_17         1.0
    x_154           PACK_30         1.0
    x_154           PACK_31         1.0
    x_154           PACK_43         1.0
    x_154           COVER_5         1.0
    x_155           OBJ           9
    x_155           PART_35         1.0
    x_155           PACK_67         1.0
    x_155           COVER_62        1.0
    x_156           OBJ           11
    x_156           PART_36         1.0
    x_156           PACK_45         1.0
    x_156           PACK_50         1.0
    x_156           COVER_26        1.0
    x_156           COVER_74        1.0
    x_157           OBJ           13
    x_157           PART_36         1.0
    x_157           PACK_21         1.0
    x_157           PACK_26         1.0
    x_157           PACK_44         1.0
    x_157           PACK_73         1.0
    x_158           OBJ           8
    x_158           PART_36         1.0
    x_158           PACK_31         1.0
    x_158           PACK_70         1.0
    x_158           COVER_10        1.0
    x_159           OBJ           28
    x_159           PART_36         1.0
    x_159           PACK_40         1.0
    x_159           COVER_34        1.0
    x_159           COVER_63        1.0
    x_160           OBJ           22
    x_160           PART_36         1.0
    x_160           PACK_11         1.0
    x_160           COVER_18        1.0
    x_161           OBJ           20
    x_161           PART_37         1.0
    x_161           PACK_12         1.0
    x_161           PACK_18         1.0
    x_161           PACK_53         1.0
    x_162           OBJ           22
    x_162           PART_37         1.0
    x_162           PACK_7          1.0
    x_162           PACK_26         1.0
    x_162           PACK_59         1.0
    x_162           COVER_1         1.0
    x_162           COVER_6         1.0
    x_163           OBJ           12
    x_163           PART_37         1.0
    x_163           PACK_32         1.0
    x_163           COVER_51        1.0
    x_164           OBJ           7
    x_164           PART_37         1.0
    x_164           PACK_20         1.0
    x_164           PACK_33         1.0
    x_164           PACK_74         1.0
    x_164           COVER_5         1.0
    x_165           OBJ           22
    x_165           PART_37         1.0
    x_165           PACK_63         1.0
    x_165           COVER_9         1.0
    x_165           COVER_39        1.0
    x_165           COVER_68        1.0
    x_166           OBJ           24
    x_166           PART_38         1.0
    x_166           COVER_13        1.0
    x_166           COVER_45        1.0
    x_166           COVER_58        1.0
    x_167           OBJ           10
    x_167           PART_38         1.0
    x_167           PACK_47         1.0
    x_167           PACK_69         1.0
    x_167           COVER_4         1.0
    x_167           COVER_12        1.0
    x_167           COVER_45        1.0
    x_167           COVER_50        1.0
    x_168           OBJ           22
    x_168           PART_38         1.0
    x_168           PACK_34         1.0
    x_168           PACK_49         1.0
    x_168           COVER_25        1.0
    x_168           COVER_50        1.0
    x_169           OBJ           15
    x_169           PART_39         1.0
    x_169           COVER_21        1.0
    x_169           COVER_38        1.0
    x_170           OBJ           21
    x_170           PART_39         1.0
    x_170           PACK_4          1.0
    x_170           PACK_14         1.0
    x_170           PACK_50         1.0
    x_170           PACK_57         1.0
    x_171           OBJ           26
    x_171           PART_39         1.0
    x_171           COVER_33        1.0
    x_172           OBJ           16
    x_172           PART_39         1.0
    x_172           PACK_2          1.0
    x_172           PACK_5          1.0
    x_172           PACK_69         1.0
    x_173           OBJ           8
    x_173           PART_40         1.0
    x_173           PACK_72         1.0
    x_173           COVER_33        1.0
    x_174           OBJ           14
    x_174           PART_40         1.0
    x_174           PACK_2          1.0
    x_174           COVER_7         1.0
    x_175           OBJ           25
    x_175           PART_40         1.0
    x_175           COVER_19        1.0
    x_175           COVER_56        1.0
    x_176           OBJ           20
    x_176           PART_40         1.0
    x_176           PACK_8          1.0
    x_176           PACK_10         1.0
    x_176           PACK_12         1.0
    x_176           PACK_54         1.0
    x_176           COVER_10        1.0
    x_176           COVER_54        1.0
    x_176           COVER_61        1.0
    x_177           OBJ           9
    x_177           PART_40         1.0
    x_177           PACK_22         1.0
    x_177           PACK_27         1.0
    x_177           PACK_37         1.0
    x_177           PACK_60         1.0
    x_177           COVER_55        1.0
    x_177           COVER_73        1.0
    x_178           OBJ           6
    x_178           PART_41         1.0
    x_178           PACK_28         1.0
    x_178           PACK_31         1.0
    x_178           COVER_54        1.0
    x_178           COVER_64        1.0
    x_179           OBJ           28
    x_179           PART_41         1.0
    x_179           COVER_12        1.0
    x_179           COVER_41        1.0
    x_179           COVER_46        1.0
    x_179           COVER_62        1.0
    x_179           COVER_70        1.0
    x_180           OBJ           7
    x_180           PART_41         1.0
    x_180           PACK_6          1.0
    x_180           PACK_16         1.0
    x_180           PACK_17         1.0
    x_180           PACK_43         1.0
    x_180           PACK_70         1.0
    x_180           COVER_31        1.0
    x_180           COVER_47        1.0
    x_181           OBJ           9
    x_181           PART_42         1.0
    x_181           PACK_64         1.0
    x_181           PACK_71         1.0
    x_182           OBJ           27
    x_182           PART_42         1.0
    x_182           PACK_2          1.0
    x_182           COVER_7         1.0
    x_182           COVER_10        1.0
    x_182           COVER_59        1.0
    x_183           OBJ           8
    x_183           PART_42         1.0
    x_183           PACK_65         1.0
    x_184           OBJ           17
    x_184           PART_42         1.0
    x_184           PACK_17         1.0
    x_185           OBJ           7
    x_185           PART_42         1.0
    x_185           PACK_34         1.0
    x_185           PACK_63         1.0
    x_185           COVER_56        1.0
    x_186           OBJ           22
    x_186           PART_42         1.0
    x_186           PACK_9          1.0
    x_186           PACK_37         1.0
    x_186           PACK_38         1.0
    x_186           PACK_44         1.0
    x_186           PACK_53         1.0
    x_186           COVER_3         1.0
    x_187           OBJ           26
    x_187           PART_43         1.0
    x_188           OBJ           16
    x_188           PART_43         1.0
    x_188           PACK_33         1.0
    x_188           PACK_64         1.0
    x_189           OBJ           14
    x_189           PART_43         1.0
    x_190           OBJ           22
    x_190           PART_43         1.0
    x_190           PACK_32         1.0
    x_190           COVER_4         1.0
    x_190           COVER_17        1.0
    x_190           COVER_25        1.0
    x_190           COVER_29        1.0
    x_190           COVER_32        1.0
    x_190           COVER_60        1.0
    x_191           OBJ           13
    x_191           PART_44         1.0
    x_191           PACK_1          1.0
    x_191           PACK_37         1.0
    x_192           OBJ           23
    x_192           PART_44         1.0
    x_192           COVER_27        1.0
    x_192           COVER_65        1.0
    x_193           OBJ           6
    x_193           PART_44         1.0
    x_193           PACK_23         1.0
    x_193           PACK_33         1.0
    x_193           PACK_66         1.0
    x_193           PACK_67         1.0
    x_194           OBJ           22
    x_194           PART_45         1.0
    x_194           COVER_0         1.0
    x_194           COVER_9         1.0
    x_194           COVER_18        1.0
    x_194           COVER_56        1.0
    x_194           COVER_57        1.0
    x_195           OBJ           7
    x_195           PART_45         1.0
    x_195           PACK_27         1.0
    x_195           COVER_27        1.0
    x_195           COVER_33        1.0
    x_196           OBJ           18
    x_196           PART_45         1.0
    x_196           PACK_10         1.0
    x_196           PACK_40         1.0
    x_196           PACK_66         1.0
    x_196           COVER_44        1.0
    x_197           OBJ           8
    x_197           PART_45         1.0
    x_197           PACK_4          1.0
    x_197           PACK_6          1.0
    x_198           OBJ           6
    x_198           PART_45         1.0
    x_198           PACK_19         1.0
    x_198           PACK_28         1.0
    x_198           PACK_62         1.0
    x_198           COVER_24        1.0
    x_199           OBJ           18
    x_199           PART_46         1.0
    x_199           PACK_11         1.0
    x_199           PACK_34         1.0
    x_199           PACK_36         1.0
    x_199           PACK_46         1.0
    x_199           COVER_30        1.0
    x_199           COVER_53        1.0
    x_200           OBJ           24
    x_200           PART_46         1.0
    x_200           COVER_22        1.0
    x_200           COVER_29        1.0
    x_200           COVER_35        1.0
    x_200           COVER_40        1.0
    x_200           COVER_70        1.0
    x_201           OBJ           8
    x_201           PART_46         1.0
    x_201           PACK_71         1.0
    x_201           COVER_9         1.0
    x_201           COVER_53        1.0
    x_202           OBJ           19
    x_202           PART_46         1.0
    x_202           PACK_15         1.0
    x_202           PACK_41         1.0
    x_202           COVER_1         1.0
    x_203           OBJ           10
    x_203           PART_47         1.0
    x_204           OBJ           23
    x_204           PART_47         1.0
    x_204           COVER_49        1.0
    x_204           COVER_67        1.0
    x_205           OBJ           18
    x_205           PART_47         1.0
    x_205           PACK_20         1.0
    x_205           PACK_25         1.0
    x_205           PACK_35         1.0
    x_205           PACK_40         1.0
    x_206           OBJ           17
    x_206           PART_47         1.0
    x_206           PACK_5          1.0
    x_206           PACK_14         1.0
    x_206           PACK_44         1.0
    x_206           COVER_9         1.0
    x_206           COVER_24        1.0
    x_206           COVER_27        1.0
    x_207           OBJ           13
    x_207           PART_48         1.0
    x_207           PACK_62         1.0
    x_207           COVER_30        1.0
    x_208           OBJ           20
    x_208           PART_48         1.0
    x_208           PACK_24         1.0
    x_208           COVER_2         1.0
    x_209           OBJ           15
    x_209           PART_48         1.0
    x_209           PACK_0          1.0
    x_209           PACK_66         1.0
    x_209           COVER_21        1.0
    x_209           COVER_68        1.0
    x_210           OBJ           8
    x_210           PART_48         1.0
    x_210           PACK_2          1.0
    x_210           COVER_61        1.0
    x_211           OBJ           25
    x_211           PART_48         1.0
    x_211           COVER_40        1.0
    x_211           COVER_57        1.0
    x_212           OBJ           22
    x_212           PART_49         1.0
    x_212           PACK_31         1.0
    x_213           OBJ           5
    x_213           PART_49         1.0
    x_213           COVER_37        1.0
    x_214           OBJ           14
    x_214           PART_49         1.0
    x_214           PACK_10         1.0
    x_214           PACK_28         1.0
    x_214           COVER_11        1.0
    x_214           COVER_67        1.0
    x_215           OBJ           15
    x_215           PART_49         1.0
    x_215           PACK_0          1.0
    x_215           COVER_64        1.0
    x_216           OBJ           19
    x_216           PART_49         1.0
    x_216           PACK_1          1.0
    x_216           PACK_3          1.0
    x_216           PACK_15         1.0
    x_216           PACK_57         1.0
    x_216           PACK_60         1.0
    x_216           COVER_20        1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           PART_0          1.0
    RHS           PART_1          1.0
    RHS           PART_2          1.0
    RHS           PART_3          1.0
    RHS           PART_4          1.0
    RHS           PART_5          1.0
    RHS           PART_6          1.0
    RHS           PART_7          1.0
    RHS           PART_8          1.0
    RHS           PART_9          1.0
    RHS           PART_10         1.0
    RHS           PART_11         1.0
    RHS           PART_12         1.0
    RHS           PART_13         1.0
    RHS           PART_14         1.0
    RHS           PART_15         1.0
    RHS           PART_16         1.0
    RHS           PART_17         1.0
    RHS           PART_18         1.0
    RHS           PART_19         1.0
    RHS           PART_20         1.0
    RHS           PART_21         1.0
    RHS           PART_22         1.0
    RHS           PART_23         1.0
    RHS           PART_24         1.0
    RHS           PART_25         1.0
    RHS           PART_26         1.0
    RHS           PART_27         1.0
    RHS           PART_28         1.0
    RHS           PART_29         1.0
    RHS           PART_30         1.0
    RHS           PART_31         1.0
    RHS           PART_32         1.0
    RHS           PART_33         1.0
    RHS           PART_34         1.0
    RHS           PART_35         1.0
    RHS           PART_36         1.0
    RHS           PART_37         1.0
    RHS           PART_38         1.0
    RHS           PART_39         1.0
    RHS           PART_40         1.0
    RHS           PART_41         1.0
    RHS           PART_42         1.0
    RHS           PART_43         1.0
    RHS           PART_44         1.0
    RHS           PART_45         1.0
    RHS           PART_46         1.0
    RHS           PART_47         1.0
    RHS           PART_48         1.0
    RHS           PART_49         1.0
    RHS           PACK_0          1.0
    RHS           PACK_1          1.0
    RHS           PACK_2          1.0
    RHS           PACK_3          1.0
    RHS           PACK_4          1.0
    RHS           PACK_5          1.0
    RHS           PACK_6          1.0
    RHS           PACK_7          1.0
    RHS           PACK_8          1.0
    RHS           PACK_9          1.0
    RHS           PACK_10         1.0
    RHS           PACK_11         1.0
    RHS           PACK_12         1.0
    RHS           PACK_13         1.0
    RHS           PACK_14         1.0
    RHS           PACK_15         1.0
    RHS           PACK_16         1.0
    RHS           PACK_17         1.0
    RHS           PACK_18         1.0
    RHS           PACK_19         1.0
    RHS           PACK_20         1.0
    RHS           PACK_21         1.0
    RHS           PACK_22         1.0
    RHS           PACK_23         1.0
    RHS           PACK_24         1.0
    RHS           PACK_25         1.0
    RHS           PACK_26         1.0
    RHS           PACK_27         1.0
    RHS           PACK_28         1.0
    RHS           PACK_29         1.0
    RHS           PACK_30         1.0
    RHS           PACK_31         1.0
    RHS           PACK_32         1.0
    RHS           PACK_33         1.0
    RHS           PACK_34         1.0
    RHS           PACK_35         1.0
    RHS           PACK_36         1.0
    RHS           PACK_37         1.0
    RHS           PACK_38         1.0
    RHS           PACK_39         1.0
    RHS           PACK_40         1.0
    RHS           PACK_41         1.0
    RHS           PACK_42         1.0
    RHS           PACK_43         1.0
    RHS           PACK_44         1.0
    RHS           PACK_45         1.0
    RHS           PACK_46         1.0
    RHS           PACK_47         1.0
    RHS           PACK_48         1.0
    RHS           PACK_49         1.0
    RHS           PACK_50         1.0
    RHS           PACK_51         1.0
    RHS           PACK_52         1.0
    RHS           PACK_53         1.0
    RHS           PACK_54         1.0
    RHS           PACK_55         1.0
    RHS           PACK_56         1.0
    RHS           PACK_57         1.0
    RHS           PACK_58         1.0
    RHS           PACK_59         1.0
    RHS           PACK_60         1.0
    RHS           PACK_61         1.0
    RHS           PACK_62         1.0
    RHS           PACK_63         1.0
    RHS           PACK_64         1.0
    RHS           PACK_65         1.0
    RHS           PACK_66         1.0
    RHS           PACK_67         1.0
    RHS           PACK_68         1.0
    RHS           PACK_69         1.0
    RHS           PACK_70         1.0
    RHS           PACK_71         1.0
    RHS           PACK_72         1.0
    RHS           PACK_73         1.0
    RHS           PACK_74         1.0
    RHS           COVER_0         1.0
    RHS           COVER_1         1.0
    RHS           COVER_2         1.0
    RHS           COVER_3         1.0
    RHS           COVER_4         1.0
    RHS           COVER_5         1.0
    RHS           COVER_6         1.0
    RHS           COVER_7         1.0
    RHS           COVER_8         1.0
    RHS           COVER_9         1.0
    RHS           COVER_10        1.0
    RHS           COVER_11        1.0
    RHS           COVER_12        1.0
    RHS           COVER_13        1.0
    RHS           COVER_14        1.0
    RHS           COVER_15        1.0
    RHS           COVER_16        1.0
    RHS           COVER_17        1.0
    RHS           COVER_18        1.0
    RHS           COVER_19        1.0
    RHS           COVER_20        1.0
    RHS           COVER_21        1.0
    RHS           COVER_22        1.0
    RHS           COVER_23        1.0
    RHS           COVER_24        1.0
    RHS           COVER_25        1.0
    RHS           COVER_26        1.0
    RHS           COVER_27        1.0
    RHS           COVER_28        1.0
    RHS           COVER_29        1.0
    RHS           COVER_30        1.0
    RHS           COVER_31        1.0
    RHS           COVER_32        1.0
    RHS           COVER_33        1.0
    RHS           COVER_34        1.0
    RHS           COVER_35        1.0
    RHS           COVER_36        1.0
    RHS           COVER_37        1.0
    RHS           COVER_38        1.0
    RHS           COVER_39        1.0
    RHS           COVER_40        1.0
    RHS           COVER_41        1.0
    RHS           COVER_42        1.0
    RHS           COVER_43        1.0
    RHS           COVER_44        1.0
    RHS           COVER_45        1.0
    RHS           COVER_46        1.0
    RHS           COVER_47        1.0
    RHS           COVER_48        1.0
    RHS           COVER_49        1.0
    RHS           COVER_50        1.0
    RHS           COVER_51        1.0
    RHS           COVER_52        1.0
    RHS           COVER_53        1.0
    RHS           COVER_54        1.0
    RHS           COVER_55        1.0
    RHS           COVER_56        1.0
    RHS           COVER_57        1.0
    RHS           COVER_58        1.0
    RHS           COVER_59        1.0
    RHS           COVER_60        1.0
    RHS           COVER_61        1.0
    RHS           COVER_62        1.0
    RHS           COVER_63        1.0
    RHS           COVER_64        1.0
    RHS           COVER_65        1.0
    RHS           COVER_66        1.0
    RHS           COVER_67        1.0
    RHS           COVER_68        1.0
    RHS           COVER_69        1.0
    RHS           COVER_70        1.0
    RHS           COVER_71        1.0
    RHS           COVER_72        1.0
    RHS           COVER_73        1.0
    RHS           COVER_74        1.0
BOUNDS
 BV BOUND         x_0
 BV BOUND         x_1
 BV BOUND         x_2
 BV BOUND         x_3
 BV BOUND         x_4
 BV BOUND         x_5
 BV BOUND         x_6
 BV BOUND         x_7
 BV BOUND         x_8
 BV BOUND         x_9
 BV BOUND         x_10
 BV BOUND         x_11
 BV BOUND         x_12
 BV BOUND         x_13
 BV BOUND         x_14
 BV BOUND         x_15
 BV BOUND         x_16
 BV BOUND         x_17
 BV BOUND         x_18
 BV BOUND         x_19
 BV BOUND         x_20
 BV BOUND         x_21
 BV BOUND         x_22
 BV BOUND         x_23
 BV BOUND         x_24
 BV BOUND         x_25
 BV BOUND         x_26
 BV BOUND         x_27
 BV BOUND         x_28
 BV BOUND         x_29
 BV BOUND         x_30
 BV BOUND         x_31
 BV BOUND         x_32
 BV BOUND         x_33
 BV BOUND         x_34
 BV BOUND         x_35
 BV BOUND         x_36
 BV BOUND         x_37
 BV BOUND         x_38
 BV BOUND         x_39
 BV BOUND         x_40
 BV BOUND         x_41
 BV BOUND         x_42
 BV BOUND         x_43
 BV BOUND         x_44
 BV BOUND         x_45
 BV BOUND         x_46
 BV BOUND         x_47
 BV BOUND         x_48
 BV BOUND         x_49
 BV BOUND         x_50
 BV BOUND         x_51
 BV BOUND         x_52
 BV BOUND         x_53
 BV BOUND         x_54
 BV BOUND         x_55
 BV BOUND         x_56
 BV BOUND         x_57
 BV BOUND         x_58
 BV BOUND         x_59
 BV BOUND         x_60
 BV BOUND         x_61
 BV BOUND         x_62
 BV BOUND         x_63
 BV BOUND         x_64
 BV BOUND         x_65
 BV BOUND         x_66
 BV BOUND         x_67
 BV BOUND         x_68
 BV BOUND         x_69
 BV BOUND         x_70
 BV BOUND         x_71
 BV BOUND         x_72
 BV BOUND         x_73
 BV BOUND         x_74
 BV BOUND         x_75
 BV BOUND         x_76
 BV BOUND         x_77
 BV BOUND         x_78
 BV BOUND         x_79
 BV BOUND         x_80
 BV BOUND         x_81
 BV BOUND         x_82
 BV BOUND         x_83
 BV BOUND         x_84
 BV BOUND         x_85
 BV BOUND         x_86
 BV BOUND         x_87
 BV BOUND         x_88
 BV BOUND         x_89
 BV BOUND         x_90
 BV BOUND         x_91
 BV BOUND         x_92
 BV BOUND         x_93
 BV BOUND         x_94
 BV BOUND         x_95
 BV BOUND         x_96
 BV BOUND         x_97
 BV BOUND         x_98
 BV BOUND         x_99
 BV BOUND         x_100
 BV BOUND         x_101
 BV BOUND         x_102
 BV BOUND         x_103
 BV BOUND         x_104
 BV BOUND         x_105
 BV BOUND         x_106
 BV BOUND         x_107
 BV BOUND         x_108
 BV BOUND         x_109
 BV BOUND         x_110
 BV BOUND         x_111
 BV BOUND         x_112
 BV BOUND         x_113
 BV BOUND         x_114
 BV BOUND         x_115
 BV BOUND         x_116
 BV BOUND         x_117
 BV BOUND         x_118
 BV BOUND         x_119
 BV BOUND         x_120
 BV BOUND         x_121
 BV BOUND         x_122
 BV BOUND         x_123
 BV BOUND         x_124
 BV BOUND         x_125
 BV BOUND         x_126
 BV BOUND         x_127
 BV BOUND         x_128
 BV BOUND         x_129
 BV BOUND         x_130
 BV BOUND         x_131
 BV BOUND         x_132
 BV BOUND         x_133
 BV BOUND         x_134
 BV BOUND         x_135
 BV BOUND         x_136
 BV BOUND         x_137
 BV BOUND         x_138
 BV BOUND         x_139
 BV BOUND         x_140
 BV BOUND         x_141
 BV BOUND         x_142
 BV BOUND         x_143
 BV BOUND         x_144
 BV BOUND         x_145
 BV BOUND         x_146
 BV BOUND         x_147
 BV BOUND         x_148
 BV BOUND         x_149
 BV BOUND         x_150
 BV BOUND         x_151
 BV BOUND         x_152
 BV BOUND         x_153
 BV BOUND         x_154
 BV BOUND         x_155
 BV BOUND         x_156
 BV BOUND         x_157
 BV BOUND         x_158
 BV BOUND         x_159
 BV BOUND         x_160
 BV BOUND         x_161
 BV BOUND         x_162
 BV BOUND         x_163
 BV BOUND         x_164
 BV BOUND         x_165
 BV BOUND         x_166
 BV BOUND         x_167
 BV BOUND         x_168
 BV BOUND         x_169
 BV BOUND         x_170
 BV BOUND         x_171
 BV BOUND         x_172
 BV BOUND         x_173
 BV BOUND         x_174
 BV BOUND         x_175
 BV BOUND         x_176
 BV BOUND         x_177
 BV BOUND         x_178
 BV BOUND         x_179
 BV BOUND         x_180
 BV BOUND         x_181
 BV BOUND         x_182
 BV BOUND         x_183
 BV BOUND         x_184
 BV BOUND         x_185
 BV BOUND         x_186
 BV BOUND         x_187
 BV BOUND         x_188
 BV BOUND         x_189
 BV BOUND         x_190
 BV BOUND         x_191
 BV BOUND         x_192
 BV BOUND         x_193
 BV BOUND         x_194
 BV BOUND         x_195
 BV BOUND         x_196
 BV BOUND         x_197
 BV BOUND         x_198
 BV BOUND         x_199
 BV BOUND         x_200
 BV BOUND         x_201
 BV BOUND         x_202
 BV BOUND         x_203
 BV BOUND         x_204
 BV BOUND         x_205
 BV BOUND         x_206
 BV BOUND         x_207
 BV BOUND         x_208
 BV BOUND         x_209
 BV BOUND         x_210
 BV BOUND         x_211
 BV BOUND         x_212
 BV BOUND         x_213
 BV BOUND         x_214
 BV BOUND         x_215
 BV BOUND         x_216
ENDATA
