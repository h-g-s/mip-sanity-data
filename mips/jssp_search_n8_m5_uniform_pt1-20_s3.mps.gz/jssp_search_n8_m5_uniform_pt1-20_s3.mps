NAME          jssp_search_n8_m5_uniform_pt1-20_s3
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_6_7_4
 G  disj2_6_7_4
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_0  -1.0
    x_0_0     disj2_0_1_0  1.0
    x_0_0     disj1_0_2_0  -1.0
    x_0_0     disj2_0_2_0  1.0
    x_0_0     disj1_0_3_0  -1.0
    x_0_0     disj2_0_3_0  1.0
    x_0_0     disj1_0_4_0  -1.0
    x_0_0     disj2_0_4_0  1.0
    x_0_0     disj1_0_5_0  -1.0
    x_0_0     disj2_0_5_0  1.0
    x_0_0     disj1_0_6_0  -1.0
    x_0_0     disj2_0_6_0  1.0
    x_0_0     disj1_0_7_0  -1.0
    x_0_0     disj2_0_7_0  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_2  -1.0
    x_0_1     disj2_0_1_2  1.0
    x_0_1     disj1_0_2_2  -1.0
    x_0_1     disj2_0_2_2  1.0
    x_0_1     disj1_0_3_2  -1.0
    x_0_1     disj2_0_3_2  1.0
    x_0_1     disj1_0_4_2  -1.0
    x_0_1     disj2_0_4_2  1.0
    x_0_1     disj1_0_5_2  -1.0
    x_0_1     disj2_0_5_2  1.0
    x_0_1     disj1_0_6_2  -1.0
    x_0_1     disj2_0_6_2  1.0
    x_0_1     disj1_0_7_2  -1.0
    x_0_1     disj2_0_7_2  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_3  -1.0
    x_0_2     disj2_0_1_3  1.0
    x_0_2     disj1_0_2_3  -1.0
    x_0_2     disj2_0_2_3  1.0
    x_0_2     disj1_0_3_3  -1.0
    x_0_2     disj2_0_3_3  1.0
    x_0_2     disj1_0_4_3  -1.0
    x_0_2     disj2_0_4_3  1.0
    x_0_2     disj1_0_5_3  -1.0
    x_0_2     disj2_0_5_3  1.0
    x_0_2     disj1_0_6_3  -1.0
    x_0_2     disj2_0_6_3  1.0
    x_0_2     disj1_0_7_3  -1.0
    x_0_2     disj2_0_7_3  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_4  -1.0
    x_0_3     disj2_0_1_4  1.0
    x_0_3     disj1_0_2_4  -1.0
    x_0_3     disj2_0_2_4  1.0
    x_0_3     disj1_0_3_4  -1.0
    x_0_3     disj2_0_3_4  1.0
    x_0_3     disj1_0_4_4  -1.0
    x_0_3     disj2_0_4_4  1.0
    x_0_3     disj1_0_5_4  -1.0
    x_0_3     disj2_0_5_4  1.0
    x_0_3     disj1_0_6_4  -1.0
    x_0_3     disj2_0_6_4  1.0
    x_0_3     disj1_0_7_4  -1.0
    x_0_3     disj2_0_7_4  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     mksp_0    -1.0
    x_0_4     disj1_0_1_1  -1.0
    x_0_4     disj2_0_1_1  1.0
    x_0_4     disj1_0_2_1  -1.0
    x_0_4     disj2_0_2_1  1.0
    x_0_4     disj1_0_3_1  -1.0
    x_0_4     disj2_0_3_1  1.0
    x_0_4     disj1_0_4_1  -1.0
    x_0_4     disj2_0_4_1  1.0
    x_0_4     disj1_0_5_1  -1.0
    x_0_4     disj2_0_5_1  1.0
    x_0_4     disj1_0_6_1  -1.0
    x_0_4     disj2_0_6_1  1.0
    x_0_4     disj1_0_7_1  -1.0
    x_0_4     disj2_0_7_1  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_4  1.0
    x_1_0     disj2_0_1_4  -1.0
    x_1_0     disj1_1_2_4  -1.0
    x_1_0     disj2_1_2_4  1.0
    x_1_0     disj1_1_3_4  -1.0
    x_1_0     disj2_1_3_4  1.0
    x_1_0     disj1_1_4_4  -1.0
    x_1_0     disj2_1_4_4  1.0
    x_1_0     disj1_1_5_4  -1.0
    x_1_0     disj2_1_5_4  1.0
    x_1_0     disj1_1_6_4  -1.0
    x_1_0     disj2_1_6_4  1.0
    x_1_0     disj1_1_7_4  -1.0
    x_1_0     disj2_1_7_4  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_3  1.0
    x_1_1     disj2_0_1_3  -1.0
    x_1_1     disj1_1_2_3  -1.0
    x_1_1     disj2_1_2_3  1.0
    x_1_1     disj1_1_3_3  -1.0
    x_1_1     disj2_1_3_3  1.0
    x_1_1     disj1_1_4_3  -1.0
    x_1_1     disj2_1_4_3  1.0
    x_1_1     disj1_1_5_3  -1.0
    x_1_1     disj2_1_5_3  1.0
    x_1_1     disj1_1_6_3  -1.0
    x_1_1     disj2_1_6_3  1.0
    x_1_1     disj1_1_7_3  -1.0
    x_1_1     disj2_1_7_3  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_0  1.0
    x_1_2     disj2_0_1_0  -1.0
    x_1_2     disj1_1_2_0  -1.0
    x_1_2     disj2_1_2_0  1.0
    x_1_2     disj1_1_3_0  -1.0
    x_1_2     disj2_1_3_0  1.0
    x_1_2     disj1_1_4_0  -1.0
    x_1_2     disj2_1_4_0  1.0
    x_1_2     disj1_1_5_0  -1.0
    x_1_2     disj2_1_5_0  1.0
    x_1_2     disj1_1_6_0  -1.0
    x_1_2     disj2_1_6_0  1.0
    x_1_2     disj1_1_7_0  -1.0
    x_1_2     disj2_1_7_0  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_1  1.0
    x_1_3     disj2_0_1_1  -1.0
    x_1_3     disj1_1_2_1  -1.0
    x_1_3     disj2_1_2_1  1.0
    x_1_3     disj1_1_3_1  -1.0
    x_1_3     disj2_1_3_1  1.0
    x_1_3     disj1_1_4_1  -1.0
    x_1_3     disj2_1_4_1  1.0
    x_1_3     disj1_1_5_1  -1.0
    x_1_3     disj2_1_5_1  1.0
    x_1_3     disj1_1_6_1  -1.0
    x_1_3     disj2_1_6_1  1.0
    x_1_3     disj1_1_7_1  -1.0
    x_1_3     disj2_1_7_1  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     mksp_1    -1.0
    x_1_4     disj1_0_1_2  1.0
    x_1_4     disj2_0_1_2  -1.0
    x_1_4     disj1_1_2_2  -1.0
    x_1_4     disj2_1_2_2  1.0
    x_1_4     disj1_1_3_2  -1.0
    x_1_4     disj2_1_3_2  1.0
    x_1_4     disj1_1_4_2  -1.0
    x_1_4     disj2_1_4_2  1.0
    x_1_4     disj1_1_5_2  -1.0
    x_1_4     disj2_1_5_2  1.0
    x_1_4     disj1_1_6_2  -1.0
    x_1_4     disj2_1_6_2  1.0
    x_1_4     disj1_1_7_2  -1.0
    x_1_4     disj2_1_7_2  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_0  1.0
    x_2_0     disj2_0_2_0  -1.0
    x_2_0     disj1_1_2_0  1.0
    x_2_0     disj2_1_2_0  -1.0
    x_2_0     disj1_2_3_0  -1.0
    x_2_0     disj2_2_3_0  1.0
    x_2_0     disj1_2_4_0  -1.0
    x_2_0     disj2_2_4_0  1.0
    x_2_0     disj1_2_5_0  -1.0
    x_2_0     disj2_2_5_0  1.0
    x_2_0     disj1_2_6_0  -1.0
    x_2_0     disj2_2_6_0  1.0
    x_2_0     disj1_2_7_0  -1.0
    x_2_0     disj2_2_7_0  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_1     disj1_2_6_3  -1.0
    x_2_1     disj2_2_6_3  1.0
    x_2_1     disj1_2_7_3  -1.0
    x_2_1     disj2_2_7_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_2  1.0
    x_2_2     disj2_0_2_2  -1.0
    x_2_2     disj1_1_2_2  1.0
    x_2_2     disj2_1_2_2  -1.0
    x_2_2     disj1_2_3_2  -1.0
    x_2_2     disj2_2_3_2  1.0
    x_2_2     disj1_2_4_2  -1.0
    x_2_2     disj2_2_4_2  1.0
    x_2_2     disj1_2_5_2  -1.0
    x_2_2     disj2_2_5_2  1.0
    x_2_2     disj1_2_6_2  -1.0
    x_2_2     disj2_2_6_2  1.0
    x_2_2     disj1_2_7_2  -1.0
    x_2_2     disj2_2_7_2  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_4  1.0
    x_2_3     disj2_0_2_4  -1.0
    x_2_3     disj1_1_2_4  1.0
    x_2_3     disj2_1_2_4  -1.0
    x_2_3     disj1_2_3_4  -1.0
    x_2_3     disj2_2_3_4  1.0
    x_2_3     disj1_2_4_4  -1.0
    x_2_3     disj2_2_4_4  1.0
    x_2_3     disj1_2_5_4  -1.0
    x_2_3     disj2_2_5_4  1.0
    x_2_3     disj1_2_6_4  -1.0
    x_2_3     disj2_2_6_4  1.0
    x_2_3     disj1_2_7_4  -1.0
    x_2_3     disj2_2_7_4  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     mksp_2    -1.0
    x_2_4     disj1_0_2_1  1.0
    x_2_4     disj2_0_2_1  -1.0
    x_2_4     disj1_1_2_1  1.0
    x_2_4     disj2_1_2_1  -1.0
    x_2_4     disj1_2_3_1  -1.0
    x_2_4     disj2_2_3_1  1.0
    x_2_4     disj1_2_4_1  -1.0
    x_2_4     disj2_2_4_1  1.0
    x_2_4     disj1_2_5_1  -1.0
    x_2_4     disj2_2_5_1  1.0
    x_2_4     disj1_2_6_1  -1.0
    x_2_4     disj2_2_6_1  1.0
    x_2_4     disj1_2_7_1  -1.0
    x_2_4     disj2_2_7_1  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_3  1.0
    x_3_0     disj2_0_3_3  -1.0
    x_3_0     disj1_1_3_3  1.0
    x_3_0     disj2_1_3_3  -1.0
    x_3_0     disj1_2_3_3  1.0
    x_3_0     disj2_2_3_3  -1.0
    x_3_0     disj1_3_4_3  -1.0
    x_3_0     disj2_3_4_3  1.0
    x_3_0     disj1_3_5_3  -1.0
    x_3_0     disj2_3_5_3  1.0
    x_3_0     disj1_3_6_3  -1.0
    x_3_0     disj2_3_6_3  1.0
    x_3_0     disj1_3_7_3  -1.0
    x_3_0     disj2_3_7_3  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_4  1.0
    x_3_1     disj2_0_3_4  -1.0
    x_3_1     disj1_1_3_4  1.0
    x_3_1     disj2_1_3_4  -1.0
    x_3_1     disj1_2_3_4  1.0
    x_3_1     disj2_2_3_4  -1.0
    x_3_1     disj1_3_4_4  -1.0
    x_3_1     disj2_3_4_4  1.0
    x_3_1     disj1_3_5_4  -1.0
    x_3_1     disj2_3_5_4  1.0
    x_3_1     disj1_3_6_4  -1.0
    x_3_1     disj2_3_6_4  1.0
    x_3_1     disj1_3_7_4  -1.0
    x_3_1     disj2_3_7_4  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_1  1.0
    x_3_2     disj2_0_3_1  -1.0
    x_3_2     disj1_1_3_1  1.0
    x_3_2     disj2_1_3_1  -1.0
    x_3_2     disj1_2_3_1  1.0
    x_3_2     disj2_2_3_1  -1.0
    x_3_2     disj1_3_4_1  -1.0
    x_3_2     disj2_3_4_1  1.0
    x_3_2     disj1_3_5_1  -1.0
    x_3_2     disj2_3_5_1  1.0
    x_3_2     disj1_3_6_1  -1.0
    x_3_2     disj2_3_6_1  1.0
    x_3_2     disj1_3_7_1  -1.0
    x_3_2     disj2_3_7_1  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_0  1.0
    x_3_3     disj2_0_3_0  -1.0
    x_3_3     disj1_1_3_0  1.0
    x_3_3     disj2_1_3_0  -1.0
    x_3_3     disj1_2_3_0  1.0
    x_3_3     disj2_2_3_0  -1.0
    x_3_3     disj1_3_4_0  -1.0
    x_3_3     disj2_3_4_0  1.0
    x_3_3     disj1_3_5_0  -1.0
    x_3_3     disj2_3_5_0  1.0
    x_3_3     disj1_3_6_0  -1.0
    x_3_3     disj2_3_6_0  1.0
    x_3_3     disj1_3_7_0  -1.0
    x_3_3     disj2_3_7_0  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     mksp_3    -1.0
    x_3_4     disj1_0_3_2  1.0
    x_3_4     disj2_0_3_2  -1.0
    x_3_4     disj1_1_3_2  1.0
    x_3_4     disj2_1_3_2  -1.0
    x_3_4     disj1_2_3_2  1.0
    x_3_4     disj2_2_3_2  -1.0
    x_3_4     disj1_3_4_2  -1.0
    x_3_4     disj2_3_4_2  1.0
    x_3_4     disj1_3_5_2  -1.0
    x_3_4     disj2_3_5_2  1.0
    x_3_4     disj1_3_6_2  -1.0
    x_3_4     disj2_3_6_2  1.0
    x_3_4     disj1_3_7_2  -1.0
    x_3_4     disj2_3_7_2  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_2  1.0
    x_4_0     disj2_0_4_2  -1.0
    x_4_0     disj1_1_4_2  1.0
    x_4_0     disj2_1_4_2  -1.0
    x_4_0     disj1_2_4_2  1.0
    x_4_0     disj2_2_4_2  -1.0
    x_4_0     disj1_3_4_2  1.0
    x_4_0     disj2_3_4_2  -1.0
    x_4_0     disj1_4_5_2  -1.0
    x_4_0     disj2_4_5_2  1.0
    x_4_0     disj1_4_6_2  -1.0
    x_4_0     disj2_4_6_2  1.0
    x_4_0     disj1_4_7_2  -1.0
    x_4_0     disj2_4_7_2  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_0  1.0
    x_4_1     disj2_0_4_0  -1.0
    x_4_1     disj1_1_4_0  1.0
    x_4_1     disj2_1_4_0  -1.0
    x_4_1     disj1_2_4_0  1.0
    x_4_1     disj2_2_4_0  -1.0
    x_4_1     disj1_3_4_0  1.0
    x_4_1     disj2_3_4_0  -1.0
    x_4_1     disj1_4_5_0  -1.0
    x_4_1     disj2_4_5_0  1.0
    x_4_1     disj1_4_6_0  -1.0
    x_4_1     disj2_4_6_0  1.0
    x_4_1     disj1_4_7_0  -1.0
    x_4_1     disj2_4_7_0  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_4  1.0
    x_4_2     disj2_0_4_4  -1.0
    x_4_2     disj1_1_4_4  1.0
    x_4_2     disj2_1_4_4  -1.0
    x_4_2     disj1_2_4_4  1.0
    x_4_2     disj2_2_4_4  -1.0
    x_4_2     disj1_3_4_4  1.0
    x_4_2     disj2_3_4_4  -1.0
    x_4_2     disj1_4_5_4  -1.0
    x_4_2     disj2_4_5_4  1.0
    x_4_2     disj1_4_6_4  -1.0
    x_4_2     disj2_4_6_4  1.0
    x_4_2     disj1_4_7_4  -1.0
    x_4_2     disj2_4_7_4  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_3     disj1_4_7_1  -1.0
    x_4_3     disj2_4_7_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     mksp_4    -1.0
    x_4_4     disj1_0_4_3  1.0
    x_4_4     disj2_0_4_3  -1.0
    x_4_4     disj1_1_4_3  1.0
    x_4_4     disj2_1_4_3  -1.0
    x_4_4     disj1_2_4_3  1.0
    x_4_4     disj2_2_4_3  -1.0
    x_4_4     disj1_3_4_3  1.0
    x_4_4     disj2_3_4_3  -1.0
    x_4_4     disj1_4_5_3  -1.0
    x_4_4     disj2_4_5_3  1.0
    x_4_4     disj1_4_6_3  -1.0
    x_4_4     disj2_4_6_3  1.0
    x_4_4     disj1_4_7_3  -1.0
    x_4_4     disj2_4_7_3  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_0  1.0
    x_5_0     disj2_0_5_0  -1.0
    x_5_0     disj1_1_5_0  1.0
    x_5_0     disj2_1_5_0  -1.0
    x_5_0     disj1_2_5_0  1.0
    x_5_0     disj2_2_5_0  -1.0
    x_5_0     disj1_3_5_0  1.0
    x_5_0     disj2_3_5_0  -1.0
    x_5_0     disj1_4_5_0  1.0
    x_5_0     disj2_4_5_0  -1.0
    x_5_0     disj1_5_6_0  -1.0
    x_5_0     disj2_5_6_0  1.0
    x_5_0     disj1_5_7_0  -1.0
    x_5_0     disj2_5_7_0  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_4  1.0
    x_5_1     disj2_0_5_4  -1.0
    x_5_1     disj1_1_5_4  1.0
    x_5_1     disj2_1_5_4  -1.0
    x_5_1     disj1_2_5_4  1.0
    x_5_1     disj2_2_5_4  -1.0
    x_5_1     disj1_3_5_4  1.0
    x_5_1     disj2_3_5_4  -1.0
    x_5_1     disj1_4_5_4  1.0
    x_5_1     disj2_4_5_4  -1.0
    x_5_1     disj1_5_6_4  -1.0
    x_5_1     disj2_5_6_4  1.0
    x_5_1     disj1_5_7_4  -1.0
    x_5_1     disj2_5_7_4  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_1  1.0
    x_5_2     disj2_0_5_1  -1.0
    x_5_2     disj1_1_5_1  1.0
    x_5_2     disj2_1_5_1  -1.0
    x_5_2     disj1_2_5_1  1.0
    x_5_2     disj2_2_5_1  -1.0
    x_5_2     disj1_3_5_1  1.0
    x_5_2     disj2_3_5_1  -1.0
    x_5_2     disj1_4_5_1  1.0
    x_5_2     disj2_4_5_1  -1.0
    x_5_2     disj1_5_6_1  -1.0
    x_5_2     disj2_5_6_1  1.0
    x_5_2     disj1_5_7_1  -1.0
    x_5_2     disj2_5_7_1  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_2  1.0
    x_5_3     disj2_0_5_2  -1.0
    x_5_3     disj1_1_5_2  1.0
    x_5_3     disj2_1_5_2  -1.0
    x_5_3     disj1_2_5_2  1.0
    x_5_3     disj2_2_5_2  -1.0
    x_5_3     disj1_3_5_2  1.0
    x_5_3     disj2_3_5_2  -1.0
    x_5_3     disj1_4_5_2  1.0
    x_5_3     disj2_4_5_2  -1.0
    x_5_3     disj1_5_6_2  -1.0
    x_5_3     disj2_5_6_2  1.0
    x_5_3     disj1_5_7_2  -1.0
    x_5_3     disj2_5_7_2  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     mksp_5    -1.0
    x_5_4     disj1_0_5_3  1.0
    x_5_4     disj2_0_5_3  -1.0
    x_5_4     disj1_1_5_3  1.0
    x_5_4     disj2_1_5_3  -1.0
    x_5_4     disj1_2_5_3  1.0
    x_5_4     disj2_2_5_3  -1.0
    x_5_4     disj1_3_5_3  1.0
    x_5_4     disj2_3_5_3  -1.0
    x_5_4     disj1_4_5_3  1.0
    x_5_4     disj2_4_5_3  -1.0
    x_5_4     disj1_5_6_3  -1.0
    x_5_4     disj2_5_6_3  1.0
    x_5_4     disj1_5_7_3  -1.0
    x_5_4     disj2_5_7_3  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_2  1.0
    x_6_0     disj2_0_6_2  -1.0
    x_6_0     disj1_1_6_2  1.0
    x_6_0     disj2_1_6_2  -1.0
    x_6_0     disj1_2_6_2  1.0
    x_6_0     disj2_2_6_2  -1.0
    x_6_0     disj1_3_6_2  1.0
    x_6_0     disj2_3_6_2  -1.0
    x_6_0     disj1_4_6_2  1.0
    x_6_0     disj2_4_6_2  -1.0
    x_6_0     disj1_5_6_2  1.0
    x_6_0     disj2_5_6_2  -1.0
    x_6_0     disj1_6_7_2  -1.0
    x_6_0     disj2_6_7_2  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_0  1.0
    x_6_1     disj2_0_6_0  -1.0
    x_6_1     disj1_1_6_0  1.0
    x_6_1     disj2_1_6_0  -1.0
    x_6_1     disj1_2_6_0  1.0
    x_6_1     disj2_2_6_0  -1.0
    x_6_1     disj1_3_6_0  1.0
    x_6_1     disj2_3_6_0  -1.0
    x_6_1     disj1_4_6_0  1.0
    x_6_1     disj2_4_6_0  -1.0
    x_6_1     disj1_5_6_0  1.0
    x_6_1     disj2_5_6_0  -1.0
    x_6_1     disj1_6_7_0  -1.0
    x_6_1     disj2_6_7_0  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_3  1.0
    x_6_2     disj2_0_6_3  -1.0
    x_6_2     disj1_1_6_3  1.0
    x_6_2     disj2_1_6_3  -1.0
    x_6_2     disj1_2_6_3  1.0
    x_6_2     disj2_2_6_3  -1.0
    x_6_2     disj1_3_6_3  1.0
    x_6_2     disj2_3_6_3  -1.0
    x_6_2     disj1_4_6_3  1.0
    x_6_2     disj2_4_6_3  -1.0
    x_6_2     disj1_5_6_3  1.0
    x_6_2     disj2_5_6_3  -1.0
    x_6_2     disj1_6_7_3  -1.0
    x_6_2     disj2_6_7_3  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_1  1.0
    x_6_3     disj2_0_6_1  -1.0
    x_6_3     disj1_1_6_1  1.0
    x_6_3     disj2_1_6_1  -1.0
    x_6_3     disj1_2_6_1  1.0
    x_6_3     disj2_2_6_1  -1.0
    x_6_3     disj1_3_6_1  1.0
    x_6_3     disj2_3_6_1  -1.0
    x_6_3     disj1_4_6_1  1.0
    x_6_3     disj2_4_6_1  -1.0
    x_6_3     disj1_5_6_1  1.0
    x_6_3     disj2_5_6_1  -1.0
    x_6_3     disj1_6_7_1  -1.0
    x_6_3     disj2_6_7_1  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     mksp_6    -1.0
    x_6_4     disj1_0_6_4  1.0
    x_6_4     disj2_0_6_4  -1.0
    x_6_4     disj1_1_6_4  1.0
    x_6_4     disj2_1_6_4  -1.0
    x_6_4     disj1_2_6_4  1.0
    x_6_4     disj2_2_6_4  -1.0
    x_6_4     disj1_3_6_4  1.0
    x_6_4     disj2_3_6_4  -1.0
    x_6_4     disj1_4_6_4  1.0
    x_6_4     disj2_4_6_4  -1.0
    x_6_4     disj1_5_6_4  1.0
    x_6_4     disj2_5_6_4  -1.0
    x_6_4     disj1_6_7_4  -1.0
    x_6_4     disj2_6_7_4  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_1  1.0
    x_7_0     disj2_0_7_1  -1.0
    x_7_0     disj1_1_7_1  1.0
    x_7_0     disj2_1_7_1  -1.0
    x_7_0     disj1_2_7_1  1.0
    x_7_0     disj2_2_7_1  -1.0
    x_7_0     disj1_3_7_1  1.0
    x_7_0     disj2_3_7_1  -1.0
    x_7_0     disj1_4_7_1  1.0
    x_7_0     disj2_4_7_1  -1.0
    x_7_0     disj1_5_7_1  1.0
    x_7_0     disj2_5_7_1  -1.0
    x_7_0     disj1_6_7_1  1.0
    x_7_0     disj2_6_7_1  -1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_3  1.0
    x_7_1     disj2_0_7_3  -1.0
    x_7_1     disj1_1_7_3  1.0
    x_7_1     disj2_1_7_3  -1.0
    x_7_1     disj1_2_7_3  1.0
    x_7_1     disj2_2_7_3  -1.0
    x_7_1     disj1_3_7_3  1.0
    x_7_1     disj2_3_7_3  -1.0
    x_7_1     disj1_4_7_3  1.0
    x_7_1     disj2_4_7_3  -1.0
    x_7_1     disj1_5_7_3  1.0
    x_7_1     disj2_5_7_3  -1.0
    x_7_1     disj1_6_7_3  1.0
    x_7_1     disj2_6_7_3  -1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_2  1.0
    x_7_2     disj2_0_7_2  -1.0
    x_7_2     disj1_1_7_2  1.0
    x_7_2     disj2_1_7_2  -1.0
    x_7_2     disj1_2_7_2  1.0
    x_7_2     disj2_2_7_2  -1.0
    x_7_2     disj1_3_7_2  1.0
    x_7_2     disj2_3_7_2  -1.0
    x_7_2     disj1_4_7_2  1.0
    x_7_2     disj2_4_7_2  -1.0
    x_7_2     disj1_5_7_2  1.0
    x_7_2     disj2_5_7_2  -1.0
    x_7_2     disj1_6_7_2  1.0
    x_7_2     disj2_6_7_2  -1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_0  1.0
    x_7_3     disj2_0_7_0  -1.0
    x_7_3     disj1_1_7_0  1.0
    x_7_3     disj2_1_7_0  -1.0
    x_7_3     disj1_2_7_0  1.0
    x_7_3     disj2_2_7_0  -1.0
    x_7_3     disj1_3_7_0  1.0
    x_7_3     disj2_3_7_0  -1.0
    x_7_3     disj1_4_7_0  1.0
    x_7_3     disj2_4_7_0  -1.0
    x_7_3     disj1_5_7_0  1.0
    x_7_3     disj2_5_7_0  -1.0
    x_7_3     disj1_6_7_0  1.0
    x_7_3     disj2_6_7_0  -1.0
    x_7_4     prec_7_3  1.0
    x_7_4     mksp_7    -1.0
    x_7_4     disj1_0_7_4  1.0
    x_7_4     disj2_0_7_4  -1.0
    x_7_4     disj1_1_7_4  1.0
    x_7_4     disj2_1_7_4  -1.0
    x_7_4     disj1_2_7_4  1.0
    x_7_4     disj2_2_7_4  -1.0
    x_7_4     disj1_3_7_4  1.0
    x_7_4     disj2_3_7_4  -1.0
    x_7_4     disj1_4_7_4  1.0
    x_7_4     disj2_4_7_4  -1.0
    x_7_4     disj1_5_7_4  1.0
    x_7_4     disj2_5_7_4  -1.0
    x_7_4     disj1_6_7_4  1.0
    x_7_4     disj2_6_7_4  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  469
    y_0_1_0   disj2_0_1_0  -469
    y_0_1_1   disj1_0_1_1  469
    y_0_1_1   disj2_0_1_1  -469
    y_0_1_2   disj1_0_1_2  469
    y_0_1_2   disj2_0_1_2  -469
    y_0_1_3   disj1_0_1_3  469
    y_0_1_3   disj2_0_1_3  -469
    y_0_1_4   disj1_0_1_4  469
    y_0_1_4   disj2_0_1_4  -469
    y_0_2_0   disj1_0_2_0  469
    y_0_2_0   disj2_0_2_0  -469
    y_0_2_1   disj1_0_2_1  469
    y_0_2_1   disj2_0_2_1  -469
    y_0_2_2   disj1_0_2_2  469
    y_0_2_2   disj2_0_2_2  -469
    y_0_2_3   disj1_0_2_3  469
    y_0_2_3   disj2_0_2_3  -469
    y_0_2_4   disj1_0_2_4  469
    y_0_2_4   disj2_0_2_4  -469
    y_0_3_0   disj1_0_3_0  469
    y_0_3_0   disj2_0_3_0  -469
    y_0_3_1   disj1_0_3_1  469
    y_0_3_1   disj2_0_3_1  -469
    y_0_3_2   disj1_0_3_2  469
    y_0_3_2   disj2_0_3_2  -469
    y_0_3_3   disj1_0_3_3  469
    y_0_3_3   disj2_0_3_3  -469
    y_0_3_4   disj1_0_3_4  469
    y_0_3_4   disj2_0_3_4  -469
    y_0_4_0   disj1_0_4_0  469
    y_0_4_0   disj2_0_4_0  -469
    y_0_4_1   disj1_0_4_1  469
    y_0_4_1   disj2_0_4_1  -469
    y_0_4_2   disj1_0_4_2  469
    y_0_4_2   disj2_0_4_2  -469
    y_0_4_3   disj1_0_4_3  469
    y_0_4_3   disj2_0_4_3  -469
    y_0_4_4   disj1_0_4_4  469
    y_0_4_4   disj2_0_4_4  -469
    y_0_5_0   disj1_0_5_0  469
    y_0_5_0   disj2_0_5_0  -469
    y_0_5_1   disj1_0_5_1  469
    y_0_5_1   disj2_0_5_1  -469
    y_0_5_2   disj1_0_5_2  469
    y_0_5_2   disj2_0_5_2  -469
    y_0_5_3   disj1_0_5_3  469
    y_0_5_3   disj2_0_5_3  -469
    y_0_5_4   disj1_0_5_4  469
    y_0_5_4   disj2_0_5_4  -469
    y_0_6_0   disj1_0_6_0  469
    y_0_6_0   disj2_0_6_0  -469
    y_0_6_1   disj1_0_6_1  469
    y_0_6_1   disj2_0_6_1  -469
    y_0_6_2   disj1_0_6_2  469
    y_0_6_2   disj2_0_6_2  -469
    y_0_6_3   disj1_0_6_3  469
    y_0_6_3   disj2_0_6_3  -469
    y_0_6_4   disj1_0_6_4  469
    y_0_6_4   disj2_0_6_4  -469
    y_0_7_0   disj1_0_7_0  469
    y_0_7_0   disj2_0_7_0  -469
    y_0_7_1   disj1_0_7_1  469
    y_0_7_1   disj2_0_7_1  -469
    y_0_7_2   disj1_0_7_2  469
    y_0_7_2   disj2_0_7_2  -469
    y_0_7_3   disj1_0_7_3  469
    y_0_7_3   disj2_0_7_3  -469
    y_0_7_4   disj1_0_7_4  469
    y_0_7_4   disj2_0_7_4  -469
    y_1_2_0   disj1_1_2_0  469
    y_1_2_0   disj2_1_2_0  -469
    y_1_2_1   disj1_1_2_1  469
    y_1_2_1   disj2_1_2_1  -469
    y_1_2_2   disj1_1_2_2  469
    y_1_2_2   disj2_1_2_2  -469
    y_1_2_3   disj1_1_2_3  469
    y_1_2_3   disj2_1_2_3  -469
    y_1_2_4   disj1_1_2_4  469
    y_1_2_4   disj2_1_2_4  -469
    y_1_3_0   disj1_1_3_0  469
    y_1_3_0   disj2_1_3_0  -469
    y_1_3_1   disj1_1_3_1  469
    y_1_3_1   disj2_1_3_1  -469
    y_1_3_2   disj1_1_3_2  469
    y_1_3_2   disj2_1_3_2  -469
    y_1_3_3   disj1_1_3_3  469
    y_1_3_3   disj2_1_3_3  -469
    y_1_3_4   disj1_1_3_4  469
    y_1_3_4   disj2_1_3_4  -469
    y_1_4_0   disj1_1_4_0  469
    y_1_4_0   disj2_1_4_0  -469
    y_1_4_1   disj1_1_4_1  469
    y_1_4_1   disj2_1_4_1  -469
    y_1_4_2   disj1_1_4_2  469
    y_1_4_2   disj2_1_4_2  -469
    y_1_4_3   disj1_1_4_3  469
    y_1_4_3   disj2_1_4_3  -469
    y_1_4_4   disj1_1_4_4  469
    y_1_4_4   disj2_1_4_4  -469
    y_1_5_0   disj1_1_5_0  469
    y_1_5_0   disj2_1_5_0  -469
    y_1_5_1   disj1_1_5_1  469
    y_1_5_1   disj2_1_5_1  -469
    y_1_5_2   disj1_1_5_2  469
    y_1_5_2   disj2_1_5_2  -469
    y_1_5_3   disj1_1_5_3  469
    y_1_5_3   disj2_1_5_3  -469
    y_1_5_4   disj1_1_5_4  469
    y_1_5_4   disj2_1_5_4  -469
    y_1_6_0   disj1_1_6_0  469
    y_1_6_0   disj2_1_6_0  -469
    y_1_6_1   disj1_1_6_1  469
    y_1_6_1   disj2_1_6_1  -469
    y_1_6_2   disj1_1_6_2  469
    y_1_6_2   disj2_1_6_2  -469
    y_1_6_3   disj1_1_6_3  469
    y_1_6_3   disj2_1_6_3  -469
    y_1_6_4   disj1_1_6_4  469
    y_1_6_4   disj2_1_6_4  -469
    y_1_7_0   disj1_1_7_0  469
    y_1_7_0   disj2_1_7_0  -469
    y_1_7_1   disj1_1_7_1  469
    y_1_7_1   disj2_1_7_1  -469
    y_1_7_2   disj1_1_7_2  469
    y_1_7_2   disj2_1_7_2  -469
    y_1_7_3   disj1_1_7_3  469
    y_1_7_3   disj2_1_7_3  -469
    y_1_7_4   disj1_1_7_4  469
    y_1_7_4   disj2_1_7_4  -469
    y_2_3_0   disj1_2_3_0  469
    y_2_3_0   disj2_2_3_0  -469
    y_2_3_1   disj1_2_3_1  469
    y_2_3_1   disj2_2_3_1  -469
    y_2_3_2   disj1_2_3_2  469
    y_2_3_2   disj2_2_3_2  -469
    y_2_3_3   disj1_2_3_3  469
    y_2_3_3   disj2_2_3_3  -469
    y_2_3_4   disj1_2_3_4  469
    y_2_3_4   disj2_2_3_4  -469
    y_2_4_0   disj1_2_4_0  469
    y_2_4_0   disj2_2_4_0  -469
    y_2_4_1   disj1_2_4_1  469
    y_2_4_1   disj2_2_4_1  -469
    y_2_4_2   disj1_2_4_2  469
    y_2_4_2   disj2_2_4_2  -469
    y_2_4_3   disj1_2_4_3  469
    y_2_4_3   disj2_2_4_3  -469
    y_2_4_4   disj1_2_4_4  469
    y_2_4_4   disj2_2_4_4  -469
    y_2_5_0   disj1_2_5_0  469
    y_2_5_0   disj2_2_5_0  -469
    y_2_5_1   disj1_2_5_1  469
    y_2_5_1   disj2_2_5_1  -469
    y_2_5_2   disj1_2_5_2  469
    y_2_5_2   disj2_2_5_2  -469
    y_2_5_3   disj1_2_5_3  469
    y_2_5_3   disj2_2_5_3  -469
    y_2_5_4   disj1_2_5_4  469
    y_2_5_4   disj2_2_5_4  -469
    y_2_6_0   disj1_2_6_0  469
    y_2_6_0   disj2_2_6_0  -469
    y_2_6_1   disj1_2_6_1  469
    y_2_6_1   disj2_2_6_1  -469
    y_2_6_2   disj1_2_6_2  469
    y_2_6_2   disj2_2_6_2  -469
    y_2_6_3   disj1_2_6_3  469
    y_2_6_3   disj2_2_6_3  -469
    y_2_6_4   disj1_2_6_4  469
    y_2_6_4   disj2_2_6_4  -469
    y_2_7_0   disj1_2_7_0  469
    y_2_7_0   disj2_2_7_0  -469
    y_2_7_1   disj1_2_7_1  469
    y_2_7_1   disj2_2_7_1  -469
    y_2_7_2   disj1_2_7_2  469
    y_2_7_2   disj2_2_7_2  -469
    y_2_7_3   disj1_2_7_3  469
    y_2_7_3   disj2_2_7_3  -469
    y_2_7_4   disj1_2_7_4  469
    y_2_7_4   disj2_2_7_4  -469
    y_3_4_0   disj1_3_4_0  469
    y_3_4_0   disj2_3_4_0  -469
    y_3_4_1   disj1_3_4_1  469
    y_3_4_1   disj2_3_4_1  -469
    y_3_4_2   disj1_3_4_2  469
    y_3_4_2   disj2_3_4_2  -469
    y_3_4_3   disj1_3_4_3  469
    y_3_4_3   disj2_3_4_3  -469
    y_3_4_4   disj1_3_4_4  469
    y_3_4_4   disj2_3_4_4  -469
    y_3_5_0   disj1_3_5_0  469
    y_3_5_0   disj2_3_5_0  -469
    y_3_5_1   disj1_3_5_1  469
    y_3_5_1   disj2_3_5_1  -469
    y_3_5_2   disj1_3_5_2  469
    y_3_5_2   disj2_3_5_2  -469
    y_3_5_3   disj1_3_5_3  469
    y_3_5_3   disj2_3_5_3  -469
    y_3_5_4   disj1_3_5_4  469
    y_3_5_4   disj2_3_5_4  -469
    y_3_6_0   disj1_3_6_0  469
    y_3_6_0   disj2_3_6_0  -469
    y_3_6_1   disj1_3_6_1  469
    y_3_6_1   disj2_3_6_1  -469
    y_3_6_2   disj1_3_6_2  469
    y_3_6_2   disj2_3_6_2  -469
    y_3_6_3   disj1_3_6_3  469
    y_3_6_3   disj2_3_6_3  -469
    y_3_6_4   disj1_3_6_4  469
    y_3_6_4   disj2_3_6_4  -469
    y_3_7_0   disj1_3_7_0  469
    y_3_7_0   disj2_3_7_0  -469
    y_3_7_1   disj1_3_7_1  469
    y_3_7_1   disj2_3_7_1  -469
    y_3_7_2   disj1_3_7_2  469
    y_3_7_2   disj2_3_7_2  -469
    y_3_7_3   disj1_3_7_3  469
    y_3_7_3   disj2_3_7_3  -469
    y_3_7_4   disj1_3_7_4  469
    y_3_7_4   disj2_3_7_4  -469
    y_4_5_0   disj1_4_5_0  469
    y_4_5_0   disj2_4_5_0  -469
    y_4_5_1   disj1_4_5_1  469
    y_4_5_1   disj2_4_5_1  -469
    y_4_5_2   disj1_4_5_2  469
    y_4_5_2   disj2_4_5_2  -469
    y_4_5_3   disj1_4_5_3  469
    y_4_5_3   disj2_4_5_3  -469
    y_4_5_4   disj1_4_5_4  469
    y_4_5_4   disj2_4_5_4  -469
    y_4_6_0   disj1_4_6_0  469
    y_4_6_0   disj2_4_6_0  -469
    y_4_6_1   disj1_4_6_1  469
    y_4_6_1   disj2_4_6_1  -469
    y_4_6_2   disj1_4_6_2  469
    y_4_6_2   disj2_4_6_2  -469
    y_4_6_3   disj1_4_6_3  469
    y_4_6_3   disj2_4_6_3  -469
    y_4_6_4   disj1_4_6_4  469
    y_4_6_4   disj2_4_6_4  -469
    y_4_7_0   disj1_4_7_0  469
    y_4_7_0   disj2_4_7_0  -469
    y_4_7_1   disj1_4_7_1  469
    y_4_7_1   disj2_4_7_1  -469
    y_4_7_2   disj1_4_7_2  469
    y_4_7_2   disj2_4_7_2  -469
    y_4_7_3   disj1_4_7_3  469
    y_4_7_3   disj2_4_7_3  -469
    y_4_7_4   disj1_4_7_4  469
    y_4_7_4   disj2_4_7_4  -469
    y_5_6_0   disj1_5_6_0  469
    y_5_6_0   disj2_5_6_0  -469
    y_5_6_1   disj1_5_6_1  469
    y_5_6_1   disj2_5_6_1  -469
    y_5_6_2   disj1_5_6_2  469
    y_5_6_2   disj2_5_6_2  -469
    y_5_6_3   disj1_5_6_3  469
    y_5_6_3   disj2_5_6_3  -469
    y_5_6_4   disj1_5_6_4  469
    y_5_6_4   disj2_5_6_4  -469
    y_5_7_0   disj1_5_7_0  469
    y_5_7_0   disj2_5_7_0  -469
    y_5_7_1   disj1_5_7_1  469
    y_5_7_1   disj2_5_7_1  -469
    y_5_7_2   disj1_5_7_2  469
    y_5_7_2   disj2_5_7_2  -469
    y_5_7_3   disj1_5_7_3  469
    y_5_7_3   disj2_5_7_3  -469
    y_5_7_4   disj1_5_7_4  469
    y_5_7_4   disj2_5_7_4  -469
    y_6_7_0   disj1_6_7_0  469
    y_6_7_0   disj2_6_7_0  -469
    y_6_7_1   disj1_6_7_1  469
    y_6_7_1   disj2_6_7_1  -469
    y_6_7_2   disj1_6_7_2  469
    y_6_7_2   disj2_6_7_2  -469
    y_6_7_3   disj1_6_7_3  469
    y_6_7_3   disj2_6_7_3  -469
    y_6_7_4   disj1_6_7_4  469
    y_6_7_4   disj2_6_7_4  -469
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  19
    RHS       prec_0_1  3
    RHS       prec_0_2  20
    RHS       prec_0_3  1
    RHS       prec_1_0  18
    RHS       prec_1_1  18
    RHS       prec_1_2  16
    RHS       prec_1_3  13
    RHS       prec_2_0  1
    RHS       prec_2_1  3
    RHS       prec_2_2  6
    RHS       prec_2_3  19
    RHS       prec_3_0  20
    RHS       prec_3_1  13
    RHS       prec_3_2  14
    RHS       prec_3_3  13
    RHS       prec_4_0  2
    RHS       prec_4_1  5
    RHS       prec_4_2  16
    RHS       prec_4_3  7
    RHS       prec_5_0  19
    RHS       prec_5_1  12
    RHS       prec_5_2  18
    RHS       prec_5_3  19
    RHS       prec_6_0  9
    RHS       prec_6_1  20
    RHS       prec_6_2  6
    RHS       prec_6_3  11
    RHS       prec_7_0  19
    RHS       prec_7_1  9
    RHS       prec_7_2  10
    RHS       prec_7_3  4
    RHS       mksp_0    16
    RHS       mksp_1    5
    RHS       mksp_2    2
    RHS       mksp_3    19
    RHS       mksp_4    9
    RHS       mksp_5    14
    RHS       mksp_6    18
    RHS       mksp_7    3
    RHS       disj1_0_1_0  19
    RHS       disj2_0_1_0  -453
    RHS       disj1_0_2_0  19
    RHS       disj2_0_2_0  -468
    RHS       disj1_0_3_0  19
    RHS       disj2_0_3_0  -456
    RHS       disj1_0_4_0  19
    RHS       disj2_0_4_0  -464
    RHS       disj1_0_5_0  19
    RHS       disj2_0_5_0  -450
    RHS       disj1_0_6_0  19
    RHS       disj2_0_6_0  -449
    RHS       disj1_0_7_0  19
    RHS       disj2_0_7_0  -465
    RHS       disj1_1_2_0  16
    RHS       disj2_1_2_0  -468
    RHS       disj1_1_3_0  16
    RHS       disj2_1_3_0  -456
    RHS       disj1_1_4_0  16
    RHS       disj2_1_4_0  -464
    RHS       disj1_1_5_0  16
    RHS       disj2_1_5_0  -450
    RHS       disj1_1_6_0  16
    RHS       disj2_1_6_0  -449
    RHS       disj1_1_7_0  16
    RHS       disj2_1_7_0  -465
    RHS       disj1_2_3_0  1
    RHS       disj2_2_3_0  -456
    RHS       disj1_2_4_0  1
    RHS       disj2_2_4_0  -464
    RHS       disj1_2_5_0  1
    RHS       disj2_2_5_0  -450
    RHS       disj1_2_6_0  1
    RHS       disj2_2_6_0  -449
    RHS       disj1_2_7_0  1
    RHS       disj2_2_7_0  -465
    RHS       disj1_3_4_0  13
    RHS       disj2_3_4_0  -464
    RHS       disj1_3_5_0  13
    RHS       disj2_3_5_0  -450
    RHS       disj1_3_6_0  13
    RHS       disj2_3_6_0  -449
    RHS       disj1_3_7_0  13
    RHS       disj2_3_7_0  -465
    RHS       disj1_4_5_0  5
    RHS       disj2_4_5_0  -450
    RHS       disj1_4_6_0  5
    RHS       disj2_4_6_0  -449
    RHS       disj1_4_7_0  5
    RHS       disj2_4_7_0  -465
    RHS       disj1_5_6_0  19
    RHS       disj2_5_6_0  -449
    RHS       disj1_5_7_0  19
    RHS       disj2_5_7_0  -465
    RHS       disj1_6_7_0  20
    RHS       disj2_6_7_0  -465
    RHS       disj1_0_1_1  16
    RHS       disj2_0_1_1  -456
    RHS       disj1_0_2_1  16
    RHS       disj2_0_2_1  -467
    RHS       disj1_0_3_1  16
    RHS       disj2_0_3_1  -455
    RHS       disj1_0_4_1  16
    RHS       disj2_0_4_1  -462
    RHS       disj1_0_5_1  16
    RHS       disj2_0_5_1  -451
    RHS       disj1_0_6_1  16
    RHS       disj2_0_6_1  -458
    RHS       disj1_0_7_1  16
    RHS       disj2_0_7_1  -450
    RHS       disj1_1_2_1  13
    RHS       disj2_1_2_1  -467
    RHS       disj1_1_3_1  13
    RHS       disj2_1_3_1  -455
    RHS       disj1_1_4_1  13
    RHS       disj2_1_4_1  -462
    RHS       disj1_1_5_1  13
    RHS       disj2_1_5_1  -451
    RHS       disj1_1_6_1  13
    RHS       disj2_1_6_1  -458
    RHS       disj1_1_7_1  13
    RHS       disj2_1_7_1  -450
    RHS       disj1_2_3_1  2
    RHS       disj2_2_3_1  -455
    RHS       disj1_2_4_1  2
    RHS       disj2_2_4_1  -462
    RHS       disj1_2_5_1  2
    RHS       disj2_2_5_1  -451
    RHS       disj1_2_6_1  2
    RHS       disj2_2_6_1  -458
    RHS       disj1_2_7_1  2
    RHS       disj2_2_7_1  -450
    RHS       disj1_3_4_1  14
    RHS       disj2_3_4_1  -462
    RHS       disj1_3_5_1  14
    RHS       disj2_3_5_1  -451
    RHS       disj1_3_6_1  14
    RHS       disj2_3_6_1  -458
    RHS       disj1_3_7_1  14
    RHS       disj2_3_7_1  -450
    RHS       disj1_4_5_1  7
    RHS       disj2_4_5_1  -451
    RHS       disj1_4_6_1  7
    RHS       disj2_4_6_1  -458
    RHS       disj1_4_7_1  7
    RHS       disj2_4_7_1  -450
    RHS       disj1_5_6_1  18
    RHS       disj2_5_6_1  -458
    RHS       disj1_5_7_1  18
    RHS       disj2_5_7_1  -450
    RHS       disj1_6_7_1  11
    RHS       disj2_6_7_1  -450
    RHS       disj1_0_1_2  3
    RHS       disj2_0_1_2  -464
    RHS       disj1_0_2_2  3
    RHS       disj2_0_2_2  -463
    RHS       disj1_0_3_2  3
    RHS       disj2_0_3_2  -450
    RHS       disj1_0_4_2  3
    RHS       disj2_0_4_2  -467
    RHS       disj1_0_5_2  3
    RHS       disj2_0_5_2  -450
    RHS       disj1_0_6_2  3
    RHS       disj2_0_6_2  -460
    RHS       disj1_0_7_2  3
    RHS       disj2_0_7_2  -459
    RHS       disj1_1_2_2  5
    RHS       disj2_1_2_2  -463
    RHS       disj1_1_3_2  5
    RHS       disj2_1_3_2  -450
    RHS       disj1_1_4_2  5
    RHS       disj2_1_4_2  -467
    RHS       disj1_1_5_2  5
    RHS       disj2_1_5_2  -450
    RHS       disj1_1_6_2  5
    RHS       disj2_1_6_2  -460
    RHS       disj1_1_7_2  5
    RHS       disj2_1_7_2  -459
    RHS       disj1_2_3_2  6
    RHS       disj2_2_3_2  -450
    RHS       disj1_2_4_2  6
    RHS       disj2_2_4_2  -467
    RHS       disj1_2_5_2  6
    RHS       disj2_2_5_2  -450
    RHS       disj1_2_6_2  6
    RHS       disj2_2_6_2  -460
    RHS       disj1_2_7_2  6
    RHS       disj2_2_7_2  -459
    RHS       disj1_3_4_2  19
    RHS       disj2_3_4_2  -467
    RHS       disj1_3_5_2  19
    RHS       disj2_3_5_2  -450
    RHS       disj1_3_6_2  19
    RHS       disj2_3_6_2  -460
    RHS       disj1_3_7_2  19
    RHS       disj2_3_7_2  -459
    RHS       disj1_4_5_2  2
    RHS       disj2_4_5_2  -450
    RHS       disj1_4_6_2  2
    RHS       disj2_4_6_2  -460
    RHS       disj1_4_7_2  2
    RHS       disj2_4_7_2  -459
    RHS       disj1_5_6_2  19
    RHS       disj2_5_6_2  -460
    RHS       disj1_5_7_2  19
    RHS       disj2_5_7_2  -459
    RHS       disj1_6_7_2  9
    RHS       disj2_6_7_2  -459
    RHS       disj1_0_1_3  20
    RHS       disj2_0_1_3  -451
    RHS       disj1_0_2_3  20
    RHS       disj2_0_2_3  -466
    RHS       disj1_0_3_3  20
    RHS       disj2_0_3_3  -449
    RHS       disj1_0_4_3  20
    RHS       disj2_0_4_3  -460
    RHS       disj1_0_5_3  20
    RHS       disj2_0_5_3  -455
    RHS       disj1_0_6_3  20
    RHS       disj2_0_6_3  -463
    RHS       disj1_0_7_3  20
    RHS       disj2_0_7_3  -460
    RHS       disj1_1_2_3  18
    RHS       disj2_1_2_3  -466
    RHS       disj1_1_3_3  18
    RHS       disj2_1_3_3  -449
    RHS       disj1_1_4_3  18
    RHS       disj2_1_4_3  -460
    RHS       disj1_1_5_3  18
    RHS       disj2_1_5_3  -455
    RHS       disj1_1_6_3  18
    RHS       disj2_1_6_3  -463
    RHS       disj1_1_7_3  18
    RHS       disj2_1_7_3  -460
    RHS       disj1_2_3_3  3
    RHS       disj2_2_3_3  -449
    RHS       disj1_2_4_3  3
    RHS       disj2_2_4_3  -460
    RHS       disj1_2_5_3  3
    RHS       disj2_2_5_3  -455
    RHS       disj1_2_6_3  3
    RHS       disj2_2_6_3  -463
    RHS       disj1_2_7_3  3
    RHS       disj2_2_7_3  -460
    RHS       disj1_3_4_3  20
    RHS       disj2_3_4_3  -460
    RHS       disj1_3_5_3  20
    RHS       disj2_3_5_3  -455
    RHS       disj1_3_6_3  20
    RHS       disj2_3_6_3  -463
    RHS       disj1_3_7_3  20
    RHS       disj2_3_7_3  -460
    RHS       disj1_4_5_3  9
    RHS       disj2_4_5_3  -455
    RHS       disj1_4_6_3  9
    RHS       disj2_4_6_3  -463
    RHS       disj1_4_7_3  9
    RHS       disj2_4_7_3  -460
    RHS       disj1_5_6_3  14
    RHS       disj2_5_6_3  -463
    RHS       disj1_5_7_3  14
    RHS       disj2_5_7_3  -460
    RHS       disj1_6_7_3  6
    RHS       disj2_6_7_3  -460
    RHS       disj1_0_1_4  1
    RHS       disj2_0_1_4  -451
    RHS       disj1_0_2_4  1
    RHS       disj2_0_2_4  -450
    RHS       disj1_0_3_4  1
    RHS       disj2_0_3_4  -456
    RHS       disj1_0_4_4  1
    RHS       disj2_0_4_4  -453
    RHS       disj1_0_5_4  1
    RHS       disj2_0_5_4  -457
    RHS       disj1_0_6_4  1
    RHS       disj2_0_6_4  -451
    RHS       disj1_0_7_4  1
    RHS       disj2_0_7_4  -466
    RHS       disj1_1_2_4  18
    RHS       disj2_1_2_4  -450
    RHS       disj1_1_3_4  18
    RHS       disj2_1_3_4  -456
    RHS       disj1_1_4_4  18
    RHS       disj2_1_4_4  -453
    RHS       disj1_1_5_4  18
    RHS       disj2_1_5_4  -457
    RHS       disj1_1_6_4  18
    RHS       disj2_1_6_4  -451
    RHS       disj1_1_7_4  18
    RHS       disj2_1_7_4  -466
    RHS       disj1_2_3_4  19
    RHS       disj2_2_3_4  -456
    RHS       disj1_2_4_4  19
    RHS       disj2_2_4_4  -453
    RHS       disj1_2_5_4  19
    RHS       disj2_2_5_4  -457
    RHS       disj1_2_6_4  19
    RHS       disj2_2_6_4  -451
    RHS       disj1_2_7_4  19
    RHS       disj2_2_7_4  -466
    RHS       disj1_3_4_4  13
    RHS       disj2_3_4_4  -453
    RHS       disj1_3_5_4  13
    RHS       disj2_3_5_4  -457
    RHS       disj1_3_6_4  13
    RHS       disj2_3_6_4  -451
    RHS       disj1_3_7_4  13
    RHS       disj2_3_7_4  -466
    RHS       disj1_4_5_4  16
    RHS       disj2_4_5_4  -457
    RHS       disj1_4_6_4  16
    RHS       disj2_4_6_4  -451
    RHS       disj1_4_7_4  16
    RHS       disj2_4_7_4  -466
    RHS       disj1_5_6_4  12
    RHS       disj2_5_6_4  -451
    RHS       disj1_5_7_4  12
    RHS       disj2_5_7_4  -466
    RHS       disj1_6_7_4  18
    RHS       disj2_6_7_4  -466
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
ENDATA
