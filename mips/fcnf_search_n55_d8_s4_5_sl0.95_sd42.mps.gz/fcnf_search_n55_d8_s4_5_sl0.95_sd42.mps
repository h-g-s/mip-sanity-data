NAME          fcnf_search_n55_d8_s4_5_sl0.95_sd42
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 E  flow_25
 E  flow_26
 E  flow_27
 E  flow_28
 E  flow_29
 E  flow_30
 E  flow_31
 E  flow_32
 E  flow_33
 E  flow_34
 E  flow_35
 E  flow_36
 E  flow_37
 E  flow_38
 E  flow_39
 E  flow_40
 E  flow_41
 E  flow_42
 E  flow_43
 E  flow_44
 E  flow_45
 E  flow_46
 E  flow_47
 E  flow_48
 E  flow_49
 E  flow_50
 E  flow_51
 E  flow_52
 E  flow_53
 E  flow_54
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
 L  link_84
 L  link_85
 L  link_86
 L  link_87
 L  link_88
 L  link_89
 L  link_90
 L  link_91
 L  link_92
 L  link_93
 L  link_94
 L  link_95
 L  link_96
 L  link_97
 L  link_98
 L  link_99
 L  link_100
 L  link_101
 L  link_102
 L  link_103
 L  link_104
 L  link_105
 L  link_106
 L  link_107
 L  link_108
 L  link_109
 L  link_110
 L  link_111
 L  link_112
 L  link_113
 L  link_114
 L  link_115
 L  link_116
 L  link_117
 L  link_118
 L  link_119
 L  link_120
 L  link_121
 L  link_122
 L  link_123
 L  link_124
 L  link_125
 L  link_126
 L  link_127
 L  link_128
 L  link_129
 L  link_130
 L  link_131
 L  link_132
 L  link_133
 L  link_134
 L  link_135
 L  link_136
 L  link_137
 L  link_138
 L  link_139
 L  link_140
 L  link_141
 L  link_142
 L  link_143
 L  link_144
 L  link_145
 L  link_146
 L  link_147
 L  link_148
 L  link_149
 L  link_150
 L  link_151
 L  link_152
 L  link_153
 L  link_154
 L  link_155
 L  link_156
 L  link_157
 L  link_158
 L  link_159
 L  link_160
 L  link_161
 L  link_162
 L  link_163
 L  link_164
 L  link_165
 L  link_166
 L  link_167
 L  link_168
 L  link_169
 L  link_170
 L  link_171
 L  link_172
 L  link_173
 L  link_174
 L  link_175
 L  link_176
 L  link_177
 L  link_178
 L  link_179
 L  link_180
 L  link_181
 L  link_182
 L  link_183
 L  link_184
 L  link_185
 L  link_186
 L  link_187
 L  link_188
 L  link_189
 L  link_190
 L  link_191
 L  link_192
 L  link_193
 L  link_194
 L  link_195
 L  link_196
 L  link_197
 L  link_198
 L  link_199
 L  link_200
 L  link_201
 L  link_202
 L  link_203
 L  link_204
 L  link_205
 L  link_206
 L  link_207
 L  link_208
 L  link_209
 L  link_210
 L  link_211
 L  link_212
 L  link_213
 L  link_214
 L  link_215
 L  link_216
 L  link_217
 L  link_218
 L  link_219
 L  link_220
 L  link_221
 L  link_222
 L  link_223
 L  link_224
 L  link_225
 L  link_226
 L  link_227
 L  link_228
 L  link_229
 L  link_230
 L  link_231
 L  link_232
 L  link_233
 L  link_234
 L  link_235
 L  link_236
 L  link_237
 L  link_238
 L  link_239
 L  link_240
 L  link_241
 L  link_242
 L  link_243
 L  link_244
 L  link_245
 L  link_246
 L  link_247
 L  link_248
 L  link_249
 L  link_250
 L  link_251
 L  link_252
 L  link_253
 L  link_254
 L  link_255
 L  link_256
 L  link_257
 L  link_258
 L  link_259
 L  link_260
 L  link_261
 L  link_262
 L  link_263
 L  link_264
 L  link_265
 L  link_266
 L  link_267
 L  link_268
 L  link_269
 L  link_270
 L  link_271
 L  link_272
 L  link_273
 L  link_274
 L  link_275
 L  link_276
 L  link_277
 L  link_278
 L  link_279
 L  link_280
 L  link_281
 L  link_282
 L  link_283
 L  link_284
 L  link_285
 L  link_286
 L  link_287
 L  link_288
 L  link_289
 L  link_290
 L  link_291
 L  link_292
 L  link_293
 L  link_294
 L  link_295
 L  link_296
 L  link_297
 L  link_298
 L  link_299
 L  link_300
 L  link_301
 L  link_302
 L  link_303
 L  link_304
 L  link_305
 L  link_306
 L  link_307
 L  link_308
 L  link_309
 L  link_310
 L  link_311
 L  link_312
 L  link_313
 L  link_314
 L  link_315
 L  link_316
 L  link_317
 L  link_318
 L  link_319
 L  link_320
 L  link_321
 L  link_322
 L  link_323
 L  link_324
 L  link_325
 L  link_326
 L  link_327
 L  link_328
 L  link_329
 L  link_330
 L  link_331
 L  link_332
 L  link_333
 L  link_334
 L  link_335
 L  link_336
 L  link_337
 L  link_338
 L  link_339
 L  link_340
 L  link_341
 L  link_342
 L  link_343
 L  link_344
 L  link_345
 L  link_346
 L  link_347
 L  link_348
 L  link_349
 L  link_350
 L  link_351
 L  link_352
 L  link_353
 L  link_354
 L  link_355
 L  link_356
 L  link_357
 L  link_358
 L  link_359
 L  link_360
 L  link_361
 L  link_362
 L  link_363
 L  link_364
 L  link_365
 L  link_366
 L  link_367
 L  link_368
 L  link_369
 L  link_370
 L  link_371
 L  link_372
 L  link_373
 L  link_374
 L  link_375
 L  link_376
 L  link_377
 L  link_378
 L  link_379
 L  link_380
 L  link_381
 L  link_382
 L  link_383
 L  link_384
 L  link_385
 L  link_386
 L  link_387
 L  link_388
 L  link_389
 L  link_390
 L  link_391
 L  link_392
 L  link_393
 L  link_394
 L  link_395
 L  link_396
 L  link_397
 L  link_398
 L  link_399
 L  link_400
 L  link_401
 L  link_402
 L  link_403
 L  link_404
 L  link_405
 L  link_406
 L  link_407
 L  link_408
 L  link_409
 L  link_410
 L  link_411
 L  link_412
 L  link_413
 L  link_414
 L  link_415
 L  link_416
 L  link_417
 L  link_418
 L  link_419
 L  link_420
 L  link_421
 L  link_422
 L  link_423
 L  link_424
 L  link_425
 L  link_426
 L  link_427
 L  link_428
 L  link_429
 L  link_430
 L  link_431
 L  link_432
 L  link_433
 L  link_434
 L  link_435
 L  link_436
 L  link_437
 L  link_438
 L  link_439
COLUMNS
    x_0         OBJ       1.19
    x_0         flow_40     1.0
    x_0         flow_7      -1.0
    x_0         link_0      1.0
    x_1         OBJ       52.72
    x_1         flow_6      1.0
    x_1         flow_43     -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.76
    x_2         flow_1      1.0
    x_2         flow_5      -1.0
    x_2         link_2      1.0
    x_3         OBJ       45.17
    x_3         flow_45     1.0
    x_3         flow_41     -1.0
    x_3         link_3      1.0
    x_4         OBJ       29.58
    x_4         flow_51     1.0
    x_4         flow_0      -1.0
    x_4         link_4      1.0
    x_5         OBJ       40.2
    x_5         flow_9      1.0
    x_5         flow_13     -1.0
    x_5         link_5      1.0
    x_6         OBJ       1.16
    x_6         flow_22     1.0
    x_6         flow_54     -1.0
    x_6         link_6      1.0
    x_7         OBJ       42.71
    x_7         flow_34     1.0
    x_7         flow_7      -1.0
    x_7         link_7      1.0
    x_8         OBJ       41.7
    x_8         flow_40     1.0
    x_8         flow_39     -1.0
    x_8         link_8      1.0
    x_9         OBJ       1.22
    x_9         flow_2      1.0
    x_9         flow_42     -1.0
    x_9         link_9      1.0
    x_10        OBJ       2.09
    x_10        flow_6      1.0
    x_10        flow_24     -1.0
    x_10        link_10     1.0
    x_11        OBJ       62.11
    x_11        flow_22     1.0
    x_11        flow_13     -1.0
    x_11        link_11     1.0
    x_12        OBJ       2.32
    x_12        flow_38     1.0
    x_12        flow_40     -1.0
    x_12        link_12     1.0
    x_13        OBJ       33.18
    x_13        flow_17     1.0
    x_13        flow_40     -1.0
    x_13        link_13     1.0
    x_14        OBJ       0.58
    x_14        flow_49     1.0
    x_14        flow_3      -1.0
    x_14        link_14     1.0
    x_15        OBJ       54.03
    x_15        flow_4      1.0
    x_15        flow_13     -1.0
    x_15        link_15     1.0
    x_16        OBJ       2.79
    x_16        flow_41     1.0
    x_16        flow_31     -1.0
    x_16        link_16     1.0
    x_17        OBJ       52.34
    x_17        flow_8      1.0
    x_17        flow_15     -1.0
    x_17        link_17     1.0
    x_18        OBJ       2.99
    x_18        flow_37     1.0
    x_18        flow_25     -1.0
    x_18        link_18     1.0
    x_19        OBJ       0.77
    x_19        flow_5      1.0
    x_19        flow_48     -1.0
    x_19        link_19     1.0
    x_20        OBJ       43.09
    x_20        flow_43     1.0
    x_20        flow_27     -1.0
    x_20        link_20     1.0
    x_21        OBJ       71.65
    x_21        flow_33     1.0
    x_21        flow_16     -1.0
    x_21        link_21     1.0
    x_22        OBJ       65.05
    x_22        flow_7      1.0
    x_22        flow_43     -1.0
    x_22        link_22     1.0
    x_23        OBJ       1.63
    x_23        flow_7      1.0
    x_23        flow_18     -1.0
    x_23        link_23     1.0
    x_24        OBJ       50.46
    x_24        flow_16     1.0
    x_24        flow_32     -1.0
    x_24        link_24     1.0
    x_25        OBJ       56.54
    x_25        flow_19     1.0
    x_25        flow_53     -1.0
    x_25        link_25     1.0
    x_26        OBJ       75.35
    x_26        flow_10     1.0
    x_26        flow_34     -1.0
    x_26        link_26     1.0
    x_27        OBJ       2.82
    x_27        flow_20     1.0
    x_27        flow_31     -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.1
    x_28        flow_51     1.0
    x_28        flow_19     -1.0
    x_28        link_28     1.0
    x_29        OBJ       0.67
    x_29        flow_5      1.0
    x_29        flow_46     -1.0
    x_29        link_29     1.0
    x_30        OBJ       29.91
    x_30        flow_42     1.0
    x_30        flow_30     -1.0
    x_30        link_30     1.0
    x_31        OBJ       65.32
    x_31        flow_27     1.0
    x_31        flow_13     -1.0
    x_31        link_31     1.0
    x_32        OBJ       58.99
    x_32        flow_19     1.0
    x_32        flow_25     -1.0
    x_32        link_32     1.0
    x_33        OBJ       0.66
    x_33        flow_28     1.0
    x_33        flow_7      -1.0
    x_33        link_33     1.0
    x_34        OBJ       0.68
    x_34        flow_14     1.0
    x_34        flow_37     -1.0
    x_34        link_34     1.0
    x_35        OBJ       24.25
    x_35        flow_4      1.0
    x_35        flow_2      -1.0
    x_35        link_35     1.0
    x_36        OBJ       63.4
    x_36        flow_31     1.0
    x_36        flow_13     -1.0
    x_36        link_36     1.0
    x_37        OBJ       68.45
    x_37        flow_30     1.0
    x_37        flow_15     -1.0
    x_37        link_37     1.0
    x_38        OBJ       1.53
    x_38        flow_42     1.0
    x_38        flow_27     -1.0
    x_38        link_38     1.0
    x_39        OBJ       25.91
    x_39        flow_43     1.0
    x_39        flow_41     -1.0
    x_39        link_39     1.0
    x_40        OBJ       0.98
    x_40        flow_51     1.0
    x_40        flow_6      -1.0
    x_40        link_40     1.0
    x_41        OBJ       2.69
    x_41        flow_11     1.0
    x_41        flow_17     -1.0
    x_41        link_41     1.0
    x_42        OBJ       2.13
    x_42        flow_54     1.0
    x_42        flow_35     -1.0
    x_42        link_42     1.0
    x_43        OBJ       1.71
    x_43        flow_54     1.0
    x_43        flow_15     -1.0
    x_43        link_43     1.0
    x_44        OBJ       2.96
    x_44        flow_3      1.0
    x_44        flow_10     -1.0
    x_44        link_44     1.0
    x_45        OBJ       2.24
    x_45        flow_50     1.0
    x_45        flow_29     -1.0
    x_45        link_45     1.0
    x_46        OBJ       29.29
    x_46        flow_35     1.0
    x_46        flow_42     -1.0
    x_46        link_46     1.0
    x_47        OBJ       64.88
    x_47        flow_37     1.0
    x_47        flow_47     -1.0
    x_47        link_47     1.0
    x_48        OBJ       51.87
    x_48        flow_30     1.0
    x_48        flow_32     -1.0
    x_48        link_48     1.0
    x_49        OBJ       1.99
    x_49        flow_5      1.0
    x_49        flow_54     -1.0
    x_49        link_49     1.0
    x_50        OBJ       54.18
    x_50        flow_25     1.0
    x_50        flow_7      -1.0
    x_50        link_50     1.0
    x_51        OBJ       1.96
    x_51        flow_39     1.0
    x_51        flow_5      -1.0
    x_51        link_51     1.0
    x_52        OBJ       34.32
    x_52        flow_13     1.0
    x_52        flow_42     -1.0
    x_52        link_52     1.0
    x_53        OBJ       2.82
    x_53        flow_41     1.0
    x_53        flow_19     -1.0
    x_53        link_53     1.0
    x_54        OBJ       79.77
    x_54        flow_29     1.0
    x_54        flow_39     -1.0
    x_54        link_54     1.0
    x_55        OBJ       1.37
    x_55        flow_32     1.0
    x_55        flow_16     -1.0
    x_55        link_55     1.0
    x_56        OBJ       2.58
    x_56        flow_23     1.0
    x_56        flow_18     -1.0
    x_56        link_56     1.0
    x_57        OBJ       60.07
    x_57        flow_51     1.0
    x_57        flow_41     -1.0
    x_57        link_57     1.0
    x_58        OBJ       2.72
    x_58        flow_6      1.0
    x_58        flow_8      -1.0
    x_58        link_58     1.0
    x_59        OBJ       63.06
    x_59        flow_17     1.0
    x_59        flow_18     -1.0
    x_59        link_59     1.0
    x_60        OBJ       35.07
    x_60        flow_54     1.0
    x_60        flow_16     -1.0
    x_60        link_60     1.0
    x_61        OBJ       1.19
    x_61        flow_5      1.0
    x_61        flow_40     -1.0
    x_61        link_61     1.0
    x_62        OBJ       29.69
    x_62        flow_8      1.0
    x_62        flow_40     -1.0
    x_62        link_62     1.0
    x_63        OBJ       0.69
    x_63        flow_27     1.0
    x_63        flow_35     -1.0
    x_63        link_63     1.0
    x_64        OBJ       54.95
    x_64        flow_34     1.0
    x_64        flow_2      -1.0
    x_64        link_64     1.0
    x_65        OBJ       2.83
    x_65        flow_2      1.0
    x_65        flow_19     -1.0
    x_65        link_65     1.0
    x_66        OBJ       41.22
    x_66        flow_43     1.0
    x_66        flow_15     -1.0
    x_66        link_66     1.0
    x_67        OBJ       75.55
    x_67        flow_26     1.0
    x_67        flow_39     -1.0
    x_67        link_67     1.0
    x_68        OBJ       2.34
    x_68        flow_11     1.0
    x_68        flow_26     -1.0
    x_68        link_68     1.0
    x_69        OBJ       68.64
    x_69        flow_51     1.0
    x_69        flow_42     -1.0
    x_69        link_69     1.0
    x_70        OBJ       0.6
    x_70        flow_44     1.0
    x_70        flow_6      -1.0
    x_70        link_70     1.0
    x_71        OBJ       2.55
    x_71        flow_52     1.0
    x_71        flow_29     -1.0
    x_71        link_71     1.0
    x_72        OBJ       1.32
    x_72        flow_1      1.0
    x_72        flow_42     -1.0
    x_72        link_72     1.0
    x_73        OBJ       43.98
    x_73        flow_17     1.0
    x_73        flow_22     -1.0
    x_73        link_73     1.0
    x_74        OBJ       2.93
    x_74        flow_21     1.0
    x_74        flow_1      -1.0
    x_74        link_74     1.0
    x_75        OBJ       40.74
    x_75        flow_2      1.0
    x_75        flow_6      -1.0
    x_75        link_75     1.0
    x_76        OBJ       2.75
    x_76        flow_38     1.0
    x_76        flow_32     -1.0
    x_76        link_76     1.0
    x_77        OBJ       2.81
    x_77        flow_45     1.0
    x_77        flow_27     -1.0
    x_77        link_77     1.0
    x_78        OBJ       0.67
    x_78        flow_42     1.0
    x_78        flow_12     -1.0
    x_78        link_78     1.0
    x_79        OBJ       27.48
    x_79        flow_39     1.0
    x_79        flow_20     -1.0
    x_79        link_79     1.0
    x_80        OBJ       1.51
    x_80        flow_19     1.0
    x_80        flow_42     -1.0
    x_80        link_80     1.0
    x_81        OBJ       42.75
    x_81        flow_12     1.0
    x_81        flow_26     -1.0
    x_81        link_81     1.0
    x_82        OBJ       1.87
    x_82        flow_39     1.0
    x_82        flow_36     -1.0
    x_82        link_82     1.0
    x_83        OBJ       56.4
    x_83        flow_13     1.0
    x_83        flow_27     -1.0
    x_83        link_83     1.0
    x_84        OBJ       1.68
    x_84        flow_28     1.0
    x_84        flow_43     -1.0
    x_84        link_84     1.0
    x_85        OBJ       37.03
    x_85        flow_47     1.0
    x_85        flow_10     -1.0
    x_85        link_85     1.0
    x_86        OBJ       65.07
    x_86        flow_21     1.0
    x_86        flow_5      -1.0
    x_86        link_86     1.0
    x_87        OBJ       0.62
    x_87        flow_51     1.0
    x_87        flow_12     -1.0
    x_87        link_87     1.0
    x_88        OBJ       1.54
    x_88        flow_54     1.0
    x_88        flow_49     -1.0
    x_88        link_88     1.0
    x_89        OBJ       1.5
    x_89        flow_45     1.0
    x_89        flow_44     -1.0
    x_89        link_89     1.0
    x_90        OBJ       73.13
    x_90        flow_0      1.0
    x_90        flow_48     -1.0
    x_90        link_90     1.0
    x_91        OBJ       51.08
    x_91        flow_11     1.0
    x_91        flow_51     -1.0
    x_91        link_91     1.0
    x_92        OBJ       2.5
    x_92        flow_54     1.0
    x_92        flow_7      -1.0
    x_92        link_92     1.0
    x_93        OBJ       73.49
    x_93        flow_38     1.0
    x_93        flow_20     -1.0
    x_93        link_93     1.0
    x_94        OBJ       52.87
    x_94        flow_32     1.0
    x_94        flow_27     -1.0
    x_94        link_94     1.0
    x_95        OBJ       1.12
    x_95        flow_30     1.0
    x_95        flow_28     -1.0
    x_95        link_95     1.0
    x_96        OBJ       1.1
    x_96        flow_49     1.0
    x_96        flow_33     -1.0
    x_96        link_96     1.0
    x_97        OBJ       1.3
    x_97        flow_18     1.0
    x_97        flow_15     -1.0
    x_97        link_97     1.0
    x_98        OBJ       0.88
    x_98        flow_9      1.0
    x_98        flow_14     -1.0
    x_98        link_98     1.0
    x_99        OBJ       44.95
    x_99        flow_26     1.0
    x_99        flow_21     -1.0
    x_99        link_99     1.0
    x_100       OBJ       61.73
    x_100       flow_24     1.0
    x_100       flow_49     -1.0
    x_100       link_100    1.0
    x_101       OBJ       2.86
    x_101       flow_36     1.0
    x_101       flow_24     -1.0
    x_101       link_101    1.0
    x_102       OBJ       2.37
    x_102       flow_54     1.0
    x_102       flow_53     -1.0
    x_102       link_102    1.0
    x_103       OBJ       1.59
    x_103       flow_14     1.0
    x_103       flow_31     -1.0
    x_103       link_103    1.0
    x_104       OBJ       63.45
    x_104       flow_42     1.0
    x_104       flow_43     -1.0
    x_104       link_104    1.0
    x_105       OBJ       1.49
    x_105       flow_39     1.0
    x_105       flow_34     -1.0
    x_105       link_105    1.0
    x_106       OBJ       2.67
    x_106       flow_5      1.0
    x_106       flow_41     -1.0
    x_106       link_106    1.0
    x_107       OBJ       1.32
    x_107       flow_24     1.0
    x_107       flow_20     -1.0
    x_107       link_107    1.0
    x_108       OBJ       45.29
    x_108       flow_17     1.0
    x_108       flow_48     -1.0
    x_108       link_108    1.0
    x_109       OBJ       79.99
    x_109       flow_1      1.0
    x_109       flow_47     -1.0
    x_109       link_109    1.0
    x_110       OBJ       22.42
    x_110       flow_4      1.0
    x_110       flow_49     -1.0
    x_110       link_110    1.0
    x_111       OBJ       0.88
    x_111       flow_12     1.0
    x_111       flow_53     -1.0
    x_111       link_111    1.0
    x_112       OBJ       47.9
    x_112       flow_7      1.0
    x_112       flow_36     -1.0
    x_112       link_112    1.0
    x_113       OBJ       64.88
    x_113       flow_10     1.0
    x_113       flow_38     -1.0
    x_113       link_113    1.0
    x_114       OBJ       0.56
    x_114       flow_10     1.0
    x_114       flow_19     -1.0
    x_114       link_114    1.0
    x_115       OBJ       31.9
    x_115       flow_24     1.0
    x_115       flow_25     -1.0
    x_115       link_115    1.0
    x_116       OBJ       2.43
    x_116       flow_40     1.0
    x_116       flow_15     -1.0
    x_116       link_116    1.0
    x_117       OBJ       53.96
    x_117       flow_51     1.0
    x_117       flow_7      -1.0
    x_117       link_117    1.0
    x_118       OBJ       1.76
    x_118       flow_27     1.0
    x_118       flow_42     -1.0
    x_118       link_118    1.0
    x_119       OBJ       1.58
    x_119       flow_26     1.0
    x_119       flow_52     -1.0
    x_119       link_119    1.0
    x_120       OBJ       0.94
    x_120       flow_29     1.0
    x_120       flow_45     -1.0
    x_120       link_120    1.0
    x_121       OBJ       52.29
    x_121       flow_17     1.0
    x_121       flow_39     -1.0
    x_121       link_121    1.0
    x_122       OBJ       39.34
    x_122       flow_52     1.0
    x_122       flow_46     -1.0
    x_122       link_122    1.0
    x_123       OBJ       1.66
    x_123       flow_17     1.0
    x_123       flow_28     -1.0
    x_123       link_123    1.0
    x_124       OBJ       1.72
    x_124       flow_31     1.0
    x_124       flow_54     -1.0
    x_124       link_124    1.0
    x_125       OBJ       62.07
    x_125       flow_21     1.0
    x_125       flow_17     -1.0
    x_125       link_125    1.0
    x_126       OBJ       2.3
    x_126       flow_33     1.0
    x_126       flow_12     -1.0
    x_126       link_126    1.0
    x_127       OBJ       2.28
    x_127       flow_15     1.0
    x_127       flow_44     -1.0
    x_127       link_127    1.0
    x_128       OBJ       2.23
    x_128       flow_5      1.0
    x_128       flow_18     -1.0
    x_128       link_128    1.0
    x_129       OBJ       40.63
    x_129       flow_23     1.0
    x_129       flow_30     -1.0
    x_129       link_129    1.0
    x_130       OBJ       36.25
    x_130       flow_21     1.0
    x_130       flow_22     -1.0
    x_130       link_130    1.0
    x_131       OBJ       2.36
    x_131       flow_46     1.0
    x_131       flow_12     -1.0
    x_131       link_131    1.0
    x_132       OBJ       1.71
    x_132       flow_11     1.0
    x_132       flow_12     -1.0
    x_132       link_132    1.0
    x_133       OBJ       0.75
    x_133       flow_33     1.0
    x_133       flow_38     -1.0
    x_133       link_133    1.0
    x_134       OBJ       2.27
    x_134       flow_23     1.0
    x_134       flow_11     -1.0
    x_134       link_134    1.0
    x_135       OBJ       2.86
    x_135       flow_3      1.0
    x_135       flow_35     -1.0
    x_135       link_135    1.0
    x_136       OBJ       54.44
    x_136       flow_31     1.0
    x_136       flow_6      -1.0
    x_136       link_136    1.0
    x_137       OBJ       35.15
    x_137       flow_21     1.0
    x_137       flow_11     -1.0
    x_137       link_137    1.0
    x_138       OBJ       0.69
    x_138       flow_52     1.0
    x_138       flow_4      -1.0
    x_138       link_138    1.0
    x_139       OBJ       25.11
    x_139       flow_51     1.0
    x_139       flow_36     -1.0
    x_139       link_139    1.0
    x_140       OBJ       67.44
    x_140       flow_48     1.0
    x_140       flow_26     -1.0
    x_140       link_140    1.0
    x_141       OBJ       37.84
    x_141       flow_24     1.0
    x_141       flow_28     -1.0
    x_141       link_141    1.0
    x_142       OBJ       56.58
    x_142       flow_19     1.0
    x_142       flow_36     -1.0
    x_142       link_142    1.0
    x_143       OBJ       2.15
    x_143       flow_13     1.0
    x_143       flow_40     -1.0
    x_143       link_143    1.0
    x_144       OBJ       1.52
    x_144       flow_35     1.0
    x_144       flow_4      -1.0
    x_144       link_144    1.0
    x_145       OBJ       2.27
    x_145       flow_18     1.0
    x_145       flow_2      -1.0
    x_145       link_145    1.0
    x_146       OBJ       1.16
    x_146       flow_4      1.0
    x_146       flow_43     -1.0
    x_146       link_146    1.0
    x_147       OBJ       45.51
    x_147       flow_42     1.0
    x_147       flow_51     -1.0
    x_147       link_147    1.0
    x_148       OBJ       24.28
    x_148       flow_9      1.0
    x_148       flow_17     -1.0
    x_148       link_148    1.0
    x_149       OBJ       75.27
    x_149       flow_38     1.0
    x_149       flow_47     -1.0
    x_149       link_149    1.0
    x_150       OBJ       76.56
    x_150       flow_44     1.0
    x_150       flow_19     -1.0
    x_150       link_150    1.0
    x_151       OBJ       73.37
    x_151       flow_28     1.0
    x_151       flow_5      -1.0
    x_151       link_151    1.0
    x_152       OBJ       2.9
    x_152       flow_16     1.0
    x_152       flow_1      -1.0
    x_152       link_152    1.0
    x_153       OBJ       60.34
    x_153       flow_37     1.0
    x_153       flow_1      -1.0
    x_153       link_153    1.0
    x_154       OBJ       46.53
    x_154       flow_11     1.0
    x_154       flow_30     -1.0
    x_154       link_154    1.0
    x_155       OBJ       78.14
    x_155       flow_27     1.0
    x_155       flow_40     -1.0
    x_155       link_155    1.0
    x_156       OBJ       71.46
    x_156       flow_21     1.0
    x_156       flow_20     -1.0
    x_156       link_156    1.0
    x_157       OBJ       44.03
    x_157       flow_31     1.0
    x_157       flow_18     -1.0
    x_157       link_157    1.0
    x_158       OBJ       1.31
    x_158       flow_29     1.0
    x_158       flow_5      -1.0
    x_158       link_158    1.0
    x_159       OBJ       59.46
    x_159       flow_32     1.0
    x_159       flow_52     -1.0
    x_159       link_159    1.0
    x_160       OBJ       57.36
    x_160       flow_3      1.0
    x_160       flow_12     -1.0
    x_160       link_160    1.0
    x_161       OBJ       1.87
    x_161       flow_48     1.0
    x_161       flow_3      -1.0
    x_161       link_161    1.0
    x_162       OBJ       2.93
    x_162       flow_44     1.0
    x_162       flow_31     -1.0
    x_162       link_162    1.0
    x_163       OBJ       0.53
    x_163       flow_45     1.0
    x_163       flow_10     -1.0
    x_163       link_163    1.0
    x_164       OBJ       0.79
    x_164       flow_53     1.0
    x_164       flow_7      -1.0
    x_164       link_164    1.0
    x_165       OBJ       36.41
    x_165       flow_45     1.0
    x_165       flow_18     -1.0
    x_165       link_165    1.0
    x_166       OBJ       43.02
    x_166       flow_15     1.0
    x_166       flow_29     -1.0
    x_166       link_166    1.0
    x_167       OBJ       36.57
    x_167       flow_47     1.0
    x_167       flow_8      -1.0
    x_167       link_167    1.0
    x_168       OBJ       69.23
    x_168       flow_21     1.0
    x_168       flow_50     -1.0
    x_168       link_168    1.0
    x_169       OBJ       59.6
    x_169       flow_53     1.0
    x_169       flow_37     -1.0
    x_169       link_169    1.0
    x_170       OBJ       1.88
    x_170       flow_34     1.0
    x_170       flow_30     -1.0
    x_170       link_170    1.0
    x_171       OBJ       34.33
    x_171       flow_20     1.0
    x_171       flow_12     -1.0
    x_171       link_171    1.0
    x_172       OBJ       2.36
    x_172       flow_49     1.0
    x_172       flow_26     -1.0
    x_172       link_172    1.0
    x_173       OBJ       78.85
    x_173       flow_42     1.0
    x_173       flow_50     -1.0
    x_173       link_173    1.0
    x_174       OBJ       39.92
    x_174       flow_8      1.0
    x_174       flow_32     -1.0
    x_174       link_174    1.0
    x_175       OBJ       47.42
    x_175       flow_28     1.0
    x_175       flow_6      -1.0
    x_175       link_175    1.0
    x_176       OBJ       2.45
    x_176       flow_41     1.0
    x_176       flow_9      -1.0
    x_176       link_176    1.0
    x_177       OBJ       71.11
    x_177       flow_44     1.0
    x_177       flow_25     -1.0
    x_177       link_177    1.0
    x_178       OBJ       57.61
    x_178       flow_34     1.0
    x_178       flow_24     -1.0
    x_178       link_178    1.0
    x_179       OBJ       2.21
    x_179       flow_39     1.0
    x_179       flow_4      -1.0
    x_179       link_179    1.0
    x_180       OBJ       0.75
    x_180       flow_47     1.0
    x_180       flow_5      -1.0
    x_180       link_180    1.0
    x_181       OBJ       1.25
    x_181       flow_6      1.0
    x_181       flow_28     -1.0
    x_181       link_181    1.0
    x_182       OBJ       1.44
    x_182       flow_50     1.0
    x_182       flow_3      -1.0
    x_182       link_182    1.0
    x_183       OBJ       30.8
    x_183       flow_26     1.0
    x_183       flow_36     -1.0
    x_183       link_183    1.0
    x_184       OBJ       49.86
    x_184       flow_24     1.0
    x_184       flow_39     -1.0
    x_184       link_184    1.0
    x_185       OBJ       1.14
    x_185       flow_29     1.0
    x_185       flow_40     -1.0
    x_185       link_185    1.0
    x_186       OBJ       29.48
    x_186       flow_29     1.0
    x_186       flow_18     -1.0
    x_186       link_186    1.0
    x_187       OBJ       45.46
    x_187       flow_37     1.0
    x_187       flow_19     -1.0
    x_187       link_187    1.0
    x_188       OBJ       71.2
    x_188       flow_19     1.0
    x_188       flow_12     -1.0
    x_188       link_188    1.0
    x_189       OBJ       79.56
    x_189       flow_36     1.0
    x_189       flow_22     -1.0
    x_189       link_189    1.0
    x_190       OBJ       1.91
    x_190       flow_42     1.0
    x_190       flow_25     -1.0
    x_190       link_190    1.0
    x_191       OBJ       69.97
    x_191       flow_3      1.0
    x_191       flow_38     -1.0
    x_191       link_191    1.0
    x_192       OBJ       41.14
    x_192       flow_51     1.0
    x_192       flow_14     -1.0
    x_192       link_192    1.0
    x_193       OBJ       66.05
    x_193       flow_16     1.0
    x_193       flow_43     -1.0
    x_193       link_193    1.0
    x_194       OBJ       58.78
    x_194       flow_40     1.0
    x_194       flow_6      -1.0
    x_194       link_194    1.0
    x_195       OBJ       0.83
    x_195       flow_2      1.0
    x_195       flow_37     -1.0
    x_195       link_195    1.0
    x_196       OBJ       0.83
    x_196       flow_47     1.0
    x_196       flow_26     -1.0
    x_196       link_196    1.0
    x_197       OBJ       69.83
    x_197       flow_33     1.0
    x_197       flow_32     -1.0
    x_197       link_197    1.0
    x_198       OBJ       2.68
    x_198       flow_30     1.0
    x_198       flow_51     -1.0
    x_198       link_198    1.0
    x_199       OBJ       33.54
    x_199       flow_4      1.0
    x_199       flow_9      -1.0
    x_199       link_199    1.0
    x_200       OBJ       41.95
    x_200       flow_25     1.0
    x_200       flow_54     -1.0
    x_200       link_200    1.0
    x_201       OBJ       1.42
    x_201       flow_16     1.0
    x_201       flow_34     -1.0
    x_201       link_201    1.0
    x_202       OBJ       76.42
    x_202       flow_37     1.0
    x_202       flow_24     -1.0
    x_202       link_202    1.0
    x_203       OBJ       76.59
    x_203       flow_30     1.0
    x_203       flow_1      -1.0
    x_203       link_203    1.0
    x_204       OBJ       2.56
    x_204       flow_14     1.0
    x_204       flow_41     -1.0
    x_204       link_204    1.0
    x_205       OBJ       0.61
    x_205       flow_41     1.0
    x_205       flow_26     -1.0
    x_205       link_205    1.0
    x_206       OBJ       1.84
    x_206       flow_7      1.0
    x_206       flow_6      -1.0
    x_206       link_206    1.0
    x_207       OBJ       52.41
    x_207       flow_42     1.0
    x_207       flow_47     -1.0
    x_207       link_207    1.0
    x_208       OBJ       70.02
    x_208       flow_9      1.0
    x_208       flow_26     -1.0
    x_208       link_208    1.0
    x_209       OBJ       1.61
    x_209       flow_2      1.0
    x_209       flow_44     -1.0
    x_209       link_209    1.0
    x_210       OBJ       42.04
    x_210       flow_23     1.0
    x_210       flow_6      -1.0
    x_210       link_210    1.0
    x_211       OBJ       0.97
    x_211       flow_22     1.0
    x_211       flow_3      -1.0
    x_211       link_211    1.0
    x_212       OBJ       2.1
    x_212       flow_5      1.0
    x_212       flow_42     -1.0
    x_212       link_212    1.0
    x_213       OBJ       0.81
    x_213       flow_50     1.0
    x_213       flow_21     -1.0
    x_213       link_213    1.0
    x_214       OBJ       55.18
    x_214       flow_53     1.0
    x_214       flow_48     -1.0
    x_214       link_214    1.0
    x_215       OBJ       2.75
    x_215       flow_21     1.0
    x_215       flow_49     -1.0
    x_215       link_215    1.0
    x_216       OBJ       67.91
    x_216       flow_9      1.0
    x_216       flow_8      -1.0
    x_216       link_216    1.0
    x_217       OBJ       2.47
    x_217       flow_1      1.0
    x_217       flow_8      -1.0
    x_217       link_217    1.0
    x_218       OBJ       0.82
    x_218       flow_1      1.0
    x_218       flow_11     -1.0
    x_218       link_218    1.0
    x_219       OBJ       2.45
    x_219       flow_47     1.0
    x_219       flow_4      -1.0
    x_219       link_219    1.0
    x_220       OBJ       2.04
    x_220       flow_28     1.0
    x_220       flow_32     -1.0
    x_220       link_220    1.0
    x_221       OBJ       2.11
    x_221       flow_42     1.0
    x_221       flow_33     -1.0
    x_221       link_221    1.0
    x_222       OBJ       0.77
    x_222       flow_54     1.0
    x_222       flow_25     -1.0
    x_222       link_222    1.0
    x_223       OBJ       0.87
    x_223       flow_4      1.0
    x_223       flow_5      -1.0
    x_223       link_223    1.0
    x_224       OBJ       39.51
    x_224       flow_40     1.0
    x_224       flow_37     -1.0
    x_224       link_224    1.0
    x_225       OBJ       45.81
    x_225       flow_18     1.0
    x_225       flow_29     -1.0
    x_225       link_225    1.0
    x_226       OBJ       66.14
    x_226       flow_54     1.0
    x_226       flow_41     -1.0
    x_226       link_226    1.0
    x_227       OBJ       44.83
    x_227       flow_27     1.0
    x_227       flow_28     -1.0
    x_227       link_227    1.0
    x_228       OBJ       1.57
    x_228       flow_26     1.0
    x_228       flow_46     -1.0
    x_228       link_228    1.0
    x_229       OBJ       24.03
    x_229       flow_9      1.0
    x_229       flow_43     -1.0
    x_229       link_229    1.0
    x_230       OBJ       42.36
    x_230       flow_27     1.0
    x_230       flow_6      -1.0
    x_230       link_230    1.0
    x_231       OBJ       60.2
    x_231       flow_37     1.0
    x_231       flow_35     -1.0
    x_231       link_231    1.0
    x_232       OBJ       2.79
    x_232       flow_42     1.0
    x_232       flow_48     -1.0
    x_232       link_232    1.0
    x_233       OBJ       1.94
    x_233       flow_38     1.0
    x_233       flow_19     -1.0
    x_233       link_233    1.0
    x_234       OBJ       41.01
    x_234       flow_30     1.0
    x_234       flow_14     -1.0
    x_234       link_234    1.0
    x_235       OBJ       68.43
    x_235       flow_48     1.0
    x_235       flow_17     -1.0
    x_235       link_235    1.0
    x_236       OBJ       58.56
    x_236       flow_52     1.0
    x_236       flow_39     -1.0
    x_236       link_236    1.0
    x_237       OBJ       0.95
    x_237       flow_53     1.0
    x_237       flow_44     -1.0
    x_237       link_237    1.0
    x_238       OBJ       53.98
    x_238       flow_0      1.0
    x_238       flow_11     -1.0
    x_238       link_238    1.0
    x_239       OBJ       25.51
    x_239       flow_47     1.0
    x_239       flow_40     -1.0
    x_239       link_239    1.0
    x_240       OBJ       1.43
    x_240       flow_26     1.0
    x_240       flow_29     -1.0
    x_240       link_240    1.0
    x_241       OBJ       0.63
    x_241       flow_36     1.0
    x_241       flow_38     -1.0
    x_241       link_241    1.0
    x_242       OBJ       1.61
    x_242       flow_3      1.0
    x_242       flow_43     -1.0
    x_242       link_242    1.0
    x_243       OBJ       2.39
    x_243       flow_28     1.0
    x_243       flow_26     -1.0
    x_243       link_243    1.0
    x_244       OBJ       38.51
    x_244       flow_37     1.0
    x_244       flow_31     -1.0
    x_244       link_244    1.0
    x_245       OBJ       2.86
    x_245       flow_3      1.0
    x_245       flow_0      -1.0
    x_245       link_245    1.0
    x_246       OBJ       0.52
    x_246       flow_16     1.0
    x_246       flow_18     -1.0
    x_246       link_246    1.0
    x_247       OBJ       33.81
    x_247       flow_8      1.0
    x_247       flow_24     -1.0
    x_247       link_247    1.0
    x_248       OBJ       2.65
    x_248       flow_51     1.0
    x_248       flow_22     -1.0
    x_248       link_248    1.0
    x_249       OBJ       54.55
    x_249       flow_29     1.0
    x_249       flow_4      -1.0
    x_249       link_249    1.0
    x_250       OBJ       1.51
    x_250       flow_40     1.0
    x_250       flow_26     -1.0
    x_250       link_250    1.0
    x_251       OBJ       2.22
    x_251       flow_51     1.0
    x_251       flow_39     -1.0
    x_251       link_251    1.0
    x_252       OBJ       1.97
    x_252       flow_54     1.0
    x_252       flow_6      -1.0
    x_252       link_252    1.0
    x_253       OBJ       1.33
    x_253       flow_19     1.0
    x_253       flow_47     -1.0
    x_253       link_253    1.0
    x_254       OBJ       2.32
    x_254       flow_12     1.0
    x_254       flow_49     -1.0
    x_254       link_254    1.0
    x_255       OBJ       1.14
    x_255       flow_9      1.0
    x_255       flow_15     -1.0
    x_255       link_255    1.0
    x_256       OBJ       2.43
    x_256       flow_41     1.0
    x_256       flow_4      -1.0
    x_256       link_256    1.0
    x_257       OBJ       60.87
    x_257       flow_36     1.0
    x_257       flow_48     -1.0
    x_257       link_257    1.0
    x_258       OBJ       1.6
    x_258       flow_20     1.0
    x_258       flow_40     -1.0
    x_258       link_258    1.0
    x_259       OBJ       0.64
    x_259       flow_19     1.0
    x_259       flow_50     -1.0
    x_259       link_259    1.0
    x_260       OBJ       1.42
    x_260       flow_29     1.0
    x_260       flow_28     -1.0
    x_260       link_260    1.0
    x_261       OBJ       50.42
    x_261       flow_54     1.0
    x_261       flow_5      -1.0
    x_261       link_261    1.0
    x_262       OBJ       46.98
    x_262       flow_50     1.0
    x_262       flow_47     -1.0
    x_262       link_262    1.0
    x_263       OBJ       50.08
    x_263       flow_12     1.0
    x_263       flow_20     -1.0
    x_263       link_263    1.0
    x_264       OBJ       40.61
    x_264       flow_6      1.0
    x_264       flow_51     -1.0
    x_264       link_264    1.0
    x_265       OBJ       2.27
    x_265       flow_41     1.0
    x_265       flow_11     -1.0
    x_265       link_265    1.0
    x_266       OBJ       1.43
    x_266       flow_33     1.0
    x_266       flow_39     -1.0
    x_266       link_266    1.0
    x_267       OBJ       23.14
    x_267       flow_49     1.0
    x_267       flow_21     -1.0
    x_267       link_267    1.0
    x_268       OBJ       2.2
    x_268       flow_4      1.0
    x_268       flow_21     -1.0
    x_268       link_268    1.0
    x_269       OBJ       56.16
    x_269       flow_54     1.0
    x_269       flow_42     -1.0
    x_269       link_269    1.0
    x_270       OBJ       1.37
    x_270       flow_37     1.0
    x_270       flow_42     -1.0
    x_270       link_270    1.0
    x_271       OBJ       25.08
    x_271       flow_8      1.0
    x_271       flow_38     -1.0
    x_271       link_271    1.0
    x_272       OBJ       69.74
    x_272       flow_52     1.0
    x_272       flow_8      -1.0
    x_272       link_272    1.0
    x_273       OBJ       45.4
    x_273       flow_33     1.0
    x_273       flow_5      -1.0
    x_273       link_273    1.0
    x_274       OBJ       40.5
    x_274       flow_19     1.0
    x_274       flow_11     -1.0
    x_274       link_274    1.0
    x_275       OBJ       1.24
    x_275       flow_14     1.0
    x_275       flow_8      -1.0
    x_275       link_275    1.0
    x_276       OBJ       73.02
    x_276       flow_49     1.0
    x_276       flow_34     -1.0
    x_276       link_276    1.0
    x_277       OBJ       1.44
    x_277       flow_49     1.0
    x_277       flow_39     -1.0
    x_277       link_277    1.0
    x_278       OBJ       74.16
    x_278       flow_44     1.0
    x_278       flow_49     -1.0
    x_278       link_278    1.0
    x_279       OBJ       34.25
    x_279       flow_26     1.0
    x_279       flow_23     -1.0
    x_279       link_279    1.0
    x_280       OBJ       34.04
    x_280       flow_48     1.0
    x_280       flow_47     -1.0
    x_280       link_280    1.0
    x_281       OBJ       31.64
    x_281       flow_50     1.0
    x_281       flow_30     -1.0
    x_281       link_281    1.0
    x_282       OBJ       66.69
    x_282       flow_28     1.0
    x_282       flow_29     -1.0
    x_282       link_282    1.0
    x_283       OBJ       2.01
    x_283       flow_10     1.0
    x_283       flow_52     -1.0
    x_283       link_283    1.0
    x_284       OBJ       53.27
    x_284       flow_41     1.0
    x_284       flow_30     -1.0
    x_284       link_284    1.0
    x_285       OBJ       0.71
    x_285       flow_33     1.0
    x_285       flow_54     -1.0
    x_285       link_285    1.0
    x_286       OBJ       25.5
    x_286       flow_32     1.0
    x_286       flow_9      -1.0
    x_286       link_286    1.0
    x_287       OBJ       44.89
    x_287       flow_28     1.0
    x_287       flow_22     -1.0
    x_287       link_287    1.0
    x_288       OBJ       42.49
    x_288       flow_15     1.0
    x_288       flow_24     -1.0
    x_288       link_288    1.0
    x_289       OBJ       67.48
    x_289       flow_53     1.0
    x_289       flow_45     -1.0
    x_289       link_289    1.0
    x_290       OBJ       28.33
    x_290       flow_53     1.0
    x_290       flow_30     -1.0
    x_290       link_290    1.0
    x_291       OBJ       21.14
    x_291       flow_39     1.0
    x_291       flow_0      -1.0
    x_291       link_291    1.0
    x_292       OBJ       45.4
    x_292       flow_35     1.0
    x_292       flow_46     -1.0
    x_292       link_292    1.0
    x_293       OBJ       1.55
    x_293       flow_19     1.0
    x_293       flow_7      -1.0
    x_293       link_293    1.0
    x_294       OBJ       49.99
    x_294       flow_4      1.0
    x_294       flow_7      -1.0
    x_294       link_294    1.0
    x_295       OBJ       0.86
    x_295       flow_32     1.0
    x_295       flow_36     -1.0
    x_295       link_295    1.0
    x_296       OBJ       31.24
    x_296       flow_22     1.0
    x_296       flow_15     -1.0
    x_296       link_296    1.0
    x_297       OBJ       52.64
    x_297       flow_23     1.0
    x_297       flow_4      -1.0
    x_297       link_297    1.0
    x_298       OBJ       1.68
    x_298       flow_35     1.0
    x_298       flow_1      -1.0
    x_298       link_298    1.0
    x_299       OBJ       2.47
    x_299       flow_16     1.0
    x_299       flow_47     -1.0
    x_299       link_299    1.0
    x_300       OBJ       1.95
    x_300       flow_42     1.0
    x_300       flow_40     -1.0
    x_300       link_300    1.0
    x_301       OBJ       68.81
    x_301       flow_2      1.0
    x_301       flow_22     -1.0
    x_301       link_301    1.0
    x_302       OBJ       48.71
    x_302       flow_43     1.0
    x_302       flow_29     -1.0
    x_302       link_302    1.0
    x_303       OBJ       47.46
    x_303       flow_4      1.0
    x_303       flow_45     -1.0
    x_303       link_303    1.0
    x_304       OBJ       38.94
    x_304       flow_50     1.0
    x_304       flow_12     -1.0
    x_304       link_304    1.0
    x_305       OBJ       0.59
    x_305       flow_52     1.0
    x_305       flow_34     -1.0
    x_305       link_305    1.0
    x_306       OBJ       2.14
    x_306       flow_22     1.0
    x_306       flow_49     -1.0
    x_306       link_306    1.0
    x_307       OBJ       64.6
    x_307       flow_23     1.0
    x_307       flow_27     -1.0
    x_307       link_307    1.0
    x_308       OBJ       2.81
    x_308       flow_31     1.0
    x_308       flow_44     -1.0
    x_308       link_308    1.0
    x_309       OBJ       2.99
    x_309       flow_27     1.0
    x_309       flow_5      -1.0
    x_309       link_309    1.0
    x_310       OBJ       2.15
    x_310       flow_20     1.0
    x_310       flow_6      -1.0
    x_310       link_310    1.0
    x_311       OBJ       1.62
    x_311       flow_10     1.0
    x_311       flow_44     -1.0
    x_311       link_311    1.0
    x_312       OBJ       2.95
    x_312       flow_39     1.0
    x_312       flow_27     -1.0
    x_312       link_312    1.0
    x_313       OBJ       64.99
    x_313       flow_25     1.0
    x_313       flow_23     -1.0
    x_313       link_313    1.0
    x_314       OBJ       66.88
    x_314       flow_9      1.0
    x_314       flow_54     -1.0
    x_314       link_314    1.0
    x_315       OBJ       41.73
    x_315       flow_15     1.0
    x_315       flow_49     -1.0
    x_315       link_315    1.0
    x_316       OBJ       76.93
    x_316       flow_38     1.0
    x_316       flow_9      -1.0
    x_316       link_316    1.0
    x_317       OBJ       1.42
    x_317       flow_4      1.0
    x_317       flow_36     -1.0
    x_317       link_317    1.0
    x_318       OBJ       0.97
    x_318       flow_15     1.0
    x_318       flow_7      -1.0
    x_318       link_318    1.0
    x_319       OBJ       62.24
    x_319       flow_7      1.0
    x_319       flow_16     -1.0
    x_319       link_319    1.0
    x_320       OBJ       49.47
    x_320       flow_18     1.0
    x_320       flow_44     -1.0
    x_320       link_320    1.0
    x_321       OBJ       2.28
    x_321       flow_4      1.0
    x_321       flow_28     -1.0
    x_321       link_321    1.0
    x_322       OBJ       60.07
    x_322       flow_43     1.0
    x_322       flow_54     -1.0
    x_322       link_322    1.0
    x_323       OBJ       71.08
    x_323       flow_34     1.0
    x_323       flow_18     -1.0
    x_323       link_323    1.0
    x_324       OBJ       50.53
    x_324       flow_40     1.0
    x_324       flow_11     -1.0
    x_324       link_324    1.0
    x_325       OBJ       1.74
    x_325       flow_50     1.0
    x_325       flow_8      -1.0
    x_325       link_325    1.0
    x_326       OBJ       53.1
    x_326       flow_23     1.0
    x_326       flow_29     -1.0
    x_326       link_326    1.0
    x_327       OBJ       2.29
    x_327       flow_4      1.0
    x_327       flow_19     -1.0
    x_327       link_327    1.0
    x_328       OBJ       2.93
    x_328       flow_52     1.0
    x_328       flow_36     -1.0
    x_328       link_328    1.0
    x_329       OBJ       27.7
    x_329       flow_29     1.0
    x_329       flow_43     -1.0
    x_329       link_329    1.0
    x_330       OBJ       45.96
    x_330       flow_11     1.0
    x_330       flow_49     -1.0
    x_330       link_330    1.0
    x_331       OBJ       0.9
    x_331       flow_33     1.0
    x_331       flow_9      -1.0
    x_331       link_331    1.0
    x_332       OBJ       70.76
    x_332       flow_22     1.0
    x_332       flow_33     -1.0
    x_332       link_332    1.0
    x_333       OBJ       1.26
    x_333       flow_35     1.0
    x_333       flow_17     -1.0
    x_333       link_333    1.0
    x_334       OBJ       54.84
    x_334       flow_41     1.0
    x_334       flow_10     -1.0
    x_334       link_334    1.0
    x_335       OBJ       2.81
    x_335       flow_46     1.0
    x_335       flow_38     -1.0
    x_335       link_335    1.0
    x_336       OBJ       35.88
    x_336       flow_2      1.0
    x_336       flow_41     -1.0
    x_336       link_336    1.0
    x_337       OBJ       2.07
    x_337       flow_40     1.0
    x_337       flow_1      -1.0
    x_337       link_337    1.0
    x_338       OBJ       0.68
    x_338       flow_43     1.0
    x_338       flow_25     -1.0
    x_338       link_338    1.0
    x_339       OBJ       1.35
    x_339       flow_26     1.0
    x_339       flow_30     -1.0
    x_339       link_339    1.0
    x_340       OBJ       71.65
    x_340       flow_45     1.0
    x_340       flow_20     -1.0
    x_340       link_340    1.0
    x_341       OBJ       26.37
    x_341       flow_48     1.0
    x_341       flow_23     -1.0
    x_341       link_341    1.0
    x_342       OBJ       1.23
    x_342       flow_15     1.0
    x_342       flow_9      -1.0
    x_342       link_342    1.0
    x_343       OBJ       74.14
    x_343       flow_26     1.0
    x_343       flow_15     -1.0
    x_343       link_343    1.0
    x_344       OBJ       0.9
    x_344       flow_46     1.0
    x_344       flow_20     -1.0
    x_344       link_344    1.0
    x_345       OBJ       0.73
    x_345       flow_31     1.0
    x_345       flow_19     -1.0
    x_345       link_345    1.0
    x_346       OBJ       22.92
    x_346       flow_15     1.0
    x_346       flow_13     -1.0
    x_346       link_346    1.0
    x_347       OBJ       37.14
    x_347       flow_53     1.0
    x_347       flow_41     -1.0
    x_347       link_347    1.0
    x_348       OBJ       63.65
    x_348       flow_27     1.0
    x_348       flow_8      -1.0
    x_348       link_348    1.0
    x_349       OBJ       1.9
    x_349       flow_2      1.0
    x_349       flow_25     -1.0
    x_349       link_349    1.0
    x_350       OBJ       65.86
    x_350       flow_4      1.0
    x_350       flow_24     -1.0
    x_350       link_350    1.0
    x_351       OBJ       2.94
    x_351       flow_43     1.0
    x_351       flow_39     -1.0
    x_351       link_351    1.0
    x_352       OBJ       65.3
    x_352       flow_21     1.0
    x_352       flow_35     -1.0
    x_352       link_352    1.0
    x_353       OBJ       0.6
    x_353       flow_25     1.0
    x_353       flow_32     -1.0
    x_353       link_353    1.0
    x_354       OBJ       2.02
    x_354       flow_30     1.0
    x_354       flow_33     -1.0
    x_354       link_354    1.0
    x_355       OBJ       64.36
    x_355       flow_10     1.0
    x_355       flow_25     -1.0
    x_355       link_355    1.0
    x_356       OBJ       49.39
    x_356       flow_32     1.0
    x_356       flow_53     -1.0
    x_356       link_356    1.0
    x_357       OBJ       2.18
    x_357       flow_52     1.0
    x_357       flow_1      -1.0
    x_357       link_357    1.0
    x_358       OBJ       55.81
    x_358       flow_46     1.0
    x_358       flow_44     -1.0
    x_358       link_358    1.0
    x_359       OBJ       33.65
    x_359       flow_50     1.0
    x_359       flow_49     -1.0
    x_359       link_359    1.0
    x_360       OBJ       57.18
    x_360       flow_10     1.0
    x_360       flow_33     -1.0
    x_360       link_360    1.0
    x_361       OBJ       1.93
    x_361       flow_52     1.0
    x_361       flow_43     -1.0
    x_361       link_361    1.0
    x_362       OBJ       0.88
    x_362       flow_1      1.0
    x_362       flow_28     -1.0
    x_362       link_362    1.0
    x_363       OBJ       48.3
    x_363       flow_32     1.0
    x_363       flow_49     -1.0
    x_363       link_363    1.0
    x_364       OBJ       1.02
    x_364       flow_3      1.0
    x_364       flow_45     -1.0
    x_364       link_364    1.0
    x_365       OBJ       40.54
    x_365       flow_11     1.0
    x_365       flow_29     -1.0
    x_365       link_365    1.0
    x_366       OBJ       61.6
    x_366       flow_46     1.0
    x_366       flow_43     -1.0
    x_366       link_366    1.0
    x_367       OBJ       33.49
    x_367       flow_15     1.0
    x_367       flow_17     -1.0
    x_367       link_367    1.0
    x_368       OBJ       61.41
    x_368       flow_49     1.0
    x_368       flow_18     -1.0
    x_368       link_368    1.0
    x_369       OBJ       67.72
    x_369       flow_22     1.0
    x_369       flow_35     -1.0
    x_369       link_369    1.0
    x_370       OBJ       73.75
    x_370       flow_36     1.0
    x_370       flow_43     -1.0
    x_370       link_370    1.0
    x_371       OBJ       0.61
    x_371       flow_49     1.0
    x_371       flow_51     -1.0
    x_371       link_371    1.0
    x_372       OBJ       64.84
    x_372       flow_22     1.0
    x_372       flow_28     -1.0
    x_372       link_372    1.0
    x_373       OBJ       61.77
    x_373       flow_34     1.0
    x_373       flow_17     -1.0
    x_373       link_373    1.0
    x_374       OBJ       0.63
    x_374       flow_47     1.0
    x_374       flow_37     -1.0
    x_374       link_374    1.0
    x_375       OBJ       1.53
    x_375       flow_40     1.0
    x_375       flow_14     -1.0
    x_375       link_375    1.0
    x_376       OBJ       2.91
    x_376       flow_43     1.0
    x_376       flow_49     -1.0
    x_376       link_376    1.0
    x_377       OBJ       72.7
    x_377       flow_26     1.0
    x_377       flow_41     -1.0
    x_377       link_377    1.0
    x_378       OBJ       2.11
    x_378       flow_48     1.0
    x_378       flow_18     -1.0
    x_378       link_378    1.0
    x_379       OBJ       2.35
    x_379       flow_41     1.0
    x_379       flow_36     -1.0
    x_379       link_379    1.0
    x_380       OBJ       22.18
    x_380       flow_53     1.0
    x_380       flow_11     -1.0
    x_380       link_380    1.0
    x_381       OBJ       77.73
    x_381       flow_31     1.0
    x_381       flow_11     -1.0
    x_381       link_381    1.0
    x_382       OBJ       26.44
    x_382       flow_0      1.0
    x_382       flow_19     -1.0
    x_382       link_382    1.0
    x_383       OBJ       49.63
    x_383       flow_29     1.0
    x_383       flow_41     -1.0
    x_383       link_383    1.0
    x_384       OBJ       2.52
    x_384       flow_32     1.0
    x_384       flow_29     -1.0
    x_384       link_384    1.0
    x_385       OBJ       2.34
    x_385       flow_16     1.0
    x_385       flow_45     -1.0
    x_385       link_385    1.0
    x_386       OBJ       2.03
    x_386       flow_43     1.0
    x_386       flow_48     -1.0
    x_386       link_386    1.0
    x_387       OBJ       25.2
    x_387       flow_52     1.0
    x_387       flow_27     -1.0
    x_387       link_387    1.0
    x_388       OBJ       1.12
    x_388       flow_8      1.0
    x_388       flow_30     -1.0
    x_388       link_388    1.0
    x_389       OBJ       1.32
    x_389       flow_28     1.0
    x_389       flow_48     -1.0
    x_389       link_389    1.0
    x_390       OBJ       61.57
    x_390       flow_0      1.0
    x_390       flow_16     -1.0
    x_390       link_390    1.0
    x_391       OBJ       2.22
    x_391       flow_29     1.0
    x_391       flow_19     -1.0
    x_391       link_391    1.0
    x_392       OBJ       58.32
    x_392       flow_49     1.0
    x_392       flow_19     -1.0
    x_392       link_392    1.0
    x_393       OBJ       0.83
    x_393       flow_39     1.0
    x_393       flow_14     -1.0
    x_393       link_393    1.0
    x_394       OBJ       1.87
    x_394       flow_38     1.0
    x_394       flow_23     -1.0
    x_394       link_394    1.0
    x_395       OBJ       60.82
    x_395       flow_52     1.0
    x_395       flow_13     -1.0
    x_395       link_395    1.0
    x_396       OBJ       2.26
    x_396       flow_5      1.0
    x_396       flow_33     -1.0
    x_396       link_396    1.0
    x_397       OBJ       74.17
    x_397       flow_7      1.0
    x_397       flow_3      -1.0
    x_397       link_397    1.0
    x_398       OBJ       1.8
    x_398       flow_9      1.0
    x_398       flow_10     -1.0
    x_398       link_398    1.0
    x_399       OBJ       2.75
    x_399       flow_45     1.0
    x_399       flow_37     -1.0
    x_399       link_399    1.0
    x_400       OBJ       47.41
    x_400       flow_29     1.0
    x_400       flow_8      -1.0
    x_400       link_400    1.0
    x_401       OBJ       0.55
    x_401       flow_43     1.0
    x_401       flow_51     -1.0
    x_401       link_401    1.0
    x_402       OBJ       22.72
    x_402       flow_47     1.0
    x_402       flow_13     -1.0
    x_402       link_402    1.0
    x_403       OBJ       24.14
    x_403       flow_34     1.0
    x_403       flow_3      -1.0
    x_403       link_403    1.0
    x_404       OBJ       0.84
    x_404       flow_18     1.0
    x_404       flow_26     -1.0
    x_404       link_404    1.0
    x_405       OBJ       2.79
    x_405       flow_23     1.0
    x_405       flow_24     -1.0
    x_405       link_405    1.0
    x_406       OBJ       27.98
    x_406       flow_43     1.0
    x_406       flow_42     -1.0
    x_406       link_406    1.0
    x_407       OBJ       0.82
    x_407       flow_11     1.0
    x_407       flow_34     -1.0
    x_407       link_407    1.0
    x_408       OBJ       2.3
    x_408       flow_1      1.0
    x_408       flow_19     -1.0
    x_408       link_408    1.0
    x_409       OBJ       1.37
    x_409       flow_52     1.0
    x_409       flow_14     -1.0
    x_409       link_409    1.0
    x_410       OBJ       2.15
    x_410       flow_48     1.0
    x_410       flow_7      -1.0
    x_410       link_410    1.0
    x_411       OBJ       46.79
    x_411       flow_4      1.0
    x_411       flow_6      -1.0
    x_411       link_411    1.0
    x_412       OBJ       44.14
    x_412       flow_3      1.0
    x_412       flow_15     -1.0
    x_412       link_412    1.0
    x_413       OBJ       1.76
    x_413       flow_48     1.0
    x_413       flow_49     -1.0
    x_413       link_413    1.0
    x_414       OBJ       1.99
    x_414       flow_46     1.0
    x_414       flow_36     -1.0
    x_414       link_414    1.0
    x_415       OBJ       79.14
    x_415       flow_15     1.0
    x_415       flow_19     -1.0
    x_415       link_415    1.0
    x_416       OBJ       2.87
    x_416       flow_19     1.0
    x_416       flow_17     -1.0
    x_416       link_416    1.0
    x_417       OBJ       1.74
    x_417       flow_40     1.0
    x_417       flow_43     -1.0
    x_417       link_417    1.0
    x_418       OBJ       39.12
    x_418       flow_42     1.0
    x_418       flow_24     -1.0
    x_418       link_418    1.0
    x_419       OBJ       1.84
    x_419       flow_19     1.0
    x_419       flow_24     -1.0
    x_419       link_419    1.0
    x_420       OBJ       68.35
    x_420       flow_19     1.0
    x_420       flow_54     -1.0
    x_420       link_420    1.0
    x_421       OBJ       1.11
    x_421       flow_35     1.0
    x_421       flow_33     -1.0
    x_421       link_421    1.0
    x_422       OBJ       25.55
    x_422       flow_5      1.0
    x_422       flow_28     -1.0
    x_422       link_422    1.0
    x_423       OBJ       2.01
    x_423       flow_3      1.0
    x_423       flow_17     -1.0
    x_423       link_423    1.0
    x_424       OBJ       63.46
    x_424       flow_12     1.0
    x_424       flow_51     -1.0
    x_424       link_424    1.0
    x_425       OBJ       2.77
    x_425       flow_13     1.0
    x_425       flow_21     -1.0
    x_425       link_425    1.0
    x_426       OBJ       65.26
    x_426       flow_47     1.0
    x_426       flow_7      -1.0
    x_426       link_426    1.0
    x_427       OBJ       2.79
    x_427       flow_38     1.0
    x_427       flow_45     -1.0
    x_427       link_427    1.0
    x_428       OBJ       2.12
    x_428       flow_18     1.0
    x_428       flow_24     -1.0
    x_428       link_428    1.0
    x_429       OBJ       2.51
    x_429       flow_32     1.0
    x_429       flow_31     -1.0
    x_429       link_429    1.0
    x_430       OBJ       42.24
    x_430       flow_53     1.0
    x_430       flow_20     -1.0
    x_430       link_430    1.0
    x_431       OBJ       1.15
    x_431       flow_14     1.0
    x_431       flow_47     -1.0
    x_431       link_431    1.0
    x_432       OBJ       0.99
    x_432       flow_46     1.0
    x_432       flow_26     -1.0
    x_432       link_432    1.0
    x_433       OBJ       2.14
    x_433       flow_53     1.0
    x_433       flow_15     -1.0
    x_433       link_433    1.0
    x_434       OBJ       2.31
    x_434       flow_48     1.0
    x_434       flow_52     -1.0
    x_434       link_434    1.0
    x_435       OBJ       30.16
    x_435       flow_10     1.0
    x_435       flow_46     -1.0
    x_435       link_435    1.0
    x_436       OBJ       70.34
    x_436       flow_41     1.0
    x_436       flow_3      -1.0
    x_436       link_436    1.0
    x_437       OBJ       44.74
    x_437       flow_42     1.0
    x_437       flow_3      -1.0
    x_437       link_437    1.0
    x_438       OBJ       1.64
    x_438       flow_9      1.0
    x_438       flow_0      -1.0
    x_438       link_438    1.0
    x_439       OBJ       59.56
    x_439       flow_42     1.0
    x_439       flow_39     -1.0
    x_439       link_439    1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       83.48
    y_0         link_0      -7.0
    y_1         OBJ       3.36
    y_1         link_1      -2.0
    y_2         OBJ       53.98
    y_2         link_2      -3.0
    y_3         OBJ       2.8
    y_3         link_3      -4.0
    y_4         OBJ       2.69
    y_4         link_4      -4.0
    y_5         OBJ       1.37
    y_5         link_5      -2.0
    y_6         OBJ       56.52
    y_6         link_6      -5.0
    y_7         OBJ       3.21
    y_7         link_7      -8.0
    y_8         OBJ       1.77
    y_8         link_8      -2.0
    y_9         OBJ       61.97
    y_9         link_9      -3.0
    y_10        OBJ       104.72
    y_10        link_10     -4.0
    y_11        OBJ       3.73
    y_11        link_11     -2.0
    y_12        OBJ       74.51
    y_12        link_12     -5.0
    y_13        OBJ       2.3
    y_13        link_13     -8.0
    y_14        OBJ       97.32
    y_14        link_14     -4.0
    y_15        OBJ       3.87
    y_15        link_15     -3.0
    y_16        OBJ       118.83
    y_16        link_16     -4.0
    y_17        OBJ       3.99
    y_17        link_17     -5.0
    y_18        OBJ       70.75
    y_18        link_18     -5.0
    y_19        OBJ       144.12
    y_19        link_19     -8.0
    y_20        OBJ       3.38
    y_20        link_20     -5.0
    y_21        OBJ       1.05
    y_21        link_21     -7.0
    y_22        OBJ       4.07
    y_22        link_22     -4.0
    y_23        OBJ       193.07
    y_23        link_23     -7.0
    y_24        OBJ       1.43
    y_24        link_24     -7.0
    y_25        OBJ       1.61
    y_25        link_25     -8.0
    y_26        OBJ       4.67
    y_26        link_26     -6.0
    y_27        OBJ       181.81
    y_27        link_27     -8.0
    y_28        OBJ       135.1
    y_28        link_28     -2.0
    y_29        OBJ       164.09
    y_29        link_29     -8.0
    y_30        OBJ       3.11
    y_30        link_30     -6.0
    y_31        OBJ       3.76
    y_31        link_31     -7.0
    y_32        OBJ       2.75
    y_32        link_32     -6.0
    y_33        OBJ       53.16
    y_33        link_33     -6.0
    y_34        OBJ       144.67
    y_34        link_34     -3.0
    y_35        OBJ       1.95
    y_35        link_35     -7.0
    y_36        OBJ       4.53
    y_36        link_36     -6.0
    y_37        OBJ       1.76
    y_37        link_37     -2.0
    y_38        OBJ       179.58
    y_38        link_38     -2.0
    y_39        OBJ       2.61
    y_39        link_39     -4.0
    y_40        OBJ       117.29
    y_40        link_40     -5.0
    y_41        OBJ       61.31
    y_41        link_41     -8.0
    y_42        OBJ       131.09
    y_42        link_42     -2.0
    y_43        OBJ       82.06
    y_43        link_43     -5.0
    y_44        OBJ       89.78
    y_44        link_44     -8.0
    y_45        OBJ       159.58
    y_45        link_45     -8.0
    y_46        OBJ       2.19
    y_46        link_46     -2.0
    y_47        OBJ       1.23
    y_47        link_47     -6.0
    y_48        OBJ       1.23
    y_48        link_48     -6.0
    y_49        OBJ       151.28
    y_49        link_49     -3.0
    y_50        OBJ       3.32
    y_50        link_50     -2.0
    y_51        OBJ       128.42
    y_51        link_51     -4.0
    y_52        OBJ       2.58
    y_52        link_52     -7.0
    y_53        OBJ       190.36
    y_53        link_53     -2.0
    y_54        OBJ       1.29
    y_54        link_54     -3.0
    y_55        OBJ       60.32
    y_55        link_55     -3.0
    y_56        OBJ       155.53
    y_56        link_56     -6.0
    y_57        OBJ       3.22
    y_57        link_57     -7.0
    y_58        OBJ       161.36
    y_58        link_58     -3.0
    y_59        OBJ       1.81
    y_59        link_59     -7.0
    y_60        OBJ       4.63
    y_60        link_60     -2.0
    y_61        OBJ       50.53
    y_61        link_61     -8.0
    y_62        OBJ       2.77
    y_62        link_62     -7.0
    y_63        OBJ       182.47
    y_63        link_63     -3.0
    y_64        OBJ       1.59
    y_64        link_64     -3.0
    y_65        OBJ       195.83
    y_65        link_65     -2.0
    y_66        OBJ       3.24
    y_66        link_66     -8.0
    y_67        OBJ       1.95
    y_67        link_67     -3.0
    y_68        OBJ       99.83
    y_68        link_68     -5.0
    y_69        OBJ       2.07
    y_69        link_69     -8.0
    y_70        OBJ       120.6
    y_70        link_70     -3.0
    y_71        OBJ       180.7
    y_71        link_71     -3.0
    y_72        OBJ       179.65
    y_72        link_72     -8.0
    y_73        OBJ       4.92
    y_73        link_73     -6.0
    y_74        OBJ       76.79
    y_74        link_74     -4.0
    y_75        OBJ       4.15
    y_75        link_75     -5.0
    y_76        OBJ       78.51
    y_76        link_76     -2.0
    y_77        OBJ       130.77
    y_77        link_77     -7.0
    y_78        OBJ       149.64
    y_78        link_78     -4.0
    y_79        OBJ       4.6
    y_79        link_79     -6.0
    y_80        OBJ       94.35
    y_80        link_80     -3.0
    y_81        OBJ       3.99
    y_81        link_81     -3.0
    y_82        OBJ       50.06
    y_82        link_82     -4.0
    y_83        OBJ       2.29
    y_83        link_83     -5.0
    y_84        OBJ       185.18
    y_84        link_84     -8.0
    y_85        OBJ       3.66
    y_85        link_85     -6.0
    y_86        OBJ       3.69
    y_86        link_86     -3.0
    y_87        OBJ       197.59
    y_87        link_87     -6.0
    y_88        OBJ       144.46
    y_88        link_88     -3.0
    y_89        OBJ       72.14
    y_89        link_89     -7.0
    y_90        OBJ       4.11
    y_90        link_90     -3.0
    y_91        OBJ       1.2
    y_91        link_91     -3.0
    y_92        OBJ       150.14
    y_92        link_92     -6.0
    y_93        OBJ       3.45
    y_93        link_93     -7.0
    y_94        OBJ       4.59
    y_94        link_94     -7.0
    y_95        OBJ       145.65
    y_95        link_95     -8.0
    y_96        OBJ       115.98
    y_96        link_96     -7.0
    y_97        OBJ       131.02
    y_97        link_97     -3.0
    y_98        OBJ       82.09
    y_98        link_98     -5.0
    y_99        OBJ       1.83
    y_99        link_99     -5.0
    y_100       OBJ       4.43
    y_100       link_100    -8.0
    y_101       OBJ       94.79
    y_101       link_101    -5.0
    y_102       OBJ       131.92
    y_102       link_102    -6.0
    y_103       OBJ       54.35
    y_103       link_103    -4.0
    y_104       OBJ       4.36
    y_104       link_104    -3.0
    y_105       OBJ       134.66
    y_105       link_105    -2.0
    y_106       OBJ       77.26
    y_106       link_106    -4.0
    y_107       OBJ       164.18
    y_107       link_107    -5.0
    y_108       OBJ       4.34
    y_108       link_108    -5.0
    y_109       OBJ       2.4
    y_109       link_109    -7.0
    y_110       OBJ       1.12
    y_110       link_110    -3.0
    y_111       OBJ       68.93
    y_111       link_111    -7.0
    y_112       OBJ       2.02
    y_112       link_112    -4.0
    y_113       OBJ       1.46
    y_113       link_113    -8.0
    y_114       OBJ       96.79
    y_114       link_114    -7.0
    y_115       OBJ       3.37
    y_115       link_115    -8.0
    y_116       OBJ       177.54
    y_116       link_116    -6.0
    y_117       OBJ       1.16
    y_117       link_117    -6.0
    y_118       OBJ       101.18
    y_118       link_118    -8.0
    y_119       OBJ       104.33
    y_119       link_119    -8.0
    y_120       OBJ       128.26
    y_120       link_120    -7.0
    y_121       OBJ       2.93
    y_121       link_121    -5.0
    y_122       OBJ       1.98
    y_122       link_122    -2.0
    y_123       OBJ       141.55
    y_123       link_123    -5.0
    y_124       OBJ       103.22
    y_124       link_124    -4.0
    y_125       OBJ       2.11
    y_125       link_125    -2.0
    y_126       OBJ       123.29
    y_126       link_126    -8.0
    y_127       OBJ       117.23
    y_127       link_127    -2.0
    y_128       OBJ       95.93
    y_128       link_128    -6.0
    y_129       OBJ       4.99
    y_129       link_129    -6.0
    y_130       OBJ       2.01
    y_130       link_130    -2.0
    y_131       OBJ       192.63
    y_131       link_131    -7.0
    y_132       OBJ       158.69
    y_132       link_132    -8.0
    y_133       OBJ       79.12
    y_133       link_133    -3.0
    y_134       OBJ       68.99
    y_134       link_134    -2.0
    y_135       OBJ       145.68
    y_135       link_135    -8.0
    y_136       OBJ       2.88
    y_136       link_136    -5.0
    y_137       OBJ       4.45
    y_137       link_137    -2.0
    y_138       OBJ       144.42
    y_138       link_138    -2.0
    y_139       OBJ       1.99
    y_139       link_139    -6.0
    y_140       OBJ       1.9
    y_140       link_140    -6.0
    y_141       OBJ       3.35
    y_141       link_141    -5.0
    y_142       OBJ       3.96
    y_142       link_142    -8.0
    y_143       OBJ       73.56
    y_143       link_143    -3.0
    y_144       OBJ       153.41
    y_144       link_144    -5.0
    y_145       OBJ       155.45
    y_145       link_145    -5.0
    y_146       OBJ       168.69
    y_146       link_146    -6.0
    y_147       OBJ       3.18
    y_147       link_147    -7.0
    y_148       OBJ       1.66
    y_148       link_148    -4.0
    y_149       OBJ       2.76
    y_149       link_149    -5.0
    y_150       OBJ       3.0
    y_150       link_150    -5.0
    y_151       OBJ       3.94
    y_151       link_151    -6.0
    y_152       OBJ       175.39
    y_152       link_152    -6.0
    y_153       OBJ       2.08
    y_153       link_153    -2.0
    y_154       OBJ       2.11
    y_154       link_154    -6.0
    y_155       OBJ       2.88
    y_155       link_155    -5.0
    y_156       OBJ       2.32
    y_156       link_156    -7.0
    y_157       OBJ       4.04
    y_157       link_157    -2.0
    y_158       OBJ       195.53
    y_158       link_158    -5.0
    y_159       OBJ       3.17
    y_159       link_159    -5.0
    y_160       OBJ       2.99
    y_160       link_160    -5.0
    y_161       OBJ       189.15
    y_161       link_161    -5.0
    y_162       OBJ       141.33
    y_162       link_162    -3.0
    y_163       OBJ       111.2
    y_163       link_163    -3.0
    y_164       OBJ       174.82
    y_164       link_164    -5.0
    y_165       OBJ       4.34
    y_165       link_165    -5.0
    y_166       OBJ       4.69
    y_166       link_166    -6.0
    y_167       OBJ       4.16
    y_167       link_167    -5.0
    y_168       OBJ       2.13
    y_168       link_168    -4.0
    y_169       OBJ       4.46
    y_169       link_169    -5.0
    y_170       OBJ       131.51
    y_170       link_170    -5.0
    y_171       OBJ       2.53
    y_171       link_171    -8.0
    y_172       OBJ       155.78
    y_172       link_172    -8.0
    y_173       OBJ       2.98
    y_173       link_173    -2.0
    y_174       OBJ       1.4
    y_174       link_174    -8.0
    y_175       OBJ       3.89
    y_175       link_175    -5.0
    y_176       OBJ       89.75
    y_176       link_176    -6.0
    y_177       OBJ       4.41
    y_177       link_177    -8.0
    y_178       OBJ       4.55
    y_178       link_178    -5.0
    y_179       OBJ       93.11
    y_179       link_179    -3.0
    y_180       OBJ       145.06
    y_180       link_180    -8.0
    y_181       OBJ       54.34
    y_181       link_181    -4.0
    y_182       OBJ       71.84
    y_182       link_182    -6.0
    y_183       OBJ       1.7
    y_183       link_183    -6.0
    y_184       OBJ       3.33
    y_184       link_184    -3.0
    y_185       OBJ       51.41
    y_185       link_185    -8.0
    y_186       OBJ       2.77
    y_186       link_186    -4.0
    y_187       OBJ       2.0
    y_187       link_187    -8.0
    y_188       OBJ       1.43
    y_188       link_188    -5.0
    y_189       OBJ       2.18
    y_189       link_189    -8.0
    y_190       OBJ       152.87
    y_190       link_190    -7.0
    y_191       OBJ       4.61
    y_191       link_191    -8.0
    y_192       OBJ       3.55
    y_192       link_192    -6.0
    y_193       OBJ       3.72
    y_193       link_193    -3.0
    y_194       OBJ       2.24
    y_194       link_194    -5.0
    y_195       OBJ       186.44
    y_195       link_195    -4.0
    y_196       OBJ       130.91
    y_196       link_196    -4.0
    y_197       OBJ       2.03
    y_197       link_197    -8.0
    y_198       OBJ       170.63
    y_198       link_198    -5.0
    y_199       OBJ       3.71
    y_199       link_199    -7.0
    y_200       OBJ       4.16
    y_200       link_200    -2.0
    y_201       OBJ       162.35
    y_201       link_201    -4.0
    y_202       OBJ       1.43
    y_202       link_202    -3.0
    y_203       OBJ       2.31
    y_203       link_203    -6.0
    y_204       OBJ       186.41
    y_204       link_204    -4.0
    y_205       OBJ       55.58
    y_205       link_205    -5.0
    y_206       OBJ       108.3
    y_206       link_206    -4.0
    y_207       OBJ       3.35
    y_207       link_207    -7.0
    y_208       OBJ       3.46
    y_208       link_208    -4.0
    y_209       OBJ       192.58
    y_209       link_209    -8.0
    y_210       OBJ       4.61
    y_210       link_210    -7.0
    y_211       OBJ       68.32
    y_211       link_211    -8.0
    y_212       OBJ       195.66
    y_212       link_212    -2.0
    y_213       OBJ       134.69
    y_213       link_213    -2.0
    y_214       OBJ       4.25
    y_214       link_214    -3.0
    y_215       OBJ       50.43
    y_215       link_215    -8.0
    y_216       OBJ       1.44
    y_216       link_216    -8.0
    y_217       OBJ       85.69
    y_217       link_217    -4.0
    y_218       OBJ       113.14
    y_218       link_218    -2.0
    y_219       OBJ       126.99
    y_219       link_219    -2.0
    y_220       OBJ       159.09
    y_220       link_220    -8.0
    y_221       OBJ       54.67
    y_221       link_221    -5.0
    y_222       OBJ       156.86
    y_222       link_222    -5.0
    y_223       OBJ       68.93
    y_223       link_223    -6.0
    y_224       OBJ       4.98
    y_224       link_224    -6.0
    y_225       OBJ       4.17
    y_225       link_225    -2.0
    y_226       OBJ       3.88
    y_226       link_226    -3.0
    y_227       OBJ       4.31
    y_227       link_227    -5.0
    y_228       OBJ       149.77
    y_228       link_228    -4.0
    y_229       OBJ       4.33
    y_229       link_229    -2.0
    y_230       OBJ       1.52
    y_230       link_230    -2.0
    y_231       OBJ       2.64
    y_231       link_231    -8.0
    y_232       OBJ       57.72
    y_232       link_232    -4.0
    y_233       OBJ       81.91
    y_233       link_233    -7.0
    y_234       OBJ       3.23
    y_234       link_234    -2.0
    y_235       OBJ       4.38
    y_235       link_235    -8.0
    y_236       OBJ       1.11
    y_236       link_236    -7.0
    y_237       OBJ       155.4
    y_237       link_237    -4.0
    y_238       OBJ       2.6
    y_238       link_238    -3.0
    y_239       OBJ       3.12
    y_239       link_239    -5.0
    y_240       OBJ       158.24
    y_240       link_240    -8.0
    y_241       OBJ       73.61
    y_241       link_241    -6.0
    y_242       OBJ       113.6
    y_242       link_242    -6.0
    y_243       OBJ       67.07
    y_243       link_243    -5.0
    y_244       OBJ       1.88
    y_244       link_244    -6.0
    y_245       OBJ       165.1
    y_245       link_245    -8.0
    y_246       OBJ       162.05
    y_246       link_246    -3.0
    y_247       OBJ       3.23
    y_247       link_247    -7.0
    y_248       OBJ       56.35
    y_248       link_248    -2.0
    y_249       OBJ       3.29
    y_249       link_249    -7.0
    y_250       OBJ       194.93
    y_250       link_250    -3.0
    y_251       OBJ       104.28
    y_251       link_251    -5.0
    y_252       OBJ       128.59
    y_252       link_252    -5.0
    y_253       OBJ       75.22
    y_253       link_253    -6.0
    y_254       OBJ       172.84
    y_254       link_254    -8.0
    y_255       OBJ       76.02
    y_255       link_255    -3.0
    y_256       OBJ       124.12
    y_256       link_256    -8.0
    y_257       OBJ       4.53
    y_257       link_257    -7.0
    y_258       OBJ       120.34
    y_258       link_258    -7.0
    y_259       OBJ       126.1
    y_259       link_259    -4.0
    y_260       OBJ       93.06
    y_260       link_260    -7.0
    y_261       OBJ       2.85
    y_261       link_261    -6.0
    y_262       OBJ       4.24
    y_262       link_262    -7.0
    y_263       OBJ       4.83
    y_263       link_263    -5.0
    y_264       OBJ       3.86
    y_264       link_264    -6.0
    y_265       OBJ       198.65
    y_265       link_265    -6.0
    y_266       OBJ       92.43
    y_266       link_266    -5.0
    y_267       OBJ       3.52
    y_267       link_267    -4.0
    y_268       OBJ       92.62
    y_268       link_268    -7.0
    y_269       OBJ       1.6
    y_269       link_269    -2.0
    y_270       OBJ       195.15
    y_270       link_270    -7.0
    y_271       OBJ       3.24
    y_271       link_271    -7.0
    y_272       OBJ       3.96
    y_272       link_272    -7.0
    y_273       OBJ       2.45
    y_273       link_273    -4.0
    y_274       OBJ       4.06
    y_274       link_274    -3.0
    y_275       OBJ       168.22
    y_275       link_275    -6.0
    y_276       OBJ       1.15
    y_276       link_276    -4.0
    y_277       OBJ       74.34
    y_277       link_277    -8.0
    y_278       OBJ       3.88
    y_278       link_278    -2.0
    y_279       OBJ       2.78
    y_279       link_279    -4.0
    y_280       OBJ       1.96
    y_280       link_280    -8.0
    y_281       OBJ       3.71
    y_281       link_281    -6.0
    y_282       OBJ       3.01
    y_282       link_282    -5.0
    y_283       OBJ       180.95
    y_283       link_283    -2.0
    y_284       OBJ       1.41
    y_284       link_284    -8.0
    y_285       OBJ       74.05
    y_285       link_285    -5.0
    y_286       OBJ       4.64
    y_286       link_286    -8.0
    y_287       OBJ       2.59
    y_287       link_287    -4.0
    y_288       OBJ       1.11
    y_288       link_288    -2.0
    y_289       OBJ       1.55
    y_289       link_289    -4.0
    y_290       OBJ       3.82
    y_290       link_290    -5.0
    y_291       OBJ       1.86
    y_291       link_291    -3.0
    y_292       OBJ       4.1
    y_292       link_292    -3.0
    y_293       OBJ       169.08
    y_293       link_293    -5.0
    y_294       OBJ       3.14
    y_294       link_294    -7.0
    y_295       OBJ       114.39
    y_295       link_295    -6.0
    y_296       OBJ       3.67
    y_296       link_296    -6.0
    y_297       OBJ       4.15
    y_297       link_297    -6.0
    y_298       OBJ       145.35
    y_298       link_298    -4.0
    y_299       OBJ       101.72
    y_299       link_299    -7.0
    y_300       OBJ       163.5
    y_300       link_300    -3.0
    y_301       OBJ       1.7
    y_301       link_301    -8.0
    y_302       OBJ       1.73
    y_302       link_302    -3.0
    y_303       OBJ       2.17
    y_303       link_303    -2.0
    y_304       OBJ       2.24
    y_304       link_304    -5.0
    y_305       OBJ       147.04
    y_305       link_305    -4.0
    y_306       OBJ       90.98
    y_306       link_306    -8.0
    y_307       OBJ       4.58
    y_307       link_307    -5.0
    y_308       OBJ       127.89
    y_308       link_308    -8.0
    y_309       OBJ       77.07
    y_309       link_309    -4.0
    y_310       OBJ       95.97
    y_310       link_310    -6.0
    y_311       OBJ       159.02
    y_311       link_311    -4.0
    y_312       OBJ       192.19
    y_312       link_312    -2.0
    y_313       OBJ       1.64
    y_313       link_313    -2.0
    y_314       OBJ       1.14
    y_314       link_314    -2.0
    y_315       OBJ       4.8
    y_315       link_315    -2.0
    y_316       OBJ       2.49
    y_316       link_316    -8.0
    y_317       OBJ       97.16
    y_317       link_317    -4.0
    y_318       OBJ       127.66
    y_318       link_318    -6.0
    y_319       OBJ       1.86
    y_319       link_319    -6.0
    y_320       OBJ       1.49
    y_320       link_320    -8.0
    y_321       OBJ       199.59
    y_321       link_321    -8.0
    y_322       OBJ       3.84
    y_322       link_322    -6.0
    y_323       OBJ       3.85
    y_323       link_323    -7.0
    y_324       OBJ       1.49
    y_324       link_324    -3.0
    y_325       OBJ       104.13
    y_325       link_325    -6.0
    y_326       OBJ       3.45
    y_326       link_326    -2.0
    y_327       OBJ       121.8
    y_327       link_327    -5.0
    y_328       OBJ       146.35
    y_328       link_328    -5.0
    y_329       OBJ       4.32
    y_329       link_329    -6.0
    y_330       OBJ       4.64
    y_330       link_330    -2.0
    y_331       OBJ       190.21
    y_331       link_331    -3.0
    y_332       OBJ       2.0
    y_332       link_332    -7.0
    y_333       OBJ       130.02
    y_333       link_333    -6.0
    y_334       OBJ       1.68
    y_334       link_334    -6.0
    y_335       OBJ       56.18
    y_335       link_335    -8.0
    y_336       OBJ       1.84
    y_336       link_336    -6.0
    y_337       OBJ       93.45
    y_337       link_337    -4.0
    y_338       OBJ       58.99
    y_338       link_338    -5.0
    y_339       OBJ       71.55
    y_339       link_339    -8.0
    y_340       OBJ       4.9
    y_340       link_340    -3.0
    y_341       OBJ       1.97
    y_341       link_341    -2.0
    y_342       OBJ       107.62
    y_342       link_342    -6.0
    y_343       OBJ       4.25
    y_343       link_343    -6.0
    y_344       OBJ       199.4
    y_344       link_344    -5.0
    y_345       OBJ       108.99
    y_345       link_345    -5.0
    y_346       OBJ       2.13
    y_346       link_346    -6.0
    y_347       OBJ       1.03
    y_347       link_347    -2.0
    y_348       OBJ       4.06
    y_348       link_348    -4.0
    y_349       OBJ       104.38
    y_349       link_349    -4.0
    y_350       OBJ       2.12
    y_350       link_350    -6.0
    y_351       OBJ       109.09
    y_351       link_351    -8.0
    y_352       OBJ       1.8
    y_352       link_352    -6.0
    y_353       OBJ       157.04
    y_353       link_353    -8.0
    y_354       OBJ       127.33
    y_354       link_354    -4.0
    y_355       OBJ       2.2
    y_355       link_355    -4.0
    y_356       OBJ       3.25
    y_356       link_356    -5.0
    y_357       OBJ       196.98
    y_357       link_357    -6.0
    y_358       OBJ       2.06
    y_358       link_358    -7.0
    y_359       OBJ       1.21
    y_359       link_359    -5.0
    y_360       OBJ       4.36
    y_360       link_360    -3.0
    y_361       OBJ       155.08
    y_361       link_361    -3.0
    y_362       OBJ       153.58
    y_362       link_362    -5.0
    y_363       OBJ       4.39
    y_363       link_363    -7.0
    y_364       OBJ       98.76
    y_364       link_364    -7.0
    y_365       OBJ       2.42
    y_365       link_365    -8.0
    y_366       OBJ       3.44
    y_366       link_366    -3.0
    y_367       OBJ       4.89
    y_367       link_367    -4.0
    y_368       OBJ       2.96
    y_368       link_368    -5.0
    y_369       OBJ       2.09
    y_369       link_369    -2.0
    y_370       OBJ       2.58
    y_370       link_370    -4.0
    y_371       OBJ       193.3
    y_371       link_371    -2.0
    y_372       OBJ       1.86
    y_372       link_372    -8.0
    y_373       OBJ       1.55
    y_373       link_373    -6.0
    y_374       OBJ       185.78
    y_374       link_374    -3.0
    y_375       OBJ       157.6
    y_375       link_375    -2.0
    y_376       OBJ       196.69
    y_376       link_376    -3.0
    y_377       OBJ       2.91
    y_377       link_377    -3.0
    y_378       OBJ       186.19
    y_378       link_378    -2.0
    y_379       OBJ       177.55
    y_379       link_379    -2.0
    y_380       OBJ       4.34
    y_380       link_380    -8.0
    y_381       OBJ       4.7
    y_381       link_381    -2.0
    y_382       OBJ       4.93
    y_382       link_382    -4.0
    y_383       OBJ       4.75
    y_383       link_383    -8.0
    y_384       OBJ       99.6
    y_384       link_384    -7.0
    y_385       OBJ       168.62
    y_385       link_385    -6.0
    y_386       OBJ       145.81
    y_386       link_386    -5.0
    y_387       OBJ       3.68
    y_387       link_387    -3.0
    y_388       OBJ       89.12
    y_388       link_388    -3.0
    y_389       OBJ       137.37
    y_389       link_389    -6.0
    y_390       OBJ       1.25
    y_390       link_390    -2.0
    y_391       OBJ       188.47
    y_391       link_391    -7.0
    y_392       OBJ       4.76
    y_392       link_392    -4.0
    y_393       OBJ       72.98
    y_393       link_393    -7.0
    y_394       OBJ       120.62
    y_394       link_394    -6.0
    y_395       OBJ       3.38
    y_395       link_395    -8.0
    y_396       OBJ       61.72
    y_396       link_396    -6.0
    y_397       OBJ       1.81
    y_397       link_397    -6.0
    y_398       OBJ       67.44
    y_398       link_398    -3.0
    y_399       OBJ       116.82
    y_399       link_399    -2.0
    y_400       OBJ       1.23
    y_400       link_400    -5.0
    y_401       OBJ       88.17
    y_401       link_401    -2.0
    y_402       OBJ       2.38
    y_402       link_402    -2.0
    y_403       OBJ       4.74
    y_403       link_403    -2.0
    y_404       OBJ       146.23
    y_404       link_404    -7.0
    y_405       OBJ       106.62
    y_405       link_405    -2.0
    y_406       OBJ       4.44
    y_406       link_406    -2.0
    y_407       OBJ       196.81
    y_407       link_407    -8.0
    y_408       OBJ       113.62
    y_408       link_408    -5.0
    y_409       OBJ       91.35
    y_409       link_409    -7.0
    y_410       OBJ       142.24
    y_410       link_410    -2.0
    y_411       OBJ       3.69
    y_411       link_411    -8.0
    y_412       OBJ       1.94
    y_412       link_412    -3.0
    y_413       OBJ       93.39
    y_413       link_413    -8.0
    y_414       OBJ       150.88
    y_414       link_414    -4.0
    y_415       OBJ       3.09
    y_415       link_415    -5.0
    y_416       OBJ       181.96
    y_416       link_416    -3.0
    y_417       OBJ       195.84
    y_417       link_417    -7.0
    y_418       OBJ       2.67
    y_418       link_418    -3.0
    y_419       OBJ       86.15
    y_419       link_419    -3.0
    y_420       OBJ       4.66
    y_420       link_420    -6.0
    y_421       OBJ       80.5
    y_421       link_421    -7.0
    y_422       OBJ       3.9
    y_422       link_422    -3.0
    y_423       OBJ       55.93
    y_423       link_423    -2.0
    y_424       OBJ       3.24
    y_424       link_424    -5.0
    y_425       OBJ       81.77
    y_425       link_425    -3.0
    y_426       OBJ       4.66
    y_426       link_426    -7.0
    y_427       OBJ       132.81
    y_427       link_427    -8.0
    y_428       OBJ       96.26
    y_428       link_428    -4.0
    y_429       OBJ       158.36
    y_429       link_429    -8.0
    y_430       OBJ       2.66
    y_430       link_430    -6.0
    y_431       OBJ       190.21
    y_431       link_431    -6.0
    y_432       OBJ       84.5
    y_432       link_432    -6.0
    y_433       OBJ       152.73
    y_433       link_433    -4.0
    y_434       OBJ       160.94
    y_434       link_434    -5.0
    y_435       OBJ       3.88
    y_435       link_435    -5.0
    y_436       OBJ       1.3
    y_436       link_436    -8.0
    y_437       OBJ       4.37
    y_437       link_437    -3.0
    y_438       OBJ       59.07
    y_438       link_438    -7.0
    y_439       OBJ       1.06
    y_439       link_439    -6.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_3      -21
    RHS       flow_4      25
    RHS       flow_5      28
    RHS       flow_13     -21
    RHS       flow_20     25
    RHS       flow_24     -21
    RHS       flow_30     -21
    RHS       flow_31     -21
    RHS       flow_36     27
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
 BV BOUND     y_84
 BV BOUND     y_85
 BV BOUND     y_86
 BV BOUND     y_87
 BV BOUND     y_88
 BV BOUND     y_89
 BV BOUND     y_90
 BV BOUND     y_91
 BV BOUND     y_92
 BV BOUND     y_93
 BV BOUND     y_94
 BV BOUND     y_95
 BV BOUND     y_96
 BV BOUND     y_97
 BV BOUND     y_98
 BV BOUND     y_99
 BV BOUND     y_100
 BV BOUND     y_101
 BV BOUND     y_102
 BV BOUND     y_103
 BV BOUND     y_104
 BV BOUND     y_105
 BV BOUND     y_106
 BV BOUND     y_107
 BV BOUND     y_108
 BV BOUND     y_109
 BV BOUND     y_110
 BV BOUND     y_111
 BV BOUND     y_112
 BV BOUND     y_113
 BV BOUND     y_114
 BV BOUND     y_115
 BV BOUND     y_116
 BV BOUND     y_117
 BV BOUND     y_118
 BV BOUND     y_119
 BV BOUND     y_120
 BV BOUND     y_121
 BV BOUND     y_122
 BV BOUND     y_123
 BV BOUND     y_124
 BV BOUND     y_125
 BV BOUND     y_126
 BV BOUND     y_127
 BV BOUND     y_128
 BV BOUND     y_129
 BV BOUND     y_130
 BV BOUND     y_131
 BV BOUND     y_132
 BV BOUND     y_133
 BV BOUND     y_134
 BV BOUND     y_135
 BV BOUND     y_136
 BV BOUND     y_137
 BV BOUND     y_138
 BV BOUND     y_139
 BV BOUND     y_140
 BV BOUND     y_141
 BV BOUND     y_142
 BV BOUND     y_143
 BV BOUND     y_144
 BV BOUND     y_145
 BV BOUND     y_146
 BV BOUND     y_147
 BV BOUND     y_148
 BV BOUND     y_149
 BV BOUND     y_150
 BV BOUND     y_151
 BV BOUND     y_152
 BV BOUND     y_153
 BV BOUND     y_154
 BV BOUND     y_155
 BV BOUND     y_156
 BV BOUND     y_157
 BV BOUND     y_158
 BV BOUND     y_159
 BV BOUND     y_160
 BV BOUND     y_161
 BV BOUND     y_162
 BV BOUND     y_163
 BV BOUND     y_164
 BV BOUND     y_165
 BV BOUND     y_166
 BV BOUND     y_167
 BV BOUND     y_168
 BV BOUND     y_169
 BV BOUND     y_170
 BV BOUND     y_171
 BV BOUND     y_172
 BV BOUND     y_173
 BV BOUND     y_174
 BV BOUND     y_175
 BV BOUND     y_176
 BV BOUND     y_177
 BV BOUND     y_178
 BV BOUND     y_179
 BV BOUND     y_180
 BV BOUND     y_181
 BV BOUND     y_182
 BV BOUND     y_183
 BV BOUND     y_184
 BV BOUND     y_185
 BV BOUND     y_186
 BV BOUND     y_187
 BV BOUND     y_188
 BV BOUND     y_189
 BV BOUND     y_190
 BV BOUND     y_191
 BV BOUND     y_192
 BV BOUND     y_193
 BV BOUND     y_194
 BV BOUND     y_195
 BV BOUND     y_196
 BV BOUND     y_197
 BV BOUND     y_198
 BV BOUND     y_199
 BV BOUND     y_200
 BV BOUND     y_201
 BV BOUND     y_202
 BV BOUND     y_203
 BV BOUND     y_204
 BV BOUND     y_205
 BV BOUND     y_206
 BV BOUND     y_207
 BV BOUND     y_208
 BV BOUND     y_209
 BV BOUND     y_210
 BV BOUND     y_211
 BV BOUND     y_212
 BV BOUND     y_213
 BV BOUND     y_214
 BV BOUND     y_215
 BV BOUND     y_216
 BV BOUND     y_217
 BV BOUND     y_218
 BV BOUND     y_219
 BV BOUND     y_220
 BV BOUND     y_221
 BV BOUND     y_222
 BV BOUND     y_223
 BV BOUND     y_224
 BV BOUND     y_225
 BV BOUND     y_226
 BV BOUND     y_227
 BV BOUND     y_228
 BV BOUND     y_229
 BV BOUND     y_230
 BV BOUND     y_231
 BV BOUND     y_232
 BV BOUND     y_233
 BV BOUND     y_234
 BV BOUND     y_235
 BV BOUND     y_236
 BV BOUND     y_237
 BV BOUND     y_238
 BV BOUND     y_239
 BV BOUND     y_240
 BV BOUND     y_241
 BV BOUND     y_242
 BV BOUND     y_243
 BV BOUND     y_244
 BV BOUND     y_245
 BV BOUND     y_246
 BV BOUND     y_247
 BV BOUND     y_248
 BV BOUND     y_249
 BV BOUND     y_250
 BV BOUND     y_251
 BV BOUND     y_252
 BV BOUND     y_253
 BV BOUND     y_254
 BV BOUND     y_255
 BV BOUND     y_256
 BV BOUND     y_257
 BV BOUND     y_258
 BV BOUND     y_259
 BV BOUND     y_260
 BV BOUND     y_261
 BV BOUND     y_262
 BV BOUND     y_263
 BV BOUND     y_264
 BV BOUND     y_265
 BV BOUND     y_266
 BV BOUND     y_267
 BV BOUND     y_268
 BV BOUND     y_269
 BV BOUND     y_270
 BV BOUND     y_271
 BV BOUND     y_272
 BV BOUND     y_273
 BV BOUND     y_274
 BV BOUND     y_275
 BV BOUND     y_276
 BV BOUND     y_277
 BV BOUND     y_278
 BV BOUND     y_279
 BV BOUND     y_280
 BV BOUND     y_281
 BV BOUND     y_282
 BV BOUND     y_283
 BV BOUND     y_284
 BV BOUND     y_285
 BV BOUND     y_286
 BV BOUND     y_287
 BV BOUND     y_288
 BV BOUND     y_289
 BV BOUND     y_290
 BV BOUND     y_291
 BV BOUND     y_292
 BV BOUND     y_293
 BV BOUND     y_294
 BV BOUND     y_295
 BV BOUND     y_296
 BV BOUND     y_297
 BV BOUND     y_298
 BV BOUND     y_299
 BV BOUND     y_300
 BV BOUND     y_301
 BV BOUND     y_302
 BV BOUND     y_303
 BV BOUND     y_304
 BV BOUND     y_305
 BV BOUND     y_306
 BV BOUND     y_307
 BV BOUND     y_308
 BV BOUND     y_309
 BV BOUND     y_310
 BV BOUND     y_311
 BV BOUND     y_312
 BV BOUND     y_313
 BV BOUND     y_314
 BV BOUND     y_315
 BV BOUND     y_316
 BV BOUND     y_317
 BV BOUND     y_318
 BV BOUND     y_319
 BV BOUND     y_320
 BV BOUND     y_321
 BV BOUND     y_322
 BV BOUND     y_323
 BV BOUND     y_324
 BV BOUND     y_325
 BV BOUND     y_326
 BV BOUND     y_327
 BV BOUND     y_328
 BV BOUND     y_329
 BV BOUND     y_330
 BV BOUND     y_331
 BV BOUND     y_332
 BV BOUND     y_333
 BV BOUND     y_334
 BV BOUND     y_335
 BV BOUND     y_336
 BV BOUND     y_337
 BV BOUND     y_338
 BV BOUND     y_339
 BV BOUND     y_340
 BV BOUND     y_341
 BV BOUND     y_342
 BV BOUND     y_343
 BV BOUND     y_344
 BV BOUND     y_345
 BV BOUND     y_346
 BV BOUND     y_347
 BV BOUND     y_348
 BV BOUND     y_349
 BV BOUND     y_350
 BV BOUND     y_351
 BV BOUND     y_352
 BV BOUND     y_353
 BV BOUND     y_354
 BV BOUND     y_355
 BV BOUND     y_356
 BV BOUND     y_357
 BV BOUND     y_358
 BV BOUND     y_359
 BV BOUND     y_360
 BV BOUND     y_361
 BV BOUND     y_362
 BV BOUND     y_363
 BV BOUND     y_364
 BV BOUND     y_365
 BV BOUND     y_366
 BV BOUND     y_367
 BV BOUND     y_368
 BV BOUND     y_369
 BV BOUND     y_370
 BV BOUND     y_371
 BV BOUND     y_372
 BV BOUND     y_373
 BV BOUND     y_374
 BV BOUND     y_375
 BV BOUND     y_376
 BV BOUND     y_377
 BV BOUND     y_378
 BV BOUND     y_379
 BV BOUND     y_380
 BV BOUND     y_381
 BV BOUND     y_382
 BV BOUND     y_383
 BV BOUND     y_384
 BV BOUND     y_385
 BV BOUND     y_386
 BV BOUND     y_387
 BV BOUND     y_388
 BV BOUND     y_389
 BV BOUND     y_390
 BV BOUND     y_391
 BV BOUND     y_392
 BV BOUND     y_393
 BV BOUND     y_394
 BV BOUND     y_395
 BV BOUND     y_396
 BV BOUND     y_397
 BV BOUND     y_398
 BV BOUND     y_399
 BV BOUND     y_400
 BV BOUND     y_401
 BV BOUND     y_402
 BV BOUND     y_403
 BV BOUND     y_404
 BV BOUND     y_405
 BV BOUND     y_406
 BV BOUND     y_407
 BV BOUND     y_408
 BV BOUND     y_409
 BV BOUND     y_410
 BV BOUND     y_411
 BV BOUND     y_412
 BV BOUND     y_413
 BV BOUND     y_414
 BV BOUND     y_415
 BV BOUND     y_416
 BV BOUND     y_417
 BV BOUND     y_418
 BV BOUND     y_419
 BV BOUND     y_420
 BV BOUND     y_421
 BV BOUND     y_422
 BV BOUND     y_423
 BV BOUND     y_424
 BV BOUND     y_425
 BV BOUND     y_426
 BV BOUND     y_427
 BV BOUND     y_428
 BV BOUND     y_429
 BV BOUND     y_430
 BV BOUND     y_431
 BV BOUND     y_432
 BV BOUND     y_433
 BV BOUND     y_434
 BV BOUND     y_435
 BV BOUND     y_436
 BV BOUND     y_437
 BV BOUND     y_438
 BV BOUND     y_439
ENDATA
