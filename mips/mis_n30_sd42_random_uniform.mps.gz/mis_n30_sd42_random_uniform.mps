NAME          MIS
ROWS
 N  OBJ
 L  EDGE_16_20
 L  EDGE_7_17
 L  EDGE_5_10
 L  EDGE_23_25
 L  EDGE_5_19
 L  EDGE_0_14
 L  EDGE_11_23
 L  EDGE_1_15
 L  EDGE_1_24
 L  EDGE_13_26
 L  EDGE_12_18
 L  EDGE_3_24
 L  EDGE_2_4
 L  EDGE_14_24
 L  EDGE_9_19
 L  EDGE_1_17
 L  EDGE_13_19
 L  EDGE_6_13
 L  EDGE_10_29
 L  EDGE_13_28
 L  EDGE_2_25
 L  EDGE_3_8
 L  EDGE_12_20
 L  EDGE_12_29
 L  EDGE_3_26
 L  EDGE_23_29
 L  EDGE_10_22
 L  EDGE_1_19
 L  EDGE_7_14
 L  EDGE_2_27
 L  EDGE_16_26
 L  EDGE_7_23
 L  EDGE_3_10
 L  EDGE_5_7
 L  EDGE_20_26
 L  EDGE_0_2
 L  EDGE_5_16
 L  EDGE_5_25
 L  EDGE_10_15
 L  EDGE_10_24
 L  EDGE_16_28
 L  EDGE_4_11
 L  EDGE_12_24
 L  EDGE_23_24
 L  EDGE_9_16
 L  EDGE_4_29
 L  EDGE_1_14
 L  EDGE_2_13
 L  EDGE_8_29
 L  EDGE_7_9
 L  EDGE_3_5
 L  EDGE_3_14
 L  EDGE_21_29
 L  EDGE_23_26
 L  EDGE_1_16
 L  EDGE_2_15
 L  EDGE_1_25
 L  EDGE_0_27
 L  EDGE_2_24
 L  EDGE_25_26
 L  EDGE_15_27
 L  EDGE_6_24
 L  EDGE_4_6
 L  EDGE_5_13
 L  EDGE_12_28
 L  EDGE_17_18
 L  EDGE_8_15
 L  EDGE_10_12
 L  EDGE_27_28
 L  EDGE_0_11
 L  EDGE_17_27
 L  EDGE_8_24
 L  EDGE_1_18
 L  EDGE_0_20
 L  EDGE_11_29
 L  EDGE_25_28
 L  EDGE_6_8
 L  EDGE_6_17
 L  EDGE_15_29
 L  EDGE_3_9
 L  EDGE_20_25
 L  EDGE_4_8
 L  EDGE_18_25
 L  EDGE_12_21
 L  EDGE_14_18
 L  EDGE_21_24
 L  EDGE_4_26
 L  EDGE_0_4
 L  EDGE_0_13
 L  EDGE_17_29
 L  EDGE_19_26
 L  EDGE_10_23
 L  EDGE_1_20
 L  EDGE_11_22
 L  EDGE_6_10
 L  EDGE_15_22
 L  EDGE_7_18
 L  EDGE_12_14
 L  EDGE_4_19
 L  EDGE_8_10
 L  EDGE_2_12
 L  EDGE_5_29
 L  EDGE_0_24
 L  EDGE_11_24
 L  EDGE_13_27
 L  EDGE_24_27
 L  EDGE_7_29
 L  EDGE_21_28
 L  EDGE_4_21
 L  EDGE_8_12
 L  EDGE_22_29
 L  EDGE_0_8
 L  EDGE_10_18
 L  EDGE_9_20
 L  EDGE_0_17
 L  EDGE_11_17
 L  EDGE_9_29
 L  EDGE_11_26
 L  EDGE_13_20
 L  EDGE_15_17
 L  EDGE_6_14
 L  EDGE_7_13
 L  EDGE_6_23
 L  EDGE_4_14
 L  EDGE_9_13
 L  EDGE_0_10
 L  EDGE_8_23
 L  EDGE_9_22
 L  EDGE_11_19
 L  EDGE_2_16
 L  EDGE_0_28
 L  EDGE_6_7
 L  EDGE_15_19
 L  EDGE_6_16
 L  EDGE_1_29
 L  EDGE_15_28
 L  EDGE_26_28
 L  EDGE_0_3
 L  EDGE_3_20
 L  EDGE_17_19
 L  EDGE_9_15
 L  EDGE_5_26
 L  EDGE_19_25
COLUMNS
    x_0         OBJ       -82
    x_0         EDGE_0_14  1.0
    x_0         EDGE_0_2  1.0
    x_0         EDGE_0_27  1.0
    x_0         EDGE_0_11  1.0
    x_0         EDGE_0_20  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_13  1.0
    x_0         EDGE_0_24  1.0
    x_0         EDGE_0_8  1.0
    x_0         EDGE_0_17  1.0
    x_0         EDGE_0_10  1.0
    x_0         EDGE_0_28  1.0
    x_0         EDGE_0_3  1.0
    x_1         OBJ       -15
    x_1         EDGE_1_15  1.0
    x_1         EDGE_1_24  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_19  1.0
    x_1         EDGE_1_14  1.0
    x_1         EDGE_1_16  1.0
    x_1         EDGE_1_25  1.0
    x_1         EDGE_1_18  1.0
    x_1         EDGE_1_20  1.0
    x_1         EDGE_1_29  1.0
    x_2         OBJ       -4
    x_2         EDGE_2_4  1.0
    x_2         EDGE_2_25  1.0
    x_2         EDGE_2_27  1.0
    x_2         EDGE_0_2  1.0
    x_2         EDGE_2_13  1.0
    x_2         EDGE_2_15  1.0
    x_2         EDGE_2_24  1.0
    x_2         EDGE_2_12  1.0
    x_2         EDGE_2_16  1.0
    x_3         OBJ       -95
    x_3         EDGE_3_24  1.0
    x_3         EDGE_3_8  1.0
    x_3         EDGE_3_26  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_5  1.0
    x_3         EDGE_3_14  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_0_3  1.0
    x_3         EDGE_3_20  1.0
    x_4         OBJ       -36
    x_4         EDGE_2_4  1.0
    x_4         EDGE_4_11  1.0
    x_4         EDGE_4_29  1.0
    x_4         EDGE_4_6  1.0
    x_4         EDGE_4_8  1.0
    x_4         EDGE_4_26  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_4_19  1.0
    x_4         EDGE_4_21  1.0
    x_4         EDGE_4_14  1.0
    x_5         OBJ       -32
    x_5         EDGE_5_10  1.0
    x_5         EDGE_5_19  1.0
    x_5         EDGE_5_7  1.0
    x_5         EDGE_5_16  1.0
    x_5         EDGE_5_25  1.0
    x_5         EDGE_3_5  1.0
    x_5         EDGE_5_13  1.0
    x_5         EDGE_5_29  1.0
    x_5         EDGE_5_26  1.0
    x_6         OBJ       -29
    x_6         EDGE_6_13  1.0
    x_6         EDGE_6_24  1.0
    x_6         EDGE_4_6  1.0
    x_6         EDGE_6_8  1.0
    x_6         EDGE_6_17  1.0
    x_6         EDGE_6_10  1.0
    x_6         EDGE_6_14  1.0
    x_6         EDGE_6_23  1.0
    x_6         EDGE_6_7  1.0
    x_6         EDGE_6_16  1.0
    x_7         OBJ       -18
    x_7         EDGE_7_17  1.0
    x_7         EDGE_7_14  1.0
    x_7         EDGE_7_23  1.0
    x_7         EDGE_5_7  1.0
    x_7         EDGE_7_9  1.0
    x_7         EDGE_7_18  1.0
    x_7         EDGE_7_29  1.0
    x_7         EDGE_7_13  1.0
    x_7         EDGE_6_7  1.0
    x_8         OBJ       -95
    x_8         EDGE_3_8  1.0
    x_8         EDGE_8_29  1.0
    x_8         EDGE_8_15  1.0
    x_8         EDGE_8_24  1.0
    x_8         EDGE_6_8  1.0
    x_8         EDGE_4_8  1.0
    x_8         EDGE_8_10  1.0
    x_8         EDGE_8_12  1.0
    x_8         EDGE_0_8  1.0
    x_8         EDGE_8_23  1.0
    x_9         OBJ       -14
    x_9         EDGE_9_19  1.0
    x_9         EDGE_9_16  1.0
    x_9         EDGE_7_9  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_9_20  1.0
    x_9         EDGE_9_29  1.0
    x_9         EDGE_9_13  1.0
    x_9         EDGE_9_22  1.0
    x_9         EDGE_9_15  1.0
    x_10        OBJ       -87
    x_10        EDGE_5_10  1.0
    x_10        EDGE_10_29  1.0
    x_10        EDGE_10_22  1.0
    x_10        EDGE_3_10  1.0
    x_10        EDGE_10_15  1.0
    x_10        EDGE_10_24  1.0
    x_10        EDGE_10_12  1.0
    x_10        EDGE_10_23  1.0
    x_10        EDGE_6_10  1.0
    x_10        EDGE_8_10  1.0
    x_10        EDGE_10_18  1.0
    x_10        EDGE_0_10  1.0
    x_11        OBJ       -95
    x_11        EDGE_11_23  1.0
    x_11        EDGE_4_11  1.0
    x_11        EDGE_0_11  1.0
    x_11        EDGE_11_29  1.0
    x_11        EDGE_11_22  1.0
    x_11        EDGE_11_24  1.0
    x_11        EDGE_11_17  1.0
    x_11        EDGE_11_26  1.0
    x_11        EDGE_11_19  1.0
    x_12        OBJ       -70
    x_12        EDGE_12_18  1.0
    x_12        EDGE_12_20  1.0
    x_12        EDGE_12_29  1.0
    x_12        EDGE_12_24  1.0
    x_12        EDGE_12_28  1.0
    x_12        EDGE_10_12  1.0
    x_12        EDGE_12_21  1.0
    x_12        EDGE_12_14  1.0
    x_12        EDGE_2_12  1.0
    x_12        EDGE_8_12  1.0
    x_13        OBJ       -12
    x_13        EDGE_13_26  1.0
    x_13        EDGE_13_19  1.0
    x_13        EDGE_6_13  1.0
    x_13        EDGE_13_28  1.0
    x_13        EDGE_2_13  1.0
    x_13        EDGE_5_13  1.0
    x_13        EDGE_0_13  1.0
    x_13        EDGE_13_27  1.0
    x_13        EDGE_13_20  1.0
    x_13        EDGE_7_13  1.0
    x_13        EDGE_9_13  1.0
    x_14        OBJ       -76
    x_14        EDGE_0_14  1.0
    x_14        EDGE_14_24  1.0
    x_14        EDGE_7_14  1.0
    x_14        EDGE_1_14  1.0
    x_14        EDGE_3_14  1.0
    x_14        EDGE_14_18  1.0
    x_14        EDGE_12_14  1.0
    x_14        EDGE_6_14  1.0
    x_14        EDGE_4_14  1.0
    x_15        OBJ       -55
    x_15        EDGE_1_15  1.0
    x_15        EDGE_10_15  1.0
    x_15        EDGE_2_15  1.0
    x_15        EDGE_15_27  1.0
    x_15        EDGE_8_15  1.0
    x_15        EDGE_15_29  1.0
    x_15        EDGE_15_22  1.0
    x_15        EDGE_15_17  1.0
    x_15        EDGE_15_19  1.0
    x_15        EDGE_15_28  1.0
    x_15        EDGE_9_15  1.0
    x_16        OBJ       -5
    x_16        EDGE_16_20  1.0
    x_16        EDGE_16_26  1.0
    x_16        EDGE_5_16  1.0
    x_16        EDGE_16_28  1.0
    x_16        EDGE_9_16  1.0
    x_16        EDGE_1_16  1.0
    x_16        EDGE_2_16  1.0
    x_16        EDGE_6_16  1.0
    x_17        OBJ       -4
    x_17        EDGE_7_17  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_17_18  1.0
    x_17        EDGE_17_27  1.0
    x_17        EDGE_6_17  1.0
    x_17        EDGE_17_29  1.0
    x_17        EDGE_0_17  1.0
    x_17        EDGE_11_17  1.0
    x_17        EDGE_15_17  1.0
    x_17        EDGE_17_19  1.0
    x_18        OBJ       -12
    x_18        EDGE_12_18  1.0
    x_18        EDGE_17_18  1.0
    x_18        EDGE_1_18  1.0
    x_18        EDGE_18_25  1.0
    x_18        EDGE_14_18  1.0
    x_18        EDGE_7_18  1.0
    x_18        EDGE_10_18  1.0
    x_19        OBJ       -28
    x_19        EDGE_5_19  1.0
    x_19        EDGE_9_19  1.0
    x_19        EDGE_13_19  1.0
    x_19        EDGE_1_19  1.0
    x_19        EDGE_19_26  1.0
    x_19        EDGE_4_19  1.0
    x_19        EDGE_11_19  1.0
    x_19        EDGE_15_19  1.0
    x_19        EDGE_17_19  1.0
    x_19        EDGE_19_25  1.0
    x_20        OBJ       -30
    x_20        EDGE_16_20  1.0
    x_20        EDGE_12_20  1.0
    x_20        EDGE_20_26  1.0
    x_20        EDGE_0_20  1.0
    x_20        EDGE_20_25  1.0
    x_20        EDGE_1_20  1.0
    x_20        EDGE_9_20  1.0
    x_20        EDGE_13_20  1.0
    x_20        EDGE_3_20  1.0
    x_21        OBJ       -65
    x_21        EDGE_21_29  1.0
    x_21        EDGE_12_21  1.0
    x_21        EDGE_21_24  1.0
    x_21        EDGE_21_28  1.0
    x_21        EDGE_4_21  1.0
    x_22        OBJ       -78
    x_22        EDGE_10_22  1.0
    x_22        EDGE_11_22  1.0
    x_22        EDGE_15_22  1.0
    x_22        EDGE_22_29  1.0
    x_22        EDGE_9_22  1.0
    x_23        OBJ       -4
    x_23        EDGE_23_25  1.0
    x_23        EDGE_11_23  1.0
    x_23        EDGE_23_29  1.0
    x_23        EDGE_7_23  1.0
    x_23        EDGE_23_24  1.0
    x_23        EDGE_23_26  1.0
    x_23        EDGE_10_23  1.0
    x_23        EDGE_6_23  1.0
    x_23        EDGE_8_23  1.0
    x_24        OBJ       -72
    x_24        EDGE_1_24  1.0
    x_24        EDGE_3_24  1.0
    x_24        EDGE_14_24  1.0
    x_24        EDGE_10_24  1.0
    x_24        EDGE_12_24  1.0
    x_24        EDGE_23_24  1.0
    x_24        EDGE_2_24  1.0
    x_24        EDGE_6_24  1.0
    x_24        EDGE_8_24  1.0
    x_24        EDGE_21_24  1.0
    x_24        EDGE_0_24  1.0
    x_24        EDGE_11_24  1.0
    x_24        EDGE_24_27  1.0
    x_25        OBJ       -26
    x_25        EDGE_23_25  1.0
    x_25        EDGE_2_25  1.0
    x_25        EDGE_5_25  1.0
    x_25        EDGE_1_25  1.0
    x_25        EDGE_25_26  1.0
    x_25        EDGE_25_28  1.0
    x_25        EDGE_20_25  1.0
    x_25        EDGE_18_25  1.0
    x_25        EDGE_19_25  1.0
    x_26        OBJ       -92
    x_26        EDGE_13_26  1.0
    x_26        EDGE_3_26  1.0
    x_26        EDGE_16_26  1.0
    x_26        EDGE_20_26  1.0
    x_26        EDGE_23_26  1.0
    x_26        EDGE_25_26  1.0
    x_26        EDGE_4_26  1.0
    x_26        EDGE_19_26  1.0
    x_26        EDGE_11_26  1.0
    x_26        EDGE_26_28  1.0
    x_26        EDGE_5_26  1.0
    x_27        OBJ       -84
    x_27        EDGE_2_27  1.0
    x_27        EDGE_0_27  1.0
    x_27        EDGE_15_27  1.0
    x_27        EDGE_27_28  1.0
    x_27        EDGE_17_27  1.0
    x_27        EDGE_13_27  1.0
    x_27        EDGE_24_27  1.0
    x_28        OBJ       -90
    x_28        EDGE_13_28  1.0
    x_28        EDGE_16_28  1.0
    x_28        EDGE_12_28  1.0
    x_28        EDGE_27_28  1.0
    x_28        EDGE_25_28  1.0
    x_28        EDGE_21_28  1.0
    x_28        EDGE_0_28  1.0
    x_28        EDGE_15_28  1.0
    x_28        EDGE_26_28  1.0
    x_29        OBJ       -70
    x_29        EDGE_10_29  1.0
    x_29        EDGE_12_29  1.0
    x_29        EDGE_23_29  1.0
    x_29        EDGE_4_29  1.0
    x_29        EDGE_8_29  1.0
    x_29        EDGE_21_29  1.0
    x_29        EDGE_11_29  1.0
    x_29        EDGE_15_29  1.0
    x_29        EDGE_17_29  1.0
    x_29        EDGE_5_29  1.0
    x_29        EDGE_7_29  1.0
    x_29        EDGE_22_29  1.0
    x_29        EDGE_9_29  1.0
    x_29        EDGE_1_29  1.0
RHS
    RHS1      EDGE_16_20  1.0
    RHS1      EDGE_7_17  1.0
    RHS1      EDGE_5_10  1.0
    RHS1      EDGE_23_25  1.0
    RHS1      EDGE_5_19  1.0
    RHS1      EDGE_0_14  1.0
    RHS1      EDGE_11_23  1.0
    RHS1      EDGE_1_15  1.0
    RHS1      EDGE_1_24  1.0
    RHS1      EDGE_13_26  1.0
    RHS1      EDGE_12_18  1.0
    RHS1      EDGE_3_24  1.0
    RHS1      EDGE_2_4  1.0
    RHS1      EDGE_14_24  1.0
    RHS1      EDGE_9_19  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_13_19  1.0
    RHS1      EDGE_6_13  1.0
    RHS1      EDGE_10_29  1.0
    RHS1      EDGE_13_28  1.0
    RHS1      EDGE_2_25  1.0
    RHS1      EDGE_3_8  1.0
    RHS1      EDGE_12_20  1.0
    RHS1      EDGE_12_29  1.0
    RHS1      EDGE_3_26  1.0
    RHS1      EDGE_23_29  1.0
    RHS1      EDGE_10_22  1.0
    RHS1      EDGE_1_19  1.0
    RHS1      EDGE_7_14  1.0
    RHS1      EDGE_2_27  1.0
    RHS1      EDGE_16_26  1.0
    RHS1      EDGE_7_23  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_5_7  1.0
    RHS1      EDGE_20_26  1.0
    RHS1      EDGE_0_2  1.0
    RHS1      EDGE_5_16  1.0
    RHS1      EDGE_5_25  1.0
    RHS1      EDGE_10_15  1.0
    RHS1      EDGE_10_24  1.0
    RHS1      EDGE_16_28  1.0
    RHS1      EDGE_4_11  1.0
    RHS1      EDGE_12_24  1.0
    RHS1      EDGE_23_24  1.0
    RHS1      EDGE_9_16  1.0
    RHS1      EDGE_4_29  1.0
    RHS1      EDGE_1_14  1.0
    RHS1      EDGE_2_13  1.0
    RHS1      EDGE_8_29  1.0
    RHS1      EDGE_7_9  1.0
    RHS1      EDGE_3_5  1.0
    RHS1      EDGE_3_14  1.0
    RHS1      EDGE_21_29  1.0
    RHS1      EDGE_23_26  1.0
    RHS1      EDGE_1_16  1.0
    RHS1      EDGE_2_15  1.0
    RHS1      EDGE_1_25  1.0
    RHS1      EDGE_0_27  1.0
    RHS1      EDGE_2_24  1.0
    RHS1      EDGE_25_26  1.0
    RHS1      EDGE_15_27  1.0
    RHS1      EDGE_6_24  1.0
    RHS1      EDGE_4_6  1.0
    RHS1      EDGE_5_13  1.0
    RHS1      EDGE_12_28  1.0
    RHS1      EDGE_17_18  1.0
    RHS1      EDGE_8_15  1.0
    RHS1      EDGE_10_12  1.0
    RHS1      EDGE_27_28  1.0
    RHS1      EDGE_0_11  1.0
    RHS1      EDGE_17_27  1.0
    RHS1      EDGE_8_24  1.0
    RHS1      EDGE_1_18  1.0
    RHS1      EDGE_0_20  1.0
    RHS1      EDGE_11_29  1.0
    RHS1      EDGE_25_28  1.0
    RHS1      EDGE_6_8  1.0
    RHS1      EDGE_6_17  1.0
    RHS1      EDGE_15_29  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_20_25  1.0
    RHS1      EDGE_4_8  1.0
    RHS1      EDGE_18_25  1.0
    RHS1      EDGE_12_21  1.0
    RHS1      EDGE_14_18  1.0
    RHS1      EDGE_21_24  1.0
    RHS1      EDGE_4_26  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_0_13  1.0
    RHS1      EDGE_17_29  1.0
    RHS1      EDGE_19_26  1.0
    RHS1      EDGE_10_23  1.0
    RHS1      EDGE_1_20  1.0
    RHS1      EDGE_11_22  1.0
    RHS1      EDGE_6_10  1.0
    RHS1      EDGE_15_22  1.0
    RHS1      EDGE_7_18  1.0
    RHS1      EDGE_12_14  1.0
    RHS1      EDGE_4_19  1.0
    RHS1      EDGE_8_10  1.0
    RHS1      EDGE_2_12  1.0
    RHS1      EDGE_5_29  1.0
    RHS1      EDGE_0_24  1.0
    RHS1      EDGE_11_24  1.0
    RHS1      EDGE_13_27  1.0
    RHS1      EDGE_24_27  1.0
    RHS1      EDGE_7_29  1.0
    RHS1      EDGE_21_28  1.0
    RHS1      EDGE_4_21  1.0
    RHS1      EDGE_8_12  1.0
    RHS1      EDGE_22_29  1.0
    RHS1      EDGE_0_8  1.0
    RHS1      EDGE_10_18  1.0
    RHS1      EDGE_9_20  1.0
    RHS1      EDGE_0_17  1.0
    RHS1      EDGE_11_17  1.0
    RHS1      EDGE_9_29  1.0
    RHS1      EDGE_11_26  1.0
    RHS1      EDGE_13_20  1.0
    RHS1      EDGE_15_17  1.0
    RHS1      EDGE_6_14  1.0
    RHS1      EDGE_7_13  1.0
    RHS1      EDGE_6_23  1.0
    RHS1      EDGE_4_14  1.0
    RHS1      EDGE_9_13  1.0
    RHS1      EDGE_0_10  1.0
    RHS1      EDGE_8_23  1.0
    RHS1      EDGE_9_22  1.0
    RHS1      EDGE_11_19  1.0
    RHS1      EDGE_2_16  1.0
    RHS1      EDGE_0_28  1.0
    RHS1      EDGE_6_7  1.0
    RHS1      EDGE_15_19  1.0
    RHS1      EDGE_6_16  1.0
    RHS1      EDGE_1_29  1.0
    RHS1      EDGE_15_28  1.0
    RHS1      EDGE_26_28  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_3_20  1.0
    RHS1      EDGE_17_19  1.0
    RHS1      EDGE_9_15  1.0
    RHS1      EDGE_5_26  1.0
    RHS1      EDGE_19_25  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
ENDATA
