NAME          upms_search_n7_m2_cmax_p5-18_s8-22_sd21
ROWS
 N  OBJ
 E  asgn_0
 E  asgn_1
 E  asgn_2
 E  asgn_3
 E  asgn_4
 E  asgn_5
 E  asgn_6
 G  lb_0_0
 G  lb_0_1
 G  lb_1_0
 G  lb_1_1
 G  lb_2_0
 G  lb_2_1
 G  lb_3_0
 G  lb_3_1
 G  lb_4_0
 G  lb_4_1
 G  lb_5_0
 G  lb_5_1
 G  lb_6_0
 G  lb_6_1
 G  prA_0_1_0
 G  prB_0_1_0
 G  prA_0_1_1
 G  prB_0_1_1
 G  prA_0_2_0
 G  prB_0_2_0
 G  prA_0_2_1
 G  prB_0_2_1
 G  prA_0_3_0
 G  prB_0_3_0
 G  prA_0_3_1
 G  prB_0_3_1
 G  prA_0_4_0
 G  prB_0_4_0
 G  prA_0_4_1
 G  prB_0_4_1
 G  prA_0_5_0
 G  prB_0_5_0
 G  prA_0_5_1
 G  prB_0_5_1
 G  prA_0_6_0
 G  prB_0_6_0
 G  prA_0_6_1
 G  prB_0_6_1
 G  prA_1_2_0
 G  prB_1_2_0
 G  prA_1_2_1
 G  prB_1_2_1
 G  prA_1_3_0
 G  prB_1_3_0
 G  prA_1_3_1
 G  prB_1_3_1
 G  prA_1_4_0
 G  prB_1_4_0
 G  prA_1_4_1
 G  prB_1_4_1
 G  prA_1_5_0
 G  prB_1_5_0
 G  prA_1_5_1
 G  prB_1_5_1
 G  prA_1_6_0
 G  prB_1_6_0
 G  prA_1_6_1
 G  prB_1_6_1
 G  prA_2_3_0
 G  prB_2_3_0
 G  prA_2_3_1
 G  prB_2_3_1
 G  prA_2_4_0
 G  prB_2_4_0
 G  prA_2_4_1
 G  prB_2_4_1
 G  prA_2_5_0
 G  prB_2_5_0
 G  prA_2_5_1
 G  prB_2_5_1
 G  prA_2_6_0
 G  prB_2_6_0
 G  prA_2_6_1
 G  prB_2_6_1
 G  prA_3_4_0
 G  prB_3_4_0
 G  prA_3_4_1
 G  prB_3_4_1
 G  prA_3_5_0
 G  prB_3_5_0
 G  prA_3_5_1
 G  prB_3_5_1
 G  prA_3_6_0
 G  prB_3_6_0
 G  prA_3_6_1
 G  prB_3_6_1
 G  prA_4_5_0
 G  prB_4_5_0
 G  prA_4_5_1
 G  prB_4_5_1
 G  prA_4_6_0
 G  prB_4_6_0
 G  prA_4_6_1
 G  prB_4_6_1
 G  prA_5_6_0
 G  prB_5_6_0
 G  prA_5_6_1
 G  prB_5_6_1
 G  cmax_0
 G  cmax_1
 G  cmax_2
 G  cmax_3
 G  cmax_4
 G  cmax_5
 G  cmax_6
COLUMNS
    Cmax            OBJ           1.0
    Cmax            cmax_0          1.0
    Cmax            cmax_1          1.0
    Cmax            cmax_2          1.0
    Cmax            cmax_3          1.0
    Cmax            cmax_4          1.0
    Cmax            cmax_5          1.0
    Cmax            cmax_6          1.0
    C_0             lb_0_0          1.0
    C_0             lb_0_1          1.0
    C_0             prA_0_1_0       -1.0
    C_0             prB_0_1_0       1.0
    C_0             prA_0_1_1       -1.0
    C_0             prB_0_1_1       1.0
    C_0             prA_0_2_0       -1.0
    C_0             prB_0_2_0       1.0
    C_0             prA_0_2_1       -1.0
    C_0             prB_0_2_1       1.0
    C_0             prA_0_3_0       -1.0
    C_0             prB_0_3_0       1.0
    C_0             prA_0_3_1       -1.0
    C_0             prB_0_3_1       1.0
    C_0             prA_0_4_0       -1.0
    C_0             prB_0_4_0       1.0
    C_0             prA_0_4_1       -1.0
    C_0             prB_0_4_1       1.0
    C_0             prA_0_5_0       -1.0
    C_0             prB_0_5_0       1.0
    C_0             prA_0_5_1       -1.0
    C_0             prB_0_5_1       1.0
    C_0             prA_0_6_0       -1.0
    C_0             prB_0_6_0       1.0
    C_0             prA_0_6_1       -1.0
    C_0             prB_0_6_1       1.0
    C_0             cmax_0          -1.0
    C_1             lb_1_0          1.0
    C_1             lb_1_1          1.0
    C_1             prA_0_1_0       1.0
    C_1             prB_0_1_0       -1.0
    C_1             prA_0_1_1       1.0
    C_1             prB_0_1_1       -1.0
    C_1             prA_1_2_0       -1.0
    C_1             prB_1_2_0       1.0
    C_1             prA_1_2_1       -1.0
    C_1             prB_1_2_1       1.0
    C_1             prA_1_3_0       -1.0
    C_1             prB_1_3_0       1.0
    C_1             prA_1_3_1       -1.0
    C_1             prB_1_3_1       1.0
    C_1             prA_1_4_0       -1.0
    C_1             prB_1_4_0       1.0
    C_1             prA_1_4_1       -1.0
    C_1             prB_1_4_1       1.0
    C_1             prA_1_5_0       -1.0
    C_1             prB_1_5_0       1.0
    C_1             prA_1_5_1       -1.0
    C_1             prB_1_5_1       1.0
    C_1             prA_1_6_0       -1.0
    C_1             prB_1_6_0       1.0
    C_1             prA_1_6_1       -1.0
    C_1             prB_1_6_1       1.0
    C_1             cmax_1          -1.0
    C_2             lb_2_0          1.0
    C_2             lb_2_1          1.0
    C_2             prA_0_2_0       1.0
    C_2             prB_0_2_0       -1.0
    C_2             prA_0_2_1       1.0
    C_2             prB_0_2_1       -1.0
    C_2             prA_1_2_0       1.0
    C_2             prB_1_2_0       -1.0
    C_2             prA_1_2_1       1.0
    C_2             prB_1_2_1       -1.0
    C_2             prA_2_3_0       -1.0
    C_2             prB_2_3_0       1.0
    C_2             prA_2_3_1       -1.0
    C_2             prB_2_3_1       1.0
    C_2             prA_2_4_0       -1.0
    C_2             prB_2_4_0       1.0
    C_2             prA_2_4_1       -1.0
    C_2             prB_2_4_1       1.0
    C_2             prA_2_5_0       -1.0
    C_2             prB_2_5_0       1.0
    C_2             prA_2_5_1       -1.0
    C_2             prB_2_5_1       1.0
    C_2             prA_2_6_0       -1.0
    C_2             prB_2_6_0       1.0
    C_2             prA_2_6_1       -1.0
    C_2             prB_2_6_1       1.0
    C_2             cmax_2          -1.0
    C_3             lb_3_0          1.0
    C_3             lb_3_1          1.0
    C_3             prA_0_3_0       1.0
    C_3             prB_0_3_0       -1.0
    C_3             prA_0_3_1       1.0
    C_3             prB_0_3_1       -1.0
    C_3             prA_1_3_0       1.0
    C_3             prB_1_3_0       -1.0
    C_3             prA_1_3_1       1.0
    C_3             prB_1_3_1       -1.0
    C_3             prA_2_3_0       1.0
    C_3             prB_2_3_0       -1.0
    C_3             prA_2_3_1       1.0
    C_3             prB_2_3_1       -1.0
    C_3             prA_3_4_0       -1.0
    C_3             prB_3_4_0       1.0
    C_3             prA_3_4_1       -1.0
    C_3             prB_3_4_1       1.0
    C_3             prA_3_5_0       -1.0
    C_3             prB_3_5_0       1.0
    C_3             prA_3_5_1       -1.0
    C_3             prB_3_5_1       1.0
    C_3             prA_3_6_0       -1.0
    C_3             prB_3_6_0       1.0
    C_3             prA_3_6_1       -1.0
    C_3             prB_3_6_1       1.0
    C_3             cmax_3          -1.0
    C_4             lb_4_0          1.0
    C_4             lb_4_1          1.0
    C_4             prA_0_4_0       1.0
    C_4             prB_0_4_0       -1.0
    C_4             prA_0_4_1       1.0
    C_4             prB_0_4_1       -1.0
    C_4             prA_1_4_0       1.0
    C_4             prB_1_4_0       -1.0
    C_4             prA_1_4_1       1.0
    C_4             prB_1_4_1       -1.0
    C_4             prA_2_4_0       1.0
    C_4             prB_2_4_0       -1.0
    C_4             prA_2_4_1       1.0
    C_4             prB_2_4_1       -1.0
    C_4             prA_3_4_0       1.0
    C_4             prB_3_4_0       -1.0
    C_4             prA_3_4_1       1.0
    C_4             prB_3_4_1       -1.0
    C_4             prA_4_5_0       -1.0
    C_4             prB_4_5_0       1.0
    C_4             prA_4_5_1       -1.0
    C_4             prB_4_5_1       1.0
    C_4             prA_4_6_0       -1.0
    C_4             prB_4_6_0       1.0
    C_4             prA_4_6_1       -1.0
    C_4             prB_4_6_1       1.0
    C_4             cmax_4          -1.0
    C_5             lb_5_0          1.0
    C_5             lb_5_1          1.0
    C_5             prA_0_5_0       1.0
    C_5             prB_0_5_0       -1.0
    C_5             prA_0_5_1       1.0
    C_5             prB_0_5_1       -1.0
    C_5             prA_1_5_0       1.0
    C_5             prB_1_5_0       -1.0
    C_5             prA_1_5_1       1.0
    C_5             prB_1_5_1       -1.0
    C_5             prA_2_5_0       1.0
    C_5             prB_2_5_0       -1.0
    C_5             prA_2_5_1       1.0
    C_5             prB_2_5_1       -1.0
    C_5             prA_3_5_0       1.0
    C_5             prB_3_5_0       -1.0
    C_5             prA_3_5_1       1.0
    C_5             prB_3_5_1       -1.0
    C_5             prA_4_5_0       1.0
    C_5             prB_4_5_0       -1.0
    C_5             prA_4_5_1       1.0
    C_5             prB_4_5_1       -1.0
    C_5             prA_5_6_0       -1.0
    C_5             prB_5_6_0       1.0
    C_5             prA_5_6_1       -1.0
    C_5             prB_5_6_1       1.0
    C_5             cmax_5          -1.0
    C_6             lb_6_0          1.0
    C_6             lb_6_1          1.0
    C_6             prA_0_6_0       1.0
    C_6             prB_0_6_0       -1.0
    C_6             prA_0_6_1       1.0
    C_6             prB_0_6_1       -1.0
    C_6             prA_1_6_0       1.0
    C_6             prB_1_6_0       -1.0
    C_6             prA_1_6_1       1.0
    C_6             prB_1_6_1       -1.0
    C_6             prA_2_6_0       1.0
    C_6             prB_2_6_0       -1.0
    C_6             prA_2_6_1       1.0
    C_6             prB_2_6_1       -1.0
    C_6             prA_3_6_0       1.0
    C_6             prB_3_6_0       -1.0
    C_6             prA_3_6_1       1.0
    C_6             prB_3_6_1       -1.0
    C_6             prA_4_6_0       1.0
    C_6             prB_4_6_0       -1.0
    C_6             prA_4_6_1       1.0
    C_6             prB_4_6_1       -1.0
    C_6             prA_5_6_0       1.0
    C_6             prB_5_6_0       -1.0
    C_6             prA_5_6_1       1.0
    C_6             prB_5_6_1       -1.0
    C_6             cmax_6          -1.0
    MARK0000  'MARKER'                 'INTORG'
    x_0_0           asgn_0          1.0
    x_0_0           lb_0_0          -280
    x_0_0           prA_0_1_0       -280
    x_0_0           prB_0_1_0       -280
    x_0_0           prA_0_2_0       -280
    x_0_0           prB_0_2_0       -280
    x_0_0           prA_0_3_0       -280
    x_0_0           prB_0_3_0       -280
    x_0_0           prA_0_4_0       -280
    x_0_0           prB_0_4_0       -280
    x_0_0           prA_0_5_0       -280
    x_0_0           prB_0_5_0       -280
    x_0_0           prA_0_6_0       -280
    x_0_0           prB_0_6_0       -280
    x_0_1           asgn_0          1.0
    x_0_1           lb_0_1          -280
    x_0_1           prA_0_1_1       -280
    x_0_1           prB_0_1_1       -280
    x_0_1           prA_0_2_1       -280
    x_0_1           prB_0_2_1       -280
    x_0_1           prA_0_3_1       -280
    x_0_1           prB_0_3_1       -280
    x_0_1           prA_0_4_1       -280
    x_0_1           prB_0_4_1       -280
    x_0_1           prA_0_5_1       -280
    x_0_1           prB_0_5_1       -280
    x_0_1           prA_0_6_1       -280
    x_0_1           prB_0_6_1       -280
    x_1_0           asgn_1          1.0
    x_1_0           lb_1_0          -280
    x_1_0           prA_0_1_0       -280
    x_1_0           prB_0_1_0       -280
    x_1_0           prA_1_2_0       -280
    x_1_0           prB_1_2_0       -280
    x_1_0           prA_1_3_0       -280
    x_1_0           prB_1_3_0       -280
    x_1_0           prA_1_4_0       -280
    x_1_0           prB_1_4_0       -280
    x_1_0           prA_1_5_0       -280
    x_1_0           prB_1_5_0       -280
    x_1_0           prA_1_6_0       -280
    x_1_0           prB_1_6_0       -280
    x_1_1           asgn_1          1.0
    x_1_1           lb_1_1          -280
    x_1_1           prA_0_1_1       -280
    x_1_1           prB_0_1_1       -280
    x_1_1           prA_1_2_1       -280
    x_1_1           prB_1_2_1       -280
    x_1_1           prA_1_3_1       -280
    x_1_1           prB_1_3_1       -280
    x_1_1           prA_1_4_1       -280
    x_1_1           prB_1_4_1       -280
    x_1_1           prA_1_5_1       -280
    x_1_1           prB_1_5_1       -280
    x_1_1           prA_1_6_1       -280
    x_1_1           prB_1_6_1       -280
    x_2_0           asgn_2          1.0
    x_2_0           lb_2_0          -280
    x_2_0           prA_0_2_0       -280
    x_2_0           prB_0_2_0       -280
    x_2_0           prA_1_2_0       -280
    x_2_0           prB_1_2_0       -280
    x_2_0           prA_2_3_0       -280
    x_2_0           prB_2_3_0       -280
    x_2_0           prA_2_4_0       -280
    x_2_0           prB_2_4_0       -280
    x_2_0           prA_2_5_0       -280
    x_2_0           prB_2_5_0       -280
    x_2_0           prA_2_6_0       -280
    x_2_0           prB_2_6_0       -280
    x_2_1           asgn_2          1.0
    x_2_1           lb_2_1          -280
    x_2_1           prA_0_2_1       -280
    x_2_1           prB_0_2_1       -280
    x_2_1           prA_1_2_1       -280
    x_2_1           prB_1_2_1       -280
    x_2_1           prA_2_3_1       -280
    x_2_1           prB_2_3_1       -280
    x_2_1           prA_2_4_1       -280
    x_2_1           prB_2_4_1       -280
    x_2_1           prA_2_5_1       -280
    x_2_1           prB_2_5_1       -280
    x_2_1           prA_2_6_1       -280
    x_2_1           prB_2_6_1       -280
    x_3_0           asgn_3          1.0
    x_3_0           lb_3_0          -280
    x_3_0           prA_0_3_0       -280
    x_3_0           prB_0_3_0       -280
    x_3_0           prA_1_3_0       -280
    x_3_0           prB_1_3_0       -280
    x_3_0           prA_2_3_0       -280
    x_3_0           prB_2_3_0       -280
    x_3_0           prA_3_4_0       -280
    x_3_0           prB_3_4_0       -280
    x_3_0           prA_3_5_0       -280
    x_3_0           prB_3_5_0       -280
    x_3_0           prA_3_6_0       -280
    x_3_0           prB_3_6_0       -280
    x_3_1           asgn_3          1.0
    x_3_1           lb_3_1          -280
    x_3_1           prA_0_3_1       -280
    x_3_1           prB_0_3_1       -280
    x_3_1           prA_1_3_1       -280
    x_3_1           prB_1_3_1       -280
    x_3_1           prA_2_3_1       -280
    x_3_1           prB_2_3_1       -280
    x_3_1           prA_3_4_1       -280
    x_3_1           prB_3_4_1       -280
    x_3_1           prA_3_5_1       -280
    x_3_1           prB_3_5_1       -280
    x_3_1           prA_3_6_1       -280
    x_3_1           prB_3_6_1       -280
    x_4_0           asgn_4          1.0
    x_4_0           lb_4_0          -280
    x_4_0           prA_0_4_0       -280
    x_4_0           prB_0_4_0       -280
    x_4_0           prA_1_4_0       -280
    x_4_0           prB_1_4_0       -280
    x_4_0           prA_2_4_0       -280
    x_4_0           prB_2_4_0       -280
    x_4_0           prA_3_4_0       -280
    x_4_0           prB_3_4_0       -280
    x_4_0           prA_4_5_0       -280
    x_4_0           prB_4_5_0       -280
    x_4_0           prA_4_6_0       -280
    x_4_0           prB_4_6_0       -280
    x_4_1           asgn_4          1.0
    x_4_1           lb_4_1          -280
    x_4_1           prA_0_4_1       -280
    x_4_1           prB_0_4_1       -280
    x_4_1           prA_1_4_1       -280
    x_4_1           prB_1_4_1       -280
    x_4_1           prA_2_4_1       -280
    x_4_1           prB_2_4_1       -280
    x_4_1           prA_3_4_1       -280
    x_4_1           prB_3_4_1       -280
    x_4_1           prA_4_5_1       -280
    x_4_1           prB_4_5_1       -280
    x_4_1           prA_4_6_1       -280
    x_4_1           prB_4_6_1       -280
    x_5_0           asgn_5          1.0
    x_5_0           lb_5_0          -280
    x_5_0           prA_0_5_0       -280
    x_5_0           prB_0_5_0       -280
    x_5_0           prA_1_5_0       -280
    x_5_0           prB_1_5_0       -280
    x_5_0           prA_2_5_0       -280
    x_5_0           prB_2_5_0       -280
    x_5_0           prA_3_5_0       -280
    x_5_0           prB_3_5_0       -280
    x_5_0           prA_4_5_0       -280
    x_5_0           prB_4_5_0       -280
    x_5_0           prA_5_6_0       -280
    x_5_0           prB_5_6_0       -280
    x_5_1           asgn_5          1.0
    x_5_1           lb_5_1          -280
    x_5_1           prA_0_5_1       -280
    x_5_1           prB_0_5_1       -280
    x_5_1           prA_1_5_1       -280
    x_5_1           prB_1_5_1       -280
    x_5_1           prA_2_5_1       -280
    x_5_1           prB_2_5_1       -280
    x_5_1           prA_3_5_1       -280
    x_5_1           prB_3_5_1       -280
    x_5_1           prA_4_5_1       -280
    x_5_1           prB_4_5_1       -280
    x_5_1           prA_5_6_1       -280
    x_5_1           prB_5_6_1       -280
    x_6_0           asgn_6          1.0
    x_6_0           lb_6_0          -280
    x_6_0           prA_0_6_0       -280
    x_6_0           prB_0_6_0       -280
    x_6_0           prA_1_6_0       -280
    x_6_0           prB_1_6_0       -280
    x_6_0           prA_2_6_0       -280
    x_6_0           prB_2_6_0       -280
    x_6_0           prA_3_6_0       -280
    x_6_0           prB_3_6_0       -280
    x_6_0           prA_4_6_0       -280
    x_6_0           prB_4_6_0       -280
    x_6_0           prA_5_6_0       -280
    x_6_0           prB_5_6_0       -280
    x_6_1           asgn_6          1.0
    x_6_1           lb_6_1          -280
    x_6_1           prA_0_6_1       -280
    x_6_1           prB_0_6_1       -280
    x_6_1           prA_1_6_1       -280
    x_6_1           prB_1_6_1       -280
    x_6_1           prA_2_6_1       -280
    x_6_1           prB_2_6_1       -280
    x_6_1           prA_3_6_1       -280
    x_6_1           prB_3_6_1       -280
    x_6_1           prA_4_6_1       -280
    x_6_1           prB_4_6_1       -280
    x_6_1           prA_5_6_1       -280
    x_6_1           prB_5_6_1       -280
    d_0_1_0         prA_0_1_0       -280
    d_0_1_0         prB_0_1_0       280
    d_0_1_1         prA_0_1_1       -280
    d_0_1_1         prB_0_1_1       280
    d_0_2_0         prA_0_2_0       -280
    d_0_2_0         prB_0_2_0       280
    d_0_2_1         prA_0_2_1       -280
    d_0_2_1         prB_0_2_1       280
    d_0_3_0         prA_0_3_0       -280
    d_0_3_0         prB_0_3_0       280
    d_0_3_1         prA_0_3_1       -280
    d_0_3_1         prB_0_3_1       280
    d_0_4_0         prA_0_4_0       -280
    d_0_4_0         prB_0_4_0       280
    d_0_4_1         prA_0_4_1       -280
    d_0_4_1         prB_0_4_1       280
    d_0_5_0         prA_0_5_0       -280
    d_0_5_0         prB_0_5_0       280
    d_0_5_1         prA_0_5_1       -280
    d_0_5_1         prB_0_5_1       280
    d_0_6_0         prA_0_6_0       -280
    d_0_6_0         prB_0_6_0       280
    d_0_6_1         prA_0_6_1       -280
    d_0_6_1         prB_0_6_1       280
    d_1_2_0         prA_1_2_0       -280
    d_1_2_0         prB_1_2_0       280
    d_1_2_1         prA_1_2_1       -280
    d_1_2_1         prB_1_2_1       280
    d_1_3_0         prA_1_3_0       -280
    d_1_3_0         prB_1_3_0       280
    d_1_3_1         prA_1_3_1       -280
    d_1_3_1         prB_1_3_1       280
    d_1_4_0         prA_1_4_0       -280
    d_1_4_0         prB_1_4_0       280
    d_1_4_1         prA_1_4_1       -280
    d_1_4_1         prB_1_4_1       280
    d_1_5_0         prA_1_5_0       -280
    d_1_5_0         prB_1_5_0       280
    d_1_5_1         prA_1_5_1       -280
    d_1_5_1         prB_1_5_1       280
    d_1_6_0         prA_1_6_0       -280
    d_1_6_0         prB_1_6_0       280
    d_1_6_1         prA_1_6_1       -280
    d_1_6_1         prB_1_6_1       280
    d_2_3_0         prA_2_3_0       -280
    d_2_3_0         prB_2_3_0       280
    d_2_3_1         prA_2_3_1       -280
    d_2_3_1         prB_2_3_1       280
    d_2_4_0         prA_2_4_0       -280
    d_2_4_0         prB_2_4_0       280
    d_2_4_1         prA_2_4_1       -280
    d_2_4_1         prB_2_4_1       280
    d_2_5_0         prA_2_5_0       -280
    d_2_5_0         prB_2_5_0       280
    d_2_5_1         prA_2_5_1       -280
    d_2_5_1         prB_2_5_1       280
    d_2_6_0         prA_2_6_0       -280
    d_2_6_0         prB_2_6_0       280
    d_2_6_1         prA_2_6_1       -280
    d_2_6_1         prB_2_6_1       280
    d_3_4_0         prA_3_4_0       -280
    d_3_4_0         prB_3_4_0       280
    d_3_4_1         prA_3_4_1       -280
    d_3_4_1         prB_3_4_1       280
    d_3_5_0         prA_3_5_0       -280
    d_3_5_0         prB_3_5_0       280
    d_3_5_1         prA_3_5_1       -280
    d_3_5_1         prB_3_5_1       280
    d_3_6_0         prA_3_6_0       -280
    d_3_6_0         prB_3_6_0       280
    d_3_6_1         prA_3_6_1       -280
    d_3_6_1         prB_3_6_1       280
    d_4_5_0         prA_4_5_0       -280
    d_4_5_0         prB_4_5_0       280
    d_4_5_1         prA_4_5_1       -280
    d_4_5_1         prB_4_5_1       280
    d_4_6_0         prA_4_6_0       -280
    d_4_6_0         prB_4_6_0       280
    d_4_6_1         prA_4_6_1       -280
    d_4_6_1         prB_4_6_1       280
    d_5_6_0         prA_5_6_0       -280
    d_5_6_0         prB_5_6_0       280
    d_5_6_1         prA_5_6_1       -280
    d_5_6_1         prB_5_6_1       280
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           asgn_0          1.0
    RHS           asgn_1          1.0
    RHS           asgn_2          1.0
    RHS           asgn_3          1.0
    RHS           asgn_4          1.0
    RHS           asgn_5          1.0
    RHS           asgn_6          1.0
    RHS           lb_0_0          -270
    RHS           lb_0_1          -269
    RHS           lb_1_0          -262
    RHS           lb_1_1          -269
    RHS           lb_2_0          -262
    RHS           lb_2_1          -271
    RHS           lb_3_0          -262
    RHS           lb_3_1          -262
    RHS           lb_4_0          -268
    RHS           lb_4_1          -263
    RHS           lb_5_0          -262
    RHS           lb_5_1          -263
    RHS           lb_6_0          -262
    RHS           lb_6_1          -273
    RHS           prA_0_1_0       -806
    RHS           prB_0_1_0       -530
    RHS           prA_0_1_1       -813
    RHS           prB_0_1_1       -529
    RHS           prA_0_2_0       -811
    RHS           prB_0_2_0       -533
    RHS           prA_0_2_1       -811
    RHS           prB_0_2_1       -534
    RHS           prA_0_3_0       -814
    RHS           prB_0_3_0       -531
    RHS           prA_0_3_1       -814
    RHS           prB_0_3_1       -528
    RHS           prA_0_4_0       -815
    RHS           prB_0_4_0       -536
    RHS           prA_0_4_1       -801
    RHS           prB_0_4_1       -534
    RHS           prA_0_5_0       -805
    RHS           prB_0_5_0       -539
    RHS           prA_0_5_1       -809
    RHS           prB_0_5_1       -538
    RHS           prA_0_6_0       -813
    RHS           prB_0_6_0       -541
    RHS           prA_0_6_1       -823
    RHS           prB_0_6_1       -533
    RHS           prA_1_2_0       -811
    RHS           prB_1_2_0       -534
    RHS           prA_1_2_1       -809
    RHS           prB_1_2_1       -536
    RHS           prA_1_3_0       -811
    RHS           prB_1_3_0       -533
    RHS           prA_1_3_1       -803
    RHS           prB_1_3_1       -540
    RHS           prA_1_4_0       -820
    RHS           prB_1_4_0       -532
    RHS           prA_1_4_1       -809
    RHS           prB_1_4_1       -539
    RHS           prA_1_5_0       -803
    RHS           prB_1_5_0       -524
    RHS           prA_1_5_1       -803
    RHS           prB_1_5_1       -529
    RHS           prA_1_6_0       -800
    RHS           prB_1_6_0       -527
    RHS           prA_1_6_1       -819
    RHS           prB_1_6_1       -533
    RHS           prA_2_3_0       -806
    RHS           prB_2_3_0       -522
    RHS           prA_2_3_1       -807
    RHS           prB_2_3_1       -529
    RHS           prA_2_4_0       -809
    RHS           prB_2_4_0       -524
    RHS           prA_2_4_1       -814
    RHS           prB_2_4_1       -543
    RHS           prA_2_5_0       -804
    RHS           prB_2_5_0       -520
    RHS           prA_2_5_1       -810
    RHS           prB_2_5_1       -533
    RHS           prA_2_6_0       -814
    RHS           prB_2_6_0       -521
    RHS           prA_2_6_1       -823
    RHS           prB_2_6_1       -537
    RHS           prA_3_4_0       -820
    RHS           prB_3_4_0       -527
    RHS           prA_3_4_1       -808
    RHS           prB_3_4_1       -521
    RHS           prA_3_5_0       -812
    RHS           prB_3_5_0       -522
    RHS           prA_3_5_1       -807
    RHS           prB_3_5_1       -522
    RHS           prA_3_6_0       -803
    RHS           prB_3_6_0       -531
    RHS           prA_3_6_1       -820
    RHS           prB_3_6_1       -529
    RHS           prA_4_5_0       -801
    RHS           prB_4_5_0       -526
    RHS           prA_4_5_1       -812
    RHS           prB_4_5_1       -526
    RHS           prA_4_6_0       -813
    RHS           prB_4_6_0       -526
    RHS           prA_4_6_1       -813
    RHS           prB_4_6_1       -533
    RHS           prA_5_6_0       -803
    RHS           prB_5_6_0       -520
    RHS           prA_5_6_1       -824
    RHS           prB_5_6_1       -527
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_0_1
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         d_0_1_0
 BV BOUND         d_0_1_1
 BV BOUND         d_0_2_0
 BV BOUND         d_0_2_1
 BV BOUND         d_0_3_0
 BV BOUND         d_0_3_1
 BV BOUND         d_0_4_0
 BV BOUND         d_0_4_1
 BV BOUND         d_0_5_0
 BV BOUND         d_0_5_1
 BV BOUND         d_0_6_0
 BV BOUND         d_0_6_1
 BV BOUND         d_1_2_0
 BV BOUND         d_1_2_1
 BV BOUND         d_1_3_0
 BV BOUND         d_1_3_1
 BV BOUND         d_1_4_0
 BV BOUND         d_1_4_1
 BV BOUND         d_1_5_0
 BV BOUND         d_1_5_1
 BV BOUND         d_1_6_0
 BV BOUND         d_1_6_1
 BV BOUND         d_2_3_0
 BV BOUND         d_2_3_1
 BV BOUND         d_2_4_0
 BV BOUND         d_2_4_1
 BV BOUND         d_2_5_0
 BV BOUND         d_2_5_1
 BV BOUND         d_2_6_0
 BV BOUND         d_2_6_1
 BV BOUND         d_3_4_0
 BV BOUND         d_3_4_1
 BV BOUND         d_3_5_0
 BV BOUND         d_3_5_1
 BV BOUND         d_3_6_0
 BV BOUND         d_3_6_1
 BV BOUND         d_4_5_0
 BV BOUND         d_4_5_1
 BV BOUND         d_4_6_0
 BV BOUND         d_4_6_1
 BV BOUND         d_5_6_0
 BV BOUND         d_5_6_1
ENDATA
