NAME          hcnd_tiny_capforce
ROWS
 N  OBJ
 L  CAP_0_1
 L  CAP_1_2
 L  CAP_0_2
 E  SUP_0
 E  DEM_0
 E  CONS_0_1_1
 E  CONS_0_0_1
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_1           OBJ           5
    y_0_1           CAP_0_1         -3.0
    y_1_2           OBJ           5
    y_1_2           CAP_1_2         -3.0
    y_0_2           OBJ           20
    y_0_2           CAP_0_2         -10.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_0_1_0       CAP_0_1         1.0
    f_0_0_1_0       SUP_0           1.0
    f_0_0_1_0       CONS_0_1_1      -1.0
    f_0_0_2_0       CAP_0_2         1.0
    f_0_0_2_0       SUP_0           1.0
    f_0_0_2_0       DEM_0           1.0
    f_0_1_2_1       CAP_1_2         1.0
    f_0_1_2_1       CONS_0_1_1      1.0
    f_0_1_2_1       DEM_0           1.0
    f_0_0_2_1       CAP_0_2         1.0
    f_0_0_2_1       CONS_0_0_1      1.0
    f_0_0_2_1       DEM_0           1.0
RHS
    RHS           SUP_0           5.0
    RHS           DEM_0           5.0
BOUNDS
 BV BOUND         y_0_1
 BV BOUND         y_1_2
 BV BOUND         y_0_2
 UP BOUND         f_0_0_1_0       3.0
 UP BOUND         f_0_0_2_0       5.0
 UP BOUND         f_0_1_2_1       3.0
 UP BOUND         f_0_0_2_1       5.0
ENDATA
