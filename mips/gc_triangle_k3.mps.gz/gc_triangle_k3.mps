NAME          gc_triangle_k3
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 L  LINK_1_0
 L  LINK_2_0
 L  LINK_2_1
 L  EDGE_0_1_0
 L  EDGE_0_2_0
 L  EDGE_1_2_0
 L  EDGE_1_2_1
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_0           OBJ           1.0
    x_0_0           ASSIGN_0        1.0
    x_0_0           LINK_1_0        -1.0
    x_0_0           LINK_2_0        -1.0
    x_0_0           EDGE_0_1_0      1.0
    x_0_0           EDGE_0_2_0      1.0
    x_0_0           EDGE_1_2_0      -1.0
    x_1_0           ASSIGN_1        1.0
    x_1_0           LINK_1_0        1.0
    x_1_0           EDGE_0_1_0      1.0
    x_1_0           EDGE_1_2_0      1.0
    x_1_1           OBJ           1.0
    x_1_1           ASSIGN_1        1.0
    x_1_1           LINK_2_1        -1.0
    x_1_1           EDGE_1_2_1      1.0
    x_2_0           ASSIGN_2        1.0
    x_2_0           LINK_2_0        1.0
    x_2_0           EDGE_0_2_0      1.0
    x_2_0           EDGE_1_2_0      1.0
    x_2_1           ASSIGN_2        1.0
    x_2_1           LINK_2_1        1.0
    x_2_1           EDGE_1_2_1      1.0
    x_2_2           OBJ           1.0
    x_2_2           ASSIGN_2        1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           ASSIGN_0        1.0
    RHS           ASSIGN_1        1.0
    RHS           ASSIGN_2        1.0
    RHS           EDGE_0_1_0      1.0
    RHS           EDGE_0_2_0      1.0
    RHS           EDGE_1_2_1      1.0
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_2
ENDATA
