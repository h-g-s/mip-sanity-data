NAME          cvrp_search_n12_k2_varied_uniform
ROWS
 N  OBJ
 E  OUT1
 E  IN1
 E  FLOW1
 E  OUT2
 E  IN2
 E  FLOW2
 E  OUT3
 E  IN3
 E  FLOW3
 E  OUT4
 E  IN4
 E  FLOW4
 E  OUT5
 E  IN5
 E  FLOW5
 E  OUT6
 E  IN6
 E  FLOW6
 E  OUT7
 E  IN7
 E  FLOW7
 E  OUT8
 E  IN8
 E  FLOW8
 E  OUT9
 E  IN9
 E  FLOW9
 E  OUT10
 E  IN10
 E  FLOW10
 E  OUT11
 E  IN11
 E  FLOW11
 E  OUT12
 E  IN12
 E  FLOW12
 L  FLEET
 L  CAP0
 L  CAP1
 L  CAP2
 L  CAP3
 L  CAP4
 L  CAP5
 L  CAP6
 L  CAP7
 L  CAP8
 L  CAP9
 L  CAP10
 L  CAP11
 L  CAP12
 L  CAP13
 L  CAP14
 L  CAP15
 L  CAP16
 L  CAP17
 L  CAP18
 L  CAP19
 L  CAP20
 L  CAP21
 L  CAP22
 L  CAP23
 L  CAP24
 L  CAP25
 L  CAP26
 L  CAP27
 L  CAP28
 L  CAP29
 L  CAP30
 L  CAP31
 L  CAP32
 L  CAP33
 L  CAP34
 L  CAP35
 L  CAP36
 L  CAP37
 L  CAP38
 L  CAP39
 L  CAP40
 L  CAP41
 L  CAP42
 L  CAP43
 L  CAP44
 L  CAP45
 L  CAP46
 L  CAP47
 L  CAP48
 L  CAP49
 L  CAP50
 L  CAP51
 L  CAP52
 L  CAP53
 L  CAP54
 L  CAP55
 L  CAP56
 L  CAP57
 L  CAP58
 L  CAP59
 L  CAP60
 L  CAP61
 L  CAP62
 L  CAP63
 L  CAP64
 L  CAP65
 L  CAP66
 L  CAP67
 L  CAP68
 L  CAP69
 L  CAP70
 L  CAP71
 L  CAP72
 L  CAP73
 L  CAP74
 L  CAP75
 L  CAP76
 L  CAP77
 L  CAP78
 L  CAP79
 L  CAP80
 L  CAP81
 L  CAP82
 L  CAP83
 L  CAP84
 L  CAP85
 L  CAP86
 L  CAP87
 L  CAP88
 L  CAP89
 L  CAP90
 L  CAP91
 L  CAP92
 L  CAP93
 L  CAP94
 L  CAP95
 L  CAP96
 L  CAP97
 L  CAP98
 L  CAP99
 L  CAP100
 L  CAP101
 L  CAP102
 L  CAP103
 L  CAP104
 L  CAP105
 L  CAP106
 L  CAP107
 L  CAP108
 L  CAP109
 L  CAP110
 L  CAP111
 L  CAP112
 L  CAP113
 L  CAP114
 L  CAP115
 L  CAP116
 L  CAP117
 L  CAP118
 L  CAP119
 L  CAP120
 L  CAP121
 L  CAP122
 L  CAP123
 L  CAP124
 L  CAP125
 L  CAP126
 L  CAP127
 L  CAP128
 L  CAP129
 L  CAP130
 L  CAP131
 L  CAP132
 L  CAP133
 L  CAP134
 L  CAP135
 L  CAP136
 L  CAP137
 L  CAP138
 L  CAP139
 L  CAP140
 L  CAP141
 L  CAP142
 L  CAP143
 G  DLBO1
 L  DUBO1
 G  DLBO2
 L  DUBO2
 G  DLBO3
 L  DUBO3
 G  DLBO4
 L  DUBO4
 G  DLBO5
 L  DUBO5
 G  DLBO6
 L  DUBO6
 G  DLBO7
 L  DUBO7
 G  DLBO8
 L  DUBO8
 G  DLBO9
 L  DUBO9
 G  DLBO10
 L  DUBO10
 G  DLBO11
 L  DUBO11
 G  DLBO12
 L  DUBO12
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0_1          OBJ       41.48
    x0_1          IN1      1
    x0_1          FLOW1   -1
    x0_1          FLEET      1
    x0_1          CAP0    34
    x0_2          OBJ       65.89
    x0_2          IN2      1
    x0_2          FLOW2   -1
    x0_2          FLEET      1
    x0_2          CAP1    34
    x0_3          OBJ       26.02
    x0_3          IN3      1
    x0_3          FLOW3   -1
    x0_3          FLEET      1
    x0_3          CAP2    34
    x0_4          OBJ       21.76
    x0_4          IN4      1
    x0_4          FLOW4   -1
    x0_4          FLEET      1
    x0_4          CAP3    34
    x0_5          OBJ       63.86
    x0_5          IN5      1
    x0_5          FLOW5   -1
    x0_5          FLEET      1
    x0_5          CAP4    34
    x0_6          OBJ       63.71
    x0_6          IN6      1
    x0_6          FLOW6   -1
    x0_6          FLEET      1
    x0_6          CAP5    34
    x0_7          OBJ       52.00
    x0_7          IN7      1
    x0_7          FLOW7   -1
    x0_7          FLEET      1
    x0_7          CAP6    34
    x0_8          OBJ       70.28
    x0_8          IN8      1
    x0_8          FLOW8   -1
    x0_8          FLEET      1
    x0_8          CAP7    34
    x0_9          OBJ       17.10
    x0_9          IN9      1
    x0_9          FLOW9   -1
    x0_9          FLEET      1
    x0_9          CAP8    34
    x0_10         OBJ       69.34
    x0_10         IN10      1
    x0_10         FLOW10   -1
    x0_10         FLEET      1
    x0_10         CAP9    34
    x0_11         OBJ       32.64
    x0_11         IN11      1
    x0_11         FLOW11   -1
    x0_11         FLEET      1
    x0_11         CAP10    34
    x0_12         OBJ       44.51
    x0_12         IN12      1
    x0_12         FLOW12   -1
    x0_12         FLEET      1
    x0_12         CAP11    34
    x1_0          OBJ       41.48
    x1_0          OUT1     1
    x1_0          FLOW1    1
    x1_2          OBJ       64.70
    x1_2          OUT1     1
    x1_2          IN2      1
    x1_2          FLOW1    1
    x1_2          FLOW2   -1
    x1_2          CAP12    34
    x1_3          OBJ       63.20
    x1_3          OUT1     1
    x1_3          IN3      1
    x1_3          FLOW1    1
    x1_3          FLOW3   -1
    x1_3          CAP13    34
    x1_4          OBJ       24.29
    x1_4          OUT1     1
    x1_4          IN4      1
    x1_4          FLOW1    1
    x1_4          FLOW4   -1
    x1_4          CAP14    34
    x1_5          OBJ       28.77
    x1_5          OUT1     1
    x1_5          IN5      1
    x1_5          FLOW1    1
    x1_5          FLOW5   -1
    x1_5          CAP15    34
    x1_6          OBJ       24.97
    x1_6          OUT1     1
    x1_6          IN6      1
    x1_6          FLOW1    1
    x1_6          FLOW6   -1
    x1_6          CAP16    34
    x1_7          OBJ       49.40
    x1_7          OUT1     1
    x1_7          IN7      1
    x1_7          FLOW1    1
    x1_7          FLOW7   -1
    x1_7          CAP17    34
    x1_8          OBJ       37.01
    x1_8          OUT1     1
    x1_8          IN8      1
    x1_8          FLOW1    1
    x1_8          FLOW8   -1
    x1_8          CAP18    34
    x1_9          OBJ       57.67
    x1_9          OUT1     1
    x1_9          IN9      1
    x1_9          FLOW1    1
    x1_9          FLOW9   -1
    x1_9          CAP19    34
    x1_10         OBJ       71.22
    x1_10         OUT1     1
    x1_10         IN10      1
    x1_10         FLOW1    1
    x1_10         FLOW10   -1
    x1_10         CAP20    34
    x1_11         OBJ       9.40
    x1_11         OUT1     1
    x1_11         IN11      1
    x1_11         FLOW1    1
    x1_11         FLOW11   -1
    x1_11         CAP21    34
    x1_12         OBJ       69.15
    x1_12         OUT1     1
    x1_12         IN12      1
    x1_12         FLOW1    1
    x1_12         FLOW12   -1
    x1_12         CAP22    34
    x2_0          OBJ       65.89
    x2_0          OUT2     1
    x2_0          FLOW2    1
    x2_1          OBJ       64.70
    x2_1          OUT2     1
    x2_1          IN1      1
    x2_1          FLOW2    1
    x2_1          FLOW1   -1
    x2_1          CAP23    34
    x2_3          OBJ       61.00
    x2_3          OUT2     1
    x2_3          IN3      1
    x2_3          FLOW2    1
    x2_3          FLOW3   -1
    x2_3          CAP24    34
    x2_4          OBJ       71.93
    x2_4          OUT2     1
    x2_4          IN4      1
    x2_4          FLOW2    1
    x2_4          FLOW4   -1
    x2_4          CAP25    34
    x2_5          OBJ       54.54
    x2_5          OUT2     1
    x2_5          IN5      1
    x2_5          FLOW2    1
    x2_5          FLOW5   -1
    x2_5          CAP26    34
    x2_6          OBJ       85.58
    x2_6          OUT2     1
    x2_6          IN6      1
    x2_6          FLOW2    1
    x2_6          FLOW6   -1
    x2_6          CAP27    34
    x2_7          OBJ       15.77
    x2_7          OUT2     1
    x2_7          IN7      1
    x2_7          FLOW2    1
    x2_7          FLOW7   -1
    x2_7          CAP28    34
    x2_8          OBJ       52.34
    x2_8          OUT2     1
    x2_8          IN8      1
    x2_8          FLOW2    1
    x2_8          FLOW8   -1
    x2_8          CAP29    34
    x2_9          OBJ       67.42
    x2_9          OUT2     1
    x2_9          IN9      1
    x2_9          FLOW2    1
    x2_9          FLOW9   -1
    x2_9          CAP30    34
    x2_10         OBJ       7.26
    x2_10         OUT2     1
    x2_10         IN10      1
    x2_10         FLOW2    1
    x2_10         FLOW10   -1
    x2_10         CAP31    34
    x2_11         OBJ       65.47
    x2_11         OUT2     1
    x2_11         IN11      1
    x2_11         FLOW2    1
    x2_11         FLOW11   -1
    x2_11         CAP32    34
    x2_12         OBJ       40.55
    x2_12         OUT2     1
    x2_12         IN12      1
    x2_12         FLOW2    1
    x2_12         FLOW12   -1
    x2_12         CAP33    34
    x3_0          OBJ       26.02
    x3_0          OUT3     1
    x3_0          FLOW3    1
    x3_1          OBJ       63.20
    x3_1          OUT3     1
    x3_1          IN1      1
    x3_1          FLOW3    1
    x3_1          FLOW1   -1
    x3_1          CAP34    34
    x3_2          OBJ       61.00
    x3_2          OUT3     1
    x3_2          IN2      1
    x3_2          FLOW3    1
    x3_2          FLOW2   -1
    x3_2          CAP35    34
    x3_4          OBJ       47.37
    x3_4          OUT3     1
    x3_4          IN4      1
    x3_4          FLOW3    1
    x3_4          FLOW4   -1
    x3_4          CAP36    34
    x3_5          OBJ       79.29
    x3_5          OUT3     1
    x3_5          IN5      1
    x3_5          FLOW3    1
    x3_5          FLOW5   -1
    x3_5          CAP37    34
    x3_6          OBJ       87.28
    x3_6          OUT3     1
    x3_6          IN6      1
    x3_6          FLOW3    1
    x3_6          FLOW6   -1
    x3_6          CAP38    34
    x3_7          OBJ       51.81
    x3_7          OUT3     1
    x3_7          IN7      1
    x3_7          FLOW3    1
    x3_7          FLOW7   -1
    x3_7          CAP39    34
    x3_8          OBJ       83.88
    x3_8          OUT3     1
    x3_8          IN8      1
    x3_8          FLOW3    1
    x3_8          FLOW8   -1
    x3_8          CAP40    34
    x3_9          OBJ       11.54
    x3_9          OUT3     1
    x3_9          IN9      1
    x3_9          FLOW3    1
    x3_9          FLOW9   -1
    x3_9          CAP41    34
    x3_10         OBJ       61.73
    x3_10         OUT3     1
    x3_10         IN10      1
    x3_10         FLOW3    1
    x3_10         FLOW10   -1
    x3_10         CAP42    34
    x3_11         OBJ       55.62
    x3_11         OUT3     1
    x3_11         IN11      1
    x3_11         FLOW3    1
    x3_11         FLOW11   -1
    x3_11         CAP43    34
    x3_12         OBJ       25.80
    x3_12         OUT3     1
    x3_12         IN12      1
    x3_12         FLOW3    1
    x3_12         FLOW12   -1
    x3_12         CAP44    34
    x4_0          OBJ       21.76
    x4_0          OUT4     1
    x4_0          FLOW4    1
    x4_1          OBJ       24.29
    x4_1          OUT4     1
    x4_1          IN1      1
    x4_1          FLOW4    1
    x4_1          FLOW1   -1
    x4_1          CAP45    34
    x4_2          OBJ       71.93
    x4_2          OUT4     1
    x4_2          IN2      1
    x4_2          FLOW4    1
    x4_2          FLOW2   -1
    x4_2          CAP46    34
    x4_3          OBJ       47.37
    x4_3          OUT4     1
    x4_3          IN3      1
    x4_3          FLOW4    1
    x4_3          FLOW3   -1
    x4_3          CAP47    34
    x4_5          OBJ       51.72
    x4_5          OUT4     1
    x4_5          IN5      1
    x4_5          FLOW4    1
    x4_5          FLOW5   -1
    x4_5          CAP48    34
    x4_6          OBJ       43.00
    x4_6          OUT4     1
    x4_6          IN6      1
    x4_6          FLOW4    1
    x4_6          FLOW6   -1
    x4_6          CAP49    34
    x4_7          OBJ       56.33
    x4_7          OUT4     1
    x4_7          IN7      1
    x4_7          FLOW4    1
    x4_7          FLOW7   -1
    x4_7          CAP50    34
    x4_8          OBJ       59.46
    x4_8          OUT4     1
    x4_8          IN8      1
    x4_8          FLOW4    1
    x4_8          FLOW8   -1
    x4_8          CAP51    34
    x4_9          OBJ       38.82
    x4_9          OUT4     1
    x4_9          IN9      1
    x4_9          FLOW4    1
    x4_9          FLOW9   -1
    x4_9          CAP52    34
    x4_10         OBJ       77.08
    x4_10         OUT4     1
    x4_10         IN10      1
    x4_10         FLOW4    1
    x4_10         FLOW10   -1
    x4_10         CAP53    34
    x4_11         OBJ       14.99
    x4_11         OUT4     1
    x4_11         IN11      1
    x4_11         FLOW4    1
    x4_11         FLOW11   -1
    x4_11         CAP54    34
    x4_12         OBJ       61.70
    x4_12         OUT4     1
    x4_12         IN12      1
    x4_12         FLOW4    1
    x4_12         FLOW12   -1
    x4_12         CAP55    34
    x5_0          OBJ       63.86
    x5_0          OUT5     1
    x5_0          FLOW5    1
    x5_1          OBJ       28.77
    x5_1          OUT5     1
    x5_1          IN1      1
    x5_1          FLOW5    1
    x5_1          FLOW1   -1
    x5_1          CAP56    34
    x5_2          OBJ       54.54
    x5_2          OUT5     1
    x5_2          IN2      1
    x5_2          FLOW5    1
    x5_2          FLOW2   -1
    x5_2          CAP57    34
    x5_3          OBJ       79.29
    x5_3          OUT5     1
    x5_3          IN3      1
    x5_3          FLOW5    1
    x5_3          FLOW3   -1
    x5_3          CAP58    34
    x5_4          OBJ       51.72
    x5_4          OUT5     1
    x5_4          IN4      1
    x5_4          FLOW5    1
    x5_4          FLOW4   -1
    x5_4          CAP59    34
    x5_6          OBJ       36.17
    x5_6          OUT5     1
    x5_6          IN6      1
    x5_6          FLOW5    1
    x5_6          FLOW6   -1
    x5_6          CAP60    34
    x5_7          OBJ       43.31
    x5_7          OUT5     1
    x5_7          IN7      1
    x5_7          FLOW5    1
    x5_7          FLOW7   -1
    x5_7          CAP61    34
    x5_8          OBJ       8.39
    x5_8          OUT5     1
    x5_8          IN8      1
    x5_8          FLOW5    1
    x5_8          FLOW8   -1
    x5_8          CAP62    34
    x5_9          OBJ       77.32
    x5_9          OUT5     1
    x5_9          IN9      1
    x5_9          FLOW5    1
    x5_9          FLOW9   -1
    x5_9          CAP63    34
    x5_10         OBJ       61.80
    x5_10         OUT5     1
    x5_10         IN10      1
    x5_10         FLOW5    1
    x5_10         FLOW10   -1
    x5_10         CAP64    34
    x5_11         OBJ       37.04
    x5_11         OUT5     1
    x5_11         IN11      1
    x5_11         FLOW5    1
    x5_11         FLOW11   -1
    x5_11         CAP65    34
    x5_12         OBJ       75.76
    x5_12         OUT5     1
    x5_12         IN12      1
    x5_12         FLOW5    1
    x5_12         FLOW12   -1
    x5_12         CAP66    34
    x6_0          OBJ       63.71
    x6_0          OUT6     1
    x6_0          FLOW6    1
    x6_1          OBJ       24.97
    x6_1          OUT6     1
    x6_1          IN1      1
    x6_1          FLOW6    1
    x6_1          FLOW1   -1
    x6_1          CAP67    34
    x6_2          OBJ       85.58
    x6_2          OUT6     1
    x6_2          IN2      1
    x6_2          FLOW6    1
    x6_2          FLOW2   -1
    x6_2          CAP68    34
    x6_3          OBJ       87.28
    x6_3          OUT6     1
    x6_3          IN3      1
    x6_3          FLOW6    1
    x6_3          FLOW3   -1
    x6_3          CAP69    34
    x6_4          OBJ       43.00
    x6_4          OUT6     1
    x6_4          IN4      1
    x6_4          FLOW6    1
    x6_4          FLOW4   -1
    x6_4          CAP70    34
    x6_5          OBJ       36.17
    x6_5          OUT6     1
    x6_5          IN5      1
    x6_5          FLOW6    1
    x6_5          FLOW5   -1
    x6_5          CAP71    34
    x6_7          OBJ       71.30
    x6_7          OUT6     1
    x6_7          IN7      1
    x6_7          FLOW6    1
    x6_7          FLOW7   -1
    x6_7          CAP72    34
    x6_8          OBJ       43.59
    x6_8          OUT6     1
    x6_8          IN8      1
    x6_8          FLOW6    1
    x6_8          FLOW8   -1
    x6_8          CAP73    34
    x6_9          OBJ       80.62
    x6_9          OUT6     1
    x6_9          IN9      1
    x6_9          FLOW6    1
    x6_9          FLOW9   -1
    x6_9          CAP74    34
    x6_10         OBJ       92.55
    x6_10         OUT6     1
    x6_10         IN10      1
    x6_10         FLOW6    1
    x6_10         FLOW10   -1
    x6_10         CAP75    34
    x6_11         OBJ       31.67
    x6_11         OUT6     1
    x6_11         IN11      1
    x6_11         FLOW6    1
    x6_11         FLOW11   -1
    x6_11         CAP76    34
    x6_12         OBJ       94.08
    x6_12         OUT6     1
    x6_12         IN12      1
    x6_12         FLOW6    1
    x6_12         FLOW12   -1
    x6_12         CAP77    34
    x7_0          OBJ       52.00
    x7_0          OUT7     1
    x7_0          FLOW7    1
    x7_1          OBJ       49.40
    x7_1          OUT7     1
    x7_1          IN1      1
    x7_1          FLOW7    1
    x7_1          FLOW1   -1
    x7_1          CAP78    34
    x7_2          OBJ       15.77
    x7_2          OUT7     1
    x7_2          IN2      1
    x7_2          FLOW7    1
    x7_2          FLOW2   -1
    x7_2          CAP79    34
    x7_3          OBJ       51.81
    x7_3          OUT7     1
    x7_3          IN3      1
    x7_3          FLOW7    1
    x7_3          FLOW3   -1
    x7_3          CAP80    34
    x7_4          OBJ       56.33
    x7_4          OUT7     1
    x7_4          IN4      1
    x7_4          FLOW7    1
    x7_4          FLOW4   -1
    x7_4          CAP81    34
    x7_5          OBJ       43.31
    x7_5          OUT7     1
    x7_5          IN5      1
    x7_5          FLOW7    1
    x7_5          FLOW5   -1
    x7_5          CAP82    34
    x7_6          OBJ       71.30
    x7_6          OUT7     1
    x7_6          IN6      1
    x7_6          FLOW7    1
    x7_6          FLOW6   -1
    x7_6          CAP83    34
    x7_8          OBJ       43.17
    x7_8          OUT7     1
    x7_8          IN8      1
    x7_8          FLOW7    1
    x7_8          FLOW8   -1
    x7_8          CAP84    34
    x7_9          OBJ       56.16
    x7_9          OUT7     1
    x7_9          IN9      1
    x7_9          FLOW7    1
    x7_9          FLOW9   -1
    x7_9          CAP85    34
    x7_10         OBJ       21.86
    x7_10         OUT7     1
    x7_10         IN10      1
    x7_10         FLOW7    1
    x7_10         FLOW10   -1
    x7_10         CAP86    34
    x7_11         OBJ       49.75
    x7_11         OUT7     1
    x7_11         IN11      1
    x7_11         FLOW7    1
    x7_11         FLOW11   -1
    x7_11         CAP87    34
    x7_12         OBJ       37.13
    x7_12         OUT7     1
    x7_12         IN12      1
    x7_12         FLOW7    1
    x7_12         FLOW12   -1
    x7_12         CAP88    34
    x8_0          OBJ       70.28
    x8_0          OUT8     1
    x8_0          FLOW8    1
    x8_1          OBJ       37.01
    x8_1          OUT8     1
    x8_1          IN1      1
    x8_1          FLOW8    1
    x8_1          FLOW1   -1
    x8_1          CAP89    34
    x8_2          OBJ       52.34
    x8_2          OUT8     1
    x8_2          IN2      1
    x8_2          FLOW8    1
    x8_2          FLOW2   -1
    x8_2          CAP90    34
    x8_3          OBJ       83.88
    x8_3          OUT8     1
    x8_3          IN3      1
    x8_3          FLOW8    1
    x8_3          FLOW3   -1
    x8_3          CAP91    34
    x8_4          OBJ       59.46
    x8_4          OUT8     1
    x8_4          IN4      1
    x8_4          FLOW8    1
    x8_4          FLOW4   -1
    x8_4          CAP92    34
    x8_5          OBJ       8.39
    x8_5          OUT8     1
    x8_5          IN5      1
    x8_5          FLOW8    1
    x8_5          FLOW5   -1
    x8_5          CAP93    34
    x8_6          OBJ       43.59
    x8_6          OUT8     1
    x8_6          IN6      1
    x8_6          FLOW8    1
    x8_6          FLOW6   -1
    x8_6          CAP94    34
    x8_7          OBJ       43.17
    x8_7          OUT8     1
    x8_7          IN7      1
    x8_7          FLOW8    1
    x8_7          FLOW7   -1
    x8_7          CAP95    34
    x8_9          OBJ       82.86
    x8_9          OUT8     1
    x8_9          IN9      1
    x8_9          FLOW8    1
    x8_9          FLOW9   -1
    x8_9          CAP96    34
    x8_10         OBJ       59.54
    x8_10         OUT8     1
    x8_10         IN10      1
    x8_10         FLOW8    1
    x8_10         FLOW10   -1
    x8_10         CAP97    34
    x8_11         OBJ       45.00
    x8_11         OUT8     1
    x8_11         IN11      1
    x8_11         FLOW8    1
    x8_11         FLOW11   -1
    x8_11         CAP98    34
    x8_12         OBJ       77.89
    x8_12         OUT8     1
    x8_12         IN12      1
    x8_12         FLOW8    1
    x8_12         FLOW12   -1
    x8_12         CAP99    34
    x9_0          OBJ       17.10
    x9_0          OUT9     1
    x9_0          FLOW9    1
    x9_1          OBJ       57.67
    x9_1          OUT9     1
    x9_1          IN1      1
    x9_1          FLOW9    1
    x9_1          FLOW1   -1
    x9_1          CAP100    34
    x9_2          OBJ       67.42
    x9_2          OUT9     1
    x9_2          IN2      1
    x9_2          FLOW9    1
    x9_2          FLOW2   -1
    x9_2          CAP101    34
    x9_3          OBJ       11.54
    x9_3          OUT9     1
    x9_3          IN3      1
    x9_3          FLOW9    1
    x9_3          FLOW3   -1
    x9_3          CAP102    34
    x9_4          OBJ       38.82
    x9_4          OUT9     1
    x9_4          IN4      1
    x9_4          FLOW9    1
    x9_4          FLOW4   -1
    x9_4          CAP103    34
    x9_5          OBJ       77.32
    x9_5          OUT9     1
    x9_5          IN5      1
    x9_5          FLOW9    1
    x9_5          FLOW5   -1
    x9_5          CAP104    34
    x9_6          OBJ       80.62
    x9_6          OUT9     1
    x9_6          IN6      1
    x9_6          FLOW9    1
    x9_6          FLOW6   -1
    x9_6          CAP105    34
    x9_7          OBJ       56.16
    x9_7          OUT9     1
    x9_7          IN7      1
    x9_7          FLOW9    1
    x9_7          FLOW7   -1
    x9_7          CAP106    34
    x9_8          OBJ       82.86
    x9_8          OUT9     1
    x9_8          IN8      1
    x9_8          FLOW9    1
    x9_8          FLOW8   -1
    x9_8          CAP107    34
    x9_10         OBJ       69.17
    x9_10         OUT9     1
    x9_10         IN10      1
    x9_10         FLOW9    1
    x9_10         FLOW10   -1
    x9_10         CAP108    34
    x9_11         OBJ       49.23
    x9_11         OUT9     1
    x9_11         IN11      1
    x9_11         FLOW9    1
    x9_11         FLOW11   -1
    x9_11         CAP109    34
    x9_12         OBJ       36.17
    x9_12         OUT9     1
    x9_12         IN12      1
    x9_12         FLOW9    1
    x9_12         FLOW12   -1
    x9_12         CAP110    34
    x10_0         OBJ       69.34
    x10_0         OUT10     1
    x10_0         FLOW10    1
    x10_1         OBJ       71.22
    x10_1         OUT10     1
    x10_1         IN1      1
    x10_1         FLOW10    1
    x10_1         FLOW1   -1
    x10_1         CAP111    34
    x10_2         OBJ       7.26
    x10_2         OUT10     1
    x10_2         IN2      1
    x10_2         FLOW10    1
    x10_2         FLOW2   -1
    x10_2         CAP112    34
    x10_3         OBJ       61.73
    x10_3         OUT10     1
    x10_3         IN3      1
    x10_3         FLOW10    1
    x10_3         FLOW3   -1
    x10_3         CAP113    34
    x10_4         OBJ       77.08
    x10_4         OUT10     1
    x10_4         IN4      1
    x10_4         FLOW10    1
    x10_4         FLOW4   -1
    x10_4         CAP114    34
    x10_5         OBJ       61.80
    x10_5         OUT10     1
    x10_5         IN5      1
    x10_5         FLOW10    1
    x10_5         FLOW5   -1
    x10_5         CAP115    34
    x10_6         OBJ       92.55
    x10_6         OUT10     1
    x10_6         IN6      1
    x10_6         FLOW10    1
    x10_6         FLOW6   -1
    x10_6         CAP116    34
    x10_7         OBJ       21.86
    x10_7         OUT10     1
    x10_7         IN7      1
    x10_7         FLOW10    1
    x10_7         FLOW7   -1
    x10_7         CAP117    34
    x10_8         OBJ       59.54
    x10_8         OUT10     1
    x10_8         IN8      1
    x10_8         FLOW10    1
    x10_8         FLOW8   -1
    x10_8         CAP118    34
    x10_9         OBJ       69.17
    x10_9         OUT10     1
    x10_9         IN9      1
    x10_9         FLOW10    1
    x10_9         FLOW9   -1
    x10_9         CAP119    34
    x10_11        OBJ       71.50
    x10_11        OUT10     1
    x10_11        IN11      1
    x10_11        FLOW10    1
    x10_11        FLOW11   -1
    x10_11        CAP120    34
    x10_12        OBJ       39.20
    x10_12        OUT10     1
    x10_12        IN12      1
    x10_12        FLOW10    1
    x10_12        FLOW12   -1
    x10_12        CAP121    34
    x11_0         OBJ       32.64
    x11_0         OUT11     1
    x11_0         FLOW11    1
    x11_1         OBJ       9.40
    x11_1         OUT11     1
    x11_1         IN1      1
    x11_1         FLOW11    1
    x11_1         FLOW1   -1
    x11_1         CAP122    34
    x11_2         OBJ       65.47
    x11_2         OUT11     1
    x11_2         IN2      1
    x11_2         FLOW11    1
    x11_2         FLOW2   -1
    x11_2         CAP123    34
    x11_3         OBJ       55.62
    x11_3         OUT11     1
    x11_3         IN3      1
    x11_3         FLOW11    1
    x11_3         FLOW3   -1
    x11_3         CAP124    34
    x11_4         OBJ       14.99
    x11_4         OUT11     1
    x11_4         IN4      1
    x11_4         FLOW11    1
    x11_4         FLOW4   -1
    x11_4         CAP125    34
    x11_5         OBJ       37.04
    x11_5         OUT11     1
    x11_5         IN5      1
    x11_5         FLOW11    1
    x11_5         FLOW5   -1
    x11_5         CAP126    34
    x11_6         OBJ       31.67
    x11_6         OUT11     1
    x11_6         IN6      1
    x11_6         FLOW11    1
    x11_6         FLOW6   -1
    x11_6         CAP127    34
    x11_7         OBJ       49.75
    x11_7         OUT11     1
    x11_7         IN7      1
    x11_7         FLOW11    1
    x11_7         FLOW7   -1
    x11_7         CAP128    34
    x11_8         OBJ       45.00
    x11_8         OUT11     1
    x11_8         IN8      1
    x11_8         FLOW11    1
    x11_8         FLOW8   -1
    x11_8         CAP129    34
    x11_9         OBJ       49.23
    x11_9         OUT11     1
    x11_9         IN9      1
    x11_9         FLOW11    1
    x11_9         FLOW9   -1
    x11_9         CAP130    34
    x11_10        OBJ       71.50
    x11_10        OUT11     1
    x11_10        IN10      1
    x11_10        FLOW11    1
    x11_10        FLOW10   -1
    x11_10        CAP131    34
    x11_12        OBJ       64.30
    x11_12        OUT11     1
    x11_12        IN12      1
    x11_12        FLOW11    1
    x11_12        FLOW12   -1
    x11_12        CAP132    34
    x12_0         OBJ       44.51
    x12_0         OUT12     1
    x12_0         FLOW12    1
    x12_1         OBJ       69.15
    x12_1         OUT12     1
    x12_1         IN1      1
    x12_1         FLOW12    1
    x12_1         FLOW1   -1
    x12_1         CAP133    34
    x12_2         OBJ       40.55
    x12_2         OUT12     1
    x12_2         IN2      1
    x12_2         FLOW12    1
    x12_2         FLOW2   -1
    x12_2         CAP134    34
    x12_3         OBJ       25.80
    x12_3         OUT12     1
    x12_3         IN3      1
    x12_3         FLOW12    1
    x12_3         FLOW3   -1
    x12_3         CAP135    34
    x12_4         OBJ       61.70
    x12_4         OUT12     1
    x12_4         IN4      1
    x12_4         FLOW12    1
    x12_4         FLOW4   -1
    x12_4         CAP136    34
    x12_5         OBJ       75.76
    x12_5         OUT12     1
    x12_5         IN5      1
    x12_5         FLOW12    1
    x12_5         FLOW5   -1
    x12_5         CAP137    34
    x12_6         OBJ       94.08
    x12_6         OUT12     1
    x12_6         IN6      1
    x12_6         FLOW12    1
    x12_6         FLOW6   -1
    x12_6         CAP138    34
    x12_7         OBJ       37.13
    x12_7         OUT12     1
    x12_7         IN7      1
    x12_7         FLOW12    1
    x12_7         FLOW7   -1
    x12_7         CAP139    34
    x12_8         OBJ       77.89
    x12_8         OUT12     1
    x12_8         IN8      1
    x12_8         FLOW12    1
    x12_8         FLOW8   -1
    x12_8         CAP140    34
    x12_9         OBJ       36.17
    x12_9         OUT12     1
    x12_9         IN9      1
    x12_9         FLOW12    1
    x12_9         FLOW9   -1
    x12_9         CAP141    34
    x12_10        OBJ       39.20
    x12_10        OUT12     1
    x12_10        IN10      1
    x12_10        FLOW12    1
    x12_10        FLOW10   -1
    x12_10        CAP142    34
    x12_11        OBJ       64.30
    x12_11        OUT12     1
    x12_11        IN11      1
    x12_11        FLOW12    1
    x12_11        FLOW11   -1
    x12_11        CAP143    34
    MARK0000  'MARKER'                 'INTEND'
    u1            CAP0    -1
    u1            CAP12     1
    u1            CAP13     1
    u1            CAP14     1
    u1            CAP15     1
    u1            CAP16     1
    u1            CAP17     1
    u1            CAP18     1
    u1            CAP19     1
    u1            CAP20     1
    u1            CAP21     1
    u1            CAP22     1
    u1            CAP23    -1
    u1            CAP34    -1
    u1            CAP45    -1
    u1            CAP56    -1
    u1            CAP67    -1
    u1            CAP78    -1
    u1            CAP89    -1
    u1            CAP100    -1
    u1            CAP111    -1
    u1            CAP122    -1
    u1            CAP133    -1
    u1            DLBO1    1
    u1            DUBO1    1
    u2            CAP1    -1
    u2            CAP12    -1
    u2            CAP23     1
    u2            CAP24     1
    u2            CAP25     1
    u2            CAP26     1
    u2            CAP27     1
    u2            CAP28     1
    u2            CAP29     1
    u2            CAP30     1
    u2            CAP31     1
    u2            CAP32     1
    u2            CAP33     1
    u2            CAP35    -1
    u2            CAP46    -1
    u2            CAP57    -1
    u2            CAP68    -1
    u2            CAP79    -1
    u2            CAP90    -1
    u2            CAP101    -1
    u2            CAP112    -1
    u2            CAP123    -1
    u2            CAP134    -1
    u2            DLBO2    1
    u2            DUBO2    1
    u3            CAP2    -1
    u3            CAP13    -1
    u3            CAP24    -1
    u3            CAP34     1
    u3            CAP35     1
    u3            CAP36     1
    u3            CAP37     1
    u3            CAP38     1
    u3            CAP39     1
    u3            CAP40     1
    u3            CAP41     1
    u3            CAP42     1
    u3            CAP43     1
    u3            CAP44     1
    u3            CAP47    -1
    u3            CAP58    -1
    u3            CAP69    -1
    u3            CAP80    -1
    u3            CAP91    -1
    u3            CAP102    -1
    u3            CAP113    -1
    u3            CAP124    -1
    u3            CAP135    -1
    u3            DLBO3    1
    u3            DUBO3    1
    u4            CAP3    -1
    u4            CAP14    -1
    u4            CAP25    -1
    u4            CAP36    -1
    u4            CAP45     1
    u4            CAP46     1
    u4            CAP47     1
    u4            CAP48     1
    u4            CAP49     1
    u4            CAP50     1
    u4            CAP51     1
    u4            CAP52     1
    u4            CAP53     1
    u4            CAP54     1
    u4            CAP55     1
    u4            CAP59    -1
    u4            CAP70    -1
    u4            CAP81    -1
    u4            CAP92    -1
    u4            CAP103    -1
    u4            CAP114    -1
    u4            CAP125    -1
    u4            CAP136    -1
    u4            DLBO4    1
    u4            DUBO4    1
    u5            CAP4    -1
    u5            CAP15    -1
    u5            CAP26    -1
    u5            CAP37    -1
    u5            CAP48    -1
    u5            CAP56     1
    u5            CAP57     1
    u5            CAP58     1
    u5            CAP59     1
    u5            CAP60     1
    u5            CAP61     1
    u5            CAP62     1
    u5            CAP63     1
    u5            CAP64     1
    u5            CAP65     1
    u5            CAP66     1
    u5            CAP71    -1
    u5            CAP82    -1
    u5            CAP93    -1
    u5            CAP104    -1
    u5            CAP115    -1
    u5            CAP126    -1
    u5            CAP137    -1
    u5            DLBO5    1
    u5            DUBO5    1
    u6            CAP5    -1
    u6            CAP16    -1
    u6            CAP27    -1
    u6            CAP38    -1
    u6            CAP49    -1
    u6            CAP60    -1
    u6            CAP67     1
    u6            CAP68     1
    u6            CAP69     1
    u6            CAP70     1
    u6            CAP71     1
    u6            CAP72     1
    u6            CAP73     1
    u6            CAP74     1
    u6            CAP75     1
    u6            CAP76     1
    u6            CAP77     1
    u6            CAP83    -1
    u6            CAP94    -1
    u6            CAP105    -1
    u6            CAP116    -1
    u6            CAP127    -1
    u6            CAP138    -1
    u6            DLBO6    1
    u6            DUBO6    1
    u7            CAP6    -1
    u7            CAP17    -1
    u7            CAP28    -1
    u7            CAP39    -1
    u7            CAP50    -1
    u7            CAP61    -1
    u7            CAP72    -1
    u7            CAP78     1
    u7            CAP79     1
    u7            CAP80     1
    u7            CAP81     1
    u7            CAP82     1
    u7            CAP83     1
    u7            CAP84     1
    u7            CAP85     1
    u7            CAP86     1
    u7            CAP87     1
    u7            CAP88     1
    u7            CAP95    -1
    u7            CAP106    -1
    u7            CAP117    -1
    u7            CAP128    -1
    u7            CAP139    -1
    u7            DLBO7    1
    u7            DUBO7    1
    u8            CAP7    -1
    u8            CAP18    -1
    u8            CAP29    -1
    u8            CAP40    -1
    u8            CAP51    -1
    u8            CAP62    -1
    u8            CAP73    -1
    u8            CAP84    -1
    u8            CAP89     1
    u8            CAP90     1
    u8            CAP91     1
    u8            CAP92     1
    u8            CAP93     1
    u8            CAP94     1
    u8            CAP95     1
    u8            CAP96     1
    u8            CAP97     1
    u8            CAP98     1
    u8            CAP99     1
    u8            CAP107    -1
    u8            CAP118    -1
    u8            CAP129    -1
    u8            CAP140    -1
    u8            DLBO8    1
    u8            DUBO8    1
    u9            CAP8    -1
    u9            CAP19    -1
    u9            CAP30    -1
    u9            CAP41    -1
    u9            CAP52    -1
    u9            CAP63    -1
    u9            CAP74    -1
    u9            CAP85    -1
    u9            CAP96    -1
    u9            CAP100     1
    u9            CAP101     1
    u9            CAP102     1
    u9            CAP103     1
    u9            CAP104     1
    u9            CAP105     1
    u9            CAP106     1
    u9            CAP107     1
    u9            CAP108     1
    u9            CAP109     1
    u9            CAP110     1
    u9            CAP119    -1
    u9            CAP130    -1
    u9            CAP141    -1
    u9            DLBO9    1
    u9            DUBO9    1
    u10           CAP9    -1
    u10           CAP20    -1
    u10           CAP31    -1
    u10           CAP42    -1
    u10           CAP53    -1
    u10           CAP64    -1
    u10           CAP75    -1
    u10           CAP86    -1
    u10           CAP97    -1
    u10           CAP108    -1
    u10           CAP111     1
    u10           CAP112     1
    u10           CAP113     1
    u10           CAP114     1
    u10           CAP115     1
    u10           CAP116     1
    u10           CAP117     1
    u10           CAP118     1
    u10           CAP119     1
    u10           CAP120     1
    u10           CAP121     1
    u10           CAP131    -1
    u10           CAP142    -1
    u10           DLBO10    1
    u10           DUBO10    1
    u11           CAP10    -1
    u11           CAP21    -1
    u11           CAP32    -1
    u11           CAP43    -1
    u11           CAP54    -1
    u11           CAP65    -1
    u11           CAP76    -1
    u11           CAP87    -1
    u11           CAP98    -1
    u11           CAP109    -1
    u11           CAP120    -1
    u11           CAP122     1
    u11           CAP123     1
    u11           CAP124     1
    u11           CAP125     1
    u11           CAP126     1
    u11           CAP127     1
    u11           CAP128     1
    u11           CAP129     1
    u11           CAP130     1
    u11           CAP131     1
    u11           CAP132     1
    u11           CAP143    -1
    u11           DLBO11    1
    u11           DUBO11    1
    u12           CAP11    -1
    u12           CAP22    -1
    u12           CAP33    -1
    u12           CAP44    -1
    u12           CAP55    -1
    u12           CAP66    -1
    u12           CAP77    -1
    u12           CAP88    -1
    u12           CAP99    -1
    u12           CAP110    -1
    u12           CAP121    -1
    u12           CAP132    -1
    u12           CAP133     1
    u12           CAP134     1
    u12           CAP135     1
    u12           CAP136     1
    u12           CAP137     1
    u12           CAP138     1
    u12           CAP139     1
    u12           CAP140     1
    u12           CAP141     1
    u12           CAP142     1
    u12           CAP143     1
    u12           DLBO12    1
    u12           DUBO12    1
RHS
    RHS1      OUT1      1
    RHS1      IN1       1
    RHS1      OUT2      1
    RHS1      IN2       1
    RHS1      OUT3      1
    RHS1      IN3       1
    RHS1      OUT4      1
    RHS1      IN4       1
    RHS1      OUT5      1
    RHS1      IN5       1
    RHS1      OUT6      1
    RHS1      IN6       1
    RHS1      OUT7      1
    RHS1      IN7       1
    RHS1      OUT8      1
    RHS1      IN8       1
    RHS1      OUT9      1
    RHS1      IN9       1
    RHS1      OUT10      1
    RHS1      IN10       1
    RHS1      OUT11      1
    RHS1      IN11       1
    RHS1      OUT12      1
    RHS1      IN12       1
    RHS1      FLEET      2
    RHS1      CAP0     31
    RHS1      CAP1     32
    RHS1      CAP2     28
    RHS1      CAP3     29
    RHS1      CAP4     29
    RHS1      CAP5     30
    RHS1      CAP6     31
    RHS1      CAP7     24
    RHS1      CAP8     31
    RHS1      CAP9     26
    RHS1      CAP10     32
    RHS1      CAP11     32
    RHS1      CAP12     32
    RHS1      CAP13     28
    RHS1      CAP14     29
    RHS1      CAP15     29
    RHS1      CAP16     30
    RHS1      CAP17     31
    RHS1      CAP18     24
    RHS1      CAP19     31
    RHS1      CAP20     26
    RHS1      CAP21     32
    RHS1      CAP22     32
    RHS1      CAP23     31
    RHS1      CAP24     28
    RHS1      CAP25     29
    RHS1      CAP26     29
    RHS1      CAP27     30
    RHS1      CAP28     31
    RHS1      CAP29     24
    RHS1      CAP30     31
    RHS1      CAP31     26
    RHS1      CAP32     32
    RHS1      CAP33     32
    RHS1      CAP34     31
    RHS1      CAP35     32
    RHS1      CAP36     29
    RHS1      CAP37     29
    RHS1      CAP38     30
    RHS1      CAP39     31
    RHS1      CAP40     24
    RHS1      CAP41     31
    RHS1      CAP42     26
    RHS1      CAP43     32
    RHS1      CAP44     32
    RHS1      CAP45     31
    RHS1      CAP46     32
    RHS1      CAP47     28
    RHS1      CAP48     29
    RHS1      CAP49     30
    RHS1      CAP50     31
    RHS1      CAP51     24
    RHS1      CAP52     31
    RHS1      CAP53     26
    RHS1      CAP54     32
    RHS1      CAP55     32
    RHS1      CAP56     31
    RHS1      CAP57     32
    RHS1      CAP58     28
    RHS1      CAP59     29
    RHS1      CAP60     30
    RHS1      CAP61     31
    RHS1      CAP62     24
    RHS1      CAP63     31
    RHS1      CAP64     26
    RHS1      CAP65     32
    RHS1      CAP66     32
    RHS1      CAP67     31
    RHS1      CAP68     32
    RHS1      CAP69     28
    RHS1      CAP70     29
    RHS1      CAP71     29
    RHS1      CAP72     31
    RHS1      CAP73     24
    RHS1      CAP74     31
    RHS1      CAP75     26
    RHS1      CAP76     32
    RHS1      CAP77     32
    RHS1      CAP78     31
    RHS1      CAP79     32
    RHS1      CAP80     28
    RHS1      CAP81     29
    RHS1      CAP82     29
    RHS1      CAP83     30
    RHS1      CAP84     24
    RHS1      CAP85     31
    RHS1      CAP86     26
    RHS1      CAP87     32
    RHS1      CAP88     32
    RHS1      CAP89     31
    RHS1      CAP90     32
    RHS1      CAP91     28
    RHS1      CAP92     29
    RHS1      CAP93     29
    RHS1      CAP94     30
    RHS1      CAP95     31
    RHS1      CAP96     31
    RHS1      CAP97     26
    RHS1      CAP98     32
    RHS1      CAP99     32
    RHS1      CAP100     31
    RHS1      CAP101     32
    RHS1      CAP102     28
    RHS1      CAP103     29
    RHS1      CAP104     29
    RHS1      CAP105     30
    RHS1      CAP106     31
    RHS1      CAP107     24
    RHS1      CAP108     26
    RHS1      CAP109     32
    RHS1      CAP110     32
    RHS1      CAP111     31
    RHS1      CAP112     32
    RHS1      CAP113     28
    RHS1      CAP114     29
    RHS1      CAP115     29
    RHS1      CAP116     30
    RHS1      CAP117     31
    RHS1      CAP118     24
    RHS1      CAP119     31
    RHS1      CAP120     32
    RHS1      CAP121     32
    RHS1      CAP122     31
    RHS1      CAP123     32
    RHS1      CAP124     28
    RHS1      CAP125     29
    RHS1      CAP126     29
    RHS1      CAP127     30
    RHS1      CAP128     31
    RHS1      CAP129     24
    RHS1      CAP130     31
    RHS1      CAP131     26
    RHS1      CAP132     32
    RHS1      CAP133     31
    RHS1      CAP134     32
    RHS1      CAP135     28
    RHS1      CAP136     29
    RHS1      CAP137     29
    RHS1      CAP138     30
    RHS1      CAP139     31
    RHS1      CAP140     24
    RHS1      CAP141     31
    RHS1      CAP142     26
    RHS1      CAP143     32
    RHS1      DLBO1    3
    RHS1      DUBO1    34
    RHS1      DLBO2    2
    RHS1      DUBO2    34
    RHS1      DLBO3    6
    RHS1      DUBO3    34
    RHS1      DLBO4    5
    RHS1      DUBO4    34
    RHS1      DLBO5    5
    RHS1      DUBO5    34
    RHS1      DLBO6    4
    RHS1      DUBO6    34
    RHS1      DLBO7    3
    RHS1      DUBO7    34
    RHS1      DLBO8    10
    RHS1      DUBO8    34
    RHS1      DLBO9    3
    RHS1      DUBO9    34
    RHS1      DLBO10    8
    RHS1      DUBO10    34
    RHS1      DLBO11    2
    RHS1      DUBO11    34
    RHS1      DLBO12    2
    RHS1      DUBO12    34
BOUNDS
ENDATA
