NAME          steiner_search_n20_t10_sd21
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 L  cap_0_1
 L  cap_0_2
 L  cap_0_3
 L  cap_0_4
 L  cap_0_5
 L  cap_0_6
 L  cap_0_7
 L  cap_0_8
 L  cap_0_9
 L  cap_0_10
 L  cap_0_11
 L  cap_0_12
 L  cap_0_13
 L  cap_0_14
 L  cap_0_15
 L  cap_0_16
 L  cap_0_17
 L  cap_0_18
 L  cap_0_19
 L  cap_1_2
 L  cap_1_3
 L  cap_1_4
 L  cap_1_5
 L  cap_1_6
 L  cap_1_7
 L  cap_1_8
 L  cap_1_9
 L  cap_1_10
 L  cap_1_11
 L  cap_1_12
 L  cap_1_13
 L  cap_1_14
 L  cap_1_15
 L  cap_1_16
 L  cap_1_17
 L  cap_1_18
 L  cap_1_19
 L  cap_2_3
 L  cap_2_4
 L  cap_2_5
 L  cap_2_6
 L  cap_2_7
 L  cap_2_8
 L  cap_2_9
 L  cap_2_10
 L  cap_2_11
 L  cap_2_12
 L  cap_2_13
 L  cap_2_14
 L  cap_2_15
 L  cap_2_16
 L  cap_2_17
 L  cap_2_18
 L  cap_2_19
 L  cap_3_4
 L  cap_3_5
 L  cap_3_6
 L  cap_3_7
 L  cap_3_8
 L  cap_3_9
 L  cap_3_10
 L  cap_3_11
 L  cap_3_12
 L  cap_3_13
 L  cap_3_14
 L  cap_3_15
 L  cap_3_16
 L  cap_3_17
 L  cap_3_18
 L  cap_3_19
 L  cap_4_5
 L  cap_4_6
 L  cap_4_7
 L  cap_4_8
 L  cap_4_9
 L  cap_4_10
 L  cap_4_11
 L  cap_4_12
 L  cap_4_13
 L  cap_4_14
 L  cap_4_15
 L  cap_4_16
 L  cap_4_17
 L  cap_4_18
 L  cap_4_19
 L  cap_5_6
 L  cap_5_7
 L  cap_5_8
 L  cap_5_9
 L  cap_5_10
 L  cap_5_11
 L  cap_5_12
 L  cap_5_13
 L  cap_5_14
 L  cap_5_15
 L  cap_5_16
 L  cap_5_17
 L  cap_5_18
 L  cap_5_19
 L  cap_6_7
 L  cap_6_8
 L  cap_6_9
 L  cap_6_10
 L  cap_6_11
 L  cap_6_12
 L  cap_6_13
 L  cap_6_14
 L  cap_6_15
 L  cap_6_16
 L  cap_6_17
 L  cap_6_18
 L  cap_6_19
 L  cap_7_8
 L  cap_7_9
 L  cap_7_10
 L  cap_7_11
 L  cap_7_12
 L  cap_7_13
 L  cap_7_14
 L  cap_7_15
 L  cap_7_16
 L  cap_7_17
 L  cap_7_18
 L  cap_7_19
 L  cap_8_9
 L  cap_8_10
 L  cap_8_11
 L  cap_8_12
 L  cap_8_13
 L  cap_8_14
 L  cap_8_15
 L  cap_8_16
 L  cap_8_17
 L  cap_8_18
 L  cap_8_19
 L  cap_9_10
 L  cap_9_11
 L  cap_9_12
 L  cap_9_13
 L  cap_9_14
 L  cap_9_15
 L  cap_9_16
 L  cap_9_17
 L  cap_9_18
 L  cap_9_19
 L  cap_10_11
 L  cap_10_12
 L  cap_10_13
 L  cap_10_14
 L  cap_10_15
 L  cap_10_16
 L  cap_10_17
 L  cap_10_18
 L  cap_10_19
 L  cap_11_12
 L  cap_11_13
 L  cap_11_14
 L  cap_11_15
 L  cap_11_16
 L  cap_11_17
 L  cap_11_18
 L  cap_11_19
 L  cap_12_13
 L  cap_12_14
 L  cap_12_15
 L  cap_12_16
 L  cap_12_17
 L  cap_12_18
 L  cap_12_19
 L  cap_13_14
 L  cap_13_15
 L  cap_13_16
 L  cap_13_17
 L  cap_13_18
 L  cap_13_19
 L  cap_14_15
 L  cap_14_16
 L  cap_14_17
 L  cap_14_18
 L  cap_14_19
 L  cap_15_16
 L  cap_15_17
 L  cap_15_18
 L  cap_15_19
 L  cap_16_17
 L  cap_16_18
 L  cap_16_19
 L  cap_17_18
 L  cap_17_19
 L  cap_18_19
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       6
    x_0_1     cap_0_1   -10
    x_0_2     OBJ       14
    x_0_2     cap_0_2   -10
    x_0_3     OBJ       14
    x_0_3     cap_0_3   -10
    x_0_4     OBJ       10
    x_0_4     cap_0_4   -10
    x_0_5     OBJ       16
    x_0_5     cap_0_5   -10
    x_0_6     OBJ       7
    x_0_6     cap_0_6   -10
    x_0_7     OBJ       16
    x_0_7     cap_0_7   -10
    x_0_8     OBJ       17
    x_0_8     cap_0_8   -10
    x_0_9     OBJ       6
    x_0_9     cap_0_9   -10
    x_0_10    OBJ       17
    x_0_10    cap_0_10  -10
    x_0_11    OBJ       17
    x_0_11    cap_0_11  -10
    x_0_12    OBJ       8
    x_0_12    cap_0_12  -10
    x_0_13    OBJ       1
    x_0_13    cap_0_13  -10
    x_0_14    OBJ       1
    x_0_14    cap_0_14  -10
    x_0_15    OBJ       12
    x_0_15    cap_0_15  -10
    x_0_16    OBJ       19
    x_0_16    cap_0_16  -10
    x_0_17    OBJ       14
    x_0_17    cap_0_17  -10
    x_0_18    OBJ       3
    x_0_18    cap_0_18  -10
    x_0_19    OBJ       5
    x_0_19    cap_0_19  -10
    x_1_2     OBJ       8
    x_1_2     cap_1_2   -10
    x_1_3     OBJ       8
    x_1_3     cap_1_3   -10
    x_1_4     OBJ       2
    x_1_4     cap_1_4   -10
    x_1_5     OBJ       14
    x_1_5     cap_1_5   -10
    x_1_6     OBJ       14
    x_1_6     cap_1_6   -10
    x_1_7     OBJ       20
    x_1_7     cap_1_7   -10
    x_1_8     OBJ       15
    x_1_8     cap_1_8   -10
    x_1_9     OBJ       2
    x_1_9     cap_1_9   -10
    x_1_10    OBJ       11
    x_1_10    cap_1_10  -10
    x_1_11    OBJ       18
    x_1_11    cap_1_11  -10
    x_1_12    OBJ       16
    x_1_12    cap_1_12  -10
    x_1_13    OBJ       4
    x_1_13    cap_1_13  -10
    x_1_14    OBJ       12
    x_1_14    cap_1_14  -10
    x_1_15    OBJ       1
    x_1_15    cap_1_15  -10
    x_1_16    OBJ       5
    x_1_16    cap_1_16  -10
    x_1_17    OBJ       3
    x_1_17    cap_1_17  -10
    x_1_18    OBJ       4
    x_1_18    cap_1_18  -10
    x_1_19    OBJ       1
    x_1_19    cap_1_19  -10
    x_2_3     OBJ       15
    x_2_3     cap_2_3   -10
    x_2_4     OBJ       6
    x_2_4     cap_2_4   -10
    x_2_5     OBJ       18
    x_2_5     cap_2_5   -10
    x_2_6     OBJ       11
    x_2_6     cap_2_6   -10
    x_2_7     OBJ       13
    x_2_7     cap_2_7   -10
    x_2_8     OBJ       16
    x_2_8     cap_2_8   -10
    x_2_9     OBJ       5
    x_2_9     cap_2_9   -10
    x_2_10    OBJ       6
    x_2_10    cap_2_10  -10
    x_2_11    OBJ       2
    x_2_11    cap_2_11  -10
    x_2_12    OBJ       16
    x_2_12    cap_2_12  -10
    x_2_13    OBJ       8
    x_2_13    cap_2_13  -10
    x_2_14    OBJ       3
    x_2_14    cap_2_14  -10
    x_2_15    OBJ       7
    x_2_15    cap_2_15  -10
    x_2_16    OBJ       7
    x_2_16    cap_2_16  -10
    x_2_17    OBJ       19
    x_2_17    cap_2_17  -10
    x_2_18    OBJ       3
    x_2_18    cap_2_18  -10
    x_2_19    OBJ       4
    x_2_19    cap_2_19  -10
    x_3_4     OBJ       18
    x_3_4     cap_3_4   -10
    x_3_5     OBJ       16
    x_3_5     cap_3_5   -10
    x_3_6     OBJ       18
    x_3_6     cap_3_6   -10
    x_3_7     OBJ       13
    x_3_7     cap_3_7   -10
    x_3_8     OBJ       7
    x_3_8     cap_3_8   -10
    x_3_9     OBJ       11
    x_3_9     cap_3_9   -10
    x_3_10    OBJ       5
    x_3_10    cap_3_10  -10
    x_3_11    OBJ       18
    x_3_11    cap_3_11  -10
    x_3_12    OBJ       14
    x_3_12    cap_3_12  -10
    x_3_13    OBJ       10
    x_3_13    cap_3_13  -10
    x_3_14    OBJ       12
    x_3_14    cap_3_14  -10
    x_3_15    OBJ       15
    x_3_15    cap_3_15  -10
    x_3_16    OBJ       17
    x_3_16    cap_3_16  -10
    x_3_17    OBJ       13
    x_3_17    cap_3_17  -10
    x_3_18    OBJ       11
    x_3_18    cap_3_18  -10
    x_3_19    OBJ       16
    x_3_19    cap_3_19  -10
    x_4_5     OBJ       13
    x_4_5     cap_4_5   -10
    x_4_6     OBJ       9
    x_4_6     cap_4_6   -10
    x_4_7     OBJ       1
    x_4_7     cap_4_7   -10
    x_4_8     OBJ       3
    x_4_8     cap_4_8   -10
    x_4_9     OBJ       6
    x_4_9     cap_4_9   -10
    x_4_10    OBJ       16
    x_4_10    cap_4_10  -10
    x_4_11    OBJ       1
    x_4_11    cap_4_11  -10
    x_4_12    OBJ       16
    x_4_12    cap_4_12  -10
    x_4_13    OBJ       3
    x_4_13    cap_4_13  -10
    x_4_14    OBJ       18
    x_4_14    cap_4_14  -10
    x_4_15    OBJ       20
    x_4_15    cap_4_15  -10
    x_4_16    OBJ       17
    x_4_16    cap_4_16  -10
    x_4_17    OBJ       8
    x_4_17    cap_4_17  -10
    x_4_18    OBJ       19
    x_4_18    cap_4_18  -10
    x_4_19    OBJ       20
    x_4_19    cap_4_19  -10
    x_5_6     OBJ       11
    x_5_6     cap_5_6   -10
    x_5_7     OBJ       18
    x_5_7     cap_5_7   -10
    x_5_8     OBJ       20
    x_5_8     cap_5_8   -10
    x_5_9     OBJ       4
    x_5_9     cap_5_9   -10
    x_5_10    OBJ       6
    x_5_10    cap_5_10  -10
    x_5_11    OBJ       6
    x_5_11    cap_5_11  -10
    x_5_12    OBJ       12
    x_5_12    cap_5_12  -10
    x_5_13    OBJ       11
    x_5_13    cap_5_13  -10
    x_5_14    OBJ       12
    x_5_14    cap_5_14  -10
    x_5_15    OBJ       20
    x_5_15    cap_5_15  -10
    x_5_16    OBJ       10
    x_5_16    cap_5_16  -10
    x_5_17    OBJ       8
    x_5_17    cap_5_17  -10
    x_5_18    OBJ       4
    x_5_18    cap_5_18  -10
    x_5_19    OBJ       6
    x_5_19    cap_5_19  -10
    x_6_7     OBJ       3
    x_6_7     cap_6_7   -10
    x_6_8     OBJ       6
    x_6_8     cap_6_8   -10
    x_6_9     OBJ       14
    x_6_9     cap_6_9   -10
    x_6_10    OBJ       12
    x_6_10    cap_6_10  -10
    x_6_11    OBJ       6
    x_6_11    cap_6_11  -10
    x_6_12    OBJ       2
    x_6_12    cap_6_12  -10
    x_6_13    OBJ       17
    x_6_13    cap_6_13  -10
    x_6_14    OBJ       8
    x_6_14    cap_6_14  -10
    x_6_15    OBJ       14
    x_6_15    cap_6_15  -10
    x_6_16    OBJ       6
    x_6_16    cap_6_16  -10
    x_6_17    OBJ       19
    x_6_17    cap_6_17  -10
    x_6_18    OBJ       1
    x_6_18    cap_6_18  -10
    x_6_19    OBJ       12
    x_6_19    cap_6_19  -10
    x_7_8     OBJ       16
    x_7_8     cap_7_8   -10
    x_7_9     OBJ       17
    x_7_9     cap_7_9   -10
    x_7_10    OBJ       13
    x_7_10    cap_7_10  -10
    x_7_11    OBJ       8
    x_7_11    cap_7_11  -10
    x_7_12    OBJ       8
    x_7_12    cap_7_12  -10
    x_7_13    OBJ       6
    x_7_13    cap_7_13  -10
    x_7_14    OBJ       18
    x_7_14    cap_7_14  -10
    x_7_15    OBJ       3
    x_7_15    cap_7_15  -10
    x_7_16    OBJ       15
    x_7_16    cap_7_16  -10
    x_7_17    OBJ       14
    x_7_17    cap_7_17  -10
    x_7_18    OBJ       16
    x_7_18    cap_7_18  -10
    x_7_19    OBJ       2
    x_7_19    cap_7_19  -10
    x_8_9     OBJ       10
    x_8_9     cap_8_9   -10
    x_8_10    OBJ       2
    x_8_10    cap_8_10  -10
    x_8_11    OBJ       9
    x_8_11    cap_8_11  -10
    x_8_12    OBJ       10
    x_8_12    cap_8_12  -10
    x_8_13    OBJ       2
    x_8_13    cap_8_13  -10
    x_8_14    OBJ       14
    x_8_14    cap_8_14  -10
    x_8_15    OBJ       8
    x_8_15    cap_8_15  -10
    x_8_16    OBJ       6
    x_8_16    cap_8_16  -10
    x_8_17    OBJ       13
    x_8_17    cap_8_17  -10
    x_8_18    OBJ       3
    x_8_18    cap_8_18  -10
    x_8_19    OBJ       11
    x_8_19    cap_8_19  -10
    x_9_10    OBJ       5
    x_9_10    cap_9_10  -10
    x_9_11    OBJ       5
    x_9_11    cap_9_11  -10
    x_9_12    OBJ       16
    x_9_12    cap_9_12  -10
    x_9_13    OBJ       2
    x_9_13    cap_9_13  -10
    x_9_14    OBJ       9
    x_9_14    cap_9_14  -10
    x_9_15    OBJ       5
    x_9_15    cap_9_15  -10
    x_9_16    OBJ       17
    x_9_16    cap_9_16  -10
    x_9_17    OBJ       16
    x_9_17    cap_9_17  -10
    x_9_18    OBJ       1
    x_9_18    cap_9_18  -10
    x_9_19    OBJ       7
    x_9_19    cap_9_19  -10
    x_10_11   OBJ       12
    x_10_11   cap_10_11  -10
    x_10_12   OBJ       5
    x_10_12   cap_10_12  -10
    x_10_13   OBJ       12
    x_10_13   cap_10_13  -10
    x_10_14   OBJ       20
    x_10_14   cap_10_14  -10
    x_10_15   OBJ       14
    x_10_15   cap_10_15  -10
    x_10_16   OBJ       16
    x_10_16   cap_10_16  -10
    x_10_17   OBJ       19
    x_10_17   cap_10_17  -10
    x_10_18   OBJ       16
    x_10_18   cap_10_18  -10
    x_10_19   OBJ       10
    x_10_19   cap_10_19  -10
    x_11_12   OBJ       5
    x_11_12   cap_11_12  -10
    x_11_13   OBJ       18
    x_11_13   cap_11_13  -10
    x_11_14   OBJ       19
    x_11_14   cap_11_14  -10
    x_11_15   OBJ       9
    x_11_15   cap_11_15  -10
    x_11_16   OBJ       5
    x_11_16   cap_11_16  -10
    x_11_17   OBJ       1
    x_11_17   cap_11_17  -10
    x_11_18   OBJ       13
    x_11_18   cap_11_18  -10
    x_11_19   OBJ       5
    x_11_19   cap_11_19  -10
    x_12_13   OBJ       1
    x_12_13   cap_12_13  -10
    x_12_14   OBJ       9
    x_12_14   cap_12_14  -10
    x_12_15   OBJ       19
    x_12_15   cap_12_15  -10
    x_12_16   OBJ       11
    x_12_16   cap_12_16  -10
    x_12_17   OBJ       8
    x_12_17   cap_12_17  -10
    x_12_18   OBJ       19
    x_12_18   cap_12_18  -10
    x_12_19   OBJ       14
    x_12_19   cap_12_19  -10
    x_13_14   OBJ       9
    x_13_14   cap_13_14  -10
    x_13_15   OBJ       13
    x_13_15   cap_13_15  -10
    x_13_16   OBJ       5
    x_13_16   cap_13_16  -10
    x_13_17   OBJ       5
    x_13_17   cap_13_17  -10
    x_13_18   OBJ       5
    x_13_18   cap_13_18  -10
    x_13_19   OBJ       4
    x_13_19   cap_13_19  -10
    x_14_15   OBJ       13
    x_14_15   cap_14_15  -10
    x_14_16   OBJ       4
    x_14_16   cap_14_16  -10
    x_14_17   OBJ       6
    x_14_17   cap_14_17  -10
    x_14_18   OBJ       1
    x_14_18   cap_14_18  -10
    x_14_19   OBJ       15
    x_14_19   cap_14_19  -10
    x_15_16   OBJ       5
    x_15_16   cap_15_16  -10
    x_15_17   OBJ       3
    x_15_17   cap_15_17  -10
    x_15_18   OBJ       4
    x_15_18   cap_15_18  -10
    x_15_19   OBJ       10
    x_15_19   cap_15_19  -10
    x_16_17   OBJ       5
    x_16_17   cap_16_17  -10
    x_16_18   OBJ       10
    x_16_18   cap_16_18  -10
    x_16_19   OBJ       18
    x_16_19   cap_16_19  -10
    x_17_18   OBJ       11
    x_17_18   cap_17_18  -10
    x_17_19   OBJ       13
    x_17_19   cap_17_19  -10
    x_18_19   OBJ       16
    x_18_19   cap_18_19  -10
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_2     flow_0    1.0
    f_0_2     flow_2    -1.0
    f_0_2     cap_0_2   1.0
    f_2_0     flow_0    -1.0
    f_2_0     flow_2    1.0
    f_2_0     cap_0_2   1.0
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_4     flow_0    1.0
    f_0_4     flow_4    -1.0
    f_0_4     cap_0_4   1.0
    f_4_0     flow_0    -1.0
    f_4_0     flow_4    1.0
    f_4_0     cap_0_4   1.0
    f_0_5     flow_0    1.0
    f_0_5     flow_5    -1.0
    f_0_5     cap_0_5   1.0
    f_5_0     flow_0    -1.0
    f_5_0     flow_5    1.0
    f_5_0     cap_0_5   1.0
    f_0_6     flow_0    1.0
    f_0_6     flow_6    -1.0
    f_0_6     cap_0_6   1.0
    f_6_0     flow_0    -1.0
    f_6_0     flow_6    1.0
    f_6_0     cap_0_6   1.0
    f_0_7     flow_0    1.0
    f_0_7     flow_7    -1.0
    f_0_7     cap_0_7   1.0
    f_7_0     flow_0    -1.0
    f_7_0     flow_7    1.0
    f_7_0     cap_0_7   1.0
    f_0_8     flow_0    1.0
    f_0_8     flow_8    -1.0
    f_0_8     cap_0_8   1.0
    f_8_0     flow_0    -1.0
    f_8_0     flow_8    1.0
    f_8_0     cap_0_8   1.0
    f_0_9     flow_0    1.0
    f_0_9     flow_9    -1.0
    f_0_9     cap_0_9   1.0
    f_9_0     flow_0    -1.0
    f_9_0     flow_9    1.0
    f_9_0     cap_0_9   1.0
    f_0_10    flow_0    1.0
    f_0_10    flow_10   -1.0
    f_0_10    cap_0_10  1.0
    f_10_0    flow_0    -1.0
    f_10_0    flow_10   1.0
    f_10_0    cap_0_10  1.0
    f_0_11    flow_0    1.0
    f_0_11    flow_11   -1.0
    f_0_11    cap_0_11  1.0
    f_11_0    flow_0    -1.0
    f_11_0    flow_11   1.0
    f_11_0    cap_0_11  1.0
    f_0_12    flow_0    1.0
    f_0_12    flow_12   -1.0
    f_0_12    cap_0_12  1.0
    f_12_0    flow_0    -1.0
    f_12_0    flow_12   1.0
    f_12_0    cap_0_12  1.0
    f_0_13    flow_0    1.0
    f_0_13    flow_13   -1.0
    f_0_13    cap_0_13  1.0
    f_13_0    flow_0    -1.0
    f_13_0    flow_13   1.0
    f_13_0    cap_0_13  1.0
    f_0_14    flow_0    1.0
    f_0_14    flow_14   -1.0
    f_0_14    cap_0_14  1.0
    f_14_0    flow_0    -1.0
    f_14_0    flow_14   1.0
    f_14_0    cap_0_14  1.0
    f_0_15    flow_0    1.0
    f_0_15    flow_15   -1.0
    f_0_15    cap_0_15  1.0
    f_15_0    flow_0    -1.0
    f_15_0    flow_15   1.0
    f_15_0    cap_0_15  1.0
    f_0_16    flow_0    1.0
    f_0_16    flow_16   -1.0
    f_0_16    cap_0_16  1.0
    f_16_0    flow_0    -1.0
    f_16_0    flow_16   1.0
    f_16_0    cap_0_16  1.0
    f_0_17    flow_0    1.0
    f_0_17    flow_17   -1.0
    f_0_17    cap_0_17  1.0
    f_17_0    flow_0    -1.0
    f_17_0    flow_17   1.0
    f_17_0    cap_0_17  1.0
    f_0_18    flow_0    1.0
    f_0_18    flow_18   -1.0
    f_0_18    cap_0_18  1.0
    f_18_0    flow_0    -1.0
    f_18_0    flow_18   1.0
    f_18_0    cap_0_18  1.0
    f_0_19    flow_0    1.0
    f_0_19    flow_19   -1.0
    f_0_19    cap_0_19  1.0
    f_19_0    flow_0    -1.0
    f_19_0    flow_19   1.0
    f_19_0    cap_0_19  1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_3     flow_1    1.0
    f_1_3     flow_3    -1.0
    f_1_3     cap_1_3   1.0
    f_3_1     flow_1    -1.0
    f_3_1     flow_3    1.0
    f_3_1     cap_1_3   1.0
    f_1_4     flow_1    1.0
    f_1_4     flow_4    -1.0
    f_1_4     cap_1_4   1.0
    f_4_1     flow_1    -1.0
    f_4_1     flow_4    1.0
    f_4_1     cap_1_4   1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_1_6     flow_1    1.0
    f_1_6     flow_6    -1.0
    f_1_6     cap_1_6   1.0
    f_6_1     flow_1    -1.0
    f_6_1     flow_6    1.0
    f_6_1     cap_1_6   1.0
    f_1_7     flow_1    1.0
    f_1_7     flow_7    -1.0
    f_1_7     cap_1_7   1.0
    f_7_1     flow_1    -1.0
    f_7_1     flow_7    1.0
    f_7_1     cap_1_7   1.0
    f_1_8     flow_1    1.0
    f_1_8     flow_8    -1.0
    f_1_8     cap_1_8   1.0
    f_8_1     flow_1    -1.0
    f_8_1     flow_8    1.0
    f_8_1     cap_1_8   1.0
    f_1_9     flow_1    1.0
    f_1_9     flow_9    -1.0
    f_1_9     cap_1_9   1.0
    f_9_1     flow_1    -1.0
    f_9_1     flow_9    1.0
    f_9_1     cap_1_9   1.0
    f_1_10    flow_1    1.0
    f_1_10    flow_10   -1.0
    f_1_10    cap_1_10  1.0
    f_10_1    flow_1    -1.0
    f_10_1    flow_10   1.0
    f_10_1    cap_1_10  1.0
    f_1_11    flow_1    1.0
    f_1_11    flow_11   -1.0
    f_1_11    cap_1_11  1.0
    f_11_1    flow_1    -1.0
    f_11_1    flow_11   1.0
    f_11_1    cap_1_11  1.0
    f_1_12    flow_1    1.0
    f_1_12    flow_12   -1.0
    f_1_12    cap_1_12  1.0
    f_12_1    flow_1    -1.0
    f_12_1    flow_12   1.0
    f_12_1    cap_1_12  1.0
    f_1_13    flow_1    1.0
    f_1_13    flow_13   -1.0
    f_1_13    cap_1_13  1.0
    f_13_1    flow_1    -1.0
    f_13_1    flow_13   1.0
    f_13_1    cap_1_13  1.0
    f_1_14    flow_1    1.0
    f_1_14    flow_14   -1.0
    f_1_14    cap_1_14  1.0
    f_14_1    flow_1    -1.0
    f_14_1    flow_14   1.0
    f_14_1    cap_1_14  1.0
    f_1_15    flow_1    1.0
    f_1_15    flow_15   -1.0
    f_1_15    cap_1_15  1.0
    f_15_1    flow_1    -1.0
    f_15_1    flow_15   1.0
    f_15_1    cap_1_15  1.0
    f_1_16    flow_1    1.0
    f_1_16    flow_16   -1.0
    f_1_16    cap_1_16  1.0
    f_16_1    flow_1    -1.0
    f_16_1    flow_16   1.0
    f_16_1    cap_1_16  1.0
    f_1_17    flow_1    1.0
    f_1_17    flow_17   -1.0
    f_1_17    cap_1_17  1.0
    f_17_1    flow_1    -1.0
    f_17_1    flow_17   1.0
    f_17_1    cap_1_17  1.0
    f_1_18    flow_1    1.0
    f_1_18    flow_18   -1.0
    f_1_18    cap_1_18  1.0
    f_18_1    flow_1    -1.0
    f_18_1    flow_18   1.0
    f_18_1    cap_1_18  1.0
    f_1_19    flow_1    1.0
    f_1_19    flow_19   -1.0
    f_1_19    cap_1_19  1.0
    f_19_1    flow_1    -1.0
    f_19_1    flow_19   1.0
    f_19_1    cap_1_19  1.0
    f_2_3     flow_2    1.0
    f_2_3     flow_3    -1.0
    f_2_3     cap_2_3   1.0
    f_3_2     flow_2    -1.0
    f_3_2     flow_3    1.0
    f_3_2     cap_2_3   1.0
    f_2_4     flow_2    1.0
    f_2_4     flow_4    -1.0
    f_2_4     cap_2_4   1.0
    f_4_2     flow_2    -1.0
    f_4_2     flow_4    1.0
    f_4_2     cap_2_4   1.0
    f_2_5     flow_2    1.0
    f_2_5     flow_5    -1.0
    f_2_5     cap_2_5   1.0
    f_5_2     flow_2    -1.0
    f_5_2     flow_5    1.0
    f_5_2     cap_2_5   1.0
    f_2_6     flow_2    1.0
    f_2_6     flow_6    -1.0
    f_2_6     cap_2_6   1.0
    f_6_2     flow_2    -1.0
    f_6_2     flow_6    1.0
    f_6_2     cap_2_6   1.0
    f_2_7     flow_2    1.0
    f_2_7     flow_7    -1.0
    f_2_7     cap_2_7   1.0
    f_7_2     flow_2    -1.0
    f_7_2     flow_7    1.0
    f_7_2     cap_2_7   1.0
    f_2_8     flow_2    1.0
    f_2_8     flow_8    -1.0
    f_2_8     cap_2_8   1.0
    f_8_2     flow_2    -1.0
    f_8_2     flow_8    1.0
    f_8_2     cap_2_8   1.0
    f_2_9     flow_2    1.0
    f_2_9     flow_9    -1.0
    f_2_9     cap_2_9   1.0
    f_9_2     flow_2    -1.0
    f_9_2     flow_9    1.0
    f_9_2     cap_2_9   1.0
    f_2_10    flow_2    1.0
    f_2_10    flow_10   -1.0
    f_2_10    cap_2_10  1.0
    f_10_2    flow_2    -1.0
    f_10_2    flow_10   1.0
    f_10_2    cap_2_10  1.0
    f_2_11    flow_2    1.0
    f_2_11    flow_11   -1.0
    f_2_11    cap_2_11  1.0
    f_11_2    flow_2    -1.0
    f_11_2    flow_11   1.0
    f_11_2    cap_2_11  1.0
    f_2_12    flow_2    1.0
    f_2_12    flow_12   -1.0
    f_2_12    cap_2_12  1.0
    f_12_2    flow_2    -1.0
    f_12_2    flow_12   1.0
    f_12_2    cap_2_12  1.0
    f_2_13    flow_2    1.0
    f_2_13    flow_13   -1.0
    f_2_13    cap_2_13  1.0
    f_13_2    flow_2    -1.0
    f_13_2    flow_13   1.0
    f_13_2    cap_2_13  1.0
    f_2_14    flow_2    1.0
    f_2_14    flow_14   -1.0
    f_2_14    cap_2_14  1.0
    f_14_2    flow_2    -1.0
    f_14_2    flow_14   1.0
    f_14_2    cap_2_14  1.0
    f_2_15    flow_2    1.0
    f_2_15    flow_15   -1.0
    f_2_15    cap_2_15  1.0
    f_15_2    flow_2    -1.0
    f_15_2    flow_15   1.0
    f_15_2    cap_2_15  1.0
    f_2_16    flow_2    1.0
    f_2_16    flow_16   -1.0
    f_2_16    cap_2_16  1.0
    f_16_2    flow_2    -1.0
    f_16_2    flow_16   1.0
    f_16_2    cap_2_16  1.0
    f_2_17    flow_2    1.0
    f_2_17    flow_17   -1.0
    f_2_17    cap_2_17  1.0
    f_17_2    flow_2    -1.0
    f_17_2    flow_17   1.0
    f_17_2    cap_2_17  1.0
    f_2_18    flow_2    1.0
    f_2_18    flow_18   -1.0
    f_2_18    cap_2_18  1.0
    f_18_2    flow_2    -1.0
    f_18_2    flow_18   1.0
    f_18_2    cap_2_18  1.0
    f_2_19    flow_2    1.0
    f_2_19    flow_19   -1.0
    f_2_19    cap_2_19  1.0
    f_19_2    flow_2    -1.0
    f_19_2    flow_19   1.0
    f_19_2    cap_2_19  1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_5     flow_3    1.0
    f_3_5     flow_5    -1.0
    f_3_5     cap_3_5   1.0
    f_5_3     flow_3    -1.0
    f_5_3     flow_5    1.0
    f_5_3     cap_3_5   1.0
    f_3_6     flow_3    1.0
    f_3_6     flow_6    -1.0
    f_3_6     cap_3_6   1.0
    f_6_3     flow_3    -1.0
    f_6_3     flow_6    1.0
    f_6_3     cap_3_6   1.0
    f_3_7     flow_3    1.0
    f_3_7     flow_7    -1.0
    f_3_7     cap_3_7   1.0
    f_7_3     flow_3    -1.0
    f_7_3     flow_7    1.0
    f_7_3     cap_3_7   1.0
    f_3_8     flow_3    1.0
    f_3_8     flow_8    -1.0
    f_3_8     cap_3_8   1.0
    f_8_3     flow_3    -1.0
    f_8_3     flow_8    1.0
    f_8_3     cap_3_8   1.0
    f_3_9     flow_3    1.0
    f_3_9     flow_9    -1.0
    f_3_9     cap_3_9   1.0
    f_9_3     flow_3    -1.0
    f_9_3     flow_9    1.0
    f_9_3     cap_3_9   1.0
    f_3_10    flow_3    1.0
    f_3_10    flow_10   -1.0
    f_3_10    cap_3_10  1.0
    f_10_3    flow_3    -1.0
    f_10_3    flow_10   1.0
    f_10_3    cap_3_10  1.0
    f_3_11    flow_3    1.0
    f_3_11    flow_11   -1.0
    f_3_11    cap_3_11  1.0
    f_11_3    flow_3    -1.0
    f_11_3    flow_11   1.0
    f_11_3    cap_3_11  1.0
    f_3_12    flow_3    1.0
    f_3_12    flow_12   -1.0
    f_3_12    cap_3_12  1.0
    f_12_3    flow_3    -1.0
    f_12_3    flow_12   1.0
    f_12_3    cap_3_12  1.0
    f_3_13    flow_3    1.0
    f_3_13    flow_13   -1.0
    f_3_13    cap_3_13  1.0
    f_13_3    flow_3    -1.0
    f_13_3    flow_13   1.0
    f_13_3    cap_3_13  1.0
    f_3_14    flow_3    1.0
    f_3_14    flow_14   -1.0
    f_3_14    cap_3_14  1.0
    f_14_3    flow_3    -1.0
    f_14_3    flow_14   1.0
    f_14_3    cap_3_14  1.0
    f_3_15    flow_3    1.0
    f_3_15    flow_15   -1.0
    f_3_15    cap_3_15  1.0
    f_15_3    flow_3    -1.0
    f_15_3    flow_15   1.0
    f_15_3    cap_3_15  1.0
    f_3_16    flow_3    1.0
    f_3_16    flow_16   -1.0
    f_3_16    cap_3_16  1.0
    f_16_3    flow_3    -1.0
    f_16_3    flow_16   1.0
    f_16_3    cap_3_16  1.0
    f_3_17    flow_3    1.0
    f_3_17    flow_17   -1.0
    f_3_17    cap_3_17  1.0
    f_17_3    flow_3    -1.0
    f_17_3    flow_17   1.0
    f_17_3    cap_3_17  1.0
    f_3_18    flow_3    1.0
    f_3_18    flow_18   -1.0
    f_3_18    cap_3_18  1.0
    f_18_3    flow_3    -1.0
    f_18_3    flow_18   1.0
    f_18_3    cap_3_18  1.0
    f_3_19    flow_3    1.0
    f_3_19    flow_19   -1.0
    f_3_19    cap_3_19  1.0
    f_19_3    flow_3    -1.0
    f_19_3    flow_19   1.0
    f_19_3    cap_3_19  1.0
    f_4_5     flow_4    1.0
    f_4_5     flow_5    -1.0
    f_4_5     cap_4_5   1.0
    f_5_4     flow_4    -1.0
    f_5_4     flow_5    1.0
    f_5_4     cap_4_5   1.0
    f_4_6     flow_4    1.0
    f_4_6     flow_6    -1.0
    f_4_6     cap_4_6   1.0
    f_6_4     flow_4    -1.0
    f_6_4     flow_6    1.0
    f_6_4     cap_4_6   1.0
    f_4_7     flow_4    1.0
    f_4_7     flow_7    -1.0
    f_4_7     cap_4_7   1.0
    f_7_4     flow_4    -1.0
    f_7_4     flow_7    1.0
    f_7_4     cap_4_7   1.0
    f_4_8     flow_4    1.0
    f_4_8     flow_8    -1.0
    f_4_8     cap_4_8   1.0
    f_8_4     flow_4    -1.0
    f_8_4     flow_8    1.0
    f_8_4     cap_4_8   1.0
    f_4_9     flow_4    1.0
    f_4_9     flow_9    -1.0
    f_4_9     cap_4_9   1.0
    f_9_4     flow_4    -1.0
    f_9_4     flow_9    1.0
    f_9_4     cap_4_9   1.0
    f_4_10    flow_4    1.0
    f_4_10    flow_10   -1.0
    f_4_10    cap_4_10  1.0
    f_10_4    flow_4    -1.0
    f_10_4    flow_10   1.0
    f_10_4    cap_4_10  1.0
    f_4_11    flow_4    1.0
    f_4_11    flow_11   -1.0
    f_4_11    cap_4_11  1.0
    f_11_4    flow_4    -1.0
    f_11_4    flow_11   1.0
    f_11_4    cap_4_11  1.0
    f_4_12    flow_4    1.0
    f_4_12    flow_12   -1.0
    f_4_12    cap_4_12  1.0
    f_12_4    flow_4    -1.0
    f_12_4    flow_12   1.0
    f_12_4    cap_4_12  1.0
    f_4_13    flow_4    1.0
    f_4_13    flow_13   -1.0
    f_4_13    cap_4_13  1.0
    f_13_4    flow_4    -1.0
    f_13_4    flow_13   1.0
    f_13_4    cap_4_13  1.0
    f_4_14    flow_4    1.0
    f_4_14    flow_14   -1.0
    f_4_14    cap_4_14  1.0
    f_14_4    flow_4    -1.0
    f_14_4    flow_14   1.0
    f_14_4    cap_4_14  1.0
    f_4_15    flow_4    1.0
    f_4_15    flow_15   -1.0
    f_4_15    cap_4_15  1.0
    f_15_4    flow_4    -1.0
    f_15_4    flow_15   1.0
    f_15_4    cap_4_15  1.0
    f_4_16    flow_4    1.0
    f_4_16    flow_16   -1.0
    f_4_16    cap_4_16  1.0
    f_16_4    flow_4    -1.0
    f_16_4    flow_16   1.0
    f_16_4    cap_4_16  1.0
    f_4_17    flow_4    1.0
    f_4_17    flow_17   -1.0
    f_4_17    cap_4_17  1.0
    f_17_4    flow_4    -1.0
    f_17_4    flow_17   1.0
    f_17_4    cap_4_17  1.0
    f_4_18    flow_4    1.0
    f_4_18    flow_18   -1.0
    f_4_18    cap_4_18  1.0
    f_18_4    flow_4    -1.0
    f_18_4    flow_18   1.0
    f_18_4    cap_4_18  1.0
    f_4_19    flow_4    1.0
    f_4_19    flow_19   -1.0
    f_4_19    cap_4_19  1.0
    f_19_4    flow_4    -1.0
    f_19_4    flow_19   1.0
    f_19_4    cap_4_19  1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_7     flow_5    1.0
    f_5_7     flow_7    -1.0
    f_5_7     cap_5_7   1.0
    f_7_5     flow_5    -1.0
    f_7_5     flow_7    1.0
    f_7_5     cap_5_7   1.0
    f_5_8     flow_5    1.0
    f_5_8     flow_8    -1.0
    f_5_8     cap_5_8   1.0
    f_8_5     flow_5    -1.0
    f_8_5     flow_8    1.0
    f_8_5     cap_5_8   1.0
    f_5_9     flow_5    1.0
    f_5_9     flow_9    -1.0
    f_5_9     cap_5_9   1.0
    f_9_5     flow_5    -1.0
    f_9_5     flow_9    1.0
    f_9_5     cap_5_9   1.0
    f_5_10    flow_5    1.0
    f_5_10    flow_10   -1.0
    f_5_10    cap_5_10  1.0
    f_10_5    flow_5    -1.0
    f_10_5    flow_10   1.0
    f_10_5    cap_5_10  1.0
    f_5_11    flow_5    1.0
    f_5_11    flow_11   -1.0
    f_5_11    cap_5_11  1.0
    f_11_5    flow_5    -1.0
    f_11_5    flow_11   1.0
    f_11_5    cap_5_11  1.0
    f_5_12    flow_5    1.0
    f_5_12    flow_12   -1.0
    f_5_12    cap_5_12  1.0
    f_12_5    flow_5    -1.0
    f_12_5    flow_12   1.0
    f_12_5    cap_5_12  1.0
    f_5_13    flow_5    1.0
    f_5_13    flow_13   -1.0
    f_5_13    cap_5_13  1.0
    f_13_5    flow_5    -1.0
    f_13_5    flow_13   1.0
    f_13_5    cap_5_13  1.0
    f_5_14    flow_5    1.0
    f_5_14    flow_14   -1.0
    f_5_14    cap_5_14  1.0
    f_14_5    flow_5    -1.0
    f_14_5    flow_14   1.0
    f_14_5    cap_5_14  1.0
    f_5_15    flow_5    1.0
    f_5_15    flow_15   -1.0
    f_5_15    cap_5_15  1.0
    f_15_5    flow_5    -1.0
    f_15_5    flow_15   1.0
    f_15_5    cap_5_15  1.0
    f_5_16    flow_5    1.0
    f_5_16    flow_16   -1.0
    f_5_16    cap_5_16  1.0
    f_16_5    flow_5    -1.0
    f_16_5    flow_16   1.0
    f_16_5    cap_5_16  1.0
    f_5_17    flow_5    1.0
    f_5_17    flow_17   -1.0
    f_5_17    cap_5_17  1.0
    f_17_5    flow_5    -1.0
    f_17_5    flow_17   1.0
    f_17_5    cap_5_17  1.0
    f_5_18    flow_5    1.0
    f_5_18    flow_18   -1.0
    f_5_18    cap_5_18  1.0
    f_18_5    flow_5    -1.0
    f_18_5    flow_18   1.0
    f_18_5    cap_5_18  1.0
    f_5_19    flow_5    1.0
    f_5_19    flow_19   -1.0
    f_5_19    cap_5_19  1.0
    f_19_5    flow_5    -1.0
    f_19_5    flow_19   1.0
    f_19_5    cap_5_19  1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_8     flow_6    1.0
    f_6_8     flow_8    -1.0
    f_6_8     cap_6_8   1.0
    f_8_6     flow_6    -1.0
    f_8_6     flow_8    1.0
    f_8_6     cap_6_8   1.0
    f_6_9     flow_6    1.0
    f_6_9     flow_9    -1.0
    f_6_9     cap_6_9   1.0
    f_9_6     flow_6    -1.0
    f_9_6     flow_9    1.0
    f_9_6     cap_6_9   1.0
    f_6_10    flow_6    1.0
    f_6_10    flow_10   -1.0
    f_6_10    cap_6_10  1.0
    f_10_6    flow_6    -1.0
    f_10_6    flow_10   1.0
    f_10_6    cap_6_10  1.0
    f_6_11    flow_6    1.0
    f_6_11    flow_11   -1.0
    f_6_11    cap_6_11  1.0
    f_11_6    flow_6    -1.0
    f_11_6    flow_11   1.0
    f_11_6    cap_6_11  1.0
    f_6_12    flow_6    1.0
    f_6_12    flow_12   -1.0
    f_6_12    cap_6_12  1.0
    f_12_6    flow_6    -1.0
    f_12_6    flow_12   1.0
    f_12_6    cap_6_12  1.0
    f_6_13    flow_6    1.0
    f_6_13    flow_13   -1.0
    f_6_13    cap_6_13  1.0
    f_13_6    flow_6    -1.0
    f_13_6    flow_13   1.0
    f_13_6    cap_6_13  1.0
    f_6_14    flow_6    1.0
    f_6_14    flow_14   -1.0
    f_6_14    cap_6_14  1.0
    f_14_6    flow_6    -1.0
    f_14_6    flow_14   1.0
    f_14_6    cap_6_14  1.0
    f_6_15    flow_6    1.0
    f_6_15    flow_15   -1.0
    f_6_15    cap_6_15  1.0
    f_15_6    flow_6    -1.0
    f_15_6    flow_15   1.0
    f_15_6    cap_6_15  1.0
    f_6_16    flow_6    1.0
    f_6_16    flow_16   -1.0
    f_6_16    cap_6_16  1.0
    f_16_6    flow_6    -1.0
    f_16_6    flow_16   1.0
    f_16_6    cap_6_16  1.0
    f_6_17    flow_6    1.0
    f_6_17    flow_17   -1.0
    f_6_17    cap_6_17  1.0
    f_17_6    flow_6    -1.0
    f_17_6    flow_17   1.0
    f_17_6    cap_6_17  1.0
    f_6_18    flow_6    1.0
    f_6_18    flow_18   -1.0
    f_6_18    cap_6_18  1.0
    f_18_6    flow_6    -1.0
    f_18_6    flow_18   1.0
    f_18_6    cap_6_18  1.0
    f_6_19    flow_6    1.0
    f_6_19    flow_19   -1.0
    f_6_19    cap_6_19  1.0
    f_19_6    flow_6    -1.0
    f_19_6    flow_19   1.0
    f_19_6    cap_6_19  1.0
    f_7_8     flow_7    1.0
    f_7_8     flow_8    -1.0
    f_7_8     cap_7_8   1.0
    f_8_7     flow_7    -1.0
    f_8_7     flow_8    1.0
    f_8_7     cap_7_8   1.0
    f_7_9     flow_7    1.0
    f_7_9     flow_9    -1.0
    f_7_9     cap_7_9   1.0
    f_9_7     flow_7    -1.0
    f_9_7     flow_9    1.0
    f_9_7     cap_7_9   1.0
    f_7_10    flow_7    1.0
    f_7_10    flow_10   -1.0
    f_7_10    cap_7_10  1.0
    f_10_7    flow_7    -1.0
    f_10_7    flow_10   1.0
    f_10_7    cap_7_10  1.0
    f_7_11    flow_7    1.0
    f_7_11    flow_11   -1.0
    f_7_11    cap_7_11  1.0
    f_11_7    flow_7    -1.0
    f_11_7    flow_11   1.0
    f_11_7    cap_7_11  1.0
    f_7_12    flow_7    1.0
    f_7_12    flow_12   -1.0
    f_7_12    cap_7_12  1.0
    f_12_7    flow_7    -1.0
    f_12_7    flow_12   1.0
    f_12_7    cap_7_12  1.0
    f_7_13    flow_7    1.0
    f_7_13    flow_13   -1.0
    f_7_13    cap_7_13  1.0
    f_13_7    flow_7    -1.0
    f_13_7    flow_13   1.0
    f_13_7    cap_7_13  1.0
    f_7_14    flow_7    1.0
    f_7_14    flow_14   -1.0
    f_7_14    cap_7_14  1.0
    f_14_7    flow_7    -1.0
    f_14_7    flow_14   1.0
    f_14_7    cap_7_14  1.0
    f_7_15    flow_7    1.0
    f_7_15    flow_15   -1.0
    f_7_15    cap_7_15  1.0
    f_15_7    flow_7    -1.0
    f_15_7    flow_15   1.0
    f_15_7    cap_7_15  1.0
    f_7_16    flow_7    1.0
    f_7_16    flow_16   -1.0
    f_7_16    cap_7_16  1.0
    f_16_7    flow_7    -1.0
    f_16_7    flow_16   1.0
    f_16_7    cap_7_16  1.0
    f_7_17    flow_7    1.0
    f_7_17    flow_17   -1.0
    f_7_17    cap_7_17  1.0
    f_17_7    flow_7    -1.0
    f_17_7    flow_17   1.0
    f_17_7    cap_7_17  1.0
    f_7_18    flow_7    1.0
    f_7_18    flow_18   -1.0
    f_7_18    cap_7_18  1.0
    f_18_7    flow_7    -1.0
    f_18_7    flow_18   1.0
    f_18_7    cap_7_18  1.0
    f_7_19    flow_7    1.0
    f_7_19    flow_19   -1.0
    f_7_19    cap_7_19  1.0
    f_19_7    flow_7    -1.0
    f_19_7    flow_19   1.0
    f_19_7    cap_7_19  1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
    f_8_10    flow_8    1.0
    f_8_10    flow_10   -1.0
    f_8_10    cap_8_10  1.0
    f_10_8    flow_8    -1.0
    f_10_8    flow_10   1.0
    f_10_8    cap_8_10  1.0
    f_8_11    flow_8    1.0
    f_8_11    flow_11   -1.0
    f_8_11    cap_8_11  1.0
    f_11_8    flow_8    -1.0
    f_11_8    flow_11   1.0
    f_11_8    cap_8_11  1.0
    f_8_12    flow_8    1.0
    f_8_12    flow_12   -1.0
    f_8_12    cap_8_12  1.0
    f_12_8    flow_8    -1.0
    f_12_8    flow_12   1.0
    f_12_8    cap_8_12  1.0
    f_8_13    flow_8    1.0
    f_8_13    flow_13   -1.0
    f_8_13    cap_8_13  1.0
    f_13_8    flow_8    -1.0
    f_13_8    flow_13   1.0
    f_13_8    cap_8_13  1.0
    f_8_14    flow_8    1.0
    f_8_14    flow_14   -1.0
    f_8_14    cap_8_14  1.0
    f_14_8    flow_8    -1.0
    f_14_8    flow_14   1.0
    f_14_8    cap_8_14  1.0
    f_8_15    flow_8    1.0
    f_8_15    flow_15   -1.0
    f_8_15    cap_8_15  1.0
    f_15_8    flow_8    -1.0
    f_15_8    flow_15   1.0
    f_15_8    cap_8_15  1.0
    f_8_16    flow_8    1.0
    f_8_16    flow_16   -1.0
    f_8_16    cap_8_16  1.0
    f_16_8    flow_8    -1.0
    f_16_8    flow_16   1.0
    f_16_8    cap_8_16  1.0
    f_8_17    flow_8    1.0
    f_8_17    flow_17   -1.0
    f_8_17    cap_8_17  1.0
    f_17_8    flow_8    -1.0
    f_17_8    flow_17   1.0
    f_17_8    cap_8_17  1.0
    f_8_18    flow_8    1.0
    f_8_18    flow_18   -1.0
    f_8_18    cap_8_18  1.0
    f_18_8    flow_8    -1.0
    f_18_8    flow_18   1.0
    f_18_8    cap_8_18  1.0
    f_8_19    flow_8    1.0
    f_8_19    flow_19   -1.0
    f_8_19    cap_8_19  1.0
    f_19_8    flow_8    -1.0
    f_19_8    flow_19   1.0
    f_19_8    cap_8_19  1.0
    f_9_10    flow_9    1.0
    f_9_10    flow_10   -1.0
    f_9_10    cap_9_10  1.0
    f_10_9    flow_9    -1.0
    f_10_9    flow_10   1.0
    f_10_9    cap_9_10  1.0
    f_9_11    flow_9    1.0
    f_9_11    flow_11   -1.0
    f_9_11    cap_9_11  1.0
    f_11_9    flow_9    -1.0
    f_11_9    flow_11   1.0
    f_11_9    cap_9_11  1.0
    f_9_12    flow_9    1.0
    f_9_12    flow_12   -1.0
    f_9_12    cap_9_12  1.0
    f_12_9    flow_9    -1.0
    f_12_9    flow_12   1.0
    f_12_9    cap_9_12  1.0
    f_9_13    flow_9    1.0
    f_9_13    flow_13   -1.0
    f_9_13    cap_9_13  1.0
    f_13_9    flow_9    -1.0
    f_13_9    flow_13   1.0
    f_13_9    cap_9_13  1.0
    f_9_14    flow_9    1.0
    f_9_14    flow_14   -1.0
    f_9_14    cap_9_14  1.0
    f_14_9    flow_9    -1.0
    f_14_9    flow_14   1.0
    f_14_9    cap_9_14  1.0
    f_9_15    flow_9    1.0
    f_9_15    flow_15   -1.0
    f_9_15    cap_9_15  1.0
    f_15_9    flow_9    -1.0
    f_15_9    flow_15   1.0
    f_15_9    cap_9_15  1.0
    f_9_16    flow_9    1.0
    f_9_16    flow_16   -1.0
    f_9_16    cap_9_16  1.0
    f_16_9    flow_9    -1.0
    f_16_9    flow_16   1.0
    f_16_9    cap_9_16  1.0
    f_9_17    flow_9    1.0
    f_9_17    flow_17   -1.0
    f_9_17    cap_9_17  1.0
    f_17_9    flow_9    -1.0
    f_17_9    flow_17   1.0
    f_17_9    cap_9_17  1.0
    f_9_18    flow_9    1.0
    f_9_18    flow_18   -1.0
    f_9_18    cap_9_18  1.0
    f_18_9    flow_9    -1.0
    f_18_9    flow_18   1.0
    f_18_9    cap_9_18  1.0
    f_9_19    flow_9    1.0
    f_9_19    flow_19   -1.0
    f_9_19    cap_9_19  1.0
    f_19_9    flow_9    -1.0
    f_19_9    flow_19   1.0
    f_19_9    cap_9_19  1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
    f_10_12   flow_10   1.0
    f_10_12   flow_12   -1.0
    f_10_12   cap_10_12  1.0
    f_12_10   flow_10   -1.0
    f_12_10   flow_12   1.0
    f_12_10   cap_10_12  1.0
    f_10_13   flow_10   1.0
    f_10_13   flow_13   -1.0
    f_10_13   cap_10_13  1.0
    f_13_10   flow_10   -1.0
    f_13_10   flow_13   1.0
    f_13_10   cap_10_13  1.0
    f_10_14   flow_10   1.0
    f_10_14   flow_14   -1.0
    f_10_14   cap_10_14  1.0
    f_14_10   flow_10   -1.0
    f_14_10   flow_14   1.0
    f_14_10   cap_10_14  1.0
    f_10_15   flow_10   1.0
    f_10_15   flow_15   -1.0
    f_10_15   cap_10_15  1.0
    f_15_10   flow_10   -1.0
    f_15_10   flow_15   1.0
    f_15_10   cap_10_15  1.0
    f_10_16   flow_10   1.0
    f_10_16   flow_16   -1.0
    f_10_16   cap_10_16  1.0
    f_16_10   flow_10   -1.0
    f_16_10   flow_16   1.0
    f_16_10   cap_10_16  1.0
    f_10_17   flow_10   1.0
    f_10_17   flow_17   -1.0
    f_10_17   cap_10_17  1.0
    f_17_10   flow_10   -1.0
    f_17_10   flow_17   1.0
    f_17_10   cap_10_17  1.0
    f_10_18   flow_10   1.0
    f_10_18   flow_18   -1.0
    f_10_18   cap_10_18  1.0
    f_18_10   flow_10   -1.0
    f_18_10   flow_18   1.0
    f_18_10   cap_10_18  1.0
    f_10_19   flow_10   1.0
    f_10_19   flow_19   -1.0
    f_10_19   cap_10_19  1.0
    f_19_10   flow_10   -1.0
    f_19_10   flow_19   1.0
    f_19_10   cap_10_19  1.0
    f_11_12   flow_11   1.0
    f_11_12   flow_12   -1.0
    f_11_12   cap_11_12  1.0
    f_12_11   flow_11   -1.0
    f_12_11   flow_12   1.0
    f_12_11   cap_11_12  1.0
    f_11_13   flow_11   1.0
    f_11_13   flow_13   -1.0
    f_11_13   cap_11_13  1.0
    f_13_11   flow_11   -1.0
    f_13_11   flow_13   1.0
    f_13_11   cap_11_13  1.0
    f_11_14   flow_11   1.0
    f_11_14   flow_14   -1.0
    f_11_14   cap_11_14  1.0
    f_14_11   flow_11   -1.0
    f_14_11   flow_14   1.0
    f_14_11   cap_11_14  1.0
    f_11_15   flow_11   1.0
    f_11_15   flow_15   -1.0
    f_11_15   cap_11_15  1.0
    f_15_11   flow_11   -1.0
    f_15_11   flow_15   1.0
    f_15_11   cap_11_15  1.0
    f_11_16   flow_11   1.0
    f_11_16   flow_16   -1.0
    f_11_16   cap_11_16  1.0
    f_16_11   flow_11   -1.0
    f_16_11   flow_16   1.0
    f_16_11   cap_11_16  1.0
    f_11_17   flow_11   1.0
    f_11_17   flow_17   -1.0
    f_11_17   cap_11_17  1.0
    f_17_11   flow_11   -1.0
    f_17_11   flow_17   1.0
    f_17_11   cap_11_17  1.0
    f_11_18   flow_11   1.0
    f_11_18   flow_18   -1.0
    f_11_18   cap_11_18  1.0
    f_18_11   flow_11   -1.0
    f_18_11   flow_18   1.0
    f_18_11   cap_11_18  1.0
    f_11_19   flow_11   1.0
    f_11_19   flow_19   -1.0
    f_11_19   cap_11_19  1.0
    f_19_11   flow_11   -1.0
    f_19_11   flow_19   1.0
    f_19_11   cap_11_19  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_12_14   flow_12   1.0
    f_12_14   flow_14   -1.0
    f_12_14   cap_12_14  1.0
    f_14_12   flow_12   -1.0
    f_14_12   flow_14   1.0
    f_14_12   cap_12_14  1.0
    f_12_15   flow_12   1.0
    f_12_15   flow_15   -1.0
    f_12_15   cap_12_15  1.0
    f_15_12   flow_12   -1.0
    f_15_12   flow_15   1.0
    f_15_12   cap_12_15  1.0
    f_12_16   flow_12   1.0
    f_12_16   flow_16   -1.0
    f_12_16   cap_12_16  1.0
    f_16_12   flow_12   -1.0
    f_16_12   flow_16   1.0
    f_16_12   cap_12_16  1.0
    f_12_17   flow_12   1.0
    f_12_17   flow_17   -1.0
    f_12_17   cap_12_17  1.0
    f_17_12   flow_12   -1.0
    f_17_12   flow_17   1.0
    f_17_12   cap_12_17  1.0
    f_12_18   flow_12   1.0
    f_12_18   flow_18   -1.0
    f_12_18   cap_12_18  1.0
    f_18_12   flow_12   -1.0
    f_18_12   flow_18   1.0
    f_18_12   cap_12_18  1.0
    f_12_19   flow_12   1.0
    f_12_19   flow_19   -1.0
    f_12_19   cap_12_19  1.0
    f_19_12   flow_12   -1.0
    f_19_12   flow_19   1.0
    f_19_12   cap_12_19  1.0
    f_13_14   flow_13   1.0
    f_13_14   flow_14   -1.0
    f_13_14   cap_13_14  1.0
    f_14_13   flow_13   -1.0
    f_14_13   flow_14   1.0
    f_14_13   cap_13_14  1.0
    f_13_15   flow_13   1.0
    f_13_15   flow_15   -1.0
    f_13_15   cap_13_15  1.0
    f_15_13   flow_13   -1.0
    f_15_13   flow_15   1.0
    f_15_13   cap_13_15  1.0
    f_13_16   flow_13   1.0
    f_13_16   flow_16   -1.0
    f_13_16   cap_13_16  1.0
    f_16_13   flow_13   -1.0
    f_16_13   flow_16   1.0
    f_16_13   cap_13_16  1.0
    f_13_17   flow_13   1.0
    f_13_17   flow_17   -1.0
    f_13_17   cap_13_17  1.0
    f_17_13   flow_13   -1.0
    f_17_13   flow_17   1.0
    f_17_13   cap_13_17  1.0
    f_13_18   flow_13   1.0
    f_13_18   flow_18   -1.0
    f_13_18   cap_13_18  1.0
    f_18_13   flow_13   -1.0
    f_18_13   flow_18   1.0
    f_18_13   cap_13_18  1.0
    f_13_19   flow_13   1.0
    f_13_19   flow_19   -1.0
    f_13_19   cap_13_19  1.0
    f_19_13   flow_13   -1.0
    f_19_13   flow_19   1.0
    f_19_13   cap_13_19  1.0
    f_14_15   flow_14   1.0
    f_14_15   flow_15   -1.0
    f_14_15   cap_14_15  1.0
    f_15_14   flow_14   -1.0
    f_15_14   flow_15   1.0
    f_15_14   cap_14_15  1.0
    f_14_16   flow_14   1.0
    f_14_16   flow_16   -1.0
    f_14_16   cap_14_16  1.0
    f_16_14   flow_14   -1.0
    f_16_14   flow_16   1.0
    f_16_14   cap_14_16  1.0
    f_14_17   flow_14   1.0
    f_14_17   flow_17   -1.0
    f_14_17   cap_14_17  1.0
    f_17_14   flow_14   -1.0
    f_17_14   flow_17   1.0
    f_17_14   cap_14_17  1.0
    f_14_18   flow_14   1.0
    f_14_18   flow_18   -1.0
    f_14_18   cap_14_18  1.0
    f_18_14   flow_14   -1.0
    f_18_14   flow_18   1.0
    f_18_14   cap_14_18  1.0
    f_14_19   flow_14   1.0
    f_14_19   flow_19   -1.0
    f_14_19   cap_14_19  1.0
    f_19_14   flow_14   -1.0
    f_19_14   flow_19   1.0
    f_19_14   cap_14_19  1.0
    f_15_16   flow_15   1.0
    f_15_16   flow_16   -1.0
    f_15_16   cap_15_16  1.0
    f_16_15   flow_15   -1.0
    f_16_15   flow_16   1.0
    f_16_15   cap_15_16  1.0
    f_15_17   flow_15   1.0
    f_15_17   flow_17   -1.0
    f_15_17   cap_15_17  1.0
    f_17_15   flow_15   -1.0
    f_17_15   flow_17   1.0
    f_17_15   cap_15_17  1.0
    f_15_18   flow_15   1.0
    f_15_18   flow_18   -1.0
    f_15_18   cap_15_18  1.0
    f_18_15   flow_15   -1.0
    f_18_15   flow_18   1.0
    f_18_15   cap_15_18  1.0
    f_15_19   flow_15   1.0
    f_15_19   flow_19   -1.0
    f_15_19   cap_15_19  1.0
    f_19_15   flow_15   -1.0
    f_19_15   flow_19   1.0
    f_19_15   cap_15_19  1.0
    f_16_17   flow_16   1.0
    f_16_17   flow_17   -1.0
    f_16_17   cap_16_17  1.0
    f_17_16   flow_16   -1.0
    f_17_16   flow_17   1.0
    f_17_16   cap_16_17  1.0
    f_16_18   flow_16   1.0
    f_16_18   flow_18   -1.0
    f_16_18   cap_16_18  1.0
    f_18_16   flow_16   -1.0
    f_18_16   flow_18   1.0
    f_18_16   cap_16_18  1.0
    f_16_19   flow_16   1.0
    f_16_19   flow_19   -1.0
    f_16_19   cap_16_19  1.0
    f_19_16   flow_16   -1.0
    f_19_16   flow_19   1.0
    f_19_16   cap_16_19  1.0
    f_17_18   flow_17   1.0
    f_17_18   flow_18   -1.0
    f_17_18   cap_17_18  1.0
    f_18_17   flow_17   -1.0
    f_18_17   flow_18   1.0
    f_18_17   cap_17_18  1.0
    f_17_19   flow_17   1.0
    f_17_19   flow_19   -1.0
    f_17_19   cap_17_19  1.0
    f_19_17   flow_17   -1.0
    f_19_17   flow_19   1.0
    f_19_17   cap_17_19  1.0
    f_18_19   flow_18   1.0
    f_18_19   flow_19   -1.0
    f_18_19   cap_18_19  1.0
    f_19_18   flow_18   -1.0
    f_19_18   flow_19   1.0
    f_19_18   cap_18_19  1.0
RHS
    RHS       flow_0    10
    RHS       flow_3    -1
    RHS       flow_4    -1
    RHS       flow_6    -1
    RHS       flow_8    -1
    RHS       flow_9    -1
    RHS       flow_10   -1
    RHS       flow_14   -1
    RHS       flow_15   -1
    RHS       flow_17   -1
    RHS       flow_18   -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_2
 BV BOUND     x_0_3
 BV BOUND     x_0_4
 BV BOUND     x_0_5
 BV BOUND     x_0_6
 BV BOUND     x_0_7
 BV BOUND     x_0_8
 BV BOUND     x_0_9
 BV BOUND     x_0_10
 BV BOUND     x_0_11
 BV BOUND     x_0_12
 BV BOUND     x_0_13
 BV BOUND     x_0_14
 BV BOUND     x_0_15
 BV BOUND     x_0_16
 BV BOUND     x_0_17
 BV BOUND     x_0_18
 BV BOUND     x_0_19
 BV BOUND     x_1_2
 BV BOUND     x_1_3
 BV BOUND     x_1_4
 BV BOUND     x_1_5
 BV BOUND     x_1_6
 BV BOUND     x_1_7
 BV BOUND     x_1_8
 BV BOUND     x_1_9
 BV BOUND     x_1_10
 BV BOUND     x_1_11
 BV BOUND     x_1_12
 BV BOUND     x_1_13
 BV BOUND     x_1_14
 BV BOUND     x_1_15
 BV BOUND     x_1_16
 BV BOUND     x_1_17
 BV BOUND     x_1_18
 BV BOUND     x_1_19
 BV BOUND     x_2_3
 BV BOUND     x_2_4
 BV BOUND     x_2_5
 BV BOUND     x_2_6
 BV BOUND     x_2_7
 BV BOUND     x_2_8
 BV BOUND     x_2_9
 BV BOUND     x_2_10
 BV BOUND     x_2_11
 BV BOUND     x_2_12
 BV BOUND     x_2_13
 BV BOUND     x_2_14
 BV BOUND     x_2_15
 BV BOUND     x_2_16
 BV BOUND     x_2_17
 BV BOUND     x_2_18
 BV BOUND     x_2_19
 BV BOUND     x_3_4
 BV BOUND     x_3_5
 BV BOUND     x_3_6
 BV BOUND     x_3_7
 BV BOUND     x_3_8
 BV BOUND     x_3_9
 BV BOUND     x_3_10
 BV BOUND     x_3_11
 BV BOUND     x_3_12
 BV BOUND     x_3_13
 BV BOUND     x_3_14
 BV BOUND     x_3_15
 BV BOUND     x_3_16
 BV BOUND     x_3_17
 BV BOUND     x_3_18
 BV BOUND     x_3_19
 BV BOUND     x_4_5
 BV BOUND     x_4_6
 BV BOUND     x_4_7
 BV BOUND     x_4_8
 BV BOUND     x_4_9
 BV BOUND     x_4_10
 BV BOUND     x_4_11
 BV BOUND     x_4_12
 BV BOUND     x_4_13
 BV BOUND     x_4_14
 BV BOUND     x_4_15
 BV BOUND     x_4_16
 BV BOUND     x_4_17
 BV BOUND     x_4_18
 BV BOUND     x_4_19
 BV BOUND     x_5_6
 BV BOUND     x_5_7
 BV BOUND     x_5_8
 BV BOUND     x_5_9
 BV BOUND     x_5_10
 BV BOUND     x_5_11
 BV BOUND     x_5_12
 BV BOUND     x_5_13
 BV BOUND     x_5_14
 BV BOUND     x_5_15
 BV BOUND     x_5_16
 BV BOUND     x_5_17
 BV BOUND     x_5_18
 BV BOUND     x_5_19
 BV BOUND     x_6_7
 BV BOUND     x_6_8
 BV BOUND     x_6_9
 BV BOUND     x_6_10
 BV BOUND     x_6_11
 BV BOUND     x_6_12
 BV BOUND     x_6_13
 BV BOUND     x_6_14
 BV BOUND     x_6_15
 BV BOUND     x_6_16
 BV BOUND     x_6_17
 BV BOUND     x_6_18
 BV BOUND     x_6_19
 BV BOUND     x_7_8
 BV BOUND     x_7_9
 BV BOUND     x_7_10
 BV BOUND     x_7_11
 BV BOUND     x_7_12
 BV BOUND     x_7_13
 BV BOUND     x_7_14
 BV BOUND     x_7_15
 BV BOUND     x_7_16
 BV BOUND     x_7_17
 BV BOUND     x_7_18
 BV BOUND     x_7_19
 BV BOUND     x_8_9
 BV BOUND     x_8_10
 BV BOUND     x_8_11
 BV BOUND     x_8_12
 BV BOUND     x_8_13
 BV BOUND     x_8_14
 BV BOUND     x_8_15
 BV BOUND     x_8_16
 BV BOUND     x_8_17
 BV BOUND     x_8_18
 BV BOUND     x_8_19
 BV BOUND     x_9_10
 BV BOUND     x_9_11
 BV BOUND     x_9_12
 BV BOUND     x_9_13
 BV BOUND     x_9_14
 BV BOUND     x_9_15
 BV BOUND     x_9_16
 BV BOUND     x_9_17
 BV BOUND     x_9_18
 BV BOUND     x_9_19
 BV BOUND     x_10_11
 BV BOUND     x_10_12
 BV BOUND     x_10_13
 BV BOUND     x_10_14
 BV BOUND     x_10_15
 BV BOUND     x_10_16
 BV BOUND     x_10_17
 BV BOUND     x_10_18
 BV BOUND     x_10_19
 BV BOUND     x_11_12
 BV BOUND     x_11_13
 BV BOUND     x_11_14
 BV BOUND     x_11_15
 BV BOUND     x_11_16
 BV BOUND     x_11_17
 BV BOUND     x_11_18
 BV BOUND     x_11_19
 BV BOUND     x_12_13
 BV BOUND     x_12_14
 BV BOUND     x_12_15
 BV BOUND     x_12_16
 BV BOUND     x_12_17
 BV BOUND     x_12_18
 BV BOUND     x_12_19
 BV BOUND     x_13_14
 BV BOUND     x_13_15
 BV BOUND     x_13_16
 BV BOUND     x_13_17
 BV BOUND     x_13_18
 BV BOUND     x_13_19
 BV BOUND     x_14_15
 BV BOUND     x_14_16
 BV BOUND     x_14_17
 BV BOUND     x_14_18
 BV BOUND     x_14_19
 BV BOUND     x_15_16
 BV BOUND     x_15_17
 BV BOUND     x_15_18
 BV BOUND     x_15_19
 BV BOUND     x_16_17
 BV BOUND     x_16_18
 BV BOUND     x_16_19
 BV BOUND     x_17_18
 BV BOUND     x_17_19
 BV BOUND     x_18_19
 UP BOUND     f_0_1     10
 UP BOUND     f_1_0     10
 UP BOUND     f_0_2     10
 UP BOUND     f_2_0     10
 UP BOUND     f_0_3     10
 UP BOUND     f_3_0     10
 UP BOUND     f_0_4     10
 UP BOUND     f_4_0     10
 UP BOUND     f_0_5     10
 UP BOUND     f_5_0     10
 UP BOUND     f_0_6     10
 UP BOUND     f_6_0     10
 UP BOUND     f_0_7     10
 UP BOUND     f_7_0     10
 UP BOUND     f_0_8     10
 UP BOUND     f_8_0     10
 UP BOUND     f_0_9     10
 UP BOUND     f_9_0     10
 UP BOUND     f_0_10    10
 UP BOUND     f_10_0    10
 UP BOUND     f_0_11    10
 UP BOUND     f_11_0    10
 UP BOUND     f_0_12    10
 UP BOUND     f_12_0    10
 UP BOUND     f_0_13    10
 UP BOUND     f_13_0    10
 UP BOUND     f_0_14    10
 UP BOUND     f_14_0    10
 UP BOUND     f_0_15    10
 UP BOUND     f_15_0    10
 UP BOUND     f_0_16    10
 UP BOUND     f_16_0    10
 UP BOUND     f_0_17    10
 UP BOUND     f_17_0    10
 UP BOUND     f_0_18    10
 UP BOUND     f_18_0    10
 UP BOUND     f_0_19    10
 UP BOUND     f_19_0    10
 UP BOUND     f_1_2     10
 UP BOUND     f_2_1     10
 UP BOUND     f_1_3     10
 UP BOUND     f_3_1     10
 UP BOUND     f_1_4     10
 UP BOUND     f_4_1     10
 UP BOUND     f_1_5     10
 UP BOUND     f_5_1     10
 UP BOUND     f_1_6     10
 UP BOUND     f_6_1     10
 UP BOUND     f_1_7     10
 UP BOUND     f_7_1     10
 UP BOUND     f_1_8     10
 UP BOUND     f_8_1     10
 UP BOUND     f_1_9     10
 UP BOUND     f_9_1     10
 UP BOUND     f_1_10    10
 UP BOUND     f_10_1    10
 UP BOUND     f_1_11    10
 UP BOUND     f_11_1    10
 UP BOUND     f_1_12    10
 UP BOUND     f_12_1    10
 UP BOUND     f_1_13    10
 UP BOUND     f_13_1    10
 UP BOUND     f_1_14    10
 UP BOUND     f_14_1    10
 UP BOUND     f_1_15    10
 UP BOUND     f_15_1    10
 UP BOUND     f_1_16    10
 UP BOUND     f_16_1    10
 UP BOUND     f_1_17    10
 UP BOUND     f_17_1    10
 UP BOUND     f_1_18    10
 UP BOUND     f_18_1    10
 UP BOUND     f_1_19    10
 UP BOUND     f_19_1    10
 UP BOUND     f_2_3     10
 UP BOUND     f_3_2     10
 UP BOUND     f_2_4     10
 UP BOUND     f_4_2     10
 UP BOUND     f_2_5     10
 UP BOUND     f_5_2     10
 UP BOUND     f_2_6     10
 UP BOUND     f_6_2     10
 UP BOUND     f_2_7     10
 UP BOUND     f_7_2     10
 UP BOUND     f_2_8     10
 UP BOUND     f_8_2     10
 UP BOUND     f_2_9     10
 UP BOUND     f_9_2     10
 UP BOUND     f_2_10    10
 UP BOUND     f_10_2    10
 UP BOUND     f_2_11    10
 UP BOUND     f_11_2    10
 UP BOUND     f_2_12    10
 UP BOUND     f_12_2    10
 UP BOUND     f_2_13    10
 UP BOUND     f_13_2    10
 UP BOUND     f_2_14    10
 UP BOUND     f_14_2    10
 UP BOUND     f_2_15    10
 UP BOUND     f_15_2    10
 UP BOUND     f_2_16    10
 UP BOUND     f_16_2    10
 UP BOUND     f_2_17    10
 UP BOUND     f_17_2    10
 UP BOUND     f_2_18    10
 UP BOUND     f_18_2    10
 UP BOUND     f_2_19    10
 UP BOUND     f_19_2    10
 UP BOUND     f_3_4     10
 UP BOUND     f_4_3     10
 UP BOUND     f_3_5     10
 UP BOUND     f_5_3     10
 UP BOUND     f_3_6     10
 UP BOUND     f_6_3     10
 UP BOUND     f_3_7     10
 UP BOUND     f_7_3     10
 UP BOUND     f_3_8     10
 UP BOUND     f_8_3     10
 UP BOUND     f_3_9     10
 UP BOUND     f_9_3     10
 UP BOUND     f_3_10    10
 UP BOUND     f_10_3    10
 UP BOUND     f_3_11    10
 UP BOUND     f_11_3    10
 UP BOUND     f_3_12    10
 UP BOUND     f_12_3    10
 UP BOUND     f_3_13    10
 UP BOUND     f_13_3    10
 UP BOUND     f_3_14    10
 UP BOUND     f_14_3    10
 UP BOUND     f_3_15    10
 UP BOUND     f_15_3    10
 UP BOUND     f_3_16    10
 UP BOUND     f_16_3    10
 UP BOUND     f_3_17    10
 UP BOUND     f_17_3    10
 UP BOUND     f_3_18    10
 UP BOUND     f_18_3    10
 UP BOUND     f_3_19    10
 UP BOUND     f_19_3    10
 UP BOUND     f_4_5     10
 UP BOUND     f_5_4     10
 UP BOUND     f_4_6     10
 UP BOUND     f_6_4     10
 UP BOUND     f_4_7     10
 UP BOUND     f_7_4     10
 UP BOUND     f_4_8     10
 UP BOUND     f_8_4     10
 UP BOUND     f_4_9     10
 UP BOUND     f_9_4     10
 UP BOUND     f_4_10    10
 UP BOUND     f_10_4    10
 UP BOUND     f_4_11    10
 UP BOUND     f_11_4    10
 UP BOUND     f_4_12    10
 UP BOUND     f_12_4    10
 UP BOUND     f_4_13    10
 UP BOUND     f_13_4    10
 UP BOUND     f_4_14    10
 UP BOUND     f_14_4    10
 UP BOUND     f_4_15    10
 UP BOUND     f_15_4    10
 UP BOUND     f_4_16    10
 UP BOUND     f_16_4    10
 UP BOUND     f_4_17    10
 UP BOUND     f_17_4    10
 UP BOUND     f_4_18    10
 UP BOUND     f_18_4    10
 UP BOUND     f_4_19    10
 UP BOUND     f_19_4    10
 UP BOUND     f_5_6     10
 UP BOUND     f_6_5     10
 UP BOUND     f_5_7     10
 UP BOUND     f_7_5     10
 UP BOUND     f_5_8     10
 UP BOUND     f_8_5     10
 UP BOUND     f_5_9     10
 UP BOUND     f_9_5     10
 UP BOUND     f_5_10    10
 UP BOUND     f_10_5    10
 UP BOUND     f_5_11    10
 UP BOUND     f_11_5    10
 UP BOUND     f_5_12    10
 UP BOUND     f_12_5    10
 UP BOUND     f_5_13    10
 UP BOUND     f_13_5    10
 UP BOUND     f_5_14    10
 UP BOUND     f_14_5    10
 UP BOUND     f_5_15    10
 UP BOUND     f_15_5    10
 UP BOUND     f_5_16    10
 UP BOUND     f_16_5    10
 UP BOUND     f_5_17    10
 UP BOUND     f_17_5    10
 UP BOUND     f_5_18    10
 UP BOUND     f_18_5    10
 UP BOUND     f_5_19    10
 UP BOUND     f_19_5    10
 UP BOUND     f_6_7     10
 UP BOUND     f_7_6     10
 UP BOUND     f_6_8     10
 UP BOUND     f_8_6     10
 UP BOUND     f_6_9     10
 UP BOUND     f_9_6     10
 UP BOUND     f_6_10    10
 UP BOUND     f_10_6    10
 UP BOUND     f_6_11    10
 UP BOUND     f_11_6    10
 UP BOUND     f_6_12    10
 UP BOUND     f_12_6    10
 UP BOUND     f_6_13    10
 UP BOUND     f_13_6    10
 UP BOUND     f_6_14    10
 UP BOUND     f_14_6    10
 UP BOUND     f_6_15    10
 UP BOUND     f_15_6    10
 UP BOUND     f_6_16    10
 UP BOUND     f_16_6    10
 UP BOUND     f_6_17    10
 UP BOUND     f_17_6    10
 UP BOUND     f_6_18    10
 UP BOUND     f_18_6    10
 UP BOUND     f_6_19    10
 UP BOUND     f_19_6    10
 UP BOUND     f_7_8     10
 UP BOUND     f_8_7     10
 UP BOUND     f_7_9     10
 UP BOUND     f_9_7     10
 UP BOUND     f_7_10    10
 UP BOUND     f_10_7    10
 UP BOUND     f_7_11    10
 UP BOUND     f_11_7    10
 UP BOUND     f_7_12    10
 UP BOUND     f_12_7    10
 UP BOUND     f_7_13    10
 UP BOUND     f_13_7    10
 UP BOUND     f_7_14    10
 UP BOUND     f_14_7    10
 UP BOUND     f_7_15    10
 UP BOUND     f_15_7    10
 UP BOUND     f_7_16    10
 UP BOUND     f_16_7    10
 UP BOUND     f_7_17    10
 UP BOUND     f_17_7    10
 UP BOUND     f_7_18    10
 UP BOUND     f_18_7    10
 UP BOUND     f_7_19    10
 UP BOUND     f_19_7    10
 UP BOUND     f_8_9     10
 UP BOUND     f_9_8     10
 UP BOUND     f_8_10    10
 UP BOUND     f_10_8    10
 UP BOUND     f_8_11    10
 UP BOUND     f_11_8    10
 UP BOUND     f_8_12    10
 UP BOUND     f_12_8    10
 UP BOUND     f_8_13    10
 UP BOUND     f_13_8    10
 UP BOUND     f_8_14    10
 UP BOUND     f_14_8    10
 UP BOUND     f_8_15    10
 UP BOUND     f_15_8    10
 UP BOUND     f_8_16    10
 UP BOUND     f_16_8    10
 UP BOUND     f_8_17    10
 UP BOUND     f_17_8    10
 UP BOUND     f_8_18    10
 UP BOUND     f_18_8    10
 UP BOUND     f_8_19    10
 UP BOUND     f_19_8    10
 UP BOUND     f_9_10    10
 UP BOUND     f_10_9    10
 UP BOUND     f_9_11    10
 UP BOUND     f_11_9    10
 UP BOUND     f_9_12    10
 UP BOUND     f_12_9    10
 UP BOUND     f_9_13    10
 UP BOUND     f_13_9    10
 UP BOUND     f_9_14    10
 UP BOUND     f_14_9    10
 UP BOUND     f_9_15    10
 UP BOUND     f_15_9    10
 UP BOUND     f_9_16    10
 UP BOUND     f_16_9    10
 UP BOUND     f_9_17    10
 UP BOUND     f_17_9    10
 UP BOUND     f_9_18    10
 UP BOUND     f_18_9    10
 UP BOUND     f_9_19    10
 UP BOUND     f_19_9    10
 UP BOUND     f_10_11   10
 UP BOUND     f_11_10   10
 UP BOUND     f_10_12   10
 UP BOUND     f_12_10   10
 UP BOUND     f_10_13   10
 UP BOUND     f_13_10   10
 UP BOUND     f_10_14   10
 UP BOUND     f_14_10   10
 UP BOUND     f_10_15   10
 UP BOUND     f_15_10   10
 UP BOUND     f_10_16   10
 UP BOUND     f_16_10   10
 UP BOUND     f_10_17   10
 UP BOUND     f_17_10   10
 UP BOUND     f_10_18   10
 UP BOUND     f_18_10   10
 UP BOUND     f_10_19   10
 UP BOUND     f_19_10   10
 UP BOUND     f_11_12   10
 UP BOUND     f_12_11   10
 UP BOUND     f_11_13   10
 UP BOUND     f_13_11   10
 UP BOUND     f_11_14   10
 UP BOUND     f_14_11   10
 UP BOUND     f_11_15   10
 UP BOUND     f_15_11   10
 UP BOUND     f_11_16   10
 UP BOUND     f_16_11   10
 UP BOUND     f_11_17   10
 UP BOUND     f_17_11   10
 UP BOUND     f_11_18   10
 UP BOUND     f_18_11   10
 UP BOUND     f_11_19   10
 UP BOUND     f_19_11   10
 UP BOUND     f_12_13   10
 UP BOUND     f_13_12   10
 UP BOUND     f_12_14   10
 UP BOUND     f_14_12   10
 UP BOUND     f_12_15   10
 UP BOUND     f_15_12   10
 UP BOUND     f_12_16   10
 UP BOUND     f_16_12   10
 UP BOUND     f_12_17   10
 UP BOUND     f_17_12   10
 UP BOUND     f_12_18   10
 UP BOUND     f_18_12   10
 UP BOUND     f_12_19   10
 UP BOUND     f_19_12   10
 UP BOUND     f_13_14   10
 UP BOUND     f_14_13   10
 UP BOUND     f_13_15   10
 UP BOUND     f_15_13   10
 UP BOUND     f_13_16   10
 UP BOUND     f_16_13   10
 UP BOUND     f_13_17   10
 UP BOUND     f_17_13   10
 UP BOUND     f_13_18   10
 UP BOUND     f_18_13   10
 UP BOUND     f_13_19   10
 UP BOUND     f_19_13   10
 UP BOUND     f_14_15   10
 UP BOUND     f_15_14   10
 UP BOUND     f_14_16   10
 UP BOUND     f_16_14   10
 UP BOUND     f_14_17   10
 UP BOUND     f_17_14   10
 UP BOUND     f_14_18   10
 UP BOUND     f_18_14   10
 UP BOUND     f_14_19   10
 UP BOUND     f_19_14   10
 UP BOUND     f_15_16   10
 UP BOUND     f_16_15   10
 UP BOUND     f_15_17   10
 UP BOUND     f_17_15   10
 UP BOUND     f_15_18   10
 UP BOUND     f_18_15   10
 UP BOUND     f_15_19   10
 UP BOUND     f_19_15   10
 UP BOUND     f_16_17   10
 UP BOUND     f_17_16   10
 UP BOUND     f_16_18   10
 UP BOUND     f_18_16   10
 UP BOUND     f_16_19   10
 UP BOUND     f_19_16   10
 UP BOUND     f_17_18   10
 UP BOUND     f_18_17   10
 UP BOUND     f_17_19   10
 UP BOUND     f_19_17   10
 UP BOUND     f_18_19   10
 UP BOUND     f_19_18   10
ENDATA
