NAME          jssp_search_n7_m7_bimodal_pt1-20_s1
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_0_5
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_1_5
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_2_5
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_3_5
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_4_5
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_5_5
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  prec_6_5
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_5_6_5
 G  disj2_5_6_5
 G  disj1_0_1_6
 G  disj2_0_1_6
 G  disj1_0_2_6
 G  disj2_0_2_6
 G  disj1_0_3_6
 G  disj2_0_3_6
 G  disj1_0_4_6
 G  disj2_0_4_6
 G  disj1_0_5_6
 G  disj2_0_5_6
 G  disj1_0_6_6
 G  disj2_0_6_6
 G  disj1_1_2_6
 G  disj2_1_2_6
 G  disj1_1_3_6
 G  disj2_1_3_6
 G  disj1_1_4_6
 G  disj2_1_4_6
 G  disj1_1_5_6
 G  disj2_1_5_6
 G  disj1_1_6_6
 G  disj2_1_6_6
 G  disj1_2_3_6
 G  disj2_2_3_6
 G  disj1_2_4_6
 G  disj2_2_4_6
 G  disj1_2_5_6
 G  disj2_2_5_6
 G  disj1_2_6_6
 G  disj2_2_6_6
 G  disj1_3_4_6
 G  disj2_3_4_6
 G  disj1_3_5_6
 G  disj2_3_5_6
 G  disj1_3_6_6
 G  disj2_3_6_6
 G  disj1_4_5_6
 G  disj2_4_5_6
 G  disj1_4_6_6
 G  disj2_4_6_6
 G  disj1_5_6_6
 G  disj2_5_6_6
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_3  -1.0
    x_0_0     disj2_0_1_3  1.0
    x_0_0     disj1_0_2_3  -1.0
    x_0_0     disj2_0_2_3  1.0
    x_0_0     disj1_0_3_3  -1.0
    x_0_0     disj2_0_3_3  1.0
    x_0_0     disj1_0_4_3  -1.0
    x_0_0     disj2_0_4_3  1.0
    x_0_0     disj1_0_5_3  -1.0
    x_0_0     disj2_0_5_3  1.0
    x_0_0     disj1_0_6_3  -1.0
    x_0_0     disj2_0_6_3  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_6  -1.0
    x_0_1     disj2_0_1_6  1.0
    x_0_1     disj1_0_2_6  -1.0
    x_0_1     disj2_0_2_6  1.0
    x_0_1     disj1_0_3_6  -1.0
    x_0_1     disj2_0_3_6  1.0
    x_0_1     disj1_0_4_6  -1.0
    x_0_1     disj2_0_4_6  1.0
    x_0_1     disj1_0_5_6  -1.0
    x_0_1     disj2_0_5_6  1.0
    x_0_1     disj1_0_6_6  -1.0
    x_0_1     disj2_0_6_6  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_5  -1.0
    x_0_2     disj2_0_1_5  1.0
    x_0_2     disj1_0_2_5  -1.0
    x_0_2     disj2_0_2_5  1.0
    x_0_2     disj1_0_3_5  -1.0
    x_0_2     disj2_0_3_5  1.0
    x_0_2     disj1_0_4_5  -1.0
    x_0_2     disj2_0_4_5  1.0
    x_0_2     disj1_0_5_5  -1.0
    x_0_2     disj2_0_5_5  1.0
    x_0_2     disj1_0_6_5  -1.0
    x_0_2     disj2_0_6_5  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_2  -1.0
    x_0_3     disj2_0_1_2  1.0
    x_0_3     disj1_0_2_2  -1.0
    x_0_3     disj2_0_2_2  1.0
    x_0_3     disj1_0_3_2  -1.0
    x_0_3     disj2_0_3_2  1.0
    x_0_3     disj1_0_4_2  -1.0
    x_0_3     disj2_0_4_2  1.0
    x_0_3     disj1_0_5_2  -1.0
    x_0_3     disj2_0_5_2  1.0
    x_0_3     disj1_0_6_2  -1.0
    x_0_3     disj2_0_6_2  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_0  -1.0
    x_0_4     disj2_0_1_0  1.0
    x_0_4     disj1_0_2_0  -1.0
    x_0_4     disj2_0_2_0  1.0
    x_0_4     disj1_0_3_0  -1.0
    x_0_4     disj2_0_3_0  1.0
    x_0_4     disj1_0_4_0  -1.0
    x_0_4     disj2_0_4_0  1.0
    x_0_4     disj1_0_5_0  -1.0
    x_0_4     disj2_0_5_0  1.0
    x_0_4     disj1_0_6_0  -1.0
    x_0_4     disj2_0_6_0  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     prec_0_5  -1.0
    x_0_5     disj1_0_1_4  -1.0
    x_0_5     disj2_0_1_4  1.0
    x_0_5     disj1_0_2_4  -1.0
    x_0_5     disj2_0_2_4  1.0
    x_0_5     disj1_0_3_4  -1.0
    x_0_5     disj2_0_3_4  1.0
    x_0_5     disj1_0_4_4  -1.0
    x_0_5     disj2_0_4_4  1.0
    x_0_5     disj1_0_5_4  -1.0
    x_0_5     disj2_0_5_4  1.0
    x_0_5     disj1_0_6_4  -1.0
    x_0_5     disj2_0_6_4  1.0
    x_0_6     prec_0_5  1.0
    x_0_6     mksp_0    -1.0
    x_0_6     disj1_0_1_1  -1.0
    x_0_6     disj2_0_1_1  1.0
    x_0_6     disj1_0_2_1  -1.0
    x_0_6     disj2_0_2_1  1.0
    x_0_6     disj1_0_3_1  -1.0
    x_0_6     disj2_0_3_1  1.0
    x_0_6     disj1_0_4_1  -1.0
    x_0_6     disj2_0_4_1  1.0
    x_0_6     disj1_0_5_1  -1.0
    x_0_6     disj2_0_5_1  1.0
    x_0_6     disj1_0_6_1  -1.0
    x_0_6     disj2_0_6_1  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_6  1.0
    x_1_1     disj2_0_1_6  -1.0
    x_1_1     disj1_1_2_6  -1.0
    x_1_1     disj2_1_2_6  1.0
    x_1_1     disj1_1_3_6  -1.0
    x_1_1     disj2_1_3_6  1.0
    x_1_1     disj1_1_4_6  -1.0
    x_1_1     disj2_1_4_6  1.0
    x_1_1     disj1_1_5_6  -1.0
    x_1_1     disj2_1_5_6  1.0
    x_1_1     disj1_1_6_6  -1.0
    x_1_1     disj2_1_6_6  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_2  1.0
    x_1_2     disj2_0_1_2  -1.0
    x_1_2     disj1_1_2_2  -1.0
    x_1_2     disj2_1_2_2  1.0
    x_1_2     disj1_1_3_2  -1.0
    x_1_2     disj2_1_3_2  1.0
    x_1_2     disj1_1_4_2  -1.0
    x_1_2     disj2_1_4_2  1.0
    x_1_2     disj1_1_5_2  -1.0
    x_1_2     disj2_1_5_2  1.0
    x_1_2     disj1_1_6_2  -1.0
    x_1_2     disj2_1_6_2  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_3  1.0
    x_1_3     disj2_0_1_3  -1.0
    x_1_3     disj1_1_2_3  -1.0
    x_1_3     disj2_1_2_3  1.0
    x_1_3     disj1_1_3_3  -1.0
    x_1_3     disj2_1_3_3  1.0
    x_1_3     disj1_1_4_3  -1.0
    x_1_3     disj2_1_4_3  1.0
    x_1_3     disj1_1_5_3  -1.0
    x_1_3     disj2_1_5_3  1.0
    x_1_3     disj1_1_6_3  -1.0
    x_1_3     disj2_1_6_3  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_0  1.0
    x_1_4     disj2_0_1_0  -1.0
    x_1_4     disj1_1_2_0  -1.0
    x_1_4     disj2_1_2_0  1.0
    x_1_4     disj1_1_3_0  -1.0
    x_1_4     disj2_1_3_0  1.0
    x_1_4     disj1_1_4_0  -1.0
    x_1_4     disj2_1_4_0  1.0
    x_1_4     disj1_1_5_0  -1.0
    x_1_4     disj2_1_5_0  1.0
    x_1_4     disj1_1_6_0  -1.0
    x_1_4     disj2_1_6_0  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     prec_1_5  -1.0
    x_1_5     disj1_0_1_4  1.0
    x_1_5     disj2_0_1_4  -1.0
    x_1_5     disj1_1_2_4  -1.0
    x_1_5     disj2_1_2_4  1.0
    x_1_5     disj1_1_3_4  -1.0
    x_1_5     disj2_1_3_4  1.0
    x_1_5     disj1_1_4_4  -1.0
    x_1_5     disj2_1_4_4  1.0
    x_1_5     disj1_1_5_4  -1.0
    x_1_5     disj2_1_5_4  1.0
    x_1_5     disj1_1_6_4  -1.0
    x_1_5     disj2_1_6_4  1.0
    x_1_6     prec_1_5  1.0
    x_1_6     mksp_1    -1.0
    x_1_6     disj1_0_1_5  1.0
    x_1_6     disj2_0_1_5  -1.0
    x_1_6     disj1_1_2_5  -1.0
    x_1_6     disj2_1_2_5  1.0
    x_1_6     disj1_1_3_5  -1.0
    x_1_6     disj2_1_3_5  1.0
    x_1_6     disj1_1_4_5  -1.0
    x_1_6     disj2_1_4_5  1.0
    x_1_6     disj1_1_5_5  -1.0
    x_1_6     disj2_1_5_5  1.0
    x_1_6     disj1_1_6_5  -1.0
    x_1_6     disj2_1_6_5  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_1  1.0
    x_2_0     disj2_0_2_1  -1.0
    x_2_0     disj1_1_2_1  1.0
    x_2_0     disj2_1_2_1  -1.0
    x_2_0     disj1_2_3_1  -1.0
    x_2_0     disj2_2_3_1  1.0
    x_2_0     disj1_2_4_1  -1.0
    x_2_0     disj2_2_4_1  1.0
    x_2_0     disj1_2_5_1  -1.0
    x_2_0     disj2_2_5_1  1.0
    x_2_0     disj1_2_6_1  -1.0
    x_2_0     disj2_2_6_1  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_6  1.0
    x_2_1     disj2_0_2_6  -1.0
    x_2_1     disj1_1_2_6  1.0
    x_2_1     disj2_1_2_6  -1.0
    x_2_1     disj1_2_3_6  -1.0
    x_2_1     disj2_2_3_6  1.0
    x_2_1     disj1_2_4_6  -1.0
    x_2_1     disj2_2_4_6  1.0
    x_2_1     disj1_2_5_6  -1.0
    x_2_1     disj2_2_5_6  1.0
    x_2_1     disj1_2_6_6  -1.0
    x_2_1     disj2_2_6_6  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_4  1.0
    x_2_2     disj2_0_2_4  -1.0
    x_2_2     disj1_1_2_4  1.0
    x_2_2     disj2_1_2_4  -1.0
    x_2_2     disj1_2_3_4  -1.0
    x_2_2     disj2_2_3_4  1.0
    x_2_2     disj1_2_4_4  -1.0
    x_2_2     disj2_2_4_4  1.0
    x_2_2     disj1_2_5_4  -1.0
    x_2_2     disj2_2_5_4  1.0
    x_2_2     disj1_2_6_4  -1.0
    x_2_2     disj2_2_6_4  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_3  1.0
    x_2_3     disj2_0_2_3  -1.0
    x_2_3     disj1_1_2_3  1.0
    x_2_3     disj2_1_2_3  -1.0
    x_2_3     disj1_2_3_3  -1.0
    x_2_3     disj2_2_3_3  1.0
    x_2_3     disj1_2_4_3  -1.0
    x_2_3     disj2_2_4_3  1.0
    x_2_3     disj1_2_5_3  -1.0
    x_2_3     disj2_2_5_3  1.0
    x_2_3     disj1_2_6_3  -1.0
    x_2_3     disj2_2_6_3  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_2  1.0
    x_2_4     disj2_0_2_2  -1.0
    x_2_4     disj1_1_2_2  1.0
    x_2_4     disj2_1_2_2  -1.0
    x_2_4     disj1_2_3_2  -1.0
    x_2_4     disj2_2_3_2  1.0
    x_2_4     disj1_2_4_2  -1.0
    x_2_4     disj2_2_4_2  1.0
    x_2_4     disj1_2_5_2  -1.0
    x_2_4     disj2_2_5_2  1.0
    x_2_4     disj1_2_6_2  -1.0
    x_2_4     disj2_2_6_2  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     prec_2_5  -1.0
    x_2_5     disj1_0_2_5  1.0
    x_2_5     disj2_0_2_5  -1.0
    x_2_5     disj1_1_2_5  1.0
    x_2_5     disj2_1_2_5  -1.0
    x_2_5     disj1_2_3_5  -1.0
    x_2_5     disj2_2_3_5  1.0
    x_2_5     disj1_2_4_5  -1.0
    x_2_5     disj2_2_4_5  1.0
    x_2_5     disj1_2_5_5  -1.0
    x_2_5     disj2_2_5_5  1.0
    x_2_5     disj1_2_6_5  -1.0
    x_2_5     disj2_2_6_5  1.0
    x_2_6     prec_2_5  1.0
    x_2_6     mksp_2    -1.0
    x_2_6     disj1_0_2_0  1.0
    x_2_6     disj2_0_2_0  -1.0
    x_2_6     disj1_1_2_0  1.0
    x_2_6     disj2_1_2_0  -1.0
    x_2_6     disj1_2_3_0  -1.0
    x_2_6     disj2_2_3_0  1.0
    x_2_6     disj1_2_4_0  -1.0
    x_2_6     disj2_2_4_0  1.0
    x_2_6     disj1_2_5_0  -1.0
    x_2_6     disj2_2_5_0  1.0
    x_2_6     disj1_2_6_0  -1.0
    x_2_6     disj2_2_6_0  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_6  1.0
    x_3_0     disj2_0_3_6  -1.0
    x_3_0     disj1_1_3_6  1.0
    x_3_0     disj2_1_3_6  -1.0
    x_3_0     disj1_2_3_6  1.0
    x_3_0     disj2_2_3_6  -1.0
    x_3_0     disj1_3_4_6  -1.0
    x_3_0     disj2_3_4_6  1.0
    x_3_0     disj1_3_5_6  -1.0
    x_3_0     disj2_3_5_6  1.0
    x_3_0     disj1_3_6_6  -1.0
    x_3_0     disj2_3_6_6  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_1  1.0
    x_3_1     disj2_0_3_1  -1.0
    x_3_1     disj1_1_3_1  1.0
    x_3_1     disj2_1_3_1  -1.0
    x_3_1     disj1_2_3_1  1.0
    x_3_1     disj2_2_3_1  -1.0
    x_3_1     disj1_3_4_1  -1.0
    x_3_1     disj2_3_4_1  1.0
    x_3_1     disj1_3_5_1  -1.0
    x_3_1     disj2_3_5_1  1.0
    x_3_1     disj1_3_6_1  -1.0
    x_3_1     disj2_3_6_1  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_4  1.0
    x_3_2     disj2_0_3_4  -1.0
    x_3_2     disj1_1_3_4  1.0
    x_3_2     disj2_1_3_4  -1.0
    x_3_2     disj1_2_3_4  1.0
    x_3_2     disj2_2_3_4  -1.0
    x_3_2     disj1_3_4_4  -1.0
    x_3_2     disj2_3_4_4  1.0
    x_3_2     disj1_3_5_4  -1.0
    x_3_2     disj2_3_5_4  1.0
    x_3_2     disj1_3_6_4  -1.0
    x_3_2     disj2_3_6_4  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_5  1.0
    x_3_3     disj2_0_3_5  -1.0
    x_3_3     disj1_1_3_5  1.0
    x_3_3     disj2_1_3_5  -1.0
    x_3_3     disj1_2_3_5  1.0
    x_3_3     disj2_2_3_5  -1.0
    x_3_3     disj1_3_4_5  -1.0
    x_3_3     disj2_3_4_5  1.0
    x_3_3     disj1_3_5_5  -1.0
    x_3_3     disj2_3_5_5  1.0
    x_3_3     disj1_3_6_5  -1.0
    x_3_3     disj2_3_6_5  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_0  1.0
    x_3_4     disj2_0_3_0  -1.0
    x_3_4     disj1_1_3_0  1.0
    x_3_4     disj2_1_3_0  -1.0
    x_3_4     disj1_2_3_0  1.0
    x_3_4     disj2_2_3_0  -1.0
    x_3_4     disj1_3_4_0  -1.0
    x_3_4     disj2_3_4_0  1.0
    x_3_4     disj1_3_5_0  -1.0
    x_3_4     disj2_3_5_0  1.0
    x_3_4     disj1_3_6_0  -1.0
    x_3_4     disj2_3_6_0  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     prec_3_5  -1.0
    x_3_5     disj1_0_3_3  1.0
    x_3_5     disj2_0_3_3  -1.0
    x_3_5     disj1_1_3_3  1.0
    x_3_5     disj2_1_3_3  -1.0
    x_3_5     disj1_2_3_3  1.0
    x_3_5     disj2_2_3_3  -1.0
    x_3_5     disj1_3_4_3  -1.0
    x_3_5     disj2_3_4_3  1.0
    x_3_5     disj1_3_5_3  -1.0
    x_3_5     disj2_3_5_3  1.0
    x_3_5     disj1_3_6_3  -1.0
    x_3_5     disj2_3_6_3  1.0
    x_3_6     prec_3_5  1.0
    x_3_6     mksp_3    -1.0
    x_3_6     disj1_0_3_2  1.0
    x_3_6     disj2_0_3_2  -1.0
    x_3_6     disj1_1_3_2  1.0
    x_3_6     disj2_1_3_2  -1.0
    x_3_6     disj1_2_3_2  1.0
    x_3_6     disj2_2_3_2  -1.0
    x_3_6     disj1_3_4_2  -1.0
    x_3_6     disj2_3_4_2  1.0
    x_3_6     disj1_3_5_2  -1.0
    x_3_6     disj2_3_5_2  1.0
    x_3_6     disj1_3_6_2  -1.0
    x_3_6     disj2_3_6_2  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_6  1.0
    x_4_0     disj2_0_4_6  -1.0
    x_4_0     disj1_1_4_6  1.0
    x_4_0     disj2_1_4_6  -1.0
    x_4_0     disj1_2_4_6  1.0
    x_4_0     disj2_2_4_6  -1.0
    x_4_0     disj1_3_4_6  1.0
    x_4_0     disj2_3_4_6  -1.0
    x_4_0     disj1_4_5_6  -1.0
    x_4_0     disj2_4_5_6  1.0
    x_4_0     disj1_4_6_6  -1.0
    x_4_0     disj2_4_6_6  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_0  1.0
    x_4_1     disj2_0_4_0  -1.0
    x_4_1     disj1_1_4_0  1.0
    x_4_1     disj2_1_4_0  -1.0
    x_4_1     disj1_2_4_0  1.0
    x_4_1     disj2_2_4_0  -1.0
    x_4_1     disj1_3_4_0  1.0
    x_4_1     disj2_3_4_0  -1.0
    x_4_1     disj1_4_5_0  -1.0
    x_4_1     disj2_4_5_0  1.0
    x_4_1     disj1_4_6_0  -1.0
    x_4_1     disj2_4_6_0  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_2  1.0
    x_4_2     disj2_0_4_2  -1.0
    x_4_2     disj1_1_4_2  1.0
    x_4_2     disj2_1_4_2  -1.0
    x_4_2     disj1_2_4_2  1.0
    x_4_2     disj2_2_4_2  -1.0
    x_4_2     disj1_3_4_2  1.0
    x_4_2     disj2_3_4_2  -1.0
    x_4_2     disj1_4_5_2  -1.0
    x_4_2     disj2_4_5_2  1.0
    x_4_2     disj1_4_6_2  -1.0
    x_4_2     disj2_4_6_2  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_4  1.0
    x_4_4     disj2_0_4_4  -1.0
    x_4_4     disj1_1_4_4  1.0
    x_4_4     disj2_1_4_4  -1.0
    x_4_4     disj1_2_4_4  1.0
    x_4_4     disj2_2_4_4  -1.0
    x_4_4     disj1_3_4_4  1.0
    x_4_4     disj2_3_4_4  -1.0
    x_4_4     disj1_4_5_4  -1.0
    x_4_4     disj2_4_5_4  1.0
    x_4_4     disj1_4_6_4  -1.0
    x_4_4     disj2_4_6_4  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     prec_4_5  -1.0
    x_4_5     disj1_0_4_5  1.0
    x_4_5     disj2_0_4_5  -1.0
    x_4_5     disj1_1_4_5  1.0
    x_4_5     disj2_1_4_5  -1.0
    x_4_5     disj1_2_4_5  1.0
    x_4_5     disj2_2_4_5  -1.0
    x_4_5     disj1_3_4_5  1.0
    x_4_5     disj2_3_4_5  -1.0
    x_4_5     disj1_4_5_5  -1.0
    x_4_5     disj2_4_5_5  1.0
    x_4_5     disj1_4_6_5  -1.0
    x_4_5     disj2_4_6_5  1.0
    x_4_6     prec_4_5  1.0
    x_4_6     mksp_4    -1.0
    x_4_6     disj1_0_4_3  1.0
    x_4_6     disj2_0_4_3  -1.0
    x_4_6     disj1_1_4_3  1.0
    x_4_6     disj2_1_4_3  -1.0
    x_4_6     disj1_2_4_3  1.0
    x_4_6     disj2_2_4_3  -1.0
    x_4_6     disj1_3_4_3  1.0
    x_4_6     disj2_3_4_3  -1.0
    x_4_6     disj1_4_5_3  -1.0
    x_4_6     disj2_4_5_3  1.0
    x_4_6     disj1_4_6_3  -1.0
    x_4_6     disj2_4_6_3  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_3  1.0
    x_5_0     disj2_0_5_3  -1.0
    x_5_0     disj1_1_5_3  1.0
    x_5_0     disj2_1_5_3  -1.0
    x_5_0     disj1_2_5_3  1.0
    x_5_0     disj2_2_5_3  -1.0
    x_5_0     disj1_3_5_3  1.0
    x_5_0     disj2_3_5_3  -1.0
    x_5_0     disj1_4_5_3  1.0
    x_5_0     disj2_4_5_3  -1.0
    x_5_0     disj1_5_6_3  -1.0
    x_5_0     disj2_5_6_3  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_5  1.0
    x_5_1     disj2_0_5_5  -1.0
    x_5_1     disj1_1_5_5  1.0
    x_5_1     disj2_1_5_5  -1.0
    x_5_1     disj1_2_5_5  1.0
    x_5_1     disj2_2_5_5  -1.0
    x_5_1     disj1_3_5_5  1.0
    x_5_1     disj2_3_5_5  -1.0
    x_5_1     disj1_4_5_5  1.0
    x_5_1     disj2_4_5_5  -1.0
    x_5_1     disj1_5_6_5  -1.0
    x_5_1     disj2_5_6_5  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_2  1.0
    x_5_2     disj2_0_5_2  -1.0
    x_5_2     disj1_1_5_2  1.0
    x_5_2     disj2_1_5_2  -1.0
    x_5_2     disj1_2_5_2  1.0
    x_5_2     disj2_2_5_2  -1.0
    x_5_2     disj1_3_5_2  1.0
    x_5_2     disj2_3_5_2  -1.0
    x_5_2     disj1_4_5_2  1.0
    x_5_2     disj2_4_5_2  -1.0
    x_5_2     disj1_5_6_2  -1.0
    x_5_2     disj2_5_6_2  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_0  1.0
    x_5_3     disj2_0_5_0  -1.0
    x_5_3     disj1_1_5_0  1.0
    x_5_3     disj2_1_5_0  -1.0
    x_5_3     disj1_2_5_0  1.0
    x_5_3     disj2_2_5_0  -1.0
    x_5_3     disj1_3_5_0  1.0
    x_5_3     disj2_3_5_0  -1.0
    x_5_3     disj1_4_5_0  1.0
    x_5_3     disj2_4_5_0  -1.0
    x_5_3     disj1_5_6_0  -1.0
    x_5_3     disj2_5_6_0  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_1  1.0
    x_5_4     disj2_0_5_1  -1.0
    x_5_4     disj1_1_5_1  1.0
    x_5_4     disj2_1_5_1  -1.0
    x_5_4     disj1_2_5_1  1.0
    x_5_4     disj2_2_5_1  -1.0
    x_5_4     disj1_3_5_1  1.0
    x_5_4     disj2_3_5_1  -1.0
    x_5_4     disj1_4_5_1  1.0
    x_5_4     disj2_4_5_1  -1.0
    x_5_4     disj1_5_6_1  -1.0
    x_5_4     disj2_5_6_1  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     prec_5_5  -1.0
    x_5_5     disj1_0_5_6  1.0
    x_5_5     disj2_0_5_6  -1.0
    x_5_5     disj1_1_5_6  1.0
    x_5_5     disj2_1_5_6  -1.0
    x_5_5     disj1_2_5_6  1.0
    x_5_5     disj2_2_5_6  -1.0
    x_5_5     disj1_3_5_6  1.0
    x_5_5     disj2_3_5_6  -1.0
    x_5_5     disj1_4_5_6  1.0
    x_5_5     disj2_4_5_6  -1.0
    x_5_5     disj1_5_6_6  -1.0
    x_5_5     disj2_5_6_6  1.0
    x_5_6     prec_5_5  1.0
    x_5_6     mksp_5    -1.0
    x_5_6     disj1_0_5_4  1.0
    x_5_6     disj2_0_5_4  -1.0
    x_5_6     disj1_1_5_4  1.0
    x_5_6     disj2_1_5_4  -1.0
    x_5_6     disj1_2_5_4  1.0
    x_5_6     disj2_2_5_4  -1.0
    x_5_6     disj1_3_5_4  1.0
    x_5_6     disj2_3_5_4  -1.0
    x_5_6     disj1_4_5_4  1.0
    x_5_6     disj2_4_5_4  -1.0
    x_5_6     disj1_5_6_4  -1.0
    x_5_6     disj2_5_6_4  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_0  1.0
    x_6_0     disj2_0_6_0  -1.0
    x_6_0     disj1_1_6_0  1.0
    x_6_0     disj2_1_6_0  -1.0
    x_6_0     disj1_2_6_0  1.0
    x_6_0     disj2_2_6_0  -1.0
    x_6_0     disj1_3_6_0  1.0
    x_6_0     disj2_3_6_0  -1.0
    x_6_0     disj1_4_6_0  1.0
    x_6_0     disj2_4_6_0  -1.0
    x_6_0     disj1_5_6_0  1.0
    x_6_0     disj2_5_6_0  -1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_1  1.0
    x_6_1     disj2_0_6_1  -1.0
    x_6_1     disj1_1_6_1  1.0
    x_6_1     disj2_1_6_1  -1.0
    x_6_1     disj1_2_6_1  1.0
    x_6_1     disj2_2_6_1  -1.0
    x_6_1     disj1_3_6_1  1.0
    x_6_1     disj2_3_6_1  -1.0
    x_6_1     disj1_4_6_1  1.0
    x_6_1     disj2_4_6_1  -1.0
    x_6_1     disj1_5_6_1  1.0
    x_6_1     disj2_5_6_1  -1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_4  1.0
    x_6_2     disj2_0_6_4  -1.0
    x_6_2     disj1_1_6_4  1.0
    x_6_2     disj2_1_6_4  -1.0
    x_6_2     disj1_2_6_4  1.0
    x_6_2     disj2_2_6_4  -1.0
    x_6_2     disj1_3_6_4  1.0
    x_6_2     disj2_3_6_4  -1.0
    x_6_2     disj1_4_6_4  1.0
    x_6_2     disj2_4_6_4  -1.0
    x_6_2     disj1_5_6_4  1.0
    x_6_2     disj2_5_6_4  -1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_3  1.0
    x_6_3     disj2_0_6_3  -1.0
    x_6_3     disj1_1_6_3  1.0
    x_6_3     disj2_1_6_3  -1.0
    x_6_3     disj1_2_6_3  1.0
    x_6_3     disj2_2_6_3  -1.0
    x_6_3     disj1_3_6_3  1.0
    x_6_3     disj2_3_6_3  -1.0
    x_6_3     disj1_4_6_3  1.0
    x_6_3     disj2_4_6_3  -1.0
    x_6_3     disj1_5_6_3  1.0
    x_6_3     disj2_5_6_3  -1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_2  1.0
    x_6_4     disj2_0_6_2  -1.0
    x_6_4     disj1_1_6_2  1.0
    x_6_4     disj2_1_6_2  -1.0
    x_6_4     disj1_2_6_2  1.0
    x_6_4     disj2_2_6_2  -1.0
    x_6_4     disj1_3_6_2  1.0
    x_6_4     disj2_3_6_2  -1.0
    x_6_4     disj1_4_6_2  1.0
    x_6_4     disj2_4_6_2  -1.0
    x_6_4     disj1_5_6_2  1.0
    x_6_4     disj2_5_6_2  -1.0
    x_6_5     prec_6_4  1.0
    x_6_5     prec_6_5  -1.0
    x_6_5     disj1_0_6_6  1.0
    x_6_5     disj2_0_6_6  -1.0
    x_6_5     disj1_1_6_6  1.0
    x_6_5     disj2_1_6_6  -1.0
    x_6_5     disj1_2_6_6  1.0
    x_6_5     disj2_2_6_6  -1.0
    x_6_5     disj1_3_6_6  1.0
    x_6_5     disj2_3_6_6  -1.0
    x_6_5     disj1_4_6_6  1.0
    x_6_5     disj2_4_6_6  -1.0
    x_6_5     disj1_5_6_6  1.0
    x_6_5     disj2_5_6_6  -1.0
    x_6_6     prec_6_5  1.0
    x_6_6     mksp_6    -1.0
    x_6_6     disj1_0_6_5  1.0
    x_6_6     disj2_0_6_5  -1.0
    x_6_6     disj1_1_6_5  1.0
    x_6_6     disj2_1_6_5  -1.0
    x_6_6     disj1_2_6_5  1.0
    x_6_6     disj2_2_6_5  -1.0
    x_6_6     disj1_3_6_5  1.0
    x_6_6     disj2_3_6_5  -1.0
    x_6_6     disj1_4_6_5  1.0
    x_6_6     disj2_4_6_5  -1.0
    x_6_6     disj1_5_6_5  1.0
    x_6_6     disj2_5_6_5  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  491
    y_0_1_0   disj2_0_1_0  -491
    y_0_1_1   disj1_0_1_1  491
    y_0_1_1   disj2_0_1_1  -491
    y_0_1_2   disj1_0_1_2  491
    y_0_1_2   disj2_0_1_2  -491
    y_0_1_3   disj1_0_1_3  491
    y_0_1_3   disj2_0_1_3  -491
    y_0_1_4   disj1_0_1_4  491
    y_0_1_4   disj2_0_1_4  -491
    y_0_1_5   disj1_0_1_5  491
    y_0_1_5   disj2_0_1_5  -491
    y_0_1_6   disj1_0_1_6  491
    y_0_1_6   disj2_0_1_6  -491
    y_0_2_0   disj1_0_2_0  491
    y_0_2_0   disj2_0_2_0  -491
    y_0_2_1   disj1_0_2_1  491
    y_0_2_1   disj2_0_2_1  -491
    y_0_2_2   disj1_0_2_2  491
    y_0_2_2   disj2_0_2_2  -491
    y_0_2_3   disj1_0_2_3  491
    y_0_2_3   disj2_0_2_3  -491
    y_0_2_4   disj1_0_2_4  491
    y_0_2_4   disj2_0_2_4  -491
    y_0_2_5   disj1_0_2_5  491
    y_0_2_5   disj2_0_2_5  -491
    y_0_2_6   disj1_0_2_6  491
    y_0_2_6   disj2_0_2_6  -491
    y_0_3_0   disj1_0_3_0  491
    y_0_3_0   disj2_0_3_0  -491
    y_0_3_1   disj1_0_3_1  491
    y_0_3_1   disj2_0_3_1  -491
    y_0_3_2   disj1_0_3_2  491
    y_0_3_2   disj2_0_3_2  -491
    y_0_3_3   disj1_0_3_3  491
    y_0_3_3   disj2_0_3_3  -491
    y_0_3_4   disj1_0_3_4  491
    y_0_3_4   disj2_0_3_4  -491
    y_0_3_5   disj1_0_3_5  491
    y_0_3_5   disj2_0_3_5  -491
    y_0_3_6   disj1_0_3_6  491
    y_0_3_6   disj2_0_3_6  -491
    y_0_4_0   disj1_0_4_0  491
    y_0_4_0   disj2_0_4_0  -491
    y_0_4_1   disj1_0_4_1  491
    y_0_4_1   disj2_0_4_1  -491
    y_0_4_2   disj1_0_4_2  491
    y_0_4_2   disj2_0_4_2  -491
    y_0_4_3   disj1_0_4_3  491
    y_0_4_3   disj2_0_4_3  -491
    y_0_4_4   disj1_0_4_4  491
    y_0_4_4   disj2_0_4_4  -491
    y_0_4_5   disj1_0_4_5  491
    y_0_4_5   disj2_0_4_5  -491
    y_0_4_6   disj1_0_4_6  491
    y_0_4_6   disj2_0_4_6  -491
    y_0_5_0   disj1_0_5_0  491
    y_0_5_0   disj2_0_5_0  -491
    y_0_5_1   disj1_0_5_1  491
    y_0_5_1   disj2_0_5_1  -491
    y_0_5_2   disj1_0_5_2  491
    y_0_5_2   disj2_0_5_2  -491
    y_0_5_3   disj1_0_5_3  491
    y_0_5_3   disj2_0_5_3  -491
    y_0_5_4   disj1_0_5_4  491
    y_0_5_4   disj2_0_5_4  -491
    y_0_5_5   disj1_0_5_5  491
    y_0_5_5   disj2_0_5_5  -491
    y_0_5_6   disj1_0_5_6  491
    y_0_5_6   disj2_0_5_6  -491
    y_0_6_0   disj1_0_6_0  491
    y_0_6_0   disj2_0_6_0  -491
    y_0_6_1   disj1_0_6_1  491
    y_0_6_1   disj2_0_6_1  -491
    y_0_6_2   disj1_0_6_2  491
    y_0_6_2   disj2_0_6_2  -491
    y_0_6_3   disj1_0_6_3  491
    y_0_6_3   disj2_0_6_3  -491
    y_0_6_4   disj1_0_6_4  491
    y_0_6_4   disj2_0_6_4  -491
    y_0_6_5   disj1_0_6_5  491
    y_0_6_5   disj2_0_6_5  -491
    y_0_6_6   disj1_0_6_6  491
    y_0_6_6   disj2_0_6_6  -491
    y_1_2_0   disj1_1_2_0  491
    y_1_2_0   disj2_1_2_0  -491
    y_1_2_1   disj1_1_2_1  491
    y_1_2_1   disj2_1_2_1  -491
    y_1_2_2   disj1_1_2_2  491
    y_1_2_2   disj2_1_2_2  -491
    y_1_2_3   disj1_1_2_3  491
    y_1_2_3   disj2_1_2_3  -491
    y_1_2_4   disj1_1_2_4  491
    y_1_2_4   disj2_1_2_4  -491
    y_1_2_5   disj1_1_2_5  491
    y_1_2_5   disj2_1_2_5  -491
    y_1_2_6   disj1_1_2_6  491
    y_1_2_6   disj2_1_2_6  -491
    y_1_3_0   disj1_1_3_0  491
    y_1_3_0   disj2_1_3_0  -491
    y_1_3_1   disj1_1_3_1  491
    y_1_3_1   disj2_1_3_1  -491
    y_1_3_2   disj1_1_3_2  491
    y_1_3_2   disj2_1_3_2  -491
    y_1_3_3   disj1_1_3_3  491
    y_1_3_3   disj2_1_3_3  -491
    y_1_3_4   disj1_1_3_4  491
    y_1_3_4   disj2_1_3_4  -491
    y_1_3_5   disj1_1_3_5  491
    y_1_3_5   disj2_1_3_5  -491
    y_1_3_6   disj1_1_3_6  491
    y_1_3_6   disj2_1_3_6  -491
    y_1_4_0   disj1_1_4_0  491
    y_1_4_0   disj2_1_4_0  -491
    y_1_4_1   disj1_1_4_1  491
    y_1_4_1   disj2_1_4_1  -491
    y_1_4_2   disj1_1_4_2  491
    y_1_4_2   disj2_1_4_2  -491
    y_1_4_3   disj1_1_4_3  491
    y_1_4_3   disj2_1_4_3  -491
    y_1_4_4   disj1_1_4_4  491
    y_1_4_4   disj2_1_4_4  -491
    y_1_4_5   disj1_1_4_5  491
    y_1_4_5   disj2_1_4_5  -491
    y_1_4_6   disj1_1_4_6  491
    y_1_4_6   disj2_1_4_6  -491
    y_1_5_0   disj1_1_5_0  491
    y_1_5_0   disj2_1_5_0  -491
    y_1_5_1   disj1_1_5_1  491
    y_1_5_1   disj2_1_5_1  -491
    y_1_5_2   disj1_1_5_2  491
    y_1_5_2   disj2_1_5_2  -491
    y_1_5_3   disj1_1_5_3  491
    y_1_5_3   disj2_1_5_3  -491
    y_1_5_4   disj1_1_5_4  491
    y_1_5_4   disj2_1_5_4  -491
    y_1_5_5   disj1_1_5_5  491
    y_1_5_5   disj2_1_5_5  -491
    y_1_5_6   disj1_1_5_6  491
    y_1_5_6   disj2_1_5_6  -491
    y_1_6_0   disj1_1_6_0  491
    y_1_6_0   disj2_1_6_0  -491
    y_1_6_1   disj1_1_6_1  491
    y_1_6_1   disj2_1_6_1  -491
    y_1_6_2   disj1_1_6_2  491
    y_1_6_2   disj2_1_6_2  -491
    y_1_6_3   disj1_1_6_3  491
    y_1_6_3   disj2_1_6_3  -491
    y_1_6_4   disj1_1_6_4  491
    y_1_6_4   disj2_1_6_4  -491
    y_1_6_5   disj1_1_6_5  491
    y_1_6_5   disj2_1_6_5  -491
    y_1_6_6   disj1_1_6_6  491
    y_1_6_6   disj2_1_6_6  -491
    y_2_3_0   disj1_2_3_0  491
    y_2_3_0   disj2_2_3_0  -491
    y_2_3_1   disj1_2_3_1  491
    y_2_3_1   disj2_2_3_1  -491
    y_2_3_2   disj1_2_3_2  491
    y_2_3_2   disj2_2_3_2  -491
    y_2_3_3   disj1_2_3_3  491
    y_2_3_3   disj2_2_3_3  -491
    y_2_3_4   disj1_2_3_4  491
    y_2_3_4   disj2_2_3_4  -491
    y_2_3_5   disj1_2_3_5  491
    y_2_3_5   disj2_2_3_5  -491
    y_2_3_6   disj1_2_3_6  491
    y_2_3_6   disj2_2_3_6  -491
    y_2_4_0   disj1_2_4_0  491
    y_2_4_0   disj2_2_4_0  -491
    y_2_4_1   disj1_2_4_1  491
    y_2_4_1   disj2_2_4_1  -491
    y_2_4_2   disj1_2_4_2  491
    y_2_4_2   disj2_2_4_2  -491
    y_2_4_3   disj1_2_4_3  491
    y_2_4_3   disj2_2_4_3  -491
    y_2_4_4   disj1_2_4_4  491
    y_2_4_4   disj2_2_4_4  -491
    y_2_4_5   disj1_2_4_5  491
    y_2_4_5   disj2_2_4_5  -491
    y_2_4_6   disj1_2_4_6  491
    y_2_4_6   disj2_2_4_6  -491
    y_2_5_0   disj1_2_5_0  491
    y_2_5_0   disj2_2_5_0  -491
    y_2_5_1   disj1_2_5_1  491
    y_2_5_1   disj2_2_5_1  -491
    y_2_5_2   disj1_2_5_2  491
    y_2_5_2   disj2_2_5_2  -491
    y_2_5_3   disj1_2_5_3  491
    y_2_5_3   disj2_2_5_3  -491
    y_2_5_4   disj1_2_5_4  491
    y_2_5_4   disj2_2_5_4  -491
    y_2_5_5   disj1_2_5_5  491
    y_2_5_5   disj2_2_5_5  -491
    y_2_5_6   disj1_2_5_6  491
    y_2_5_6   disj2_2_5_6  -491
    y_2_6_0   disj1_2_6_0  491
    y_2_6_0   disj2_2_6_0  -491
    y_2_6_1   disj1_2_6_1  491
    y_2_6_1   disj2_2_6_1  -491
    y_2_6_2   disj1_2_6_2  491
    y_2_6_2   disj2_2_6_2  -491
    y_2_6_3   disj1_2_6_3  491
    y_2_6_3   disj2_2_6_3  -491
    y_2_6_4   disj1_2_6_4  491
    y_2_6_4   disj2_2_6_4  -491
    y_2_6_5   disj1_2_6_5  491
    y_2_6_5   disj2_2_6_5  -491
    y_2_6_6   disj1_2_6_6  491
    y_2_6_6   disj2_2_6_6  -491
    y_3_4_0   disj1_3_4_0  491
    y_3_4_0   disj2_3_4_0  -491
    y_3_4_1   disj1_3_4_1  491
    y_3_4_1   disj2_3_4_1  -491
    y_3_4_2   disj1_3_4_2  491
    y_3_4_2   disj2_3_4_2  -491
    y_3_4_3   disj1_3_4_3  491
    y_3_4_3   disj2_3_4_3  -491
    y_3_4_4   disj1_3_4_4  491
    y_3_4_4   disj2_3_4_4  -491
    y_3_4_5   disj1_3_4_5  491
    y_3_4_5   disj2_3_4_5  -491
    y_3_4_6   disj1_3_4_6  491
    y_3_4_6   disj2_3_4_6  -491
    y_3_5_0   disj1_3_5_0  491
    y_3_5_0   disj2_3_5_0  -491
    y_3_5_1   disj1_3_5_1  491
    y_3_5_1   disj2_3_5_1  -491
    y_3_5_2   disj1_3_5_2  491
    y_3_5_2   disj2_3_5_2  -491
    y_3_5_3   disj1_3_5_3  491
    y_3_5_3   disj2_3_5_3  -491
    y_3_5_4   disj1_3_5_4  491
    y_3_5_4   disj2_3_5_4  -491
    y_3_5_5   disj1_3_5_5  491
    y_3_5_5   disj2_3_5_5  -491
    y_3_5_6   disj1_3_5_6  491
    y_3_5_6   disj2_3_5_6  -491
    y_3_6_0   disj1_3_6_0  491
    y_3_6_0   disj2_3_6_0  -491
    y_3_6_1   disj1_3_6_1  491
    y_3_6_1   disj2_3_6_1  -491
    y_3_6_2   disj1_3_6_2  491
    y_3_6_2   disj2_3_6_2  -491
    y_3_6_3   disj1_3_6_3  491
    y_3_6_3   disj2_3_6_3  -491
    y_3_6_4   disj1_3_6_4  491
    y_3_6_4   disj2_3_6_4  -491
    y_3_6_5   disj1_3_6_5  491
    y_3_6_5   disj2_3_6_5  -491
    y_3_6_6   disj1_3_6_6  491
    y_3_6_6   disj2_3_6_6  -491
    y_4_5_0   disj1_4_5_0  491
    y_4_5_0   disj2_4_5_0  -491
    y_4_5_1   disj1_4_5_1  491
    y_4_5_1   disj2_4_5_1  -491
    y_4_5_2   disj1_4_5_2  491
    y_4_5_2   disj2_4_5_2  -491
    y_4_5_3   disj1_4_5_3  491
    y_4_5_3   disj2_4_5_3  -491
    y_4_5_4   disj1_4_5_4  491
    y_4_5_4   disj2_4_5_4  -491
    y_4_5_5   disj1_4_5_5  491
    y_4_5_5   disj2_4_5_5  -491
    y_4_5_6   disj1_4_5_6  491
    y_4_5_6   disj2_4_5_6  -491
    y_4_6_0   disj1_4_6_0  491
    y_4_6_0   disj2_4_6_0  -491
    y_4_6_1   disj1_4_6_1  491
    y_4_6_1   disj2_4_6_1  -491
    y_4_6_2   disj1_4_6_2  491
    y_4_6_2   disj2_4_6_2  -491
    y_4_6_3   disj1_4_6_3  491
    y_4_6_3   disj2_4_6_3  -491
    y_4_6_4   disj1_4_6_4  491
    y_4_6_4   disj2_4_6_4  -491
    y_4_6_5   disj1_4_6_5  491
    y_4_6_5   disj2_4_6_5  -491
    y_4_6_6   disj1_4_6_6  491
    y_4_6_6   disj2_4_6_6  -491
    y_5_6_0   disj1_5_6_0  491
    y_5_6_0   disj2_5_6_0  -491
    y_5_6_1   disj1_5_6_1  491
    y_5_6_1   disj2_5_6_1  -491
    y_5_6_2   disj1_5_6_2  491
    y_5_6_2   disj2_5_6_2  -491
    y_5_6_3   disj1_5_6_3  491
    y_5_6_3   disj2_5_6_3  -491
    y_5_6_4   disj1_5_6_4  491
    y_5_6_4   disj2_5_6_4  -491
    y_5_6_5   disj1_5_6_5  491
    y_5_6_5   disj2_5_6_5  -491
    y_5_6_6   disj1_5_6_6  491
    y_5_6_6   disj2_5_6_6  -491
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  18
    RHS       prec_0_1  15
    RHS       prec_0_2  18
    RHS       prec_0_3  15
    RHS       prec_0_4  3
    RHS       prec_0_5  15
    RHS       prec_1_0  4
    RHS       prec_1_1  16
    RHS       prec_1_2  4
    RHS       prec_1_3  3
    RHS       prec_1_4  4
    RHS       prec_1_5  4
    RHS       prec_2_0  17
    RHS       prec_2_1  5
    RHS       prec_2_2  16
    RHS       prec_2_3  4
    RHS       prec_2_4  19
    RHS       prec_2_5  1
    RHS       prec_3_0  19
    RHS       prec_3_1  6
    RHS       prec_3_2  5
    RHS       prec_3_3  2
    RHS       prec_3_4  19
    RHS       prec_3_5  17
    RHS       prec_4_0  15
    RHS       prec_4_1  3
    RHS       prec_4_2  18
    RHS       prec_4_3  18
    RHS       prec_4_4  19
    RHS       prec_4_5  4
    RHS       prec_5_0  1
    RHS       prec_5_1  15
    RHS       prec_5_2  1
    RHS       prec_5_3  3
    RHS       prec_5_4  3
    RHS       prec_5_5  16
    RHS       prec_6_0  4
    RHS       prec_6_1  17
    RHS       prec_6_2  3
    RHS       prec_6_3  15
    RHS       prec_6_4  6
    RHS       prec_6_5  5
    RHS       mksp_0    1
    RHS       mksp_1    20
    RHS       mksp_2    19
    RHS       mksp_3    3
    RHS       mksp_4    2
    RHS       mksp_5    16
    RHS       mksp_6    15
    RHS       disj1_0_1_0  3
    RHS       disj2_0_1_0  -487
    RHS       disj1_0_2_0  3
    RHS       disj2_0_2_0  -472
    RHS       disj1_0_3_0  3
    RHS       disj2_0_3_0  -472
    RHS       disj1_0_4_0  3
    RHS       disj2_0_4_0  -488
    RHS       disj1_0_5_0  3
    RHS       disj2_0_5_0  -488
    RHS       disj1_0_6_0  3
    RHS       disj2_0_6_0  -487
    RHS       disj1_1_2_0  4
    RHS       disj2_1_2_0  -472
    RHS       disj1_1_3_0  4
    RHS       disj2_1_3_0  -472
    RHS       disj1_1_4_0  4
    RHS       disj2_1_4_0  -488
    RHS       disj1_1_5_0  4
    RHS       disj2_1_5_0  -488
    RHS       disj1_1_6_0  4
    RHS       disj2_1_6_0  -487
    RHS       disj1_2_3_0  19
    RHS       disj2_2_3_0  -472
    RHS       disj1_2_4_0  19
    RHS       disj2_2_4_0  -488
    RHS       disj1_2_5_0  19
    RHS       disj2_2_5_0  -488
    RHS       disj1_2_6_0  19
    RHS       disj2_2_6_0  -487
    RHS       disj1_3_4_0  19
    RHS       disj2_3_4_0  -488
    RHS       disj1_3_5_0  19
    RHS       disj2_3_5_0  -488
    RHS       disj1_3_6_0  19
    RHS       disj2_3_6_0  -487
    RHS       disj1_4_5_0  3
    RHS       disj2_4_5_0  -488
    RHS       disj1_4_6_0  3
    RHS       disj2_4_6_0  -487
    RHS       disj1_5_6_0  3
    RHS       disj2_5_6_0  -487
    RHS       disj1_0_1_1  1
    RHS       disj2_0_1_1  -487
    RHS       disj1_0_2_1  1
    RHS       disj2_0_2_1  -474
    RHS       disj1_0_3_1  1
    RHS       disj2_0_3_1  -485
    RHS       disj1_0_4_1  1
    RHS       disj2_0_4_1  -473
    RHS       disj1_0_5_1  1
    RHS       disj2_0_5_1  -488
    RHS       disj1_0_6_1  1
    RHS       disj2_0_6_1  -474
    RHS       disj1_1_2_1  4
    RHS       disj2_1_2_1  -474
    RHS       disj1_1_3_1  4
    RHS       disj2_1_3_1  -485
    RHS       disj1_1_4_1  4
    RHS       disj2_1_4_1  -473
    RHS       disj1_1_5_1  4
    RHS       disj2_1_5_1  -488
    RHS       disj1_1_6_1  4
    RHS       disj2_1_6_1  -474
    RHS       disj1_2_3_1  17
    RHS       disj2_2_3_1  -485
    RHS       disj1_2_4_1  17
    RHS       disj2_2_4_1  -473
    RHS       disj1_2_5_1  17
    RHS       disj2_2_5_1  -488
    RHS       disj1_2_6_1  17
    RHS       disj2_2_6_1  -474
    RHS       disj1_3_4_1  6
    RHS       disj2_3_4_1  -473
    RHS       disj1_3_5_1  6
    RHS       disj2_3_5_1  -488
    RHS       disj1_3_6_1  6
    RHS       disj2_3_6_1  -474
    RHS       disj1_4_5_1  18
    RHS       disj2_4_5_1  -488
    RHS       disj1_4_6_1  18
    RHS       disj2_4_6_1  -474
    RHS       disj1_5_6_1  3
    RHS       disj2_5_6_1  -474
    RHS       disj1_0_1_2  15
    RHS       disj2_0_1_2  -487
    RHS       disj1_0_2_2  15
    RHS       disj2_0_2_2  -472
    RHS       disj1_0_3_2  15
    RHS       disj2_0_3_2  -488
    RHS       disj1_0_4_2  15
    RHS       disj2_0_4_2  -473
    RHS       disj1_0_5_2  15
    RHS       disj2_0_5_2  -490
    RHS       disj1_0_6_2  15
    RHS       disj2_0_6_2  -485
    RHS       disj1_1_2_2  4
    RHS       disj2_1_2_2  -472
    RHS       disj1_1_3_2  4
    RHS       disj2_1_3_2  -488
    RHS       disj1_1_4_2  4
    RHS       disj2_1_4_2  -473
    RHS       disj1_1_5_2  4
    RHS       disj2_1_5_2  -490
    RHS       disj1_1_6_2  4
    RHS       disj2_1_6_2  -485
    RHS       disj1_2_3_2  19
    RHS       disj2_2_3_2  -488
    RHS       disj1_2_4_2  19
    RHS       disj2_2_4_2  -473
    RHS       disj1_2_5_2  19
    RHS       disj2_2_5_2  -490
    RHS       disj1_2_6_2  19
    RHS       disj2_2_6_2  -485
    RHS       disj1_3_4_2  3
    RHS       disj2_3_4_2  -473
    RHS       disj1_3_5_2  3
    RHS       disj2_3_5_2  -490
    RHS       disj1_3_6_2  3
    RHS       disj2_3_6_2  -485
    RHS       disj1_4_5_2  18
    RHS       disj2_4_5_2  -490
    RHS       disj1_4_6_2  18
    RHS       disj2_4_6_2  -485
    RHS       disj1_5_6_2  1
    RHS       disj2_5_6_2  -485
    RHS       disj1_0_1_3  18
    RHS       disj2_0_1_3  -488
    RHS       disj1_0_2_3  18
    RHS       disj2_0_2_3  -487
    RHS       disj1_0_3_3  18
    RHS       disj2_0_3_3  -474
    RHS       disj1_0_4_3  18
    RHS       disj2_0_4_3  -489
    RHS       disj1_0_5_3  18
    RHS       disj2_0_5_3  -490
    RHS       disj1_0_6_3  18
    RHS       disj2_0_6_3  -476
    RHS       disj1_1_2_3  3
    RHS       disj2_1_2_3  -487
    RHS       disj1_1_3_3  3
    RHS       disj2_1_3_3  -474
    RHS       disj1_1_4_3  3
    RHS       disj2_1_4_3  -489
    RHS       disj1_1_5_3  3
    RHS       disj2_1_5_3  -490
    RHS       disj1_1_6_3  3
    RHS       disj2_1_6_3  -476
    RHS       disj1_2_3_3  4
    RHS       disj2_2_3_3  -474
    RHS       disj1_2_4_3  4
    RHS       disj2_2_4_3  -489
    RHS       disj1_2_5_3  4
    RHS       disj2_2_5_3  -490
    RHS       disj1_2_6_3  4
    RHS       disj2_2_6_3  -476
    RHS       disj1_3_4_3  17
    RHS       disj2_3_4_3  -489
    RHS       disj1_3_5_3  17
    RHS       disj2_3_5_3  -490
    RHS       disj1_3_6_3  17
    RHS       disj2_3_6_3  -476
    RHS       disj1_4_5_3  2
    RHS       disj2_4_5_3  -490
    RHS       disj1_4_6_3  2
    RHS       disj2_4_6_3  -476
    RHS       disj1_5_6_3  1
    RHS       disj2_5_6_3  -476
    RHS       disj1_0_1_4  15
    RHS       disj2_0_1_4  -487
    RHS       disj1_0_2_4  15
    RHS       disj2_0_2_4  -475
    RHS       disj1_0_3_4  15
    RHS       disj2_0_3_4  -486
    RHS       disj1_0_4_4  15
    RHS       disj2_0_4_4  -472
    RHS       disj1_0_5_4  15
    RHS       disj2_0_5_4  -475
    RHS       disj1_0_6_4  15
    RHS       disj2_0_6_4  -488
    RHS       disj1_1_2_4  4
    RHS       disj2_1_2_4  -475
    RHS       disj1_1_3_4  4
    RHS       disj2_1_3_4  -486
    RHS       disj1_1_4_4  4
    RHS       disj2_1_4_4  -472
    RHS       disj1_1_5_4  4
    RHS       disj2_1_5_4  -475
    RHS       disj1_1_6_4  4
    RHS       disj2_1_6_4  -488
    RHS       disj1_2_3_4  16
    RHS       disj2_2_3_4  -486
    RHS       disj1_2_4_4  16
    RHS       disj2_2_4_4  -472
    RHS       disj1_2_5_4  16
    RHS       disj2_2_5_4  -475
    RHS       disj1_2_6_4  16
    RHS       disj2_2_6_4  -488
    RHS       disj1_3_4_4  5
    RHS       disj2_3_4_4  -472
    RHS       disj1_3_5_4  5
    RHS       disj2_3_5_4  -475
    RHS       disj1_3_6_4  5
    RHS       disj2_3_6_4  -488
    RHS       disj1_4_5_4  19
    RHS       disj2_4_5_4  -475
    RHS       disj1_4_6_4  19
    RHS       disj2_4_6_4  -488
    RHS       disj1_5_6_4  16
    RHS       disj2_5_6_4  -488
    RHS       disj1_0_1_5  18
    RHS       disj2_0_1_5  -471
    RHS       disj1_0_2_5  18
    RHS       disj2_0_2_5  -490
    RHS       disj1_0_3_5  18
    RHS       disj2_0_3_5  -489
    RHS       disj1_0_4_5  18
    RHS       disj2_0_4_5  -487
    RHS       disj1_0_5_5  18
    RHS       disj2_0_5_5  -476
    RHS       disj1_0_6_5  18
    RHS       disj2_0_6_5  -476
    RHS       disj1_1_2_5  20
    RHS       disj2_1_2_5  -490
    RHS       disj1_1_3_5  20
    RHS       disj2_1_3_5  -489
    RHS       disj1_1_4_5  20
    RHS       disj2_1_4_5  -487
    RHS       disj1_1_5_5  20
    RHS       disj2_1_5_5  -476
    RHS       disj1_1_6_5  20
    RHS       disj2_1_6_5  -476
    RHS       disj1_2_3_5  1
    RHS       disj2_2_3_5  -489
    RHS       disj1_2_4_5  1
    RHS       disj2_2_4_5  -487
    RHS       disj1_2_5_5  1
    RHS       disj2_2_5_5  -476
    RHS       disj1_2_6_5  1
    RHS       disj2_2_6_5  -476
    RHS       disj1_3_4_5  2
    RHS       disj2_3_4_5  -487
    RHS       disj1_3_5_5  2
    RHS       disj2_3_5_5  -476
    RHS       disj1_3_6_5  2
    RHS       disj2_3_6_5  -476
    RHS       disj1_4_5_5  4
    RHS       disj2_4_5_5  -476
    RHS       disj1_4_6_5  4
    RHS       disj2_4_6_5  -476
    RHS       disj1_5_6_5  15
    RHS       disj2_5_6_5  -476
    RHS       disj1_0_1_6  15
    RHS       disj2_0_1_6  -475
    RHS       disj1_0_2_6  15
    RHS       disj2_0_2_6  -486
    RHS       disj1_0_3_6  15
    RHS       disj2_0_3_6  -472
    RHS       disj1_0_4_6  15
    RHS       disj2_0_4_6  -476
    RHS       disj1_0_5_6  15
    RHS       disj2_0_5_6  -475
    RHS       disj1_0_6_6  15
    RHS       disj2_0_6_6  -486
    RHS       disj1_1_2_6  16
    RHS       disj2_1_2_6  -486
    RHS       disj1_1_3_6  16
    RHS       disj2_1_3_6  -472
    RHS       disj1_1_4_6  16
    RHS       disj2_1_4_6  -476
    RHS       disj1_1_5_6  16
    RHS       disj2_1_5_6  -475
    RHS       disj1_1_6_6  16
    RHS       disj2_1_6_6  -486
    RHS       disj1_2_3_6  5
    RHS       disj2_2_3_6  -472
    RHS       disj1_2_4_6  5
    RHS       disj2_2_4_6  -476
    RHS       disj1_2_5_6  5
    RHS       disj2_2_5_6  -475
    RHS       disj1_2_6_6  5
    RHS       disj2_2_6_6  -486
    RHS       disj1_3_4_6  19
    RHS       disj2_3_4_6  -476
    RHS       disj1_3_5_6  19
    RHS       disj2_3_5_6  -475
    RHS       disj1_3_6_6  19
    RHS       disj2_3_6_6  -486
    RHS       disj1_4_5_6  15
    RHS       disj2_4_5_6  -475
    RHS       disj1_4_6_6  15
    RHS       disj2_4_6_6  -486
    RHS       disj1_5_6_6  16
    RHS       disj2_5_6_6  -486
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_1_6
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_2_6
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_3_6
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_4_6
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_5_6
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_0_6_6
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_2_6
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_3_6
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_4_6
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_5_6
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_1_6_6
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_3_6
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_4_6
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_5_6
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_2_6_6
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_4_6
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_5_6
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_3_6_6
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_5_6
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_4_6_6
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
 BV BOUND     y_5_6_6
ENDATA
