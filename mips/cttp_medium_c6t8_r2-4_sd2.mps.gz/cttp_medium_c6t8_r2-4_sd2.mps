NAME          cttp_medium_c6t8_r2-4_sd2
ROWS
 N  OBJ
 L  DAY_0_1_0
 L  DAY_0_1_1
 L  DAY_0_1_2
 L  DAY_0_1_3
 L  DAY_0_1_4
 E  REQ_0_1
 L  DAY_0_3_0
 L  DAY_0_3_1
 L  DAY_0_3_2
 L  DAY_0_3_3
 L  DAY_0_3_4
 E  REQ_0_3
 L  DAY_0_4_0
 L  DAY_0_4_1
 L  DAY_0_4_2
 L  DAY_0_4_3
 L  DAY_0_4_4
 E  REQ_0_4
 L  DAY_0_5_0
 L  DAY_0_5_1
 L  DAY_0_5_2
 L  DAY_0_5_3
 L  DAY_0_5_4
 E  REQ_0_5
 L  DAY_1_2_0
 L  DAY_1_2_1
 L  DAY_1_2_2
 L  DAY_1_2_3
 L  DAY_1_2_4
 E  REQ_1_2
 L  DAY_1_5_0
 L  DAY_1_5_1
 L  DAY_1_5_2
 L  DAY_1_5_3
 L  DAY_1_5_4
 E  REQ_1_5
 L  DAY_1_6_0
 L  DAY_1_6_1
 L  DAY_1_6_2
 L  DAY_1_6_3
 L  DAY_1_6_4
 E  REQ_1_6
 L  DAY_1_7_0
 L  DAY_1_7_1
 L  DAY_1_7_2
 L  DAY_1_7_3
 L  DAY_1_7_4
 E  REQ_1_7
 L  DAY_2_0_0
 L  DAY_2_0_1
 L  DAY_2_0_2
 L  DAY_2_0_3
 L  DAY_2_0_4
 E  REQ_2_0
 L  DAY_2_2_0
 L  DAY_2_2_1
 L  DAY_2_2_2
 L  DAY_2_2_3
 L  DAY_2_2_4
 E  REQ_2_2
 L  DAY_2_3_0
 L  DAY_2_3_1
 L  DAY_2_3_2
 L  DAY_2_3_3
 L  DAY_2_3_4
 E  REQ_2_3
 L  DAY_2_5_0
 L  DAY_2_5_1
 L  DAY_2_5_2
 L  DAY_2_5_3
 L  DAY_2_5_4
 E  REQ_2_5
 L  DAY_2_6_0
 L  DAY_2_6_1
 L  DAY_2_6_2
 L  DAY_2_6_3
 L  DAY_2_6_4
 E  REQ_2_6
 L  DAY_3_2_0
 L  DAY_3_2_1
 L  DAY_3_2_2
 L  DAY_3_2_3
 L  DAY_3_2_4
 E  REQ_3_2
 L  DAY_3_5_0
 L  DAY_3_5_1
 L  DAY_3_5_2
 L  DAY_3_5_3
 L  DAY_3_5_4
 E  REQ_3_5
 L  DAY_3_6_0
 L  DAY_3_6_1
 L  DAY_3_6_2
 L  DAY_3_6_3
 L  DAY_3_6_4
 E  REQ_3_6
 L  DAY_3_7_0
 L  DAY_3_7_1
 L  DAY_3_7_2
 L  DAY_3_7_3
 L  DAY_3_7_4
 E  REQ_3_7
 L  DAY_4_2_0
 L  DAY_4_2_1
 L  DAY_4_2_2
 L  DAY_4_2_3
 L  DAY_4_2_4
 E  REQ_4_2
 L  DAY_4_3_0
 L  DAY_4_3_1
 L  DAY_4_3_2
 L  DAY_4_3_3
 L  DAY_4_3_4
 E  REQ_4_3
 L  DAY_4_4_0
 L  DAY_4_4_1
 L  DAY_4_4_2
 L  DAY_4_4_3
 L  DAY_4_4_4
 E  REQ_4_4
 L  DAY_4_5_0
 L  DAY_4_5_1
 L  DAY_4_5_2
 L  DAY_4_5_3
 L  DAY_4_5_4
 E  REQ_4_5
 L  DAY_4_6_0
 L  DAY_4_6_1
 L  DAY_4_6_2
 L  DAY_4_6_3
 L  DAY_4_6_4
 E  REQ_4_6
 L  DAY_4_7_0
 L  DAY_4_7_1
 L  DAY_4_7_2
 L  DAY_4_7_3
 L  DAY_4_7_4
 E  REQ_4_7
 L  DAY_5_0_0
 L  DAY_5_0_1
 L  DAY_5_0_2
 L  DAY_5_0_3
 L  DAY_5_0_4
 E  REQ_5_0
 L  DAY_5_1_0
 L  DAY_5_1_1
 L  DAY_5_1_2
 L  DAY_5_1_3
 L  DAY_5_1_4
 E  REQ_5_1
 L  DAY_5_2_0
 L  DAY_5_2_1
 L  DAY_5_2_2
 L  DAY_5_2_3
 L  DAY_5_2_4
 E  REQ_5_2
 L  DAY_5_3_0
 L  DAY_5_3_1
 L  DAY_5_3_2
 L  DAY_5_3_3
 L  DAY_5_3_4
 E  REQ_5_3
 L  DAY_5_4_0
 L  DAY_5_4_1
 L  DAY_5_4_2
 L  DAY_5_4_3
 L  DAY_5_4_4
 E  REQ_5_4
 L  DAY_5_5_0
 L  DAY_5_5_1
 L  DAY_5_5_2
 L  DAY_5_5_3
 L  DAY_5_5_4
 E  REQ_5_5
 E  OCC_0_0_0
 E  OCC_0_0_1
 E  OCC_0_0_2
 E  OCC_0_0_3
 E  OCC_0_0_4
 E  OCC_0_0_5
 E  OCC_0_1_0
 E  OCC_0_1_1
 E  OCC_0_1_2
 E  OCC_0_1_3
 E  OCC_0_1_4
 E  OCC_0_1_5
 E  OCC_0_2_0
 E  OCC_0_2_1
 E  OCC_0_2_2
 E  OCC_0_2_3
 E  OCC_0_2_4
 E  OCC_0_2_5
 E  OCC_0_3_0
 E  OCC_0_3_1
 E  OCC_0_3_2
 E  OCC_0_3_3
 E  OCC_0_3_4
 E  OCC_0_3_5
 E  OCC_0_4_0
 E  OCC_0_4_1
 E  OCC_0_4_2
 E  OCC_0_4_3
 E  OCC_0_4_4
 E  OCC_0_4_5
 E  OCC_1_0_0
 E  OCC_1_0_1
 E  OCC_1_0_2
 E  OCC_1_0_3
 E  OCC_1_0_4
 E  OCC_1_0_5
 E  OCC_1_1_0
 E  OCC_1_1_1
 E  OCC_1_1_2
 E  OCC_1_1_3
 E  OCC_1_1_4
 E  OCC_1_1_5
 E  OCC_1_2_0
 E  OCC_1_2_1
 E  OCC_1_2_2
 E  OCC_1_2_3
 E  OCC_1_2_4
 E  OCC_1_2_5
 E  OCC_1_3_0
 E  OCC_1_3_1
 E  OCC_1_3_2
 E  OCC_1_3_3
 E  OCC_1_3_4
 E  OCC_1_3_5
 E  OCC_1_4_0
 E  OCC_1_4_1
 E  OCC_1_4_2
 E  OCC_1_4_3
 E  OCC_1_4_4
 E  OCC_1_4_5
 E  OCC_2_0_0
 E  OCC_2_0_1
 E  OCC_2_0_2
 E  OCC_2_0_3
 E  OCC_2_0_4
 E  OCC_2_0_5
 E  OCC_2_1_0
 E  OCC_2_1_1
 E  OCC_2_1_2
 E  OCC_2_1_3
 E  OCC_2_1_4
 E  OCC_2_1_5
 E  OCC_2_2_0
 E  OCC_2_2_1
 E  OCC_2_2_2
 E  OCC_2_2_3
 E  OCC_2_2_4
 E  OCC_2_2_5
 E  OCC_2_3_0
 E  OCC_2_3_1
 E  OCC_2_3_2
 E  OCC_2_3_3
 E  OCC_2_3_4
 E  OCC_2_3_5
 E  OCC_2_4_0
 E  OCC_2_4_1
 E  OCC_2_4_2
 E  OCC_2_4_3
 E  OCC_2_4_4
 E  OCC_2_4_5
 E  OCC_3_0_0
 E  OCC_3_0_1
 E  OCC_3_0_2
 E  OCC_3_0_3
 E  OCC_3_0_4
 E  OCC_3_0_5
 E  OCC_3_1_0
 E  OCC_3_1_1
 E  OCC_3_1_2
 E  OCC_3_1_3
 E  OCC_3_1_4
 E  OCC_3_1_5
 E  OCC_3_2_0
 E  OCC_3_2_1
 E  OCC_3_2_2
 E  OCC_3_2_3
 E  OCC_3_2_4
 E  OCC_3_2_5
 E  OCC_3_3_0
 E  OCC_3_3_1
 E  OCC_3_3_2
 E  OCC_3_3_3
 E  OCC_3_3_4
 E  OCC_3_3_5
 E  OCC_3_4_0
 E  OCC_3_4_1
 E  OCC_3_4_2
 E  OCC_3_4_3
 E  OCC_3_4_4
 E  OCC_3_4_5
 E  OCC_4_0_0
 E  OCC_4_0_1
 E  OCC_4_0_2
 E  OCC_4_0_3
 E  OCC_4_0_4
 E  OCC_4_0_5
 E  OCC_4_1_0
 E  OCC_4_1_1
 E  OCC_4_1_2
 E  OCC_4_1_3
 E  OCC_4_1_4
 E  OCC_4_1_5
 E  OCC_4_2_0
 E  OCC_4_2_1
 E  OCC_4_2_2
 E  OCC_4_2_3
 E  OCC_4_2_4
 E  OCC_4_2_5
 E  OCC_4_3_0
 E  OCC_4_3_1
 E  OCC_4_3_2
 E  OCC_4_3_3
 E  OCC_4_3_4
 E  OCC_4_3_5
 E  OCC_4_4_0
 E  OCC_4_4_1
 E  OCC_4_4_2
 E  OCC_4_4_3
 E  OCC_4_4_4
 E  OCC_4_4_5
 E  OCC_5_0_0
 E  OCC_5_0_1
 E  OCC_5_0_2
 E  OCC_5_0_3
 E  OCC_5_0_4
 E  OCC_5_0_5
 E  OCC_5_1_0
 E  OCC_5_1_1
 E  OCC_5_1_2
 E  OCC_5_1_3
 E  OCC_5_1_4
 E  OCC_5_1_5
 E  OCC_5_2_0
 E  OCC_5_2_1
 E  OCC_5_2_2
 E  OCC_5_2_3
 E  OCC_5_2_4
 E  OCC_5_2_5
 E  OCC_5_3_0
 E  OCC_5_3_1
 E  OCC_5_3_2
 E  OCC_5_3_3
 E  OCC_5_3_4
 E  OCC_5_3_5
 E  OCC_5_4_0
 E  OCC_5_4_1
 E  OCC_5_4_2
 E  OCC_5_4_3
 E  OCC_5_4_4
 E  OCC_5_4_5
 E  OCC_6_0_0
 E  OCC_6_0_1
 E  OCC_6_0_2
 E  OCC_6_0_3
 E  OCC_6_0_4
 E  OCC_6_0_5
 E  OCC_6_1_0
 E  OCC_6_1_1
 E  OCC_6_1_2
 E  OCC_6_1_3
 E  OCC_6_1_4
 E  OCC_6_1_5
 E  OCC_6_2_0
 E  OCC_6_2_1
 E  OCC_6_2_2
 E  OCC_6_2_3
 E  OCC_6_2_4
 E  OCC_6_2_5
 E  OCC_6_3_0
 E  OCC_6_3_1
 E  OCC_6_3_2
 E  OCC_6_3_3
 E  OCC_6_3_4
 E  OCC_6_3_5
 E  OCC_6_4_0
 E  OCC_6_4_1
 E  OCC_6_4_2
 E  OCC_6_4_3
 E  OCC_6_4_4
 E  OCC_6_4_5
 E  OCC_7_0_0
 E  OCC_7_0_1
 E  OCC_7_0_2
 E  OCC_7_0_3
 E  OCC_7_0_4
 E  OCC_7_0_5
 E  OCC_7_1_0
 E  OCC_7_1_1
 E  OCC_7_1_2
 E  OCC_7_1_3
 E  OCC_7_1_4
 E  OCC_7_1_5
 E  OCC_7_2_0
 E  OCC_7_2_1
 E  OCC_7_2_2
 E  OCC_7_2_3
 E  OCC_7_2_4
 E  OCC_7_2_5
 E  OCC_7_3_0
 E  OCC_7_3_1
 E  OCC_7_3_2
 E  OCC_7_3_3
 E  OCC_7_3_4
 E  OCC_7_3_5
 E  OCC_7_4_0
 E  OCC_7_4_1
 E  OCC_7_4_2
 E  OCC_7_4_3
 E  OCC_7_4_4
 E  OCC_7_4_5
 E  CLS_0_0_0
 E  CLS_0_0_1
 E  CLS_0_0_2
 E  CLS_0_0_3
 E  CLS_0_0_4
 E  CLS_0_0_5
 E  CLS_0_1_0
 E  CLS_0_1_1
 E  CLS_0_1_2
 E  CLS_0_1_3
 E  CLS_0_1_4
 E  CLS_0_1_5
 E  CLS_0_2_0
 E  CLS_0_2_1
 E  CLS_0_2_2
 E  CLS_0_2_3
 E  CLS_0_2_4
 E  CLS_0_2_5
 E  CLS_0_3_0
 E  CLS_0_3_1
 E  CLS_0_3_2
 E  CLS_0_3_3
 E  CLS_0_3_4
 E  CLS_0_3_5
 E  CLS_0_4_0
 E  CLS_0_4_1
 E  CLS_0_4_2
 E  CLS_0_4_3
 E  CLS_0_4_4
 E  CLS_0_4_5
 E  CLS_1_0_0
 E  CLS_1_0_1
 E  CLS_1_0_2
 E  CLS_1_0_3
 E  CLS_1_0_4
 E  CLS_1_0_5
 E  CLS_1_1_0
 E  CLS_1_1_1
 E  CLS_1_1_2
 E  CLS_1_1_3
 E  CLS_1_1_4
 E  CLS_1_1_5
 E  CLS_1_2_0
 E  CLS_1_2_1
 E  CLS_1_2_2
 E  CLS_1_2_3
 E  CLS_1_2_4
 E  CLS_1_2_5
 E  CLS_1_3_0
 E  CLS_1_3_1
 E  CLS_1_3_2
 E  CLS_1_3_3
 E  CLS_1_3_4
 E  CLS_1_3_5
 E  CLS_1_4_0
 E  CLS_1_4_1
 E  CLS_1_4_2
 E  CLS_1_4_3
 E  CLS_1_4_4
 E  CLS_1_4_5
 E  CLS_2_0_0
 E  CLS_2_0_1
 E  CLS_2_0_2
 E  CLS_2_0_3
 E  CLS_2_0_4
 E  CLS_2_0_5
 E  CLS_2_1_0
 E  CLS_2_1_1
 E  CLS_2_1_2
 E  CLS_2_1_3
 E  CLS_2_1_4
 E  CLS_2_1_5
 E  CLS_2_2_0
 E  CLS_2_2_1
 E  CLS_2_2_2
 E  CLS_2_2_3
 E  CLS_2_2_4
 E  CLS_2_2_5
 E  CLS_2_3_0
 E  CLS_2_3_1
 E  CLS_2_3_2
 E  CLS_2_3_3
 E  CLS_2_3_4
 E  CLS_2_3_5
 E  CLS_2_4_0
 E  CLS_2_4_1
 E  CLS_2_4_2
 E  CLS_2_4_3
 E  CLS_2_4_4
 E  CLS_2_4_5
 E  CLS_3_0_0
 E  CLS_3_0_1
 E  CLS_3_0_2
 E  CLS_3_0_3
 E  CLS_3_0_4
 E  CLS_3_0_5
 E  CLS_3_1_0
 E  CLS_3_1_1
 E  CLS_3_1_2
 E  CLS_3_1_3
 E  CLS_3_1_4
 E  CLS_3_1_5
 E  CLS_3_2_0
 E  CLS_3_2_1
 E  CLS_3_2_2
 E  CLS_3_2_3
 E  CLS_3_2_4
 E  CLS_3_2_5
 E  CLS_3_3_0
 E  CLS_3_3_1
 E  CLS_3_3_2
 E  CLS_3_3_3
 E  CLS_3_3_4
 E  CLS_3_3_5
 E  CLS_3_4_0
 E  CLS_3_4_1
 E  CLS_3_4_2
 E  CLS_3_4_3
 E  CLS_3_4_4
 E  CLS_3_4_5
 E  CLS_4_0_0
 E  CLS_4_0_1
 E  CLS_4_0_2
 E  CLS_4_0_3
 E  CLS_4_0_4
 E  CLS_4_0_5
 E  CLS_4_1_0
 E  CLS_4_1_1
 E  CLS_4_1_2
 E  CLS_4_1_3
 E  CLS_4_1_4
 E  CLS_4_1_5
 E  CLS_4_2_0
 E  CLS_4_2_1
 E  CLS_4_2_2
 E  CLS_4_2_3
 E  CLS_4_2_4
 E  CLS_4_2_5
 E  CLS_4_3_0
 E  CLS_4_3_1
 E  CLS_4_3_2
 E  CLS_4_3_3
 E  CLS_4_3_4
 E  CLS_4_3_5
 E  CLS_4_4_0
 E  CLS_4_4_1
 E  CLS_4_4_2
 E  CLS_4_4_3
 E  CLS_4_4_4
 E  CLS_4_4_5
 E  CLS_5_0_0
 E  CLS_5_0_1
 E  CLS_5_0_2
 E  CLS_5_0_3
 E  CLS_5_0_4
 E  CLS_5_0_5
 E  CLS_5_1_0
 E  CLS_5_1_1
 E  CLS_5_1_2
 E  CLS_5_1_3
 E  CLS_5_1_4
 E  CLS_5_1_5
 E  CLS_5_2_0
 E  CLS_5_2_1
 E  CLS_5_2_2
 E  CLS_5_2_3
 E  CLS_5_2_4
 E  CLS_5_2_5
 E  CLS_5_3_0
 E  CLS_5_3_1
 E  CLS_5_3_2
 E  CLS_5_3_3
 E  CLS_5_3_4
 E  CLS_5_3_5
 E  CLS_5_4_0
 E  CLS_5_4_1
 E  CLS_5_4_2
 E  CLS_5_4_3
 E  CLS_5_4_4
 E  CLS_5_4_5
 G  WDEF_0_0_0
 G  WDEF_0_0_1
 G  WDEF_0_0_2
 G  WDEF_0_0_3
 G  WDEF_0_0_4
 G  WDEF_0_0_5
 G  WDEF_0_1_0
 G  WDEF_0_1_1
 G  WDEF_0_1_2
 G  WDEF_0_1_3
 G  WDEF_0_1_4
 G  WDEF_0_1_5
 G  WDEF_0_2_0
 G  WDEF_0_2_1
 G  WDEF_0_2_2
 G  WDEF_0_2_3
 G  WDEF_0_2_4
 G  WDEF_0_2_5
 G  WDEF_0_3_0
 G  WDEF_0_3_1
 G  WDEF_0_3_2
 G  WDEF_0_3_3
 G  WDEF_0_3_4
 G  WDEF_0_3_5
 G  WDEF_0_4_0
 G  WDEF_0_4_1
 G  WDEF_0_4_2
 G  WDEF_0_4_3
 G  WDEF_0_4_4
 G  WDEF_0_4_5
 G  WDEF_1_0_0
 G  WDEF_1_0_1
 G  WDEF_1_0_2
 G  WDEF_1_0_3
 G  WDEF_1_0_4
 G  WDEF_1_0_5
 G  WDEF_1_1_0
 G  WDEF_1_1_1
 G  WDEF_1_1_2
 G  WDEF_1_1_3
 G  WDEF_1_1_4
 G  WDEF_1_1_5
 G  WDEF_1_2_0
 G  WDEF_1_2_1
 G  WDEF_1_2_2
 G  WDEF_1_2_3
 G  WDEF_1_2_4
 G  WDEF_1_2_5
 G  WDEF_1_3_0
 G  WDEF_1_3_1
 G  WDEF_1_3_2
 G  WDEF_1_3_3
 G  WDEF_1_3_4
 G  WDEF_1_3_5
 G  WDEF_1_4_0
 G  WDEF_1_4_1
 G  WDEF_1_4_2
 G  WDEF_1_4_3
 G  WDEF_1_4_4
 G  WDEF_1_4_5
 G  WDEF_2_0_0
 G  WDEF_2_0_1
 G  WDEF_2_0_2
 G  WDEF_2_0_3
 G  WDEF_2_0_4
 G  WDEF_2_0_5
 G  WDEF_2_1_0
 G  WDEF_2_1_1
 G  WDEF_2_1_2
 G  WDEF_2_1_3
 G  WDEF_2_1_4
 G  WDEF_2_1_5
 G  WDEF_2_2_0
 G  WDEF_2_2_1
 G  WDEF_2_2_2
 G  WDEF_2_2_3
 G  WDEF_2_2_4
 G  WDEF_2_2_5
 G  WDEF_2_3_0
 G  WDEF_2_3_1
 G  WDEF_2_3_2
 G  WDEF_2_3_3
 G  WDEF_2_3_4
 G  WDEF_2_3_5
 G  WDEF_2_4_0
 G  WDEF_2_4_1
 G  WDEF_2_4_2
 G  WDEF_2_4_3
 G  WDEF_2_4_4
 G  WDEF_2_4_5
 G  WDEF_3_0_0
 G  WDEF_3_0_1
 G  WDEF_3_0_2
 G  WDEF_3_0_3
 G  WDEF_3_0_4
 G  WDEF_3_0_5
 G  WDEF_3_1_0
 G  WDEF_3_1_1
 G  WDEF_3_1_2
 G  WDEF_3_1_3
 G  WDEF_3_1_4
 G  WDEF_3_1_5
 G  WDEF_3_2_0
 G  WDEF_3_2_1
 G  WDEF_3_2_2
 G  WDEF_3_2_3
 G  WDEF_3_2_4
 G  WDEF_3_2_5
 G  WDEF_3_3_0
 G  WDEF_3_3_1
 G  WDEF_3_3_2
 G  WDEF_3_3_3
 G  WDEF_3_3_4
 G  WDEF_3_3_5
 G  WDEF_3_4_0
 G  WDEF_3_4_1
 G  WDEF_3_4_2
 G  WDEF_3_4_3
 G  WDEF_3_4_4
 G  WDEF_3_4_5
 G  WDEF_4_0_0
 G  WDEF_4_0_1
 G  WDEF_4_0_2
 G  WDEF_4_0_3
 G  WDEF_4_0_4
 G  WDEF_4_0_5
 G  WDEF_4_1_0
 G  WDEF_4_1_1
 G  WDEF_4_1_2
 G  WDEF_4_1_3
 G  WDEF_4_1_4
 G  WDEF_4_1_5
 G  WDEF_4_2_0
 G  WDEF_4_2_1
 G  WDEF_4_2_2
 G  WDEF_4_2_3
 G  WDEF_4_2_4
 G  WDEF_4_2_5
 G  WDEF_4_3_0
 G  WDEF_4_3_1
 G  WDEF_4_3_2
 G  WDEF_4_3_3
 G  WDEF_4_3_4
 G  WDEF_4_3_5
 G  WDEF_4_4_0
 G  WDEF_4_4_1
 G  WDEF_4_4_2
 G  WDEF_4_4_3
 G  WDEF_4_4_4
 G  WDEF_4_4_5
 G  WDEF_5_0_0
 G  WDEF_5_0_1
 G  WDEF_5_0_2
 G  WDEF_5_0_3
 G  WDEF_5_0_4
 G  WDEF_5_0_5
 G  WDEF_5_1_0
 G  WDEF_5_1_1
 G  WDEF_5_1_2
 G  WDEF_5_1_3
 G  WDEF_5_1_4
 G  WDEF_5_1_5
 G  WDEF_5_2_0
 G  WDEF_5_2_1
 G  WDEF_5_2_2
 G  WDEF_5_2_3
 G  WDEF_5_2_4
 G  WDEF_5_2_5
 G  WDEF_5_3_0
 G  WDEF_5_3_1
 G  WDEF_5_3_2
 G  WDEF_5_3_3
 G  WDEF_5_3_4
 G  WDEF_5_3_5
 G  WDEF_5_4_0
 G  WDEF_5_4_1
 G  WDEF_5_4_2
 G  WDEF_5_4_3
 G  WDEF_5_4_4
 G  WDEF_5_4_5
 G  WDEF_6_0_0
 G  WDEF_6_0_1
 G  WDEF_6_0_2
 G  WDEF_6_0_3
 G  WDEF_6_0_4
 G  WDEF_6_0_5
 G  WDEF_6_1_0
 G  WDEF_6_1_1
 G  WDEF_6_1_2
 G  WDEF_6_1_3
 G  WDEF_6_1_4
 G  WDEF_6_1_5
 G  WDEF_6_2_0
 G  WDEF_6_2_1
 G  WDEF_6_2_2
 G  WDEF_6_2_3
 G  WDEF_6_2_4
 G  WDEF_6_2_5
 G  WDEF_6_3_0
 G  WDEF_6_3_1
 G  WDEF_6_3_2
 G  WDEF_6_3_3
 G  WDEF_6_3_4
 G  WDEF_6_3_5
 G  WDEF_6_4_0
 G  WDEF_6_4_1
 G  WDEF_6_4_2
 G  WDEF_6_4_3
 G  WDEF_6_4_4
 G  WDEF_6_4_5
 G  WDEF_7_0_0
 G  WDEF_7_0_1
 G  WDEF_7_0_2
 G  WDEF_7_0_3
 G  WDEF_7_0_4
 G  WDEF_7_0_5
 G  WDEF_7_1_0
 G  WDEF_7_1_1
 G  WDEF_7_1_2
 G  WDEF_7_1_3
 G  WDEF_7_1_4
 G  WDEF_7_1_5
 G  WDEF_7_2_0
 G  WDEF_7_2_1
 G  WDEF_7_2_2
 G  WDEF_7_2_3
 G  WDEF_7_2_4
 G  WDEF_7_2_5
 G  WDEF_7_3_0
 G  WDEF_7_3_1
 G  WDEF_7_3_2
 G  WDEF_7_3_3
 G  WDEF_7_3_4
 G  WDEF_7_3_5
 G  WDEF_7_4_0
 G  WDEF_7_4_1
 G  WDEF_7_4_2
 G  WDEF_7_4_3
 G  WDEF_7_4_4
 G  WDEF_7_4_5
 G  AFCH_0_0_0
 G  AFO_0_0_0
 G  BFCH_0_0_1
 G  BFO_0_0_1
 G  AFCH_0_0_1
 G  AFO_0_0_1
 G  BFCH_0_0_2
 G  BFO_0_0_2
 G  AFCH_0_0_2
 G  AFO_0_0_2
 G  BFCH_0_0_3
 G  BFO_0_0_3
 G  AFCH_0_0_3
 G  AFO_0_0_3
 G  BFCH_0_0_4
 G  BFO_0_0_4
 G  AFCH_0_0_4
 G  AFO_0_0_4
 G  BFCH_0_0_5
 G  BFO_0_0_5
 G  AFCH_0_1_0
 G  AFO_0_1_0
 G  BFCH_0_1_1
 G  BFO_0_1_1
 G  AFCH_0_1_1
 G  AFO_0_1_1
 G  BFCH_0_1_2
 G  BFO_0_1_2
 G  AFCH_0_1_2
 G  AFO_0_1_2
 G  BFCH_0_1_3
 G  BFO_0_1_3
 G  AFCH_0_1_3
 G  AFO_0_1_3
 G  BFCH_0_1_4
 G  BFO_0_1_4
 G  AFCH_0_1_4
 G  AFO_0_1_4
 G  BFCH_0_1_5
 G  BFO_0_1_5
 G  AFCH_0_2_0
 G  AFO_0_2_0
 G  BFCH_0_2_1
 G  BFO_0_2_1
 G  AFCH_0_2_1
 G  AFO_0_2_1
 G  BFCH_0_2_2
 G  BFO_0_2_2
 G  AFCH_0_2_2
 G  AFO_0_2_2
 G  BFCH_0_2_3
 G  BFO_0_2_3
 G  AFCH_0_2_3
 G  AFO_0_2_3
 G  BFCH_0_2_4
 G  BFO_0_2_4
 G  AFCH_0_2_4
 G  AFO_0_2_4
 G  BFCH_0_2_5
 G  BFO_0_2_5
 G  AFCH_0_3_0
 G  AFO_0_3_0
 G  BFCH_0_3_1
 G  BFO_0_3_1
 G  AFCH_0_3_1
 G  AFO_0_3_1
 G  BFCH_0_3_2
 G  BFO_0_3_2
 G  AFCH_0_3_2
 G  AFO_0_3_2
 G  BFCH_0_3_3
 G  BFO_0_3_3
 G  AFCH_0_3_3
 G  AFO_0_3_3
 G  BFCH_0_3_4
 G  BFO_0_3_4
 G  AFCH_0_3_4
 G  AFO_0_3_4
 G  BFCH_0_3_5
 G  BFO_0_3_5
 G  AFCH_0_4_0
 G  AFO_0_4_0
 G  BFCH_0_4_1
 G  BFO_0_4_1
 G  AFCH_0_4_1
 G  AFO_0_4_1
 G  BFCH_0_4_2
 G  BFO_0_4_2
 G  AFCH_0_4_2
 G  AFO_0_4_2
 G  BFCH_0_4_3
 G  BFO_0_4_3
 G  AFCH_0_4_3
 G  AFO_0_4_3
 G  BFCH_0_4_4
 G  BFO_0_4_4
 G  AFCH_0_4_4
 G  AFO_0_4_4
 G  BFCH_0_4_5
 G  BFO_0_4_5
 G  AFCH_1_0_0
 G  AFO_1_0_0
 G  BFCH_1_0_1
 G  BFO_1_0_1
 G  AFCH_1_0_1
 G  AFO_1_0_1
 G  BFCH_1_0_2
 G  BFO_1_0_2
 G  AFCH_1_0_2
 G  AFO_1_0_2
 G  BFCH_1_0_3
 G  BFO_1_0_3
 G  AFCH_1_0_3
 G  AFO_1_0_3
 G  BFCH_1_0_4
 G  BFO_1_0_4
 G  AFCH_1_0_4
 G  AFO_1_0_4
 G  BFCH_1_0_5
 G  BFO_1_0_5
 G  AFCH_1_1_0
 G  AFO_1_1_0
 G  BFCH_1_1_1
 G  BFO_1_1_1
 G  AFCH_1_1_1
 G  AFO_1_1_1
 G  BFCH_1_1_2
 G  BFO_1_1_2
 G  AFCH_1_1_2
 G  AFO_1_1_2
 G  BFCH_1_1_3
 G  BFO_1_1_3
 G  AFCH_1_1_3
 G  AFO_1_1_3
 G  BFCH_1_1_4
 G  BFO_1_1_4
 G  AFCH_1_1_4
 G  AFO_1_1_4
 G  BFCH_1_1_5
 G  BFO_1_1_5
 G  AFCH_1_2_0
 G  AFO_1_2_0
 G  BFCH_1_2_1
 G  BFO_1_2_1
 G  AFCH_1_2_1
 G  AFO_1_2_1
 G  BFCH_1_2_2
 G  BFO_1_2_2
 G  AFCH_1_2_2
 G  AFO_1_2_2
 G  BFCH_1_2_3
 G  BFO_1_2_3
 G  AFCH_1_2_3
 G  AFO_1_2_3
 G  BFCH_1_2_4
 G  BFO_1_2_4
 G  AFCH_1_2_4
 G  AFO_1_2_4
 G  BFCH_1_2_5
 G  BFO_1_2_5
 G  AFCH_1_3_0
 G  AFO_1_3_0
 G  BFCH_1_3_1
 G  BFO_1_3_1
 G  AFCH_1_3_1
 G  AFO_1_3_1
 G  BFCH_1_3_2
 G  BFO_1_3_2
 G  AFCH_1_3_2
 G  AFO_1_3_2
 G  BFCH_1_3_3
 G  BFO_1_3_3
 G  AFCH_1_3_3
 G  AFO_1_3_3
 G  BFCH_1_3_4
 G  BFO_1_3_4
 G  AFCH_1_3_4
 G  AFO_1_3_4
 G  BFCH_1_3_5
 G  BFO_1_3_5
 G  AFCH_1_4_0
 G  AFO_1_4_0
 G  BFCH_1_4_1
 G  BFO_1_4_1
 G  AFCH_1_4_1
 G  AFO_1_4_1
 G  BFCH_1_4_2
 G  BFO_1_4_2
 G  AFCH_1_4_2
 G  AFO_1_4_2
 G  BFCH_1_4_3
 G  BFO_1_4_3
 G  AFCH_1_4_3
 G  AFO_1_4_3
 G  BFCH_1_4_4
 G  BFO_1_4_4
 G  AFCH_1_4_4
 G  AFO_1_4_4
 G  BFCH_1_4_5
 G  BFO_1_4_5
 G  AFCH_2_0_0
 G  AFO_2_0_0
 G  BFCH_2_0_1
 G  BFO_2_0_1
 G  AFCH_2_0_1
 G  AFO_2_0_1
 G  BFCH_2_0_2
 G  BFO_2_0_2
 G  AFCH_2_0_2
 G  AFO_2_0_2
 G  BFCH_2_0_3
 G  BFO_2_0_3
 G  AFCH_2_0_3
 G  AFO_2_0_3
 G  BFCH_2_0_4
 G  BFO_2_0_4
 G  AFCH_2_0_4
 G  AFO_2_0_4
 G  BFCH_2_0_5
 G  BFO_2_0_5
 G  AFCH_2_1_0
 G  AFO_2_1_0
 G  BFCH_2_1_1
 G  BFO_2_1_1
 G  AFCH_2_1_1
 G  AFO_2_1_1
 G  BFCH_2_1_2
 G  BFO_2_1_2
 G  AFCH_2_1_2
 G  AFO_2_1_2
 G  BFCH_2_1_3
 G  BFO_2_1_3
 G  AFCH_2_1_3
 G  AFO_2_1_3
 G  BFCH_2_1_4
 G  BFO_2_1_4
 G  AFCH_2_1_4
 G  AFO_2_1_4
 G  BFCH_2_1_5
 G  BFO_2_1_5
 G  AFCH_2_2_0
 G  AFO_2_2_0
 G  BFCH_2_2_1
 G  BFO_2_2_1
 G  AFCH_2_2_1
 G  AFO_2_2_1
 G  BFCH_2_2_2
 G  BFO_2_2_2
 G  AFCH_2_2_2
 G  AFO_2_2_2
 G  BFCH_2_2_3
 G  BFO_2_2_3
 G  AFCH_2_2_3
 G  AFO_2_2_3
 G  BFCH_2_2_4
 G  BFO_2_2_4
 G  AFCH_2_2_4
 G  AFO_2_2_4
 G  BFCH_2_2_5
 G  BFO_2_2_5
 G  AFCH_2_3_0
 G  AFO_2_3_0
 G  BFCH_2_3_1
 G  BFO_2_3_1
 G  AFCH_2_3_1
 G  AFO_2_3_1
 G  BFCH_2_3_2
 G  BFO_2_3_2
 G  AFCH_2_3_2
 G  AFO_2_3_2
 G  BFCH_2_3_3
 G  BFO_2_3_3
 G  AFCH_2_3_3
 G  AFO_2_3_3
 G  BFCH_2_3_4
 G  BFO_2_3_4
 G  AFCH_2_3_4
 G  AFO_2_3_4
 G  BFCH_2_3_5
 G  BFO_2_3_5
 G  AFCH_2_4_0
 G  AFO_2_4_0
 G  BFCH_2_4_1
 G  BFO_2_4_1
 G  AFCH_2_4_1
 G  AFO_2_4_1
 G  BFCH_2_4_2
 G  BFO_2_4_2
 G  AFCH_2_4_2
 G  AFO_2_4_2
 G  BFCH_2_4_3
 G  BFO_2_4_3
 G  AFCH_2_4_3
 G  AFO_2_4_3
 G  BFCH_2_4_4
 G  BFO_2_4_4
 G  AFCH_2_4_4
 G  AFO_2_4_4
 G  BFCH_2_4_5
 G  BFO_2_4_5
 G  AFCH_3_0_0
 G  AFO_3_0_0
 G  BFCH_3_0_1
 G  BFO_3_0_1
 G  AFCH_3_0_1
 G  AFO_3_0_1
 G  BFCH_3_0_2
 G  BFO_3_0_2
 G  AFCH_3_0_2
 G  AFO_3_0_2
 G  BFCH_3_0_3
 G  BFO_3_0_3
 G  AFCH_3_0_3
 G  AFO_3_0_3
 G  BFCH_3_0_4
 G  BFO_3_0_4
 G  AFCH_3_0_4
 G  AFO_3_0_4
 G  BFCH_3_0_5
 G  BFO_3_0_5
 G  AFCH_3_1_0
 G  AFO_3_1_0
 G  BFCH_3_1_1
 G  BFO_3_1_1
 G  AFCH_3_1_1
 G  AFO_3_1_1
 G  BFCH_3_1_2
 G  BFO_3_1_2
 G  AFCH_3_1_2
 G  AFO_3_1_2
 G  BFCH_3_1_3
 G  BFO_3_1_3
 G  AFCH_3_1_3
 G  AFO_3_1_3
 G  BFCH_3_1_4
 G  BFO_3_1_4
 G  AFCH_3_1_4
 G  AFO_3_1_4
 G  BFCH_3_1_5
 G  BFO_3_1_5
 G  AFCH_3_2_0
 G  AFO_3_2_0
 G  BFCH_3_2_1
 G  BFO_3_2_1
 G  AFCH_3_2_1
 G  AFO_3_2_1
 G  BFCH_3_2_2
 G  BFO_3_2_2
 G  AFCH_3_2_2
 G  AFO_3_2_2
 G  BFCH_3_2_3
 G  BFO_3_2_3
 G  AFCH_3_2_3
 G  AFO_3_2_3
 G  BFCH_3_2_4
 G  BFO_3_2_4
 G  AFCH_3_2_4
 G  AFO_3_2_4
 G  BFCH_3_2_5
 G  BFO_3_2_5
 G  AFCH_3_3_0
 G  AFO_3_3_0
 G  BFCH_3_3_1
 G  BFO_3_3_1
 G  AFCH_3_3_1
 G  AFO_3_3_1
 G  BFCH_3_3_2
 G  BFO_3_3_2
 G  AFCH_3_3_2
 G  AFO_3_3_2
 G  BFCH_3_3_3
 G  BFO_3_3_3
 G  AFCH_3_3_3
 G  AFO_3_3_3
 G  BFCH_3_3_4
 G  BFO_3_3_4
 G  AFCH_3_3_4
 G  AFO_3_3_4
 G  BFCH_3_3_5
 G  BFO_3_3_5
 G  AFCH_3_4_0
 G  AFO_3_4_0
 G  BFCH_3_4_1
 G  BFO_3_4_1
 G  AFCH_3_4_1
 G  AFO_3_4_1
 G  BFCH_3_4_2
 G  BFO_3_4_2
 G  AFCH_3_4_2
 G  AFO_3_4_2
 G  BFCH_3_4_3
 G  BFO_3_4_3
 G  AFCH_3_4_3
 G  AFO_3_4_3
 G  BFCH_3_4_4
 G  BFO_3_4_4
 G  AFCH_3_4_4
 G  AFO_3_4_4
 G  BFCH_3_4_5
 G  BFO_3_4_5
 G  AFCH_4_0_0
 G  AFO_4_0_0
 G  BFCH_4_0_1
 G  BFO_4_0_1
 G  AFCH_4_0_1
 G  AFO_4_0_1
 G  BFCH_4_0_2
 G  BFO_4_0_2
 G  AFCH_4_0_2
 G  AFO_4_0_2
 G  BFCH_4_0_3
 G  BFO_4_0_3
 G  AFCH_4_0_3
 G  AFO_4_0_3
 G  BFCH_4_0_4
 G  BFO_4_0_4
 G  AFCH_4_0_4
 G  AFO_4_0_4
 G  BFCH_4_0_5
 G  BFO_4_0_5
 G  AFCH_4_1_0
 G  AFO_4_1_0
 G  BFCH_4_1_1
 G  BFO_4_1_1
 G  AFCH_4_1_1
 G  AFO_4_1_1
 G  BFCH_4_1_2
 G  BFO_4_1_2
 G  AFCH_4_1_2
 G  AFO_4_1_2
 G  BFCH_4_1_3
 G  BFO_4_1_3
 G  AFCH_4_1_3
 G  AFO_4_1_3
 G  BFCH_4_1_4
 G  BFO_4_1_4
 G  AFCH_4_1_4
 G  AFO_4_1_4
 G  BFCH_4_1_5
 G  BFO_4_1_5
 G  AFCH_4_2_0
 G  AFO_4_2_0
 G  BFCH_4_2_1
 G  BFO_4_2_1
 G  AFCH_4_2_1
 G  AFO_4_2_1
 G  BFCH_4_2_2
 G  BFO_4_2_2
 G  AFCH_4_2_2
 G  AFO_4_2_2
 G  BFCH_4_2_3
 G  BFO_4_2_3
 G  AFCH_4_2_3
 G  AFO_4_2_3
 G  BFCH_4_2_4
 G  BFO_4_2_4
 G  AFCH_4_2_4
 G  AFO_4_2_4
 G  BFCH_4_2_5
 G  BFO_4_2_5
 G  AFCH_4_3_0
 G  AFO_4_3_0
 G  BFCH_4_3_1
 G  BFO_4_3_1
 G  AFCH_4_3_1
 G  AFO_4_3_1
 G  BFCH_4_3_2
 G  BFO_4_3_2
 G  AFCH_4_3_2
 G  AFO_4_3_2
 G  BFCH_4_3_3
 G  BFO_4_3_3
 G  AFCH_4_3_3
 G  AFO_4_3_3
 G  BFCH_4_3_4
 G  BFO_4_3_4
 G  AFCH_4_3_4
 G  AFO_4_3_4
 G  BFCH_4_3_5
 G  BFO_4_3_5
 G  AFCH_4_4_0
 G  AFO_4_4_0
 G  BFCH_4_4_1
 G  BFO_4_4_1
 G  AFCH_4_4_1
 G  AFO_4_4_1
 G  BFCH_4_4_2
 G  BFO_4_4_2
 G  AFCH_4_4_2
 G  AFO_4_4_2
 G  BFCH_4_4_3
 G  BFO_4_4_3
 G  AFCH_4_4_3
 G  AFO_4_4_3
 G  BFCH_4_4_4
 G  BFO_4_4_4
 G  AFCH_4_4_4
 G  AFO_4_4_4
 G  BFCH_4_4_5
 G  BFO_4_4_5
 G  AFCH_5_0_0
 G  AFO_5_0_0
 G  BFCH_5_0_1
 G  BFO_5_0_1
 G  AFCH_5_0_1
 G  AFO_5_0_1
 G  BFCH_5_0_2
 G  BFO_5_0_2
 G  AFCH_5_0_2
 G  AFO_5_0_2
 G  BFCH_5_0_3
 G  BFO_5_0_3
 G  AFCH_5_0_3
 G  AFO_5_0_3
 G  BFCH_5_0_4
 G  BFO_5_0_4
 G  AFCH_5_0_4
 G  AFO_5_0_4
 G  BFCH_5_0_5
 G  BFO_5_0_5
 G  AFCH_5_1_0
 G  AFO_5_1_0
 G  BFCH_5_1_1
 G  BFO_5_1_1
 G  AFCH_5_1_1
 G  AFO_5_1_1
 G  BFCH_5_1_2
 G  BFO_5_1_2
 G  AFCH_5_1_2
 G  AFO_5_1_2
 G  BFCH_5_1_3
 G  BFO_5_1_3
 G  AFCH_5_1_3
 G  AFO_5_1_3
 G  BFCH_5_1_4
 G  BFO_5_1_4
 G  AFCH_5_1_4
 G  AFO_5_1_4
 G  BFCH_5_1_5
 G  BFO_5_1_5
 G  AFCH_5_2_0
 G  AFO_5_2_0
 G  BFCH_5_2_1
 G  BFO_5_2_1
 G  AFCH_5_2_1
 G  AFO_5_2_1
 G  BFCH_5_2_2
 G  BFO_5_2_2
 G  AFCH_5_2_2
 G  AFO_5_2_2
 G  BFCH_5_2_3
 G  BFO_5_2_3
 G  AFCH_5_2_3
 G  AFO_5_2_3
 G  BFCH_5_2_4
 G  BFO_5_2_4
 G  AFCH_5_2_4
 G  AFO_5_2_4
 G  BFCH_5_2_5
 G  BFO_5_2_5
 G  AFCH_5_3_0
 G  AFO_5_3_0
 G  BFCH_5_3_1
 G  BFO_5_3_1
 G  AFCH_5_3_1
 G  AFO_5_3_1
 G  BFCH_5_3_2
 G  BFO_5_3_2
 G  AFCH_5_3_2
 G  AFO_5_3_2
 G  BFCH_5_3_3
 G  BFO_5_3_3
 G  AFCH_5_3_3
 G  AFO_5_3_3
 G  BFCH_5_3_4
 G  BFO_5_3_4
 G  AFCH_5_3_4
 G  AFO_5_3_4
 G  BFCH_5_3_5
 G  BFO_5_3_5
 G  AFCH_5_4_0
 G  AFO_5_4_0
 G  BFCH_5_4_1
 G  BFO_5_4_1
 G  AFCH_5_4_1
 G  AFO_5_4_1
 G  BFCH_5_4_2
 G  BFO_5_4_2
 G  AFCH_5_4_2
 G  AFO_5_4_2
 G  BFCH_5_4_3
 G  BFO_5_4_3
 G  AFCH_5_4_3
 G  AFO_5_4_3
 G  BFCH_5_4_4
 G  BFO_5_4_4
 G  AFCH_5_4_4
 G  AFO_5_4_4
 G  BFCH_5_4_5
 G  BFO_5_4_5
 G  AFCH_6_0_0
 G  AFO_6_0_0
 G  BFCH_6_0_1
 G  BFO_6_0_1
 G  AFCH_6_0_1
 G  AFO_6_0_1
 G  BFCH_6_0_2
 G  BFO_6_0_2
 G  AFCH_6_0_2
 G  AFO_6_0_2
 G  BFCH_6_0_3
 G  BFO_6_0_3
 G  AFCH_6_0_3
 G  AFO_6_0_3
 G  BFCH_6_0_4
 G  BFO_6_0_4
 G  AFCH_6_0_4
 G  AFO_6_0_4
 G  BFCH_6_0_5
 G  BFO_6_0_5
 G  AFCH_6_1_0
 G  AFO_6_1_0
 G  BFCH_6_1_1
 G  BFO_6_1_1
 G  AFCH_6_1_1
 G  AFO_6_1_1
 G  BFCH_6_1_2
 G  BFO_6_1_2
 G  AFCH_6_1_2
 G  AFO_6_1_2
 G  BFCH_6_1_3
 G  BFO_6_1_3
 G  AFCH_6_1_3
 G  AFO_6_1_3
 G  BFCH_6_1_4
 G  BFO_6_1_4
 G  AFCH_6_1_4
 G  AFO_6_1_4
 G  BFCH_6_1_5
 G  BFO_6_1_5
 G  AFCH_6_2_0
 G  AFO_6_2_0
 G  BFCH_6_2_1
 G  BFO_6_2_1
 G  AFCH_6_2_1
 G  AFO_6_2_1
 G  BFCH_6_2_2
 G  BFO_6_2_2
 G  AFCH_6_2_2
 G  AFO_6_2_2
 G  BFCH_6_2_3
 G  BFO_6_2_3
 G  AFCH_6_2_3
 G  AFO_6_2_3
 G  BFCH_6_2_4
 G  BFO_6_2_4
 G  AFCH_6_2_4
 G  AFO_6_2_4
 G  BFCH_6_2_5
 G  BFO_6_2_5
 G  AFCH_6_3_0
 G  AFO_6_3_0
 G  BFCH_6_3_1
 G  BFO_6_3_1
 G  AFCH_6_3_1
 G  AFO_6_3_1
 G  BFCH_6_3_2
 G  BFO_6_3_2
 G  AFCH_6_3_2
 G  AFO_6_3_2
 G  BFCH_6_3_3
 G  BFO_6_3_3
 G  AFCH_6_3_3
 G  AFO_6_3_3
 G  BFCH_6_3_4
 G  BFO_6_3_4
 G  AFCH_6_3_4
 G  AFO_6_3_4
 G  BFCH_6_3_5
 G  BFO_6_3_5
 G  AFCH_6_4_0
 G  AFO_6_4_0
 G  BFCH_6_4_1
 G  BFO_6_4_1
 G  AFCH_6_4_1
 G  AFO_6_4_1
 G  BFCH_6_4_2
 G  BFO_6_4_2
 G  AFCH_6_4_2
 G  AFO_6_4_2
 G  BFCH_6_4_3
 G  BFO_6_4_3
 G  AFCH_6_4_3
 G  AFO_6_4_3
 G  BFCH_6_4_4
 G  BFO_6_4_4
 G  AFCH_6_4_4
 G  AFO_6_4_4
 G  BFCH_6_4_5
 G  BFO_6_4_5
 G  AFCH_7_0_0
 G  AFO_7_0_0
 G  BFCH_7_0_1
 G  BFO_7_0_1
 G  AFCH_7_0_1
 G  AFO_7_0_1
 G  BFCH_7_0_2
 G  BFO_7_0_2
 G  AFCH_7_0_2
 G  AFO_7_0_2
 G  BFCH_7_0_3
 G  BFO_7_0_3
 G  AFCH_7_0_3
 G  AFO_7_0_3
 G  BFCH_7_0_4
 G  BFO_7_0_4
 G  AFCH_7_0_4
 G  AFO_7_0_4
 G  BFCH_7_0_5
 G  BFO_7_0_5
 G  AFCH_7_1_0
 G  AFO_7_1_0
 G  BFCH_7_1_1
 G  BFO_7_1_1
 G  AFCH_7_1_1
 G  AFO_7_1_1
 G  BFCH_7_1_2
 G  BFO_7_1_2
 G  AFCH_7_1_2
 G  AFO_7_1_2
 G  BFCH_7_1_3
 G  BFO_7_1_3
 G  AFCH_7_1_3
 G  AFO_7_1_3
 G  BFCH_7_1_4
 G  BFO_7_1_4
 G  AFCH_7_1_4
 G  AFO_7_1_4
 G  BFCH_7_1_5
 G  BFO_7_1_5
 G  AFCH_7_2_0
 G  AFO_7_2_0
 G  BFCH_7_2_1
 G  BFO_7_2_1
 G  AFCH_7_2_1
 G  AFO_7_2_1
 G  BFCH_7_2_2
 G  BFO_7_2_2
 G  AFCH_7_2_2
 G  AFO_7_2_2
 G  BFCH_7_2_3
 G  BFO_7_2_3
 G  AFCH_7_2_3
 G  AFO_7_2_3
 G  BFCH_7_2_4
 G  BFO_7_2_4
 G  AFCH_7_2_4
 G  AFO_7_2_4
 G  BFCH_7_2_5
 G  BFO_7_2_5
 G  AFCH_7_3_0
 G  AFO_7_3_0
 G  BFCH_7_3_1
 G  BFO_7_3_1
 G  AFCH_7_3_1
 G  AFO_7_3_1
 G  BFCH_7_3_2
 G  BFO_7_3_2
 G  AFCH_7_3_2
 G  AFO_7_3_2
 G  BFCH_7_3_3
 G  BFO_7_3_3
 G  AFCH_7_3_3
 G  AFO_7_3_3
 G  BFCH_7_3_4
 G  BFO_7_3_4
 G  AFCH_7_3_4
 G  AFO_7_3_4
 G  BFCH_7_3_5
 G  BFO_7_3_5
 G  AFCH_7_4_0
 G  AFO_7_4_0
 G  BFCH_7_4_1
 G  BFO_7_4_1
 G  AFCH_7_4_1
 G  AFO_7_4_1
 G  BFCH_7_4_2
 G  BFO_7_4_2
 G  AFCH_7_4_2
 G  AFO_7_4_2
 G  BFCH_7_4_3
 G  BFO_7_4_3
 G  AFCH_7_4_3
 G  AFO_7_4_3
 G  BFCH_7_4_4
 G  BFO_7_4_4
 G  AFCH_7_4_4
 G  AFO_7_4_4
 G  BFCH_7_4_5
 G  BFO_7_4_5
 G  GAP_0_0_0
 G  GAP_0_0_1
 G  GAP_0_0_2
 G  GAP_0_0_3
 G  GAP_0_0_4
 G  GAP_0_0_5
 G  GAP_0_1_0
 G  GAP_0_1_1
 G  GAP_0_1_2
 G  GAP_0_1_3
 G  GAP_0_1_4
 G  GAP_0_1_5
 G  GAP_0_2_0
 G  GAP_0_2_1
 G  GAP_0_2_2
 G  GAP_0_2_3
 G  GAP_0_2_4
 G  GAP_0_2_5
 G  GAP_0_3_0
 G  GAP_0_3_1
 G  GAP_0_3_2
 G  GAP_0_3_3
 G  GAP_0_3_4
 G  GAP_0_3_5
 G  GAP_0_4_0
 G  GAP_0_4_1
 G  GAP_0_4_2
 G  GAP_0_4_3
 G  GAP_0_4_4
 G  GAP_0_4_5
 G  GAP_1_0_0
 G  GAP_1_0_1
 G  GAP_1_0_2
 G  GAP_1_0_3
 G  GAP_1_0_4
 G  GAP_1_0_5
 G  GAP_1_1_0
 G  GAP_1_1_1
 G  GAP_1_1_2
 G  GAP_1_1_3
 G  GAP_1_1_4
 G  GAP_1_1_5
 G  GAP_1_2_0
 G  GAP_1_2_1
 G  GAP_1_2_2
 G  GAP_1_2_3
 G  GAP_1_2_4
 G  GAP_1_2_5
 G  GAP_1_3_0
 G  GAP_1_3_1
 G  GAP_1_3_2
 G  GAP_1_3_3
 G  GAP_1_3_4
 G  GAP_1_3_5
 G  GAP_1_4_0
 G  GAP_1_4_1
 G  GAP_1_4_2
 G  GAP_1_4_3
 G  GAP_1_4_4
 G  GAP_1_4_5
 G  GAP_2_0_0
 G  GAP_2_0_1
 G  GAP_2_0_2
 G  GAP_2_0_3
 G  GAP_2_0_4
 G  GAP_2_0_5
 G  GAP_2_1_0
 G  GAP_2_1_1
 G  GAP_2_1_2
 G  GAP_2_1_3
 G  GAP_2_1_4
 G  GAP_2_1_5
 G  GAP_2_2_0
 G  GAP_2_2_1
 G  GAP_2_2_2
 G  GAP_2_2_3
 G  GAP_2_2_4
 G  GAP_2_2_5
 G  GAP_2_3_0
 G  GAP_2_3_1
 G  GAP_2_3_2
 G  GAP_2_3_3
 G  GAP_2_3_4
 G  GAP_2_3_5
 G  GAP_2_4_0
 G  GAP_2_4_1
 G  GAP_2_4_2
 G  GAP_2_4_3
 G  GAP_2_4_4
 G  GAP_2_4_5
 G  GAP_3_0_0
 G  GAP_3_0_1
 G  GAP_3_0_2
 G  GAP_3_0_3
 G  GAP_3_0_4
 G  GAP_3_0_5
 G  GAP_3_1_0
 G  GAP_3_1_1
 G  GAP_3_1_2
 G  GAP_3_1_3
 G  GAP_3_1_4
 G  GAP_3_1_5
 G  GAP_3_2_0
 G  GAP_3_2_1
 G  GAP_3_2_2
 G  GAP_3_2_3
 G  GAP_3_2_4
 G  GAP_3_2_5
 G  GAP_3_3_0
 G  GAP_3_3_1
 G  GAP_3_3_2
 G  GAP_3_3_3
 G  GAP_3_3_4
 G  GAP_3_3_5
 G  GAP_3_4_0
 G  GAP_3_4_1
 G  GAP_3_4_2
 G  GAP_3_4_3
 G  GAP_3_4_4
 G  GAP_3_4_5
 G  GAP_4_0_0
 G  GAP_4_0_1
 G  GAP_4_0_2
 G  GAP_4_0_3
 G  GAP_4_0_4
 G  GAP_4_0_5
 G  GAP_4_1_0
 G  GAP_4_1_1
 G  GAP_4_1_2
 G  GAP_4_1_3
 G  GAP_4_1_4
 G  GAP_4_1_5
 G  GAP_4_2_0
 G  GAP_4_2_1
 G  GAP_4_2_2
 G  GAP_4_2_3
 G  GAP_4_2_4
 G  GAP_4_2_5
 G  GAP_4_3_0
 G  GAP_4_3_1
 G  GAP_4_3_2
 G  GAP_4_3_3
 G  GAP_4_3_4
 G  GAP_4_3_5
 G  GAP_4_4_0
 G  GAP_4_4_1
 G  GAP_4_4_2
 G  GAP_4_4_3
 G  GAP_4_4_4
 G  GAP_4_4_5
 G  GAP_5_0_0
 G  GAP_5_0_1
 G  GAP_5_0_2
 G  GAP_5_0_3
 G  GAP_5_0_4
 G  GAP_5_0_5
 G  GAP_5_1_0
 G  GAP_5_1_1
 G  GAP_5_1_2
 G  GAP_5_1_3
 G  GAP_5_1_4
 G  GAP_5_1_5
 G  GAP_5_2_0
 G  GAP_5_2_1
 G  GAP_5_2_2
 G  GAP_5_2_3
 G  GAP_5_2_4
 G  GAP_5_2_5
 G  GAP_5_3_0
 G  GAP_5_3_1
 G  GAP_5_3_2
 G  GAP_5_3_3
 G  GAP_5_3_4
 G  GAP_5_3_5
 G  GAP_5_4_0
 G  GAP_5_4_1
 G  GAP_5_4_2
 G  GAP_5_4_3
 G  GAP_5_4_4
 G  GAP_5_4_5
 G  GAP_6_0_0
 G  GAP_6_0_1
 G  GAP_6_0_2
 G  GAP_6_0_3
 G  GAP_6_0_4
 G  GAP_6_0_5
 G  GAP_6_1_0
 G  GAP_6_1_1
 G  GAP_6_1_2
 G  GAP_6_1_3
 G  GAP_6_1_4
 G  GAP_6_1_5
 G  GAP_6_2_0
 G  GAP_6_2_1
 G  GAP_6_2_2
 G  GAP_6_2_3
 G  GAP_6_2_4
 G  GAP_6_2_5
 G  GAP_6_3_0
 G  GAP_6_3_1
 G  GAP_6_3_2
 G  GAP_6_3_3
 G  GAP_6_3_4
 G  GAP_6_3_5
 G  GAP_6_4_0
 G  GAP_6_4_1
 G  GAP_6_4_2
 G  GAP_6_4_3
 G  GAP_6_4_4
 G  GAP_6_4_5
 G  GAP_7_0_0
 G  GAP_7_0_1
 G  GAP_7_0_2
 G  GAP_7_0_3
 G  GAP_7_0_4
 G  GAP_7_0_5
 G  GAP_7_1_0
 G  GAP_7_1_1
 G  GAP_7_1_2
 G  GAP_7_1_3
 G  GAP_7_1_4
 G  GAP_7_1_5
 G  GAP_7_2_0
 G  GAP_7_2_1
 G  GAP_7_2_2
 G  GAP_7_2_3
 G  GAP_7_2_4
 G  GAP_7_2_5
 G  GAP_7_3_0
 G  GAP_7_3_1
 G  GAP_7_3_2
 G  GAP_7_3_3
 G  GAP_7_3_4
 G  GAP_7_3_5
 G  GAP_7_4_0
 G  GAP_7_4_1
 G  GAP_7_4_2
 G  GAP_7_4_3
 G  GAP_7_4_4
 G  GAP_7_4_5
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    z_0_1_0_0         OBJ           0.0
    z_0_1_0_0         DAY_0_1_0       1.0
    z_0_1_0_0         REQ_0_1         1.0
    z_0_1_0_0         OCC_1_0_0       -1.0
    z_0_1_0_0         CLS_0_0_0       -1.0
    z_0_1_0_1         OBJ           0.0
    z_0_1_0_1         DAY_0_1_0       1.0
    z_0_1_0_1         REQ_0_1         1.0
    z_0_1_0_1         OCC_1_0_1       -1.0
    z_0_1_0_1         CLS_0_0_1       -1.0
    z_0_1_0_2         OBJ           0.0
    z_0_1_0_2         DAY_0_1_0       1.0
    z_0_1_0_2         REQ_0_1         1.0
    z_0_1_0_2         OCC_1_0_2       -1.0
    z_0_1_0_2         CLS_0_0_2       -1.0
    z_0_1_0_3         OBJ           0.0
    z_0_1_0_3         DAY_0_1_0       1.0
    z_0_1_0_3         REQ_0_1         1.0
    z_0_1_0_3         OCC_1_0_3       -1.0
    z_0_1_0_3         CLS_0_0_3       -1.0
    z_0_1_0_4         OBJ           0.0
    z_0_1_0_4         DAY_0_1_0       1.0
    z_0_1_0_4         REQ_0_1         1.0
    z_0_1_0_4         OCC_1_0_4       -1.0
    z_0_1_0_4         CLS_0_0_4       -1.0
    z_0_1_0_5         OBJ           0.0
    z_0_1_0_5         DAY_0_1_0       1.0
    z_0_1_0_5         REQ_0_1         1.0
    z_0_1_0_5         OCC_1_0_5       -1.0
    z_0_1_0_5         CLS_0_0_5       -1.0
    z_0_1_0_6         OBJ           0.0
    z_0_1_0_6         DAY_0_1_0       1.0
    z_0_1_0_6         REQ_0_1         2.0
    z_0_1_0_6         OCC_1_0_0       -1.0
    z_0_1_0_6         OCC_1_0_1       -1.0
    z_0_1_0_6         CLS_0_0_0       -1.0
    z_0_1_0_6         CLS_0_0_1       -1.0
    z_0_1_0_7         OBJ           0.0
    z_0_1_0_7         DAY_0_1_0       1.0
    z_0_1_0_7         REQ_0_1         2.0
    z_0_1_0_7         OCC_1_0_1       -1.0
    z_0_1_0_7         OCC_1_0_2       -1.0
    z_0_1_0_7         CLS_0_0_1       -1.0
    z_0_1_0_7         CLS_0_0_2       -1.0
    z_0_1_0_8         OBJ           0.0
    z_0_1_0_8         DAY_0_1_0       1.0
    z_0_1_0_8         REQ_0_1         2.0
    z_0_1_0_8         OCC_1_0_2       -1.0
    z_0_1_0_8         OCC_1_0_3       -1.0
    z_0_1_0_8         CLS_0_0_2       -1.0
    z_0_1_0_8         CLS_0_0_3       -1.0
    z_0_1_0_9         OBJ           0.0
    z_0_1_0_9         DAY_0_1_0       1.0
    z_0_1_0_9         REQ_0_1         2.0
    z_0_1_0_9         OCC_1_0_3       -1.0
    z_0_1_0_9         OCC_1_0_4       -1.0
    z_0_1_0_9         CLS_0_0_3       -1.0
    z_0_1_0_9         CLS_0_0_4       -1.0
    z_0_1_0_10        OBJ           0.0
    z_0_1_0_10        DAY_0_1_0       1.0
    z_0_1_0_10        REQ_0_1         2.0
    z_0_1_0_10        OCC_1_0_4       -1.0
    z_0_1_0_10        OCC_1_0_5       -1.0
    z_0_1_0_10        CLS_0_0_4       -1.0
    z_0_1_0_10        CLS_0_0_5       -1.0
    z_0_1_1_0         OBJ           0.0
    z_0_1_1_0         DAY_0_1_1       1.0
    z_0_1_1_0         REQ_0_1         1.0
    z_0_1_1_0         OCC_1_1_0       -1.0
    z_0_1_1_0         CLS_0_1_0       -1.0
    z_0_1_1_1         OBJ           0.0
    z_0_1_1_1         DAY_0_1_1       1.0
    z_0_1_1_1         REQ_0_1         1.0
    z_0_1_1_1         OCC_1_1_1       -1.0
    z_0_1_1_1         CLS_0_1_1       -1.0
    z_0_1_1_2         OBJ           0.0
    z_0_1_1_2         DAY_0_1_1       1.0
    z_0_1_1_2         REQ_0_1         1.0
    z_0_1_1_2         OCC_1_1_2       -1.0
    z_0_1_1_2         CLS_0_1_2       -1.0
    z_0_1_1_3         OBJ           0.0
    z_0_1_1_3         DAY_0_1_1       1.0
    z_0_1_1_3         REQ_0_1         1.0
    z_0_1_1_3         OCC_1_1_3       -1.0
    z_0_1_1_3         CLS_0_1_3       -1.0
    z_0_1_1_4         OBJ           0.0
    z_0_1_1_4         DAY_0_1_1       1.0
    z_0_1_1_4         REQ_0_1         1.0
    z_0_1_1_4         OCC_1_1_4       -1.0
    z_0_1_1_4         CLS_0_1_4       -1.0
    z_0_1_1_5         OBJ           0.0
    z_0_1_1_5         DAY_0_1_1       1.0
    z_0_1_1_5         REQ_0_1         1.0
    z_0_1_1_5         OCC_1_1_5       -1.0
    z_0_1_1_5         CLS_0_1_5       -1.0
    z_0_1_1_6         OBJ           0.0
    z_0_1_1_6         DAY_0_1_1       1.0
    z_0_1_1_6         REQ_0_1         2.0
    z_0_1_1_6         OCC_1_1_0       -1.0
    z_0_1_1_6         OCC_1_1_1       -1.0
    z_0_1_1_6         CLS_0_1_0       -1.0
    z_0_1_1_6         CLS_0_1_1       -1.0
    z_0_1_1_7         OBJ           0.0
    z_0_1_1_7         DAY_0_1_1       1.0
    z_0_1_1_7         REQ_0_1         2.0
    z_0_1_1_7         OCC_1_1_1       -1.0
    z_0_1_1_7         OCC_1_1_2       -1.0
    z_0_1_1_7         CLS_0_1_1       -1.0
    z_0_1_1_7         CLS_0_1_2       -1.0
    z_0_1_1_8         OBJ           0.0
    z_0_1_1_8         DAY_0_1_1       1.0
    z_0_1_1_8         REQ_0_1         2.0
    z_0_1_1_8         OCC_1_1_2       -1.0
    z_0_1_1_8         OCC_1_1_3       -1.0
    z_0_1_1_8         CLS_0_1_2       -1.0
    z_0_1_1_8         CLS_0_1_3       -1.0
    z_0_1_1_9         OBJ           0.0
    z_0_1_1_9         DAY_0_1_1       1.0
    z_0_1_1_9         REQ_0_1         2.0
    z_0_1_1_9         OCC_1_1_3       -1.0
    z_0_1_1_9         OCC_1_1_4       -1.0
    z_0_1_1_9         CLS_0_1_3       -1.0
    z_0_1_1_9         CLS_0_1_4       -1.0
    z_0_1_1_10        OBJ           0.0
    z_0_1_1_10        DAY_0_1_1       1.0
    z_0_1_1_10        REQ_0_1         2.0
    z_0_1_1_10        OCC_1_1_4       -1.0
    z_0_1_1_10        OCC_1_1_5       -1.0
    z_0_1_1_10        CLS_0_1_4       -1.0
    z_0_1_1_10        CLS_0_1_5       -1.0
    z_0_1_2_0         OBJ           0.0
    z_0_1_2_0         DAY_0_1_2       1.0
    z_0_1_2_0         REQ_0_1         1.0
    z_0_1_2_0         OCC_1_2_0       -1.0
    z_0_1_2_0         CLS_0_2_0       -1.0
    z_0_1_2_1         OBJ           0.0
    z_0_1_2_1         DAY_0_1_2       1.0
    z_0_1_2_1         REQ_0_1         1.0
    z_0_1_2_1         OCC_1_2_1       -1.0
    z_0_1_2_1         CLS_0_2_1       -1.0
    z_0_1_2_2         OBJ           0.0
    z_0_1_2_2         DAY_0_1_2       1.0
    z_0_1_2_2         REQ_0_1         1.0
    z_0_1_2_2         OCC_1_2_2       -1.0
    z_0_1_2_2         CLS_0_2_2       -1.0
    z_0_1_2_3         OBJ           0.0
    z_0_1_2_3         DAY_0_1_2       1.0
    z_0_1_2_3         REQ_0_1         1.0
    z_0_1_2_3         OCC_1_2_3       -1.0
    z_0_1_2_3         CLS_0_2_3       -1.0
    z_0_1_2_4         OBJ           0.0
    z_0_1_2_4         DAY_0_1_2       1.0
    z_0_1_2_4         REQ_0_1         1.0
    z_0_1_2_4         OCC_1_2_4       -1.0
    z_0_1_2_4         CLS_0_2_4       -1.0
    z_0_1_2_5         OBJ           0.0
    z_0_1_2_5         DAY_0_1_2       1.0
    z_0_1_2_5         REQ_0_1         1.0
    z_0_1_2_5         OCC_1_2_5       -1.0
    z_0_1_2_5         CLS_0_2_5       -1.0
    z_0_1_2_6         OBJ           0.0
    z_0_1_2_6         DAY_0_1_2       1.0
    z_0_1_2_6         REQ_0_1         2.0
    z_0_1_2_6         OCC_1_2_0       -1.0
    z_0_1_2_6         OCC_1_2_1       -1.0
    z_0_1_2_6         CLS_0_2_0       -1.0
    z_0_1_2_6         CLS_0_2_1       -1.0
    z_0_1_2_7         OBJ           0.0
    z_0_1_2_7         DAY_0_1_2       1.0
    z_0_1_2_7         REQ_0_1         2.0
    z_0_1_2_7         OCC_1_2_1       -1.0
    z_0_1_2_7         OCC_1_2_2       -1.0
    z_0_1_2_7         CLS_0_2_1       -1.0
    z_0_1_2_7         CLS_0_2_2       -1.0
    z_0_1_2_8         OBJ           0.0
    z_0_1_2_8         DAY_0_1_2       1.0
    z_0_1_2_8         REQ_0_1         2.0
    z_0_1_2_8         OCC_1_2_2       -1.0
    z_0_1_2_8         OCC_1_2_3       -1.0
    z_0_1_2_8         CLS_0_2_2       -1.0
    z_0_1_2_8         CLS_0_2_3       -1.0
    z_0_1_2_9         OBJ           0.0
    z_0_1_2_9         DAY_0_1_2       1.0
    z_0_1_2_9         REQ_0_1         2.0
    z_0_1_2_9         OCC_1_2_3       -1.0
    z_0_1_2_9         OCC_1_2_4       -1.0
    z_0_1_2_9         CLS_0_2_3       -1.0
    z_0_1_2_9         CLS_0_2_4       -1.0
    z_0_1_2_10        OBJ           0.0
    z_0_1_2_10        DAY_0_1_2       1.0
    z_0_1_2_10        REQ_0_1         2.0
    z_0_1_2_10        OCC_1_2_4       -1.0
    z_0_1_2_10        OCC_1_2_5       -1.0
    z_0_1_2_10        CLS_0_2_4       -1.0
    z_0_1_2_10        CLS_0_2_5       -1.0
    z_0_1_3_0         OBJ           0.0
    z_0_1_3_0         DAY_0_1_3       1.0
    z_0_1_3_0         REQ_0_1         1.0
    z_0_1_3_0         OCC_1_3_1       -1.0
    z_0_1_3_0         CLS_0_3_1       -1.0
    z_0_1_3_1         OBJ           0.0
    z_0_1_3_1         DAY_0_1_3       1.0
    z_0_1_3_1         REQ_0_1         1.0
    z_0_1_3_1         OCC_1_3_3       -1.0
    z_0_1_3_1         CLS_0_3_3       -1.0
    z_0_1_3_2         OBJ           0.0
    z_0_1_3_2         DAY_0_1_3       1.0
    z_0_1_3_2         REQ_0_1         1.0
    z_0_1_3_2         OCC_1_3_4       -1.0
    z_0_1_3_2         CLS_0_3_4       -1.0
    z_0_1_3_3         OBJ           0.0
    z_0_1_3_3         DAY_0_1_3       1.0
    z_0_1_3_3         REQ_0_1         1.0
    z_0_1_3_3         OCC_1_3_5       -1.0
    z_0_1_3_3         CLS_0_3_5       -1.0
    z_0_1_3_4         OBJ           0.0
    z_0_1_3_4         DAY_0_1_3       1.0
    z_0_1_3_4         REQ_0_1         2.0
    z_0_1_3_4         OCC_1_3_3       -1.0
    z_0_1_3_4         OCC_1_3_4       -1.0
    z_0_1_3_4         CLS_0_3_3       -1.0
    z_0_1_3_4         CLS_0_3_4       -1.0
    z_0_1_3_5         OBJ           0.0
    z_0_1_3_5         DAY_0_1_3       1.0
    z_0_1_3_5         REQ_0_1         2.0
    z_0_1_3_5         OCC_1_3_4       -1.0
    z_0_1_3_5         OCC_1_3_5       -1.0
    z_0_1_3_5         CLS_0_3_4       -1.0
    z_0_1_3_5         CLS_0_3_5       -1.0
    z_0_1_4_0         OBJ           0.0
    z_0_1_4_0         DAY_0_1_4       1.0
    z_0_1_4_0         REQ_0_1         1.0
    z_0_1_4_0         OCC_1_4_0       -1.0
    z_0_1_4_0         CLS_0_4_0       -1.0
    z_0_1_4_1         OBJ           0.0
    z_0_1_4_1         DAY_0_1_4       1.0
    z_0_1_4_1         REQ_0_1         1.0
    z_0_1_4_1         OCC_1_4_1       -1.0
    z_0_1_4_1         CLS_0_4_1       -1.0
    z_0_1_4_2         OBJ           0.0
    z_0_1_4_2         DAY_0_1_4       1.0
    z_0_1_4_2         REQ_0_1         1.0
    z_0_1_4_2         OCC_1_4_2       -1.0
    z_0_1_4_2         CLS_0_4_2       -1.0
    z_0_1_4_3         OBJ           0.0
    z_0_1_4_3         DAY_0_1_4       1.0
    z_0_1_4_3         REQ_0_1         1.0
    z_0_1_4_3         OCC_1_4_3       -1.0
    z_0_1_4_3         CLS_0_4_3       -1.0
    z_0_1_4_4         OBJ           0.0
    z_0_1_4_4         DAY_0_1_4       1.0
    z_0_1_4_4         REQ_0_1         1.0
    z_0_1_4_4         OCC_1_4_4       -1.0
    z_0_1_4_4         CLS_0_4_4       -1.0
    z_0_1_4_5         OBJ           0.0
    z_0_1_4_5         DAY_0_1_4       1.0
    z_0_1_4_5         REQ_0_1         1.0
    z_0_1_4_5         OCC_1_4_5       -1.0
    z_0_1_4_5         CLS_0_4_5       -1.0
    z_0_1_4_6         OBJ           0.0
    z_0_1_4_6         DAY_0_1_4       1.0
    z_0_1_4_6         REQ_0_1         2.0
    z_0_1_4_6         OCC_1_4_0       -1.0
    z_0_1_4_6         OCC_1_4_1       -1.0
    z_0_1_4_6         CLS_0_4_0       -1.0
    z_0_1_4_6         CLS_0_4_1       -1.0
    z_0_1_4_7         OBJ           0.0
    z_0_1_4_7         DAY_0_1_4       1.0
    z_0_1_4_7         REQ_0_1         2.0
    z_0_1_4_7         OCC_1_4_1       -1.0
    z_0_1_4_7         OCC_1_4_2       -1.0
    z_0_1_4_7         CLS_0_4_1       -1.0
    z_0_1_4_7         CLS_0_4_2       -1.0
    z_0_1_4_8         OBJ           0.0
    z_0_1_4_8         DAY_0_1_4       1.0
    z_0_1_4_8         REQ_0_1         2.0
    z_0_1_4_8         OCC_1_4_2       -1.0
    z_0_1_4_8         OCC_1_4_3       -1.0
    z_0_1_4_8         CLS_0_4_2       -1.0
    z_0_1_4_8         CLS_0_4_3       -1.0
    z_0_1_4_9         OBJ           0.0
    z_0_1_4_9         DAY_0_1_4       1.0
    z_0_1_4_9         REQ_0_1         2.0
    z_0_1_4_9         OCC_1_4_3       -1.0
    z_0_1_4_9         OCC_1_4_4       -1.0
    z_0_1_4_9         CLS_0_4_3       -1.0
    z_0_1_4_9         CLS_0_4_4       -1.0
    z_0_1_4_10        OBJ           0.0
    z_0_1_4_10        DAY_0_1_4       1.0
    z_0_1_4_10        REQ_0_1         2.0
    z_0_1_4_10        OCC_1_4_4       -1.0
    z_0_1_4_10        OCC_1_4_5       -1.0
    z_0_1_4_10        CLS_0_4_4       -1.0
    z_0_1_4_10        CLS_0_4_5       -1.0
    z_0_3_0_0         OBJ           0.0
    z_0_3_0_0         DAY_0_3_0       1.0
    z_0_3_0_0         REQ_0_3         1.0
    z_0_3_0_0         OCC_3_0_0       -1.0
    z_0_3_0_0         CLS_0_0_0       -1.0
    z_0_3_0_1         OBJ           0.0
    z_0_3_0_1         DAY_0_3_0       1.0
    z_0_3_0_1         REQ_0_3         1.0
    z_0_3_0_1         OCC_3_0_2       -1.0
    z_0_3_0_1         CLS_0_0_2       -1.0
    z_0_3_0_2         OBJ           0.0
    z_0_3_0_2         DAY_0_3_0       1.0
    z_0_3_0_2         REQ_0_3         1.0
    z_0_3_0_2         OCC_3_0_3       -1.0
    z_0_3_0_2         CLS_0_0_3       -1.0
    z_0_3_0_3         OBJ           0.0
    z_0_3_0_3         DAY_0_3_0       1.0
    z_0_3_0_3         REQ_0_3         1.0
    z_0_3_0_3         OCC_3_0_4       -1.0
    z_0_3_0_3         CLS_0_0_4       -1.0
    z_0_3_0_4         OBJ           0.0
    z_0_3_0_4         DAY_0_3_0       1.0
    z_0_3_0_4         REQ_0_3         1.0
    z_0_3_0_4         OCC_3_0_5       -1.0
    z_0_3_0_4         CLS_0_0_5       -1.0
    z_0_3_0_5         OBJ           0.0
    z_0_3_0_5         DAY_0_3_0       1.0
    z_0_3_0_5         REQ_0_3         2.0
    z_0_3_0_5         OCC_3_0_2       -1.0
    z_0_3_0_5         OCC_3_0_3       -1.0
    z_0_3_0_5         CLS_0_0_2       -1.0
    z_0_3_0_5         CLS_0_0_3       -1.0
    z_0_3_0_6         OBJ           0.0
    z_0_3_0_6         DAY_0_3_0       1.0
    z_0_3_0_6         REQ_0_3         2.0
    z_0_3_0_6         OCC_3_0_3       -1.0
    z_0_3_0_6         OCC_3_0_4       -1.0
    z_0_3_0_6         CLS_0_0_3       -1.0
    z_0_3_0_6         CLS_0_0_4       -1.0
    z_0_3_0_7         OBJ           0.0
    z_0_3_0_7         DAY_0_3_0       1.0
    z_0_3_0_7         REQ_0_3         2.0
    z_0_3_0_7         OCC_3_0_4       -1.0
    z_0_3_0_7         OCC_3_0_5       -1.0
    z_0_3_0_7         CLS_0_0_4       -1.0
    z_0_3_0_7         CLS_0_0_5       -1.0
    z_0_3_2_0         OBJ           0.0
    z_0_3_2_0         DAY_0_3_2       1.0
    z_0_3_2_0         REQ_0_3         1.0
    z_0_3_2_0         OCC_3_2_0       -1.0
    z_0_3_2_0         CLS_0_2_0       -1.0
    z_0_3_2_1         OBJ           0.0
    z_0_3_2_1         DAY_0_3_2       1.0
    z_0_3_2_1         REQ_0_3         1.0
    z_0_3_2_1         OCC_3_2_1       -1.0
    z_0_3_2_1         CLS_0_2_1       -1.0
    z_0_3_2_2         OBJ           0.0
    z_0_3_2_2         DAY_0_3_2       1.0
    z_0_3_2_2         REQ_0_3         1.0
    z_0_3_2_2         OCC_3_2_2       -1.0
    z_0_3_2_2         CLS_0_2_2       -1.0
    z_0_3_2_3         OBJ           0.0
    z_0_3_2_3         DAY_0_3_2       1.0
    z_0_3_2_3         REQ_0_3         1.0
    z_0_3_2_3         OCC_3_2_3       -1.0
    z_0_3_2_3         CLS_0_2_3       -1.0
    z_0_3_2_4         OBJ           0.0
    z_0_3_2_4         DAY_0_3_2       1.0
    z_0_3_2_4         REQ_0_3         1.0
    z_0_3_2_4         OCC_3_2_4       -1.0
    z_0_3_2_4         CLS_0_2_4       -1.0
    z_0_3_2_5         OBJ           0.0
    z_0_3_2_5         DAY_0_3_2       1.0
    z_0_3_2_5         REQ_0_3         1.0
    z_0_3_2_5         OCC_3_2_5       -1.0
    z_0_3_2_5         CLS_0_2_5       -1.0
    z_0_3_2_6         OBJ           0.0
    z_0_3_2_6         DAY_0_3_2       1.0
    z_0_3_2_6         REQ_0_3         2.0
    z_0_3_2_6         OCC_3_2_0       -1.0
    z_0_3_2_6         OCC_3_2_1       -1.0
    z_0_3_2_6         CLS_0_2_0       -1.0
    z_0_3_2_6         CLS_0_2_1       -1.0
    z_0_3_2_7         OBJ           0.0
    z_0_3_2_7         DAY_0_3_2       1.0
    z_0_3_2_7         REQ_0_3         2.0
    z_0_3_2_7         OCC_3_2_1       -1.0
    z_0_3_2_7         OCC_3_2_2       -1.0
    z_0_3_2_7         CLS_0_2_1       -1.0
    z_0_3_2_7         CLS_0_2_2       -1.0
    z_0_3_2_8         OBJ           0.0
    z_0_3_2_8         DAY_0_3_2       1.0
    z_0_3_2_8         REQ_0_3         2.0
    z_0_3_2_8         OCC_3_2_2       -1.0
    z_0_3_2_8         OCC_3_2_3       -1.0
    z_0_3_2_8         CLS_0_2_2       -1.0
    z_0_3_2_8         CLS_0_2_3       -1.0
    z_0_3_2_9         OBJ           0.0
    z_0_3_2_9         DAY_0_3_2       1.0
    z_0_3_2_9         REQ_0_3         2.0
    z_0_3_2_9         OCC_3_2_3       -1.0
    z_0_3_2_9         OCC_3_2_4       -1.0
    z_0_3_2_9         CLS_0_2_3       -1.0
    z_0_3_2_9         CLS_0_2_4       -1.0
    z_0_3_2_10        OBJ           0.0
    z_0_3_2_10        DAY_0_3_2       1.0
    z_0_3_2_10        REQ_0_3         2.0
    z_0_3_2_10        OCC_3_2_4       -1.0
    z_0_3_2_10        OCC_3_2_5       -1.0
    z_0_3_2_10        CLS_0_2_4       -1.0
    z_0_3_2_10        CLS_0_2_5       -1.0
    z_0_3_3_0         OBJ           0.0
    z_0_3_3_0         DAY_0_3_3       1.0
    z_0_3_3_0         REQ_0_3         1.0
    z_0_3_3_0         OCC_3_3_1       -1.0
    z_0_3_3_0         CLS_0_3_1       -1.0
    z_0_3_3_1         OBJ           0.0
    z_0_3_3_1         DAY_0_3_3       1.0
    z_0_3_3_1         REQ_0_3         1.0
    z_0_3_3_1         OCC_3_3_2       -1.0
    z_0_3_3_1         CLS_0_3_2       -1.0
    z_0_3_3_2         OBJ           0.0
    z_0_3_3_2         DAY_0_3_3       1.0
    z_0_3_3_2         REQ_0_3         1.0
    z_0_3_3_2         OCC_3_3_3       -1.0
    z_0_3_3_2         CLS_0_3_3       -1.0
    z_0_3_3_3         OBJ           0.0
    z_0_3_3_3         DAY_0_3_3       1.0
    z_0_3_3_3         REQ_0_3         1.0
    z_0_3_3_3         OCC_3_3_4       -1.0
    z_0_3_3_3         CLS_0_3_4       -1.0
    z_0_3_3_4         OBJ           0.0
    z_0_3_3_4         DAY_0_3_3       1.0
    z_0_3_3_4         REQ_0_3         1.0
    z_0_3_3_4         OCC_3_3_5       -1.0
    z_0_3_3_4         CLS_0_3_5       -1.0
    z_0_3_3_5         OBJ           0.0
    z_0_3_3_5         DAY_0_3_3       1.0
    z_0_3_3_5         REQ_0_3         2.0
    z_0_3_3_5         OCC_3_3_1       -1.0
    z_0_3_3_5         OCC_3_3_2       -1.0
    z_0_3_3_5         CLS_0_3_1       -1.0
    z_0_3_3_5         CLS_0_3_2       -1.0
    z_0_3_3_6         OBJ           0.0
    z_0_3_3_6         DAY_0_3_3       1.0
    z_0_3_3_6         REQ_0_3         2.0
    z_0_3_3_6         OCC_3_3_2       -1.0
    z_0_3_3_6         OCC_3_3_3       -1.0
    z_0_3_3_6         CLS_0_3_2       -1.0
    z_0_3_3_6         CLS_0_3_3       -1.0
    z_0_3_3_7         OBJ           0.0
    z_0_3_3_7         DAY_0_3_3       1.0
    z_0_3_3_7         REQ_0_3         2.0
    z_0_3_3_7         OCC_3_3_3       -1.0
    z_0_3_3_7         OCC_3_3_4       -1.0
    z_0_3_3_7         CLS_0_3_3       -1.0
    z_0_3_3_7         CLS_0_3_4       -1.0
    z_0_3_3_8         OBJ           0.0
    z_0_3_3_8         DAY_0_3_3       1.0
    z_0_3_3_8         REQ_0_3         2.0
    z_0_3_3_8         OCC_3_3_4       -1.0
    z_0_3_3_8         OCC_3_3_5       -1.0
    z_0_3_3_8         CLS_0_3_4       -1.0
    z_0_3_3_8         CLS_0_3_5       -1.0
    z_0_3_4_0         OBJ           0.0
    z_0_3_4_0         DAY_0_3_4       1.0
    z_0_3_4_0         REQ_0_3         1.0
    z_0_3_4_0         OCC_3_4_0       -1.0
    z_0_3_4_0         CLS_0_4_0       -1.0
    z_0_3_4_1         OBJ           0.0
    z_0_3_4_1         DAY_0_3_4       1.0
    z_0_3_4_1         REQ_0_3         1.0
    z_0_3_4_1         OCC_3_4_1       -1.0
    z_0_3_4_1         CLS_0_4_1       -1.0
    z_0_3_4_2         OBJ           0.0
    z_0_3_4_2         DAY_0_3_4       1.0
    z_0_3_4_2         REQ_0_3         1.0
    z_0_3_4_2         OCC_3_4_2       -1.0
    z_0_3_4_2         CLS_0_4_2       -1.0
    z_0_3_4_3         OBJ           0.0
    z_0_3_4_3         DAY_0_3_4       1.0
    z_0_3_4_3         REQ_0_3         1.0
    z_0_3_4_3         OCC_3_4_3       -1.0
    z_0_3_4_3         CLS_0_4_3       -1.0
    z_0_3_4_4         OBJ           0.0
    z_0_3_4_4         DAY_0_3_4       1.0
    z_0_3_4_4         REQ_0_3         1.0
    z_0_3_4_4         OCC_3_4_4       -1.0
    z_0_3_4_4         CLS_0_4_4       -1.0
    z_0_3_4_5         OBJ           0.0
    z_0_3_4_5         DAY_0_3_4       1.0
    z_0_3_4_5         REQ_0_3         1.0
    z_0_3_4_5         OCC_3_4_5       -1.0
    z_0_3_4_5         CLS_0_4_5       -1.0
    z_0_3_4_6         OBJ           0.0
    z_0_3_4_6         DAY_0_3_4       1.0
    z_0_3_4_6         REQ_0_3         2.0
    z_0_3_4_6         OCC_3_4_0       -1.0
    z_0_3_4_6         OCC_3_4_1       -1.0
    z_0_3_4_6         CLS_0_4_0       -1.0
    z_0_3_4_6         CLS_0_4_1       -1.0
    z_0_3_4_7         OBJ           0.0
    z_0_3_4_7         DAY_0_3_4       1.0
    z_0_3_4_7         REQ_0_3         2.0
    z_0_3_4_7         OCC_3_4_1       -1.0
    z_0_3_4_7         OCC_3_4_2       -1.0
    z_0_3_4_7         CLS_0_4_1       -1.0
    z_0_3_4_7         CLS_0_4_2       -1.0
    z_0_3_4_8         OBJ           0.0
    z_0_3_4_8         DAY_0_3_4       1.0
    z_0_3_4_8         REQ_0_3         2.0
    z_0_3_4_8         OCC_3_4_2       -1.0
    z_0_3_4_8         OCC_3_4_3       -1.0
    z_0_3_4_8         CLS_0_4_2       -1.0
    z_0_3_4_8         CLS_0_4_3       -1.0
    z_0_3_4_9         OBJ           0.0
    z_0_3_4_9         DAY_0_3_4       1.0
    z_0_3_4_9         REQ_0_3         2.0
    z_0_3_4_9         OCC_3_4_3       -1.0
    z_0_3_4_9         OCC_3_4_4       -1.0
    z_0_3_4_9         CLS_0_4_3       -1.0
    z_0_3_4_9         CLS_0_4_4       -1.0
    z_0_3_4_10        OBJ           0.0
    z_0_3_4_10        DAY_0_3_4       1.0
    z_0_3_4_10        REQ_0_3         2.0
    z_0_3_4_10        OCC_3_4_4       -1.0
    z_0_3_4_10        OCC_3_4_5       -1.0
    z_0_3_4_10        CLS_0_4_4       -1.0
    z_0_3_4_10        CLS_0_4_5       -1.0
    z_0_4_0_0         OBJ           0.0
    z_0_4_0_0         DAY_0_4_0       1.0
    z_0_4_0_0         REQ_0_4         1.0
    z_0_4_0_0         OCC_4_0_0       -1.0
    z_0_4_0_0         CLS_0_0_0       -1.0
    z_0_4_0_1         OBJ           0.0
    z_0_4_0_1         DAY_0_4_0       1.0
    z_0_4_0_1         REQ_0_4         1.0
    z_0_4_0_1         OCC_4_0_1       -1.0
    z_0_4_0_1         CLS_0_0_1       -1.0
    z_0_4_0_2         OBJ           0.0
    z_0_4_0_2         DAY_0_4_0       1.0
    z_0_4_0_2         REQ_0_4         1.0
    z_0_4_0_2         OCC_4_0_2       -1.0
    z_0_4_0_2         CLS_0_0_2       -1.0
    z_0_4_0_3         OBJ           0.0
    z_0_4_0_3         DAY_0_4_0       1.0
    z_0_4_0_3         REQ_0_4         1.0
    z_0_4_0_3         OCC_4_0_3       -1.0
    z_0_4_0_3         CLS_0_0_3       -1.0
    z_0_4_0_4         OBJ           0.0
    z_0_4_0_4         DAY_0_4_0       1.0
    z_0_4_0_4         REQ_0_4         1.0
    z_0_4_0_4         OCC_4_0_5       -1.0
    z_0_4_0_4         CLS_0_0_5       -1.0
    z_0_4_0_5         OBJ           0.0
    z_0_4_0_5         DAY_0_4_0       1.0
    z_0_4_0_5         REQ_0_4         2.0
    z_0_4_0_5         OCC_4_0_0       -1.0
    z_0_4_0_5         OCC_4_0_1       -1.0
    z_0_4_0_5         CLS_0_0_0       -1.0
    z_0_4_0_5         CLS_0_0_1       -1.0
    z_0_4_0_6         OBJ           0.0
    z_0_4_0_6         DAY_0_4_0       1.0
    z_0_4_0_6         REQ_0_4         2.0
    z_0_4_0_6         OCC_4_0_1       -1.0
    z_0_4_0_6         OCC_4_0_2       -1.0
    z_0_4_0_6         CLS_0_0_1       -1.0
    z_0_4_0_6         CLS_0_0_2       -1.0
    z_0_4_0_7         OBJ           0.0
    z_0_4_0_7         DAY_0_4_0       1.0
    z_0_4_0_7         REQ_0_4         2.0
    z_0_4_0_7         OCC_4_0_2       -1.0
    z_0_4_0_7         OCC_4_0_3       -1.0
    z_0_4_0_7         CLS_0_0_2       -1.0
    z_0_4_0_7         CLS_0_0_3       -1.0
    z_0_4_1_0         OBJ           0.0
    z_0_4_1_0         DAY_0_4_1       1.0
    z_0_4_1_0         REQ_0_4         1.0
    z_0_4_1_0         OCC_4_1_0       -1.0
    z_0_4_1_0         CLS_0_1_0       -1.0
    z_0_4_1_1         OBJ           0.0
    z_0_4_1_1         DAY_0_4_1       1.0
    z_0_4_1_1         REQ_0_4         1.0
    z_0_4_1_1         OCC_4_1_1       -1.0
    z_0_4_1_1         CLS_0_1_1       -1.0
    z_0_4_1_2         OBJ           0.0
    z_0_4_1_2         DAY_0_4_1       1.0
    z_0_4_1_2         REQ_0_4         1.0
    z_0_4_1_2         OCC_4_1_2       -1.0
    z_0_4_1_2         CLS_0_1_2       -1.0
    z_0_4_1_3         OBJ           0.0
    z_0_4_1_3         DAY_0_4_1       1.0
    z_0_4_1_3         REQ_0_4         1.0
    z_0_4_1_3         OCC_4_1_3       -1.0
    z_0_4_1_3         CLS_0_1_3       -1.0
    z_0_4_1_4         OBJ           0.0
    z_0_4_1_4         DAY_0_4_1       1.0
    z_0_4_1_4         REQ_0_4         1.0
    z_0_4_1_4         OCC_4_1_4       -1.0
    z_0_4_1_4         CLS_0_1_4       -1.0
    z_0_4_1_5         OBJ           0.0
    z_0_4_1_5         DAY_0_4_1       1.0
    z_0_4_1_5         REQ_0_4         1.0
    z_0_4_1_5         OCC_4_1_5       -1.0
    z_0_4_1_5         CLS_0_1_5       -1.0
    z_0_4_1_6         OBJ           0.0
    z_0_4_1_6         DAY_0_4_1       1.0
    z_0_4_1_6         REQ_0_4         2.0
    z_0_4_1_6         OCC_4_1_0       -1.0
    z_0_4_1_6         OCC_4_1_1       -1.0
    z_0_4_1_6         CLS_0_1_0       -1.0
    z_0_4_1_6         CLS_0_1_1       -1.0
    z_0_4_1_7         OBJ           0.0
    z_0_4_1_7         DAY_0_4_1       1.0
    z_0_4_1_7         REQ_0_4         2.0
    z_0_4_1_7         OCC_4_1_1       -1.0
    z_0_4_1_7         OCC_4_1_2       -1.0
    z_0_4_1_7         CLS_0_1_1       -1.0
    z_0_4_1_7         CLS_0_1_2       -1.0
    z_0_4_1_8         OBJ           0.0
    z_0_4_1_8         DAY_0_4_1       1.0
    z_0_4_1_8         REQ_0_4         2.0
    z_0_4_1_8         OCC_4_1_2       -1.0
    z_0_4_1_8         OCC_4_1_3       -1.0
    z_0_4_1_8         CLS_0_1_2       -1.0
    z_0_4_1_8         CLS_0_1_3       -1.0
    z_0_4_1_9         OBJ           0.0
    z_0_4_1_9         DAY_0_4_1       1.0
    z_0_4_1_9         REQ_0_4         2.0
    z_0_4_1_9         OCC_4_1_3       -1.0
    z_0_4_1_9         OCC_4_1_4       -1.0
    z_0_4_1_9         CLS_0_1_3       -1.0
    z_0_4_1_9         CLS_0_1_4       -1.0
    z_0_4_1_10        OBJ           0.0
    z_0_4_1_10        DAY_0_4_1       1.0
    z_0_4_1_10        REQ_0_4         2.0
    z_0_4_1_10        OCC_4_1_4       -1.0
    z_0_4_1_10        OCC_4_1_5       -1.0
    z_0_4_1_10        CLS_0_1_4       -1.0
    z_0_4_1_10        CLS_0_1_5       -1.0
    z_0_4_2_0         OBJ           0.0
    z_0_4_2_0         DAY_0_4_2       1.0
    z_0_4_2_0         REQ_0_4         1.0
    z_0_4_2_0         OCC_4_2_0       -1.0
    z_0_4_2_0         CLS_0_2_0       -1.0
    z_0_4_2_1         OBJ           0.0
    z_0_4_2_1         DAY_0_4_2       1.0
    z_0_4_2_1         REQ_0_4         1.0
    z_0_4_2_1         OCC_4_2_1       -1.0
    z_0_4_2_1         CLS_0_2_1       -1.0
    z_0_4_2_2         OBJ           0.0
    z_0_4_2_2         DAY_0_4_2       1.0
    z_0_4_2_2         REQ_0_4         1.0
    z_0_4_2_2         OCC_4_2_2       -1.0
    z_0_4_2_2         CLS_0_2_2       -1.0
    z_0_4_2_3         OBJ           0.0
    z_0_4_2_3         DAY_0_4_2       1.0
    z_0_4_2_3         REQ_0_4         1.0
    z_0_4_2_3         OCC_4_2_3       -1.0
    z_0_4_2_3         CLS_0_2_3       -1.0
    z_0_4_2_4         OBJ           0.0
    z_0_4_2_4         DAY_0_4_2       1.0
    z_0_4_2_4         REQ_0_4         1.0
    z_0_4_2_4         OCC_4_2_4       -1.0
    z_0_4_2_4         CLS_0_2_4       -1.0
    z_0_4_2_5         OBJ           0.0
    z_0_4_2_5         DAY_0_4_2       1.0
    z_0_4_2_5         REQ_0_4         1.0
    z_0_4_2_5         OCC_4_2_5       -1.0
    z_0_4_2_5         CLS_0_2_5       -1.0
    z_0_4_2_6         OBJ           0.0
    z_0_4_2_6         DAY_0_4_2       1.0
    z_0_4_2_6         REQ_0_4         2.0
    z_0_4_2_6         OCC_4_2_0       -1.0
    z_0_4_2_6         OCC_4_2_1       -1.0
    z_0_4_2_6         CLS_0_2_0       -1.0
    z_0_4_2_6         CLS_0_2_1       -1.0
    z_0_4_2_7         OBJ           0.0
    z_0_4_2_7         DAY_0_4_2       1.0
    z_0_4_2_7         REQ_0_4         2.0
    z_0_4_2_7         OCC_4_2_1       -1.0
    z_0_4_2_7         OCC_4_2_2       -1.0
    z_0_4_2_7         CLS_0_2_1       -1.0
    z_0_4_2_7         CLS_0_2_2       -1.0
    z_0_4_2_8         OBJ           0.0
    z_0_4_2_8         DAY_0_4_2       1.0
    z_0_4_2_8         REQ_0_4         2.0
    z_0_4_2_8         OCC_4_2_2       -1.0
    z_0_4_2_8         OCC_4_2_3       -1.0
    z_0_4_2_8         CLS_0_2_2       -1.0
    z_0_4_2_8         CLS_0_2_3       -1.0
    z_0_4_2_9         OBJ           0.0
    z_0_4_2_9         DAY_0_4_2       1.0
    z_0_4_2_9         REQ_0_4         2.0
    z_0_4_2_9         OCC_4_2_3       -1.0
    z_0_4_2_9         OCC_4_2_4       -1.0
    z_0_4_2_9         CLS_0_2_3       -1.0
    z_0_4_2_9         CLS_0_2_4       -1.0
    z_0_4_2_10        OBJ           0.0
    z_0_4_2_10        DAY_0_4_2       1.0
    z_0_4_2_10        REQ_0_4         2.0
    z_0_4_2_10        OCC_4_2_4       -1.0
    z_0_4_2_10        OCC_4_2_5       -1.0
    z_0_4_2_10        CLS_0_2_4       -1.0
    z_0_4_2_10        CLS_0_2_5       -1.0
    z_0_4_3_0         OBJ           0.0
    z_0_4_3_0         DAY_0_4_3       1.0
    z_0_4_3_0         REQ_0_4         1.0
    z_0_4_3_0         OCC_4_3_0       -1.0
    z_0_4_3_0         CLS_0_3_0       -1.0
    z_0_4_3_1         OBJ           0.0
    z_0_4_3_1         DAY_0_4_3       1.0
    z_0_4_3_1         REQ_0_4         1.0
    z_0_4_3_1         OCC_4_3_1       -1.0
    z_0_4_3_1         CLS_0_3_1       -1.0
    z_0_4_3_2         OBJ           0.0
    z_0_4_3_2         DAY_0_4_3       1.0
    z_0_4_3_2         REQ_0_4         1.0
    z_0_4_3_2         OCC_4_3_2       -1.0
    z_0_4_3_2         CLS_0_3_2       -1.0
    z_0_4_3_3         OBJ           0.0
    z_0_4_3_3         DAY_0_4_3       1.0
    z_0_4_3_3         REQ_0_4         1.0
    z_0_4_3_3         OCC_4_3_3       -1.0
    z_0_4_3_3         CLS_0_3_3       -1.0
    z_0_4_3_4         OBJ           0.0
    z_0_4_3_4         DAY_0_4_3       1.0
    z_0_4_3_4         REQ_0_4         1.0
    z_0_4_3_4         OCC_4_3_4       -1.0
    z_0_4_3_4         CLS_0_3_4       -1.0
    z_0_4_3_5         OBJ           0.0
    z_0_4_3_5         DAY_0_4_3       1.0
    z_0_4_3_5         REQ_0_4         1.0
    z_0_4_3_5         OCC_4_3_5       -1.0
    z_0_4_3_5         CLS_0_3_5       -1.0
    z_0_4_3_6         OBJ           0.0
    z_0_4_3_6         DAY_0_4_3       1.0
    z_0_4_3_6         REQ_0_4         2.0
    z_0_4_3_6         OCC_4_3_0       -1.0
    z_0_4_3_6         OCC_4_3_1       -1.0
    z_0_4_3_6         CLS_0_3_0       -1.0
    z_0_4_3_6         CLS_0_3_1       -1.0
    z_0_4_3_7         OBJ           0.0
    z_0_4_3_7         DAY_0_4_3       1.0
    z_0_4_3_7         REQ_0_4         2.0
    z_0_4_3_7         OCC_4_3_1       -1.0
    z_0_4_3_7         OCC_4_3_2       -1.0
    z_0_4_3_7         CLS_0_3_1       -1.0
    z_0_4_3_7         CLS_0_3_2       -1.0
    z_0_4_3_8         OBJ           0.0
    z_0_4_3_8         DAY_0_4_3       1.0
    z_0_4_3_8         REQ_0_4         2.0
    z_0_4_3_8         OCC_4_3_2       -1.0
    z_0_4_3_8         OCC_4_3_3       -1.0
    z_0_4_3_8         CLS_0_3_2       -1.0
    z_0_4_3_8         CLS_0_3_3       -1.0
    z_0_4_3_9         OBJ           0.0
    z_0_4_3_9         DAY_0_4_3       1.0
    z_0_4_3_9         REQ_0_4         2.0
    z_0_4_3_9         OCC_4_3_3       -1.0
    z_0_4_3_9         OCC_4_3_4       -1.0
    z_0_4_3_9         CLS_0_3_3       -1.0
    z_0_4_3_9         CLS_0_3_4       -1.0
    z_0_4_3_10        OBJ           0.0
    z_0_4_3_10        DAY_0_4_3       1.0
    z_0_4_3_10        REQ_0_4         2.0
    z_0_4_3_10        OCC_4_3_4       -1.0
    z_0_4_3_10        OCC_4_3_5       -1.0
    z_0_4_3_10        CLS_0_3_4       -1.0
    z_0_4_3_10        CLS_0_3_5       -1.0
    z_0_4_4_0         OBJ           0.0
    z_0_4_4_0         DAY_0_4_4       1.0
    z_0_4_4_0         REQ_0_4         1.0
    z_0_4_4_0         OCC_4_4_0       -1.0
    z_0_4_4_0         CLS_0_4_0       -1.0
    z_0_4_4_1         OBJ           0.0
    z_0_4_4_1         DAY_0_4_4       1.0
    z_0_4_4_1         REQ_0_4         1.0
    z_0_4_4_1         OCC_4_4_1       -1.0
    z_0_4_4_1         CLS_0_4_1       -1.0
    z_0_4_4_2         OBJ           0.0
    z_0_4_4_2         DAY_0_4_4       1.0
    z_0_4_4_2         REQ_0_4         1.0
    z_0_4_4_2         OCC_4_4_2       -1.0
    z_0_4_4_2         CLS_0_4_2       -1.0
    z_0_4_4_3         OBJ           0.0
    z_0_4_4_3         DAY_0_4_4       1.0
    z_0_4_4_3         REQ_0_4         1.0
    z_0_4_4_3         OCC_4_4_3       -1.0
    z_0_4_4_3         CLS_0_4_3       -1.0
    z_0_4_4_4         OBJ           0.0
    z_0_4_4_4         DAY_0_4_4       1.0
    z_0_4_4_4         REQ_0_4         1.0
    z_0_4_4_4         OCC_4_4_4       -1.0
    z_0_4_4_4         CLS_0_4_4       -1.0
    z_0_4_4_5         OBJ           0.0
    z_0_4_4_5         DAY_0_4_4       1.0
    z_0_4_4_5         REQ_0_4         1.0
    z_0_4_4_5         OCC_4_4_5       -1.0
    z_0_4_4_5         CLS_0_4_5       -1.0
    z_0_4_4_6         OBJ           0.0
    z_0_4_4_6         DAY_0_4_4       1.0
    z_0_4_4_6         REQ_0_4         2.0
    z_0_4_4_6         OCC_4_4_0       -1.0
    z_0_4_4_6         OCC_4_4_1       -1.0
    z_0_4_4_6         CLS_0_4_0       -1.0
    z_0_4_4_6         CLS_0_4_1       -1.0
    z_0_4_4_7         OBJ           0.0
    z_0_4_4_7         DAY_0_4_4       1.0
    z_0_4_4_7         REQ_0_4         2.0
    z_0_4_4_7         OCC_4_4_1       -1.0
    z_0_4_4_7         OCC_4_4_2       -1.0
    z_0_4_4_7         CLS_0_4_1       -1.0
    z_0_4_4_7         CLS_0_4_2       -1.0
    z_0_4_4_8         OBJ           0.0
    z_0_4_4_8         DAY_0_4_4       1.0
    z_0_4_4_8         REQ_0_4         2.0
    z_0_4_4_8         OCC_4_4_2       -1.0
    z_0_4_4_8         OCC_4_4_3       -1.0
    z_0_4_4_8         CLS_0_4_2       -1.0
    z_0_4_4_8         CLS_0_4_3       -1.0
    z_0_4_4_9         OBJ           0.0
    z_0_4_4_9         DAY_0_4_4       1.0
    z_0_4_4_9         REQ_0_4         2.0
    z_0_4_4_9         OCC_4_4_3       -1.0
    z_0_4_4_9         OCC_4_4_4       -1.0
    z_0_4_4_9         CLS_0_4_3       -1.0
    z_0_4_4_9         CLS_0_4_4       -1.0
    z_0_4_4_10        OBJ           0.0
    z_0_4_4_10        DAY_0_4_4       1.0
    z_0_4_4_10        REQ_0_4         2.0
    z_0_4_4_10        OCC_4_4_4       -1.0
    z_0_4_4_10        OCC_4_4_5       -1.0
    z_0_4_4_10        CLS_0_4_4       -1.0
    z_0_4_4_10        CLS_0_4_5       -1.0
    z_0_5_0_0         OBJ           0.0
    z_0_5_0_0         DAY_0_5_0       1.0
    z_0_5_0_0         REQ_0_5         1.0
    z_0_5_0_0         OCC_5_0_0       -1.0
    z_0_5_0_0         CLS_0_0_0       -1.0
    z_0_5_0_1         OBJ           0.0
    z_0_5_0_1         DAY_0_5_0       1.0
    z_0_5_0_1         REQ_0_5         1.0
    z_0_5_0_1         OCC_5_0_1       -1.0
    z_0_5_0_1         CLS_0_0_1       -1.0
    z_0_5_0_2         OBJ           0.0
    z_0_5_0_2         DAY_0_5_0       1.0
    z_0_5_0_2         REQ_0_5         1.0
    z_0_5_0_2         OCC_5_0_2       -1.0
    z_0_5_0_2         CLS_0_0_2       -1.0
    z_0_5_0_3         OBJ           0.0
    z_0_5_0_3         DAY_0_5_0       1.0
    z_0_5_0_3         REQ_0_5         1.0
    z_0_5_0_3         OCC_5_0_3       -1.0
    z_0_5_0_3         CLS_0_0_3       -1.0
    z_0_5_0_4         OBJ           0.0
    z_0_5_0_4         DAY_0_5_0       1.0
    z_0_5_0_4         REQ_0_5         1.0
    z_0_5_0_4         OCC_5_0_4       -1.0
    z_0_5_0_4         CLS_0_0_4       -1.0
    z_0_5_0_5         OBJ           0.0
    z_0_5_0_5         DAY_0_5_0       1.0
    z_0_5_0_5         REQ_0_5         1.0
    z_0_5_0_5         OCC_5_0_5       -1.0
    z_0_5_0_5         CLS_0_0_5       -1.0
    z_0_5_0_6         OBJ           0.0
    z_0_5_0_6         DAY_0_5_0       1.0
    z_0_5_0_6         REQ_0_5         2.0
    z_0_5_0_6         OCC_5_0_0       -1.0
    z_0_5_0_6         OCC_5_0_1       -1.0
    z_0_5_0_6         CLS_0_0_0       -1.0
    z_0_5_0_6         CLS_0_0_1       -1.0
    z_0_5_0_7         OBJ           0.0
    z_0_5_0_7         DAY_0_5_0       1.0
    z_0_5_0_7         REQ_0_5         2.0
    z_0_5_0_7         OCC_5_0_1       -1.0
    z_0_5_0_7         OCC_5_0_2       -1.0
    z_0_5_0_7         CLS_0_0_1       -1.0
    z_0_5_0_7         CLS_0_0_2       -1.0
    z_0_5_0_8         OBJ           0.0
    z_0_5_0_8         DAY_0_5_0       1.0
    z_0_5_0_8         REQ_0_5         2.0
    z_0_5_0_8         OCC_5_0_2       -1.0
    z_0_5_0_8         OCC_5_0_3       -1.0
    z_0_5_0_8         CLS_0_0_2       -1.0
    z_0_5_0_8         CLS_0_0_3       -1.0
    z_0_5_0_9         OBJ           0.0
    z_0_5_0_9         DAY_0_5_0       1.0
    z_0_5_0_9         REQ_0_5         2.0
    z_0_5_0_9         OCC_5_0_3       -1.0
    z_0_5_0_9         OCC_5_0_4       -1.0
    z_0_5_0_9         CLS_0_0_3       -1.0
    z_0_5_0_9         CLS_0_0_4       -1.0
    z_0_5_0_10        OBJ           0.0
    z_0_5_0_10        DAY_0_5_0       1.0
    z_0_5_0_10        REQ_0_5         2.0
    z_0_5_0_10        OCC_5_0_4       -1.0
    z_0_5_0_10        OCC_5_0_5       -1.0
    z_0_5_0_10        CLS_0_0_4       -1.0
    z_0_5_0_10        CLS_0_0_5       -1.0
    z_0_5_1_0         OBJ           0.0
    z_0_5_1_0         DAY_0_5_1       1.0
    z_0_5_1_0         REQ_0_5         1.0
    z_0_5_1_0         OCC_5_1_0       -1.0
    z_0_5_1_0         CLS_0_1_0       -1.0
    z_0_5_1_1         OBJ           0.0
    z_0_5_1_1         DAY_0_5_1       1.0
    z_0_5_1_1         REQ_0_5         1.0
    z_0_5_1_1         OCC_5_1_2       -1.0
    z_0_5_1_1         CLS_0_1_2       -1.0
    z_0_5_1_2         OBJ           0.0
    z_0_5_1_2         DAY_0_5_1       1.0
    z_0_5_1_2         REQ_0_5         1.0
    z_0_5_1_2         OCC_5_1_3       -1.0
    z_0_5_1_2         CLS_0_1_3       -1.0
    z_0_5_1_3         OBJ           0.0
    z_0_5_1_3         DAY_0_5_1       1.0
    z_0_5_1_3         REQ_0_5         1.0
    z_0_5_1_3         OCC_5_1_4       -1.0
    z_0_5_1_3         CLS_0_1_4       -1.0
    z_0_5_1_4         OBJ           0.0
    z_0_5_1_4         DAY_0_5_1       1.0
    z_0_5_1_4         REQ_0_5         1.0
    z_0_5_1_4         OCC_5_1_5       -1.0
    z_0_5_1_4         CLS_0_1_5       -1.0
    z_0_5_1_5         OBJ           0.0
    z_0_5_1_5         DAY_0_5_1       1.0
    z_0_5_1_5         REQ_0_5         2.0
    z_0_5_1_5         OCC_5_1_2       -1.0
    z_0_5_1_5         OCC_5_1_3       -1.0
    z_0_5_1_5         CLS_0_1_2       -1.0
    z_0_5_1_5         CLS_0_1_3       -1.0
    z_0_5_1_6         OBJ           0.0
    z_0_5_1_6         DAY_0_5_1       1.0
    z_0_5_1_6         REQ_0_5         2.0
    z_0_5_1_6         OCC_5_1_3       -1.0
    z_0_5_1_6         OCC_5_1_4       -1.0
    z_0_5_1_6         CLS_0_1_3       -1.0
    z_0_5_1_6         CLS_0_1_4       -1.0
    z_0_5_1_7         OBJ           0.0
    z_0_5_1_7         DAY_0_5_1       1.0
    z_0_5_1_7         REQ_0_5         2.0
    z_0_5_1_7         OCC_5_1_4       -1.0
    z_0_5_1_7         OCC_5_1_5       -1.0
    z_0_5_1_7         CLS_0_1_4       -1.0
    z_0_5_1_7         CLS_0_1_5       -1.0
    z_0_5_2_0         OBJ           0.0
    z_0_5_2_0         DAY_0_5_2       1.0
    z_0_5_2_0         REQ_0_5         1.0
    z_0_5_2_0         OCC_5_2_0       -1.0
    z_0_5_2_0         CLS_0_2_0       -1.0
    z_0_5_2_1         OBJ           0.0
    z_0_5_2_1         DAY_0_5_2       1.0
    z_0_5_2_1         REQ_0_5         1.0
    z_0_5_2_1         OCC_5_2_1       -1.0
    z_0_5_2_1         CLS_0_2_1       -1.0
    z_0_5_2_2         OBJ           0.0
    z_0_5_2_2         DAY_0_5_2       1.0
    z_0_5_2_2         REQ_0_5         1.0
    z_0_5_2_2         OCC_5_2_2       -1.0
    z_0_5_2_2         CLS_0_2_2       -1.0
    z_0_5_2_3         OBJ           0.0
    z_0_5_2_3         DAY_0_5_2       1.0
    z_0_5_2_3         REQ_0_5         1.0
    z_0_5_2_3         OCC_5_2_4       -1.0
    z_0_5_2_3         CLS_0_2_4       -1.0
    z_0_5_2_4         OBJ           0.0
    z_0_5_2_4         DAY_0_5_2       1.0
    z_0_5_2_4         REQ_0_5         1.0
    z_0_5_2_4         OCC_5_2_5       -1.0
    z_0_5_2_4         CLS_0_2_5       -1.0
    z_0_5_2_5         OBJ           0.0
    z_0_5_2_5         DAY_0_5_2       1.0
    z_0_5_2_5         REQ_0_5         2.0
    z_0_5_2_5         OCC_5_2_0       -1.0
    z_0_5_2_5         OCC_5_2_1       -1.0
    z_0_5_2_5         CLS_0_2_0       -1.0
    z_0_5_2_5         CLS_0_2_1       -1.0
    z_0_5_2_6         OBJ           0.0
    z_0_5_2_6         DAY_0_5_2       1.0
    z_0_5_2_6         REQ_0_5         2.0
    z_0_5_2_6         OCC_5_2_1       -1.0
    z_0_5_2_6         OCC_5_2_2       -1.0
    z_0_5_2_6         CLS_0_2_1       -1.0
    z_0_5_2_6         CLS_0_2_2       -1.0
    z_0_5_2_7         OBJ           0.0
    z_0_5_2_7         DAY_0_5_2       1.0
    z_0_5_2_7         REQ_0_5         2.0
    z_0_5_2_7         OCC_5_2_4       -1.0
    z_0_5_2_7         OCC_5_2_5       -1.0
    z_0_5_2_7         CLS_0_2_4       -1.0
    z_0_5_2_7         CLS_0_2_5       -1.0
    z_0_5_3_0         OBJ           0.0
    z_0_5_3_0         DAY_0_5_3       1.0
    z_0_5_3_0         REQ_0_5         1.0
    z_0_5_3_0         OCC_5_3_0       -1.0
    z_0_5_3_0         CLS_0_3_0       -1.0
    z_0_5_3_1         OBJ           0.0
    z_0_5_3_1         DAY_0_5_3       1.0
    z_0_5_3_1         REQ_0_5         1.0
    z_0_5_3_1         OCC_5_3_1       -1.0
    z_0_5_3_1         CLS_0_3_1       -1.0
    z_0_5_3_2         OBJ           0.0
    z_0_5_3_2         DAY_0_5_3       1.0
    z_0_5_3_2         REQ_0_5         1.0
    z_0_5_3_2         OCC_5_3_2       -1.0
    z_0_5_3_2         CLS_0_3_2       -1.0
    z_0_5_3_3         OBJ           0.0
    z_0_5_3_3         DAY_0_5_3       1.0
    z_0_5_3_3         REQ_0_5         1.0
    z_0_5_3_3         OCC_5_3_3       -1.0
    z_0_5_3_3         CLS_0_3_3       -1.0
    z_0_5_3_4         OBJ           0.0
    z_0_5_3_4         DAY_0_5_3       1.0
    z_0_5_3_4         REQ_0_5         1.0
    z_0_5_3_4         OCC_5_3_4       -1.0
    z_0_5_3_4         CLS_0_3_4       -1.0
    z_0_5_3_5         OBJ           0.0
    z_0_5_3_5         DAY_0_5_3       1.0
    z_0_5_3_5         REQ_0_5         1.0
    z_0_5_3_5         OCC_5_3_5       -1.0
    z_0_5_3_5         CLS_0_3_5       -1.0
    z_0_5_3_6         OBJ           0.0
    z_0_5_3_6         DAY_0_5_3       1.0
    z_0_5_3_6         REQ_0_5         2.0
    z_0_5_3_6         OCC_5_3_0       -1.0
    z_0_5_3_6         OCC_5_3_1       -1.0
    z_0_5_3_6         CLS_0_3_0       -1.0
    z_0_5_3_6         CLS_0_3_1       -1.0
    z_0_5_3_7         OBJ           0.0
    z_0_5_3_7         DAY_0_5_3       1.0
    z_0_5_3_7         REQ_0_5         2.0
    z_0_5_3_7         OCC_5_3_1       -1.0
    z_0_5_3_7         OCC_5_3_2       -1.0
    z_0_5_3_7         CLS_0_3_1       -1.0
    z_0_5_3_7         CLS_0_3_2       -1.0
    z_0_5_3_8         OBJ           0.0
    z_0_5_3_8         DAY_0_5_3       1.0
    z_0_5_3_8         REQ_0_5         2.0
    z_0_5_3_8         OCC_5_3_2       -1.0
    z_0_5_3_8         OCC_5_3_3       -1.0
    z_0_5_3_8         CLS_0_3_2       -1.0
    z_0_5_3_8         CLS_0_3_3       -1.0
    z_0_5_3_9         OBJ           0.0
    z_0_5_3_9         DAY_0_5_3       1.0
    z_0_5_3_9         REQ_0_5         2.0
    z_0_5_3_9         OCC_5_3_3       -1.0
    z_0_5_3_9         OCC_5_3_4       -1.0
    z_0_5_3_9         CLS_0_3_3       -1.0
    z_0_5_3_9         CLS_0_3_4       -1.0
    z_0_5_3_10        OBJ           0.0
    z_0_5_3_10        DAY_0_5_3       1.0
    z_0_5_3_10        REQ_0_5         2.0
    z_0_5_3_10        OCC_5_3_4       -1.0
    z_0_5_3_10        OCC_5_3_5       -1.0
    z_0_5_3_10        CLS_0_3_4       -1.0
    z_0_5_3_10        CLS_0_3_5       -1.0
    z_1_2_0_0         OBJ           0.0
    z_1_2_0_0         DAY_1_2_0       1.0
    z_1_2_0_0         REQ_1_2         1.0
    z_1_2_0_0         OCC_2_0_0       -1.0
    z_1_2_0_0         CLS_1_0_0       -1.0
    z_1_2_0_1         OBJ           0.0
    z_1_2_0_1         DAY_1_2_0       1.0
    z_1_2_0_1         REQ_1_2         1.0
    z_1_2_0_1         OCC_2_0_1       -1.0
    z_1_2_0_1         CLS_1_0_1       -1.0
    z_1_2_0_2         OBJ           0.0
    z_1_2_0_2         DAY_1_2_0       1.0
    z_1_2_0_2         REQ_1_2         1.0
    z_1_2_0_2         OCC_2_0_2       -1.0
    z_1_2_0_2         CLS_1_0_2       -1.0
    z_1_2_0_3         OBJ           0.0
    z_1_2_0_3         DAY_1_2_0       1.0
    z_1_2_0_3         REQ_1_2         1.0
    z_1_2_0_3         OCC_2_0_3       -1.0
    z_1_2_0_3         CLS_1_0_3       -1.0
    z_1_2_0_4         OBJ           0.0
    z_1_2_0_4         DAY_1_2_0       1.0
    z_1_2_0_4         REQ_1_2         1.0
    z_1_2_0_4         OCC_2_0_4       -1.0
    z_1_2_0_4         CLS_1_0_4       -1.0
    z_1_2_0_5         OBJ           0.0
    z_1_2_0_5         DAY_1_2_0       1.0
    z_1_2_0_5         REQ_1_2         2.0
    z_1_2_0_5         OCC_2_0_0       -1.0
    z_1_2_0_5         OCC_2_0_1       -1.0
    z_1_2_0_5         CLS_1_0_0       -1.0
    z_1_2_0_5         CLS_1_0_1       -1.0
    z_1_2_0_6         OBJ           0.0
    z_1_2_0_6         DAY_1_2_0       1.0
    z_1_2_0_6         REQ_1_2         2.0
    z_1_2_0_6         OCC_2_0_1       -1.0
    z_1_2_0_6         OCC_2_0_2       -1.0
    z_1_2_0_6         CLS_1_0_1       -1.0
    z_1_2_0_6         CLS_1_0_2       -1.0
    z_1_2_0_7         OBJ           0.0
    z_1_2_0_7         DAY_1_2_0       1.0
    z_1_2_0_7         REQ_1_2         2.0
    z_1_2_0_7         OCC_2_0_2       -1.0
    z_1_2_0_7         OCC_2_0_3       -1.0
    z_1_2_0_7         CLS_1_0_2       -1.0
    z_1_2_0_7         CLS_1_0_3       -1.0
    z_1_2_0_8         OBJ           0.0
    z_1_2_0_8         DAY_1_2_0       1.0
    z_1_2_0_8         REQ_1_2         2.0
    z_1_2_0_8         OCC_2_0_3       -1.0
    z_1_2_0_8         OCC_2_0_4       -1.0
    z_1_2_0_8         CLS_1_0_3       -1.0
    z_1_2_0_8         CLS_1_0_4       -1.0
    z_1_2_1_0         OBJ           0.0
    z_1_2_1_0         DAY_1_2_1       1.0
    z_1_2_1_0         REQ_1_2         1.0
    z_1_2_1_0         OCC_2_1_0       -1.0
    z_1_2_1_0         CLS_1_1_0       -1.0
    z_1_2_1_1         OBJ           0.0
    z_1_2_1_1         DAY_1_2_1       1.0
    z_1_2_1_1         REQ_1_2         1.0
    z_1_2_1_1         OCC_2_1_1       -1.0
    z_1_2_1_1         CLS_1_1_1       -1.0
    z_1_2_1_2         OBJ           0.0
    z_1_2_1_2         DAY_1_2_1       1.0
    z_1_2_1_2         REQ_1_2         1.0
    z_1_2_1_2         OCC_2_1_2       -1.0
    z_1_2_1_2         CLS_1_1_2       -1.0
    z_1_2_1_3         OBJ           0.0
    z_1_2_1_3         DAY_1_2_1       1.0
    z_1_2_1_3         REQ_1_2         1.0
    z_1_2_1_3         OCC_2_1_3       -1.0
    z_1_2_1_3         CLS_1_1_3       -1.0
    z_1_2_1_4         OBJ           0.0
    z_1_2_1_4         DAY_1_2_1       1.0
    z_1_2_1_4         REQ_1_2         1.0
    z_1_2_1_4         OCC_2_1_4       -1.0
    z_1_2_1_4         CLS_1_1_4       -1.0
    z_1_2_1_5         OBJ           0.0
    z_1_2_1_5         DAY_1_2_1       1.0
    z_1_2_1_5         REQ_1_2         1.0
    z_1_2_1_5         OCC_2_1_5       -1.0
    z_1_2_1_5         CLS_1_1_5       -1.0
    z_1_2_1_6         OBJ           0.0
    z_1_2_1_6         DAY_1_2_1       1.0
    z_1_2_1_6         REQ_1_2         2.0
    z_1_2_1_6         OCC_2_1_0       -1.0
    z_1_2_1_6         OCC_2_1_1       -1.0
    z_1_2_1_6         CLS_1_1_0       -1.0
    z_1_2_1_6         CLS_1_1_1       -1.0
    z_1_2_1_7         OBJ           0.0
    z_1_2_1_7         DAY_1_2_1       1.0
    z_1_2_1_7         REQ_1_2         2.0
    z_1_2_1_7         OCC_2_1_1       -1.0
    z_1_2_1_7         OCC_2_1_2       -1.0
    z_1_2_1_7         CLS_1_1_1       -1.0
    z_1_2_1_7         CLS_1_1_2       -1.0
    z_1_2_1_8         OBJ           0.0
    z_1_2_1_8         DAY_1_2_1       1.0
    z_1_2_1_8         REQ_1_2         2.0
    z_1_2_1_8         OCC_2_1_2       -1.0
    z_1_2_1_8         OCC_2_1_3       -1.0
    z_1_2_1_8         CLS_1_1_2       -1.0
    z_1_2_1_8         CLS_1_1_3       -1.0
    z_1_2_1_9         OBJ           0.0
    z_1_2_1_9         DAY_1_2_1       1.0
    z_1_2_1_9         REQ_1_2         2.0
    z_1_2_1_9         OCC_2_1_3       -1.0
    z_1_2_1_9         OCC_2_1_4       -1.0
    z_1_2_1_9         CLS_1_1_3       -1.0
    z_1_2_1_9         CLS_1_1_4       -1.0
    z_1_2_1_10        OBJ           0.0
    z_1_2_1_10        DAY_1_2_1       1.0
    z_1_2_1_10        REQ_1_2         2.0
    z_1_2_1_10        OCC_2_1_4       -1.0
    z_1_2_1_10        OCC_2_1_5       -1.0
    z_1_2_1_10        CLS_1_1_4       -1.0
    z_1_2_1_10        CLS_1_1_5       -1.0
    z_1_2_2_0         OBJ           0.0
    z_1_2_2_0         DAY_1_2_2       1.0
    z_1_2_2_0         REQ_1_2         1.0
    z_1_2_2_0         OCC_2_2_0       -1.0
    z_1_2_2_0         CLS_1_2_0       -1.0
    z_1_2_2_1         OBJ           0.0
    z_1_2_2_1         DAY_1_2_2       1.0
    z_1_2_2_1         REQ_1_2         1.0
    z_1_2_2_1         OCC_2_2_1       -1.0
    z_1_2_2_1         CLS_1_2_1       -1.0
    z_1_2_2_2         OBJ           0.0
    z_1_2_2_2         DAY_1_2_2       1.0
    z_1_2_2_2         REQ_1_2         1.0
    z_1_2_2_2         OCC_2_2_2       -1.0
    z_1_2_2_2         CLS_1_2_2       -1.0
    z_1_2_2_3         OBJ           0.0
    z_1_2_2_3         DAY_1_2_2       1.0
    z_1_2_2_3         REQ_1_2         1.0
    z_1_2_2_3         OCC_2_2_3       -1.0
    z_1_2_2_3         CLS_1_2_3       -1.0
    z_1_2_2_4         OBJ           0.0
    z_1_2_2_4         DAY_1_2_2       1.0
    z_1_2_2_4         REQ_1_2         1.0
    z_1_2_2_4         OCC_2_2_4       -1.0
    z_1_2_2_4         CLS_1_2_4       -1.0
    z_1_2_2_5         OBJ           0.0
    z_1_2_2_5         DAY_1_2_2       1.0
    z_1_2_2_5         REQ_1_2         2.0
    z_1_2_2_5         OCC_2_2_0       -1.0
    z_1_2_2_5         OCC_2_2_1       -1.0
    z_1_2_2_5         CLS_1_2_0       -1.0
    z_1_2_2_5         CLS_1_2_1       -1.0
    z_1_2_2_6         OBJ           0.0
    z_1_2_2_6         DAY_1_2_2       1.0
    z_1_2_2_6         REQ_1_2         2.0
    z_1_2_2_6         OCC_2_2_1       -1.0
    z_1_2_2_6         OCC_2_2_2       -1.0
    z_1_2_2_6         CLS_1_2_1       -1.0
    z_1_2_2_6         CLS_1_2_2       -1.0
    z_1_2_2_7         OBJ           0.0
    z_1_2_2_7         DAY_1_2_2       1.0
    z_1_2_2_7         REQ_1_2         2.0
    z_1_2_2_7         OCC_2_2_2       -1.0
    z_1_2_2_7         OCC_2_2_3       -1.0
    z_1_2_2_7         CLS_1_2_2       -1.0
    z_1_2_2_7         CLS_1_2_3       -1.0
    z_1_2_2_8         OBJ           0.0
    z_1_2_2_8         DAY_1_2_2       1.0
    z_1_2_2_8         REQ_1_2         2.0
    z_1_2_2_8         OCC_2_2_3       -1.0
    z_1_2_2_8         OCC_2_2_4       -1.0
    z_1_2_2_8         CLS_1_2_3       -1.0
    z_1_2_2_8         CLS_1_2_4       -1.0
    z_1_2_3_0         OBJ           0.0
    z_1_2_3_0         DAY_1_2_3       1.0
    z_1_2_3_0         REQ_1_2         1.0
    z_1_2_3_0         OCC_2_3_0       -1.0
    z_1_2_3_0         CLS_1_3_0       -1.0
    z_1_2_3_1         OBJ           0.0
    z_1_2_3_1         DAY_1_2_3       1.0
    z_1_2_3_1         REQ_1_2         1.0
    z_1_2_3_1         OCC_2_3_1       -1.0
    z_1_2_3_1         CLS_1_3_1       -1.0
    z_1_2_3_2         OBJ           0.0
    z_1_2_3_2         DAY_1_2_3       1.0
    z_1_2_3_2         REQ_1_2         1.0
    z_1_2_3_2         OCC_2_3_2       -1.0
    z_1_2_3_2         CLS_1_3_2       -1.0
    z_1_2_3_3         OBJ           0.0
    z_1_2_3_3         DAY_1_2_3       1.0
    z_1_2_3_3         REQ_1_2         1.0
    z_1_2_3_3         OCC_2_3_3       -1.0
    z_1_2_3_3         CLS_1_3_3       -1.0
    z_1_2_3_4         OBJ           0.0
    z_1_2_3_4         DAY_1_2_3       1.0
    z_1_2_3_4         REQ_1_2         1.0
    z_1_2_3_4         OCC_2_3_4       -1.0
    z_1_2_3_4         CLS_1_3_4       -1.0
    z_1_2_3_5         OBJ           0.0
    z_1_2_3_5         DAY_1_2_3       1.0
    z_1_2_3_5         REQ_1_2         1.0
    z_1_2_3_5         OCC_2_3_5       -1.0
    z_1_2_3_5         CLS_1_3_5       -1.0
    z_1_2_3_6         OBJ           0.0
    z_1_2_3_6         DAY_1_2_3       1.0
    z_1_2_3_6         REQ_1_2         2.0
    z_1_2_3_6         OCC_2_3_0       -1.0
    z_1_2_3_6         OCC_2_3_1       -1.0
    z_1_2_3_6         CLS_1_3_0       -1.0
    z_1_2_3_6         CLS_1_3_1       -1.0
    z_1_2_3_7         OBJ           0.0
    z_1_2_3_7         DAY_1_2_3       1.0
    z_1_2_3_7         REQ_1_2         2.0
    z_1_2_3_7         OCC_2_3_1       -1.0
    z_1_2_3_7         OCC_2_3_2       -1.0
    z_1_2_3_7         CLS_1_3_1       -1.0
    z_1_2_3_7         CLS_1_3_2       -1.0
    z_1_2_3_8         OBJ           0.0
    z_1_2_3_8         DAY_1_2_3       1.0
    z_1_2_3_8         REQ_1_2         2.0
    z_1_2_3_8         OCC_2_3_2       -1.0
    z_1_2_3_8         OCC_2_3_3       -1.0
    z_1_2_3_8         CLS_1_3_2       -1.0
    z_1_2_3_8         CLS_1_3_3       -1.0
    z_1_2_3_9         OBJ           0.0
    z_1_2_3_9         DAY_1_2_3       1.0
    z_1_2_3_9         REQ_1_2         2.0
    z_1_2_3_9         OCC_2_3_3       -1.0
    z_1_2_3_9         OCC_2_3_4       -1.0
    z_1_2_3_9         CLS_1_3_3       -1.0
    z_1_2_3_9         CLS_1_3_4       -1.0
    z_1_2_3_10        OBJ           0.0
    z_1_2_3_10        DAY_1_2_3       1.0
    z_1_2_3_10        REQ_1_2         2.0
    z_1_2_3_10        OCC_2_3_4       -1.0
    z_1_2_3_10        OCC_2_3_5       -1.0
    z_1_2_3_10        CLS_1_3_4       -1.0
    z_1_2_3_10        CLS_1_3_5       -1.0
    z_1_2_4_0         OBJ           0.0
    z_1_2_4_0         DAY_1_2_4       1.0
    z_1_2_4_0         REQ_1_2         1.0
    z_1_2_4_0         OCC_2_4_0       -1.0
    z_1_2_4_0         CLS_1_4_0       -1.0
    z_1_2_4_1         OBJ           0.0
    z_1_2_4_1         DAY_1_2_4       1.0
    z_1_2_4_1         REQ_1_2         1.0
    z_1_2_4_1         OCC_2_4_2       -1.0
    z_1_2_4_1         CLS_1_4_2       -1.0
    z_1_2_4_2         OBJ           0.0
    z_1_2_4_2         DAY_1_2_4       1.0
    z_1_2_4_2         REQ_1_2         1.0
    z_1_2_4_2         OCC_2_4_3       -1.0
    z_1_2_4_2         CLS_1_4_3       -1.0
    z_1_2_4_3         OBJ           0.0
    z_1_2_4_3         DAY_1_2_4       1.0
    z_1_2_4_3         REQ_1_2         1.0
    z_1_2_4_3         OCC_2_4_5       -1.0
    z_1_2_4_3         CLS_1_4_5       -1.0
    z_1_2_4_4         OBJ           0.0
    z_1_2_4_4         DAY_1_2_4       1.0
    z_1_2_4_4         REQ_1_2         2.0
    z_1_2_4_4         OCC_2_4_2       -1.0
    z_1_2_4_4         OCC_2_4_3       -1.0
    z_1_2_4_4         CLS_1_4_2       -1.0
    z_1_2_4_4         CLS_1_4_3       -1.0
    z_1_5_0_0         OBJ           0.0
    z_1_5_0_0         DAY_1_5_0       1.0
    z_1_5_0_0         REQ_1_5         1.0
    z_1_5_0_0         OCC_5_0_0       -1.0
    z_1_5_0_0         CLS_1_0_0       -1.0
    z_1_5_0_1         OBJ           0.0
    z_1_5_0_1         DAY_1_5_0       1.0
    z_1_5_0_1         REQ_1_5         1.0
    z_1_5_0_1         OCC_5_0_1       -1.0
    z_1_5_0_1         CLS_1_0_1       -1.0
    z_1_5_0_2         OBJ           0.0
    z_1_5_0_2         DAY_1_5_0       1.0
    z_1_5_0_2         REQ_1_5         1.0
    z_1_5_0_2         OCC_5_0_2       -1.0
    z_1_5_0_2         CLS_1_0_2       -1.0
    z_1_5_0_3         OBJ           0.0
    z_1_5_0_3         DAY_1_5_0       1.0
    z_1_5_0_3         REQ_1_5         1.0
    z_1_5_0_3         OCC_5_0_3       -1.0
    z_1_5_0_3         CLS_1_0_3       -1.0
    z_1_5_0_4         OBJ           0.0
    z_1_5_0_4         DAY_1_5_0       1.0
    z_1_5_0_4         REQ_1_5         1.0
    z_1_5_0_4         OCC_5_0_4       -1.0
    z_1_5_0_4         CLS_1_0_4       -1.0
    z_1_5_0_5         OBJ           0.0
    z_1_5_0_5         DAY_1_5_0       1.0
    z_1_5_0_5         REQ_1_5         1.0
    z_1_5_0_5         OCC_5_0_5       -1.0
    z_1_5_0_5         CLS_1_0_5       -1.0
    z_1_5_0_6         OBJ           0.0
    z_1_5_0_6         DAY_1_5_0       1.0
    z_1_5_0_6         REQ_1_5         2.0
    z_1_5_0_6         OCC_5_0_0       -1.0
    z_1_5_0_6         OCC_5_0_1       -1.0
    z_1_5_0_6         CLS_1_0_0       -1.0
    z_1_5_0_6         CLS_1_0_1       -1.0
    z_1_5_0_7         OBJ           0.0
    z_1_5_0_7         DAY_1_5_0       1.0
    z_1_5_0_7         REQ_1_5         2.0
    z_1_5_0_7         OCC_5_0_1       -1.0
    z_1_5_0_7         OCC_5_0_2       -1.0
    z_1_5_0_7         CLS_1_0_1       -1.0
    z_1_5_0_7         CLS_1_0_2       -1.0
    z_1_5_0_8         OBJ           0.0
    z_1_5_0_8         DAY_1_5_0       1.0
    z_1_5_0_8         REQ_1_5         2.0
    z_1_5_0_8         OCC_5_0_2       -1.0
    z_1_5_0_8         OCC_5_0_3       -1.0
    z_1_5_0_8         CLS_1_0_2       -1.0
    z_1_5_0_8         CLS_1_0_3       -1.0
    z_1_5_0_9         OBJ           0.0
    z_1_5_0_9         DAY_1_5_0       1.0
    z_1_5_0_9         REQ_1_5         2.0
    z_1_5_0_9         OCC_5_0_3       -1.0
    z_1_5_0_9         OCC_5_0_4       -1.0
    z_1_5_0_9         CLS_1_0_3       -1.0
    z_1_5_0_9         CLS_1_0_4       -1.0
    z_1_5_0_10        OBJ           0.0
    z_1_5_0_10        DAY_1_5_0       1.0
    z_1_5_0_10        REQ_1_5         2.0
    z_1_5_0_10        OCC_5_0_4       -1.0
    z_1_5_0_10        OCC_5_0_5       -1.0
    z_1_5_0_10        CLS_1_0_4       -1.0
    z_1_5_0_10        CLS_1_0_5       -1.0
    z_1_5_1_0         OBJ           0.0
    z_1_5_1_0         DAY_1_5_1       1.0
    z_1_5_1_0         REQ_1_5         1.0
    z_1_5_1_0         OCC_5_1_0       -1.0
    z_1_5_1_0         CLS_1_1_0       -1.0
    z_1_5_1_1         OBJ           0.0
    z_1_5_1_1         DAY_1_5_1       1.0
    z_1_5_1_1         REQ_1_5         1.0
    z_1_5_1_1         OCC_5_1_2       -1.0
    z_1_5_1_1         CLS_1_1_2       -1.0
    z_1_5_1_2         OBJ           0.0
    z_1_5_1_2         DAY_1_5_1       1.0
    z_1_5_1_2         REQ_1_5         1.0
    z_1_5_1_2         OCC_5_1_3       -1.0
    z_1_5_1_2         CLS_1_1_3       -1.0
    z_1_5_1_3         OBJ           0.0
    z_1_5_1_3         DAY_1_5_1       1.0
    z_1_5_1_3         REQ_1_5         1.0
    z_1_5_1_3         OCC_5_1_4       -1.0
    z_1_5_1_3         CLS_1_1_4       -1.0
    z_1_5_1_4         OBJ           0.0
    z_1_5_1_4         DAY_1_5_1       1.0
    z_1_5_1_4         REQ_1_5         1.0
    z_1_5_1_4         OCC_5_1_5       -1.0
    z_1_5_1_4         CLS_1_1_5       -1.0
    z_1_5_1_5         OBJ           0.0
    z_1_5_1_5         DAY_1_5_1       1.0
    z_1_5_1_5         REQ_1_5         2.0
    z_1_5_1_5         OCC_5_1_2       -1.0
    z_1_5_1_5         OCC_5_1_3       -1.0
    z_1_5_1_5         CLS_1_1_2       -1.0
    z_1_5_1_5         CLS_1_1_3       -1.0
    z_1_5_1_6         OBJ           0.0
    z_1_5_1_6         DAY_1_5_1       1.0
    z_1_5_1_6         REQ_1_5         2.0
    z_1_5_1_6         OCC_5_1_3       -1.0
    z_1_5_1_6         OCC_5_1_4       -1.0
    z_1_5_1_6         CLS_1_1_3       -1.0
    z_1_5_1_6         CLS_1_1_4       -1.0
    z_1_5_1_7         OBJ           0.0
    z_1_5_1_7         DAY_1_5_1       1.0
    z_1_5_1_7         REQ_1_5         2.0
    z_1_5_1_7         OCC_5_1_4       -1.0
    z_1_5_1_7         OCC_5_1_5       -1.0
    z_1_5_1_7         CLS_1_1_4       -1.0
    z_1_5_1_7         CLS_1_1_5       -1.0
    z_1_5_2_0         OBJ           0.0
    z_1_5_2_0         DAY_1_5_2       1.0
    z_1_5_2_0         REQ_1_5         1.0
    z_1_5_2_0         OCC_5_2_0       -1.0
    z_1_5_2_0         CLS_1_2_0       -1.0
    z_1_5_2_1         OBJ           0.0
    z_1_5_2_1         DAY_1_5_2       1.0
    z_1_5_2_1         REQ_1_5         1.0
    z_1_5_2_1         OCC_5_2_1       -1.0
    z_1_5_2_1         CLS_1_2_1       -1.0
    z_1_5_2_2         OBJ           0.0
    z_1_5_2_2         DAY_1_5_2       1.0
    z_1_5_2_2         REQ_1_5         1.0
    z_1_5_2_2         OCC_5_2_2       -1.0
    z_1_5_2_2         CLS_1_2_2       -1.0
    z_1_5_2_3         OBJ           0.0
    z_1_5_2_3         DAY_1_5_2       1.0
    z_1_5_2_3         REQ_1_5         1.0
    z_1_5_2_3         OCC_5_2_4       -1.0
    z_1_5_2_3         CLS_1_2_4       -1.0
    z_1_5_2_4         OBJ           0.0
    z_1_5_2_4         DAY_1_5_2       1.0
    z_1_5_2_4         REQ_1_5         1.0
    z_1_5_2_4         OCC_5_2_5       -1.0
    z_1_5_2_4         CLS_1_2_5       -1.0
    z_1_5_2_5         OBJ           0.0
    z_1_5_2_5         DAY_1_5_2       1.0
    z_1_5_2_5         REQ_1_5         2.0
    z_1_5_2_5         OCC_5_2_0       -1.0
    z_1_5_2_5         OCC_5_2_1       -1.0
    z_1_5_2_5         CLS_1_2_0       -1.0
    z_1_5_2_5         CLS_1_2_1       -1.0
    z_1_5_2_6         OBJ           0.0
    z_1_5_2_6         DAY_1_5_2       1.0
    z_1_5_2_6         REQ_1_5         2.0
    z_1_5_2_6         OCC_5_2_1       -1.0
    z_1_5_2_6         OCC_5_2_2       -1.0
    z_1_5_2_6         CLS_1_2_1       -1.0
    z_1_5_2_6         CLS_1_2_2       -1.0
    z_1_5_2_7         OBJ           0.0
    z_1_5_2_7         DAY_1_5_2       1.0
    z_1_5_2_7         REQ_1_5         2.0
    z_1_5_2_7         OCC_5_2_4       -1.0
    z_1_5_2_7         OCC_5_2_5       -1.0
    z_1_5_2_7         CLS_1_2_4       -1.0
    z_1_5_2_7         CLS_1_2_5       -1.0
    z_1_5_3_0         OBJ           0.0
    z_1_5_3_0         DAY_1_5_3       1.0
    z_1_5_3_0         REQ_1_5         1.0
    z_1_5_3_0         OCC_5_3_0       -1.0
    z_1_5_3_0         CLS_1_3_0       -1.0
    z_1_5_3_1         OBJ           0.0
    z_1_5_3_1         DAY_1_5_3       1.0
    z_1_5_3_1         REQ_1_5         1.0
    z_1_5_3_1         OCC_5_3_1       -1.0
    z_1_5_3_1         CLS_1_3_1       -1.0
    z_1_5_3_2         OBJ           0.0
    z_1_5_3_2         DAY_1_5_3       1.0
    z_1_5_3_2         REQ_1_5         1.0
    z_1_5_3_2         OCC_5_3_2       -1.0
    z_1_5_3_2         CLS_1_3_2       -1.0
    z_1_5_3_3         OBJ           0.0
    z_1_5_3_3         DAY_1_5_3       1.0
    z_1_5_3_3         REQ_1_5         1.0
    z_1_5_3_3         OCC_5_3_3       -1.0
    z_1_5_3_3         CLS_1_3_3       -1.0
    z_1_5_3_4         OBJ           0.0
    z_1_5_3_4         DAY_1_5_3       1.0
    z_1_5_3_4         REQ_1_5         1.0
    z_1_5_3_4         OCC_5_3_4       -1.0
    z_1_5_3_4         CLS_1_3_4       -1.0
    z_1_5_3_5         OBJ           0.0
    z_1_5_3_5         DAY_1_5_3       1.0
    z_1_5_3_5         REQ_1_5         1.0
    z_1_5_3_5         OCC_5_3_5       -1.0
    z_1_5_3_5         CLS_1_3_5       -1.0
    z_1_5_3_6         OBJ           0.0
    z_1_5_3_6         DAY_1_5_3       1.0
    z_1_5_3_6         REQ_1_5         2.0
    z_1_5_3_6         OCC_5_3_0       -1.0
    z_1_5_3_6         OCC_5_3_1       -1.0
    z_1_5_3_6         CLS_1_3_0       -1.0
    z_1_5_3_6         CLS_1_3_1       -1.0
    z_1_5_3_7         OBJ           0.0
    z_1_5_3_7         DAY_1_5_3       1.0
    z_1_5_3_7         REQ_1_5         2.0
    z_1_5_3_7         OCC_5_3_1       -1.0
    z_1_5_3_7         OCC_5_3_2       -1.0
    z_1_5_3_7         CLS_1_3_1       -1.0
    z_1_5_3_7         CLS_1_3_2       -1.0
    z_1_5_3_8         OBJ           0.0
    z_1_5_3_8         DAY_1_5_3       1.0
    z_1_5_3_8         REQ_1_5         2.0
    z_1_5_3_8         OCC_5_3_2       -1.0
    z_1_5_3_8         OCC_5_3_3       -1.0
    z_1_5_3_8         CLS_1_3_2       -1.0
    z_1_5_3_8         CLS_1_3_3       -1.0
    z_1_5_3_9         OBJ           0.0
    z_1_5_3_9         DAY_1_5_3       1.0
    z_1_5_3_9         REQ_1_5         2.0
    z_1_5_3_9         OCC_5_3_3       -1.0
    z_1_5_3_9         OCC_5_3_4       -1.0
    z_1_5_3_9         CLS_1_3_3       -1.0
    z_1_5_3_9         CLS_1_3_4       -1.0
    z_1_5_3_10        OBJ           0.0
    z_1_5_3_10        DAY_1_5_3       1.0
    z_1_5_3_10        REQ_1_5         2.0
    z_1_5_3_10        OCC_5_3_4       -1.0
    z_1_5_3_10        OCC_5_3_5       -1.0
    z_1_5_3_10        CLS_1_3_4       -1.0
    z_1_5_3_10        CLS_1_3_5       -1.0
    z_1_6_0_0         OBJ           0.0
    z_1_6_0_0         DAY_1_6_0       1.0
    z_1_6_0_0         REQ_1_6         1.0
    z_1_6_0_0         OCC_6_0_0       -1.0
    z_1_6_0_0         CLS_1_0_0       -1.0
    z_1_6_0_1         OBJ           0.0
    z_1_6_0_1         DAY_1_6_0       1.0
    z_1_6_0_1         REQ_1_6         1.0
    z_1_6_0_1         OCC_6_0_1       -1.0
    z_1_6_0_1         CLS_1_0_1       -1.0
    z_1_6_0_2         OBJ           0.0
    z_1_6_0_2         DAY_1_6_0       1.0
    z_1_6_0_2         REQ_1_6         1.0
    z_1_6_0_2         OCC_6_0_2       -1.0
    z_1_6_0_2         CLS_1_0_2       -1.0
    z_1_6_0_3         OBJ           0.0
    z_1_6_0_3         DAY_1_6_0       1.0
    z_1_6_0_3         REQ_1_6         1.0
    z_1_6_0_3         OCC_6_0_3       -1.0
    z_1_6_0_3         CLS_1_0_3       -1.0
    z_1_6_0_4         OBJ           0.0
    z_1_6_0_4         DAY_1_6_0       1.0
    z_1_6_0_4         REQ_1_6         1.0
    z_1_6_0_4         OCC_6_0_4       -1.0
    z_1_6_0_4         CLS_1_0_4       -1.0
    z_1_6_0_5         OBJ           0.0
    z_1_6_0_5         DAY_1_6_0       1.0
    z_1_6_0_5         REQ_1_6         1.0
    z_1_6_0_5         OCC_6_0_5       -1.0
    z_1_6_0_5         CLS_1_0_5       -1.0
    z_1_6_0_6         OBJ           0.0
    z_1_6_0_6         DAY_1_6_0       1.0
    z_1_6_0_6         REQ_1_6         2.0
    z_1_6_0_6         OCC_6_0_0       -1.0
    z_1_6_0_6         OCC_6_0_1       -1.0
    z_1_6_0_6         CLS_1_0_0       -1.0
    z_1_6_0_6         CLS_1_0_1       -1.0
    z_1_6_0_7         OBJ           0.0
    z_1_6_0_7         DAY_1_6_0       1.0
    z_1_6_0_7         REQ_1_6         2.0
    z_1_6_0_7         OCC_6_0_1       -1.0
    z_1_6_0_7         OCC_6_0_2       -1.0
    z_1_6_0_7         CLS_1_0_1       -1.0
    z_1_6_0_7         CLS_1_0_2       -1.0
    z_1_6_0_8         OBJ           0.0
    z_1_6_0_8         DAY_1_6_0       1.0
    z_1_6_0_8         REQ_1_6         2.0
    z_1_6_0_8         OCC_6_0_2       -1.0
    z_1_6_0_8         OCC_6_0_3       -1.0
    z_1_6_0_8         CLS_1_0_2       -1.0
    z_1_6_0_8         CLS_1_0_3       -1.0
    z_1_6_0_9         OBJ           0.0
    z_1_6_0_9         DAY_1_6_0       1.0
    z_1_6_0_9         REQ_1_6         2.0
    z_1_6_0_9         OCC_6_0_3       -1.0
    z_1_6_0_9         OCC_6_0_4       -1.0
    z_1_6_0_9         CLS_1_0_3       -1.0
    z_1_6_0_9         CLS_1_0_4       -1.0
    z_1_6_0_10        OBJ           0.0
    z_1_6_0_10        DAY_1_6_0       1.0
    z_1_6_0_10        REQ_1_6         2.0
    z_1_6_0_10        OCC_6_0_4       -1.0
    z_1_6_0_10        OCC_6_0_5       -1.0
    z_1_6_0_10        CLS_1_0_4       -1.0
    z_1_6_0_10        CLS_1_0_5       -1.0
    z_1_6_1_0         OBJ           0.0
    z_1_6_1_0         DAY_1_6_1       1.0
    z_1_6_1_0         REQ_1_6         1.0
    z_1_6_1_0         OCC_6_1_0       -1.0
    z_1_6_1_0         CLS_1_1_0       -1.0
    z_1_6_1_1         OBJ           0.0
    z_1_6_1_1         DAY_1_6_1       1.0
    z_1_6_1_1         REQ_1_6         1.0
    z_1_6_1_1         OCC_6_1_1       -1.0
    z_1_6_1_1         CLS_1_1_1       -1.0
    z_1_6_1_2         OBJ           0.0
    z_1_6_1_2         DAY_1_6_1       1.0
    z_1_6_1_2         REQ_1_6         1.0
    z_1_6_1_2         OCC_6_1_2       -1.0
    z_1_6_1_2         CLS_1_1_2       -1.0
    z_1_6_1_3         OBJ           0.0
    z_1_6_1_3         DAY_1_6_1       1.0
    z_1_6_1_3         REQ_1_6         1.0
    z_1_6_1_3         OCC_6_1_3       -1.0
    z_1_6_1_3         CLS_1_1_3       -1.0
    z_1_6_1_4         OBJ           0.0
    z_1_6_1_4         DAY_1_6_1       1.0
    z_1_6_1_4         REQ_1_6         1.0
    z_1_6_1_4         OCC_6_1_4       -1.0
    z_1_6_1_4         CLS_1_1_4       -1.0
    z_1_6_1_5         OBJ           0.0
    z_1_6_1_5         DAY_1_6_1       1.0
    z_1_6_1_5         REQ_1_6         1.0
    z_1_6_1_5         OCC_6_1_5       -1.0
    z_1_6_1_5         CLS_1_1_5       -1.0
    z_1_6_1_6         OBJ           0.0
    z_1_6_1_6         DAY_1_6_1       1.0
    z_1_6_1_6         REQ_1_6         2.0
    z_1_6_1_6         OCC_6_1_0       -1.0
    z_1_6_1_6         OCC_6_1_1       -1.0
    z_1_6_1_6         CLS_1_1_0       -1.0
    z_1_6_1_6         CLS_1_1_1       -1.0
    z_1_6_1_7         OBJ           0.0
    z_1_6_1_7         DAY_1_6_1       1.0
    z_1_6_1_7         REQ_1_6         2.0
    z_1_6_1_7         OCC_6_1_1       -1.0
    z_1_6_1_7         OCC_6_1_2       -1.0
    z_1_6_1_7         CLS_1_1_1       -1.0
    z_1_6_1_7         CLS_1_1_2       -1.0
    z_1_6_1_8         OBJ           0.0
    z_1_6_1_8         DAY_1_6_1       1.0
    z_1_6_1_8         REQ_1_6         2.0
    z_1_6_1_8         OCC_6_1_2       -1.0
    z_1_6_1_8         OCC_6_1_3       -1.0
    z_1_6_1_8         CLS_1_1_2       -1.0
    z_1_6_1_8         CLS_1_1_3       -1.0
    z_1_6_1_9         OBJ           0.0
    z_1_6_1_9         DAY_1_6_1       1.0
    z_1_6_1_9         REQ_1_6         2.0
    z_1_6_1_9         OCC_6_1_3       -1.0
    z_1_6_1_9         OCC_6_1_4       -1.0
    z_1_6_1_9         CLS_1_1_3       -1.0
    z_1_6_1_9         CLS_1_1_4       -1.0
    z_1_6_1_10        OBJ           0.0
    z_1_6_1_10        DAY_1_6_1       1.0
    z_1_6_1_10        REQ_1_6         2.0
    z_1_6_1_10        OCC_6_1_4       -1.0
    z_1_6_1_10        OCC_6_1_5       -1.0
    z_1_6_1_10        CLS_1_1_4       -1.0
    z_1_6_1_10        CLS_1_1_5       -1.0
    z_1_6_2_0         OBJ           0.0
    z_1_6_2_0         DAY_1_6_2       1.0
    z_1_6_2_0         REQ_1_6         1.0
    z_1_6_2_0         OCC_6_2_0       -1.0
    z_1_6_2_0         CLS_1_2_0       -1.0
    z_1_6_2_1         OBJ           0.0
    z_1_6_2_1         DAY_1_6_2       1.0
    z_1_6_2_1         REQ_1_6         1.0
    z_1_6_2_1         OCC_6_2_1       -1.0
    z_1_6_2_1         CLS_1_2_1       -1.0
    z_1_6_2_2         OBJ           0.0
    z_1_6_2_2         DAY_1_6_2       1.0
    z_1_6_2_2         REQ_1_6         1.0
    z_1_6_2_2         OCC_6_2_2       -1.0
    z_1_6_2_2         CLS_1_2_2       -1.0
    z_1_6_2_3         OBJ           0.0
    z_1_6_2_3         DAY_1_6_2       1.0
    z_1_6_2_3         REQ_1_6         1.0
    z_1_6_2_3         OCC_6_2_3       -1.0
    z_1_6_2_3         CLS_1_2_3       -1.0
    z_1_6_2_4         OBJ           0.0
    z_1_6_2_4         DAY_1_6_2       1.0
    z_1_6_2_4         REQ_1_6         1.0
    z_1_6_2_4         OCC_6_2_4       -1.0
    z_1_6_2_4         CLS_1_2_4       -1.0
    z_1_6_2_5         OBJ           0.0
    z_1_6_2_5         DAY_1_6_2       1.0
    z_1_6_2_5         REQ_1_6         2.0
    z_1_6_2_5         OCC_6_2_0       -1.0
    z_1_6_2_5         OCC_6_2_1       -1.0
    z_1_6_2_5         CLS_1_2_0       -1.0
    z_1_6_2_5         CLS_1_2_1       -1.0
    z_1_6_2_6         OBJ           0.0
    z_1_6_2_6         DAY_1_6_2       1.0
    z_1_6_2_6         REQ_1_6         2.0
    z_1_6_2_6         OCC_6_2_1       -1.0
    z_1_6_2_6         OCC_6_2_2       -1.0
    z_1_6_2_6         CLS_1_2_1       -1.0
    z_1_6_2_6         CLS_1_2_2       -1.0
    z_1_6_2_7         OBJ           0.0
    z_1_6_2_7         DAY_1_6_2       1.0
    z_1_6_2_7         REQ_1_6         2.0
    z_1_6_2_7         OCC_6_2_2       -1.0
    z_1_6_2_7         OCC_6_2_3       -1.0
    z_1_6_2_7         CLS_1_2_2       -1.0
    z_1_6_2_7         CLS_1_2_3       -1.0
    z_1_6_2_8         OBJ           0.0
    z_1_6_2_8         DAY_1_6_2       1.0
    z_1_6_2_8         REQ_1_6         2.0
    z_1_6_2_8         OCC_6_2_3       -1.0
    z_1_6_2_8         OCC_6_2_4       -1.0
    z_1_6_2_8         CLS_1_2_3       -1.0
    z_1_6_2_8         CLS_1_2_4       -1.0
    z_1_6_3_0         OBJ           0.0
    z_1_6_3_0         DAY_1_6_3       1.0
    z_1_6_3_0         REQ_1_6         1.0
    z_1_6_3_0         OCC_6_3_0       -1.0
    z_1_6_3_0         CLS_1_3_0       -1.0
    z_1_6_3_1         OBJ           0.0
    z_1_6_3_1         DAY_1_6_3       1.0
    z_1_6_3_1         REQ_1_6         1.0
    z_1_6_3_1         OCC_6_3_1       -1.0
    z_1_6_3_1         CLS_1_3_1       -1.0
    z_1_6_3_2         OBJ           0.0
    z_1_6_3_2         DAY_1_6_3       1.0
    z_1_6_3_2         REQ_1_6         1.0
    z_1_6_3_2         OCC_6_3_2       -1.0
    z_1_6_3_2         CLS_1_3_2       -1.0
    z_1_6_3_3         OBJ           0.0
    z_1_6_3_3         DAY_1_6_3       1.0
    z_1_6_3_3         REQ_1_6         1.0
    z_1_6_3_3         OCC_6_3_3       -1.0
    z_1_6_3_3         CLS_1_3_3       -1.0
    z_1_6_3_4         OBJ           0.0
    z_1_6_3_4         DAY_1_6_3       1.0
    z_1_6_3_4         REQ_1_6         1.0
    z_1_6_3_4         OCC_6_3_5       -1.0
    z_1_6_3_4         CLS_1_3_5       -1.0
    z_1_6_3_5         OBJ           0.0
    z_1_6_3_5         DAY_1_6_3       1.0
    z_1_6_3_5         REQ_1_6         2.0
    z_1_6_3_5         OCC_6_3_0       -1.0
    z_1_6_3_5         OCC_6_3_1       -1.0
    z_1_6_3_5         CLS_1_3_0       -1.0
    z_1_6_3_5         CLS_1_3_1       -1.0
    z_1_6_3_6         OBJ           0.0
    z_1_6_3_6         DAY_1_6_3       1.0
    z_1_6_3_6         REQ_1_6         2.0
    z_1_6_3_6         OCC_6_3_1       -1.0
    z_1_6_3_6         OCC_6_3_2       -1.0
    z_1_6_3_6         CLS_1_3_1       -1.0
    z_1_6_3_6         CLS_1_3_2       -1.0
    z_1_6_3_7         OBJ           0.0
    z_1_6_3_7         DAY_1_6_3       1.0
    z_1_6_3_7         REQ_1_6         2.0
    z_1_6_3_7         OCC_6_3_2       -1.0
    z_1_6_3_7         OCC_6_3_3       -1.0
    z_1_6_3_7         CLS_1_3_2       -1.0
    z_1_6_3_7         CLS_1_3_3       -1.0
    z_1_6_4_0         OBJ           0.0
    z_1_6_4_0         DAY_1_6_4       1.0
    z_1_6_4_0         REQ_1_6         1.0
    z_1_6_4_0         OCC_6_4_0       -1.0
    z_1_6_4_0         CLS_1_4_0       -1.0
    z_1_6_4_1         OBJ           0.0
    z_1_6_4_1         DAY_1_6_4       1.0
    z_1_6_4_1         REQ_1_6         1.0
    z_1_6_4_1         OCC_6_4_1       -1.0
    z_1_6_4_1         CLS_1_4_1       -1.0
    z_1_6_4_2         OBJ           0.0
    z_1_6_4_2         DAY_1_6_4       1.0
    z_1_6_4_2         REQ_1_6         1.0
    z_1_6_4_2         OCC_6_4_2       -1.0
    z_1_6_4_2         CLS_1_4_2       -1.0
    z_1_6_4_3         OBJ           0.0
    z_1_6_4_3         DAY_1_6_4       1.0
    z_1_6_4_3         REQ_1_6         1.0
    z_1_6_4_3         OCC_6_4_3       -1.0
    z_1_6_4_3         CLS_1_4_3       -1.0
    z_1_6_4_4         OBJ           0.0
    z_1_6_4_4         DAY_1_6_4       1.0
    z_1_6_4_4         REQ_1_6         1.0
    z_1_6_4_4         OCC_6_4_4       -1.0
    z_1_6_4_4         CLS_1_4_4       -1.0
    z_1_6_4_5         OBJ           0.0
    z_1_6_4_5         DAY_1_6_4       1.0
    z_1_6_4_5         REQ_1_6         1.0
    z_1_6_4_5         OCC_6_4_5       -1.0
    z_1_6_4_5         CLS_1_4_5       -1.0
    z_1_6_4_6         OBJ           0.0
    z_1_6_4_6         DAY_1_6_4       1.0
    z_1_6_4_6         REQ_1_6         2.0
    z_1_6_4_6         OCC_6_4_0       -1.0
    z_1_6_4_6         OCC_6_4_1       -1.0
    z_1_6_4_6         CLS_1_4_0       -1.0
    z_1_6_4_6         CLS_1_4_1       -1.0
    z_1_6_4_7         OBJ           0.0
    z_1_6_4_7         DAY_1_6_4       1.0
    z_1_6_4_7         REQ_1_6         2.0
    z_1_6_4_7         OCC_6_4_1       -1.0
    z_1_6_4_7         OCC_6_4_2       -1.0
    z_1_6_4_7         CLS_1_4_1       -1.0
    z_1_6_4_7         CLS_1_4_2       -1.0
    z_1_6_4_8         OBJ           0.0
    z_1_6_4_8         DAY_1_6_4       1.0
    z_1_6_4_8         REQ_1_6         2.0
    z_1_6_4_8         OCC_6_4_2       -1.0
    z_1_6_4_8         OCC_6_4_3       -1.0
    z_1_6_4_8         CLS_1_4_2       -1.0
    z_1_6_4_8         CLS_1_4_3       -1.0
    z_1_6_4_9         OBJ           0.0
    z_1_6_4_9         DAY_1_6_4       1.0
    z_1_6_4_9         REQ_1_6         2.0
    z_1_6_4_9         OCC_6_4_3       -1.0
    z_1_6_4_9         OCC_6_4_4       -1.0
    z_1_6_4_9         CLS_1_4_3       -1.0
    z_1_6_4_9         CLS_1_4_4       -1.0
    z_1_6_4_10        OBJ           0.0
    z_1_6_4_10        DAY_1_6_4       1.0
    z_1_6_4_10        REQ_1_6         2.0
    z_1_6_4_10        OCC_6_4_4       -1.0
    z_1_6_4_10        OCC_6_4_5       -1.0
    z_1_6_4_10        CLS_1_4_4       -1.0
    z_1_6_4_10        CLS_1_4_5       -1.0
    z_1_7_0_0         OBJ           0.0
    z_1_7_0_0         DAY_1_7_0       1.0
    z_1_7_0_0         REQ_1_7         1.0
    z_1_7_0_0         OCC_7_0_0       -1.0
    z_1_7_0_0         CLS_1_0_0       -1.0
    z_1_7_0_1         OBJ           0.0
    z_1_7_0_1         DAY_1_7_0       1.0
    z_1_7_0_1         REQ_1_7         1.0
    z_1_7_0_1         OCC_7_0_1       -1.0
    z_1_7_0_1         CLS_1_0_1       -1.0
    z_1_7_0_2         OBJ           0.0
    z_1_7_0_2         DAY_1_7_0       1.0
    z_1_7_0_2         REQ_1_7         1.0
    z_1_7_0_2         OCC_7_0_2       -1.0
    z_1_7_0_2         CLS_1_0_2       -1.0
    z_1_7_0_3         OBJ           0.0
    z_1_7_0_3         DAY_1_7_0       1.0
    z_1_7_0_3         REQ_1_7         1.0
    z_1_7_0_3         OCC_7_0_3       -1.0
    z_1_7_0_3         CLS_1_0_3       -1.0
    z_1_7_0_4         OBJ           0.0
    z_1_7_0_4         DAY_1_7_0       1.0
    z_1_7_0_4         REQ_1_7         1.0
    z_1_7_0_4         OCC_7_0_5       -1.0
    z_1_7_0_4         CLS_1_0_5       -1.0
    z_1_7_0_5         OBJ           0.0
    z_1_7_0_5         DAY_1_7_0       1.0
    z_1_7_0_5         REQ_1_7         2.0
    z_1_7_0_5         OCC_7_0_0       -1.0
    z_1_7_0_5         OCC_7_0_1       -1.0
    z_1_7_0_5         CLS_1_0_0       -1.0
    z_1_7_0_5         CLS_1_0_1       -1.0
    z_1_7_0_6         OBJ           0.0
    z_1_7_0_6         DAY_1_7_0       1.0
    z_1_7_0_6         REQ_1_7         2.0
    z_1_7_0_6         OCC_7_0_1       -1.0
    z_1_7_0_6         OCC_7_0_2       -1.0
    z_1_7_0_6         CLS_1_0_1       -1.0
    z_1_7_0_6         CLS_1_0_2       -1.0
    z_1_7_0_7         OBJ           0.0
    z_1_7_0_7         DAY_1_7_0       1.0
    z_1_7_0_7         REQ_1_7         2.0
    z_1_7_0_7         OCC_7_0_2       -1.0
    z_1_7_0_7         OCC_7_0_3       -1.0
    z_1_7_0_7         CLS_1_0_2       -1.0
    z_1_7_0_7         CLS_1_0_3       -1.0
    z_1_7_1_0         OBJ           0.0
    z_1_7_1_0         DAY_1_7_1       1.0
    z_1_7_1_0         REQ_1_7         1.0
    z_1_7_1_0         OCC_7_1_0       -1.0
    z_1_7_1_0         CLS_1_1_0       -1.0
    z_1_7_1_1         OBJ           0.0
    z_1_7_1_1         DAY_1_7_1       1.0
    z_1_7_1_1         REQ_1_7         1.0
    z_1_7_1_1         OCC_7_1_1       -1.0
    z_1_7_1_1         CLS_1_1_1       -1.0
    z_1_7_1_2         OBJ           0.0
    z_1_7_1_2         DAY_1_7_1       1.0
    z_1_7_1_2         REQ_1_7         1.0
    z_1_7_1_2         OCC_7_1_2       -1.0
    z_1_7_1_2         CLS_1_1_2       -1.0
    z_1_7_1_3         OBJ           0.0
    z_1_7_1_3         DAY_1_7_1       1.0
    z_1_7_1_3         REQ_1_7         1.0
    z_1_7_1_3         OCC_7_1_3       -1.0
    z_1_7_1_3         CLS_1_1_3       -1.0
    z_1_7_1_4         OBJ           0.0
    z_1_7_1_4         DAY_1_7_1       1.0
    z_1_7_1_4         REQ_1_7         1.0
    z_1_7_1_4         OCC_7_1_4       -1.0
    z_1_7_1_4         CLS_1_1_4       -1.0
    z_1_7_1_5         OBJ           0.0
    z_1_7_1_5         DAY_1_7_1       1.0
    z_1_7_1_5         REQ_1_7         1.0
    z_1_7_1_5         OCC_7_1_5       -1.0
    z_1_7_1_5         CLS_1_1_5       -1.0
    z_1_7_1_6         OBJ           0.0
    z_1_7_1_6         DAY_1_7_1       1.0
    z_1_7_1_6         REQ_1_7         2.0
    z_1_7_1_6         OCC_7_1_0       -1.0
    z_1_7_1_6         OCC_7_1_1       -1.0
    z_1_7_1_6         CLS_1_1_0       -1.0
    z_1_7_1_6         CLS_1_1_1       -1.0
    z_1_7_1_7         OBJ           0.0
    z_1_7_1_7         DAY_1_7_1       1.0
    z_1_7_1_7         REQ_1_7         2.0
    z_1_7_1_7         OCC_7_1_1       -1.0
    z_1_7_1_7         OCC_7_1_2       -1.0
    z_1_7_1_7         CLS_1_1_1       -1.0
    z_1_7_1_7         CLS_1_1_2       -1.0
    z_1_7_1_8         OBJ           0.0
    z_1_7_1_8         DAY_1_7_1       1.0
    z_1_7_1_8         REQ_1_7         2.0
    z_1_7_1_8         OCC_7_1_2       -1.0
    z_1_7_1_8         OCC_7_1_3       -1.0
    z_1_7_1_8         CLS_1_1_2       -1.0
    z_1_7_1_8         CLS_1_1_3       -1.0
    z_1_7_1_9         OBJ           0.0
    z_1_7_1_9         DAY_1_7_1       1.0
    z_1_7_1_9         REQ_1_7         2.0
    z_1_7_1_9         OCC_7_1_3       -1.0
    z_1_7_1_9         OCC_7_1_4       -1.0
    z_1_7_1_9         CLS_1_1_3       -1.0
    z_1_7_1_9         CLS_1_1_4       -1.0
    z_1_7_1_10        OBJ           0.0
    z_1_7_1_10        DAY_1_7_1       1.0
    z_1_7_1_10        REQ_1_7         2.0
    z_1_7_1_10        OCC_7_1_4       -1.0
    z_1_7_1_10        OCC_7_1_5       -1.0
    z_1_7_1_10        CLS_1_1_4       -1.0
    z_1_7_1_10        CLS_1_1_5       -1.0
    z_1_7_2_0         OBJ           0.0
    z_1_7_2_0         DAY_1_7_2       1.0
    z_1_7_2_0         REQ_1_7         1.0
    z_1_7_2_0         OCC_7_2_0       -1.0
    z_1_7_2_0         CLS_1_2_0       -1.0
    z_1_7_2_1         OBJ           0.0
    z_1_7_2_1         DAY_1_7_2       1.0
    z_1_7_2_1         REQ_1_7         1.0
    z_1_7_2_1         OCC_7_2_1       -1.0
    z_1_7_2_1         CLS_1_2_1       -1.0
    z_1_7_2_2         OBJ           0.0
    z_1_7_2_2         DAY_1_7_2       1.0
    z_1_7_2_2         REQ_1_7         1.0
    z_1_7_2_2         OCC_7_2_2       -1.0
    z_1_7_2_2         CLS_1_2_2       -1.0
    z_1_7_2_3         OBJ           0.0
    z_1_7_2_3         DAY_1_7_2       1.0
    z_1_7_2_3         REQ_1_7         1.0
    z_1_7_2_3         OCC_7_2_3       -1.0
    z_1_7_2_3         CLS_1_2_3       -1.0
    z_1_7_2_4         OBJ           0.0
    z_1_7_2_4         DAY_1_7_2       1.0
    z_1_7_2_4         REQ_1_7         1.0
    z_1_7_2_4         OCC_7_2_4       -1.0
    z_1_7_2_4         CLS_1_2_4       -1.0
    z_1_7_2_5         OBJ           0.0
    z_1_7_2_5         DAY_1_7_2       1.0
    z_1_7_2_5         REQ_1_7         1.0
    z_1_7_2_5         OCC_7_2_5       -1.0
    z_1_7_2_5         CLS_1_2_5       -1.0
    z_1_7_2_6         OBJ           0.0
    z_1_7_2_6         DAY_1_7_2       1.0
    z_1_7_2_6         REQ_1_7         2.0
    z_1_7_2_6         OCC_7_2_0       -1.0
    z_1_7_2_6         OCC_7_2_1       -1.0
    z_1_7_2_6         CLS_1_2_0       -1.0
    z_1_7_2_6         CLS_1_2_1       -1.0
    z_1_7_2_7         OBJ           0.0
    z_1_7_2_7         DAY_1_7_2       1.0
    z_1_7_2_7         REQ_1_7         2.0
    z_1_7_2_7         OCC_7_2_1       -1.0
    z_1_7_2_7         OCC_7_2_2       -1.0
    z_1_7_2_7         CLS_1_2_1       -1.0
    z_1_7_2_7         CLS_1_2_2       -1.0
    z_1_7_2_8         OBJ           0.0
    z_1_7_2_8         DAY_1_7_2       1.0
    z_1_7_2_8         REQ_1_7         2.0
    z_1_7_2_8         OCC_7_2_2       -1.0
    z_1_7_2_8         OCC_7_2_3       -1.0
    z_1_7_2_8         CLS_1_2_2       -1.0
    z_1_7_2_8         CLS_1_2_3       -1.0
    z_1_7_2_9         OBJ           0.0
    z_1_7_2_9         DAY_1_7_2       1.0
    z_1_7_2_9         REQ_1_7         2.0
    z_1_7_2_9         OCC_7_2_3       -1.0
    z_1_7_2_9         OCC_7_2_4       -1.0
    z_1_7_2_9         CLS_1_2_3       -1.0
    z_1_7_2_9         CLS_1_2_4       -1.0
    z_1_7_2_10        OBJ           0.0
    z_1_7_2_10        DAY_1_7_2       1.0
    z_1_7_2_10        REQ_1_7         2.0
    z_1_7_2_10        OCC_7_2_4       -1.0
    z_1_7_2_10        OCC_7_2_5       -1.0
    z_1_7_2_10        CLS_1_2_4       -1.0
    z_1_7_2_10        CLS_1_2_5       -1.0
    z_1_7_3_0         OBJ           0.0
    z_1_7_3_0         DAY_1_7_3       1.0
    z_1_7_3_0         REQ_1_7         1.0
    z_1_7_3_0         OCC_7_3_0       -1.0
    z_1_7_3_0         CLS_1_3_0       -1.0
    z_1_7_3_1         OBJ           0.0
    z_1_7_3_1         DAY_1_7_3       1.0
    z_1_7_3_1         REQ_1_7         1.0
    z_1_7_3_1         OCC_7_3_1       -1.0
    z_1_7_3_1         CLS_1_3_1       -1.0
    z_1_7_3_2         OBJ           0.0
    z_1_7_3_2         DAY_1_7_3       1.0
    z_1_7_3_2         REQ_1_7         1.0
    z_1_7_3_2         OCC_7_3_2       -1.0
    z_1_7_3_2         CLS_1_3_2       -1.0
    z_1_7_3_3         OBJ           0.0
    z_1_7_3_3         DAY_1_7_3       1.0
    z_1_7_3_3         REQ_1_7         1.0
    z_1_7_3_3         OCC_7_3_3       -1.0
    z_1_7_3_3         CLS_1_3_3       -1.0
    z_1_7_3_4         OBJ           0.0
    z_1_7_3_4         DAY_1_7_3       1.0
    z_1_7_3_4         REQ_1_7         1.0
    z_1_7_3_4         OCC_7_3_4       -1.0
    z_1_7_3_4         CLS_1_3_4       -1.0
    z_1_7_3_5         OBJ           0.0
    z_1_7_3_5         DAY_1_7_3       1.0
    z_1_7_3_5         REQ_1_7         1.0
    z_1_7_3_5         OCC_7_3_5       -1.0
    z_1_7_3_5         CLS_1_3_5       -1.0
    z_1_7_3_6         OBJ           0.0
    z_1_7_3_6         DAY_1_7_3       1.0
    z_1_7_3_6         REQ_1_7         2.0
    z_1_7_3_6         OCC_7_3_0       -1.0
    z_1_7_3_6         OCC_7_3_1       -1.0
    z_1_7_3_6         CLS_1_3_0       -1.0
    z_1_7_3_6         CLS_1_3_1       -1.0
    z_1_7_3_7         OBJ           0.0
    z_1_7_3_7         DAY_1_7_3       1.0
    z_1_7_3_7         REQ_1_7         2.0
    z_1_7_3_7         OCC_7_3_1       -1.0
    z_1_7_3_7         OCC_7_3_2       -1.0
    z_1_7_3_7         CLS_1_3_1       -1.0
    z_1_7_3_7         CLS_1_3_2       -1.0
    z_1_7_3_8         OBJ           0.0
    z_1_7_3_8         DAY_1_7_3       1.0
    z_1_7_3_8         REQ_1_7         2.0
    z_1_7_3_8         OCC_7_3_2       -1.0
    z_1_7_3_8         OCC_7_3_3       -1.0
    z_1_7_3_8         CLS_1_3_2       -1.0
    z_1_7_3_8         CLS_1_3_3       -1.0
    z_1_7_3_9         OBJ           0.0
    z_1_7_3_9         DAY_1_7_3       1.0
    z_1_7_3_9         REQ_1_7         2.0
    z_1_7_3_9         OCC_7_3_3       -1.0
    z_1_7_3_9         OCC_7_3_4       -1.0
    z_1_7_3_9         CLS_1_3_3       -1.0
    z_1_7_3_9         CLS_1_3_4       -1.0
    z_1_7_3_10        OBJ           0.0
    z_1_7_3_10        DAY_1_7_3       1.0
    z_1_7_3_10        REQ_1_7         2.0
    z_1_7_3_10        OCC_7_3_4       -1.0
    z_1_7_3_10        OCC_7_3_5       -1.0
    z_1_7_3_10        CLS_1_3_4       -1.0
    z_1_7_3_10        CLS_1_3_5       -1.0
    z_1_7_4_0         OBJ           0.0
    z_1_7_4_0         DAY_1_7_4       1.0
    z_1_7_4_0         REQ_1_7         1.0
    z_1_7_4_0         OCC_7_4_0       -1.0
    z_1_7_4_0         CLS_1_4_0       -1.0
    z_1_7_4_1         OBJ           0.0
    z_1_7_4_1         DAY_1_7_4       1.0
    z_1_7_4_1         REQ_1_7         1.0
    z_1_7_4_1         OCC_7_4_1       -1.0
    z_1_7_4_1         CLS_1_4_1       -1.0
    z_1_7_4_2         OBJ           0.0
    z_1_7_4_2         DAY_1_7_4       1.0
    z_1_7_4_2         REQ_1_7         1.0
    z_1_7_4_2         OCC_7_4_2       -1.0
    z_1_7_4_2         CLS_1_4_2       -1.0
    z_1_7_4_3         OBJ           0.0
    z_1_7_4_3         DAY_1_7_4       1.0
    z_1_7_4_3         REQ_1_7         1.0
    z_1_7_4_3         OCC_7_4_3       -1.0
    z_1_7_4_3         CLS_1_4_3       -1.0
    z_1_7_4_4         OBJ           0.0
    z_1_7_4_4         DAY_1_7_4       1.0
    z_1_7_4_4         REQ_1_7         1.0
    z_1_7_4_4         OCC_7_4_4       -1.0
    z_1_7_4_4         CLS_1_4_4       -1.0
    z_1_7_4_5         OBJ           0.0
    z_1_7_4_5         DAY_1_7_4       1.0
    z_1_7_4_5         REQ_1_7         1.0
    z_1_7_4_5         OCC_7_4_5       -1.0
    z_1_7_4_5         CLS_1_4_5       -1.0
    z_1_7_4_6         OBJ           0.0
    z_1_7_4_6         DAY_1_7_4       1.0
    z_1_7_4_6         REQ_1_7         2.0
    z_1_7_4_6         OCC_7_4_0       -1.0
    z_1_7_4_6         OCC_7_4_1       -1.0
    z_1_7_4_6         CLS_1_4_0       -1.0
    z_1_7_4_6         CLS_1_4_1       -1.0
    z_1_7_4_7         OBJ           0.0
    z_1_7_4_7         DAY_1_7_4       1.0
    z_1_7_4_7         REQ_1_7         2.0
    z_1_7_4_7         OCC_7_4_1       -1.0
    z_1_7_4_7         OCC_7_4_2       -1.0
    z_1_7_4_7         CLS_1_4_1       -1.0
    z_1_7_4_7         CLS_1_4_2       -1.0
    z_1_7_4_8         OBJ           0.0
    z_1_7_4_8         DAY_1_7_4       1.0
    z_1_7_4_8         REQ_1_7         2.0
    z_1_7_4_8         OCC_7_4_2       -1.0
    z_1_7_4_8         OCC_7_4_3       -1.0
    z_1_7_4_8         CLS_1_4_2       -1.0
    z_1_7_4_8         CLS_1_4_3       -1.0
    z_1_7_4_9         OBJ           0.0
    z_1_7_4_9         DAY_1_7_4       1.0
    z_1_7_4_9         REQ_1_7         2.0
    z_1_7_4_9         OCC_7_4_3       -1.0
    z_1_7_4_9         OCC_7_4_4       -1.0
    z_1_7_4_9         CLS_1_4_3       -1.0
    z_1_7_4_9         CLS_1_4_4       -1.0
    z_1_7_4_10        OBJ           0.0
    z_1_7_4_10        DAY_1_7_4       1.0
    z_1_7_4_10        REQ_1_7         2.0
    z_1_7_4_10        OCC_7_4_4       -1.0
    z_1_7_4_10        OCC_7_4_5       -1.0
    z_1_7_4_10        CLS_1_4_4       -1.0
    z_1_7_4_10        CLS_1_4_5       -1.0
    z_2_0_0_0         OBJ           0.0
    z_2_0_0_0         DAY_2_0_0       1.0
    z_2_0_0_0         REQ_2_0         1.0
    z_2_0_0_0         OCC_0_0_0       -1.0
    z_2_0_0_0         CLS_2_0_0       -1.0
    z_2_0_0_1         OBJ           0.0
    z_2_0_0_1         DAY_2_0_0       1.0
    z_2_0_0_1         REQ_2_0         1.0
    z_2_0_0_1         OCC_0_0_1       -1.0
    z_2_0_0_1         CLS_2_0_1       -1.0
    z_2_0_0_2         OBJ           0.0
    z_2_0_0_2         DAY_2_0_0       1.0
    z_2_0_0_2         REQ_2_0         1.0
    z_2_0_0_2         OCC_0_0_2       -1.0
    z_2_0_0_2         CLS_2_0_2       -1.0
    z_2_0_0_3         OBJ           0.0
    z_2_0_0_3         DAY_2_0_0       1.0
    z_2_0_0_3         REQ_2_0         1.0
    z_2_0_0_3         OCC_0_0_3       -1.0
    z_2_0_0_3         CLS_2_0_3       -1.0
    z_2_0_0_4         OBJ           0.0
    z_2_0_0_4         DAY_2_0_0       1.0
    z_2_0_0_4         REQ_2_0         1.0
    z_2_0_0_4         OCC_0_0_4       -1.0
    z_2_0_0_4         CLS_2_0_4       -1.0
    z_2_0_0_5         OBJ           0.0
    z_2_0_0_5         DAY_2_0_0       1.0
    z_2_0_0_5         REQ_2_0         1.0
    z_2_0_0_5         OCC_0_0_5       -1.0
    z_2_0_0_5         CLS_2_0_5       -1.0
    z_2_0_0_6         OBJ           0.0
    z_2_0_0_6         DAY_2_0_0       1.0
    z_2_0_0_6         REQ_2_0         2.0
    z_2_0_0_6         OCC_0_0_0       -1.0
    z_2_0_0_6         OCC_0_0_1       -1.0
    z_2_0_0_6         CLS_2_0_0       -1.0
    z_2_0_0_6         CLS_2_0_1       -1.0
    z_2_0_0_7         OBJ           0.0
    z_2_0_0_7         DAY_2_0_0       1.0
    z_2_0_0_7         REQ_2_0         2.0
    z_2_0_0_7         OCC_0_0_1       -1.0
    z_2_0_0_7         OCC_0_0_2       -1.0
    z_2_0_0_7         CLS_2_0_1       -1.0
    z_2_0_0_7         CLS_2_0_2       -1.0
    z_2_0_0_8         OBJ           0.0
    z_2_0_0_8         DAY_2_0_0       1.0
    z_2_0_0_8         REQ_2_0         2.0
    z_2_0_0_8         OCC_0_0_2       -1.0
    z_2_0_0_8         OCC_0_0_3       -1.0
    z_2_0_0_8         CLS_2_0_2       -1.0
    z_2_0_0_8         CLS_2_0_3       -1.0
    z_2_0_0_9         OBJ           0.0
    z_2_0_0_9         DAY_2_0_0       1.0
    z_2_0_0_9         REQ_2_0         2.0
    z_2_0_0_9         OCC_0_0_3       -1.0
    z_2_0_0_9         OCC_0_0_4       -1.0
    z_2_0_0_9         CLS_2_0_3       -1.0
    z_2_0_0_9         CLS_2_0_4       -1.0
    z_2_0_0_10        OBJ           0.0
    z_2_0_0_10        DAY_2_0_0       1.0
    z_2_0_0_10        REQ_2_0         2.0
    z_2_0_0_10        OCC_0_0_4       -1.0
    z_2_0_0_10        OCC_0_0_5       -1.0
    z_2_0_0_10        CLS_2_0_4       -1.0
    z_2_0_0_10        CLS_2_0_5       -1.0
    z_2_0_1_0         OBJ           0.0
    z_2_0_1_0         DAY_2_0_1       1.0
    z_2_0_1_0         REQ_2_0         1.0
    z_2_0_1_0         OCC_0_1_0       -1.0
    z_2_0_1_0         CLS_2_1_0       -1.0
    z_2_0_1_1         OBJ           0.0
    z_2_0_1_1         DAY_2_0_1       1.0
    z_2_0_1_1         REQ_2_0         1.0
    z_2_0_1_1         OCC_0_1_1       -1.0
    z_2_0_1_1         CLS_2_1_1       -1.0
    z_2_0_1_2         OBJ           0.0
    z_2_0_1_2         DAY_2_0_1       1.0
    z_2_0_1_2         REQ_2_0         1.0
    z_2_0_1_2         OCC_0_1_2       -1.0
    z_2_0_1_2         CLS_2_1_2       -1.0
    z_2_0_1_3         OBJ           0.0
    z_2_0_1_3         DAY_2_0_1       1.0
    z_2_0_1_3         REQ_2_0         1.0
    z_2_0_1_3         OCC_0_1_3       -1.0
    z_2_0_1_3         CLS_2_1_3       -1.0
    z_2_0_1_4         OBJ           0.0
    z_2_0_1_4         DAY_2_0_1       1.0
    z_2_0_1_4         REQ_2_0         1.0
    z_2_0_1_4         OCC_0_1_4       -1.0
    z_2_0_1_4         CLS_2_1_4       -1.0
    z_2_0_1_5         OBJ           0.0
    z_2_0_1_5         DAY_2_0_1       1.0
    z_2_0_1_5         REQ_2_0         1.0
    z_2_0_1_5         OCC_0_1_5       -1.0
    z_2_0_1_5         CLS_2_1_5       -1.0
    z_2_0_1_6         OBJ           0.0
    z_2_0_1_6         DAY_2_0_1       1.0
    z_2_0_1_6         REQ_2_0         2.0
    z_2_0_1_6         OCC_0_1_0       -1.0
    z_2_0_1_6         OCC_0_1_1       -1.0
    z_2_0_1_6         CLS_2_1_0       -1.0
    z_2_0_1_6         CLS_2_1_1       -1.0
    z_2_0_1_7         OBJ           0.0
    z_2_0_1_7         DAY_2_0_1       1.0
    z_2_0_1_7         REQ_2_0         2.0
    z_2_0_1_7         OCC_0_1_1       -1.0
    z_2_0_1_7         OCC_0_1_2       -1.0
    z_2_0_1_7         CLS_2_1_1       -1.0
    z_2_0_1_7         CLS_2_1_2       -1.0
    z_2_0_1_8         OBJ           0.0
    z_2_0_1_8         DAY_2_0_1       1.0
    z_2_0_1_8         REQ_2_0         2.0
    z_2_0_1_8         OCC_0_1_2       -1.0
    z_2_0_1_8         OCC_0_1_3       -1.0
    z_2_0_1_8         CLS_2_1_2       -1.0
    z_2_0_1_8         CLS_2_1_3       -1.0
    z_2_0_1_9         OBJ           0.0
    z_2_0_1_9         DAY_2_0_1       1.0
    z_2_0_1_9         REQ_2_0         2.0
    z_2_0_1_9         OCC_0_1_3       -1.0
    z_2_0_1_9         OCC_0_1_4       -1.0
    z_2_0_1_9         CLS_2_1_3       -1.0
    z_2_0_1_9         CLS_2_1_4       -1.0
    z_2_0_1_10        OBJ           0.0
    z_2_0_1_10        DAY_2_0_1       1.0
    z_2_0_1_10        REQ_2_0         2.0
    z_2_0_1_10        OCC_0_1_4       -1.0
    z_2_0_1_10        OCC_0_1_5       -1.0
    z_2_0_1_10        CLS_2_1_4       -1.0
    z_2_0_1_10        CLS_2_1_5       -1.0
    z_2_0_2_0         OBJ           0.0
    z_2_0_2_0         DAY_2_0_2       1.0
    z_2_0_2_0         REQ_2_0         1.0
    z_2_0_2_0         OCC_0_2_0       -1.0
    z_2_0_2_0         CLS_2_2_0       -1.0
    z_2_0_2_1         OBJ           0.0
    z_2_0_2_1         DAY_2_0_2       1.0
    z_2_0_2_1         REQ_2_0         1.0
    z_2_0_2_1         OCC_0_2_1       -1.0
    z_2_0_2_1         CLS_2_2_1       -1.0
    z_2_0_2_2         OBJ           0.0
    z_2_0_2_2         DAY_2_0_2       1.0
    z_2_0_2_2         REQ_2_0         1.0
    z_2_0_2_2         OCC_0_2_2       -1.0
    z_2_0_2_2         CLS_2_2_2       -1.0
    z_2_0_2_3         OBJ           0.0
    z_2_0_2_3         DAY_2_0_2       1.0
    z_2_0_2_3         REQ_2_0         1.0
    z_2_0_2_3         OCC_0_2_3       -1.0
    z_2_0_2_3         CLS_2_2_3       -1.0
    z_2_0_2_4         OBJ           0.0
    z_2_0_2_4         DAY_2_0_2       1.0
    z_2_0_2_4         REQ_2_0         1.0
    z_2_0_2_4         OCC_0_2_4       -1.0
    z_2_0_2_4         CLS_2_2_4       -1.0
    z_2_0_2_5         OBJ           0.0
    z_2_0_2_5         DAY_2_0_2       1.0
    z_2_0_2_5         REQ_2_0         1.0
    z_2_0_2_5         OCC_0_2_5       -1.0
    z_2_0_2_5         CLS_2_2_5       -1.0
    z_2_0_2_6         OBJ           0.0
    z_2_0_2_6         DAY_2_0_2       1.0
    z_2_0_2_6         REQ_2_0         2.0
    z_2_0_2_6         OCC_0_2_0       -1.0
    z_2_0_2_6         OCC_0_2_1       -1.0
    z_2_0_2_6         CLS_2_2_0       -1.0
    z_2_0_2_6         CLS_2_2_1       -1.0
    z_2_0_2_7         OBJ           0.0
    z_2_0_2_7         DAY_2_0_2       1.0
    z_2_0_2_7         REQ_2_0         2.0
    z_2_0_2_7         OCC_0_2_1       -1.0
    z_2_0_2_7         OCC_0_2_2       -1.0
    z_2_0_2_7         CLS_2_2_1       -1.0
    z_2_0_2_7         CLS_2_2_2       -1.0
    z_2_0_2_8         OBJ           0.0
    z_2_0_2_8         DAY_2_0_2       1.0
    z_2_0_2_8         REQ_2_0         2.0
    z_2_0_2_8         OCC_0_2_2       -1.0
    z_2_0_2_8         OCC_0_2_3       -1.0
    z_2_0_2_8         CLS_2_2_2       -1.0
    z_2_0_2_8         CLS_2_2_3       -1.0
    z_2_0_2_9         OBJ           0.0
    z_2_0_2_9         DAY_2_0_2       1.0
    z_2_0_2_9         REQ_2_0         2.0
    z_2_0_2_9         OCC_0_2_3       -1.0
    z_2_0_2_9         OCC_0_2_4       -1.0
    z_2_0_2_9         CLS_2_2_3       -1.0
    z_2_0_2_9         CLS_2_2_4       -1.0
    z_2_0_2_10        OBJ           0.0
    z_2_0_2_10        DAY_2_0_2       1.0
    z_2_0_2_10        REQ_2_0         2.0
    z_2_0_2_10        OCC_0_2_4       -1.0
    z_2_0_2_10        OCC_0_2_5       -1.0
    z_2_0_2_10        CLS_2_2_4       -1.0
    z_2_0_2_10        CLS_2_2_5       -1.0
    z_2_0_3_0         OBJ           0.0
    z_2_0_3_0         DAY_2_0_3       1.0
    z_2_0_3_0         REQ_2_0         1.0
    z_2_0_3_0         OCC_0_3_0       -1.0
    z_2_0_3_0         CLS_2_3_0       -1.0
    z_2_0_3_1         OBJ           0.0
    z_2_0_3_1         DAY_2_0_3       1.0
    z_2_0_3_1         REQ_2_0         1.0
    z_2_0_3_1         OCC_0_3_1       -1.0
    z_2_0_3_1         CLS_2_3_1       -1.0
    z_2_0_3_2         OBJ           0.0
    z_2_0_3_2         DAY_2_0_3       1.0
    z_2_0_3_2         REQ_2_0         1.0
    z_2_0_3_2         OCC_0_3_2       -1.0
    z_2_0_3_2         CLS_2_3_2       -1.0
    z_2_0_3_3         OBJ           0.0
    z_2_0_3_3         DAY_2_0_3       1.0
    z_2_0_3_3         REQ_2_0         1.0
    z_2_0_3_3         OCC_0_3_3       -1.0
    z_2_0_3_3         CLS_2_3_3       -1.0
    z_2_0_3_4         OBJ           0.0
    z_2_0_3_4         DAY_2_0_3       1.0
    z_2_0_3_4         REQ_2_0         1.0
    z_2_0_3_4         OCC_0_3_5       -1.0
    z_2_0_3_4         CLS_2_3_5       -1.0
    z_2_0_3_5         OBJ           0.0
    z_2_0_3_5         DAY_2_0_3       1.0
    z_2_0_3_5         REQ_2_0         2.0
    z_2_0_3_5         OCC_0_3_0       -1.0
    z_2_0_3_5         OCC_0_3_1       -1.0
    z_2_0_3_5         CLS_2_3_0       -1.0
    z_2_0_3_5         CLS_2_3_1       -1.0
    z_2_0_3_6         OBJ           0.0
    z_2_0_3_6         DAY_2_0_3       1.0
    z_2_0_3_6         REQ_2_0         2.0
    z_2_0_3_6         OCC_0_3_1       -1.0
    z_2_0_3_6         OCC_0_3_2       -1.0
    z_2_0_3_6         CLS_2_3_1       -1.0
    z_2_0_3_6         CLS_2_3_2       -1.0
    z_2_0_3_7         OBJ           0.0
    z_2_0_3_7         DAY_2_0_3       1.0
    z_2_0_3_7         REQ_2_0         2.0
    z_2_0_3_7         OCC_0_3_2       -1.0
    z_2_0_3_7         OCC_0_3_3       -1.0
    z_2_0_3_7         CLS_2_3_2       -1.0
    z_2_0_3_7         CLS_2_3_3       -1.0
    z_2_0_4_0         OBJ           0.0
    z_2_0_4_0         DAY_2_0_4       1.0
    z_2_0_4_0         REQ_2_0         1.0
    z_2_0_4_0         OCC_0_4_0       -1.0
    z_2_0_4_0         CLS_2_4_0       -1.0
    z_2_0_4_1         OBJ           0.0
    z_2_0_4_1         DAY_2_0_4       1.0
    z_2_0_4_1         REQ_2_0         1.0
    z_2_0_4_1         OCC_0_4_1       -1.0
    z_2_0_4_1         CLS_2_4_1       -1.0
    z_2_0_4_2         OBJ           0.0
    z_2_0_4_2         DAY_2_0_4       1.0
    z_2_0_4_2         REQ_2_0         1.0
    z_2_0_4_2         OCC_0_4_2       -1.0
    z_2_0_4_2         CLS_2_4_2       -1.0
    z_2_0_4_3         OBJ           0.0
    z_2_0_4_3         DAY_2_0_4       1.0
    z_2_0_4_3         REQ_2_0         1.0
    z_2_0_4_3         OCC_0_4_3       -1.0
    z_2_0_4_3         CLS_2_4_3       -1.0
    z_2_0_4_4         OBJ           0.0
    z_2_0_4_4         DAY_2_0_4       1.0
    z_2_0_4_4         REQ_2_0         1.0
    z_2_0_4_4         OCC_0_4_4       -1.0
    z_2_0_4_4         CLS_2_4_4       -1.0
    z_2_0_4_5         OBJ           0.0
    z_2_0_4_5         DAY_2_0_4       1.0
    z_2_0_4_5         REQ_2_0         1.0
    z_2_0_4_5         OCC_0_4_5       -1.0
    z_2_0_4_5         CLS_2_4_5       -1.0
    z_2_0_4_6         OBJ           0.0
    z_2_0_4_6         DAY_2_0_4       1.0
    z_2_0_4_6         REQ_2_0         2.0
    z_2_0_4_6         OCC_0_4_0       -1.0
    z_2_0_4_6         OCC_0_4_1       -1.0
    z_2_0_4_6         CLS_2_4_0       -1.0
    z_2_0_4_6         CLS_2_4_1       -1.0
    z_2_0_4_7         OBJ           0.0
    z_2_0_4_7         DAY_2_0_4       1.0
    z_2_0_4_7         REQ_2_0         2.0
    z_2_0_4_7         OCC_0_4_1       -1.0
    z_2_0_4_7         OCC_0_4_2       -1.0
    z_2_0_4_7         CLS_2_4_1       -1.0
    z_2_0_4_7         CLS_2_4_2       -1.0
    z_2_0_4_8         OBJ           0.0
    z_2_0_4_8         DAY_2_0_4       1.0
    z_2_0_4_8         REQ_2_0         2.0
    z_2_0_4_8         OCC_0_4_2       -1.0
    z_2_0_4_8         OCC_0_4_3       -1.0
    z_2_0_4_8         CLS_2_4_2       -1.0
    z_2_0_4_8         CLS_2_4_3       -1.0
    z_2_0_4_9         OBJ           0.0
    z_2_0_4_9         DAY_2_0_4       1.0
    z_2_0_4_9         REQ_2_0         2.0
    z_2_0_4_9         OCC_0_4_3       -1.0
    z_2_0_4_9         OCC_0_4_4       -1.0
    z_2_0_4_9         CLS_2_4_3       -1.0
    z_2_0_4_9         CLS_2_4_4       -1.0
    z_2_0_4_10        OBJ           0.0
    z_2_0_4_10        DAY_2_0_4       1.0
    z_2_0_4_10        REQ_2_0         2.0
    z_2_0_4_10        OCC_0_4_4       -1.0
    z_2_0_4_10        OCC_0_4_5       -1.0
    z_2_0_4_10        CLS_2_4_4       -1.0
    z_2_0_4_10        CLS_2_4_5       -1.0
    z_2_2_0_0         OBJ           0.0
    z_2_2_0_0         DAY_2_2_0       1.0
    z_2_2_0_0         REQ_2_2         1.0
    z_2_2_0_0         OCC_2_0_0       -1.0
    z_2_2_0_0         CLS_2_0_0       -1.0
    z_2_2_0_1         OBJ           0.0
    z_2_2_0_1         DAY_2_2_0       1.0
    z_2_2_0_1         REQ_2_2         1.0
    z_2_2_0_1         OCC_2_0_1       -1.0
    z_2_2_0_1         CLS_2_0_1       -1.0
    z_2_2_0_2         OBJ           0.0
    z_2_2_0_2         DAY_2_2_0       1.0
    z_2_2_0_2         REQ_2_2         1.0
    z_2_2_0_2         OCC_2_0_2       -1.0
    z_2_2_0_2         CLS_2_0_2       -1.0
    z_2_2_0_3         OBJ           0.0
    z_2_2_0_3         DAY_2_2_0       1.0
    z_2_2_0_3         REQ_2_2         1.0
    z_2_2_0_3         OCC_2_0_3       -1.0
    z_2_2_0_3         CLS_2_0_3       -1.0
    z_2_2_0_4         OBJ           0.0
    z_2_2_0_4         DAY_2_2_0       1.0
    z_2_2_0_4         REQ_2_2         1.0
    z_2_2_0_4         OCC_2_0_4       -1.0
    z_2_2_0_4         CLS_2_0_4       -1.0
    z_2_2_0_5         OBJ           0.0
    z_2_2_0_5         DAY_2_2_0       1.0
    z_2_2_0_5         REQ_2_2         2.0
    z_2_2_0_5         OCC_2_0_0       -1.0
    z_2_2_0_5         OCC_2_0_1       -1.0
    z_2_2_0_5         CLS_2_0_0       -1.0
    z_2_2_0_5         CLS_2_0_1       -1.0
    z_2_2_0_6         OBJ           0.0
    z_2_2_0_6         DAY_2_2_0       1.0
    z_2_2_0_6         REQ_2_2         2.0
    z_2_2_0_6         OCC_2_0_1       -1.0
    z_2_2_0_6         OCC_2_0_2       -1.0
    z_2_2_0_6         CLS_2_0_1       -1.0
    z_2_2_0_6         CLS_2_0_2       -1.0
    z_2_2_0_7         OBJ           0.0
    z_2_2_0_7         DAY_2_2_0       1.0
    z_2_2_0_7         REQ_2_2         2.0
    z_2_2_0_7         OCC_2_0_2       -1.0
    z_2_2_0_7         OCC_2_0_3       -1.0
    z_2_2_0_7         CLS_2_0_2       -1.0
    z_2_2_0_7         CLS_2_0_3       -1.0
    z_2_2_0_8         OBJ           0.0
    z_2_2_0_8         DAY_2_2_0       1.0
    z_2_2_0_8         REQ_2_2         2.0
    z_2_2_0_8         OCC_2_0_3       -1.0
    z_2_2_0_8         OCC_2_0_4       -1.0
    z_2_2_0_8         CLS_2_0_3       -1.0
    z_2_2_0_8         CLS_2_0_4       -1.0
    z_2_2_1_0         OBJ           0.0
    z_2_2_1_0         DAY_2_2_1       1.0
    z_2_2_1_0         REQ_2_2         1.0
    z_2_2_1_0         OCC_2_1_0       -1.0
    z_2_2_1_0         CLS_2_1_0       -1.0
    z_2_2_1_1         OBJ           0.0
    z_2_2_1_1         DAY_2_2_1       1.0
    z_2_2_1_1         REQ_2_2         1.0
    z_2_2_1_1         OCC_2_1_1       -1.0
    z_2_2_1_1         CLS_2_1_1       -1.0
    z_2_2_1_2         OBJ           0.0
    z_2_2_1_2         DAY_2_2_1       1.0
    z_2_2_1_2         REQ_2_2         1.0
    z_2_2_1_2         OCC_2_1_2       -1.0
    z_2_2_1_2         CLS_2_1_2       -1.0
    z_2_2_1_3         OBJ           0.0
    z_2_2_1_3         DAY_2_2_1       1.0
    z_2_2_1_3         REQ_2_2         1.0
    z_2_2_1_3         OCC_2_1_3       -1.0
    z_2_2_1_3         CLS_2_1_3       -1.0
    z_2_2_1_4         OBJ           0.0
    z_2_2_1_4         DAY_2_2_1       1.0
    z_2_2_1_4         REQ_2_2         1.0
    z_2_2_1_4         OCC_2_1_4       -1.0
    z_2_2_1_4         CLS_2_1_4       -1.0
    z_2_2_1_5         OBJ           0.0
    z_2_2_1_5         DAY_2_2_1       1.0
    z_2_2_1_5         REQ_2_2         1.0
    z_2_2_1_5         OCC_2_1_5       -1.0
    z_2_2_1_5         CLS_2_1_5       -1.0
    z_2_2_1_6         OBJ           0.0
    z_2_2_1_6         DAY_2_2_1       1.0
    z_2_2_1_6         REQ_2_2         2.0
    z_2_2_1_6         OCC_2_1_0       -1.0
    z_2_2_1_6         OCC_2_1_1       -1.0
    z_2_2_1_6         CLS_2_1_0       -1.0
    z_2_2_1_6         CLS_2_1_1       -1.0
    z_2_2_1_7         OBJ           0.0
    z_2_2_1_7         DAY_2_2_1       1.0
    z_2_2_1_7         REQ_2_2         2.0
    z_2_2_1_7         OCC_2_1_1       -1.0
    z_2_2_1_7         OCC_2_1_2       -1.0
    z_2_2_1_7         CLS_2_1_1       -1.0
    z_2_2_1_7         CLS_2_1_2       -1.0
    z_2_2_1_8         OBJ           0.0
    z_2_2_1_8         DAY_2_2_1       1.0
    z_2_2_1_8         REQ_2_2         2.0
    z_2_2_1_8         OCC_2_1_2       -1.0
    z_2_2_1_8         OCC_2_1_3       -1.0
    z_2_2_1_8         CLS_2_1_2       -1.0
    z_2_2_1_8         CLS_2_1_3       -1.0
    z_2_2_1_9         OBJ           0.0
    z_2_2_1_9         DAY_2_2_1       1.0
    z_2_2_1_9         REQ_2_2         2.0
    z_2_2_1_9         OCC_2_1_3       -1.0
    z_2_2_1_9         OCC_2_1_4       -1.0
    z_2_2_1_9         CLS_2_1_3       -1.0
    z_2_2_1_9         CLS_2_1_4       -1.0
    z_2_2_1_10        OBJ           0.0
    z_2_2_1_10        DAY_2_2_1       1.0
    z_2_2_1_10        REQ_2_2         2.0
    z_2_2_1_10        OCC_2_1_4       -1.0
    z_2_2_1_10        OCC_2_1_5       -1.0
    z_2_2_1_10        CLS_2_1_4       -1.0
    z_2_2_1_10        CLS_2_1_5       -1.0
    z_2_2_2_0         OBJ           0.0
    z_2_2_2_0         DAY_2_2_2       1.0
    z_2_2_2_0         REQ_2_2         1.0
    z_2_2_2_0         OCC_2_2_0       -1.0
    z_2_2_2_0         CLS_2_2_0       -1.0
    z_2_2_2_1         OBJ           0.0
    z_2_2_2_1         DAY_2_2_2       1.0
    z_2_2_2_1         REQ_2_2         1.0
    z_2_2_2_1         OCC_2_2_1       -1.0
    z_2_2_2_1         CLS_2_2_1       -1.0
    z_2_2_2_2         OBJ           0.0
    z_2_2_2_2         DAY_2_2_2       1.0
    z_2_2_2_2         REQ_2_2         1.0
    z_2_2_2_2         OCC_2_2_2       -1.0
    z_2_2_2_2         CLS_2_2_2       -1.0
    z_2_2_2_3         OBJ           0.0
    z_2_2_2_3         DAY_2_2_2       1.0
    z_2_2_2_3         REQ_2_2         1.0
    z_2_2_2_3         OCC_2_2_3       -1.0
    z_2_2_2_3         CLS_2_2_3       -1.0
    z_2_2_2_4         OBJ           0.0
    z_2_2_2_4         DAY_2_2_2       1.0
    z_2_2_2_4         REQ_2_2         1.0
    z_2_2_2_4         OCC_2_2_4       -1.0
    z_2_2_2_4         CLS_2_2_4       -1.0
    z_2_2_2_5         OBJ           0.0
    z_2_2_2_5         DAY_2_2_2       1.0
    z_2_2_2_5         REQ_2_2         2.0
    z_2_2_2_5         OCC_2_2_0       -1.0
    z_2_2_2_5         OCC_2_2_1       -1.0
    z_2_2_2_5         CLS_2_2_0       -1.0
    z_2_2_2_5         CLS_2_2_1       -1.0
    z_2_2_2_6         OBJ           0.0
    z_2_2_2_6         DAY_2_2_2       1.0
    z_2_2_2_6         REQ_2_2         2.0
    z_2_2_2_6         OCC_2_2_1       -1.0
    z_2_2_2_6         OCC_2_2_2       -1.0
    z_2_2_2_6         CLS_2_2_1       -1.0
    z_2_2_2_6         CLS_2_2_2       -1.0
    z_2_2_2_7         OBJ           0.0
    z_2_2_2_7         DAY_2_2_2       1.0
    z_2_2_2_7         REQ_2_2         2.0
    z_2_2_2_7         OCC_2_2_2       -1.0
    z_2_2_2_7         OCC_2_2_3       -1.0
    z_2_2_2_7         CLS_2_2_2       -1.0
    z_2_2_2_7         CLS_2_2_3       -1.0
    z_2_2_2_8         OBJ           0.0
    z_2_2_2_8         DAY_2_2_2       1.0
    z_2_2_2_8         REQ_2_2         2.0
    z_2_2_2_8         OCC_2_2_3       -1.0
    z_2_2_2_8         OCC_2_2_4       -1.0
    z_2_2_2_8         CLS_2_2_3       -1.0
    z_2_2_2_8         CLS_2_2_4       -1.0
    z_2_2_3_0         OBJ           0.0
    z_2_2_3_0         DAY_2_2_3       1.0
    z_2_2_3_0         REQ_2_2         1.0
    z_2_2_3_0         OCC_2_3_0       -1.0
    z_2_2_3_0         CLS_2_3_0       -1.0
    z_2_2_3_1         OBJ           0.0
    z_2_2_3_1         DAY_2_2_3       1.0
    z_2_2_3_1         REQ_2_2         1.0
    z_2_2_3_1         OCC_2_3_1       -1.0
    z_2_2_3_1         CLS_2_3_1       -1.0
    z_2_2_3_2         OBJ           0.0
    z_2_2_3_2         DAY_2_2_3       1.0
    z_2_2_3_2         REQ_2_2         1.0
    z_2_2_3_2         OCC_2_3_2       -1.0
    z_2_2_3_2         CLS_2_3_2       -1.0
    z_2_2_3_3         OBJ           0.0
    z_2_2_3_3         DAY_2_2_3       1.0
    z_2_2_3_3         REQ_2_2         1.0
    z_2_2_3_3         OCC_2_3_3       -1.0
    z_2_2_3_3         CLS_2_3_3       -1.0
    z_2_2_3_4         OBJ           0.0
    z_2_2_3_4         DAY_2_2_3       1.0
    z_2_2_3_4         REQ_2_2         1.0
    z_2_2_3_4         OCC_2_3_4       -1.0
    z_2_2_3_4         CLS_2_3_4       -1.0
    z_2_2_3_5         OBJ           0.0
    z_2_2_3_5         DAY_2_2_3       1.0
    z_2_2_3_5         REQ_2_2         1.0
    z_2_2_3_5         OCC_2_3_5       -1.0
    z_2_2_3_5         CLS_2_3_5       -1.0
    z_2_2_3_6         OBJ           0.0
    z_2_2_3_6         DAY_2_2_3       1.0
    z_2_2_3_6         REQ_2_2         2.0
    z_2_2_3_6         OCC_2_3_0       -1.0
    z_2_2_3_6         OCC_2_3_1       -1.0
    z_2_2_3_6         CLS_2_3_0       -1.0
    z_2_2_3_6         CLS_2_3_1       -1.0
    z_2_2_3_7         OBJ           0.0
    z_2_2_3_7         DAY_2_2_3       1.0
    z_2_2_3_7         REQ_2_2         2.0
    z_2_2_3_7         OCC_2_3_1       -1.0
    z_2_2_3_7         OCC_2_3_2       -1.0
    z_2_2_3_7         CLS_2_3_1       -1.0
    z_2_2_3_7         CLS_2_3_2       -1.0
    z_2_2_3_8         OBJ           0.0
    z_2_2_3_8         DAY_2_2_3       1.0
    z_2_2_3_8         REQ_2_2         2.0
    z_2_2_3_8         OCC_2_3_2       -1.0
    z_2_2_3_8         OCC_2_3_3       -1.0
    z_2_2_3_8         CLS_2_3_2       -1.0
    z_2_2_3_8         CLS_2_3_3       -1.0
    z_2_2_3_9         OBJ           0.0
    z_2_2_3_9         DAY_2_2_3       1.0
    z_2_2_3_9         REQ_2_2         2.0
    z_2_2_3_9         OCC_2_3_3       -1.0
    z_2_2_3_9         OCC_2_3_4       -1.0
    z_2_2_3_9         CLS_2_3_3       -1.0
    z_2_2_3_9         CLS_2_3_4       -1.0
    z_2_2_3_10        OBJ           0.0
    z_2_2_3_10        DAY_2_2_3       1.0
    z_2_2_3_10        REQ_2_2         2.0
    z_2_2_3_10        OCC_2_3_4       -1.0
    z_2_2_3_10        OCC_2_3_5       -1.0
    z_2_2_3_10        CLS_2_3_4       -1.0
    z_2_2_3_10        CLS_2_3_5       -1.0
    z_2_2_4_0         OBJ           0.0
    z_2_2_4_0         DAY_2_2_4       1.0
    z_2_2_4_0         REQ_2_2         1.0
    z_2_2_4_0         OCC_2_4_0       -1.0
    z_2_2_4_0         CLS_2_4_0       -1.0
    z_2_2_4_1         OBJ           0.0
    z_2_2_4_1         DAY_2_2_4       1.0
    z_2_2_4_1         REQ_2_2         1.0
    z_2_2_4_1         OCC_2_4_2       -1.0
    z_2_2_4_1         CLS_2_4_2       -1.0
    z_2_2_4_2         OBJ           0.0
    z_2_2_4_2         DAY_2_2_4       1.0
    z_2_2_4_2         REQ_2_2         1.0
    z_2_2_4_2         OCC_2_4_3       -1.0
    z_2_2_4_2         CLS_2_4_3       -1.0
    z_2_2_4_3         OBJ           0.0
    z_2_2_4_3         DAY_2_2_4       1.0
    z_2_2_4_3         REQ_2_2         1.0
    z_2_2_4_3         OCC_2_4_5       -1.0
    z_2_2_4_3         CLS_2_4_5       -1.0
    z_2_2_4_4         OBJ           0.0
    z_2_2_4_4         DAY_2_2_4       1.0
    z_2_2_4_4         REQ_2_2         2.0
    z_2_2_4_4         OCC_2_4_2       -1.0
    z_2_2_4_4         OCC_2_4_3       -1.0
    z_2_2_4_4         CLS_2_4_2       -1.0
    z_2_2_4_4         CLS_2_4_3       -1.0
    z_2_3_0_0         OBJ           0.0
    z_2_3_0_0         DAY_2_3_0       1.0
    z_2_3_0_0         REQ_2_3         1.0
    z_2_3_0_0         OCC_3_0_0       -1.0
    z_2_3_0_0         CLS_2_0_0       -1.0
    z_2_3_0_1         OBJ           0.0
    z_2_3_0_1         DAY_2_3_0       1.0
    z_2_3_0_1         REQ_2_3         1.0
    z_2_3_0_1         OCC_3_0_2       -1.0
    z_2_3_0_1         CLS_2_0_2       -1.0
    z_2_3_0_2         OBJ           0.0
    z_2_3_0_2         DAY_2_3_0       1.0
    z_2_3_0_2         REQ_2_3         1.0
    z_2_3_0_2         OCC_3_0_3       -1.0
    z_2_3_0_2         CLS_2_0_3       -1.0
    z_2_3_0_3         OBJ           0.0
    z_2_3_0_3         DAY_2_3_0       1.0
    z_2_3_0_3         REQ_2_3         1.0
    z_2_3_0_3         OCC_3_0_4       -1.0
    z_2_3_0_3         CLS_2_0_4       -1.0
    z_2_3_0_4         OBJ           0.0
    z_2_3_0_4         DAY_2_3_0       1.0
    z_2_3_0_4         REQ_2_3         1.0
    z_2_3_0_4         OCC_3_0_5       -1.0
    z_2_3_0_4         CLS_2_0_5       -1.0
    z_2_3_0_5         OBJ           0.0
    z_2_3_0_5         DAY_2_3_0       1.0
    z_2_3_0_5         REQ_2_3         2.0
    z_2_3_0_5         OCC_3_0_2       -1.0
    z_2_3_0_5         OCC_3_0_3       -1.0
    z_2_3_0_5         CLS_2_0_2       -1.0
    z_2_3_0_5         CLS_2_0_3       -1.0
    z_2_3_0_6         OBJ           0.0
    z_2_3_0_6         DAY_2_3_0       1.0
    z_2_3_0_6         REQ_2_3         2.0
    z_2_3_0_6         OCC_3_0_3       -1.0
    z_2_3_0_6         OCC_3_0_4       -1.0
    z_2_3_0_6         CLS_2_0_3       -1.0
    z_2_3_0_6         CLS_2_0_4       -1.0
    z_2_3_0_7         OBJ           0.0
    z_2_3_0_7         DAY_2_3_0       1.0
    z_2_3_0_7         REQ_2_3         2.0
    z_2_3_0_7         OCC_3_0_4       -1.0
    z_2_3_0_7         OCC_3_0_5       -1.0
    z_2_3_0_7         CLS_2_0_4       -1.0
    z_2_3_0_7         CLS_2_0_5       -1.0
    z_2_3_2_0         OBJ           0.0
    z_2_3_2_0         DAY_2_3_2       1.0
    z_2_3_2_0         REQ_2_3         1.0
    z_2_3_2_0         OCC_3_2_0       -1.0
    z_2_3_2_0         CLS_2_2_0       -1.0
    z_2_3_2_1         OBJ           0.0
    z_2_3_2_1         DAY_2_3_2       1.0
    z_2_3_2_1         REQ_2_3         1.0
    z_2_3_2_1         OCC_3_2_1       -1.0
    z_2_3_2_1         CLS_2_2_1       -1.0
    z_2_3_2_2         OBJ           0.0
    z_2_3_2_2         DAY_2_3_2       1.0
    z_2_3_2_2         REQ_2_3         1.0
    z_2_3_2_2         OCC_3_2_2       -1.0
    z_2_3_2_2         CLS_2_2_2       -1.0
    z_2_3_2_3         OBJ           0.0
    z_2_3_2_3         DAY_2_3_2       1.0
    z_2_3_2_3         REQ_2_3         1.0
    z_2_3_2_3         OCC_3_2_3       -1.0
    z_2_3_2_3         CLS_2_2_3       -1.0
    z_2_3_2_4         OBJ           0.0
    z_2_3_2_4         DAY_2_3_2       1.0
    z_2_3_2_4         REQ_2_3         1.0
    z_2_3_2_4         OCC_3_2_4       -1.0
    z_2_3_2_4         CLS_2_2_4       -1.0
    z_2_3_2_5         OBJ           0.0
    z_2_3_2_5         DAY_2_3_2       1.0
    z_2_3_2_5         REQ_2_3         1.0
    z_2_3_2_5         OCC_3_2_5       -1.0
    z_2_3_2_5         CLS_2_2_5       -1.0
    z_2_3_2_6         OBJ           0.0
    z_2_3_2_6         DAY_2_3_2       1.0
    z_2_3_2_6         REQ_2_3         2.0
    z_2_3_2_6         OCC_3_2_0       -1.0
    z_2_3_2_6         OCC_3_2_1       -1.0
    z_2_3_2_6         CLS_2_2_0       -1.0
    z_2_3_2_6         CLS_2_2_1       -1.0
    z_2_3_2_7         OBJ           0.0
    z_2_3_2_7         DAY_2_3_2       1.0
    z_2_3_2_7         REQ_2_3         2.0
    z_2_3_2_7         OCC_3_2_1       -1.0
    z_2_3_2_7         OCC_3_2_2       -1.0
    z_2_3_2_7         CLS_2_2_1       -1.0
    z_2_3_2_7         CLS_2_2_2       -1.0
    z_2_3_2_8         OBJ           0.0
    z_2_3_2_8         DAY_2_3_2       1.0
    z_2_3_2_8         REQ_2_3         2.0
    z_2_3_2_8         OCC_3_2_2       -1.0
    z_2_3_2_8         OCC_3_2_3       -1.0
    z_2_3_2_8         CLS_2_2_2       -1.0
    z_2_3_2_8         CLS_2_2_3       -1.0
    z_2_3_2_9         OBJ           0.0
    z_2_3_2_9         DAY_2_3_2       1.0
    z_2_3_2_9         REQ_2_3         2.0
    z_2_3_2_9         OCC_3_2_3       -1.0
    z_2_3_2_9         OCC_3_2_4       -1.0
    z_2_3_2_9         CLS_2_2_3       -1.0
    z_2_3_2_9         CLS_2_2_4       -1.0
    z_2_3_2_10        OBJ           0.0
    z_2_3_2_10        DAY_2_3_2       1.0
    z_2_3_2_10        REQ_2_3         2.0
    z_2_3_2_10        OCC_3_2_4       -1.0
    z_2_3_2_10        OCC_3_2_5       -1.0
    z_2_3_2_10        CLS_2_2_4       -1.0
    z_2_3_2_10        CLS_2_2_5       -1.0
    z_2_3_3_0         OBJ           0.0
    z_2_3_3_0         DAY_2_3_3       1.0
    z_2_3_3_0         REQ_2_3         1.0
    z_2_3_3_0         OCC_3_3_1       -1.0
    z_2_3_3_0         CLS_2_3_1       -1.0
    z_2_3_3_1         OBJ           0.0
    z_2_3_3_1         DAY_2_3_3       1.0
    z_2_3_3_1         REQ_2_3         1.0
    z_2_3_3_1         OCC_3_3_2       -1.0
    z_2_3_3_1         CLS_2_3_2       -1.0
    z_2_3_3_2         OBJ           0.0
    z_2_3_3_2         DAY_2_3_3       1.0
    z_2_3_3_2         REQ_2_3         1.0
    z_2_3_3_2         OCC_3_3_3       -1.0
    z_2_3_3_2         CLS_2_3_3       -1.0
    z_2_3_3_3         OBJ           0.0
    z_2_3_3_3         DAY_2_3_3       1.0
    z_2_3_3_3         REQ_2_3         1.0
    z_2_3_3_3         OCC_3_3_4       -1.0
    z_2_3_3_3         CLS_2_3_4       -1.0
    z_2_3_3_4         OBJ           0.0
    z_2_3_3_4         DAY_2_3_3       1.0
    z_2_3_3_4         REQ_2_3         1.0
    z_2_3_3_4         OCC_3_3_5       -1.0
    z_2_3_3_4         CLS_2_3_5       -1.0
    z_2_3_3_5         OBJ           0.0
    z_2_3_3_5         DAY_2_3_3       1.0
    z_2_3_3_5         REQ_2_3         2.0
    z_2_3_3_5         OCC_3_3_1       -1.0
    z_2_3_3_5         OCC_3_3_2       -1.0
    z_2_3_3_5         CLS_2_3_1       -1.0
    z_2_3_3_5         CLS_2_3_2       -1.0
    z_2_3_3_6         OBJ           0.0
    z_2_3_3_6         DAY_2_3_3       1.0
    z_2_3_3_6         REQ_2_3         2.0
    z_2_3_3_6         OCC_3_3_2       -1.0
    z_2_3_3_6         OCC_3_3_3       -1.0
    z_2_3_3_6         CLS_2_3_2       -1.0
    z_2_3_3_6         CLS_2_3_3       -1.0
    z_2_3_3_7         OBJ           0.0
    z_2_3_3_7         DAY_2_3_3       1.0
    z_2_3_3_7         REQ_2_3         2.0
    z_2_3_3_7         OCC_3_3_3       -1.0
    z_2_3_3_7         OCC_3_3_4       -1.0
    z_2_3_3_7         CLS_2_3_3       -1.0
    z_2_3_3_7         CLS_2_3_4       -1.0
    z_2_3_3_8         OBJ           0.0
    z_2_3_3_8         DAY_2_3_3       1.0
    z_2_3_3_8         REQ_2_3         2.0
    z_2_3_3_8         OCC_3_3_4       -1.0
    z_2_3_3_8         OCC_3_3_5       -1.0
    z_2_3_3_8         CLS_2_3_4       -1.0
    z_2_3_3_8         CLS_2_3_5       -1.0
    z_2_3_4_0         OBJ           0.0
    z_2_3_4_0         DAY_2_3_4       1.0
    z_2_3_4_0         REQ_2_3         1.0
    z_2_3_4_0         OCC_3_4_0       -1.0
    z_2_3_4_0         CLS_2_4_0       -1.0
    z_2_3_4_1         OBJ           0.0
    z_2_3_4_1         DAY_2_3_4       1.0
    z_2_3_4_1         REQ_2_3         1.0
    z_2_3_4_1         OCC_3_4_1       -1.0
    z_2_3_4_1         CLS_2_4_1       -1.0
    z_2_3_4_2         OBJ           0.0
    z_2_3_4_2         DAY_2_3_4       1.0
    z_2_3_4_2         REQ_2_3         1.0
    z_2_3_4_2         OCC_3_4_2       -1.0
    z_2_3_4_2         CLS_2_4_2       -1.0
    z_2_3_4_3         OBJ           0.0
    z_2_3_4_3         DAY_2_3_4       1.0
    z_2_3_4_3         REQ_2_3         1.0
    z_2_3_4_3         OCC_3_4_3       -1.0
    z_2_3_4_3         CLS_2_4_3       -1.0
    z_2_3_4_4         OBJ           0.0
    z_2_3_4_4         DAY_2_3_4       1.0
    z_2_3_4_4         REQ_2_3         1.0
    z_2_3_4_4         OCC_3_4_4       -1.0
    z_2_3_4_4         CLS_2_4_4       -1.0
    z_2_3_4_5         OBJ           0.0
    z_2_3_4_5         DAY_2_3_4       1.0
    z_2_3_4_5         REQ_2_3         1.0
    z_2_3_4_5         OCC_3_4_5       -1.0
    z_2_3_4_5         CLS_2_4_5       -1.0
    z_2_3_4_6         OBJ           0.0
    z_2_3_4_6         DAY_2_3_4       1.0
    z_2_3_4_6         REQ_2_3         2.0
    z_2_3_4_6         OCC_3_4_0       -1.0
    z_2_3_4_6         OCC_3_4_1       -1.0
    z_2_3_4_6         CLS_2_4_0       -1.0
    z_2_3_4_6         CLS_2_4_1       -1.0
    z_2_3_4_7         OBJ           0.0
    z_2_3_4_7         DAY_2_3_4       1.0
    z_2_3_4_7         REQ_2_3         2.0
    z_2_3_4_7         OCC_3_4_1       -1.0
    z_2_3_4_7         OCC_3_4_2       -1.0
    z_2_3_4_7         CLS_2_4_1       -1.0
    z_2_3_4_7         CLS_2_4_2       -1.0
    z_2_3_4_8         OBJ           0.0
    z_2_3_4_8         DAY_2_3_4       1.0
    z_2_3_4_8         REQ_2_3         2.0
    z_2_3_4_8         OCC_3_4_2       -1.0
    z_2_3_4_8         OCC_3_4_3       -1.0
    z_2_3_4_8         CLS_2_4_2       -1.0
    z_2_3_4_8         CLS_2_4_3       -1.0
    z_2_3_4_9         OBJ           0.0
    z_2_3_4_9         DAY_2_3_4       1.0
    z_2_3_4_9         REQ_2_3         2.0
    z_2_3_4_9         OCC_3_4_3       -1.0
    z_2_3_4_9         OCC_3_4_4       -1.0
    z_2_3_4_9         CLS_2_4_3       -1.0
    z_2_3_4_9         CLS_2_4_4       -1.0
    z_2_3_4_10        OBJ           0.0
    z_2_3_4_10        DAY_2_3_4       1.0
    z_2_3_4_10        REQ_2_3         2.0
    z_2_3_4_10        OCC_3_4_4       -1.0
    z_2_3_4_10        OCC_3_4_5       -1.0
    z_2_3_4_10        CLS_2_4_4       -1.0
    z_2_3_4_10        CLS_2_4_5       -1.0
    z_2_5_0_0         OBJ           0.0
    z_2_5_0_0         DAY_2_5_0       1.0
    z_2_5_0_0         REQ_2_5         1.0
    z_2_5_0_0         OCC_5_0_0       -1.0
    z_2_5_0_0         CLS_2_0_0       -1.0
    z_2_5_0_1         OBJ           0.0
    z_2_5_0_1         DAY_2_5_0       1.0
    z_2_5_0_1         REQ_2_5         1.0
    z_2_5_0_1         OCC_5_0_1       -1.0
    z_2_5_0_1         CLS_2_0_1       -1.0
    z_2_5_0_2         OBJ           0.0
    z_2_5_0_2         DAY_2_5_0       1.0
    z_2_5_0_2         REQ_2_5         1.0
    z_2_5_0_2         OCC_5_0_2       -1.0
    z_2_5_0_2         CLS_2_0_2       -1.0
    z_2_5_0_3         OBJ           0.0
    z_2_5_0_3         DAY_2_5_0       1.0
    z_2_5_0_3         REQ_2_5         1.0
    z_2_5_0_3         OCC_5_0_3       -1.0
    z_2_5_0_3         CLS_2_0_3       -1.0
    z_2_5_0_4         OBJ           0.0
    z_2_5_0_4         DAY_2_5_0       1.0
    z_2_5_0_4         REQ_2_5         1.0
    z_2_5_0_4         OCC_5_0_4       -1.0
    z_2_5_0_4         CLS_2_0_4       -1.0
    z_2_5_0_5         OBJ           0.0
    z_2_5_0_5         DAY_2_5_0       1.0
    z_2_5_0_5         REQ_2_5         1.0
    z_2_5_0_5         OCC_5_0_5       -1.0
    z_2_5_0_5         CLS_2_0_5       -1.0
    z_2_5_0_6         OBJ           0.0
    z_2_5_0_6         DAY_2_5_0       1.0
    z_2_5_0_6         REQ_2_5         2.0
    z_2_5_0_6         OCC_5_0_0       -1.0
    z_2_5_0_6         OCC_5_0_1       -1.0
    z_2_5_0_6         CLS_2_0_0       -1.0
    z_2_5_0_6         CLS_2_0_1       -1.0
    z_2_5_0_7         OBJ           0.0
    z_2_5_0_7         DAY_2_5_0       1.0
    z_2_5_0_7         REQ_2_5         2.0
    z_2_5_0_7         OCC_5_0_1       -1.0
    z_2_5_0_7         OCC_5_0_2       -1.0
    z_2_5_0_7         CLS_2_0_1       -1.0
    z_2_5_0_7         CLS_2_0_2       -1.0
    z_2_5_0_8         OBJ           0.0
    z_2_5_0_8         DAY_2_5_0       1.0
    z_2_5_0_8         REQ_2_5         2.0
    z_2_5_0_8         OCC_5_0_2       -1.0
    z_2_5_0_8         OCC_5_0_3       -1.0
    z_2_5_0_8         CLS_2_0_2       -1.0
    z_2_5_0_8         CLS_2_0_3       -1.0
    z_2_5_0_9         OBJ           0.0
    z_2_5_0_9         DAY_2_5_0       1.0
    z_2_5_0_9         REQ_2_5         2.0
    z_2_5_0_9         OCC_5_0_3       -1.0
    z_2_5_0_9         OCC_5_0_4       -1.0
    z_2_5_0_9         CLS_2_0_3       -1.0
    z_2_5_0_9         CLS_2_0_4       -1.0
    z_2_5_0_10        OBJ           0.0
    z_2_5_0_10        DAY_2_5_0       1.0
    z_2_5_0_10        REQ_2_5         2.0
    z_2_5_0_10        OCC_5_0_4       -1.0
    z_2_5_0_10        OCC_5_0_5       -1.0
    z_2_5_0_10        CLS_2_0_4       -1.0
    z_2_5_0_10        CLS_2_0_5       -1.0
    z_2_5_1_0         OBJ           0.0
    z_2_5_1_0         DAY_2_5_1       1.0
    z_2_5_1_0         REQ_2_5         1.0
    z_2_5_1_0         OCC_5_1_0       -1.0
    z_2_5_1_0         CLS_2_1_0       -1.0
    z_2_5_1_1         OBJ           0.0
    z_2_5_1_1         DAY_2_5_1       1.0
    z_2_5_1_1         REQ_2_5         1.0
    z_2_5_1_1         OCC_5_1_2       -1.0
    z_2_5_1_1         CLS_2_1_2       -1.0
    z_2_5_1_2         OBJ           0.0
    z_2_5_1_2         DAY_2_5_1       1.0
    z_2_5_1_2         REQ_2_5         1.0
    z_2_5_1_2         OCC_5_1_3       -1.0
    z_2_5_1_2         CLS_2_1_3       -1.0
    z_2_5_1_3         OBJ           0.0
    z_2_5_1_3         DAY_2_5_1       1.0
    z_2_5_1_3         REQ_2_5         1.0
    z_2_5_1_3         OCC_5_1_4       -1.0
    z_2_5_1_3         CLS_2_1_4       -1.0
    z_2_5_1_4         OBJ           0.0
    z_2_5_1_4         DAY_2_5_1       1.0
    z_2_5_1_4         REQ_2_5         1.0
    z_2_5_1_4         OCC_5_1_5       -1.0
    z_2_5_1_4         CLS_2_1_5       -1.0
    z_2_5_1_5         OBJ           0.0
    z_2_5_1_5         DAY_2_5_1       1.0
    z_2_5_1_5         REQ_2_5         2.0
    z_2_5_1_5         OCC_5_1_2       -1.0
    z_2_5_1_5         OCC_5_1_3       -1.0
    z_2_5_1_5         CLS_2_1_2       -1.0
    z_2_5_1_5         CLS_2_1_3       -1.0
    z_2_5_1_6         OBJ           0.0
    z_2_5_1_6         DAY_2_5_1       1.0
    z_2_5_1_6         REQ_2_5         2.0
    z_2_5_1_6         OCC_5_1_3       -1.0
    z_2_5_1_6         OCC_5_1_4       -1.0
    z_2_5_1_6         CLS_2_1_3       -1.0
    z_2_5_1_6         CLS_2_1_4       -1.0
    z_2_5_1_7         OBJ           0.0
    z_2_5_1_7         DAY_2_5_1       1.0
    z_2_5_1_7         REQ_2_5         2.0
    z_2_5_1_7         OCC_5_1_4       -1.0
    z_2_5_1_7         OCC_5_1_5       -1.0
    z_2_5_1_7         CLS_2_1_4       -1.0
    z_2_5_1_7         CLS_2_1_5       -1.0
    z_2_5_2_0         OBJ           0.0
    z_2_5_2_0         DAY_2_5_2       1.0
    z_2_5_2_0         REQ_2_5         1.0
    z_2_5_2_0         OCC_5_2_0       -1.0
    z_2_5_2_0         CLS_2_2_0       -1.0
    z_2_5_2_1         OBJ           0.0
    z_2_5_2_1         DAY_2_5_2       1.0
    z_2_5_2_1         REQ_2_5         1.0
    z_2_5_2_1         OCC_5_2_1       -1.0
    z_2_5_2_1         CLS_2_2_1       -1.0
    z_2_5_2_2         OBJ           0.0
    z_2_5_2_2         DAY_2_5_2       1.0
    z_2_5_2_2         REQ_2_5         1.0
    z_2_5_2_2         OCC_5_2_2       -1.0
    z_2_5_2_2         CLS_2_2_2       -1.0
    z_2_5_2_3         OBJ           0.0
    z_2_5_2_3         DAY_2_5_2       1.0
    z_2_5_2_3         REQ_2_5         1.0
    z_2_5_2_3         OCC_5_2_4       -1.0
    z_2_5_2_3         CLS_2_2_4       -1.0
    z_2_5_2_4         OBJ           0.0
    z_2_5_2_4         DAY_2_5_2       1.0
    z_2_5_2_4         REQ_2_5         1.0
    z_2_5_2_4         OCC_5_2_5       -1.0
    z_2_5_2_4         CLS_2_2_5       -1.0
    z_2_5_2_5         OBJ           0.0
    z_2_5_2_5         DAY_2_5_2       1.0
    z_2_5_2_5         REQ_2_5         2.0
    z_2_5_2_5         OCC_5_2_0       -1.0
    z_2_5_2_5         OCC_5_2_1       -1.0
    z_2_5_2_5         CLS_2_2_0       -1.0
    z_2_5_2_5         CLS_2_2_1       -1.0
    z_2_5_2_6         OBJ           0.0
    z_2_5_2_6         DAY_2_5_2       1.0
    z_2_5_2_6         REQ_2_5         2.0
    z_2_5_2_6         OCC_5_2_1       -1.0
    z_2_5_2_6         OCC_5_2_2       -1.0
    z_2_5_2_6         CLS_2_2_1       -1.0
    z_2_5_2_6         CLS_2_2_2       -1.0
    z_2_5_2_7         OBJ           0.0
    z_2_5_2_7         DAY_2_5_2       1.0
    z_2_5_2_7         REQ_2_5         2.0
    z_2_5_2_7         OCC_5_2_4       -1.0
    z_2_5_2_7         OCC_5_2_5       -1.0
    z_2_5_2_7         CLS_2_2_4       -1.0
    z_2_5_2_7         CLS_2_2_5       -1.0
    z_2_5_3_0         OBJ           0.0
    z_2_5_3_0         DAY_2_5_3       1.0
    z_2_5_3_0         REQ_2_5         1.0
    z_2_5_3_0         OCC_5_3_0       -1.0
    z_2_5_3_0         CLS_2_3_0       -1.0
    z_2_5_3_1         OBJ           0.0
    z_2_5_3_1         DAY_2_5_3       1.0
    z_2_5_3_1         REQ_2_5         1.0
    z_2_5_3_1         OCC_5_3_1       -1.0
    z_2_5_3_1         CLS_2_3_1       -1.0
    z_2_5_3_2         OBJ           0.0
    z_2_5_3_2         DAY_2_5_3       1.0
    z_2_5_3_2         REQ_2_5         1.0
    z_2_5_3_2         OCC_5_3_2       -1.0
    z_2_5_3_2         CLS_2_3_2       -1.0
    z_2_5_3_3         OBJ           0.0
    z_2_5_3_3         DAY_2_5_3       1.0
    z_2_5_3_3         REQ_2_5         1.0
    z_2_5_3_3         OCC_5_3_3       -1.0
    z_2_5_3_3         CLS_2_3_3       -1.0
    z_2_5_3_4         OBJ           0.0
    z_2_5_3_4         DAY_2_5_3       1.0
    z_2_5_3_4         REQ_2_5         1.0
    z_2_5_3_4         OCC_5_3_4       -1.0
    z_2_5_3_4         CLS_2_3_4       -1.0
    z_2_5_3_5         OBJ           0.0
    z_2_5_3_5         DAY_2_5_3       1.0
    z_2_5_3_5         REQ_2_5         1.0
    z_2_5_3_5         OCC_5_3_5       -1.0
    z_2_5_3_5         CLS_2_3_5       -1.0
    z_2_5_3_6         OBJ           0.0
    z_2_5_3_6         DAY_2_5_3       1.0
    z_2_5_3_6         REQ_2_5         2.0
    z_2_5_3_6         OCC_5_3_0       -1.0
    z_2_5_3_6         OCC_5_3_1       -1.0
    z_2_5_3_6         CLS_2_3_0       -1.0
    z_2_5_3_6         CLS_2_3_1       -1.0
    z_2_5_3_7         OBJ           0.0
    z_2_5_3_7         DAY_2_5_3       1.0
    z_2_5_3_7         REQ_2_5         2.0
    z_2_5_3_7         OCC_5_3_1       -1.0
    z_2_5_3_7         OCC_5_3_2       -1.0
    z_2_5_3_7         CLS_2_3_1       -1.0
    z_2_5_3_7         CLS_2_3_2       -1.0
    z_2_5_3_8         OBJ           0.0
    z_2_5_3_8         DAY_2_5_3       1.0
    z_2_5_3_8         REQ_2_5         2.0
    z_2_5_3_8         OCC_5_3_2       -1.0
    z_2_5_3_8         OCC_5_3_3       -1.0
    z_2_5_3_8         CLS_2_3_2       -1.0
    z_2_5_3_8         CLS_2_3_3       -1.0
    z_2_5_3_9         OBJ           0.0
    z_2_5_3_9         DAY_2_5_3       1.0
    z_2_5_3_9         REQ_2_5         2.0
    z_2_5_3_9         OCC_5_3_3       -1.0
    z_2_5_3_9         OCC_5_3_4       -1.0
    z_2_5_3_9         CLS_2_3_3       -1.0
    z_2_5_3_9         CLS_2_3_4       -1.0
    z_2_5_3_10        OBJ           0.0
    z_2_5_3_10        DAY_2_5_3       1.0
    z_2_5_3_10        REQ_2_5         2.0
    z_2_5_3_10        OCC_5_3_4       -1.0
    z_2_5_3_10        OCC_5_3_5       -1.0
    z_2_5_3_10        CLS_2_3_4       -1.0
    z_2_5_3_10        CLS_2_3_5       -1.0
    z_2_6_0_0         OBJ           0.0
    z_2_6_0_0         DAY_2_6_0       1.0
    z_2_6_0_0         REQ_2_6         1.0
    z_2_6_0_0         OCC_6_0_0       -1.0
    z_2_6_0_0         CLS_2_0_0       -1.0
    z_2_6_0_1         OBJ           0.0
    z_2_6_0_1         DAY_2_6_0       1.0
    z_2_6_0_1         REQ_2_6         1.0
    z_2_6_0_1         OCC_6_0_1       -1.0
    z_2_6_0_1         CLS_2_0_1       -1.0
    z_2_6_0_2         OBJ           0.0
    z_2_6_0_2         DAY_2_6_0       1.0
    z_2_6_0_2         REQ_2_6         1.0
    z_2_6_0_2         OCC_6_0_2       -1.0
    z_2_6_0_2         CLS_2_0_2       -1.0
    z_2_6_0_3         OBJ           0.0
    z_2_6_0_3         DAY_2_6_0       1.0
    z_2_6_0_3         REQ_2_6         1.0
    z_2_6_0_3         OCC_6_0_3       -1.0
    z_2_6_0_3         CLS_2_0_3       -1.0
    z_2_6_0_4         OBJ           0.0
    z_2_6_0_4         DAY_2_6_0       1.0
    z_2_6_0_4         REQ_2_6         1.0
    z_2_6_0_4         OCC_6_0_4       -1.0
    z_2_6_0_4         CLS_2_0_4       -1.0
    z_2_6_0_5         OBJ           0.0
    z_2_6_0_5         DAY_2_6_0       1.0
    z_2_6_0_5         REQ_2_6         1.0
    z_2_6_0_5         OCC_6_0_5       -1.0
    z_2_6_0_5         CLS_2_0_5       -1.0
    z_2_6_0_6         OBJ           0.0
    z_2_6_0_6         DAY_2_6_0       1.0
    z_2_6_0_6         REQ_2_6         2.0
    z_2_6_0_6         OCC_6_0_0       -1.0
    z_2_6_0_6         OCC_6_0_1       -1.0
    z_2_6_0_6         CLS_2_0_0       -1.0
    z_2_6_0_6         CLS_2_0_1       -1.0
    z_2_6_0_7         OBJ           0.0
    z_2_6_0_7         DAY_2_6_0       1.0
    z_2_6_0_7         REQ_2_6         2.0
    z_2_6_0_7         OCC_6_0_1       -1.0
    z_2_6_0_7         OCC_6_0_2       -1.0
    z_2_6_0_7         CLS_2_0_1       -1.0
    z_2_6_0_7         CLS_2_0_2       -1.0
    z_2_6_0_8         OBJ           0.0
    z_2_6_0_8         DAY_2_6_0       1.0
    z_2_6_0_8         REQ_2_6         2.0
    z_2_6_0_8         OCC_6_0_2       -1.0
    z_2_6_0_8         OCC_6_0_3       -1.0
    z_2_6_0_8         CLS_2_0_2       -1.0
    z_2_6_0_8         CLS_2_0_3       -1.0
    z_2_6_0_9         OBJ           0.0
    z_2_6_0_9         DAY_2_6_0       1.0
    z_2_6_0_9         REQ_2_6         2.0
    z_2_6_0_9         OCC_6_0_3       -1.0
    z_2_6_0_9         OCC_6_0_4       -1.0
    z_2_6_0_9         CLS_2_0_3       -1.0
    z_2_6_0_9         CLS_2_0_4       -1.0
    z_2_6_0_10        OBJ           0.0
    z_2_6_0_10        DAY_2_6_0       1.0
    z_2_6_0_10        REQ_2_6         2.0
    z_2_6_0_10        OCC_6_0_4       -1.0
    z_2_6_0_10        OCC_6_0_5       -1.0
    z_2_6_0_10        CLS_2_0_4       -1.0
    z_2_6_0_10        CLS_2_0_5       -1.0
    z_2_6_1_0         OBJ           0.0
    z_2_6_1_0         DAY_2_6_1       1.0
    z_2_6_1_0         REQ_2_6         1.0
    z_2_6_1_0         OCC_6_1_0       -1.0
    z_2_6_1_0         CLS_2_1_0       -1.0
    z_2_6_1_1         OBJ           0.0
    z_2_6_1_1         DAY_2_6_1       1.0
    z_2_6_1_1         REQ_2_6         1.0
    z_2_6_1_1         OCC_6_1_1       -1.0
    z_2_6_1_1         CLS_2_1_1       -1.0
    z_2_6_1_2         OBJ           0.0
    z_2_6_1_2         DAY_2_6_1       1.0
    z_2_6_1_2         REQ_2_6         1.0
    z_2_6_1_2         OCC_6_1_2       -1.0
    z_2_6_1_2         CLS_2_1_2       -1.0
    z_2_6_1_3         OBJ           0.0
    z_2_6_1_3         DAY_2_6_1       1.0
    z_2_6_1_3         REQ_2_6         1.0
    z_2_6_1_3         OCC_6_1_3       -1.0
    z_2_6_1_3         CLS_2_1_3       -1.0
    z_2_6_1_4         OBJ           0.0
    z_2_6_1_4         DAY_2_6_1       1.0
    z_2_6_1_4         REQ_2_6         1.0
    z_2_6_1_4         OCC_6_1_4       -1.0
    z_2_6_1_4         CLS_2_1_4       -1.0
    z_2_6_1_5         OBJ           0.0
    z_2_6_1_5         DAY_2_6_1       1.0
    z_2_6_1_5         REQ_2_6         1.0
    z_2_6_1_5         OCC_6_1_5       -1.0
    z_2_6_1_5         CLS_2_1_5       -1.0
    z_2_6_1_6         OBJ           0.0
    z_2_6_1_6         DAY_2_6_1       1.0
    z_2_6_1_6         REQ_2_6         2.0
    z_2_6_1_6         OCC_6_1_0       -1.0
    z_2_6_1_6         OCC_6_1_1       -1.0
    z_2_6_1_6         CLS_2_1_0       -1.0
    z_2_6_1_6         CLS_2_1_1       -1.0
    z_2_6_1_7         OBJ           0.0
    z_2_6_1_7         DAY_2_6_1       1.0
    z_2_6_1_7         REQ_2_6         2.0
    z_2_6_1_7         OCC_6_1_1       -1.0
    z_2_6_1_7         OCC_6_1_2       -1.0
    z_2_6_1_7         CLS_2_1_1       -1.0
    z_2_6_1_7         CLS_2_1_2       -1.0
    z_2_6_1_8         OBJ           0.0
    z_2_6_1_8         DAY_2_6_1       1.0
    z_2_6_1_8         REQ_2_6         2.0
    z_2_6_1_8         OCC_6_1_2       -1.0
    z_2_6_1_8         OCC_6_1_3       -1.0
    z_2_6_1_8         CLS_2_1_2       -1.0
    z_2_6_1_8         CLS_2_1_3       -1.0
    z_2_6_1_9         OBJ           0.0
    z_2_6_1_9         DAY_2_6_1       1.0
    z_2_6_1_9         REQ_2_6         2.0
    z_2_6_1_9         OCC_6_1_3       -1.0
    z_2_6_1_9         OCC_6_1_4       -1.0
    z_2_6_1_9         CLS_2_1_3       -1.0
    z_2_6_1_9         CLS_2_1_4       -1.0
    z_2_6_1_10        OBJ           0.0
    z_2_6_1_10        DAY_2_6_1       1.0
    z_2_6_1_10        REQ_2_6         2.0
    z_2_6_1_10        OCC_6_1_4       -1.0
    z_2_6_1_10        OCC_6_1_5       -1.0
    z_2_6_1_10        CLS_2_1_4       -1.0
    z_2_6_1_10        CLS_2_1_5       -1.0
    z_2_6_2_0         OBJ           0.0
    z_2_6_2_0         DAY_2_6_2       1.0
    z_2_6_2_0         REQ_2_6         1.0
    z_2_6_2_0         OCC_6_2_0       -1.0
    z_2_6_2_0         CLS_2_2_0       -1.0
    z_2_6_2_1         OBJ           0.0
    z_2_6_2_1         DAY_2_6_2       1.0
    z_2_6_2_1         REQ_2_6         1.0
    z_2_6_2_1         OCC_6_2_1       -1.0
    z_2_6_2_1         CLS_2_2_1       -1.0
    z_2_6_2_2         OBJ           0.0
    z_2_6_2_2         DAY_2_6_2       1.0
    z_2_6_2_2         REQ_2_6         1.0
    z_2_6_2_2         OCC_6_2_2       -1.0
    z_2_6_2_2         CLS_2_2_2       -1.0
    z_2_6_2_3         OBJ           0.0
    z_2_6_2_3         DAY_2_6_2       1.0
    z_2_6_2_3         REQ_2_6         1.0
    z_2_6_2_3         OCC_6_2_3       -1.0
    z_2_6_2_3         CLS_2_2_3       -1.0
    z_2_6_2_4         OBJ           0.0
    z_2_6_2_4         DAY_2_6_2       1.0
    z_2_6_2_4         REQ_2_6         1.0
    z_2_6_2_4         OCC_6_2_4       -1.0
    z_2_6_2_4         CLS_2_2_4       -1.0
    z_2_6_2_5         OBJ           0.0
    z_2_6_2_5         DAY_2_6_2       1.0
    z_2_6_2_5         REQ_2_6         2.0
    z_2_6_2_5         OCC_6_2_0       -1.0
    z_2_6_2_5         OCC_6_2_1       -1.0
    z_2_6_2_5         CLS_2_2_0       -1.0
    z_2_6_2_5         CLS_2_2_1       -1.0
    z_2_6_2_6         OBJ           0.0
    z_2_6_2_6         DAY_2_6_2       1.0
    z_2_6_2_6         REQ_2_6         2.0
    z_2_6_2_6         OCC_6_2_1       -1.0
    z_2_6_2_6         OCC_6_2_2       -1.0
    z_2_6_2_6         CLS_2_2_1       -1.0
    z_2_6_2_6         CLS_2_2_2       -1.0
    z_2_6_2_7         OBJ           0.0
    z_2_6_2_7         DAY_2_6_2       1.0
    z_2_6_2_7         REQ_2_6         2.0
    z_2_6_2_7         OCC_6_2_2       -1.0
    z_2_6_2_7         OCC_6_2_3       -1.0
    z_2_6_2_7         CLS_2_2_2       -1.0
    z_2_6_2_7         CLS_2_2_3       -1.0
    z_2_6_2_8         OBJ           0.0
    z_2_6_2_8         DAY_2_6_2       1.0
    z_2_6_2_8         REQ_2_6         2.0
    z_2_6_2_8         OCC_6_2_3       -1.0
    z_2_6_2_8         OCC_6_2_4       -1.0
    z_2_6_2_8         CLS_2_2_3       -1.0
    z_2_6_2_8         CLS_2_2_4       -1.0
    z_2_6_3_0         OBJ           0.0
    z_2_6_3_0         DAY_2_6_3       1.0
    z_2_6_3_0         REQ_2_6         1.0
    z_2_6_3_0         OCC_6_3_0       -1.0
    z_2_6_3_0         CLS_2_3_0       -1.0
    z_2_6_3_1         OBJ           0.0
    z_2_6_3_1         DAY_2_6_3       1.0
    z_2_6_3_1         REQ_2_6         1.0
    z_2_6_3_1         OCC_6_3_1       -1.0
    z_2_6_3_1         CLS_2_3_1       -1.0
    z_2_6_3_2         OBJ           0.0
    z_2_6_3_2         DAY_2_6_3       1.0
    z_2_6_3_2         REQ_2_6         1.0
    z_2_6_3_2         OCC_6_3_2       -1.0
    z_2_6_3_2         CLS_2_3_2       -1.0
    z_2_6_3_3         OBJ           0.0
    z_2_6_3_3         DAY_2_6_3       1.0
    z_2_6_3_3         REQ_2_6         1.0
    z_2_6_3_3         OCC_6_3_3       -1.0
    z_2_6_3_3         CLS_2_3_3       -1.0
    z_2_6_3_4         OBJ           0.0
    z_2_6_3_4         DAY_2_6_3       1.0
    z_2_6_3_4         REQ_2_6         1.0
    z_2_6_3_4         OCC_6_3_5       -1.0
    z_2_6_3_4         CLS_2_3_5       -1.0
    z_2_6_3_5         OBJ           0.0
    z_2_6_3_5         DAY_2_6_3       1.0
    z_2_6_3_5         REQ_2_6         2.0
    z_2_6_3_5         OCC_6_3_0       -1.0
    z_2_6_3_5         OCC_6_3_1       -1.0
    z_2_6_3_5         CLS_2_3_0       -1.0
    z_2_6_3_5         CLS_2_3_1       -1.0
    z_2_6_3_6         OBJ           0.0
    z_2_6_3_6         DAY_2_6_3       1.0
    z_2_6_3_6         REQ_2_6         2.0
    z_2_6_3_6         OCC_6_3_1       -1.0
    z_2_6_3_6         OCC_6_3_2       -1.0
    z_2_6_3_6         CLS_2_3_1       -1.0
    z_2_6_3_6         CLS_2_3_2       -1.0
    z_2_6_3_7         OBJ           0.0
    z_2_6_3_7         DAY_2_6_3       1.0
    z_2_6_3_7         REQ_2_6         2.0
    z_2_6_3_7         OCC_6_3_2       -1.0
    z_2_6_3_7         OCC_6_3_3       -1.0
    z_2_6_3_7         CLS_2_3_2       -1.0
    z_2_6_3_7         CLS_2_3_3       -1.0
    z_2_6_4_0         OBJ           0.0
    z_2_6_4_0         DAY_2_6_4       1.0
    z_2_6_4_0         REQ_2_6         1.0
    z_2_6_4_0         OCC_6_4_0       -1.0
    z_2_6_4_0         CLS_2_4_0       -1.0
    z_2_6_4_1         OBJ           0.0
    z_2_6_4_1         DAY_2_6_4       1.0
    z_2_6_4_1         REQ_2_6         1.0
    z_2_6_4_1         OCC_6_4_1       -1.0
    z_2_6_4_1         CLS_2_4_1       -1.0
    z_2_6_4_2         OBJ           0.0
    z_2_6_4_2         DAY_2_6_4       1.0
    z_2_6_4_2         REQ_2_6         1.0
    z_2_6_4_2         OCC_6_4_2       -1.0
    z_2_6_4_2         CLS_2_4_2       -1.0
    z_2_6_4_3         OBJ           0.0
    z_2_6_4_3         DAY_2_6_4       1.0
    z_2_6_4_3         REQ_2_6         1.0
    z_2_6_4_3         OCC_6_4_3       -1.0
    z_2_6_4_3         CLS_2_4_3       -1.0
    z_2_6_4_4         OBJ           0.0
    z_2_6_4_4         DAY_2_6_4       1.0
    z_2_6_4_4         REQ_2_6         1.0
    z_2_6_4_4         OCC_6_4_4       -1.0
    z_2_6_4_4         CLS_2_4_4       -1.0
    z_2_6_4_5         OBJ           0.0
    z_2_6_4_5         DAY_2_6_4       1.0
    z_2_6_4_5         REQ_2_6         1.0
    z_2_6_4_5         OCC_6_4_5       -1.0
    z_2_6_4_5         CLS_2_4_5       -1.0
    z_2_6_4_6         OBJ           0.0
    z_2_6_4_6         DAY_2_6_4       1.0
    z_2_6_4_6         REQ_2_6         2.0
    z_2_6_4_6         OCC_6_4_0       -1.0
    z_2_6_4_6         OCC_6_4_1       -1.0
    z_2_6_4_6         CLS_2_4_0       -1.0
    z_2_6_4_6         CLS_2_4_1       -1.0
    z_2_6_4_7         OBJ           0.0
    z_2_6_4_7         DAY_2_6_4       1.0
    z_2_6_4_7         REQ_2_6         2.0
    z_2_6_4_7         OCC_6_4_1       -1.0
    z_2_6_4_7         OCC_6_4_2       -1.0
    z_2_6_4_7         CLS_2_4_1       -1.0
    z_2_6_4_7         CLS_2_4_2       -1.0
    z_2_6_4_8         OBJ           0.0
    z_2_6_4_8         DAY_2_6_4       1.0
    z_2_6_4_8         REQ_2_6         2.0
    z_2_6_4_8         OCC_6_4_2       -1.0
    z_2_6_4_8         OCC_6_4_3       -1.0
    z_2_6_4_8         CLS_2_4_2       -1.0
    z_2_6_4_8         CLS_2_4_3       -1.0
    z_2_6_4_9         OBJ           0.0
    z_2_6_4_9         DAY_2_6_4       1.0
    z_2_6_4_9         REQ_2_6         2.0
    z_2_6_4_9         OCC_6_4_3       -1.0
    z_2_6_4_9         OCC_6_4_4       -1.0
    z_2_6_4_9         CLS_2_4_3       -1.0
    z_2_6_4_9         CLS_2_4_4       -1.0
    z_2_6_4_10        OBJ           0.0
    z_2_6_4_10        DAY_2_6_4       1.0
    z_2_6_4_10        REQ_2_6         2.0
    z_2_6_4_10        OCC_6_4_4       -1.0
    z_2_6_4_10        OCC_6_4_5       -1.0
    z_2_6_4_10        CLS_2_4_4       -1.0
    z_2_6_4_10        CLS_2_4_5       -1.0
    z_3_2_0_0         OBJ           0.0
    z_3_2_0_0         DAY_3_2_0       1.0
    z_3_2_0_0         REQ_3_2         1.0
    z_3_2_0_0         OCC_2_0_0       -1.0
    z_3_2_0_0         CLS_3_0_0       -1.0
    z_3_2_0_1         OBJ           0.0
    z_3_2_0_1         DAY_3_2_0       1.0
    z_3_2_0_1         REQ_3_2         1.0
    z_3_2_0_1         OCC_2_0_1       -1.0
    z_3_2_0_1         CLS_3_0_1       -1.0
    z_3_2_0_2         OBJ           0.0
    z_3_2_0_2         DAY_3_2_0       1.0
    z_3_2_0_2         REQ_3_2         1.0
    z_3_2_0_2         OCC_2_0_2       -1.0
    z_3_2_0_2         CLS_3_0_2       -1.0
    z_3_2_0_3         OBJ           0.0
    z_3_2_0_3         DAY_3_2_0       1.0
    z_3_2_0_3         REQ_3_2         1.0
    z_3_2_0_3         OCC_2_0_3       -1.0
    z_3_2_0_3         CLS_3_0_3       -1.0
    z_3_2_0_4         OBJ           0.0
    z_3_2_0_4         DAY_3_2_0       1.0
    z_3_2_0_4         REQ_3_2         1.0
    z_3_2_0_4         OCC_2_0_4       -1.0
    z_3_2_0_4         CLS_3_0_4       -1.0
    z_3_2_0_5         OBJ           0.0
    z_3_2_0_5         DAY_3_2_0       1.0
    z_3_2_0_5         REQ_3_2         2.0
    z_3_2_0_5         OCC_2_0_0       -1.0
    z_3_2_0_5         OCC_2_0_1       -1.0
    z_3_2_0_5         CLS_3_0_0       -1.0
    z_3_2_0_5         CLS_3_0_1       -1.0
    z_3_2_0_6         OBJ           0.0
    z_3_2_0_6         DAY_3_2_0       1.0
    z_3_2_0_6         REQ_3_2         2.0
    z_3_2_0_6         OCC_2_0_1       -1.0
    z_3_2_0_6         OCC_2_0_2       -1.0
    z_3_2_0_6         CLS_3_0_1       -1.0
    z_3_2_0_6         CLS_3_0_2       -1.0
    z_3_2_0_7         OBJ           0.0
    z_3_2_0_7         DAY_3_2_0       1.0
    z_3_2_0_7         REQ_3_2         2.0
    z_3_2_0_7         OCC_2_0_2       -1.0
    z_3_2_0_7         OCC_2_0_3       -1.0
    z_3_2_0_7         CLS_3_0_2       -1.0
    z_3_2_0_7         CLS_3_0_3       -1.0
    z_3_2_0_8         OBJ           0.0
    z_3_2_0_8         DAY_3_2_0       1.0
    z_3_2_0_8         REQ_3_2         2.0
    z_3_2_0_8         OCC_2_0_3       -1.0
    z_3_2_0_8         OCC_2_0_4       -1.0
    z_3_2_0_8         CLS_3_0_3       -1.0
    z_3_2_0_8         CLS_3_0_4       -1.0
    z_3_2_1_0         OBJ           0.0
    z_3_2_1_0         DAY_3_2_1       1.0
    z_3_2_1_0         REQ_3_2         1.0
    z_3_2_1_0         OCC_2_1_0       -1.0
    z_3_2_1_0         CLS_3_1_0       -1.0
    z_3_2_1_1         OBJ           0.0
    z_3_2_1_1         DAY_3_2_1       1.0
    z_3_2_1_1         REQ_3_2         1.0
    z_3_2_1_1         OCC_2_1_1       -1.0
    z_3_2_1_1         CLS_3_1_1       -1.0
    z_3_2_1_2         OBJ           0.0
    z_3_2_1_2         DAY_3_2_1       1.0
    z_3_2_1_2         REQ_3_2         1.0
    z_3_2_1_2         OCC_2_1_2       -1.0
    z_3_2_1_2         CLS_3_1_2       -1.0
    z_3_2_1_3         OBJ           0.0
    z_3_2_1_3         DAY_3_2_1       1.0
    z_3_2_1_3         REQ_3_2         1.0
    z_3_2_1_3         OCC_2_1_3       -1.0
    z_3_2_1_3         CLS_3_1_3       -1.0
    z_3_2_1_4         OBJ           0.0
    z_3_2_1_4         DAY_3_2_1       1.0
    z_3_2_1_4         REQ_3_2         1.0
    z_3_2_1_4         OCC_2_1_4       -1.0
    z_3_2_1_4         CLS_3_1_4       -1.0
    z_3_2_1_5         OBJ           0.0
    z_3_2_1_5         DAY_3_2_1       1.0
    z_3_2_1_5         REQ_3_2         1.0
    z_3_2_1_5         OCC_2_1_5       -1.0
    z_3_2_1_5         CLS_3_1_5       -1.0
    z_3_2_1_6         OBJ           0.0
    z_3_2_1_6         DAY_3_2_1       1.0
    z_3_2_1_6         REQ_3_2         2.0
    z_3_2_1_6         OCC_2_1_0       -1.0
    z_3_2_1_6         OCC_2_1_1       -1.0
    z_3_2_1_6         CLS_3_1_0       -1.0
    z_3_2_1_6         CLS_3_1_1       -1.0
    z_3_2_1_7         OBJ           0.0
    z_3_2_1_7         DAY_3_2_1       1.0
    z_3_2_1_7         REQ_3_2         2.0
    z_3_2_1_7         OCC_2_1_1       -1.0
    z_3_2_1_7         OCC_2_1_2       -1.0
    z_3_2_1_7         CLS_3_1_1       -1.0
    z_3_2_1_7         CLS_3_1_2       -1.0
    z_3_2_1_8         OBJ           0.0
    z_3_2_1_8         DAY_3_2_1       1.0
    z_3_2_1_8         REQ_3_2         2.0
    z_3_2_1_8         OCC_2_1_2       -1.0
    z_3_2_1_8         OCC_2_1_3       -1.0
    z_3_2_1_8         CLS_3_1_2       -1.0
    z_3_2_1_8         CLS_3_1_3       -1.0
    z_3_2_1_9         OBJ           0.0
    z_3_2_1_9         DAY_3_2_1       1.0
    z_3_2_1_9         REQ_3_2         2.0
    z_3_2_1_9         OCC_2_1_3       -1.0
    z_3_2_1_9         OCC_2_1_4       -1.0
    z_3_2_1_9         CLS_3_1_3       -1.0
    z_3_2_1_9         CLS_3_1_4       -1.0
    z_3_2_1_10        OBJ           0.0
    z_3_2_1_10        DAY_3_2_1       1.0
    z_3_2_1_10        REQ_3_2         2.0
    z_3_2_1_10        OCC_2_1_4       -1.0
    z_3_2_1_10        OCC_2_1_5       -1.0
    z_3_2_1_10        CLS_3_1_4       -1.0
    z_3_2_1_10        CLS_3_1_5       -1.0
    z_3_2_2_0         OBJ           0.0
    z_3_2_2_0         DAY_3_2_2       1.0
    z_3_2_2_0         REQ_3_2         1.0
    z_3_2_2_0         OCC_2_2_0       -1.0
    z_3_2_2_0         CLS_3_2_0       -1.0
    z_3_2_2_1         OBJ           0.0
    z_3_2_2_1         DAY_3_2_2       1.0
    z_3_2_2_1         REQ_3_2         1.0
    z_3_2_2_1         OCC_2_2_1       -1.0
    z_3_2_2_1         CLS_3_2_1       -1.0
    z_3_2_2_2         OBJ           0.0
    z_3_2_2_2         DAY_3_2_2       1.0
    z_3_2_2_2         REQ_3_2         1.0
    z_3_2_2_2         OCC_2_2_2       -1.0
    z_3_2_2_2         CLS_3_2_2       -1.0
    z_3_2_2_3         OBJ           0.0
    z_3_2_2_3         DAY_3_2_2       1.0
    z_3_2_2_3         REQ_3_2         1.0
    z_3_2_2_3         OCC_2_2_3       -1.0
    z_3_2_2_3         CLS_3_2_3       -1.0
    z_3_2_2_4         OBJ           0.0
    z_3_2_2_4         DAY_3_2_2       1.0
    z_3_2_2_4         REQ_3_2         1.0
    z_3_2_2_4         OCC_2_2_4       -1.0
    z_3_2_2_4         CLS_3_2_4       -1.0
    z_3_2_2_5         OBJ           0.0
    z_3_2_2_5         DAY_3_2_2       1.0
    z_3_2_2_5         REQ_3_2         2.0
    z_3_2_2_5         OCC_2_2_0       -1.0
    z_3_2_2_5         OCC_2_2_1       -1.0
    z_3_2_2_5         CLS_3_2_0       -1.0
    z_3_2_2_5         CLS_3_2_1       -1.0
    z_3_2_2_6         OBJ           0.0
    z_3_2_2_6         DAY_3_2_2       1.0
    z_3_2_2_6         REQ_3_2         2.0
    z_3_2_2_6         OCC_2_2_1       -1.0
    z_3_2_2_6         OCC_2_2_2       -1.0
    z_3_2_2_6         CLS_3_2_1       -1.0
    z_3_2_2_6         CLS_3_2_2       -1.0
    z_3_2_2_7         OBJ           0.0
    z_3_2_2_7         DAY_3_2_2       1.0
    z_3_2_2_7         REQ_3_2         2.0
    z_3_2_2_7         OCC_2_2_2       -1.0
    z_3_2_2_7         OCC_2_2_3       -1.0
    z_3_2_2_7         CLS_3_2_2       -1.0
    z_3_2_2_7         CLS_3_2_3       -1.0
    z_3_2_2_8         OBJ           0.0
    z_3_2_2_8         DAY_3_2_2       1.0
    z_3_2_2_8         REQ_3_2         2.0
    z_3_2_2_8         OCC_2_2_3       -1.0
    z_3_2_2_8         OCC_2_2_4       -1.0
    z_3_2_2_8         CLS_3_2_3       -1.0
    z_3_2_2_8         CLS_3_2_4       -1.0
    z_3_2_3_0         OBJ           0.0
    z_3_2_3_0         DAY_3_2_3       1.0
    z_3_2_3_0         REQ_3_2         1.0
    z_3_2_3_0         OCC_2_3_0       -1.0
    z_3_2_3_0         CLS_3_3_0       -1.0
    z_3_2_3_1         OBJ           0.0
    z_3_2_3_1         DAY_3_2_3       1.0
    z_3_2_3_1         REQ_3_2         1.0
    z_3_2_3_1         OCC_2_3_1       -1.0
    z_3_2_3_1         CLS_3_3_1       -1.0
    z_3_2_3_2         OBJ           0.0
    z_3_2_3_2         DAY_3_2_3       1.0
    z_3_2_3_2         REQ_3_2         1.0
    z_3_2_3_2         OCC_2_3_2       -1.0
    z_3_2_3_2         CLS_3_3_2       -1.0
    z_3_2_3_3         OBJ           0.0
    z_3_2_3_3         DAY_3_2_3       1.0
    z_3_2_3_3         REQ_3_2         1.0
    z_3_2_3_3         OCC_2_3_3       -1.0
    z_3_2_3_3         CLS_3_3_3       -1.0
    z_3_2_3_4         OBJ           0.0
    z_3_2_3_4         DAY_3_2_3       1.0
    z_3_2_3_4         REQ_3_2         1.0
    z_3_2_3_4         OCC_2_3_4       -1.0
    z_3_2_3_4         CLS_3_3_4       -1.0
    z_3_2_3_5         OBJ           0.0
    z_3_2_3_5         DAY_3_2_3       1.0
    z_3_2_3_5         REQ_3_2         1.0
    z_3_2_3_5         OCC_2_3_5       -1.0
    z_3_2_3_5         CLS_3_3_5       -1.0
    z_3_2_3_6         OBJ           0.0
    z_3_2_3_6         DAY_3_2_3       1.0
    z_3_2_3_6         REQ_3_2         2.0
    z_3_2_3_6         OCC_2_3_0       -1.0
    z_3_2_3_6         OCC_2_3_1       -1.0
    z_3_2_3_6         CLS_3_3_0       -1.0
    z_3_2_3_6         CLS_3_3_1       -1.0
    z_3_2_3_7         OBJ           0.0
    z_3_2_3_7         DAY_3_2_3       1.0
    z_3_2_3_7         REQ_3_2         2.0
    z_3_2_3_7         OCC_2_3_1       -1.0
    z_3_2_3_7         OCC_2_3_2       -1.0
    z_3_2_3_7         CLS_3_3_1       -1.0
    z_3_2_3_7         CLS_3_3_2       -1.0
    z_3_2_3_8         OBJ           0.0
    z_3_2_3_8         DAY_3_2_3       1.0
    z_3_2_3_8         REQ_3_2         2.0
    z_3_2_3_8         OCC_2_3_2       -1.0
    z_3_2_3_8         OCC_2_3_3       -1.0
    z_3_2_3_8         CLS_3_3_2       -1.0
    z_3_2_3_8         CLS_3_3_3       -1.0
    z_3_2_3_9         OBJ           0.0
    z_3_2_3_9         DAY_3_2_3       1.0
    z_3_2_3_9         REQ_3_2         2.0
    z_3_2_3_9         OCC_2_3_3       -1.0
    z_3_2_3_9         OCC_2_3_4       -1.0
    z_3_2_3_9         CLS_3_3_3       -1.0
    z_3_2_3_9         CLS_3_3_4       -1.0
    z_3_2_3_10        OBJ           0.0
    z_3_2_3_10        DAY_3_2_3       1.0
    z_3_2_3_10        REQ_3_2         2.0
    z_3_2_3_10        OCC_2_3_4       -1.0
    z_3_2_3_10        OCC_2_3_5       -1.0
    z_3_2_3_10        CLS_3_3_4       -1.0
    z_3_2_3_10        CLS_3_3_5       -1.0
    z_3_2_4_0         OBJ           0.0
    z_3_2_4_0         DAY_3_2_4       1.0
    z_3_2_4_0         REQ_3_2         1.0
    z_3_2_4_0         OCC_2_4_0       -1.0
    z_3_2_4_0         CLS_3_4_0       -1.0
    z_3_2_4_1         OBJ           0.0
    z_3_2_4_1         DAY_3_2_4       1.0
    z_3_2_4_1         REQ_3_2         1.0
    z_3_2_4_1         OCC_2_4_2       -1.0
    z_3_2_4_1         CLS_3_4_2       -1.0
    z_3_2_4_2         OBJ           0.0
    z_3_2_4_2         DAY_3_2_4       1.0
    z_3_2_4_2         REQ_3_2         1.0
    z_3_2_4_2         OCC_2_4_3       -1.0
    z_3_2_4_2         CLS_3_4_3       -1.0
    z_3_2_4_3         OBJ           0.0
    z_3_2_4_3         DAY_3_2_4       1.0
    z_3_2_4_3         REQ_3_2         1.0
    z_3_2_4_3         OCC_2_4_5       -1.0
    z_3_2_4_3         CLS_3_4_5       -1.0
    z_3_2_4_4         OBJ           0.0
    z_3_2_4_4         DAY_3_2_4       1.0
    z_3_2_4_4         REQ_3_2         2.0
    z_3_2_4_4         OCC_2_4_2       -1.0
    z_3_2_4_4         OCC_2_4_3       -1.0
    z_3_2_4_4         CLS_3_4_2       -1.0
    z_3_2_4_4         CLS_3_4_3       -1.0
    z_3_5_0_0         OBJ           0.0
    z_3_5_0_0         DAY_3_5_0       1.0
    z_3_5_0_0         REQ_3_5         1.0
    z_3_5_0_0         OCC_5_0_0       -1.0
    z_3_5_0_0         CLS_3_0_0       -1.0
    z_3_5_0_1         OBJ           0.0
    z_3_5_0_1         DAY_3_5_0       1.0
    z_3_5_0_1         REQ_3_5         1.0
    z_3_5_0_1         OCC_5_0_1       -1.0
    z_3_5_0_1         CLS_3_0_1       -1.0
    z_3_5_0_2         OBJ           0.0
    z_3_5_0_2         DAY_3_5_0       1.0
    z_3_5_0_2         REQ_3_5         1.0
    z_3_5_0_2         OCC_5_0_2       -1.0
    z_3_5_0_2         CLS_3_0_2       -1.0
    z_3_5_0_3         OBJ           0.0
    z_3_5_0_3         DAY_3_5_0       1.0
    z_3_5_0_3         REQ_3_5         1.0
    z_3_5_0_3         OCC_5_0_3       -1.0
    z_3_5_0_3         CLS_3_0_3       -1.0
    z_3_5_0_4         OBJ           0.0
    z_3_5_0_4         DAY_3_5_0       1.0
    z_3_5_0_4         REQ_3_5         1.0
    z_3_5_0_4         OCC_5_0_4       -1.0
    z_3_5_0_4         CLS_3_0_4       -1.0
    z_3_5_0_5         OBJ           0.0
    z_3_5_0_5         DAY_3_5_0       1.0
    z_3_5_0_5         REQ_3_5         1.0
    z_3_5_0_5         OCC_5_0_5       -1.0
    z_3_5_0_5         CLS_3_0_5       -1.0
    z_3_5_0_6         OBJ           0.0
    z_3_5_0_6         DAY_3_5_0       1.0
    z_3_5_0_6         REQ_3_5         2.0
    z_3_5_0_6         OCC_5_0_0       -1.0
    z_3_5_0_6         OCC_5_0_1       -1.0
    z_3_5_0_6         CLS_3_0_0       -1.0
    z_3_5_0_6         CLS_3_0_1       -1.0
    z_3_5_0_7         OBJ           0.0
    z_3_5_0_7         DAY_3_5_0       1.0
    z_3_5_0_7         REQ_3_5         2.0
    z_3_5_0_7         OCC_5_0_1       -1.0
    z_3_5_0_7         OCC_5_0_2       -1.0
    z_3_5_0_7         CLS_3_0_1       -1.0
    z_3_5_0_7         CLS_3_0_2       -1.0
    z_3_5_0_8         OBJ           0.0
    z_3_5_0_8         DAY_3_5_0       1.0
    z_3_5_0_8         REQ_3_5         2.0
    z_3_5_0_8         OCC_5_0_2       -1.0
    z_3_5_0_8         OCC_5_0_3       -1.0
    z_3_5_0_8         CLS_3_0_2       -1.0
    z_3_5_0_8         CLS_3_0_3       -1.0
    z_3_5_0_9         OBJ           0.0
    z_3_5_0_9         DAY_3_5_0       1.0
    z_3_5_0_9         REQ_3_5         2.0
    z_3_5_0_9         OCC_5_0_3       -1.0
    z_3_5_0_9         OCC_5_0_4       -1.0
    z_3_5_0_9         CLS_3_0_3       -1.0
    z_3_5_0_9         CLS_3_0_4       -1.0
    z_3_5_0_10        OBJ           0.0
    z_3_5_0_10        DAY_3_5_0       1.0
    z_3_5_0_10        REQ_3_5         2.0
    z_3_5_0_10        OCC_5_0_4       -1.0
    z_3_5_0_10        OCC_5_0_5       -1.0
    z_3_5_0_10        CLS_3_0_4       -1.0
    z_3_5_0_10        CLS_3_0_5       -1.0
    z_3_5_1_0         OBJ           0.0
    z_3_5_1_0         DAY_3_5_1       1.0
    z_3_5_1_0         REQ_3_5         1.0
    z_3_5_1_0         OCC_5_1_0       -1.0
    z_3_5_1_0         CLS_3_1_0       -1.0
    z_3_5_1_1         OBJ           0.0
    z_3_5_1_1         DAY_3_5_1       1.0
    z_3_5_1_1         REQ_3_5         1.0
    z_3_5_1_1         OCC_5_1_2       -1.0
    z_3_5_1_1         CLS_3_1_2       -1.0
    z_3_5_1_2         OBJ           0.0
    z_3_5_1_2         DAY_3_5_1       1.0
    z_3_5_1_2         REQ_3_5         1.0
    z_3_5_1_2         OCC_5_1_3       -1.0
    z_3_5_1_2         CLS_3_1_3       -1.0
    z_3_5_1_3         OBJ           0.0
    z_3_5_1_3         DAY_3_5_1       1.0
    z_3_5_1_3         REQ_3_5         1.0
    z_3_5_1_3         OCC_5_1_4       -1.0
    z_3_5_1_3         CLS_3_1_4       -1.0
    z_3_5_1_4         OBJ           0.0
    z_3_5_1_4         DAY_3_5_1       1.0
    z_3_5_1_4         REQ_3_5         1.0
    z_3_5_1_4         OCC_5_1_5       -1.0
    z_3_5_1_4         CLS_3_1_5       -1.0
    z_3_5_1_5         OBJ           0.0
    z_3_5_1_5         DAY_3_5_1       1.0
    z_3_5_1_5         REQ_3_5         2.0
    z_3_5_1_5         OCC_5_1_2       -1.0
    z_3_5_1_5         OCC_5_1_3       -1.0
    z_3_5_1_5         CLS_3_1_2       -1.0
    z_3_5_1_5         CLS_3_1_3       -1.0
    z_3_5_1_6         OBJ           0.0
    z_3_5_1_6         DAY_3_5_1       1.0
    z_3_5_1_6         REQ_3_5         2.0
    z_3_5_1_6         OCC_5_1_3       -1.0
    z_3_5_1_6         OCC_5_1_4       -1.0
    z_3_5_1_6         CLS_3_1_3       -1.0
    z_3_5_1_6         CLS_3_1_4       -1.0
    z_3_5_1_7         OBJ           0.0
    z_3_5_1_7         DAY_3_5_1       1.0
    z_3_5_1_7         REQ_3_5         2.0
    z_3_5_1_7         OCC_5_1_4       -1.0
    z_3_5_1_7         OCC_5_1_5       -1.0
    z_3_5_1_7         CLS_3_1_4       -1.0
    z_3_5_1_7         CLS_3_1_5       -1.0
    z_3_5_2_0         OBJ           0.0
    z_3_5_2_0         DAY_3_5_2       1.0
    z_3_5_2_0         REQ_3_5         1.0
    z_3_5_2_0         OCC_5_2_0       -1.0
    z_3_5_2_0         CLS_3_2_0       -1.0
    z_3_5_2_1         OBJ           0.0
    z_3_5_2_1         DAY_3_5_2       1.0
    z_3_5_2_1         REQ_3_5         1.0
    z_3_5_2_1         OCC_5_2_1       -1.0
    z_3_5_2_1         CLS_3_2_1       -1.0
    z_3_5_2_2         OBJ           0.0
    z_3_5_2_2         DAY_3_5_2       1.0
    z_3_5_2_2         REQ_3_5         1.0
    z_3_5_2_2         OCC_5_2_2       -1.0
    z_3_5_2_2         CLS_3_2_2       -1.0
    z_3_5_2_3         OBJ           0.0
    z_3_5_2_3         DAY_3_5_2       1.0
    z_3_5_2_3         REQ_3_5         1.0
    z_3_5_2_3         OCC_5_2_4       -1.0
    z_3_5_2_3         CLS_3_2_4       -1.0
    z_3_5_2_4         OBJ           0.0
    z_3_5_2_4         DAY_3_5_2       1.0
    z_3_5_2_4         REQ_3_5         1.0
    z_3_5_2_4         OCC_5_2_5       -1.0
    z_3_5_2_4         CLS_3_2_5       -1.0
    z_3_5_2_5         OBJ           0.0
    z_3_5_2_5         DAY_3_5_2       1.0
    z_3_5_2_5         REQ_3_5         2.0
    z_3_5_2_5         OCC_5_2_0       -1.0
    z_3_5_2_5         OCC_5_2_1       -1.0
    z_3_5_2_5         CLS_3_2_0       -1.0
    z_3_5_2_5         CLS_3_2_1       -1.0
    z_3_5_2_6         OBJ           0.0
    z_3_5_2_6         DAY_3_5_2       1.0
    z_3_5_2_6         REQ_3_5         2.0
    z_3_5_2_6         OCC_5_2_1       -1.0
    z_3_5_2_6         OCC_5_2_2       -1.0
    z_3_5_2_6         CLS_3_2_1       -1.0
    z_3_5_2_6         CLS_3_2_2       -1.0
    z_3_5_2_7         OBJ           0.0
    z_3_5_2_7         DAY_3_5_2       1.0
    z_3_5_2_7         REQ_3_5         2.0
    z_3_5_2_7         OCC_5_2_4       -1.0
    z_3_5_2_7         OCC_5_2_5       -1.0
    z_3_5_2_7         CLS_3_2_4       -1.0
    z_3_5_2_7         CLS_3_2_5       -1.0
    z_3_5_3_0         OBJ           0.0
    z_3_5_3_0         DAY_3_5_3       1.0
    z_3_5_3_0         REQ_3_5         1.0
    z_3_5_3_0         OCC_5_3_0       -1.0
    z_3_5_3_0         CLS_3_3_0       -1.0
    z_3_5_3_1         OBJ           0.0
    z_3_5_3_1         DAY_3_5_3       1.0
    z_3_5_3_1         REQ_3_5         1.0
    z_3_5_3_1         OCC_5_3_1       -1.0
    z_3_5_3_1         CLS_3_3_1       -1.0
    z_3_5_3_2         OBJ           0.0
    z_3_5_3_2         DAY_3_5_3       1.0
    z_3_5_3_2         REQ_3_5         1.0
    z_3_5_3_2         OCC_5_3_2       -1.0
    z_3_5_3_2         CLS_3_3_2       -1.0
    z_3_5_3_3         OBJ           0.0
    z_3_5_3_3         DAY_3_5_3       1.0
    z_3_5_3_3         REQ_3_5         1.0
    z_3_5_3_3         OCC_5_3_3       -1.0
    z_3_5_3_3         CLS_3_3_3       -1.0
    z_3_5_3_4         OBJ           0.0
    z_3_5_3_4         DAY_3_5_3       1.0
    z_3_5_3_4         REQ_3_5         1.0
    z_3_5_3_4         OCC_5_3_4       -1.0
    z_3_5_3_4         CLS_3_3_4       -1.0
    z_3_5_3_5         OBJ           0.0
    z_3_5_3_5         DAY_3_5_3       1.0
    z_3_5_3_5         REQ_3_5         1.0
    z_3_5_3_5         OCC_5_3_5       -1.0
    z_3_5_3_5         CLS_3_3_5       -1.0
    z_3_5_3_6         OBJ           0.0
    z_3_5_3_6         DAY_3_5_3       1.0
    z_3_5_3_6         REQ_3_5         2.0
    z_3_5_3_6         OCC_5_3_0       -1.0
    z_3_5_3_6         OCC_5_3_1       -1.0
    z_3_5_3_6         CLS_3_3_0       -1.0
    z_3_5_3_6         CLS_3_3_1       -1.0
    z_3_5_3_7         OBJ           0.0
    z_3_5_3_7         DAY_3_5_3       1.0
    z_3_5_3_7         REQ_3_5         2.0
    z_3_5_3_7         OCC_5_3_1       -1.0
    z_3_5_3_7         OCC_5_3_2       -1.0
    z_3_5_3_7         CLS_3_3_1       -1.0
    z_3_5_3_7         CLS_3_3_2       -1.0
    z_3_5_3_8         OBJ           0.0
    z_3_5_3_8         DAY_3_5_3       1.0
    z_3_5_3_8         REQ_3_5         2.0
    z_3_5_3_8         OCC_5_3_2       -1.0
    z_3_5_3_8         OCC_5_3_3       -1.0
    z_3_5_3_8         CLS_3_3_2       -1.0
    z_3_5_3_8         CLS_3_3_3       -1.0
    z_3_5_3_9         OBJ           0.0
    z_3_5_3_9         DAY_3_5_3       1.0
    z_3_5_3_9         REQ_3_5         2.0
    z_3_5_3_9         OCC_5_3_3       -1.0
    z_3_5_3_9         OCC_5_3_4       -1.0
    z_3_5_3_9         CLS_3_3_3       -1.0
    z_3_5_3_9         CLS_3_3_4       -1.0
    z_3_5_3_10        OBJ           0.0
    z_3_5_3_10        DAY_3_5_3       1.0
    z_3_5_3_10        REQ_3_5         2.0
    z_3_5_3_10        OCC_5_3_4       -1.0
    z_3_5_3_10        OCC_5_3_5       -1.0
    z_3_5_3_10        CLS_3_3_4       -1.0
    z_3_5_3_10        CLS_3_3_5       -1.0
    z_3_6_0_0         OBJ           0.0
    z_3_6_0_0         DAY_3_6_0       1.0
    z_3_6_0_0         REQ_3_6         1.0
    z_3_6_0_0         OCC_6_0_0       -1.0
    z_3_6_0_0         CLS_3_0_0       -1.0
    z_3_6_0_1         OBJ           0.0
    z_3_6_0_1         DAY_3_6_0       1.0
    z_3_6_0_1         REQ_3_6         1.0
    z_3_6_0_1         OCC_6_0_1       -1.0
    z_3_6_0_1         CLS_3_0_1       -1.0
    z_3_6_0_2         OBJ           0.0
    z_3_6_0_2         DAY_3_6_0       1.0
    z_3_6_0_2         REQ_3_6         1.0
    z_3_6_0_2         OCC_6_0_2       -1.0
    z_3_6_0_2         CLS_3_0_2       -1.0
    z_3_6_0_3         OBJ           0.0
    z_3_6_0_3         DAY_3_6_0       1.0
    z_3_6_0_3         REQ_3_6         1.0
    z_3_6_0_3         OCC_6_0_3       -1.0
    z_3_6_0_3         CLS_3_0_3       -1.0
    z_3_6_0_4         OBJ           0.0
    z_3_6_0_4         DAY_3_6_0       1.0
    z_3_6_0_4         REQ_3_6         1.0
    z_3_6_0_4         OCC_6_0_4       -1.0
    z_3_6_0_4         CLS_3_0_4       -1.0
    z_3_6_0_5         OBJ           0.0
    z_3_6_0_5         DAY_3_6_0       1.0
    z_3_6_0_5         REQ_3_6         1.0
    z_3_6_0_5         OCC_6_0_5       -1.0
    z_3_6_0_5         CLS_3_0_5       -1.0
    z_3_6_0_6         OBJ           0.0
    z_3_6_0_6         DAY_3_6_0       1.0
    z_3_6_0_6         REQ_3_6         2.0
    z_3_6_0_6         OCC_6_0_0       -1.0
    z_3_6_0_6         OCC_6_0_1       -1.0
    z_3_6_0_6         CLS_3_0_0       -1.0
    z_3_6_0_6         CLS_3_0_1       -1.0
    z_3_6_0_7         OBJ           0.0
    z_3_6_0_7         DAY_3_6_0       1.0
    z_3_6_0_7         REQ_3_6         2.0
    z_3_6_0_7         OCC_6_0_1       -1.0
    z_3_6_0_7         OCC_6_0_2       -1.0
    z_3_6_0_7         CLS_3_0_1       -1.0
    z_3_6_0_7         CLS_3_0_2       -1.0
    z_3_6_0_8         OBJ           0.0
    z_3_6_0_8         DAY_3_6_0       1.0
    z_3_6_0_8         REQ_3_6         2.0
    z_3_6_0_8         OCC_6_0_2       -1.0
    z_3_6_0_8         OCC_6_0_3       -1.0
    z_3_6_0_8         CLS_3_0_2       -1.0
    z_3_6_0_8         CLS_3_0_3       -1.0
    z_3_6_0_9         OBJ           0.0
    z_3_6_0_9         DAY_3_6_0       1.0
    z_3_6_0_9         REQ_3_6         2.0
    z_3_6_0_9         OCC_6_0_3       -1.0
    z_3_6_0_9         OCC_6_0_4       -1.0
    z_3_6_0_9         CLS_3_0_3       -1.0
    z_3_6_0_9         CLS_3_0_4       -1.0
    z_3_6_0_10        OBJ           0.0
    z_3_6_0_10        DAY_3_6_0       1.0
    z_3_6_0_10        REQ_3_6         2.0
    z_3_6_0_10        OCC_6_0_4       -1.0
    z_3_6_0_10        OCC_6_0_5       -1.0
    z_3_6_0_10        CLS_3_0_4       -1.0
    z_3_6_0_10        CLS_3_0_5       -1.0
    z_3_6_1_0         OBJ           0.0
    z_3_6_1_0         DAY_3_6_1       1.0
    z_3_6_1_0         REQ_3_6         1.0
    z_3_6_1_0         OCC_6_1_0       -1.0
    z_3_6_1_0         CLS_3_1_0       -1.0
    z_3_6_1_1         OBJ           0.0
    z_3_6_1_1         DAY_3_6_1       1.0
    z_3_6_1_1         REQ_3_6         1.0
    z_3_6_1_1         OCC_6_1_1       -1.0
    z_3_6_1_1         CLS_3_1_1       -1.0
    z_3_6_1_2         OBJ           0.0
    z_3_6_1_2         DAY_3_6_1       1.0
    z_3_6_1_2         REQ_3_6         1.0
    z_3_6_1_2         OCC_6_1_2       -1.0
    z_3_6_1_2         CLS_3_1_2       -1.0
    z_3_6_1_3         OBJ           0.0
    z_3_6_1_3         DAY_3_6_1       1.0
    z_3_6_1_3         REQ_3_6         1.0
    z_3_6_1_3         OCC_6_1_3       -1.0
    z_3_6_1_3         CLS_3_1_3       -1.0
    z_3_6_1_4         OBJ           0.0
    z_3_6_1_4         DAY_3_6_1       1.0
    z_3_6_1_4         REQ_3_6         1.0
    z_3_6_1_4         OCC_6_1_4       -1.0
    z_3_6_1_4         CLS_3_1_4       -1.0
    z_3_6_1_5         OBJ           0.0
    z_3_6_1_5         DAY_3_6_1       1.0
    z_3_6_1_5         REQ_3_6         1.0
    z_3_6_1_5         OCC_6_1_5       -1.0
    z_3_6_1_5         CLS_3_1_5       -1.0
    z_3_6_1_6         OBJ           0.0
    z_3_6_1_6         DAY_3_6_1       1.0
    z_3_6_1_6         REQ_3_6         2.0
    z_3_6_1_6         OCC_6_1_0       -1.0
    z_3_6_1_6         OCC_6_1_1       -1.0
    z_3_6_1_6         CLS_3_1_0       -1.0
    z_3_6_1_6         CLS_3_1_1       -1.0
    z_3_6_1_7         OBJ           0.0
    z_3_6_1_7         DAY_3_6_1       1.0
    z_3_6_1_7         REQ_3_6         2.0
    z_3_6_1_7         OCC_6_1_1       -1.0
    z_3_6_1_7         OCC_6_1_2       -1.0
    z_3_6_1_7         CLS_3_1_1       -1.0
    z_3_6_1_7         CLS_3_1_2       -1.0
    z_3_6_1_8         OBJ           0.0
    z_3_6_1_8         DAY_3_6_1       1.0
    z_3_6_1_8         REQ_3_6         2.0
    z_3_6_1_8         OCC_6_1_2       -1.0
    z_3_6_1_8         OCC_6_1_3       -1.0
    z_3_6_1_8         CLS_3_1_2       -1.0
    z_3_6_1_8         CLS_3_1_3       -1.0
    z_3_6_1_9         OBJ           0.0
    z_3_6_1_9         DAY_3_6_1       1.0
    z_3_6_1_9         REQ_3_6         2.0
    z_3_6_1_9         OCC_6_1_3       -1.0
    z_3_6_1_9         OCC_6_1_4       -1.0
    z_3_6_1_9         CLS_3_1_3       -1.0
    z_3_6_1_9         CLS_3_1_4       -1.0
    z_3_6_1_10        OBJ           0.0
    z_3_6_1_10        DAY_3_6_1       1.0
    z_3_6_1_10        REQ_3_6         2.0
    z_3_6_1_10        OCC_6_1_4       -1.0
    z_3_6_1_10        OCC_6_1_5       -1.0
    z_3_6_1_10        CLS_3_1_4       -1.0
    z_3_6_1_10        CLS_3_1_5       -1.0
    z_3_6_2_0         OBJ           0.0
    z_3_6_2_0         DAY_3_6_2       1.0
    z_3_6_2_0         REQ_3_6         1.0
    z_3_6_2_0         OCC_6_2_0       -1.0
    z_3_6_2_0         CLS_3_2_0       -1.0
    z_3_6_2_1         OBJ           0.0
    z_3_6_2_1         DAY_3_6_2       1.0
    z_3_6_2_1         REQ_3_6         1.0
    z_3_6_2_1         OCC_6_2_1       -1.0
    z_3_6_2_1         CLS_3_2_1       -1.0
    z_3_6_2_2         OBJ           0.0
    z_3_6_2_2         DAY_3_6_2       1.0
    z_3_6_2_2         REQ_3_6         1.0
    z_3_6_2_2         OCC_6_2_2       -1.0
    z_3_6_2_2         CLS_3_2_2       -1.0
    z_3_6_2_3         OBJ           0.0
    z_3_6_2_3         DAY_3_6_2       1.0
    z_3_6_2_3         REQ_3_6         1.0
    z_3_6_2_3         OCC_6_2_3       -1.0
    z_3_6_2_3         CLS_3_2_3       -1.0
    z_3_6_2_4         OBJ           0.0
    z_3_6_2_4         DAY_3_6_2       1.0
    z_3_6_2_4         REQ_3_6         1.0
    z_3_6_2_4         OCC_6_2_4       -1.0
    z_3_6_2_4         CLS_3_2_4       -1.0
    z_3_6_2_5         OBJ           0.0
    z_3_6_2_5         DAY_3_6_2       1.0
    z_3_6_2_5         REQ_3_6         2.0
    z_3_6_2_5         OCC_6_2_0       -1.0
    z_3_6_2_5         OCC_6_2_1       -1.0
    z_3_6_2_5         CLS_3_2_0       -1.0
    z_3_6_2_5         CLS_3_2_1       -1.0
    z_3_6_2_6         OBJ           0.0
    z_3_6_2_6         DAY_3_6_2       1.0
    z_3_6_2_6         REQ_3_6         2.0
    z_3_6_2_6         OCC_6_2_1       -1.0
    z_3_6_2_6         OCC_6_2_2       -1.0
    z_3_6_2_6         CLS_3_2_1       -1.0
    z_3_6_2_6         CLS_3_2_2       -1.0
    z_3_6_2_7         OBJ           0.0
    z_3_6_2_7         DAY_3_6_2       1.0
    z_3_6_2_7         REQ_3_6         2.0
    z_3_6_2_7         OCC_6_2_2       -1.0
    z_3_6_2_7         OCC_6_2_3       -1.0
    z_3_6_2_7         CLS_3_2_2       -1.0
    z_3_6_2_7         CLS_3_2_3       -1.0
    z_3_6_2_8         OBJ           0.0
    z_3_6_2_8         DAY_3_6_2       1.0
    z_3_6_2_8         REQ_3_6         2.0
    z_3_6_2_8         OCC_6_2_3       -1.0
    z_3_6_2_8         OCC_6_2_4       -1.0
    z_3_6_2_8         CLS_3_2_3       -1.0
    z_3_6_2_8         CLS_3_2_4       -1.0
    z_3_6_3_0         OBJ           0.0
    z_3_6_3_0         DAY_3_6_3       1.0
    z_3_6_3_0         REQ_3_6         1.0
    z_3_6_3_0         OCC_6_3_0       -1.0
    z_3_6_3_0         CLS_3_3_0       -1.0
    z_3_6_3_1         OBJ           0.0
    z_3_6_3_1         DAY_3_6_3       1.0
    z_3_6_3_1         REQ_3_6         1.0
    z_3_6_3_1         OCC_6_3_1       -1.0
    z_3_6_3_1         CLS_3_3_1       -1.0
    z_3_6_3_2         OBJ           0.0
    z_3_6_3_2         DAY_3_6_3       1.0
    z_3_6_3_2         REQ_3_6         1.0
    z_3_6_3_2         OCC_6_3_2       -1.0
    z_3_6_3_2         CLS_3_3_2       -1.0
    z_3_6_3_3         OBJ           0.0
    z_3_6_3_3         DAY_3_6_3       1.0
    z_3_6_3_3         REQ_3_6         1.0
    z_3_6_3_3         OCC_6_3_3       -1.0
    z_3_6_3_3         CLS_3_3_3       -1.0
    z_3_6_3_4         OBJ           0.0
    z_3_6_3_4         DAY_3_6_3       1.0
    z_3_6_3_4         REQ_3_6         1.0
    z_3_6_3_4         OCC_6_3_5       -1.0
    z_3_6_3_4         CLS_3_3_5       -1.0
    z_3_6_3_5         OBJ           0.0
    z_3_6_3_5         DAY_3_6_3       1.0
    z_3_6_3_5         REQ_3_6         2.0
    z_3_6_3_5         OCC_6_3_0       -1.0
    z_3_6_3_5         OCC_6_3_1       -1.0
    z_3_6_3_5         CLS_3_3_0       -1.0
    z_3_6_3_5         CLS_3_3_1       -1.0
    z_3_6_3_6         OBJ           0.0
    z_3_6_3_6         DAY_3_6_3       1.0
    z_3_6_3_6         REQ_3_6         2.0
    z_3_6_3_6         OCC_6_3_1       -1.0
    z_3_6_3_6         OCC_6_3_2       -1.0
    z_3_6_3_6         CLS_3_3_1       -1.0
    z_3_6_3_6         CLS_3_3_2       -1.0
    z_3_6_3_7         OBJ           0.0
    z_3_6_3_7         DAY_3_6_3       1.0
    z_3_6_3_7         REQ_3_6         2.0
    z_3_6_3_7         OCC_6_3_2       -1.0
    z_3_6_3_7         OCC_6_3_3       -1.0
    z_3_6_3_7         CLS_3_3_2       -1.0
    z_3_6_3_7         CLS_3_3_3       -1.0
    z_3_6_4_0         OBJ           0.0
    z_3_6_4_0         DAY_3_6_4       1.0
    z_3_6_4_0         REQ_3_6         1.0
    z_3_6_4_0         OCC_6_4_0       -1.0
    z_3_6_4_0         CLS_3_4_0       -1.0
    z_3_6_4_1         OBJ           0.0
    z_3_6_4_1         DAY_3_6_4       1.0
    z_3_6_4_1         REQ_3_6         1.0
    z_3_6_4_1         OCC_6_4_1       -1.0
    z_3_6_4_1         CLS_3_4_1       -1.0
    z_3_6_4_2         OBJ           0.0
    z_3_6_4_2         DAY_3_6_4       1.0
    z_3_6_4_2         REQ_3_6         1.0
    z_3_6_4_2         OCC_6_4_2       -1.0
    z_3_6_4_2         CLS_3_4_2       -1.0
    z_3_6_4_3         OBJ           0.0
    z_3_6_4_3         DAY_3_6_4       1.0
    z_3_6_4_3         REQ_3_6         1.0
    z_3_6_4_3         OCC_6_4_3       -1.0
    z_3_6_4_3         CLS_3_4_3       -1.0
    z_3_6_4_4         OBJ           0.0
    z_3_6_4_4         DAY_3_6_4       1.0
    z_3_6_4_4         REQ_3_6         1.0
    z_3_6_4_4         OCC_6_4_4       -1.0
    z_3_6_4_4         CLS_3_4_4       -1.0
    z_3_6_4_5         OBJ           0.0
    z_3_6_4_5         DAY_3_6_4       1.0
    z_3_6_4_5         REQ_3_6         1.0
    z_3_6_4_5         OCC_6_4_5       -1.0
    z_3_6_4_5         CLS_3_4_5       -1.0
    z_3_6_4_6         OBJ           0.0
    z_3_6_4_6         DAY_3_6_4       1.0
    z_3_6_4_6         REQ_3_6         2.0
    z_3_6_4_6         OCC_6_4_0       -1.0
    z_3_6_4_6         OCC_6_4_1       -1.0
    z_3_6_4_6         CLS_3_4_0       -1.0
    z_3_6_4_6         CLS_3_4_1       -1.0
    z_3_6_4_7         OBJ           0.0
    z_3_6_4_7         DAY_3_6_4       1.0
    z_3_6_4_7         REQ_3_6         2.0
    z_3_6_4_7         OCC_6_4_1       -1.0
    z_3_6_4_7         OCC_6_4_2       -1.0
    z_3_6_4_7         CLS_3_4_1       -1.0
    z_3_6_4_7         CLS_3_4_2       -1.0
    z_3_6_4_8         OBJ           0.0
    z_3_6_4_8         DAY_3_6_4       1.0
    z_3_6_4_8         REQ_3_6         2.0
    z_3_6_4_8         OCC_6_4_2       -1.0
    z_3_6_4_8         OCC_6_4_3       -1.0
    z_3_6_4_8         CLS_3_4_2       -1.0
    z_3_6_4_8         CLS_3_4_3       -1.0
    z_3_6_4_9         OBJ           0.0
    z_3_6_4_9         DAY_3_6_4       1.0
    z_3_6_4_9         REQ_3_6         2.0
    z_3_6_4_9         OCC_6_4_3       -1.0
    z_3_6_4_9         OCC_6_4_4       -1.0
    z_3_6_4_9         CLS_3_4_3       -1.0
    z_3_6_4_9         CLS_3_4_4       -1.0
    z_3_6_4_10        OBJ           0.0
    z_3_6_4_10        DAY_3_6_4       1.0
    z_3_6_4_10        REQ_3_6         2.0
    z_3_6_4_10        OCC_6_4_4       -1.0
    z_3_6_4_10        OCC_6_4_5       -1.0
    z_3_6_4_10        CLS_3_4_4       -1.0
    z_3_6_4_10        CLS_3_4_5       -1.0
    z_3_7_0_0         OBJ           0.0
    z_3_7_0_0         DAY_3_7_0       1.0
    z_3_7_0_0         REQ_3_7         1.0
    z_3_7_0_0         OCC_7_0_0       -1.0
    z_3_7_0_0         CLS_3_0_0       -1.0
    z_3_7_0_1         OBJ           0.0
    z_3_7_0_1         DAY_3_7_0       1.0
    z_3_7_0_1         REQ_3_7         1.0
    z_3_7_0_1         OCC_7_0_1       -1.0
    z_3_7_0_1         CLS_3_0_1       -1.0
    z_3_7_0_2         OBJ           0.0
    z_3_7_0_2         DAY_3_7_0       1.0
    z_3_7_0_2         REQ_3_7         1.0
    z_3_7_0_2         OCC_7_0_2       -1.0
    z_3_7_0_2         CLS_3_0_2       -1.0
    z_3_7_0_3         OBJ           0.0
    z_3_7_0_3         DAY_3_7_0       1.0
    z_3_7_0_3         REQ_3_7         1.0
    z_3_7_0_3         OCC_7_0_3       -1.0
    z_3_7_0_3         CLS_3_0_3       -1.0
    z_3_7_0_4         OBJ           0.0
    z_3_7_0_4         DAY_3_7_0       1.0
    z_3_7_0_4         REQ_3_7         1.0
    z_3_7_0_4         OCC_7_0_5       -1.0
    z_3_7_0_4         CLS_3_0_5       -1.0
    z_3_7_0_5         OBJ           0.0
    z_3_7_0_5         DAY_3_7_0       1.0
    z_3_7_0_5         REQ_3_7         2.0
    z_3_7_0_5         OCC_7_0_0       -1.0
    z_3_7_0_5         OCC_7_0_1       -1.0
    z_3_7_0_5         CLS_3_0_0       -1.0
    z_3_7_0_5         CLS_3_0_1       -1.0
    z_3_7_0_6         OBJ           0.0
    z_3_7_0_6         DAY_3_7_0       1.0
    z_3_7_0_6         REQ_3_7         2.0
    z_3_7_0_6         OCC_7_0_1       -1.0
    z_3_7_0_6         OCC_7_0_2       -1.0
    z_3_7_0_6         CLS_3_0_1       -1.0
    z_3_7_0_6         CLS_3_0_2       -1.0
    z_3_7_0_7         OBJ           0.0
    z_3_7_0_7         DAY_3_7_0       1.0
    z_3_7_0_7         REQ_3_7         2.0
    z_3_7_0_7         OCC_7_0_2       -1.0
    z_3_7_0_7         OCC_7_0_3       -1.0
    z_3_7_0_7         CLS_3_0_2       -1.0
    z_3_7_0_7         CLS_3_0_3       -1.0
    z_3_7_1_0         OBJ           0.0
    z_3_7_1_0         DAY_3_7_1       1.0
    z_3_7_1_0         REQ_3_7         1.0
    z_3_7_1_0         OCC_7_1_0       -1.0
    z_3_7_1_0         CLS_3_1_0       -1.0
    z_3_7_1_1         OBJ           0.0
    z_3_7_1_1         DAY_3_7_1       1.0
    z_3_7_1_1         REQ_3_7         1.0
    z_3_7_1_1         OCC_7_1_1       -1.0
    z_3_7_1_1         CLS_3_1_1       -1.0
    z_3_7_1_2         OBJ           0.0
    z_3_7_1_2         DAY_3_7_1       1.0
    z_3_7_1_2         REQ_3_7         1.0
    z_3_7_1_2         OCC_7_1_2       -1.0
    z_3_7_1_2         CLS_3_1_2       -1.0
    z_3_7_1_3         OBJ           0.0
    z_3_7_1_3         DAY_3_7_1       1.0
    z_3_7_1_3         REQ_3_7         1.0
    z_3_7_1_3         OCC_7_1_3       -1.0
    z_3_7_1_3         CLS_3_1_3       -1.0
    z_3_7_1_4         OBJ           0.0
    z_3_7_1_4         DAY_3_7_1       1.0
    z_3_7_1_4         REQ_3_7         1.0
    z_3_7_1_4         OCC_7_1_4       -1.0
    z_3_7_1_4         CLS_3_1_4       -1.0
    z_3_7_1_5         OBJ           0.0
    z_3_7_1_5         DAY_3_7_1       1.0
    z_3_7_1_5         REQ_3_7         1.0
    z_3_7_1_5         OCC_7_1_5       -1.0
    z_3_7_1_5         CLS_3_1_5       -1.0
    z_3_7_1_6         OBJ           0.0
    z_3_7_1_6         DAY_3_7_1       1.0
    z_3_7_1_6         REQ_3_7         2.0
    z_3_7_1_6         OCC_7_1_0       -1.0
    z_3_7_1_6         OCC_7_1_1       -1.0
    z_3_7_1_6         CLS_3_1_0       -1.0
    z_3_7_1_6         CLS_3_1_1       -1.0
    z_3_7_1_7         OBJ           0.0
    z_3_7_1_7         DAY_3_7_1       1.0
    z_3_7_1_7         REQ_3_7         2.0
    z_3_7_1_7         OCC_7_1_1       -1.0
    z_3_7_1_7         OCC_7_1_2       -1.0
    z_3_7_1_7         CLS_3_1_1       -1.0
    z_3_7_1_7         CLS_3_1_2       -1.0
    z_3_7_1_8         OBJ           0.0
    z_3_7_1_8         DAY_3_7_1       1.0
    z_3_7_1_8         REQ_3_7         2.0
    z_3_7_1_8         OCC_7_1_2       -1.0
    z_3_7_1_8         OCC_7_1_3       -1.0
    z_3_7_1_8         CLS_3_1_2       -1.0
    z_3_7_1_8         CLS_3_1_3       -1.0
    z_3_7_1_9         OBJ           0.0
    z_3_7_1_9         DAY_3_7_1       1.0
    z_3_7_1_9         REQ_3_7         2.0
    z_3_7_1_9         OCC_7_1_3       -1.0
    z_3_7_1_9         OCC_7_1_4       -1.0
    z_3_7_1_9         CLS_3_1_3       -1.0
    z_3_7_1_9         CLS_3_1_4       -1.0
    z_3_7_1_10        OBJ           0.0
    z_3_7_1_10        DAY_3_7_1       1.0
    z_3_7_1_10        REQ_3_7         2.0
    z_3_7_1_10        OCC_7_1_4       -1.0
    z_3_7_1_10        OCC_7_1_5       -1.0
    z_3_7_1_10        CLS_3_1_4       -1.0
    z_3_7_1_10        CLS_3_1_5       -1.0
    z_3_7_2_0         OBJ           0.0
    z_3_7_2_0         DAY_3_7_2       1.0
    z_3_7_2_0         REQ_3_7         1.0
    z_3_7_2_0         OCC_7_2_0       -1.0
    z_3_7_2_0         CLS_3_2_0       -1.0
    z_3_7_2_1         OBJ           0.0
    z_3_7_2_1         DAY_3_7_2       1.0
    z_3_7_2_1         REQ_3_7         1.0
    z_3_7_2_1         OCC_7_2_1       -1.0
    z_3_7_2_1         CLS_3_2_1       -1.0
    z_3_7_2_2         OBJ           0.0
    z_3_7_2_2         DAY_3_7_2       1.0
    z_3_7_2_2         REQ_3_7         1.0
    z_3_7_2_2         OCC_7_2_2       -1.0
    z_3_7_2_2         CLS_3_2_2       -1.0
    z_3_7_2_3         OBJ           0.0
    z_3_7_2_3         DAY_3_7_2       1.0
    z_3_7_2_3         REQ_3_7         1.0
    z_3_7_2_3         OCC_7_2_3       -1.0
    z_3_7_2_3         CLS_3_2_3       -1.0
    z_3_7_2_4         OBJ           0.0
    z_3_7_2_4         DAY_3_7_2       1.0
    z_3_7_2_4         REQ_3_7         1.0
    z_3_7_2_4         OCC_7_2_4       -1.0
    z_3_7_2_4         CLS_3_2_4       -1.0
    z_3_7_2_5         OBJ           0.0
    z_3_7_2_5         DAY_3_7_2       1.0
    z_3_7_2_5         REQ_3_7         1.0
    z_3_7_2_5         OCC_7_2_5       -1.0
    z_3_7_2_5         CLS_3_2_5       -1.0
    z_3_7_2_6         OBJ           0.0
    z_3_7_2_6         DAY_3_7_2       1.0
    z_3_7_2_6         REQ_3_7         2.0
    z_3_7_2_6         OCC_7_2_0       -1.0
    z_3_7_2_6         OCC_7_2_1       -1.0
    z_3_7_2_6         CLS_3_2_0       -1.0
    z_3_7_2_6         CLS_3_2_1       -1.0
    z_3_7_2_7         OBJ           0.0
    z_3_7_2_7         DAY_3_7_2       1.0
    z_3_7_2_7         REQ_3_7         2.0
    z_3_7_2_7         OCC_7_2_1       -1.0
    z_3_7_2_7         OCC_7_2_2       -1.0
    z_3_7_2_7         CLS_3_2_1       -1.0
    z_3_7_2_7         CLS_3_2_2       -1.0
    z_3_7_2_8         OBJ           0.0
    z_3_7_2_8         DAY_3_7_2       1.0
    z_3_7_2_8         REQ_3_7         2.0
    z_3_7_2_8         OCC_7_2_2       -1.0
    z_3_7_2_8         OCC_7_2_3       -1.0
    z_3_7_2_8         CLS_3_2_2       -1.0
    z_3_7_2_8         CLS_3_2_3       -1.0
    z_3_7_2_9         OBJ           0.0
    z_3_7_2_9         DAY_3_7_2       1.0
    z_3_7_2_9         REQ_3_7         2.0
    z_3_7_2_9         OCC_7_2_3       -1.0
    z_3_7_2_9         OCC_7_2_4       -1.0
    z_3_7_2_9         CLS_3_2_3       -1.0
    z_3_7_2_9         CLS_3_2_4       -1.0
    z_3_7_2_10        OBJ           0.0
    z_3_7_2_10        DAY_3_7_2       1.0
    z_3_7_2_10        REQ_3_7         2.0
    z_3_7_2_10        OCC_7_2_4       -1.0
    z_3_7_2_10        OCC_7_2_5       -1.0
    z_3_7_2_10        CLS_3_2_4       -1.0
    z_3_7_2_10        CLS_3_2_5       -1.0
    z_3_7_3_0         OBJ           0.0
    z_3_7_3_0         DAY_3_7_3       1.0
    z_3_7_3_0         REQ_3_7         1.0
    z_3_7_3_0         OCC_7_3_0       -1.0
    z_3_7_3_0         CLS_3_3_0       -1.0
    z_3_7_3_1         OBJ           0.0
    z_3_7_3_1         DAY_3_7_3       1.0
    z_3_7_3_1         REQ_3_7         1.0
    z_3_7_3_1         OCC_7_3_1       -1.0
    z_3_7_3_1         CLS_3_3_1       -1.0
    z_3_7_3_2         OBJ           0.0
    z_3_7_3_2         DAY_3_7_3       1.0
    z_3_7_3_2         REQ_3_7         1.0
    z_3_7_3_2         OCC_7_3_2       -1.0
    z_3_7_3_2         CLS_3_3_2       -1.0
    z_3_7_3_3         OBJ           0.0
    z_3_7_3_3         DAY_3_7_3       1.0
    z_3_7_3_3         REQ_3_7         1.0
    z_3_7_3_3         OCC_7_3_3       -1.0
    z_3_7_3_3         CLS_3_3_3       -1.0
    z_3_7_3_4         OBJ           0.0
    z_3_7_3_4         DAY_3_7_3       1.0
    z_3_7_3_4         REQ_3_7         1.0
    z_3_7_3_4         OCC_7_3_4       -1.0
    z_3_7_3_4         CLS_3_3_4       -1.0
    z_3_7_3_5         OBJ           0.0
    z_3_7_3_5         DAY_3_7_3       1.0
    z_3_7_3_5         REQ_3_7         1.0
    z_3_7_3_5         OCC_7_3_5       -1.0
    z_3_7_3_5         CLS_3_3_5       -1.0
    z_3_7_3_6         OBJ           0.0
    z_3_7_3_6         DAY_3_7_3       1.0
    z_3_7_3_6         REQ_3_7         2.0
    z_3_7_3_6         OCC_7_3_0       -1.0
    z_3_7_3_6         OCC_7_3_1       -1.0
    z_3_7_3_6         CLS_3_3_0       -1.0
    z_3_7_3_6         CLS_3_3_1       -1.0
    z_3_7_3_7         OBJ           0.0
    z_3_7_3_7         DAY_3_7_3       1.0
    z_3_7_3_7         REQ_3_7         2.0
    z_3_7_3_7         OCC_7_3_1       -1.0
    z_3_7_3_7         OCC_7_3_2       -1.0
    z_3_7_3_7         CLS_3_3_1       -1.0
    z_3_7_3_7         CLS_3_3_2       -1.0
    z_3_7_3_8         OBJ           0.0
    z_3_7_3_8         DAY_3_7_3       1.0
    z_3_7_3_8         REQ_3_7         2.0
    z_3_7_3_8         OCC_7_3_2       -1.0
    z_3_7_3_8         OCC_7_3_3       -1.0
    z_3_7_3_8         CLS_3_3_2       -1.0
    z_3_7_3_8         CLS_3_3_3       -1.0
    z_3_7_3_9         OBJ           0.0
    z_3_7_3_9         DAY_3_7_3       1.0
    z_3_7_3_9         REQ_3_7         2.0
    z_3_7_3_9         OCC_7_3_3       -1.0
    z_3_7_3_9         OCC_7_3_4       -1.0
    z_3_7_3_9         CLS_3_3_3       -1.0
    z_3_7_3_9         CLS_3_3_4       -1.0
    z_3_7_3_10        OBJ           0.0
    z_3_7_3_10        DAY_3_7_3       1.0
    z_3_7_3_10        REQ_3_7         2.0
    z_3_7_3_10        OCC_7_3_4       -1.0
    z_3_7_3_10        OCC_7_3_5       -1.0
    z_3_7_3_10        CLS_3_3_4       -1.0
    z_3_7_3_10        CLS_3_3_5       -1.0
    z_3_7_4_0         OBJ           0.0
    z_3_7_4_0         DAY_3_7_4       1.0
    z_3_7_4_0         REQ_3_7         1.0
    z_3_7_4_0         OCC_7_4_0       -1.0
    z_3_7_4_0         CLS_3_4_0       -1.0
    z_3_7_4_1         OBJ           0.0
    z_3_7_4_1         DAY_3_7_4       1.0
    z_3_7_4_1         REQ_3_7         1.0
    z_3_7_4_1         OCC_7_4_1       -1.0
    z_3_7_4_1         CLS_3_4_1       -1.0
    z_3_7_4_2         OBJ           0.0
    z_3_7_4_2         DAY_3_7_4       1.0
    z_3_7_4_2         REQ_3_7         1.0
    z_3_7_4_2         OCC_7_4_2       -1.0
    z_3_7_4_2         CLS_3_4_2       -1.0
    z_3_7_4_3         OBJ           0.0
    z_3_7_4_3         DAY_3_7_4       1.0
    z_3_7_4_3         REQ_3_7         1.0
    z_3_7_4_3         OCC_7_4_3       -1.0
    z_3_7_4_3         CLS_3_4_3       -1.0
    z_3_7_4_4         OBJ           0.0
    z_3_7_4_4         DAY_3_7_4       1.0
    z_3_7_4_4         REQ_3_7         1.0
    z_3_7_4_4         OCC_7_4_4       -1.0
    z_3_7_4_4         CLS_3_4_4       -1.0
    z_3_7_4_5         OBJ           0.0
    z_3_7_4_5         DAY_3_7_4       1.0
    z_3_7_4_5         REQ_3_7         1.0
    z_3_7_4_5         OCC_7_4_5       -1.0
    z_3_7_4_5         CLS_3_4_5       -1.0
    z_3_7_4_6         OBJ           0.0
    z_3_7_4_6         DAY_3_7_4       1.0
    z_3_7_4_6         REQ_3_7         2.0
    z_3_7_4_6         OCC_7_4_0       -1.0
    z_3_7_4_6         OCC_7_4_1       -1.0
    z_3_7_4_6         CLS_3_4_0       -1.0
    z_3_7_4_6         CLS_3_4_1       -1.0
    z_3_7_4_7         OBJ           0.0
    z_3_7_4_7         DAY_3_7_4       1.0
    z_3_7_4_7         REQ_3_7         2.0
    z_3_7_4_7         OCC_7_4_1       -1.0
    z_3_7_4_7         OCC_7_4_2       -1.0
    z_3_7_4_7         CLS_3_4_1       -1.0
    z_3_7_4_7         CLS_3_4_2       -1.0
    z_3_7_4_8         OBJ           0.0
    z_3_7_4_8         DAY_3_7_4       1.0
    z_3_7_4_8         REQ_3_7         2.0
    z_3_7_4_8         OCC_7_4_2       -1.0
    z_3_7_4_8         OCC_7_4_3       -1.0
    z_3_7_4_8         CLS_3_4_2       -1.0
    z_3_7_4_8         CLS_3_4_3       -1.0
    z_3_7_4_9         OBJ           0.0
    z_3_7_4_9         DAY_3_7_4       1.0
    z_3_7_4_9         REQ_3_7         2.0
    z_3_7_4_9         OCC_7_4_3       -1.0
    z_3_7_4_9         OCC_7_4_4       -1.0
    z_3_7_4_9         CLS_3_4_3       -1.0
    z_3_7_4_9         CLS_3_4_4       -1.0
    z_3_7_4_10        OBJ           0.0
    z_3_7_4_10        DAY_3_7_4       1.0
    z_3_7_4_10        REQ_3_7         2.0
    z_3_7_4_10        OCC_7_4_4       -1.0
    z_3_7_4_10        OCC_7_4_5       -1.0
    z_3_7_4_10        CLS_3_4_4       -1.0
    z_3_7_4_10        CLS_3_4_5       -1.0
    z_4_2_0_0         OBJ           0.0
    z_4_2_0_0         DAY_4_2_0       1.0
    z_4_2_0_0         REQ_4_2         1.0
    z_4_2_0_0         OCC_2_0_0       -1.0
    z_4_2_0_0         CLS_4_0_0       -1.0
    z_4_2_0_1         OBJ           0.0
    z_4_2_0_1         DAY_4_2_0       1.0
    z_4_2_0_1         REQ_4_2         1.0
    z_4_2_0_1         OCC_2_0_1       -1.0
    z_4_2_0_1         CLS_4_0_1       -1.0
    z_4_2_0_2         OBJ           0.0
    z_4_2_0_2         DAY_4_2_0       1.0
    z_4_2_0_2         REQ_4_2         1.0
    z_4_2_0_2         OCC_2_0_2       -1.0
    z_4_2_0_2         CLS_4_0_2       -1.0
    z_4_2_0_3         OBJ           0.0
    z_4_2_0_3         DAY_4_2_0       1.0
    z_4_2_0_3         REQ_4_2         1.0
    z_4_2_0_3         OCC_2_0_3       -1.0
    z_4_2_0_3         CLS_4_0_3       -1.0
    z_4_2_0_4         OBJ           0.0
    z_4_2_0_4         DAY_4_2_0       1.0
    z_4_2_0_4         REQ_4_2         1.0
    z_4_2_0_4         OCC_2_0_4       -1.0
    z_4_2_0_4         CLS_4_0_4       -1.0
    z_4_2_0_5         OBJ           0.0
    z_4_2_0_5         DAY_4_2_0       1.0
    z_4_2_0_5         REQ_4_2         2.0
    z_4_2_0_5         OCC_2_0_0       -1.0
    z_4_2_0_5         OCC_2_0_1       -1.0
    z_4_2_0_5         CLS_4_0_0       -1.0
    z_4_2_0_5         CLS_4_0_1       -1.0
    z_4_2_0_6         OBJ           0.0
    z_4_2_0_6         DAY_4_2_0       1.0
    z_4_2_0_6         REQ_4_2         2.0
    z_4_2_0_6         OCC_2_0_1       -1.0
    z_4_2_0_6         OCC_2_0_2       -1.0
    z_4_2_0_6         CLS_4_0_1       -1.0
    z_4_2_0_6         CLS_4_0_2       -1.0
    z_4_2_0_7         OBJ           0.0
    z_4_2_0_7         DAY_4_2_0       1.0
    z_4_2_0_7         REQ_4_2         2.0
    z_4_2_0_7         OCC_2_0_2       -1.0
    z_4_2_0_7         OCC_2_0_3       -1.0
    z_4_2_0_7         CLS_4_0_2       -1.0
    z_4_2_0_7         CLS_4_0_3       -1.0
    z_4_2_0_8         OBJ           0.0
    z_4_2_0_8         DAY_4_2_0       1.0
    z_4_2_0_8         REQ_4_2         2.0
    z_4_2_0_8         OCC_2_0_3       -1.0
    z_4_2_0_8         OCC_2_0_4       -1.0
    z_4_2_0_8         CLS_4_0_3       -1.0
    z_4_2_0_8         CLS_4_0_4       -1.0
    z_4_2_1_0         OBJ           0.0
    z_4_2_1_0         DAY_4_2_1       1.0
    z_4_2_1_0         REQ_4_2         1.0
    z_4_2_1_0         OCC_2_1_0       -1.0
    z_4_2_1_0         CLS_4_1_0       -1.0
    z_4_2_1_1         OBJ           0.0
    z_4_2_1_1         DAY_4_2_1       1.0
    z_4_2_1_1         REQ_4_2         1.0
    z_4_2_1_1         OCC_2_1_1       -1.0
    z_4_2_1_1         CLS_4_1_1       -1.0
    z_4_2_1_2         OBJ           0.0
    z_4_2_1_2         DAY_4_2_1       1.0
    z_4_2_1_2         REQ_4_2         1.0
    z_4_2_1_2         OCC_2_1_2       -1.0
    z_4_2_1_2         CLS_4_1_2       -1.0
    z_4_2_1_3         OBJ           0.0
    z_4_2_1_3         DAY_4_2_1       1.0
    z_4_2_1_3         REQ_4_2         1.0
    z_4_2_1_3         OCC_2_1_3       -1.0
    z_4_2_1_3         CLS_4_1_3       -1.0
    z_4_2_1_4         OBJ           0.0
    z_4_2_1_4         DAY_4_2_1       1.0
    z_4_2_1_4         REQ_4_2         1.0
    z_4_2_1_4         OCC_2_1_4       -1.0
    z_4_2_1_4         CLS_4_1_4       -1.0
    z_4_2_1_5         OBJ           0.0
    z_4_2_1_5         DAY_4_2_1       1.0
    z_4_2_1_5         REQ_4_2         1.0
    z_4_2_1_5         OCC_2_1_5       -1.0
    z_4_2_1_5         CLS_4_1_5       -1.0
    z_4_2_1_6         OBJ           0.0
    z_4_2_1_6         DAY_4_2_1       1.0
    z_4_2_1_6         REQ_4_2         2.0
    z_4_2_1_6         OCC_2_1_0       -1.0
    z_4_2_1_6         OCC_2_1_1       -1.0
    z_4_2_1_6         CLS_4_1_0       -1.0
    z_4_2_1_6         CLS_4_1_1       -1.0
    z_4_2_1_7         OBJ           0.0
    z_4_2_1_7         DAY_4_2_1       1.0
    z_4_2_1_7         REQ_4_2         2.0
    z_4_2_1_7         OCC_2_1_1       -1.0
    z_4_2_1_7         OCC_2_1_2       -1.0
    z_4_2_1_7         CLS_4_1_1       -1.0
    z_4_2_1_7         CLS_4_1_2       -1.0
    z_4_2_1_8         OBJ           0.0
    z_4_2_1_8         DAY_4_2_1       1.0
    z_4_2_1_8         REQ_4_2         2.0
    z_4_2_1_8         OCC_2_1_2       -1.0
    z_4_2_1_8         OCC_2_1_3       -1.0
    z_4_2_1_8         CLS_4_1_2       -1.0
    z_4_2_1_8         CLS_4_1_3       -1.0
    z_4_2_1_9         OBJ           0.0
    z_4_2_1_9         DAY_4_2_1       1.0
    z_4_2_1_9         REQ_4_2         2.0
    z_4_2_1_9         OCC_2_1_3       -1.0
    z_4_2_1_9         OCC_2_1_4       -1.0
    z_4_2_1_9         CLS_4_1_3       -1.0
    z_4_2_1_9         CLS_4_1_4       -1.0
    z_4_2_1_10        OBJ           0.0
    z_4_2_1_10        DAY_4_2_1       1.0
    z_4_2_1_10        REQ_4_2         2.0
    z_4_2_1_10        OCC_2_1_4       -1.0
    z_4_2_1_10        OCC_2_1_5       -1.0
    z_4_2_1_10        CLS_4_1_4       -1.0
    z_4_2_1_10        CLS_4_1_5       -1.0
    z_4_2_2_0         OBJ           0.0
    z_4_2_2_0         DAY_4_2_2       1.0
    z_4_2_2_0         REQ_4_2         1.0
    z_4_2_2_0         OCC_2_2_0       -1.0
    z_4_2_2_0         CLS_4_2_0       -1.0
    z_4_2_2_1         OBJ           0.0
    z_4_2_2_1         DAY_4_2_2       1.0
    z_4_2_2_1         REQ_4_2         1.0
    z_4_2_2_1         OCC_2_2_1       -1.0
    z_4_2_2_1         CLS_4_2_1       -1.0
    z_4_2_2_2         OBJ           0.0
    z_4_2_2_2         DAY_4_2_2       1.0
    z_4_2_2_2         REQ_4_2         1.0
    z_4_2_2_2         OCC_2_2_2       -1.0
    z_4_2_2_2         CLS_4_2_2       -1.0
    z_4_2_2_3         OBJ           0.0
    z_4_2_2_3         DAY_4_2_2       1.0
    z_4_2_2_3         REQ_4_2         1.0
    z_4_2_2_3         OCC_2_2_3       -1.0
    z_4_2_2_3         CLS_4_2_3       -1.0
    z_4_2_2_4         OBJ           0.0
    z_4_2_2_4         DAY_4_2_2       1.0
    z_4_2_2_4         REQ_4_2         1.0
    z_4_2_2_4         OCC_2_2_4       -1.0
    z_4_2_2_4         CLS_4_2_4       -1.0
    z_4_2_2_5         OBJ           0.0
    z_4_2_2_5         DAY_4_2_2       1.0
    z_4_2_2_5         REQ_4_2         2.0
    z_4_2_2_5         OCC_2_2_0       -1.0
    z_4_2_2_5         OCC_2_2_1       -1.0
    z_4_2_2_5         CLS_4_2_0       -1.0
    z_4_2_2_5         CLS_4_2_1       -1.0
    z_4_2_2_6         OBJ           0.0
    z_4_2_2_6         DAY_4_2_2       1.0
    z_4_2_2_6         REQ_4_2         2.0
    z_4_2_2_6         OCC_2_2_1       -1.0
    z_4_2_2_6         OCC_2_2_2       -1.0
    z_4_2_2_6         CLS_4_2_1       -1.0
    z_4_2_2_6         CLS_4_2_2       -1.0
    z_4_2_2_7         OBJ           0.0
    z_4_2_2_7         DAY_4_2_2       1.0
    z_4_2_2_7         REQ_4_2         2.0
    z_4_2_2_7         OCC_2_2_2       -1.0
    z_4_2_2_7         OCC_2_2_3       -1.0
    z_4_2_2_7         CLS_4_2_2       -1.0
    z_4_2_2_7         CLS_4_2_3       -1.0
    z_4_2_2_8         OBJ           0.0
    z_4_2_2_8         DAY_4_2_2       1.0
    z_4_2_2_8         REQ_4_2         2.0
    z_4_2_2_8         OCC_2_2_3       -1.0
    z_4_2_2_8         OCC_2_2_4       -1.0
    z_4_2_2_8         CLS_4_2_3       -1.0
    z_4_2_2_8         CLS_4_2_4       -1.0
    z_4_2_3_0         OBJ           0.0
    z_4_2_3_0         DAY_4_2_3       1.0
    z_4_2_3_0         REQ_4_2         1.0
    z_4_2_3_0         OCC_2_3_0       -1.0
    z_4_2_3_0         CLS_4_3_0       -1.0
    z_4_2_3_1         OBJ           0.0
    z_4_2_3_1         DAY_4_2_3       1.0
    z_4_2_3_1         REQ_4_2         1.0
    z_4_2_3_1         OCC_2_3_1       -1.0
    z_4_2_3_1         CLS_4_3_1       -1.0
    z_4_2_3_2         OBJ           0.0
    z_4_2_3_2         DAY_4_2_3       1.0
    z_4_2_3_2         REQ_4_2         1.0
    z_4_2_3_2         OCC_2_3_2       -1.0
    z_4_2_3_2         CLS_4_3_2       -1.0
    z_4_2_3_3         OBJ           0.0
    z_4_2_3_3         DAY_4_2_3       1.0
    z_4_2_3_3         REQ_4_2         1.0
    z_4_2_3_3         OCC_2_3_3       -1.0
    z_4_2_3_3         CLS_4_3_3       -1.0
    z_4_2_3_4         OBJ           0.0
    z_4_2_3_4         DAY_4_2_3       1.0
    z_4_2_3_4         REQ_4_2         1.0
    z_4_2_3_4         OCC_2_3_4       -1.0
    z_4_2_3_4         CLS_4_3_4       -1.0
    z_4_2_3_5         OBJ           0.0
    z_4_2_3_5         DAY_4_2_3       1.0
    z_4_2_3_5         REQ_4_2         1.0
    z_4_2_3_5         OCC_2_3_5       -1.0
    z_4_2_3_5         CLS_4_3_5       -1.0
    z_4_2_3_6         OBJ           0.0
    z_4_2_3_6         DAY_4_2_3       1.0
    z_4_2_3_6         REQ_4_2         2.0
    z_4_2_3_6         OCC_2_3_0       -1.0
    z_4_2_3_6         OCC_2_3_1       -1.0
    z_4_2_3_6         CLS_4_3_0       -1.0
    z_4_2_3_6         CLS_4_3_1       -1.0
    z_4_2_3_7         OBJ           0.0
    z_4_2_3_7         DAY_4_2_3       1.0
    z_4_2_3_7         REQ_4_2         2.0
    z_4_2_3_7         OCC_2_3_1       -1.0
    z_4_2_3_7         OCC_2_3_2       -1.0
    z_4_2_3_7         CLS_4_3_1       -1.0
    z_4_2_3_7         CLS_4_3_2       -1.0
    z_4_2_3_8         OBJ           0.0
    z_4_2_3_8         DAY_4_2_3       1.0
    z_4_2_3_8         REQ_4_2         2.0
    z_4_2_3_8         OCC_2_3_2       -1.0
    z_4_2_3_8         OCC_2_3_3       -1.0
    z_4_2_3_8         CLS_4_3_2       -1.0
    z_4_2_3_8         CLS_4_3_3       -1.0
    z_4_2_3_9         OBJ           0.0
    z_4_2_3_9         DAY_4_2_3       1.0
    z_4_2_3_9         REQ_4_2         2.0
    z_4_2_3_9         OCC_2_3_3       -1.0
    z_4_2_3_9         OCC_2_3_4       -1.0
    z_4_2_3_9         CLS_4_3_3       -1.0
    z_4_2_3_9         CLS_4_3_4       -1.0
    z_4_2_3_10        OBJ           0.0
    z_4_2_3_10        DAY_4_2_3       1.0
    z_4_2_3_10        REQ_4_2         2.0
    z_4_2_3_10        OCC_2_3_4       -1.0
    z_4_2_3_10        OCC_2_3_5       -1.0
    z_4_2_3_10        CLS_4_3_4       -1.0
    z_4_2_3_10        CLS_4_3_5       -1.0
    z_4_2_4_0         OBJ           0.0
    z_4_2_4_0         DAY_4_2_4       1.0
    z_4_2_4_0         REQ_4_2         1.0
    z_4_2_4_0         OCC_2_4_0       -1.0
    z_4_2_4_0         CLS_4_4_0       -1.0
    z_4_2_4_1         OBJ           0.0
    z_4_2_4_1         DAY_4_2_4       1.0
    z_4_2_4_1         REQ_4_2         1.0
    z_4_2_4_1         OCC_2_4_2       -1.0
    z_4_2_4_1         CLS_4_4_2       -1.0
    z_4_2_4_2         OBJ           0.0
    z_4_2_4_2         DAY_4_2_4       1.0
    z_4_2_4_2         REQ_4_2         1.0
    z_4_2_4_2         OCC_2_4_3       -1.0
    z_4_2_4_2         CLS_4_4_3       -1.0
    z_4_2_4_3         OBJ           0.0
    z_4_2_4_3         DAY_4_2_4       1.0
    z_4_2_4_3         REQ_4_2         1.0
    z_4_2_4_3         OCC_2_4_5       -1.0
    z_4_2_4_3         CLS_4_4_5       -1.0
    z_4_2_4_4         OBJ           0.0
    z_4_2_4_4         DAY_4_2_4       1.0
    z_4_2_4_4         REQ_4_2         2.0
    z_4_2_4_4         OCC_2_4_2       -1.0
    z_4_2_4_4         OCC_2_4_3       -1.0
    z_4_2_4_4         CLS_4_4_2       -1.0
    z_4_2_4_4         CLS_4_4_3       -1.0
    z_4_3_0_0         OBJ           0.0
    z_4_3_0_0         DAY_4_3_0       1.0
    z_4_3_0_0         REQ_4_3         1.0
    z_4_3_0_0         OCC_3_0_0       -1.0
    z_4_3_0_0         CLS_4_0_0       -1.0
    z_4_3_0_1         OBJ           0.0
    z_4_3_0_1         DAY_4_3_0       1.0
    z_4_3_0_1         REQ_4_3         1.0
    z_4_3_0_1         OCC_3_0_2       -1.0
    z_4_3_0_1         CLS_4_0_2       -1.0
    z_4_3_0_2         OBJ           0.0
    z_4_3_0_2         DAY_4_3_0       1.0
    z_4_3_0_2         REQ_4_3         1.0
    z_4_3_0_2         OCC_3_0_3       -1.0
    z_4_3_0_2         CLS_4_0_3       -1.0
    z_4_3_0_3         OBJ           0.0
    z_4_3_0_3         DAY_4_3_0       1.0
    z_4_3_0_3         REQ_4_3         1.0
    z_4_3_0_3         OCC_3_0_4       -1.0
    z_4_3_0_3         CLS_4_0_4       -1.0
    z_4_3_0_4         OBJ           0.0
    z_4_3_0_4         DAY_4_3_0       1.0
    z_4_3_0_4         REQ_4_3         1.0
    z_4_3_0_4         OCC_3_0_5       -1.0
    z_4_3_0_4         CLS_4_0_5       -1.0
    z_4_3_0_5         OBJ           0.0
    z_4_3_0_5         DAY_4_3_0       1.0
    z_4_3_0_5         REQ_4_3         2.0
    z_4_3_0_5         OCC_3_0_2       -1.0
    z_4_3_0_5         OCC_3_0_3       -1.0
    z_4_3_0_5         CLS_4_0_2       -1.0
    z_4_3_0_5         CLS_4_0_3       -1.0
    z_4_3_0_6         OBJ           0.0
    z_4_3_0_6         DAY_4_3_0       1.0
    z_4_3_0_6         REQ_4_3         2.0
    z_4_3_0_6         OCC_3_0_3       -1.0
    z_4_3_0_6         OCC_3_0_4       -1.0
    z_4_3_0_6         CLS_4_0_3       -1.0
    z_4_3_0_6         CLS_4_0_4       -1.0
    z_4_3_0_7         OBJ           0.0
    z_4_3_0_7         DAY_4_3_0       1.0
    z_4_3_0_7         REQ_4_3         2.0
    z_4_3_0_7         OCC_3_0_4       -1.0
    z_4_3_0_7         OCC_3_0_5       -1.0
    z_4_3_0_7         CLS_4_0_4       -1.0
    z_4_3_0_7         CLS_4_0_5       -1.0
    z_4_3_2_0         OBJ           0.0
    z_4_3_2_0         DAY_4_3_2       1.0
    z_4_3_2_0         REQ_4_3         1.0
    z_4_3_2_0         OCC_3_2_0       -1.0
    z_4_3_2_0         CLS_4_2_0       -1.0
    z_4_3_2_1         OBJ           0.0
    z_4_3_2_1         DAY_4_3_2       1.0
    z_4_3_2_1         REQ_4_3         1.0
    z_4_3_2_1         OCC_3_2_1       -1.0
    z_4_3_2_1         CLS_4_2_1       -1.0
    z_4_3_2_2         OBJ           0.0
    z_4_3_2_2         DAY_4_3_2       1.0
    z_4_3_2_2         REQ_4_3         1.0
    z_4_3_2_2         OCC_3_2_2       -1.0
    z_4_3_2_2         CLS_4_2_2       -1.0
    z_4_3_2_3         OBJ           0.0
    z_4_3_2_3         DAY_4_3_2       1.0
    z_4_3_2_3         REQ_4_3         1.0
    z_4_3_2_3         OCC_3_2_3       -1.0
    z_4_3_2_3         CLS_4_2_3       -1.0
    z_4_3_2_4         OBJ           0.0
    z_4_3_2_4         DAY_4_3_2       1.0
    z_4_3_2_4         REQ_4_3         1.0
    z_4_3_2_4         OCC_3_2_4       -1.0
    z_4_3_2_4         CLS_4_2_4       -1.0
    z_4_3_2_5         OBJ           0.0
    z_4_3_2_5         DAY_4_3_2       1.0
    z_4_3_2_5         REQ_4_3         1.0
    z_4_3_2_5         OCC_3_2_5       -1.0
    z_4_3_2_5         CLS_4_2_5       -1.0
    z_4_3_2_6         OBJ           0.0
    z_4_3_2_6         DAY_4_3_2       1.0
    z_4_3_2_6         REQ_4_3         2.0
    z_4_3_2_6         OCC_3_2_0       -1.0
    z_4_3_2_6         OCC_3_2_1       -1.0
    z_4_3_2_6         CLS_4_2_0       -1.0
    z_4_3_2_6         CLS_4_2_1       -1.0
    z_4_3_2_7         OBJ           0.0
    z_4_3_2_7         DAY_4_3_2       1.0
    z_4_3_2_7         REQ_4_3         2.0
    z_4_3_2_7         OCC_3_2_1       -1.0
    z_4_3_2_7         OCC_3_2_2       -1.0
    z_4_3_2_7         CLS_4_2_1       -1.0
    z_4_3_2_7         CLS_4_2_2       -1.0
    z_4_3_2_8         OBJ           0.0
    z_4_3_2_8         DAY_4_3_2       1.0
    z_4_3_2_8         REQ_4_3         2.0
    z_4_3_2_8         OCC_3_2_2       -1.0
    z_4_3_2_8         OCC_3_2_3       -1.0
    z_4_3_2_8         CLS_4_2_2       -1.0
    z_4_3_2_8         CLS_4_2_3       -1.0
    z_4_3_2_9         OBJ           0.0
    z_4_3_2_9         DAY_4_3_2       1.0
    z_4_3_2_9         REQ_4_3         2.0
    z_4_3_2_9         OCC_3_2_3       -1.0
    z_4_3_2_9         OCC_3_2_4       -1.0
    z_4_3_2_9         CLS_4_2_3       -1.0
    z_4_3_2_9         CLS_4_2_4       -1.0
    z_4_3_2_10        OBJ           0.0
    z_4_3_2_10        DAY_4_3_2       1.0
    z_4_3_2_10        REQ_4_3         2.0
    z_4_3_2_10        OCC_3_2_4       -1.0
    z_4_3_2_10        OCC_3_2_5       -1.0
    z_4_3_2_10        CLS_4_2_4       -1.0
    z_4_3_2_10        CLS_4_2_5       -1.0
    z_4_3_3_0         OBJ           0.0
    z_4_3_3_0         DAY_4_3_3       1.0
    z_4_3_3_0         REQ_4_3         1.0
    z_4_3_3_0         OCC_3_3_1       -1.0
    z_4_3_3_0         CLS_4_3_1       -1.0
    z_4_3_3_1         OBJ           0.0
    z_4_3_3_1         DAY_4_3_3       1.0
    z_4_3_3_1         REQ_4_3         1.0
    z_4_3_3_1         OCC_3_3_2       -1.0
    z_4_3_3_1         CLS_4_3_2       -1.0
    z_4_3_3_2         OBJ           0.0
    z_4_3_3_2         DAY_4_3_3       1.0
    z_4_3_3_2         REQ_4_3         1.0
    z_4_3_3_2         OCC_3_3_3       -1.0
    z_4_3_3_2         CLS_4_3_3       -1.0
    z_4_3_3_3         OBJ           0.0
    z_4_3_3_3         DAY_4_3_3       1.0
    z_4_3_3_3         REQ_4_3         1.0
    z_4_3_3_3         OCC_3_3_4       -1.0
    z_4_3_3_3         CLS_4_3_4       -1.0
    z_4_3_3_4         OBJ           0.0
    z_4_3_3_4         DAY_4_3_3       1.0
    z_4_3_3_4         REQ_4_3         1.0
    z_4_3_3_4         OCC_3_3_5       -1.0
    z_4_3_3_4         CLS_4_3_5       -1.0
    z_4_3_3_5         OBJ           0.0
    z_4_3_3_5         DAY_4_3_3       1.0
    z_4_3_3_5         REQ_4_3         2.0
    z_4_3_3_5         OCC_3_3_1       -1.0
    z_4_3_3_5         OCC_3_3_2       -1.0
    z_4_3_3_5         CLS_4_3_1       -1.0
    z_4_3_3_5         CLS_4_3_2       -1.0
    z_4_3_3_6         OBJ           0.0
    z_4_3_3_6         DAY_4_3_3       1.0
    z_4_3_3_6         REQ_4_3         2.0
    z_4_3_3_6         OCC_3_3_2       -1.0
    z_4_3_3_6         OCC_3_3_3       -1.0
    z_4_3_3_6         CLS_4_3_2       -1.0
    z_4_3_3_6         CLS_4_3_3       -1.0
    z_4_3_3_7         OBJ           0.0
    z_4_3_3_7         DAY_4_3_3       1.0
    z_4_3_3_7         REQ_4_3         2.0
    z_4_3_3_7         OCC_3_3_3       -1.0
    z_4_3_3_7         OCC_3_3_4       -1.0
    z_4_3_3_7         CLS_4_3_3       -1.0
    z_4_3_3_7         CLS_4_3_4       -1.0
    z_4_3_3_8         OBJ           0.0
    z_4_3_3_8         DAY_4_3_3       1.0
    z_4_3_3_8         REQ_4_3         2.0
    z_4_3_3_8         OCC_3_3_4       -1.0
    z_4_3_3_8         OCC_3_3_5       -1.0
    z_4_3_3_8         CLS_4_3_4       -1.0
    z_4_3_3_8         CLS_4_3_5       -1.0
    z_4_3_4_0         OBJ           0.0
    z_4_3_4_0         DAY_4_3_4       1.0
    z_4_3_4_0         REQ_4_3         1.0
    z_4_3_4_0         OCC_3_4_0       -1.0
    z_4_3_4_0         CLS_4_4_0       -1.0
    z_4_3_4_1         OBJ           0.0
    z_4_3_4_1         DAY_4_3_4       1.0
    z_4_3_4_1         REQ_4_3         1.0
    z_4_3_4_1         OCC_3_4_1       -1.0
    z_4_3_4_1         CLS_4_4_1       -1.0
    z_4_3_4_2         OBJ           0.0
    z_4_3_4_2         DAY_4_3_4       1.0
    z_4_3_4_2         REQ_4_3         1.0
    z_4_3_4_2         OCC_3_4_2       -1.0
    z_4_3_4_2         CLS_4_4_2       -1.0
    z_4_3_4_3         OBJ           0.0
    z_4_3_4_3         DAY_4_3_4       1.0
    z_4_3_4_3         REQ_4_3         1.0
    z_4_3_4_3         OCC_3_4_3       -1.0
    z_4_3_4_3         CLS_4_4_3       -1.0
    z_4_3_4_4         OBJ           0.0
    z_4_3_4_4         DAY_4_3_4       1.0
    z_4_3_4_4         REQ_4_3         1.0
    z_4_3_4_4         OCC_3_4_4       -1.0
    z_4_3_4_4         CLS_4_4_4       -1.0
    z_4_3_4_5         OBJ           0.0
    z_4_3_4_5         DAY_4_3_4       1.0
    z_4_3_4_5         REQ_4_3         1.0
    z_4_3_4_5         OCC_3_4_5       -1.0
    z_4_3_4_5         CLS_4_4_5       -1.0
    z_4_3_4_6         OBJ           0.0
    z_4_3_4_6         DAY_4_3_4       1.0
    z_4_3_4_6         REQ_4_3         2.0
    z_4_3_4_6         OCC_3_4_0       -1.0
    z_4_3_4_6         OCC_3_4_1       -1.0
    z_4_3_4_6         CLS_4_4_0       -1.0
    z_4_3_4_6         CLS_4_4_1       -1.0
    z_4_3_4_7         OBJ           0.0
    z_4_3_4_7         DAY_4_3_4       1.0
    z_4_3_4_7         REQ_4_3         2.0
    z_4_3_4_7         OCC_3_4_1       -1.0
    z_4_3_4_7         OCC_3_4_2       -1.0
    z_4_3_4_7         CLS_4_4_1       -1.0
    z_4_3_4_7         CLS_4_4_2       -1.0
    z_4_3_4_8         OBJ           0.0
    z_4_3_4_8         DAY_4_3_4       1.0
    z_4_3_4_8         REQ_4_3         2.0
    z_4_3_4_8         OCC_3_4_2       -1.0
    z_4_3_4_8         OCC_3_4_3       -1.0
    z_4_3_4_8         CLS_4_4_2       -1.0
    z_4_3_4_8         CLS_4_4_3       -1.0
    z_4_3_4_9         OBJ           0.0
    z_4_3_4_9         DAY_4_3_4       1.0
    z_4_3_4_9         REQ_4_3         2.0
    z_4_3_4_9         OCC_3_4_3       -1.0
    z_4_3_4_9         OCC_3_4_4       -1.0
    z_4_3_4_9         CLS_4_4_3       -1.0
    z_4_3_4_9         CLS_4_4_4       -1.0
    z_4_3_4_10        OBJ           0.0
    z_4_3_4_10        DAY_4_3_4       1.0
    z_4_3_4_10        REQ_4_3         2.0
    z_4_3_4_10        OCC_3_4_4       -1.0
    z_4_3_4_10        OCC_3_4_5       -1.0
    z_4_3_4_10        CLS_4_4_4       -1.0
    z_4_3_4_10        CLS_4_4_5       -1.0
    z_4_4_0_0         OBJ           0.0
    z_4_4_0_0         DAY_4_4_0       1.0
    z_4_4_0_0         REQ_4_4         1.0
    z_4_4_0_0         OCC_4_0_0       -1.0
    z_4_4_0_0         CLS_4_0_0       -1.0
    z_4_4_0_1         OBJ           0.0
    z_4_4_0_1         DAY_4_4_0       1.0
    z_4_4_0_1         REQ_4_4         1.0
    z_4_4_0_1         OCC_4_0_1       -1.0
    z_4_4_0_1         CLS_4_0_1       -1.0
    z_4_4_0_2         OBJ           0.0
    z_4_4_0_2         DAY_4_4_0       1.0
    z_4_4_0_2         REQ_4_4         1.0
    z_4_4_0_2         OCC_4_0_2       -1.0
    z_4_4_0_2         CLS_4_0_2       -1.0
    z_4_4_0_3         OBJ           0.0
    z_4_4_0_3         DAY_4_4_0       1.0
    z_4_4_0_3         REQ_4_4         1.0
    z_4_4_0_3         OCC_4_0_3       -1.0
    z_4_4_0_3         CLS_4_0_3       -1.0
    z_4_4_0_4         OBJ           0.0
    z_4_4_0_4         DAY_4_4_0       1.0
    z_4_4_0_4         REQ_4_4         1.0
    z_4_4_0_4         OCC_4_0_5       -1.0
    z_4_4_0_4         CLS_4_0_5       -1.0
    z_4_4_0_5         OBJ           0.0
    z_4_4_0_5         DAY_4_4_0       1.0
    z_4_4_0_5         REQ_4_4         2.0
    z_4_4_0_5         OCC_4_0_0       -1.0
    z_4_4_0_5         OCC_4_0_1       -1.0
    z_4_4_0_5         CLS_4_0_0       -1.0
    z_4_4_0_5         CLS_4_0_1       -1.0
    z_4_4_0_6         OBJ           0.0
    z_4_4_0_6         DAY_4_4_0       1.0
    z_4_4_0_6         REQ_4_4         2.0
    z_4_4_0_6         OCC_4_0_1       -1.0
    z_4_4_0_6         OCC_4_0_2       -1.0
    z_4_4_0_6         CLS_4_0_1       -1.0
    z_4_4_0_6         CLS_4_0_2       -1.0
    z_4_4_0_7         OBJ           0.0
    z_4_4_0_7         DAY_4_4_0       1.0
    z_4_4_0_7         REQ_4_4         2.0
    z_4_4_0_7         OCC_4_0_2       -1.0
    z_4_4_0_7         OCC_4_0_3       -1.0
    z_4_4_0_7         CLS_4_0_2       -1.0
    z_4_4_0_7         CLS_4_0_3       -1.0
    z_4_4_1_0         OBJ           0.0
    z_4_4_1_0         DAY_4_4_1       1.0
    z_4_4_1_0         REQ_4_4         1.0
    z_4_4_1_0         OCC_4_1_0       -1.0
    z_4_4_1_0         CLS_4_1_0       -1.0
    z_4_4_1_1         OBJ           0.0
    z_4_4_1_1         DAY_4_4_1       1.0
    z_4_4_1_1         REQ_4_4         1.0
    z_4_4_1_1         OCC_4_1_1       -1.0
    z_4_4_1_1         CLS_4_1_1       -1.0
    z_4_4_1_2         OBJ           0.0
    z_4_4_1_2         DAY_4_4_1       1.0
    z_4_4_1_2         REQ_4_4         1.0
    z_4_4_1_2         OCC_4_1_2       -1.0
    z_4_4_1_2         CLS_4_1_2       -1.0
    z_4_4_1_3         OBJ           0.0
    z_4_4_1_3         DAY_4_4_1       1.0
    z_4_4_1_3         REQ_4_4         1.0
    z_4_4_1_3         OCC_4_1_3       -1.0
    z_4_4_1_3         CLS_4_1_3       -1.0
    z_4_4_1_4         OBJ           0.0
    z_4_4_1_4         DAY_4_4_1       1.0
    z_4_4_1_4         REQ_4_4         1.0
    z_4_4_1_4         OCC_4_1_4       -1.0
    z_4_4_1_4         CLS_4_1_4       -1.0
    z_4_4_1_5         OBJ           0.0
    z_4_4_1_5         DAY_4_4_1       1.0
    z_4_4_1_5         REQ_4_4         1.0
    z_4_4_1_5         OCC_4_1_5       -1.0
    z_4_4_1_5         CLS_4_1_5       -1.0
    z_4_4_1_6         OBJ           0.0
    z_4_4_1_6         DAY_4_4_1       1.0
    z_4_4_1_6         REQ_4_4         2.0
    z_4_4_1_6         OCC_4_1_0       -1.0
    z_4_4_1_6         OCC_4_1_1       -1.0
    z_4_4_1_6         CLS_4_1_0       -1.0
    z_4_4_1_6         CLS_4_1_1       -1.0
    z_4_4_1_7         OBJ           0.0
    z_4_4_1_7         DAY_4_4_1       1.0
    z_4_4_1_7         REQ_4_4         2.0
    z_4_4_1_7         OCC_4_1_1       -1.0
    z_4_4_1_7         OCC_4_1_2       -1.0
    z_4_4_1_7         CLS_4_1_1       -1.0
    z_4_4_1_7         CLS_4_1_2       -1.0
    z_4_4_1_8         OBJ           0.0
    z_4_4_1_8         DAY_4_4_1       1.0
    z_4_4_1_8         REQ_4_4         2.0
    z_4_4_1_8         OCC_4_1_2       -1.0
    z_4_4_1_8         OCC_4_1_3       -1.0
    z_4_4_1_8         CLS_4_1_2       -1.0
    z_4_4_1_8         CLS_4_1_3       -1.0
    z_4_4_1_9         OBJ           0.0
    z_4_4_1_9         DAY_4_4_1       1.0
    z_4_4_1_9         REQ_4_4         2.0
    z_4_4_1_9         OCC_4_1_3       -1.0
    z_4_4_1_9         OCC_4_1_4       -1.0
    z_4_4_1_9         CLS_4_1_3       -1.0
    z_4_4_1_9         CLS_4_1_4       -1.0
    z_4_4_1_10        OBJ           0.0
    z_4_4_1_10        DAY_4_4_1       1.0
    z_4_4_1_10        REQ_4_4         2.0
    z_4_4_1_10        OCC_4_1_4       -1.0
    z_4_4_1_10        OCC_4_1_5       -1.0
    z_4_4_1_10        CLS_4_1_4       -1.0
    z_4_4_1_10        CLS_4_1_5       -1.0
    z_4_4_2_0         OBJ           0.0
    z_4_4_2_0         DAY_4_4_2       1.0
    z_4_4_2_0         REQ_4_4         1.0
    z_4_4_2_0         OCC_4_2_0       -1.0
    z_4_4_2_0         CLS_4_2_0       -1.0
    z_4_4_2_1         OBJ           0.0
    z_4_4_2_1         DAY_4_4_2       1.0
    z_4_4_2_1         REQ_4_4         1.0
    z_4_4_2_1         OCC_4_2_1       -1.0
    z_4_4_2_1         CLS_4_2_1       -1.0
    z_4_4_2_2         OBJ           0.0
    z_4_4_2_2         DAY_4_4_2       1.0
    z_4_4_2_2         REQ_4_4         1.0
    z_4_4_2_2         OCC_4_2_2       -1.0
    z_4_4_2_2         CLS_4_2_2       -1.0
    z_4_4_2_3         OBJ           0.0
    z_4_4_2_3         DAY_4_4_2       1.0
    z_4_4_2_3         REQ_4_4         1.0
    z_4_4_2_3         OCC_4_2_3       -1.0
    z_4_4_2_3         CLS_4_2_3       -1.0
    z_4_4_2_4         OBJ           0.0
    z_4_4_2_4         DAY_4_4_2       1.0
    z_4_4_2_4         REQ_4_4         1.0
    z_4_4_2_4         OCC_4_2_4       -1.0
    z_4_4_2_4         CLS_4_2_4       -1.0
    z_4_4_2_5         OBJ           0.0
    z_4_4_2_5         DAY_4_4_2       1.0
    z_4_4_2_5         REQ_4_4         1.0
    z_4_4_2_5         OCC_4_2_5       -1.0
    z_4_4_2_5         CLS_4_2_5       -1.0
    z_4_4_2_6         OBJ           0.0
    z_4_4_2_6         DAY_4_4_2       1.0
    z_4_4_2_6         REQ_4_4         2.0
    z_4_4_2_6         OCC_4_2_0       -1.0
    z_4_4_2_6         OCC_4_2_1       -1.0
    z_4_4_2_6         CLS_4_2_0       -1.0
    z_4_4_2_6         CLS_4_2_1       -1.0
    z_4_4_2_7         OBJ           0.0
    z_4_4_2_7         DAY_4_4_2       1.0
    z_4_4_2_7         REQ_4_4         2.0
    z_4_4_2_7         OCC_4_2_1       -1.0
    z_4_4_2_7         OCC_4_2_2       -1.0
    z_4_4_2_7         CLS_4_2_1       -1.0
    z_4_4_2_7         CLS_4_2_2       -1.0
    z_4_4_2_8         OBJ           0.0
    z_4_4_2_8         DAY_4_4_2       1.0
    z_4_4_2_8         REQ_4_4         2.0
    z_4_4_2_8         OCC_4_2_2       -1.0
    z_4_4_2_8         OCC_4_2_3       -1.0
    z_4_4_2_8         CLS_4_2_2       -1.0
    z_4_4_2_8         CLS_4_2_3       -1.0
    z_4_4_2_9         OBJ           0.0
    z_4_4_2_9         DAY_4_4_2       1.0
    z_4_4_2_9         REQ_4_4         2.0
    z_4_4_2_9         OCC_4_2_3       -1.0
    z_4_4_2_9         OCC_4_2_4       -1.0
    z_4_4_2_9         CLS_4_2_3       -1.0
    z_4_4_2_9         CLS_4_2_4       -1.0
    z_4_4_2_10        OBJ           0.0
    z_4_4_2_10        DAY_4_4_2       1.0
    z_4_4_2_10        REQ_4_4         2.0
    z_4_4_2_10        OCC_4_2_4       -1.0
    z_4_4_2_10        OCC_4_2_5       -1.0
    z_4_4_2_10        CLS_4_2_4       -1.0
    z_4_4_2_10        CLS_4_2_5       -1.0
    z_4_4_3_0         OBJ           0.0
    z_4_4_3_0         DAY_4_4_3       1.0
    z_4_4_3_0         REQ_4_4         1.0
    z_4_4_3_0         OCC_4_3_0       -1.0
    z_4_4_3_0         CLS_4_3_0       -1.0
    z_4_4_3_1         OBJ           0.0
    z_4_4_3_1         DAY_4_4_3       1.0
    z_4_4_3_1         REQ_4_4         1.0
    z_4_4_3_1         OCC_4_3_1       -1.0
    z_4_4_3_1         CLS_4_3_1       -1.0
    z_4_4_3_2         OBJ           0.0
    z_4_4_3_2         DAY_4_4_3       1.0
    z_4_4_3_2         REQ_4_4         1.0
    z_4_4_3_2         OCC_4_3_2       -1.0
    z_4_4_3_2         CLS_4_3_2       -1.0
    z_4_4_3_3         OBJ           0.0
    z_4_4_3_3         DAY_4_4_3       1.0
    z_4_4_3_3         REQ_4_4         1.0
    z_4_4_3_3         OCC_4_3_3       -1.0
    z_4_4_3_3         CLS_4_3_3       -1.0
    z_4_4_3_4         OBJ           0.0
    z_4_4_3_4         DAY_4_4_3       1.0
    z_4_4_3_4         REQ_4_4         1.0
    z_4_4_3_4         OCC_4_3_4       -1.0
    z_4_4_3_4         CLS_4_3_4       -1.0
    z_4_4_3_5         OBJ           0.0
    z_4_4_3_5         DAY_4_4_3       1.0
    z_4_4_3_5         REQ_4_4         1.0
    z_4_4_3_5         OCC_4_3_5       -1.0
    z_4_4_3_5         CLS_4_3_5       -1.0
    z_4_4_3_6         OBJ           0.0
    z_4_4_3_6         DAY_4_4_3       1.0
    z_4_4_3_6         REQ_4_4         2.0
    z_4_4_3_6         OCC_4_3_0       -1.0
    z_4_4_3_6         OCC_4_3_1       -1.0
    z_4_4_3_6         CLS_4_3_0       -1.0
    z_4_4_3_6         CLS_4_3_1       -1.0
    z_4_4_3_7         OBJ           0.0
    z_4_4_3_7         DAY_4_4_3       1.0
    z_4_4_3_7         REQ_4_4         2.0
    z_4_4_3_7         OCC_4_3_1       -1.0
    z_4_4_3_7         OCC_4_3_2       -1.0
    z_4_4_3_7         CLS_4_3_1       -1.0
    z_4_4_3_7         CLS_4_3_2       -1.0
    z_4_4_3_8         OBJ           0.0
    z_4_4_3_8         DAY_4_4_3       1.0
    z_4_4_3_8         REQ_4_4         2.0
    z_4_4_3_8         OCC_4_3_2       -1.0
    z_4_4_3_8         OCC_4_3_3       -1.0
    z_4_4_3_8         CLS_4_3_2       -1.0
    z_4_4_3_8         CLS_4_3_3       -1.0
    z_4_4_3_9         OBJ           0.0
    z_4_4_3_9         DAY_4_4_3       1.0
    z_4_4_3_9         REQ_4_4         2.0
    z_4_4_3_9         OCC_4_3_3       -1.0
    z_4_4_3_9         OCC_4_3_4       -1.0
    z_4_4_3_9         CLS_4_3_3       -1.0
    z_4_4_3_9         CLS_4_3_4       -1.0
    z_4_4_3_10        OBJ           0.0
    z_4_4_3_10        DAY_4_4_3       1.0
    z_4_4_3_10        REQ_4_4         2.0
    z_4_4_3_10        OCC_4_3_4       -1.0
    z_4_4_3_10        OCC_4_3_5       -1.0
    z_4_4_3_10        CLS_4_3_4       -1.0
    z_4_4_3_10        CLS_4_3_5       -1.0
    z_4_4_4_0         OBJ           0.0
    z_4_4_4_0         DAY_4_4_4       1.0
    z_4_4_4_0         REQ_4_4         1.0
    z_4_4_4_0         OCC_4_4_0       -1.0
    z_4_4_4_0         CLS_4_4_0       -1.0
    z_4_4_4_1         OBJ           0.0
    z_4_4_4_1         DAY_4_4_4       1.0
    z_4_4_4_1         REQ_4_4         1.0
    z_4_4_4_1         OCC_4_4_1       -1.0
    z_4_4_4_1         CLS_4_4_1       -1.0
    z_4_4_4_2         OBJ           0.0
    z_4_4_4_2         DAY_4_4_4       1.0
    z_4_4_4_2         REQ_4_4         1.0
    z_4_4_4_2         OCC_4_4_2       -1.0
    z_4_4_4_2         CLS_4_4_2       -1.0
    z_4_4_4_3         OBJ           0.0
    z_4_4_4_3         DAY_4_4_4       1.0
    z_4_4_4_3         REQ_4_4         1.0
    z_4_4_4_3         OCC_4_4_3       -1.0
    z_4_4_4_3         CLS_4_4_3       -1.0
    z_4_4_4_4         OBJ           0.0
    z_4_4_4_4         DAY_4_4_4       1.0
    z_4_4_4_4         REQ_4_4         1.0
    z_4_4_4_4         OCC_4_4_4       -1.0
    z_4_4_4_4         CLS_4_4_4       -1.0
    z_4_4_4_5         OBJ           0.0
    z_4_4_4_5         DAY_4_4_4       1.0
    z_4_4_4_5         REQ_4_4         1.0
    z_4_4_4_5         OCC_4_4_5       -1.0
    z_4_4_4_5         CLS_4_4_5       -1.0
    z_4_4_4_6         OBJ           0.0
    z_4_4_4_6         DAY_4_4_4       1.0
    z_4_4_4_6         REQ_4_4         2.0
    z_4_4_4_6         OCC_4_4_0       -1.0
    z_4_4_4_6         OCC_4_4_1       -1.0
    z_4_4_4_6         CLS_4_4_0       -1.0
    z_4_4_4_6         CLS_4_4_1       -1.0
    z_4_4_4_7         OBJ           0.0
    z_4_4_4_7         DAY_4_4_4       1.0
    z_4_4_4_7         REQ_4_4         2.0
    z_4_4_4_7         OCC_4_4_1       -1.0
    z_4_4_4_7         OCC_4_4_2       -1.0
    z_4_4_4_7         CLS_4_4_1       -1.0
    z_4_4_4_7         CLS_4_4_2       -1.0
    z_4_4_4_8         OBJ           0.0
    z_4_4_4_8         DAY_4_4_4       1.0
    z_4_4_4_8         REQ_4_4         2.0
    z_4_4_4_8         OCC_4_4_2       -1.0
    z_4_4_4_8         OCC_4_4_3       -1.0
    z_4_4_4_8         CLS_4_4_2       -1.0
    z_4_4_4_8         CLS_4_4_3       -1.0
    z_4_4_4_9         OBJ           0.0
    z_4_4_4_9         DAY_4_4_4       1.0
    z_4_4_4_9         REQ_4_4         2.0
    z_4_4_4_9         OCC_4_4_3       -1.0
    z_4_4_4_9         OCC_4_4_4       -1.0
    z_4_4_4_9         CLS_4_4_3       -1.0
    z_4_4_4_9         CLS_4_4_4       -1.0
    z_4_4_4_10        OBJ           0.0
    z_4_4_4_10        DAY_4_4_4       1.0
    z_4_4_4_10        REQ_4_4         2.0
    z_4_4_4_10        OCC_4_4_4       -1.0
    z_4_4_4_10        OCC_4_4_5       -1.0
    z_4_4_4_10        CLS_4_4_4       -1.0
    z_4_4_4_10        CLS_4_4_5       -1.0
    z_4_5_0_0         OBJ           0.0
    z_4_5_0_0         DAY_4_5_0       1.0
    z_4_5_0_0         REQ_4_5         1.0
    z_4_5_0_0         OCC_5_0_0       -1.0
    z_4_5_0_0         CLS_4_0_0       -1.0
    z_4_5_0_1         OBJ           0.0
    z_4_5_0_1         DAY_4_5_0       1.0
    z_4_5_0_1         REQ_4_5         1.0
    z_4_5_0_1         OCC_5_0_1       -1.0
    z_4_5_0_1         CLS_4_0_1       -1.0
    z_4_5_0_2         OBJ           0.0
    z_4_5_0_2         DAY_4_5_0       1.0
    z_4_5_0_2         REQ_4_5         1.0
    z_4_5_0_2         OCC_5_0_2       -1.0
    z_4_5_0_2         CLS_4_0_2       -1.0
    z_4_5_0_3         OBJ           0.0
    z_4_5_0_3         DAY_4_5_0       1.0
    z_4_5_0_3         REQ_4_5         1.0
    z_4_5_0_3         OCC_5_0_3       -1.0
    z_4_5_0_3         CLS_4_0_3       -1.0
    z_4_5_0_4         OBJ           0.0
    z_4_5_0_4         DAY_4_5_0       1.0
    z_4_5_0_4         REQ_4_5         1.0
    z_4_5_0_4         OCC_5_0_4       -1.0
    z_4_5_0_4         CLS_4_0_4       -1.0
    z_4_5_0_5         OBJ           0.0
    z_4_5_0_5         DAY_4_5_0       1.0
    z_4_5_0_5         REQ_4_5         1.0
    z_4_5_0_5         OCC_5_0_5       -1.0
    z_4_5_0_5         CLS_4_0_5       -1.0
    z_4_5_0_6         OBJ           0.0
    z_4_5_0_6         DAY_4_5_0       1.0
    z_4_5_0_6         REQ_4_5         2.0
    z_4_5_0_6         OCC_5_0_0       -1.0
    z_4_5_0_6         OCC_5_0_1       -1.0
    z_4_5_0_6         CLS_4_0_0       -1.0
    z_4_5_0_6         CLS_4_0_1       -1.0
    z_4_5_0_7         OBJ           0.0
    z_4_5_0_7         DAY_4_5_0       1.0
    z_4_5_0_7         REQ_4_5         2.0
    z_4_5_0_7         OCC_5_0_1       -1.0
    z_4_5_0_7         OCC_5_0_2       -1.0
    z_4_5_0_7         CLS_4_0_1       -1.0
    z_4_5_0_7         CLS_4_0_2       -1.0
    z_4_5_0_8         OBJ           0.0
    z_4_5_0_8         DAY_4_5_0       1.0
    z_4_5_0_8         REQ_4_5         2.0
    z_4_5_0_8         OCC_5_0_2       -1.0
    z_4_5_0_8         OCC_5_0_3       -1.0
    z_4_5_0_8         CLS_4_0_2       -1.0
    z_4_5_0_8         CLS_4_0_3       -1.0
    z_4_5_0_9         OBJ           0.0
    z_4_5_0_9         DAY_4_5_0       1.0
    z_4_5_0_9         REQ_4_5         2.0
    z_4_5_0_9         OCC_5_0_3       -1.0
    z_4_5_0_9         OCC_5_0_4       -1.0
    z_4_5_0_9         CLS_4_0_3       -1.0
    z_4_5_0_9         CLS_4_0_4       -1.0
    z_4_5_0_10        OBJ           0.0
    z_4_5_0_10        DAY_4_5_0       1.0
    z_4_5_0_10        REQ_4_5         2.0
    z_4_5_0_10        OCC_5_0_4       -1.0
    z_4_5_0_10        OCC_5_0_5       -1.0
    z_4_5_0_10        CLS_4_0_4       -1.0
    z_4_5_0_10        CLS_4_0_5       -1.0
    z_4_5_1_0         OBJ           0.0
    z_4_5_1_0         DAY_4_5_1       1.0
    z_4_5_1_0         REQ_4_5         1.0
    z_4_5_1_0         OCC_5_1_0       -1.0
    z_4_5_1_0         CLS_4_1_0       -1.0
    z_4_5_1_1         OBJ           0.0
    z_4_5_1_1         DAY_4_5_1       1.0
    z_4_5_1_1         REQ_4_5         1.0
    z_4_5_1_1         OCC_5_1_2       -1.0
    z_4_5_1_1         CLS_4_1_2       -1.0
    z_4_5_1_2         OBJ           0.0
    z_4_5_1_2         DAY_4_5_1       1.0
    z_4_5_1_2         REQ_4_5         1.0
    z_4_5_1_2         OCC_5_1_3       -1.0
    z_4_5_1_2         CLS_4_1_3       -1.0
    z_4_5_1_3         OBJ           0.0
    z_4_5_1_3         DAY_4_5_1       1.0
    z_4_5_1_3         REQ_4_5         1.0
    z_4_5_1_3         OCC_5_1_4       -1.0
    z_4_5_1_3         CLS_4_1_4       -1.0
    z_4_5_1_4         OBJ           0.0
    z_4_5_1_4         DAY_4_5_1       1.0
    z_4_5_1_4         REQ_4_5         1.0
    z_4_5_1_4         OCC_5_1_5       -1.0
    z_4_5_1_4         CLS_4_1_5       -1.0
    z_4_5_1_5         OBJ           0.0
    z_4_5_1_5         DAY_4_5_1       1.0
    z_4_5_1_5         REQ_4_5         2.0
    z_4_5_1_5         OCC_5_1_2       -1.0
    z_4_5_1_5         OCC_5_1_3       -1.0
    z_4_5_1_5         CLS_4_1_2       -1.0
    z_4_5_1_5         CLS_4_1_3       -1.0
    z_4_5_1_6         OBJ           0.0
    z_4_5_1_6         DAY_4_5_1       1.0
    z_4_5_1_6         REQ_4_5         2.0
    z_4_5_1_6         OCC_5_1_3       -1.0
    z_4_5_1_6         OCC_5_1_4       -1.0
    z_4_5_1_6         CLS_4_1_3       -1.0
    z_4_5_1_6         CLS_4_1_4       -1.0
    z_4_5_1_7         OBJ           0.0
    z_4_5_1_7         DAY_4_5_1       1.0
    z_4_5_1_7         REQ_4_5         2.0
    z_4_5_1_7         OCC_5_1_4       -1.0
    z_4_5_1_7         OCC_5_1_5       -1.0
    z_4_5_1_7         CLS_4_1_4       -1.0
    z_4_5_1_7         CLS_4_1_5       -1.0
    z_4_5_2_0         OBJ           0.0
    z_4_5_2_0         DAY_4_5_2       1.0
    z_4_5_2_0         REQ_4_5         1.0
    z_4_5_2_0         OCC_5_2_0       -1.0
    z_4_5_2_0         CLS_4_2_0       -1.0
    z_4_5_2_1         OBJ           0.0
    z_4_5_2_1         DAY_4_5_2       1.0
    z_4_5_2_1         REQ_4_5         1.0
    z_4_5_2_1         OCC_5_2_1       -1.0
    z_4_5_2_1         CLS_4_2_1       -1.0
    z_4_5_2_2         OBJ           0.0
    z_4_5_2_2         DAY_4_5_2       1.0
    z_4_5_2_2         REQ_4_5         1.0
    z_4_5_2_2         OCC_5_2_2       -1.0
    z_4_5_2_2         CLS_4_2_2       -1.0
    z_4_5_2_3         OBJ           0.0
    z_4_5_2_3         DAY_4_5_2       1.0
    z_4_5_2_3         REQ_4_5         1.0
    z_4_5_2_3         OCC_5_2_4       -1.0
    z_4_5_2_3         CLS_4_2_4       -1.0
    z_4_5_2_4         OBJ           0.0
    z_4_5_2_4         DAY_4_5_2       1.0
    z_4_5_2_4         REQ_4_5         1.0
    z_4_5_2_4         OCC_5_2_5       -1.0
    z_4_5_2_4         CLS_4_2_5       -1.0
    z_4_5_2_5         OBJ           0.0
    z_4_5_2_5         DAY_4_5_2       1.0
    z_4_5_2_5         REQ_4_5         2.0
    z_4_5_2_5         OCC_5_2_0       -1.0
    z_4_5_2_5         OCC_5_2_1       -1.0
    z_4_5_2_5         CLS_4_2_0       -1.0
    z_4_5_2_5         CLS_4_2_1       -1.0
    z_4_5_2_6         OBJ           0.0
    z_4_5_2_6         DAY_4_5_2       1.0
    z_4_5_2_6         REQ_4_5         2.0
    z_4_5_2_6         OCC_5_2_1       -1.0
    z_4_5_2_6         OCC_5_2_2       -1.0
    z_4_5_2_6         CLS_4_2_1       -1.0
    z_4_5_2_6         CLS_4_2_2       -1.0
    z_4_5_2_7         OBJ           0.0
    z_4_5_2_7         DAY_4_5_2       1.0
    z_4_5_2_7         REQ_4_5         2.0
    z_4_5_2_7         OCC_5_2_4       -1.0
    z_4_5_2_7         OCC_5_2_5       -1.0
    z_4_5_2_7         CLS_4_2_4       -1.0
    z_4_5_2_7         CLS_4_2_5       -1.0
    z_4_5_3_0         OBJ           0.0
    z_4_5_3_0         DAY_4_5_3       1.0
    z_4_5_3_0         REQ_4_5         1.0
    z_4_5_3_0         OCC_5_3_0       -1.0
    z_4_5_3_0         CLS_4_3_0       -1.0
    z_4_5_3_1         OBJ           0.0
    z_4_5_3_1         DAY_4_5_3       1.0
    z_4_5_3_1         REQ_4_5         1.0
    z_4_5_3_1         OCC_5_3_1       -1.0
    z_4_5_3_1         CLS_4_3_1       -1.0
    z_4_5_3_2         OBJ           0.0
    z_4_5_3_2         DAY_4_5_3       1.0
    z_4_5_3_2         REQ_4_5         1.0
    z_4_5_3_2         OCC_5_3_2       -1.0
    z_4_5_3_2         CLS_4_3_2       -1.0
    z_4_5_3_3         OBJ           0.0
    z_4_5_3_3         DAY_4_5_3       1.0
    z_4_5_3_3         REQ_4_5         1.0
    z_4_5_3_3         OCC_5_3_3       -1.0
    z_4_5_3_3         CLS_4_3_3       -1.0
    z_4_5_3_4         OBJ           0.0
    z_4_5_3_4         DAY_4_5_3       1.0
    z_4_5_3_4         REQ_4_5         1.0
    z_4_5_3_4         OCC_5_3_4       -1.0
    z_4_5_3_4         CLS_4_3_4       -1.0
    z_4_5_3_5         OBJ           0.0
    z_4_5_3_5         DAY_4_5_3       1.0
    z_4_5_3_5         REQ_4_5         1.0
    z_4_5_3_5         OCC_5_3_5       -1.0
    z_4_5_3_5         CLS_4_3_5       -1.0
    z_4_5_3_6         OBJ           0.0
    z_4_5_3_6         DAY_4_5_3       1.0
    z_4_5_3_6         REQ_4_5         2.0
    z_4_5_3_6         OCC_5_3_0       -1.0
    z_4_5_3_6         OCC_5_3_1       -1.0
    z_4_5_3_6         CLS_4_3_0       -1.0
    z_4_5_3_6         CLS_4_3_1       -1.0
    z_4_5_3_7         OBJ           0.0
    z_4_5_3_7         DAY_4_5_3       1.0
    z_4_5_3_7         REQ_4_5         2.0
    z_4_5_3_7         OCC_5_3_1       -1.0
    z_4_5_3_7         OCC_5_3_2       -1.0
    z_4_5_3_7         CLS_4_3_1       -1.0
    z_4_5_3_7         CLS_4_3_2       -1.0
    z_4_5_3_8         OBJ           0.0
    z_4_5_3_8         DAY_4_5_3       1.0
    z_4_5_3_8         REQ_4_5         2.0
    z_4_5_3_8         OCC_5_3_2       -1.0
    z_4_5_3_8         OCC_5_3_3       -1.0
    z_4_5_3_8         CLS_4_3_2       -1.0
    z_4_5_3_8         CLS_4_3_3       -1.0
    z_4_5_3_9         OBJ           0.0
    z_4_5_3_9         DAY_4_5_3       1.0
    z_4_5_3_9         REQ_4_5         2.0
    z_4_5_3_9         OCC_5_3_3       -1.0
    z_4_5_3_9         OCC_5_3_4       -1.0
    z_4_5_3_9         CLS_4_3_3       -1.0
    z_4_5_3_9         CLS_4_3_4       -1.0
    z_4_5_3_10        OBJ           0.0
    z_4_5_3_10        DAY_4_5_3       1.0
    z_4_5_3_10        REQ_4_5         2.0
    z_4_5_3_10        OCC_5_3_4       -1.0
    z_4_5_3_10        OCC_5_3_5       -1.0
    z_4_5_3_10        CLS_4_3_4       -1.0
    z_4_5_3_10        CLS_4_3_5       -1.0
    z_4_6_0_0         OBJ           0.0
    z_4_6_0_0         DAY_4_6_0       1.0
    z_4_6_0_0         REQ_4_6         1.0
    z_4_6_0_0         OCC_6_0_0       -1.0
    z_4_6_0_0         CLS_4_0_0       -1.0
    z_4_6_0_1         OBJ           0.0
    z_4_6_0_1         DAY_4_6_0       1.0
    z_4_6_0_1         REQ_4_6         1.0
    z_4_6_0_1         OCC_6_0_1       -1.0
    z_4_6_0_1         CLS_4_0_1       -1.0
    z_4_6_0_2         OBJ           0.0
    z_4_6_0_2         DAY_4_6_0       1.0
    z_4_6_0_2         REQ_4_6         1.0
    z_4_6_0_2         OCC_6_0_2       -1.0
    z_4_6_0_2         CLS_4_0_2       -1.0
    z_4_6_0_3         OBJ           0.0
    z_4_6_0_3         DAY_4_6_0       1.0
    z_4_6_0_3         REQ_4_6         1.0
    z_4_6_0_3         OCC_6_0_3       -1.0
    z_4_6_0_3         CLS_4_0_3       -1.0
    z_4_6_0_4         OBJ           0.0
    z_4_6_0_4         DAY_4_6_0       1.0
    z_4_6_0_4         REQ_4_6         1.0
    z_4_6_0_4         OCC_6_0_4       -1.0
    z_4_6_0_4         CLS_4_0_4       -1.0
    z_4_6_0_5         OBJ           0.0
    z_4_6_0_5         DAY_4_6_0       1.0
    z_4_6_0_5         REQ_4_6         1.0
    z_4_6_0_5         OCC_6_0_5       -1.0
    z_4_6_0_5         CLS_4_0_5       -1.0
    z_4_6_0_6         OBJ           0.0
    z_4_6_0_6         DAY_4_6_0       1.0
    z_4_6_0_6         REQ_4_6         2.0
    z_4_6_0_6         OCC_6_0_0       -1.0
    z_4_6_0_6         OCC_6_0_1       -1.0
    z_4_6_0_6         CLS_4_0_0       -1.0
    z_4_6_0_6         CLS_4_0_1       -1.0
    z_4_6_0_7         OBJ           0.0
    z_4_6_0_7         DAY_4_6_0       1.0
    z_4_6_0_7         REQ_4_6         2.0
    z_4_6_0_7         OCC_6_0_1       -1.0
    z_4_6_0_7         OCC_6_0_2       -1.0
    z_4_6_0_7         CLS_4_0_1       -1.0
    z_4_6_0_7         CLS_4_0_2       -1.0
    z_4_6_0_8         OBJ           0.0
    z_4_6_0_8         DAY_4_6_0       1.0
    z_4_6_0_8         REQ_4_6         2.0
    z_4_6_0_8         OCC_6_0_2       -1.0
    z_4_6_0_8         OCC_6_0_3       -1.0
    z_4_6_0_8         CLS_4_0_2       -1.0
    z_4_6_0_8         CLS_4_0_3       -1.0
    z_4_6_0_9         OBJ           0.0
    z_4_6_0_9         DAY_4_6_0       1.0
    z_4_6_0_9         REQ_4_6         2.0
    z_4_6_0_9         OCC_6_0_3       -1.0
    z_4_6_0_9         OCC_6_0_4       -1.0
    z_4_6_0_9         CLS_4_0_3       -1.0
    z_4_6_0_9         CLS_4_0_4       -1.0
    z_4_6_0_10        OBJ           0.0
    z_4_6_0_10        DAY_4_6_0       1.0
    z_4_6_0_10        REQ_4_6         2.0
    z_4_6_0_10        OCC_6_0_4       -1.0
    z_4_6_0_10        OCC_6_0_5       -1.0
    z_4_6_0_10        CLS_4_0_4       -1.0
    z_4_6_0_10        CLS_4_0_5       -1.0
    z_4_6_1_0         OBJ           0.0
    z_4_6_1_0         DAY_4_6_1       1.0
    z_4_6_1_0         REQ_4_6         1.0
    z_4_6_1_0         OCC_6_1_0       -1.0
    z_4_6_1_0         CLS_4_1_0       -1.0
    z_4_6_1_1         OBJ           0.0
    z_4_6_1_1         DAY_4_6_1       1.0
    z_4_6_1_1         REQ_4_6         1.0
    z_4_6_1_1         OCC_6_1_1       -1.0
    z_4_6_1_1         CLS_4_1_1       -1.0
    z_4_6_1_2         OBJ           0.0
    z_4_6_1_2         DAY_4_6_1       1.0
    z_4_6_1_2         REQ_4_6         1.0
    z_4_6_1_2         OCC_6_1_2       -1.0
    z_4_6_1_2         CLS_4_1_2       -1.0
    z_4_6_1_3         OBJ           0.0
    z_4_6_1_3         DAY_4_6_1       1.0
    z_4_6_1_3         REQ_4_6         1.0
    z_4_6_1_3         OCC_6_1_3       -1.0
    z_4_6_1_3         CLS_4_1_3       -1.0
    z_4_6_1_4         OBJ           0.0
    z_4_6_1_4         DAY_4_6_1       1.0
    z_4_6_1_4         REQ_4_6         1.0
    z_4_6_1_4         OCC_6_1_4       -1.0
    z_4_6_1_4         CLS_4_1_4       -1.0
    z_4_6_1_5         OBJ           0.0
    z_4_6_1_5         DAY_4_6_1       1.0
    z_4_6_1_5         REQ_4_6         1.0
    z_4_6_1_5         OCC_6_1_5       -1.0
    z_4_6_1_5         CLS_4_1_5       -1.0
    z_4_6_1_6         OBJ           0.0
    z_4_6_1_6         DAY_4_6_1       1.0
    z_4_6_1_6         REQ_4_6         2.0
    z_4_6_1_6         OCC_6_1_0       -1.0
    z_4_6_1_6         OCC_6_1_1       -1.0
    z_4_6_1_6         CLS_4_1_0       -1.0
    z_4_6_1_6         CLS_4_1_1       -1.0
    z_4_6_1_7         OBJ           0.0
    z_4_6_1_7         DAY_4_6_1       1.0
    z_4_6_1_7         REQ_4_6         2.0
    z_4_6_1_7         OCC_6_1_1       -1.0
    z_4_6_1_7         OCC_6_1_2       -1.0
    z_4_6_1_7         CLS_4_1_1       -1.0
    z_4_6_1_7         CLS_4_1_2       -1.0
    z_4_6_1_8         OBJ           0.0
    z_4_6_1_8         DAY_4_6_1       1.0
    z_4_6_1_8         REQ_4_6         2.0
    z_4_6_1_8         OCC_6_1_2       -1.0
    z_4_6_1_8         OCC_6_1_3       -1.0
    z_4_6_1_8         CLS_4_1_2       -1.0
    z_4_6_1_8         CLS_4_1_3       -1.0
    z_4_6_1_9         OBJ           0.0
    z_4_6_1_9         DAY_4_6_1       1.0
    z_4_6_1_9         REQ_4_6         2.0
    z_4_6_1_9         OCC_6_1_3       -1.0
    z_4_6_1_9         OCC_6_1_4       -1.0
    z_4_6_1_9         CLS_4_1_3       -1.0
    z_4_6_1_9         CLS_4_1_4       -1.0
    z_4_6_1_10        OBJ           0.0
    z_4_6_1_10        DAY_4_6_1       1.0
    z_4_6_1_10        REQ_4_6         2.0
    z_4_6_1_10        OCC_6_1_4       -1.0
    z_4_6_1_10        OCC_6_1_5       -1.0
    z_4_6_1_10        CLS_4_1_4       -1.0
    z_4_6_1_10        CLS_4_1_5       -1.0
    z_4_6_2_0         OBJ           0.0
    z_4_6_2_0         DAY_4_6_2       1.0
    z_4_6_2_0         REQ_4_6         1.0
    z_4_6_2_0         OCC_6_2_0       -1.0
    z_4_6_2_0         CLS_4_2_0       -1.0
    z_4_6_2_1         OBJ           0.0
    z_4_6_2_1         DAY_4_6_2       1.0
    z_4_6_2_1         REQ_4_6         1.0
    z_4_6_2_1         OCC_6_2_1       -1.0
    z_4_6_2_1         CLS_4_2_1       -1.0
    z_4_6_2_2         OBJ           0.0
    z_4_6_2_2         DAY_4_6_2       1.0
    z_4_6_2_2         REQ_4_6         1.0
    z_4_6_2_2         OCC_6_2_2       -1.0
    z_4_6_2_2         CLS_4_2_2       -1.0
    z_4_6_2_3         OBJ           0.0
    z_4_6_2_3         DAY_4_6_2       1.0
    z_4_6_2_3         REQ_4_6         1.0
    z_4_6_2_3         OCC_6_2_3       -1.0
    z_4_6_2_3         CLS_4_2_3       -1.0
    z_4_6_2_4         OBJ           0.0
    z_4_6_2_4         DAY_4_6_2       1.0
    z_4_6_2_4         REQ_4_6         1.0
    z_4_6_2_4         OCC_6_2_4       -1.0
    z_4_6_2_4         CLS_4_2_4       -1.0
    z_4_6_2_5         OBJ           0.0
    z_4_6_2_5         DAY_4_6_2       1.0
    z_4_6_2_5         REQ_4_6         2.0
    z_4_6_2_5         OCC_6_2_0       -1.0
    z_4_6_2_5         OCC_6_2_1       -1.0
    z_4_6_2_5         CLS_4_2_0       -1.0
    z_4_6_2_5         CLS_4_2_1       -1.0
    z_4_6_2_6         OBJ           0.0
    z_4_6_2_6         DAY_4_6_2       1.0
    z_4_6_2_6         REQ_4_6         2.0
    z_4_6_2_6         OCC_6_2_1       -1.0
    z_4_6_2_6         OCC_6_2_2       -1.0
    z_4_6_2_6         CLS_4_2_1       -1.0
    z_4_6_2_6         CLS_4_2_2       -1.0
    z_4_6_2_7         OBJ           0.0
    z_4_6_2_7         DAY_4_6_2       1.0
    z_4_6_2_7         REQ_4_6         2.0
    z_4_6_2_7         OCC_6_2_2       -1.0
    z_4_6_2_7         OCC_6_2_3       -1.0
    z_4_6_2_7         CLS_4_2_2       -1.0
    z_4_6_2_7         CLS_4_2_3       -1.0
    z_4_6_2_8         OBJ           0.0
    z_4_6_2_8         DAY_4_6_2       1.0
    z_4_6_2_8         REQ_4_6         2.0
    z_4_6_2_8         OCC_6_2_3       -1.0
    z_4_6_2_8         OCC_6_2_4       -1.0
    z_4_6_2_8         CLS_4_2_3       -1.0
    z_4_6_2_8         CLS_4_2_4       -1.0
    z_4_6_3_0         OBJ           0.0
    z_4_6_3_0         DAY_4_6_3       1.0
    z_4_6_3_0         REQ_4_6         1.0
    z_4_6_3_0         OCC_6_3_0       -1.0
    z_4_6_3_0         CLS_4_3_0       -1.0
    z_4_6_3_1         OBJ           0.0
    z_4_6_3_1         DAY_4_6_3       1.0
    z_4_6_3_1         REQ_4_6         1.0
    z_4_6_3_1         OCC_6_3_1       -1.0
    z_4_6_3_1         CLS_4_3_1       -1.0
    z_4_6_3_2         OBJ           0.0
    z_4_6_3_2         DAY_4_6_3       1.0
    z_4_6_3_2         REQ_4_6         1.0
    z_4_6_3_2         OCC_6_3_2       -1.0
    z_4_6_3_2         CLS_4_3_2       -1.0
    z_4_6_3_3         OBJ           0.0
    z_4_6_3_3         DAY_4_6_3       1.0
    z_4_6_3_3         REQ_4_6         1.0
    z_4_6_3_3         OCC_6_3_3       -1.0
    z_4_6_3_3         CLS_4_3_3       -1.0
    z_4_6_3_4         OBJ           0.0
    z_4_6_3_4         DAY_4_6_3       1.0
    z_4_6_3_4         REQ_4_6         1.0
    z_4_6_3_4         OCC_6_3_5       -1.0
    z_4_6_3_4         CLS_4_3_5       -1.0
    z_4_6_3_5         OBJ           0.0
    z_4_6_3_5         DAY_4_6_3       1.0
    z_4_6_3_5         REQ_4_6         2.0
    z_4_6_3_5         OCC_6_3_0       -1.0
    z_4_6_3_5         OCC_6_3_1       -1.0
    z_4_6_3_5         CLS_4_3_0       -1.0
    z_4_6_3_5         CLS_4_3_1       -1.0
    z_4_6_3_6         OBJ           0.0
    z_4_6_3_6         DAY_4_6_3       1.0
    z_4_6_3_6         REQ_4_6         2.0
    z_4_6_3_6         OCC_6_3_1       -1.0
    z_4_6_3_6         OCC_6_3_2       -1.0
    z_4_6_3_6         CLS_4_3_1       -1.0
    z_4_6_3_6         CLS_4_3_2       -1.0
    z_4_6_3_7         OBJ           0.0
    z_4_6_3_7         DAY_4_6_3       1.0
    z_4_6_3_7         REQ_4_6         2.0
    z_4_6_3_7         OCC_6_3_2       -1.0
    z_4_6_3_7         OCC_6_3_3       -1.0
    z_4_6_3_7         CLS_4_3_2       -1.0
    z_4_6_3_7         CLS_4_3_3       -1.0
    z_4_6_4_0         OBJ           0.0
    z_4_6_4_0         DAY_4_6_4       1.0
    z_4_6_4_0         REQ_4_6         1.0
    z_4_6_4_0         OCC_6_4_0       -1.0
    z_4_6_4_0         CLS_4_4_0       -1.0
    z_4_6_4_1         OBJ           0.0
    z_4_6_4_1         DAY_4_6_4       1.0
    z_4_6_4_1         REQ_4_6         1.0
    z_4_6_4_1         OCC_6_4_1       -1.0
    z_4_6_4_1         CLS_4_4_1       -1.0
    z_4_6_4_2         OBJ           0.0
    z_4_6_4_2         DAY_4_6_4       1.0
    z_4_6_4_2         REQ_4_6         1.0
    z_4_6_4_2         OCC_6_4_2       -1.0
    z_4_6_4_2         CLS_4_4_2       -1.0
    z_4_6_4_3         OBJ           0.0
    z_4_6_4_3         DAY_4_6_4       1.0
    z_4_6_4_3         REQ_4_6         1.0
    z_4_6_4_3         OCC_6_4_3       -1.0
    z_4_6_4_3         CLS_4_4_3       -1.0
    z_4_6_4_4         OBJ           0.0
    z_4_6_4_4         DAY_4_6_4       1.0
    z_4_6_4_4         REQ_4_6         1.0
    z_4_6_4_4         OCC_6_4_4       -1.0
    z_4_6_4_4         CLS_4_4_4       -1.0
    z_4_6_4_5         OBJ           0.0
    z_4_6_4_5         DAY_4_6_4       1.0
    z_4_6_4_5         REQ_4_6         1.0
    z_4_6_4_5         OCC_6_4_5       -1.0
    z_4_6_4_5         CLS_4_4_5       -1.0
    z_4_6_4_6         OBJ           0.0
    z_4_6_4_6         DAY_4_6_4       1.0
    z_4_6_4_6         REQ_4_6         2.0
    z_4_6_4_6         OCC_6_4_0       -1.0
    z_4_6_4_6         OCC_6_4_1       -1.0
    z_4_6_4_6         CLS_4_4_0       -1.0
    z_4_6_4_6         CLS_4_4_1       -1.0
    z_4_6_4_7         OBJ           0.0
    z_4_6_4_7         DAY_4_6_4       1.0
    z_4_6_4_7         REQ_4_6         2.0
    z_4_6_4_7         OCC_6_4_1       -1.0
    z_4_6_4_7         OCC_6_4_2       -1.0
    z_4_6_4_7         CLS_4_4_1       -1.0
    z_4_6_4_7         CLS_4_4_2       -1.0
    z_4_6_4_8         OBJ           0.0
    z_4_6_4_8         DAY_4_6_4       1.0
    z_4_6_4_8         REQ_4_6         2.0
    z_4_6_4_8         OCC_6_4_2       -1.0
    z_4_6_4_8         OCC_6_4_3       -1.0
    z_4_6_4_8         CLS_4_4_2       -1.0
    z_4_6_4_8         CLS_4_4_3       -1.0
    z_4_6_4_9         OBJ           0.0
    z_4_6_4_9         DAY_4_6_4       1.0
    z_4_6_4_9         REQ_4_6         2.0
    z_4_6_4_9         OCC_6_4_3       -1.0
    z_4_6_4_9         OCC_6_4_4       -1.0
    z_4_6_4_9         CLS_4_4_3       -1.0
    z_4_6_4_9         CLS_4_4_4       -1.0
    z_4_6_4_10        OBJ           0.0
    z_4_6_4_10        DAY_4_6_4       1.0
    z_4_6_4_10        REQ_4_6         2.0
    z_4_6_4_10        OCC_6_4_4       -1.0
    z_4_6_4_10        OCC_6_4_5       -1.0
    z_4_6_4_10        CLS_4_4_4       -1.0
    z_4_6_4_10        CLS_4_4_5       -1.0
    z_4_7_0_0         OBJ           0.0
    z_4_7_0_0         DAY_4_7_0       1.0
    z_4_7_0_0         REQ_4_7         1.0
    z_4_7_0_0         OCC_7_0_0       -1.0
    z_4_7_0_0         CLS_4_0_0       -1.0
    z_4_7_0_1         OBJ           0.0
    z_4_7_0_1         DAY_4_7_0       1.0
    z_4_7_0_1         REQ_4_7         1.0
    z_4_7_0_1         OCC_7_0_1       -1.0
    z_4_7_0_1         CLS_4_0_1       -1.0
    z_4_7_0_2         OBJ           0.0
    z_4_7_0_2         DAY_4_7_0       1.0
    z_4_7_0_2         REQ_4_7         1.0
    z_4_7_0_2         OCC_7_0_2       -1.0
    z_4_7_0_2         CLS_4_0_2       -1.0
    z_4_7_0_3         OBJ           0.0
    z_4_7_0_3         DAY_4_7_0       1.0
    z_4_7_0_3         REQ_4_7         1.0
    z_4_7_0_3         OCC_7_0_3       -1.0
    z_4_7_0_3         CLS_4_0_3       -1.0
    z_4_7_0_4         OBJ           0.0
    z_4_7_0_4         DAY_4_7_0       1.0
    z_4_7_0_4         REQ_4_7         1.0
    z_4_7_0_4         OCC_7_0_5       -1.0
    z_4_7_0_4         CLS_4_0_5       -1.0
    z_4_7_0_5         OBJ           0.0
    z_4_7_0_5         DAY_4_7_0       1.0
    z_4_7_0_5         REQ_4_7         2.0
    z_4_7_0_5         OCC_7_0_0       -1.0
    z_4_7_0_5         OCC_7_0_1       -1.0
    z_4_7_0_5         CLS_4_0_0       -1.0
    z_4_7_0_5         CLS_4_0_1       -1.0
    z_4_7_0_6         OBJ           0.0
    z_4_7_0_6         DAY_4_7_0       1.0
    z_4_7_0_6         REQ_4_7         2.0
    z_4_7_0_6         OCC_7_0_1       -1.0
    z_4_7_0_6         OCC_7_0_2       -1.0
    z_4_7_0_6         CLS_4_0_1       -1.0
    z_4_7_0_6         CLS_4_0_2       -1.0
    z_4_7_0_7         OBJ           0.0
    z_4_7_0_7         DAY_4_7_0       1.0
    z_4_7_0_7         REQ_4_7         2.0
    z_4_7_0_7         OCC_7_0_2       -1.0
    z_4_7_0_7         OCC_7_0_3       -1.0
    z_4_7_0_7         CLS_4_0_2       -1.0
    z_4_7_0_7         CLS_4_0_3       -1.0
    z_4_7_1_0         OBJ           0.0
    z_4_7_1_0         DAY_4_7_1       1.0
    z_4_7_1_0         REQ_4_7         1.0
    z_4_7_1_0         OCC_7_1_0       -1.0
    z_4_7_1_0         CLS_4_1_0       -1.0
    z_4_7_1_1         OBJ           0.0
    z_4_7_1_1         DAY_4_7_1       1.0
    z_4_7_1_1         REQ_4_7         1.0
    z_4_7_1_1         OCC_7_1_1       -1.0
    z_4_7_1_1         CLS_4_1_1       -1.0
    z_4_7_1_2         OBJ           0.0
    z_4_7_1_2         DAY_4_7_1       1.0
    z_4_7_1_2         REQ_4_7         1.0
    z_4_7_1_2         OCC_7_1_2       -1.0
    z_4_7_1_2         CLS_4_1_2       -1.0
    z_4_7_1_3         OBJ           0.0
    z_4_7_1_3         DAY_4_7_1       1.0
    z_4_7_1_3         REQ_4_7         1.0
    z_4_7_1_3         OCC_7_1_3       -1.0
    z_4_7_1_3         CLS_4_1_3       -1.0
    z_4_7_1_4         OBJ           0.0
    z_4_7_1_4         DAY_4_7_1       1.0
    z_4_7_1_4         REQ_4_7         1.0
    z_4_7_1_4         OCC_7_1_4       -1.0
    z_4_7_1_4         CLS_4_1_4       -1.0
    z_4_7_1_5         OBJ           0.0
    z_4_7_1_5         DAY_4_7_1       1.0
    z_4_7_1_5         REQ_4_7         1.0
    z_4_7_1_5         OCC_7_1_5       -1.0
    z_4_7_1_5         CLS_4_1_5       -1.0
    z_4_7_1_6         OBJ           0.0
    z_4_7_1_6         DAY_4_7_1       1.0
    z_4_7_1_6         REQ_4_7         2.0
    z_4_7_1_6         OCC_7_1_0       -1.0
    z_4_7_1_6         OCC_7_1_1       -1.0
    z_4_7_1_6         CLS_4_1_0       -1.0
    z_4_7_1_6         CLS_4_1_1       -1.0
    z_4_7_1_7         OBJ           0.0
    z_4_7_1_7         DAY_4_7_1       1.0
    z_4_7_1_7         REQ_4_7         2.0
    z_4_7_1_7         OCC_7_1_1       -1.0
    z_4_7_1_7         OCC_7_1_2       -1.0
    z_4_7_1_7         CLS_4_1_1       -1.0
    z_4_7_1_7         CLS_4_1_2       -1.0
    z_4_7_1_8         OBJ           0.0
    z_4_7_1_8         DAY_4_7_1       1.0
    z_4_7_1_8         REQ_4_7         2.0
    z_4_7_1_8         OCC_7_1_2       -1.0
    z_4_7_1_8         OCC_7_1_3       -1.0
    z_4_7_1_8         CLS_4_1_2       -1.0
    z_4_7_1_8         CLS_4_1_3       -1.0
    z_4_7_1_9         OBJ           0.0
    z_4_7_1_9         DAY_4_7_1       1.0
    z_4_7_1_9         REQ_4_7         2.0
    z_4_7_1_9         OCC_7_1_3       -1.0
    z_4_7_1_9         OCC_7_1_4       -1.0
    z_4_7_1_9         CLS_4_1_3       -1.0
    z_4_7_1_9         CLS_4_1_4       -1.0
    z_4_7_1_10        OBJ           0.0
    z_4_7_1_10        DAY_4_7_1       1.0
    z_4_7_1_10        REQ_4_7         2.0
    z_4_7_1_10        OCC_7_1_4       -1.0
    z_4_7_1_10        OCC_7_1_5       -1.0
    z_4_7_1_10        CLS_4_1_4       -1.0
    z_4_7_1_10        CLS_4_1_5       -1.0
    z_4_7_2_0         OBJ           0.0
    z_4_7_2_0         DAY_4_7_2       1.0
    z_4_7_2_0         REQ_4_7         1.0
    z_4_7_2_0         OCC_7_2_0       -1.0
    z_4_7_2_0         CLS_4_2_0       -1.0
    z_4_7_2_1         OBJ           0.0
    z_4_7_2_1         DAY_4_7_2       1.0
    z_4_7_2_1         REQ_4_7         1.0
    z_4_7_2_1         OCC_7_2_1       -1.0
    z_4_7_2_1         CLS_4_2_1       -1.0
    z_4_7_2_2         OBJ           0.0
    z_4_7_2_2         DAY_4_7_2       1.0
    z_4_7_2_2         REQ_4_7         1.0
    z_4_7_2_2         OCC_7_2_2       -1.0
    z_4_7_2_2         CLS_4_2_2       -1.0
    z_4_7_2_3         OBJ           0.0
    z_4_7_2_3         DAY_4_7_2       1.0
    z_4_7_2_3         REQ_4_7         1.0
    z_4_7_2_3         OCC_7_2_3       -1.0
    z_4_7_2_3         CLS_4_2_3       -1.0
    z_4_7_2_4         OBJ           0.0
    z_4_7_2_4         DAY_4_7_2       1.0
    z_4_7_2_4         REQ_4_7         1.0
    z_4_7_2_4         OCC_7_2_4       -1.0
    z_4_7_2_4         CLS_4_2_4       -1.0
    z_4_7_2_5         OBJ           0.0
    z_4_7_2_5         DAY_4_7_2       1.0
    z_4_7_2_5         REQ_4_7         1.0
    z_4_7_2_5         OCC_7_2_5       -1.0
    z_4_7_2_5         CLS_4_2_5       -1.0
    z_4_7_2_6         OBJ           0.0
    z_4_7_2_6         DAY_4_7_2       1.0
    z_4_7_2_6         REQ_4_7         2.0
    z_4_7_2_6         OCC_7_2_0       -1.0
    z_4_7_2_6         OCC_7_2_1       -1.0
    z_4_7_2_6         CLS_4_2_0       -1.0
    z_4_7_2_6         CLS_4_2_1       -1.0
    z_4_7_2_7         OBJ           0.0
    z_4_7_2_7         DAY_4_7_2       1.0
    z_4_7_2_7         REQ_4_7         2.0
    z_4_7_2_7         OCC_7_2_1       -1.0
    z_4_7_2_7         OCC_7_2_2       -1.0
    z_4_7_2_7         CLS_4_2_1       -1.0
    z_4_7_2_7         CLS_4_2_2       -1.0
    z_4_7_2_8         OBJ           0.0
    z_4_7_2_8         DAY_4_7_2       1.0
    z_4_7_2_8         REQ_4_7         2.0
    z_4_7_2_8         OCC_7_2_2       -1.0
    z_4_7_2_8         OCC_7_2_3       -1.0
    z_4_7_2_8         CLS_4_2_2       -1.0
    z_4_7_2_8         CLS_4_2_3       -1.0
    z_4_7_2_9         OBJ           0.0
    z_4_7_2_9         DAY_4_7_2       1.0
    z_4_7_2_9         REQ_4_7         2.0
    z_4_7_2_9         OCC_7_2_3       -1.0
    z_4_7_2_9         OCC_7_2_4       -1.0
    z_4_7_2_9         CLS_4_2_3       -1.0
    z_4_7_2_9         CLS_4_2_4       -1.0
    z_4_7_2_10        OBJ           0.0
    z_4_7_2_10        DAY_4_7_2       1.0
    z_4_7_2_10        REQ_4_7         2.0
    z_4_7_2_10        OCC_7_2_4       -1.0
    z_4_7_2_10        OCC_7_2_5       -1.0
    z_4_7_2_10        CLS_4_2_4       -1.0
    z_4_7_2_10        CLS_4_2_5       -1.0
    z_4_7_3_0         OBJ           0.0
    z_4_7_3_0         DAY_4_7_3       1.0
    z_4_7_3_0         REQ_4_7         1.0
    z_4_7_3_0         OCC_7_3_0       -1.0
    z_4_7_3_0         CLS_4_3_0       -1.0
    z_4_7_3_1         OBJ           0.0
    z_4_7_3_1         DAY_4_7_3       1.0
    z_4_7_3_1         REQ_4_7         1.0
    z_4_7_3_1         OCC_7_3_1       -1.0
    z_4_7_3_1         CLS_4_3_1       -1.0
    z_4_7_3_2         OBJ           0.0
    z_4_7_3_2         DAY_4_7_3       1.0
    z_4_7_3_2         REQ_4_7         1.0
    z_4_7_3_2         OCC_7_3_2       -1.0
    z_4_7_3_2         CLS_4_3_2       -1.0
    z_4_7_3_3         OBJ           0.0
    z_4_7_3_3         DAY_4_7_3       1.0
    z_4_7_3_3         REQ_4_7         1.0
    z_4_7_3_3         OCC_7_3_3       -1.0
    z_4_7_3_3         CLS_4_3_3       -1.0
    z_4_7_3_4         OBJ           0.0
    z_4_7_3_4         DAY_4_7_3       1.0
    z_4_7_3_4         REQ_4_7         1.0
    z_4_7_3_4         OCC_7_3_4       -1.0
    z_4_7_3_4         CLS_4_3_4       -1.0
    z_4_7_3_5         OBJ           0.0
    z_4_7_3_5         DAY_4_7_3       1.0
    z_4_7_3_5         REQ_4_7         1.0
    z_4_7_3_5         OCC_7_3_5       -1.0
    z_4_7_3_5         CLS_4_3_5       -1.0
    z_4_7_3_6         OBJ           0.0
    z_4_7_3_6         DAY_4_7_3       1.0
    z_4_7_3_6         REQ_4_7         2.0
    z_4_7_3_6         OCC_7_3_0       -1.0
    z_4_7_3_6         OCC_7_3_1       -1.0
    z_4_7_3_6         CLS_4_3_0       -1.0
    z_4_7_3_6         CLS_4_3_1       -1.0
    z_4_7_3_7         OBJ           0.0
    z_4_7_3_7         DAY_4_7_3       1.0
    z_4_7_3_7         REQ_4_7         2.0
    z_4_7_3_7         OCC_7_3_1       -1.0
    z_4_7_3_7         OCC_7_3_2       -1.0
    z_4_7_3_7         CLS_4_3_1       -1.0
    z_4_7_3_7         CLS_4_3_2       -1.0
    z_4_7_3_8         OBJ           0.0
    z_4_7_3_8         DAY_4_7_3       1.0
    z_4_7_3_8         REQ_4_7         2.0
    z_4_7_3_8         OCC_7_3_2       -1.0
    z_4_7_3_8         OCC_7_3_3       -1.0
    z_4_7_3_8         CLS_4_3_2       -1.0
    z_4_7_3_8         CLS_4_3_3       -1.0
    z_4_7_3_9         OBJ           0.0
    z_4_7_3_9         DAY_4_7_3       1.0
    z_4_7_3_9         REQ_4_7         2.0
    z_4_7_3_9         OCC_7_3_3       -1.0
    z_4_7_3_9         OCC_7_3_4       -1.0
    z_4_7_3_9         CLS_4_3_3       -1.0
    z_4_7_3_9         CLS_4_3_4       -1.0
    z_4_7_3_10        OBJ           0.0
    z_4_7_3_10        DAY_4_7_3       1.0
    z_4_7_3_10        REQ_4_7         2.0
    z_4_7_3_10        OCC_7_3_4       -1.0
    z_4_7_3_10        OCC_7_3_5       -1.0
    z_4_7_3_10        CLS_4_3_4       -1.0
    z_4_7_3_10        CLS_4_3_5       -1.0
    z_4_7_4_0         OBJ           0.0
    z_4_7_4_0         DAY_4_7_4       1.0
    z_4_7_4_0         REQ_4_7         1.0
    z_4_7_4_0         OCC_7_4_0       -1.0
    z_4_7_4_0         CLS_4_4_0       -1.0
    z_4_7_4_1         OBJ           0.0
    z_4_7_4_1         DAY_4_7_4       1.0
    z_4_7_4_1         REQ_4_7         1.0
    z_4_7_4_1         OCC_7_4_1       -1.0
    z_4_7_4_1         CLS_4_4_1       -1.0
    z_4_7_4_2         OBJ           0.0
    z_4_7_4_2         DAY_4_7_4       1.0
    z_4_7_4_2         REQ_4_7         1.0
    z_4_7_4_2         OCC_7_4_2       -1.0
    z_4_7_4_2         CLS_4_4_2       -1.0
    z_4_7_4_3         OBJ           0.0
    z_4_7_4_3         DAY_4_7_4       1.0
    z_4_7_4_3         REQ_4_7         1.0
    z_4_7_4_3         OCC_7_4_3       -1.0
    z_4_7_4_3         CLS_4_4_3       -1.0
    z_4_7_4_4         OBJ           0.0
    z_4_7_4_4         DAY_4_7_4       1.0
    z_4_7_4_4         REQ_4_7         1.0
    z_4_7_4_4         OCC_7_4_4       -1.0
    z_4_7_4_4         CLS_4_4_4       -1.0
    z_4_7_4_5         OBJ           0.0
    z_4_7_4_5         DAY_4_7_4       1.0
    z_4_7_4_5         REQ_4_7         1.0
    z_4_7_4_5         OCC_7_4_5       -1.0
    z_4_7_4_5         CLS_4_4_5       -1.0
    z_4_7_4_6         OBJ           0.0
    z_4_7_4_6         DAY_4_7_4       1.0
    z_4_7_4_6         REQ_4_7         2.0
    z_4_7_4_6         OCC_7_4_0       -1.0
    z_4_7_4_6         OCC_7_4_1       -1.0
    z_4_7_4_6         CLS_4_4_0       -1.0
    z_4_7_4_6         CLS_4_4_1       -1.0
    z_4_7_4_7         OBJ           0.0
    z_4_7_4_7         DAY_4_7_4       1.0
    z_4_7_4_7         REQ_4_7         2.0
    z_4_7_4_7         OCC_7_4_1       -1.0
    z_4_7_4_7         OCC_7_4_2       -1.0
    z_4_7_4_7         CLS_4_4_1       -1.0
    z_4_7_4_7         CLS_4_4_2       -1.0
    z_4_7_4_8         OBJ           0.0
    z_4_7_4_8         DAY_4_7_4       1.0
    z_4_7_4_8         REQ_4_7         2.0
    z_4_7_4_8         OCC_7_4_2       -1.0
    z_4_7_4_8         OCC_7_4_3       -1.0
    z_4_7_4_8         CLS_4_4_2       -1.0
    z_4_7_4_8         CLS_4_4_3       -1.0
    z_4_7_4_9         OBJ           0.0
    z_4_7_4_9         DAY_4_7_4       1.0
    z_4_7_4_9         REQ_4_7         2.0
    z_4_7_4_9         OCC_7_4_3       -1.0
    z_4_7_4_9         OCC_7_4_4       -1.0
    z_4_7_4_9         CLS_4_4_3       -1.0
    z_4_7_4_9         CLS_4_4_4       -1.0
    z_4_7_4_10        OBJ           0.0
    z_4_7_4_10        DAY_4_7_4       1.0
    z_4_7_4_10        REQ_4_7         2.0
    z_4_7_4_10        OCC_7_4_4       -1.0
    z_4_7_4_10        OCC_7_4_5       -1.0
    z_4_7_4_10        CLS_4_4_4       -1.0
    z_4_7_4_10        CLS_4_4_5       -1.0
    z_5_0_0_0         OBJ           0.0
    z_5_0_0_0         DAY_5_0_0       1.0
    z_5_0_0_0         REQ_5_0         1.0
    z_5_0_0_0         OCC_0_0_0       -1.0
    z_5_0_0_0         CLS_5_0_0       -1.0
    z_5_0_0_1         OBJ           0.0
    z_5_0_0_1         DAY_5_0_0       1.0
    z_5_0_0_1         REQ_5_0         1.0
    z_5_0_0_1         OCC_0_0_1       -1.0
    z_5_0_0_1         CLS_5_0_1       -1.0
    z_5_0_0_2         OBJ           0.0
    z_5_0_0_2         DAY_5_0_0       1.0
    z_5_0_0_2         REQ_5_0         1.0
    z_5_0_0_2         OCC_0_0_2       -1.0
    z_5_0_0_2         CLS_5_0_2       -1.0
    z_5_0_0_3         OBJ           0.0
    z_5_0_0_3         DAY_5_0_0       1.0
    z_5_0_0_3         REQ_5_0         1.0
    z_5_0_0_3         OCC_0_0_3       -1.0
    z_5_0_0_3         CLS_5_0_3       -1.0
    z_5_0_0_4         OBJ           0.0
    z_5_0_0_4         DAY_5_0_0       1.0
    z_5_0_0_4         REQ_5_0         1.0
    z_5_0_0_4         OCC_0_0_4       -1.0
    z_5_0_0_4         CLS_5_0_4       -1.0
    z_5_0_0_5         OBJ           0.0
    z_5_0_0_5         DAY_5_0_0       1.0
    z_5_0_0_5         REQ_5_0         1.0
    z_5_0_0_5         OCC_0_0_5       -1.0
    z_5_0_0_5         CLS_5_0_5       -1.0
    z_5_0_0_6         OBJ           0.0
    z_5_0_0_6         DAY_5_0_0       1.0
    z_5_0_0_6         REQ_5_0         2.0
    z_5_0_0_6         OCC_0_0_0       -1.0
    z_5_0_0_6         OCC_0_0_1       -1.0
    z_5_0_0_6         CLS_5_0_0       -1.0
    z_5_0_0_6         CLS_5_0_1       -1.0
    z_5_0_0_7         OBJ           0.0
    z_5_0_0_7         DAY_5_0_0       1.0
    z_5_0_0_7         REQ_5_0         2.0
    z_5_0_0_7         OCC_0_0_1       -1.0
    z_5_0_0_7         OCC_0_0_2       -1.0
    z_5_0_0_7         CLS_5_0_1       -1.0
    z_5_0_0_7         CLS_5_0_2       -1.0
    z_5_0_0_8         OBJ           0.0
    z_5_0_0_8         DAY_5_0_0       1.0
    z_5_0_0_8         REQ_5_0         2.0
    z_5_0_0_8         OCC_0_0_2       -1.0
    z_5_0_0_8         OCC_0_0_3       -1.0
    z_5_0_0_8         CLS_5_0_2       -1.0
    z_5_0_0_8         CLS_5_0_3       -1.0
    z_5_0_0_9         OBJ           0.0
    z_5_0_0_9         DAY_5_0_0       1.0
    z_5_0_0_9         REQ_5_0         2.0
    z_5_0_0_9         OCC_0_0_3       -1.0
    z_5_0_0_9         OCC_0_0_4       -1.0
    z_5_0_0_9         CLS_5_0_3       -1.0
    z_5_0_0_9         CLS_5_0_4       -1.0
    z_5_0_0_10        OBJ           0.0
    z_5_0_0_10        DAY_5_0_0       1.0
    z_5_0_0_10        REQ_5_0         2.0
    z_5_0_0_10        OCC_0_0_4       -1.0
    z_5_0_0_10        OCC_0_0_5       -1.0
    z_5_0_0_10        CLS_5_0_4       -1.0
    z_5_0_0_10        CLS_5_0_5       -1.0
    z_5_0_1_0         OBJ           0.0
    z_5_0_1_0         DAY_5_0_1       1.0
    z_5_0_1_0         REQ_5_0         1.0
    z_5_0_1_0         OCC_0_1_0       -1.0
    z_5_0_1_0         CLS_5_1_0       -1.0
    z_5_0_1_1         OBJ           0.0
    z_5_0_1_1         DAY_5_0_1       1.0
    z_5_0_1_1         REQ_5_0         1.0
    z_5_0_1_1         OCC_0_1_1       -1.0
    z_5_0_1_1         CLS_5_1_1       -1.0
    z_5_0_1_2         OBJ           0.0
    z_5_0_1_2         DAY_5_0_1       1.0
    z_5_0_1_2         REQ_5_0         1.0
    z_5_0_1_2         OCC_0_1_2       -1.0
    z_5_0_1_2         CLS_5_1_2       -1.0
    z_5_0_1_3         OBJ           0.0
    z_5_0_1_3         DAY_5_0_1       1.0
    z_5_0_1_3         REQ_5_0         1.0
    z_5_0_1_3         OCC_0_1_3       -1.0
    z_5_0_1_3         CLS_5_1_3       -1.0
    z_5_0_1_4         OBJ           0.0
    z_5_0_1_4         DAY_5_0_1       1.0
    z_5_0_1_4         REQ_5_0         1.0
    z_5_0_1_4         OCC_0_1_4       -1.0
    z_5_0_1_4         CLS_5_1_4       -1.0
    z_5_0_1_5         OBJ           0.0
    z_5_0_1_5         DAY_5_0_1       1.0
    z_5_0_1_5         REQ_5_0         1.0
    z_5_0_1_5         OCC_0_1_5       -1.0
    z_5_0_1_5         CLS_5_1_5       -1.0
    z_5_0_1_6         OBJ           0.0
    z_5_0_1_6         DAY_5_0_1       1.0
    z_5_0_1_6         REQ_5_0         2.0
    z_5_0_1_6         OCC_0_1_0       -1.0
    z_5_0_1_6         OCC_0_1_1       -1.0
    z_5_0_1_6         CLS_5_1_0       -1.0
    z_5_0_1_6         CLS_5_1_1       -1.0
    z_5_0_1_7         OBJ           0.0
    z_5_0_1_7         DAY_5_0_1       1.0
    z_5_0_1_7         REQ_5_0         2.0
    z_5_0_1_7         OCC_0_1_1       -1.0
    z_5_0_1_7         OCC_0_1_2       -1.0
    z_5_0_1_7         CLS_5_1_1       -1.0
    z_5_0_1_7         CLS_5_1_2       -1.0
    z_5_0_1_8         OBJ           0.0
    z_5_0_1_8         DAY_5_0_1       1.0
    z_5_0_1_8         REQ_5_0         2.0
    z_5_0_1_8         OCC_0_1_2       -1.0
    z_5_0_1_8         OCC_0_1_3       -1.0
    z_5_0_1_8         CLS_5_1_2       -1.0
    z_5_0_1_8         CLS_5_1_3       -1.0
    z_5_0_1_9         OBJ           0.0
    z_5_0_1_9         DAY_5_0_1       1.0
    z_5_0_1_9         REQ_5_0         2.0
    z_5_0_1_9         OCC_0_1_3       -1.0
    z_5_0_1_9         OCC_0_1_4       -1.0
    z_5_0_1_9         CLS_5_1_3       -1.0
    z_5_0_1_9         CLS_5_1_4       -1.0
    z_5_0_1_10        OBJ           0.0
    z_5_0_1_10        DAY_5_0_1       1.0
    z_5_0_1_10        REQ_5_0         2.0
    z_5_0_1_10        OCC_0_1_4       -1.0
    z_5_0_1_10        OCC_0_1_5       -1.0
    z_5_0_1_10        CLS_5_1_4       -1.0
    z_5_0_1_10        CLS_5_1_5       -1.0
    z_5_0_2_0         OBJ           0.0
    z_5_0_2_0         DAY_5_0_2       1.0
    z_5_0_2_0         REQ_5_0         1.0
    z_5_0_2_0         OCC_0_2_0       -1.0
    z_5_0_2_0         CLS_5_2_0       -1.0
    z_5_0_2_1         OBJ           0.0
    z_5_0_2_1         DAY_5_0_2       1.0
    z_5_0_2_1         REQ_5_0         1.0
    z_5_0_2_1         OCC_0_2_1       -1.0
    z_5_0_2_1         CLS_5_2_1       -1.0
    z_5_0_2_2         OBJ           0.0
    z_5_0_2_2         DAY_5_0_2       1.0
    z_5_0_2_2         REQ_5_0         1.0
    z_5_0_2_2         OCC_0_2_2       -1.0
    z_5_0_2_2         CLS_5_2_2       -1.0
    z_5_0_2_3         OBJ           0.0
    z_5_0_2_3         DAY_5_0_2       1.0
    z_5_0_2_3         REQ_5_0         1.0
    z_5_0_2_3         OCC_0_2_3       -1.0
    z_5_0_2_3         CLS_5_2_3       -1.0
    z_5_0_2_4         OBJ           0.0
    z_5_0_2_4         DAY_5_0_2       1.0
    z_5_0_2_4         REQ_5_0         1.0
    z_5_0_2_4         OCC_0_2_4       -1.0
    z_5_0_2_4         CLS_5_2_4       -1.0
    z_5_0_2_5         OBJ           0.0
    z_5_0_2_5         DAY_5_0_2       1.0
    z_5_0_2_5         REQ_5_0         1.0
    z_5_0_2_5         OCC_0_2_5       -1.0
    z_5_0_2_5         CLS_5_2_5       -1.0
    z_5_0_2_6         OBJ           0.0
    z_5_0_2_6         DAY_5_0_2       1.0
    z_5_0_2_6         REQ_5_0         2.0
    z_5_0_2_6         OCC_0_2_0       -1.0
    z_5_0_2_6         OCC_0_2_1       -1.0
    z_5_0_2_6         CLS_5_2_0       -1.0
    z_5_0_2_6         CLS_5_2_1       -1.0
    z_5_0_2_7         OBJ           0.0
    z_5_0_2_7         DAY_5_0_2       1.0
    z_5_0_2_7         REQ_5_0         2.0
    z_5_0_2_7         OCC_0_2_1       -1.0
    z_5_0_2_7         OCC_0_2_2       -1.0
    z_5_0_2_7         CLS_5_2_1       -1.0
    z_5_0_2_7         CLS_5_2_2       -1.0
    z_5_0_2_8         OBJ           0.0
    z_5_0_2_8         DAY_5_0_2       1.0
    z_5_0_2_8         REQ_5_0         2.0
    z_5_0_2_8         OCC_0_2_2       -1.0
    z_5_0_2_8         OCC_0_2_3       -1.0
    z_5_0_2_8         CLS_5_2_2       -1.0
    z_5_0_2_8         CLS_5_2_3       -1.0
    z_5_0_2_9         OBJ           0.0
    z_5_0_2_9         DAY_5_0_2       1.0
    z_5_0_2_9         REQ_5_0         2.0
    z_5_0_2_9         OCC_0_2_3       -1.0
    z_5_0_2_9         OCC_0_2_4       -1.0
    z_5_0_2_9         CLS_5_2_3       -1.0
    z_5_0_2_9         CLS_5_2_4       -1.0
    z_5_0_2_10        OBJ           0.0
    z_5_0_2_10        DAY_5_0_2       1.0
    z_5_0_2_10        REQ_5_0         2.0
    z_5_0_2_10        OCC_0_2_4       -1.0
    z_5_0_2_10        OCC_0_2_5       -1.0
    z_5_0_2_10        CLS_5_2_4       -1.0
    z_5_0_2_10        CLS_5_2_5       -1.0
    z_5_0_3_0         OBJ           0.0
    z_5_0_3_0         DAY_5_0_3       1.0
    z_5_0_3_0         REQ_5_0         1.0
    z_5_0_3_0         OCC_0_3_0       -1.0
    z_5_0_3_0         CLS_5_3_0       -1.0
    z_5_0_3_1         OBJ           0.0
    z_5_0_3_1         DAY_5_0_3       1.0
    z_5_0_3_1         REQ_5_0         1.0
    z_5_0_3_1         OCC_0_3_1       -1.0
    z_5_0_3_1         CLS_5_3_1       -1.0
    z_5_0_3_2         OBJ           0.0
    z_5_0_3_2         DAY_5_0_3       1.0
    z_5_0_3_2         REQ_5_0         1.0
    z_5_0_3_2         OCC_0_3_2       -1.0
    z_5_0_3_2         CLS_5_3_2       -1.0
    z_5_0_3_3         OBJ           0.0
    z_5_0_3_3         DAY_5_0_3       1.0
    z_5_0_3_3         REQ_5_0         1.0
    z_5_0_3_3         OCC_0_3_3       -1.0
    z_5_0_3_3         CLS_5_3_3       -1.0
    z_5_0_3_4         OBJ           0.0
    z_5_0_3_4         DAY_5_0_3       1.0
    z_5_0_3_4         REQ_5_0         1.0
    z_5_0_3_4         OCC_0_3_5       -1.0
    z_5_0_3_4         CLS_5_3_5       -1.0
    z_5_0_3_5         OBJ           0.0
    z_5_0_3_5         DAY_5_0_3       1.0
    z_5_0_3_5         REQ_5_0         2.0
    z_5_0_3_5         OCC_0_3_0       -1.0
    z_5_0_3_5         OCC_0_3_1       -1.0
    z_5_0_3_5         CLS_5_3_0       -1.0
    z_5_0_3_5         CLS_5_3_1       -1.0
    z_5_0_3_6         OBJ           0.0
    z_5_0_3_6         DAY_5_0_3       1.0
    z_5_0_3_6         REQ_5_0         2.0
    z_5_0_3_6         OCC_0_3_1       -1.0
    z_5_0_3_6         OCC_0_3_2       -1.0
    z_5_0_3_6         CLS_5_3_1       -1.0
    z_5_0_3_6         CLS_5_3_2       -1.0
    z_5_0_3_7         OBJ           0.0
    z_5_0_3_7         DAY_5_0_3       1.0
    z_5_0_3_7         REQ_5_0         2.0
    z_5_0_3_7         OCC_0_3_2       -1.0
    z_5_0_3_7         OCC_0_3_3       -1.0
    z_5_0_3_7         CLS_5_3_2       -1.0
    z_5_0_3_7         CLS_5_3_3       -1.0
    z_5_0_4_0         OBJ           0.0
    z_5_0_4_0         DAY_5_0_4       1.0
    z_5_0_4_0         REQ_5_0         1.0
    z_5_0_4_0         OCC_0_4_0       -1.0
    z_5_0_4_0         CLS_5_4_0       -1.0
    z_5_0_4_1         OBJ           0.0
    z_5_0_4_1         DAY_5_0_4       1.0
    z_5_0_4_1         REQ_5_0         1.0
    z_5_0_4_1         OCC_0_4_1       -1.0
    z_5_0_4_1         CLS_5_4_1       -1.0
    z_5_0_4_2         OBJ           0.0
    z_5_0_4_2         DAY_5_0_4       1.0
    z_5_0_4_2         REQ_5_0         1.0
    z_5_0_4_2         OCC_0_4_2       -1.0
    z_5_0_4_2         CLS_5_4_2       -1.0
    z_5_0_4_3         OBJ           0.0
    z_5_0_4_3         DAY_5_0_4       1.0
    z_5_0_4_3         REQ_5_0         1.0
    z_5_0_4_3         OCC_0_4_3       -1.0
    z_5_0_4_3         CLS_5_4_3       -1.0
    z_5_0_4_4         OBJ           0.0
    z_5_0_4_4         DAY_5_0_4       1.0
    z_5_0_4_4         REQ_5_0         1.0
    z_5_0_4_4         OCC_0_4_4       -1.0
    z_5_0_4_4         CLS_5_4_4       -1.0
    z_5_0_4_5         OBJ           0.0
    z_5_0_4_5         DAY_5_0_4       1.0
    z_5_0_4_5         REQ_5_0         1.0
    z_5_0_4_5         OCC_0_4_5       -1.0
    z_5_0_4_5         CLS_5_4_5       -1.0
    z_5_0_4_6         OBJ           0.0
    z_5_0_4_6         DAY_5_0_4       1.0
    z_5_0_4_6         REQ_5_0         2.0
    z_5_0_4_6         OCC_0_4_0       -1.0
    z_5_0_4_6         OCC_0_4_1       -1.0
    z_5_0_4_6         CLS_5_4_0       -1.0
    z_5_0_4_6         CLS_5_4_1       -1.0
    z_5_0_4_7         OBJ           0.0
    z_5_0_4_7         DAY_5_0_4       1.0
    z_5_0_4_7         REQ_5_0         2.0
    z_5_0_4_7         OCC_0_4_1       -1.0
    z_5_0_4_7         OCC_0_4_2       -1.0
    z_5_0_4_7         CLS_5_4_1       -1.0
    z_5_0_4_7         CLS_5_4_2       -1.0
    z_5_0_4_8         OBJ           0.0
    z_5_0_4_8         DAY_5_0_4       1.0
    z_5_0_4_8         REQ_5_0         2.0
    z_5_0_4_8         OCC_0_4_2       -1.0
    z_5_0_4_8         OCC_0_4_3       -1.0
    z_5_0_4_8         CLS_5_4_2       -1.0
    z_5_0_4_8         CLS_5_4_3       -1.0
    z_5_0_4_9         OBJ           0.0
    z_5_0_4_9         DAY_5_0_4       1.0
    z_5_0_4_9         REQ_5_0         2.0
    z_5_0_4_9         OCC_0_4_3       -1.0
    z_5_0_4_9         OCC_0_4_4       -1.0
    z_5_0_4_9         CLS_5_4_3       -1.0
    z_5_0_4_9         CLS_5_4_4       -1.0
    z_5_0_4_10        OBJ           0.0
    z_5_0_4_10        DAY_5_0_4       1.0
    z_5_0_4_10        REQ_5_0         2.0
    z_5_0_4_10        OCC_0_4_4       -1.0
    z_5_0_4_10        OCC_0_4_5       -1.0
    z_5_0_4_10        CLS_5_4_4       -1.0
    z_5_0_4_10        CLS_5_4_5       -1.0
    z_5_1_0_0         OBJ           0.0
    z_5_1_0_0         DAY_5_1_0       1.0
    z_5_1_0_0         REQ_5_1         1.0
    z_5_1_0_0         OCC_1_0_0       -1.0
    z_5_1_0_0         CLS_5_0_0       -1.0
    z_5_1_0_1         OBJ           0.0
    z_5_1_0_1         DAY_5_1_0       1.0
    z_5_1_0_1         REQ_5_1         1.0
    z_5_1_0_1         OCC_1_0_1       -1.0
    z_5_1_0_1         CLS_5_0_1       -1.0
    z_5_1_0_2         OBJ           0.0
    z_5_1_0_2         DAY_5_1_0       1.0
    z_5_1_0_2         REQ_5_1         1.0
    z_5_1_0_2         OCC_1_0_2       -1.0
    z_5_1_0_2         CLS_5_0_2       -1.0
    z_5_1_0_3         OBJ           0.0
    z_5_1_0_3         DAY_5_1_0       1.0
    z_5_1_0_3         REQ_5_1         1.0
    z_5_1_0_3         OCC_1_0_3       -1.0
    z_5_1_0_3         CLS_5_0_3       -1.0
    z_5_1_0_4         OBJ           0.0
    z_5_1_0_4         DAY_5_1_0       1.0
    z_5_1_0_4         REQ_5_1         1.0
    z_5_1_0_4         OCC_1_0_4       -1.0
    z_5_1_0_4         CLS_5_0_4       -1.0
    z_5_1_0_5         OBJ           0.0
    z_5_1_0_5         DAY_5_1_0       1.0
    z_5_1_0_5         REQ_5_1         1.0
    z_5_1_0_5         OCC_1_0_5       -1.0
    z_5_1_0_5         CLS_5_0_5       -1.0
    z_5_1_0_6         OBJ           0.0
    z_5_1_0_6         DAY_5_1_0       1.0
    z_5_1_0_6         REQ_5_1         2.0
    z_5_1_0_6         OCC_1_0_0       -1.0
    z_5_1_0_6         OCC_1_0_1       -1.0
    z_5_1_0_6         CLS_5_0_0       -1.0
    z_5_1_0_6         CLS_5_0_1       -1.0
    z_5_1_0_7         OBJ           0.0
    z_5_1_0_7         DAY_5_1_0       1.0
    z_5_1_0_7         REQ_5_1         2.0
    z_5_1_0_7         OCC_1_0_1       -1.0
    z_5_1_0_7         OCC_1_0_2       -1.0
    z_5_1_0_7         CLS_5_0_1       -1.0
    z_5_1_0_7         CLS_5_0_2       -1.0
    z_5_1_0_8         OBJ           0.0
    z_5_1_0_8         DAY_5_1_0       1.0
    z_5_1_0_8         REQ_5_1         2.0
    z_5_1_0_8         OCC_1_0_2       -1.0
    z_5_1_0_8         OCC_1_0_3       -1.0
    z_5_1_0_8         CLS_5_0_2       -1.0
    z_5_1_0_8         CLS_5_0_3       -1.0
    z_5_1_0_9         OBJ           0.0
    z_5_1_0_9         DAY_5_1_0       1.0
    z_5_1_0_9         REQ_5_1         2.0
    z_5_1_0_9         OCC_1_0_3       -1.0
    z_5_1_0_9         OCC_1_0_4       -1.0
    z_5_1_0_9         CLS_5_0_3       -1.0
    z_5_1_0_9         CLS_5_0_4       -1.0
    z_5_1_0_10        OBJ           0.0
    z_5_1_0_10        DAY_5_1_0       1.0
    z_5_1_0_10        REQ_5_1         2.0
    z_5_1_0_10        OCC_1_0_4       -1.0
    z_5_1_0_10        OCC_1_0_5       -1.0
    z_5_1_0_10        CLS_5_0_4       -1.0
    z_5_1_0_10        CLS_5_0_5       -1.0
    z_5_1_1_0         OBJ           0.0
    z_5_1_1_0         DAY_5_1_1       1.0
    z_5_1_1_0         REQ_5_1         1.0
    z_5_1_1_0         OCC_1_1_0       -1.0
    z_5_1_1_0         CLS_5_1_0       -1.0
    z_5_1_1_1         OBJ           0.0
    z_5_1_1_1         DAY_5_1_1       1.0
    z_5_1_1_1         REQ_5_1         1.0
    z_5_1_1_1         OCC_1_1_1       -1.0
    z_5_1_1_1         CLS_5_1_1       -1.0
    z_5_1_1_2         OBJ           0.0
    z_5_1_1_2         DAY_5_1_1       1.0
    z_5_1_1_2         REQ_5_1         1.0
    z_5_1_1_2         OCC_1_1_2       -1.0
    z_5_1_1_2         CLS_5_1_2       -1.0
    z_5_1_1_3         OBJ           0.0
    z_5_1_1_3         DAY_5_1_1       1.0
    z_5_1_1_3         REQ_5_1         1.0
    z_5_1_1_3         OCC_1_1_3       -1.0
    z_5_1_1_3         CLS_5_1_3       -1.0
    z_5_1_1_4         OBJ           0.0
    z_5_1_1_4         DAY_5_1_1       1.0
    z_5_1_1_4         REQ_5_1         1.0
    z_5_1_1_4         OCC_1_1_4       -1.0
    z_5_1_1_4         CLS_5_1_4       -1.0
    z_5_1_1_5         OBJ           0.0
    z_5_1_1_5         DAY_5_1_1       1.0
    z_5_1_1_5         REQ_5_1         1.0
    z_5_1_1_5         OCC_1_1_5       -1.0
    z_5_1_1_5         CLS_5_1_5       -1.0
    z_5_1_1_6         OBJ           0.0
    z_5_1_1_6         DAY_5_1_1       1.0
    z_5_1_1_6         REQ_5_1         2.0
    z_5_1_1_6         OCC_1_1_0       -1.0
    z_5_1_1_6         OCC_1_1_1       -1.0
    z_5_1_1_6         CLS_5_1_0       -1.0
    z_5_1_1_6         CLS_5_1_1       -1.0
    z_5_1_1_7         OBJ           0.0
    z_5_1_1_7         DAY_5_1_1       1.0
    z_5_1_1_7         REQ_5_1         2.0
    z_5_1_1_7         OCC_1_1_1       -1.0
    z_5_1_1_7         OCC_1_1_2       -1.0
    z_5_1_1_7         CLS_5_1_1       -1.0
    z_5_1_1_7         CLS_5_1_2       -1.0
    z_5_1_1_8         OBJ           0.0
    z_5_1_1_8         DAY_5_1_1       1.0
    z_5_1_1_8         REQ_5_1         2.0
    z_5_1_1_8         OCC_1_1_2       -1.0
    z_5_1_1_8         OCC_1_1_3       -1.0
    z_5_1_1_8         CLS_5_1_2       -1.0
    z_5_1_1_8         CLS_5_1_3       -1.0
    z_5_1_1_9         OBJ           0.0
    z_5_1_1_9         DAY_5_1_1       1.0
    z_5_1_1_9         REQ_5_1         2.0
    z_5_1_1_9         OCC_1_1_3       -1.0
    z_5_1_1_9         OCC_1_1_4       -1.0
    z_5_1_1_9         CLS_5_1_3       -1.0
    z_5_1_1_9         CLS_5_1_4       -1.0
    z_5_1_1_10        OBJ           0.0
    z_5_1_1_10        DAY_5_1_1       1.0
    z_5_1_1_10        REQ_5_1         2.0
    z_5_1_1_10        OCC_1_1_4       -1.0
    z_5_1_1_10        OCC_1_1_5       -1.0
    z_5_1_1_10        CLS_5_1_4       -1.0
    z_5_1_1_10        CLS_5_1_5       -1.0
    z_5_1_2_0         OBJ           0.0
    z_5_1_2_0         DAY_5_1_2       1.0
    z_5_1_2_0         REQ_5_1         1.0
    z_5_1_2_0         OCC_1_2_0       -1.0
    z_5_1_2_0         CLS_5_2_0       -1.0
    z_5_1_2_1         OBJ           0.0
    z_5_1_2_1         DAY_5_1_2       1.0
    z_5_1_2_1         REQ_5_1         1.0
    z_5_1_2_1         OCC_1_2_1       -1.0
    z_5_1_2_1         CLS_5_2_1       -1.0
    z_5_1_2_2         OBJ           0.0
    z_5_1_2_2         DAY_5_1_2       1.0
    z_5_1_2_2         REQ_5_1         1.0
    z_5_1_2_2         OCC_1_2_2       -1.0
    z_5_1_2_2         CLS_5_2_2       -1.0
    z_5_1_2_3         OBJ           0.0
    z_5_1_2_3         DAY_5_1_2       1.0
    z_5_1_2_3         REQ_5_1         1.0
    z_5_1_2_3         OCC_1_2_3       -1.0
    z_5_1_2_3         CLS_5_2_3       -1.0
    z_5_1_2_4         OBJ           0.0
    z_5_1_2_4         DAY_5_1_2       1.0
    z_5_1_2_4         REQ_5_1         1.0
    z_5_1_2_4         OCC_1_2_4       -1.0
    z_5_1_2_4         CLS_5_2_4       -1.0
    z_5_1_2_5         OBJ           0.0
    z_5_1_2_5         DAY_5_1_2       1.0
    z_5_1_2_5         REQ_5_1         1.0
    z_5_1_2_5         OCC_1_2_5       -1.0
    z_5_1_2_5         CLS_5_2_5       -1.0
    z_5_1_2_6         OBJ           0.0
    z_5_1_2_6         DAY_5_1_2       1.0
    z_5_1_2_6         REQ_5_1         2.0
    z_5_1_2_6         OCC_1_2_0       -1.0
    z_5_1_2_6         OCC_1_2_1       -1.0
    z_5_1_2_6         CLS_5_2_0       -1.0
    z_5_1_2_6         CLS_5_2_1       -1.0
    z_5_1_2_7         OBJ           0.0
    z_5_1_2_7         DAY_5_1_2       1.0
    z_5_1_2_7         REQ_5_1         2.0
    z_5_1_2_7         OCC_1_2_1       -1.0
    z_5_1_2_7         OCC_1_2_2       -1.0
    z_5_1_2_7         CLS_5_2_1       -1.0
    z_5_1_2_7         CLS_5_2_2       -1.0
    z_5_1_2_8         OBJ           0.0
    z_5_1_2_8         DAY_5_1_2       1.0
    z_5_1_2_8         REQ_5_1         2.0
    z_5_1_2_8         OCC_1_2_2       -1.0
    z_5_1_2_8         OCC_1_2_3       -1.0
    z_5_1_2_8         CLS_5_2_2       -1.0
    z_5_1_2_8         CLS_5_2_3       -1.0
    z_5_1_2_9         OBJ           0.0
    z_5_1_2_9         DAY_5_1_2       1.0
    z_5_1_2_9         REQ_5_1         2.0
    z_5_1_2_9         OCC_1_2_3       -1.0
    z_5_1_2_9         OCC_1_2_4       -1.0
    z_5_1_2_9         CLS_5_2_3       -1.0
    z_5_1_2_9         CLS_5_2_4       -1.0
    z_5_1_2_10        OBJ           0.0
    z_5_1_2_10        DAY_5_1_2       1.0
    z_5_1_2_10        REQ_5_1         2.0
    z_5_1_2_10        OCC_1_2_4       -1.0
    z_5_1_2_10        OCC_1_2_5       -1.0
    z_5_1_2_10        CLS_5_2_4       -1.0
    z_5_1_2_10        CLS_5_2_5       -1.0
    z_5_1_3_0         OBJ           0.0
    z_5_1_3_0         DAY_5_1_3       1.0
    z_5_1_3_0         REQ_5_1         1.0
    z_5_1_3_0         OCC_1_3_1       -1.0
    z_5_1_3_0         CLS_5_3_1       -1.0
    z_5_1_3_1         OBJ           0.0
    z_5_1_3_1         DAY_5_1_3       1.0
    z_5_1_3_1         REQ_5_1         1.0
    z_5_1_3_1         OCC_1_3_3       -1.0
    z_5_1_3_1         CLS_5_3_3       -1.0
    z_5_1_3_2         OBJ           0.0
    z_5_1_3_2         DAY_5_1_3       1.0
    z_5_1_3_2         REQ_5_1         1.0
    z_5_1_3_2         OCC_1_3_4       -1.0
    z_5_1_3_2         CLS_5_3_4       -1.0
    z_5_1_3_3         OBJ           0.0
    z_5_1_3_3         DAY_5_1_3       1.0
    z_5_1_3_3         REQ_5_1         1.0
    z_5_1_3_3         OCC_1_3_5       -1.0
    z_5_1_3_3         CLS_5_3_5       -1.0
    z_5_1_3_4         OBJ           0.0
    z_5_1_3_4         DAY_5_1_3       1.0
    z_5_1_3_4         REQ_5_1         2.0
    z_5_1_3_4         OCC_1_3_3       -1.0
    z_5_1_3_4         OCC_1_3_4       -1.0
    z_5_1_3_4         CLS_5_3_3       -1.0
    z_5_1_3_4         CLS_5_3_4       -1.0
    z_5_1_3_5         OBJ           0.0
    z_5_1_3_5         DAY_5_1_3       1.0
    z_5_1_3_5         REQ_5_1         2.0
    z_5_1_3_5         OCC_1_3_4       -1.0
    z_5_1_3_5         OCC_1_3_5       -1.0
    z_5_1_3_5         CLS_5_3_4       -1.0
    z_5_1_3_5         CLS_5_3_5       -1.0
    z_5_1_4_0         OBJ           0.0
    z_5_1_4_0         DAY_5_1_4       1.0
    z_5_1_4_0         REQ_5_1         1.0
    z_5_1_4_0         OCC_1_4_0       -1.0
    z_5_1_4_0         CLS_5_4_0       -1.0
    z_5_1_4_1         OBJ           0.0
    z_5_1_4_1         DAY_5_1_4       1.0
    z_5_1_4_1         REQ_5_1         1.0
    z_5_1_4_1         OCC_1_4_1       -1.0
    z_5_1_4_1         CLS_5_4_1       -1.0
    z_5_1_4_2         OBJ           0.0
    z_5_1_4_2         DAY_5_1_4       1.0
    z_5_1_4_2         REQ_5_1         1.0
    z_5_1_4_2         OCC_1_4_2       -1.0
    z_5_1_4_2         CLS_5_4_2       -1.0
    z_5_1_4_3         OBJ           0.0
    z_5_1_4_3         DAY_5_1_4       1.0
    z_5_1_4_3         REQ_5_1         1.0
    z_5_1_4_3         OCC_1_4_3       -1.0
    z_5_1_4_3         CLS_5_4_3       -1.0
    z_5_1_4_4         OBJ           0.0
    z_5_1_4_4         DAY_5_1_4       1.0
    z_5_1_4_4         REQ_5_1         1.0
    z_5_1_4_4         OCC_1_4_4       -1.0
    z_5_1_4_4         CLS_5_4_4       -1.0
    z_5_1_4_5         OBJ           0.0
    z_5_1_4_5         DAY_5_1_4       1.0
    z_5_1_4_5         REQ_5_1         1.0
    z_5_1_4_5         OCC_1_4_5       -1.0
    z_5_1_4_5         CLS_5_4_5       -1.0
    z_5_1_4_6         OBJ           0.0
    z_5_1_4_6         DAY_5_1_4       1.0
    z_5_1_4_6         REQ_5_1         2.0
    z_5_1_4_6         OCC_1_4_0       -1.0
    z_5_1_4_6         OCC_1_4_1       -1.0
    z_5_1_4_6         CLS_5_4_0       -1.0
    z_5_1_4_6         CLS_5_4_1       -1.0
    z_5_1_4_7         OBJ           0.0
    z_5_1_4_7         DAY_5_1_4       1.0
    z_5_1_4_7         REQ_5_1         2.0
    z_5_1_4_7         OCC_1_4_1       -1.0
    z_5_1_4_7         OCC_1_4_2       -1.0
    z_5_1_4_7         CLS_5_4_1       -1.0
    z_5_1_4_7         CLS_5_4_2       -1.0
    z_5_1_4_8         OBJ           0.0
    z_5_1_4_8         DAY_5_1_4       1.0
    z_5_1_4_8         REQ_5_1         2.0
    z_5_1_4_8         OCC_1_4_2       -1.0
    z_5_1_4_8         OCC_1_4_3       -1.0
    z_5_1_4_8         CLS_5_4_2       -1.0
    z_5_1_4_8         CLS_5_4_3       -1.0
    z_5_1_4_9         OBJ           0.0
    z_5_1_4_9         DAY_5_1_4       1.0
    z_5_1_4_9         REQ_5_1         2.0
    z_5_1_4_9         OCC_1_4_3       -1.0
    z_5_1_4_9         OCC_1_4_4       -1.0
    z_5_1_4_9         CLS_5_4_3       -1.0
    z_5_1_4_9         CLS_5_4_4       -1.0
    z_5_1_4_10        OBJ           0.0
    z_5_1_4_10        DAY_5_1_4       1.0
    z_5_1_4_10        REQ_5_1         2.0
    z_5_1_4_10        OCC_1_4_4       -1.0
    z_5_1_4_10        OCC_1_4_5       -1.0
    z_5_1_4_10        CLS_5_4_4       -1.0
    z_5_1_4_10        CLS_5_4_5       -1.0
    z_5_2_0_0         OBJ           0.0
    z_5_2_0_0         DAY_5_2_0       1.0
    z_5_2_0_0         REQ_5_2         1.0
    z_5_2_0_0         OCC_2_0_0       -1.0
    z_5_2_0_0         CLS_5_0_0       -1.0
    z_5_2_0_1         OBJ           0.0
    z_5_2_0_1         DAY_5_2_0       1.0
    z_5_2_0_1         REQ_5_2         1.0
    z_5_2_0_1         OCC_2_0_1       -1.0
    z_5_2_0_1         CLS_5_0_1       -1.0
    z_5_2_0_2         OBJ           0.0
    z_5_2_0_2         DAY_5_2_0       1.0
    z_5_2_0_2         REQ_5_2         1.0
    z_5_2_0_2         OCC_2_0_2       -1.0
    z_5_2_0_2         CLS_5_0_2       -1.0
    z_5_2_0_3         OBJ           0.0
    z_5_2_0_3         DAY_5_2_0       1.0
    z_5_2_0_3         REQ_5_2         1.0
    z_5_2_0_3         OCC_2_0_3       -1.0
    z_5_2_0_3         CLS_5_0_3       -1.0
    z_5_2_0_4         OBJ           0.0
    z_5_2_0_4         DAY_5_2_0       1.0
    z_5_2_0_4         REQ_5_2         1.0
    z_5_2_0_4         OCC_2_0_4       -1.0
    z_5_2_0_4         CLS_5_0_4       -1.0
    z_5_2_0_5         OBJ           0.0
    z_5_2_0_5         DAY_5_2_0       1.0
    z_5_2_0_5         REQ_5_2         2.0
    z_5_2_0_5         OCC_2_0_0       -1.0
    z_5_2_0_5         OCC_2_0_1       -1.0
    z_5_2_0_5         CLS_5_0_0       -1.0
    z_5_2_0_5         CLS_5_0_1       -1.0
    z_5_2_0_6         OBJ           0.0
    z_5_2_0_6         DAY_5_2_0       1.0
    z_5_2_0_6         REQ_5_2         2.0
    z_5_2_0_6         OCC_2_0_1       -1.0
    z_5_2_0_6         OCC_2_0_2       -1.0
    z_5_2_0_6         CLS_5_0_1       -1.0
    z_5_2_0_6         CLS_5_0_2       -1.0
    z_5_2_0_7         OBJ           0.0
    z_5_2_0_7         DAY_5_2_0       1.0
    z_5_2_0_7         REQ_5_2         2.0
    z_5_2_0_7         OCC_2_0_2       -1.0
    z_5_2_0_7         OCC_2_0_3       -1.0
    z_5_2_0_7         CLS_5_0_2       -1.0
    z_5_2_0_7         CLS_5_0_3       -1.0
    z_5_2_0_8         OBJ           0.0
    z_5_2_0_8         DAY_5_2_0       1.0
    z_5_2_0_8         REQ_5_2         2.0
    z_5_2_0_8         OCC_2_0_3       -1.0
    z_5_2_0_8         OCC_2_0_4       -1.0
    z_5_2_0_8         CLS_5_0_3       -1.0
    z_5_2_0_8         CLS_5_0_4       -1.0
    z_5_2_1_0         OBJ           0.0
    z_5_2_1_0         DAY_5_2_1       1.0
    z_5_2_1_0         REQ_5_2         1.0
    z_5_2_1_0         OCC_2_1_0       -1.0
    z_5_2_1_0         CLS_5_1_0       -1.0
    z_5_2_1_1         OBJ           0.0
    z_5_2_1_1         DAY_5_2_1       1.0
    z_5_2_1_1         REQ_5_2         1.0
    z_5_2_1_1         OCC_2_1_1       -1.0
    z_5_2_1_1         CLS_5_1_1       -1.0
    z_5_2_1_2         OBJ           0.0
    z_5_2_1_2         DAY_5_2_1       1.0
    z_5_2_1_2         REQ_5_2         1.0
    z_5_2_1_2         OCC_2_1_2       -1.0
    z_5_2_1_2         CLS_5_1_2       -1.0
    z_5_2_1_3         OBJ           0.0
    z_5_2_1_3         DAY_5_2_1       1.0
    z_5_2_1_3         REQ_5_2         1.0
    z_5_2_1_3         OCC_2_1_3       -1.0
    z_5_2_1_3         CLS_5_1_3       -1.0
    z_5_2_1_4         OBJ           0.0
    z_5_2_1_4         DAY_5_2_1       1.0
    z_5_2_1_4         REQ_5_2         1.0
    z_5_2_1_4         OCC_2_1_4       -1.0
    z_5_2_1_4         CLS_5_1_4       -1.0
    z_5_2_1_5         OBJ           0.0
    z_5_2_1_5         DAY_5_2_1       1.0
    z_5_2_1_5         REQ_5_2         1.0
    z_5_2_1_5         OCC_2_1_5       -1.0
    z_5_2_1_5         CLS_5_1_5       -1.0
    z_5_2_1_6         OBJ           0.0
    z_5_2_1_6         DAY_5_2_1       1.0
    z_5_2_1_6         REQ_5_2         2.0
    z_5_2_1_6         OCC_2_1_0       -1.0
    z_5_2_1_6         OCC_2_1_1       -1.0
    z_5_2_1_6         CLS_5_1_0       -1.0
    z_5_2_1_6         CLS_5_1_1       -1.0
    z_5_2_1_7         OBJ           0.0
    z_5_2_1_7         DAY_5_2_1       1.0
    z_5_2_1_7         REQ_5_2         2.0
    z_5_2_1_7         OCC_2_1_1       -1.0
    z_5_2_1_7         OCC_2_1_2       -1.0
    z_5_2_1_7         CLS_5_1_1       -1.0
    z_5_2_1_7         CLS_5_1_2       -1.0
    z_5_2_1_8         OBJ           0.0
    z_5_2_1_8         DAY_5_2_1       1.0
    z_5_2_1_8         REQ_5_2         2.0
    z_5_2_1_8         OCC_2_1_2       -1.0
    z_5_2_1_8         OCC_2_1_3       -1.0
    z_5_2_1_8         CLS_5_1_2       -1.0
    z_5_2_1_8         CLS_5_1_3       -1.0
    z_5_2_1_9         OBJ           0.0
    z_5_2_1_9         DAY_5_2_1       1.0
    z_5_2_1_9         REQ_5_2         2.0
    z_5_2_1_9         OCC_2_1_3       -1.0
    z_5_2_1_9         OCC_2_1_4       -1.0
    z_5_2_1_9         CLS_5_1_3       -1.0
    z_5_2_1_9         CLS_5_1_4       -1.0
    z_5_2_1_10        OBJ           0.0
    z_5_2_1_10        DAY_5_2_1       1.0
    z_5_2_1_10        REQ_5_2         2.0
    z_5_2_1_10        OCC_2_1_4       -1.0
    z_5_2_1_10        OCC_2_1_5       -1.0
    z_5_2_1_10        CLS_5_1_4       -1.0
    z_5_2_1_10        CLS_5_1_5       -1.0
    z_5_2_2_0         OBJ           0.0
    z_5_2_2_0         DAY_5_2_2       1.0
    z_5_2_2_0         REQ_5_2         1.0
    z_5_2_2_0         OCC_2_2_0       -1.0
    z_5_2_2_0         CLS_5_2_0       -1.0
    z_5_2_2_1         OBJ           0.0
    z_5_2_2_1         DAY_5_2_2       1.0
    z_5_2_2_1         REQ_5_2         1.0
    z_5_2_2_1         OCC_2_2_1       -1.0
    z_5_2_2_1         CLS_5_2_1       -1.0
    z_5_2_2_2         OBJ           0.0
    z_5_2_2_2         DAY_5_2_2       1.0
    z_5_2_2_2         REQ_5_2         1.0
    z_5_2_2_2         OCC_2_2_2       -1.0
    z_5_2_2_2         CLS_5_2_2       -1.0
    z_5_2_2_3         OBJ           0.0
    z_5_2_2_3         DAY_5_2_2       1.0
    z_5_2_2_3         REQ_5_2         1.0
    z_5_2_2_3         OCC_2_2_3       -1.0
    z_5_2_2_3         CLS_5_2_3       -1.0
    z_5_2_2_4         OBJ           0.0
    z_5_2_2_4         DAY_5_2_2       1.0
    z_5_2_2_4         REQ_5_2         1.0
    z_5_2_2_4         OCC_2_2_4       -1.0
    z_5_2_2_4         CLS_5_2_4       -1.0
    z_5_2_2_5         OBJ           0.0
    z_5_2_2_5         DAY_5_2_2       1.0
    z_5_2_2_5         REQ_5_2         2.0
    z_5_2_2_5         OCC_2_2_0       -1.0
    z_5_2_2_5         OCC_2_2_1       -1.0
    z_5_2_2_5         CLS_5_2_0       -1.0
    z_5_2_2_5         CLS_5_2_1       -1.0
    z_5_2_2_6         OBJ           0.0
    z_5_2_2_6         DAY_5_2_2       1.0
    z_5_2_2_6         REQ_5_2         2.0
    z_5_2_2_6         OCC_2_2_1       -1.0
    z_5_2_2_6         OCC_2_2_2       -1.0
    z_5_2_2_6         CLS_5_2_1       -1.0
    z_5_2_2_6         CLS_5_2_2       -1.0
    z_5_2_2_7         OBJ           0.0
    z_5_2_2_7         DAY_5_2_2       1.0
    z_5_2_2_7         REQ_5_2         2.0
    z_5_2_2_7         OCC_2_2_2       -1.0
    z_5_2_2_7         OCC_2_2_3       -1.0
    z_5_2_2_7         CLS_5_2_2       -1.0
    z_5_2_2_7         CLS_5_2_3       -1.0
    z_5_2_2_8         OBJ           0.0
    z_5_2_2_8         DAY_5_2_2       1.0
    z_5_2_2_8         REQ_5_2         2.0
    z_5_2_2_8         OCC_2_2_3       -1.0
    z_5_2_2_8         OCC_2_2_4       -1.0
    z_5_2_2_8         CLS_5_2_3       -1.0
    z_5_2_2_8         CLS_5_2_4       -1.0
    z_5_2_3_0         OBJ           0.0
    z_5_2_3_0         DAY_5_2_3       1.0
    z_5_2_3_0         REQ_5_2         1.0
    z_5_2_3_0         OCC_2_3_0       -1.0
    z_5_2_3_0         CLS_5_3_0       -1.0
    z_5_2_3_1         OBJ           0.0
    z_5_2_3_1         DAY_5_2_3       1.0
    z_5_2_3_1         REQ_5_2         1.0
    z_5_2_3_1         OCC_2_3_1       -1.0
    z_5_2_3_1         CLS_5_3_1       -1.0
    z_5_2_3_2         OBJ           0.0
    z_5_2_3_2         DAY_5_2_3       1.0
    z_5_2_3_2         REQ_5_2         1.0
    z_5_2_3_2         OCC_2_3_2       -1.0
    z_5_2_3_2         CLS_5_3_2       -1.0
    z_5_2_3_3         OBJ           0.0
    z_5_2_3_3         DAY_5_2_3       1.0
    z_5_2_3_3         REQ_5_2         1.0
    z_5_2_3_3         OCC_2_3_3       -1.0
    z_5_2_3_3         CLS_5_3_3       -1.0
    z_5_2_3_4         OBJ           0.0
    z_5_2_3_4         DAY_5_2_3       1.0
    z_5_2_3_4         REQ_5_2         1.0
    z_5_2_3_4         OCC_2_3_4       -1.0
    z_5_2_3_4         CLS_5_3_4       -1.0
    z_5_2_3_5         OBJ           0.0
    z_5_2_3_5         DAY_5_2_3       1.0
    z_5_2_3_5         REQ_5_2         1.0
    z_5_2_3_5         OCC_2_3_5       -1.0
    z_5_2_3_5         CLS_5_3_5       -1.0
    z_5_2_3_6         OBJ           0.0
    z_5_2_3_6         DAY_5_2_3       1.0
    z_5_2_3_6         REQ_5_2         2.0
    z_5_2_3_6         OCC_2_3_0       -1.0
    z_5_2_3_6         OCC_2_3_1       -1.0
    z_5_2_3_6         CLS_5_3_0       -1.0
    z_5_2_3_6         CLS_5_3_1       -1.0
    z_5_2_3_7         OBJ           0.0
    z_5_2_3_7         DAY_5_2_3       1.0
    z_5_2_3_7         REQ_5_2         2.0
    z_5_2_3_7         OCC_2_3_1       -1.0
    z_5_2_3_7         OCC_2_3_2       -1.0
    z_5_2_3_7         CLS_5_3_1       -1.0
    z_5_2_3_7         CLS_5_3_2       -1.0
    z_5_2_3_8         OBJ           0.0
    z_5_2_3_8         DAY_5_2_3       1.0
    z_5_2_3_8         REQ_5_2         2.0
    z_5_2_3_8         OCC_2_3_2       -1.0
    z_5_2_3_8         OCC_2_3_3       -1.0
    z_5_2_3_8         CLS_5_3_2       -1.0
    z_5_2_3_8         CLS_5_3_3       -1.0
    z_5_2_3_9         OBJ           0.0
    z_5_2_3_9         DAY_5_2_3       1.0
    z_5_2_3_9         REQ_5_2         2.0
    z_5_2_3_9         OCC_2_3_3       -1.0
    z_5_2_3_9         OCC_2_3_4       -1.0
    z_5_2_3_9         CLS_5_3_3       -1.0
    z_5_2_3_9         CLS_5_3_4       -1.0
    z_5_2_3_10        OBJ           0.0
    z_5_2_3_10        DAY_5_2_3       1.0
    z_5_2_3_10        REQ_5_2         2.0
    z_5_2_3_10        OCC_2_3_4       -1.0
    z_5_2_3_10        OCC_2_3_5       -1.0
    z_5_2_3_10        CLS_5_3_4       -1.0
    z_5_2_3_10        CLS_5_3_5       -1.0
    z_5_2_4_0         OBJ           0.0
    z_5_2_4_0         DAY_5_2_4       1.0
    z_5_2_4_0         REQ_5_2         1.0
    z_5_2_4_0         OCC_2_4_0       -1.0
    z_5_2_4_0         CLS_5_4_0       -1.0
    z_5_2_4_1         OBJ           0.0
    z_5_2_4_1         DAY_5_2_4       1.0
    z_5_2_4_1         REQ_5_2         1.0
    z_5_2_4_1         OCC_2_4_2       -1.0
    z_5_2_4_1         CLS_5_4_2       -1.0
    z_5_2_4_2         OBJ           0.0
    z_5_2_4_2         DAY_5_2_4       1.0
    z_5_2_4_2         REQ_5_2         1.0
    z_5_2_4_2         OCC_2_4_3       -1.0
    z_5_2_4_2         CLS_5_4_3       -1.0
    z_5_2_4_3         OBJ           0.0
    z_5_2_4_3         DAY_5_2_4       1.0
    z_5_2_4_3         REQ_5_2         1.0
    z_5_2_4_3         OCC_2_4_5       -1.0
    z_5_2_4_3         CLS_5_4_5       -1.0
    z_5_2_4_4         OBJ           0.0
    z_5_2_4_4         DAY_5_2_4       1.0
    z_5_2_4_4         REQ_5_2         2.0
    z_5_2_4_4         OCC_2_4_2       -1.0
    z_5_2_4_4         OCC_2_4_3       -1.0
    z_5_2_4_4         CLS_5_4_2       -1.0
    z_5_2_4_4         CLS_5_4_3       -1.0
    z_5_3_0_0         OBJ           0.0
    z_5_3_0_0         DAY_5_3_0       1.0
    z_5_3_0_0         REQ_5_3         1.0
    z_5_3_0_0         OCC_3_0_0       -1.0
    z_5_3_0_0         CLS_5_0_0       -1.0
    z_5_3_0_1         OBJ           0.0
    z_5_3_0_1         DAY_5_3_0       1.0
    z_5_3_0_1         REQ_5_3         1.0
    z_5_3_0_1         OCC_3_0_2       -1.0
    z_5_3_0_1         CLS_5_0_2       -1.0
    z_5_3_0_2         OBJ           0.0
    z_5_3_0_2         DAY_5_3_0       1.0
    z_5_3_0_2         REQ_5_3         1.0
    z_5_3_0_2         OCC_3_0_3       -1.0
    z_5_3_0_2         CLS_5_0_3       -1.0
    z_5_3_0_3         OBJ           0.0
    z_5_3_0_3         DAY_5_3_0       1.0
    z_5_3_0_3         REQ_5_3         1.0
    z_5_3_0_3         OCC_3_0_4       -1.0
    z_5_3_0_3         CLS_5_0_4       -1.0
    z_5_3_0_4         OBJ           0.0
    z_5_3_0_4         DAY_5_3_0       1.0
    z_5_3_0_4         REQ_5_3         1.0
    z_5_3_0_4         OCC_3_0_5       -1.0
    z_5_3_0_4         CLS_5_0_5       -1.0
    z_5_3_0_5         OBJ           0.0
    z_5_3_0_5         DAY_5_3_0       1.0
    z_5_3_0_5         REQ_5_3         2.0
    z_5_3_0_5         OCC_3_0_2       -1.0
    z_5_3_0_5         OCC_3_0_3       -1.0
    z_5_3_0_5         CLS_5_0_2       -1.0
    z_5_3_0_5         CLS_5_0_3       -1.0
    z_5_3_0_6         OBJ           0.0
    z_5_3_0_6         DAY_5_3_0       1.0
    z_5_3_0_6         REQ_5_3         2.0
    z_5_3_0_6         OCC_3_0_3       -1.0
    z_5_3_0_6         OCC_3_0_4       -1.0
    z_5_3_0_6         CLS_5_0_3       -1.0
    z_5_3_0_6         CLS_5_0_4       -1.0
    z_5_3_0_7         OBJ           0.0
    z_5_3_0_7         DAY_5_3_0       1.0
    z_5_3_0_7         REQ_5_3         2.0
    z_5_3_0_7         OCC_3_0_4       -1.0
    z_5_3_0_7         OCC_3_0_5       -1.0
    z_5_3_0_7         CLS_5_0_4       -1.0
    z_5_3_0_7         CLS_5_0_5       -1.0
    z_5_3_2_0         OBJ           0.0
    z_5_3_2_0         DAY_5_3_2       1.0
    z_5_3_2_0         REQ_5_3         1.0
    z_5_3_2_0         OCC_3_2_0       -1.0
    z_5_3_2_0         CLS_5_2_0       -1.0
    z_5_3_2_1         OBJ           0.0
    z_5_3_2_1         DAY_5_3_2       1.0
    z_5_3_2_1         REQ_5_3         1.0
    z_5_3_2_1         OCC_3_2_1       -1.0
    z_5_3_2_1         CLS_5_2_1       -1.0
    z_5_3_2_2         OBJ           0.0
    z_5_3_2_2         DAY_5_3_2       1.0
    z_5_3_2_2         REQ_5_3         1.0
    z_5_3_2_2         OCC_3_2_2       -1.0
    z_5_3_2_2         CLS_5_2_2       -1.0
    z_5_3_2_3         OBJ           0.0
    z_5_3_2_3         DAY_5_3_2       1.0
    z_5_3_2_3         REQ_5_3         1.0
    z_5_3_2_3         OCC_3_2_3       -1.0
    z_5_3_2_3         CLS_5_2_3       -1.0
    z_5_3_2_4         OBJ           0.0
    z_5_3_2_4         DAY_5_3_2       1.0
    z_5_3_2_4         REQ_5_3         1.0
    z_5_3_2_4         OCC_3_2_4       -1.0
    z_5_3_2_4         CLS_5_2_4       -1.0
    z_5_3_2_5         OBJ           0.0
    z_5_3_2_5         DAY_5_3_2       1.0
    z_5_3_2_5         REQ_5_3         1.0
    z_5_3_2_5         OCC_3_2_5       -1.0
    z_5_3_2_5         CLS_5_2_5       -1.0
    z_5_3_2_6         OBJ           0.0
    z_5_3_2_6         DAY_5_3_2       1.0
    z_5_3_2_6         REQ_5_3         2.0
    z_5_3_2_6         OCC_3_2_0       -1.0
    z_5_3_2_6         OCC_3_2_1       -1.0
    z_5_3_2_6         CLS_5_2_0       -1.0
    z_5_3_2_6         CLS_5_2_1       -1.0
    z_5_3_2_7         OBJ           0.0
    z_5_3_2_7         DAY_5_3_2       1.0
    z_5_3_2_7         REQ_5_3         2.0
    z_5_3_2_7         OCC_3_2_1       -1.0
    z_5_3_2_7         OCC_3_2_2       -1.0
    z_5_3_2_7         CLS_5_2_1       -1.0
    z_5_3_2_7         CLS_5_2_2       -1.0
    z_5_3_2_8         OBJ           0.0
    z_5_3_2_8         DAY_5_3_2       1.0
    z_5_3_2_8         REQ_5_3         2.0
    z_5_3_2_8         OCC_3_2_2       -1.0
    z_5_3_2_8         OCC_3_2_3       -1.0
    z_5_3_2_8         CLS_5_2_2       -1.0
    z_5_3_2_8         CLS_5_2_3       -1.0
    z_5_3_2_9         OBJ           0.0
    z_5_3_2_9         DAY_5_3_2       1.0
    z_5_3_2_9         REQ_5_3         2.0
    z_5_3_2_9         OCC_3_2_3       -1.0
    z_5_3_2_9         OCC_3_2_4       -1.0
    z_5_3_2_9         CLS_5_2_3       -1.0
    z_5_3_2_9         CLS_5_2_4       -1.0
    z_5_3_2_10        OBJ           0.0
    z_5_3_2_10        DAY_5_3_2       1.0
    z_5_3_2_10        REQ_5_3         2.0
    z_5_3_2_10        OCC_3_2_4       -1.0
    z_5_3_2_10        OCC_3_2_5       -1.0
    z_5_3_2_10        CLS_5_2_4       -1.0
    z_5_3_2_10        CLS_5_2_5       -1.0
    z_5_3_3_0         OBJ           0.0
    z_5_3_3_0         DAY_5_3_3       1.0
    z_5_3_3_0         REQ_5_3         1.0
    z_5_3_3_0         OCC_3_3_1       -1.0
    z_5_3_3_0         CLS_5_3_1       -1.0
    z_5_3_3_1         OBJ           0.0
    z_5_3_3_1         DAY_5_3_3       1.0
    z_5_3_3_1         REQ_5_3         1.0
    z_5_3_3_1         OCC_3_3_2       -1.0
    z_5_3_3_1         CLS_5_3_2       -1.0
    z_5_3_3_2         OBJ           0.0
    z_5_3_3_2         DAY_5_3_3       1.0
    z_5_3_3_2         REQ_5_3         1.0
    z_5_3_3_2         OCC_3_3_3       -1.0
    z_5_3_3_2         CLS_5_3_3       -1.0
    z_5_3_3_3         OBJ           0.0
    z_5_3_3_3         DAY_5_3_3       1.0
    z_5_3_3_3         REQ_5_3         1.0
    z_5_3_3_3         OCC_3_3_4       -1.0
    z_5_3_3_3         CLS_5_3_4       -1.0
    z_5_3_3_4         OBJ           0.0
    z_5_3_3_4         DAY_5_3_3       1.0
    z_5_3_3_4         REQ_5_3         1.0
    z_5_3_3_4         OCC_3_3_5       -1.0
    z_5_3_3_4         CLS_5_3_5       -1.0
    z_5_3_3_5         OBJ           0.0
    z_5_3_3_5         DAY_5_3_3       1.0
    z_5_3_3_5         REQ_5_3         2.0
    z_5_3_3_5         OCC_3_3_1       -1.0
    z_5_3_3_5         OCC_3_3_2       -1.0
    z_5_3_3_5         CLS_5_3_1       -1.0
    z_5_3_3_5         CLS_5_3_2       -1.0
    z_5_3_3_6         OBJ           0.0
    z_5_3_3_6         DAY_5_3_3       1.0
    z_5_3_3_6         REQ_5_3         2.0
    z_5_3_3_6         OCC_3_3_2       -1.0
    z_5_3_3_6         OCC_3_3_3       -1.0
    z_5_3_3_6         CLS_5_3_2       -1.0
    z_5_3_3_6         CLS_5_3_3       -1.0
    z_5_3_3_7         OBJ           0.0
    z_5_3_3_7         DAY_5_3_3       1.0
    z_5_3_3_7         REQ_5_3         2.0
    z_5_3_3_7         OCC_3_3_3       -1.0
    z_5_3_3_7         OCC_3_3_4       -1.0
    z_5_3_3_7         CLS_5_3_3       -1.0
    z_5_3_3_7         CLS_5_3_4       -1.0
    z_5_3_3_8         OBJ           0.0
    z_5_3_3_8         DAY_5_3_3       1.0
    z_5_3_3_8         REQ_5_3         2.0
    z_5_3_3_8         OCC_3_3_4       -1.0
    z_5_3_3_8         OCC_3_3_5       -1.0
    z_5_3_3_8         CLS_5_3_4       -1.0
    z_5_3_3_8         CLS_5_3_5       -1.0
    z_5_3_4_0         OBJ           0.0
    z_5_3_4_0         DAY_5_3_4       1.0
    z_5_3_4_0         REQ_5_3         1.0
    z_5_3_4_0         OCC_3_4_0       -1.0
    z_5_3_4_0         CLS_5_4_0       -1.0
    z_5_3_4_1         OBJ           0.0
    z_5_3_4_1         DAY_5_3_4       1.0
    z_5_3_4_1         REQ_5_3         1.0
    z_5_3_4_1         OCC_3_4_1       -1.0
    z_5_3_4_1         CLS_5_4_1       -1.0
    z_5_3_4_2         OBJ           0.0
    z_5_3_4_2         DAY_5_3_4       1.0
    z_5_3_4_2         REQ_5_3         1.0
    z_5_3_4_2         OCC_3_4_2       -1.0
    z_5_3_4_2         CLS_5_4_2       -1.0
    z_5_3_4_3         OBJ           0.0
    z_5_3_4_3         DAY_5_3_4       1.0
    z_5_3_4_3         REQ_5_3         1.0
    z_5_3_4_3         OCC_3_4_3       -1.0
    z_5_3_4_3         CLS_5_4_3       -1.0
    z_5_3_4_4         OBJ           0.0
    z_5_3_4_4         DAY_5_3_4       1.0
    z_5_3_4_4         REQ_5_3         1.0
    z_5_3_4_4         OCC_3_4_4       -1.0
    z_5_3_4_4         CLS_5_4_4       -1.0
    z_5_3_4_5         OBJ           0.0
    z_5_3_4_5         DAY_5_3_4       1.0
    z_5_3_4_5         REQ_5_3         1.0
    z_5_3_4_5         OCC_3_4_5       -1.0
    z_5_3_4_5         CLS_5_4_5       -1.0
    z_5_3_4_6         OBJ           0.0
    z_5_3_4_6         DAY_5_3_4       1.0
    z_5_3_4_6         REQ_5_3         2.0
    z_5_3_4_6         OCC_3_4_0       -1.0
    z_5_3_4_6         OCC_3_4_1       -1.0
    z_5_3_4_6         CLS_5_4_0       -1.0
    z_5_3_4_6         CLS_5_4_1       -1.0
    z_5_3_4_7         OBJ           0.0
    z_5_3_4_7         DAY_5_3_4       1.0
    z_5_3_4_7         REQ_5_3         2.0
    z_5_3_4_7         OCC_3_4_1       -1.0
    z_5_3_4_7         OCC_3_4_2       -1.0
    z_5_3_4_7         CLS_5_4_1       -1.0
    z_5_3_4_7         CLS_5_4_2       -1.0
    z_5_3_4_8         OBJ           0.0
    z_5_3_4_8         DAY_5_3_4       1.0
    z_5_3_4_8         REQ_5_3         2.0
    z_5_3_4_8         OCC_3_4_2       -1.0
    z_5_3_4_8         OCC_3_4_3       -1.0
    z_5_3_4_8         CLS_5_4_2       -1.0
    z_5_3_4_8         CLS_5_4_3       -1.0
    z_5_3_4_9         OBJ           0.0
    z_5_3_4_9         DAY_5_3_4       1.0
    z_5_3_4_9         REQ_5_3         2.0
    z_5_3_4_9         OCC_3_4_3       -1.0
    z_5_3_4_9         OCC_3_4_4       -1.0
    z_5_3_4_9         CLS_5_4_3       -1.0
    z_5_3_4_9         CLS_5_4_4       -1.0
    z_5_3_4_10        OBJ           0.0
    z_5_3_4_10        DAY_5_3_4       1.0
    z_5_3_4_10        REQ_5_3         2.0
    z_5_3_4_10        OCC_3_4_4       -1.0
    z_5_3_4_10        OCC_3_4_5       -1.0
    z_5_3_4_10        CLS_5_4_4       -1.0
    z_5_3_4_10        CLS_5_4_5       -1.0
    z_5_4_0_0         OBJ           0.0
    z_5_4_0_0         DAY_5_4_0       1.0
    z_5_4_0_0         REQ_5_4         1.0
    z_5_4_0_0         OCC_4_0_0       -1.0
    z_5_4_0_0         CLS_5_0_0       -1.0
    z_5_4_0_1         OBJ           0.0
    z_5_4_0_1         DAY_5_4_0       1.0
    z_5_4_0_1         REQ_5_4         1.0
    z_5_4_0_1         OCC_4_0_1       -1.0
    z_5_4_0_1         CLS_5_0_1       -1.0
    z_5_4_0_2         OBJ           0.0
    z_5_4_0_2         DAY_5_4_0       1.0
    z_5_4_0_2         REQ_5_4         1.0
    z_5_4_0_2         OCC_4_0_2       -1.0
    z_5_4_0_2         CLS_5_0_2       -1.0
    z_5_4_0_3         OBJ           0.0
    z_5_4_0_3         DAY_5_4_0       1.0
    z_5_4_0_3         REQ_5_4         1.0
    z_5_4_0_3         OCC_4_0_3       -1.0
    z_5_4_0_3         CLS_5_0_3       -1.0
    z_5_4_0_4         OBJ           0.0
    z_5_4_0_4         DAY_5_4_0       1.0
    z_5_4_0_4         REQ_5_4         1.0
    z_5_4_0_4         OCC_4_0_5       -1.0
    z_5_4_0_4         CLS_5_0_5       -1.0
    z_5_4_0_5         OBJ           0.0
    z_5_4_0_5         DAY_5_4_0       1.0
    z_5_4_0_5         REQ_5_4         2.0
    z_5_4_0_5         OCC_4_0_0       -1.0
    z_5_4_0_5         OCC_4_0_1       -1.0
    z_5_4_0_5         CLS_5_0_0       -1.0
    z_5_4_0_5         CLS_5_0_1       -1.0
    z_5_4_0_6         OBJ           0.0
    z_5_4_0_6         DAY_5_4_0       1.0
    z_5_4_0_6         REQ_5_4         2.0
    z_5_4_0_6         OCC_4_0_1       -1.0
    z_5_4_0_6         OCC_4_0_2       -1.0
    z_5_4_0_6         CLS_5_0_1       -1.0
    z_5_4_0_6         CLS_5_0_2       -1.0
    z_5_4_0_7         OBJ           0.0
    z_5_4_0_7         DAY_5_4_0       1.0
    z_5_4_0_7         REQ_5_4         2.0
    z_5_4_0_7         OCC_4_0_2       -1.0
    z_5_4_0_7         OCC_4_0_3       -1.0
    z_5_4_0_7         CLS_5_0_2       -1.0
    z_5_4_0_7         CLS_5_0_3       -1.0
    z_5_4_1_0         OBJ           0.0
    z_5_4_1_0         DAY_5_4_1       1.0
    z_5_4_1_0         REQ_5_4         1.0
    z_5_4_1_0         OCC_4_1_0       -1.0
    z_5_4_1_0         CLS_5_1_0       -1.0
    z_5_4_1_1         OBJ           0.0
    z_5_4_1_1         DAY_5_4_1       1.0
    z_5_4_1_1         REQ_5_4         1.0
    z_5_4_1_1         OCC_4_1_1       -1.0
    z_5_4_1_1         CLS_5_1_1       -1.0
    z_5_4_1_2         OBJ           0.0
    z_5_4_1_2         DAY_5_4_1       1.0
    z_5_4_1_2         REQ_5_4         1.0
    z_5_4_1_2         OCC_4_1_2       -1.0
    z_5_4_1_2         CLS_5_1_2       -1.0
    z_5_4_1_3         OBJ           0.0
    z_5_4_1_3         DAY_5_4_1       1.0
    z_5_4_1_3         REQ_5_4         1.0
    z_5_4_1_3         OCC_4_1_3       -1.0
    z_5_4_1_3         CLS_5_1_3       -1.0
    z_5_4_1_4         OBJ           0.0
    z_5_4_1_4         DAY_5_4_1       1.0
    z_5_4_1_4         REQ_5_4         1.0
    z_5_4_1_4         OCC_4_1_4       -1.0
    z_5_4_1_4         CLS_5_1_4       -1.0
    z_5_4_1_5         OBJ           0.0
    z_5_4_1_5         DAY_5_4_1       1.0
    z_5_4_1_5         REQ_5_4         1.0
    z_5_4_1_5         OCC_4_1_5       -1.0
    z_5_4_1_5         CLS_5_1_5       -1.0
    z_5_4_1_6         OBJ           0.0
    z_5_4_1_6         DAY_5_4_1       1.0
    z_5_4_1_6         REQ_5_4         2.0
    z_5_4_1_6         OCC_4_1_0       -1.0
    z_5_4_1_6         OCC_4_1_1       -1.0
    z_5_4_1_6         CLS_5_1_0       -1.0
    z_5_4_1_6         CLS_5_1_1       -1.0
    z_5_4_1_7         OBJ           0.0
    z_5_4_1_7         DAY_5_4_1       1.0
    z_5_4_1_7         REQ_5_4         2.0
    z_5_4_1_7         OCC_4_1_1       -1.0
    z_5_4_1_7         OCC_4_1_2       -1.0
    z_5_4_1_7         CLS_5_1_1       -1.0
    z_5_4_1_7         CLS_5_1_2       -1.0
    z_5_4_1_8         OBJ           0.0
    z_5_4_1_8         DAY_5_4_1       1.0
    z_5_4_1_8         REQ_5_4         2.0
    z_5_4_1_8         OCC_4_1_2       -1.0
    z_5_4_1_8         OCC_4_1_3       -1.0
    z_5_4_1_8         CLS_5_1_2       -1.0
    z_5_4_1_8         CLS_5_1_3       -1.0
    z_5_4_1_9         OBJ           0.0
    z_5_4_1_9         DAY_5_4_1       1.0
    z_5_4_1_9         REQ_5_4         2.0
    z_5_4_1_9         OCC_4_1_3       -1.0
    z_5_4_1_9         OCC_4_1_4       -1.0
    z_5_4_1_9         CLS_5_1_3       -1.0
    z_5_4_1_9         CLS_5_1_4       -1.0
    z_5_4_1_10        OBJ           0.0
    z_5_4_1_10        DAY_5_4_1       1.0
    z_5_4_1_10        REQ_5_4         2.0
    z_5_4_1_10        OCC_4_1_4       -1.0
    z_5_4_1_10        OCC_4_1_5       -1.0
    z_5_4_1_10        CLS_5_1_4       -1.0
    z_5_4_1_10        CLS_5_1_5       -1.0
    z_5_4_2_0         OBJ           0.0
    z_5_4_2_0         DAY_5_4_2       1.0
    z_5_4_2_0         REQ_5_4         1.0
    z_5_4_2_0         OCC_4_2_0       -1.0
    z_5_4_2_0         CLS_5_2_0       -1.0
    z_5_4_2_1         OBJ           0.0
    z_5_4_2_1         DAY_5_4_2       1.0
    z_5_4_2_1         REQ_5_4         1.0
    z_5_4_2_1         OCC_4_2_1       -1.0
    z_5_4_2_1         CLS_5_2_1       -1.0
    z_5_4_2_2         OBJ           0.0
    z_5_4_2_2         DAY_5_4_2       1.0
    z_5_4_2_2         REQ_5_4         1.0
    z_5_4_2_2         OCC_4_2_2       -1.0
    z_5_4_2_2         CLS_5_2_2       -1.0
    z_5_4_2_3         OBJ           0.0
    z_5_4_2_3         DAY_5_4_2       1.0
    z_5_4_2_3         REQ_5_4         1.0
    z_5_4_2_3         OCC_4_2_3       -1.0
    z_5_4_2_3         CLS_5_2_3       -1.0
    z_5_4_2_4         OBJ           0.0
    z_5_4_2_4         DAY_5_4_2       1.0
    z_5_4_2_4         REQ_5_4         1.0
    z_5_4_2_4         OCC_4_2_4       -1.0
    z_5_4_2_4         CLS_5_2_4       -1.0
    z_5_4_2_5         OBJ           0.0
    z_5_4_2_5         DAY_5_4_2       1.0
    z_5_4_2_5         REQ_5_4         1.0
    z_5_4_2_5         OCC_4_2_5       -1.0
    z_5_4_2_5         CLS_5_2_5       -1.0
    z_5_4_2_6         OBJ           0.0
    z_5_4_2_6         DAY_5_4_2       1.0
    z_5_4_2_6         REQ_5_4         2.0
    z_5_4_2_6         OCC_4_2_0       -1.0
    z_5_4_2_6         OCC_4_2_1       -1.0
    z_5_4_2_6         CLS_5_2_0       -1.0
    z_5_4_2_6         CLS_5_2_1       -1.0
    z_5_4_2_7         OBJ           0.0
    z_5_4_2_7         DAY_5_4_2       1.0
    z_5_4_2_7         REQ_5_4         2.0
    z_5_4_2_7         OCC_4_2_1       -1.0
    z_5_4_2_7         OCC_4_2_2       -1.0
    z_5_4_2_7         CLS_5_2_1       -1.0
    z_5_4_2_7         CLS_5_2_2       -1.0
    z_5_4_2_8         OBJ           0.0
    z_5_4_2_8         DAY_5_4_2       1.0
    z_5_4_2_8         REQ_5_4         2.0
    z_5_4_2_8         OCC_4_2_2       -1.0
    z_5_4_2_8         OCC_4_2_3       -1.0
    z_5_4_2_8         CLS_5_2_2       -1.0
    z_5_4_2_8         CLS_5_2_3       -1.0
    z_5_4_2_9         OBJ           0.0
    z_5_4_2_9         DAY_5_4_2       1.0
    z_5_4_2_9         REQ_5_4         2.0
    z_5_4_2_9         OCC_4_2_3       -1.0
    z_5_4_2_9         OCC_4_2_4       -1.0
    z_5_4_2_9         CLS_5_2_3       -1.0
    z_5_4_2_9         CLS_5_2_4       -1.0
    z_5_4_2_10        OBJ           0.0
    z_5_4_2_10        DAY_5_4_2       1.0
    z_5_4_2_10        REQ_5_4         2.0
    z_5_4_2_10        OCC_4_2_4       -1.0
    z_5_4_2_10        OCC_4_2_5       -1.0
    z_5_4_2_10        CLS_5_2_4       -1.0
    z_5_4_2_10        CLS_5_2_5       -1.0
    z_5_4_3_0         OBJ           0.0
    z_5_4_3_0         DAY_5_4_3       1.0
    z_5_4_3_0         REQ_5_4         1.0
    z_5_4_3_0         OCC_4_3_0       -1.0
    z_5_4_3_0         CLS_5_3_0       -1.0
    z_5_4_3_1         OBJ           0.0
    z_5_4_3_1         DAY_5_4_3       1.0
    z_5_4_3_1         REQ_5_4         1.0
    z_5_4_3_1         OCC_4_3_1       -1.0
    z_5_4_3_1         CLS_5_3_1       -1.0
    z_5_4_3_2         OBJ           0.0
    z_5_4_3_2         DAY_5_4_3       1.0
    z_5_4_3_2         REQ_5_4         1.0
    z_5_4_3_2         OCC_4_3_2       -1.0
    z_5_4_3_2         CLS_5_3_2       -1.0
    z_5_4_3_3         OBJ           0.0
    z_5_4_3_3         DAY_5_4_3       1.0
    z_5_4_3_3         REQ_5_4         1.0
    z_5_4_3_3         OCC_4_3_3       -1.0
    z_5_4_3_3         CLS_5_3_3       -1.0
    z_5_4_3_4         OBJ           0.0
    z_5_4_3_4         DAY_5_4_3       1.0
    z_5_4_3_4         REQ_5_4         1.0
    z_5_4_3_4         OCC_4_3_4       -1.0
    z_5_4_3_4         CLS_5_3_4       -1.0
    z_5_4_3_5         OBJ           0.0
    z_5_4_3_5         DAY_5_4_3       1.0
    z_5_4_3_5         REQ_5_4         1.0
    z_5_4_3_5         OCC_4_3_5       -1.0
    z_5_4_3_5         CLS_5_3_5       -1.0
    z_5_4_3_6         OBJ           0.0
    z_5_4_3_6         DAY_5_4_3       1.0
    z_5_4_3_6         REQ_5_4         2.0
    z_5_4_3_6         OCC_4_3_0       -1.0
    z_5_4_3_6         OCC_4_3_1       -1.0
    z_5_4_3_6         CLS_5_3_0       -1.0
    z_5_4_3_6         CLS_5_3_1       -1.0
    z_5_4_3_7         OBJ           0.0
    z_5_4_3_7         DAY_5_4_3       1.0
    z_5_4_3_7         REQ_5_4         2.0
    z_5_4_3_7         OCC_4_3_1       -1.0
    z_5_4_3_7         OCC_4_3_2       -1.0
    z_5_4_3_7         CLS_5_3_1       -1.0
    z_5_4_3_7         CLS_5_3_2       -1.0
    z_5_4_3_8         OBJ           0.0
    z_5_4_3_8         DAY_5_4_3       1.0
    z_5_4_3_8         REQ_5_4         2.0
    z_5_4_3_8         OCC_4_3_2       -1.0
    z_5_4_3_8         OCC_4_3_3       -1.0
    z_5_4_3_8         CLS_5_3_2       -1.0
    z_5_4_3_8         CLS_5_3_3       -1.0
    z_5_4_3_9         OBJ           0.0
    z_5_4_3_9         DAY_5_4_3       1.0
    z_5_4_3_9         REQ_5_4         2.0
    z_5_4_3_9         OCC_4_3_3       -1.0
    z_5_4_3_9         OCC_4_3_4       -1.0
    z_5_4_3_9         CLS_5_3_3       -1.0
    z_5_4_3_9         CLS_5_3_4       -1.0
    z_5_4_3_10        OBJ           0.0
    z_5_4_3_10        DAY_5_4_3       1.0
    z_5_4_3_10        REQ_5_4         2.0
    z_5_4_3_10        OCC_4_3_4       -1.0
    z_5_4_3_10        OCC_4_3_5       -1.0
    z_5_4_3_10        CLS_5_3_4       -1.0
    z_5_4_3_10        CLS_5_3_5       -1.0
    z_5_4_4_0         OBJ           0.0
    z_5_4_4_0         DAY_5_4_4       1.0
    z_5_4_4_0         REQ_5_4         1.0
    z_5_4_4_0         OCC_4_4_0       -1.0
    z_5_4_4_0         CLS_5_4_0       -1.0
    z_5_4_4_1         OBJ           0.0
    z_5_4_4_1         DAY_5_4_4       1.0
    z_5_4_4_1         REQ_5_4         1.0
    z_5_4_4_1         OCC_4_4_1       -1.0
    z_5_4_4_1         CLS_5_4_1       -1.0
    z_5_4_4_2         OBJ           0.0
    z_5_4_4_2         DAY_5_4_4       1.0
    z_5_4_4_2         REQ_5_4         1.0
    z_5_4_4_2         OCC_4_4_2       -1.0
    z_5_4_4_2         CLS_5_4_2       -1.0
    z_5_4_4_3         OBJ           0.0
    z_5_4_4_3         DAY_5_4_4       1.0
    z_5_4_4_3         REQ_5_4         1.0
    z_5_4_4_3         OCC_4_4_3       -1.0
    z_5_4_4_3         CLS_5_4_3       -1.0
    z_5_4_4_4         OBJ           0.0
    z_5_4_4_4         DAY_5_4_4       1.0
    z_5_4_4_4         REQ_5_4         1.0
    z_5_4_4_4         OCC_4_4_4       -1.0
    z_5_4_4_4         CLS_5_4_4       -1.0
    z_5_4_4_5         OBJ           0.0
    z_5_4_4_5         DAY_5_4_4       1.0
    z_5_4_4_5         REQ_5_4         1.0
    z_5_4_4_5         OCC_4_4_5       -1.0
    z_5_4_4_5         CLS_5_4_5       -1.0
    z_5_4_4_6         OBJ           0.0
    z_5_4_4_6         DAY_5_4_4       1.0
    z_5_4_4_6         REQ_5_4         2.0
    z_5_4_4_6         OCC_4_4_0       -1.0
    z_5_4_4_6         OCC_4_4_1       -1.0
    z_5_4_4_6         CLS_5_4_0       -1.0
    z_5_4_4_6         CLS_5_4_1       -1.0
    z_5_4_4_7         OBJ           0.0
    z_5_4_4_7         DAY_5_4_4       1.0
    z_5_4_4_7         REQ_5_4         2.0
    z_5_4_4_7         OCC_4_4_1       -1.0
    z_5_4_4_7         OCC_4_4_2       -1.0
    z_5_4_4_7         CLS_5_4_1       -1.0
    z_5_4_4_7         CLS_5_4_2       -1.0
    z_5_4_4_8         OBJ           0.0
    z_5_4_4_8         DAY_5_4_4       1.0
    z_5_4_4_8         REQ_5_4         2.0
    z_5_4_4_8         OCC_4_4_2       -1.0
    z_5_4_4_8         OCC_4_4_3       -1.0
    z_5_4_4_8         CLS_5_4_2       -1.0
    z_5_4_4_8         CLS_5_4_3       -1.0
    z_5_4_4_9         OBJ           0.0
    z_5_4_4_9         DAY_5_4_4       1.0
    z_5_4_4_9         REQ_5_4         2.0
    z_5_4_4_9         OCC_4_4_3       -1.0
    z_5_4_4_9         OCC_4_4_4       -1.0
    z_5_4_4_9         CLS_5_4_3       -1.0
    z_5_4_4_9         CLS_5_4_4       -1.0
    z_5_4_4_10        OBJ           0.0
    z_5_4_4_10        DAY_5_4_4       1.0
    z_5_4_4_10        REQ_5_4         2.0
    z_5_4_4_10        OCC_4_4_4       -1.0
    z_5_4_4_10        OCC_4_4_5       -1.0
    z_5_4_4_10        CLS_5_4_4       -1.0
    z_5_4_4_10        CLS_5_4_5       -1.0
    z_5_5_0_0         OBJ           0.0
    z_5_5_0_0         DAY_5_5_0       1.0
    z_5_5_0_0         REQ_5_5         1.0
    z_5_5_0_0         OCC_5_0_0       -1.0
    z_5_5_0_0         CLS_5_0_0       -1.0
    z_5_5_0_1         OBJ           0.0
    z_5_5_0_1         DAY_5_5_0       1.0
    z_5_5_0_1         REQ_5_5         1.0
    z_5_5_0_1         OCC_5_0_1       -1.0
    z_5_5_0_1         CLS_5_0_1       -1.0
    z_5_5_0_2         OBJ           0.0
    z_5_5_0_2         DAY_5_5_0       1.0
    z_5_5_0_2         REQ_5_5         1.0
    z_5_5_0_2         OCC_5_0_2       -1.0
    z_5_5_0_2         CLS_5_0_2       -1.0
    z_5_5_0_3         OBJ           0.0
    z_5_5_0_3         DAY_5_5_0       1.0
    z_5_5_0_3         REQ_5_5         1.0
    z_5_5_0_3         OCC_5_0_3       -1.0
    z_5_5_0_3         CLS_5_0_3       -1.0
    z_5_5_0_4         OBJ           0.0
    z_5_5_0_4         DAY_5_5_0       1.0
    z_5_5_0_4         REQ_5_5         1.0
    z_5_5_0_4         OCC_5_0_4       -1.0
    z_5_5_0_4         CLS_5_0_4       -1.0
    z_5_5_0_5         OBJ           0.0
    z_5_5_0_5         DAY_5_5_0       1.0
    z_5_5_0_5         REQ_5_5         1.0
    z_5_5_0_5         OCC_5_0_5       -1.0
    z_5_5_0_5         CLS_5_0_5       -1.0
    z_5_5_0_6         OBJ           0.0
    z_5_5_0_6         DAY_5_5_0       1.0
    z_5_5_0_6         REQ_5_5         2.0
    z_5_5_0_6         OCC_5_0_0       -1.0
    z_5_5_0_6         OCC_5_0_1       -1.0
    z_5_5_0_6         CLS_5_0_0       -1.0
    z_5_5_0_6         CLS_5_0_1       -1.0
    z_5_5_0_7         OBJ           0.0
    z_5_5_0_7         DAY_5_5_0       1.0
    z_5_5_0_7         REQ_5_5         2.0
    z_5_5_0_7         OCC_5_0_1       -1.0
    z_5_5_0_7         OCC_5_0_2       -1.0
    z_5_5_0_7         CLS_5_0_1       -1.0
    z_5_5_0_7         CLS_5_0_2       -1.0
    z_5_5_0_8         OBJ           0.0
    z_5_5_0_8         DAY_5_5_0       1.0
    z_5_5_0_8         REQ_5_5         2.0
    z_5_5_0_8         OCC_5_0_2       -1.0
    z_5_5_0_8         OCC_5_0_3       -1.0
    z_5_5_0_8         CLS_5_0_2       -1.0
    z_5_5_0_8         CLS_5_0_3       -1.0
    z_5_5_0_9         OBJ           0.0
    z_5_5_0_9         DAY_5_5_0       1.0
    z_5_5_0_9         REQ_5_5         2.0
    z_5_5_0_9         OCC_5_0_3       -1.0
    z_5_5_0_9         OCC_5_0_4       -1.0
    z_5_5_0_9         CLS_5_0_3       -1.0
    z_5_5_0_9         CLS_5_0_4       -1.0
    z_5_5_0_10        OBJ           0.0
    z_5_5_0_10        DAY_5_5_0       1.0
    z_5_5_0_10        REQ_5_5         2.0
    z_5_5_0_10        OCC_5_0_4       -1.0
    z_5_5_0_10        OCC_5_0_5       -1.0
    z_5_5_0_10        CLS_5_0_4       -1.0
    z_5_5_0_10        CLS_5_0_5       -1.0
    z_5_5_1_0         OBJ           0.0
    z_5_5_1_0         DAY_5_5_1       1.0
    z_5_5_1_0         REQ_5_5         1.0
    z_5_5_1_0         OCC_5_1_0       -1.0
    z_5_5_1_0         CLS_5_1_0       -1.0
    z_5_5_1_1         OBJ           0.0
    z_5_5_1_1         DAY_5_5_1       1.0
    z_5_5_1_1         REQ_5_5         1.0
    z_5_5_1_1         OCC_5_1_2       -1.0
    z_5_5_1_1         CLS_5_1_2       -1.0
    z_5_5_1_2         OBJ           0.0
    z_5_5_1_2         DAY_5_5_1       1.0
    z_5_5_1_2         REQ_5_5         1.0
    z_5_5_1_2         OCC_5_1_3       -1.0
    z_5_5_1_2         CLS_5_1_3       -1.0
    z_5_5_1_3         OBJ           0.0
    z_5_5_1_3         DAY_5_5_1       1.0
    z_5_5_1_3         REQ_5_5         1.0
    z_5_5_1_3         OCC_5_1_4       -1.0
    z_5_5_1_3         CLS_5_1_4       -1.0
    z_5_5_1_4         OBJ           0.0
    z_5_5_1_4         DAY_5_5_1       1.0
    z_5_5_1_4         REQ_5_5         1.0
    z_5_5_1_4         OCC_5_1_5       -1.0
    z_5_5_1_4         CLS_5_1_5       -1.0
    z_5_5_1_5         OBJ           0.0
    z_5_5_1_5         DAY_5_5_1       1.0
    z_5_5_1_5         REQ_5_5         2.0
    z_5_5_1_5         OCC_5_1_2       -1.0
    z_5_5_1_5         OCC_5_1_3       -1.0
    z_5_5_1_5         CLS_5_1_2       -1.0
    z_5_5_1_5         CLS_5_1_3       -1.0
    z_5_5_1_6         OBJ           0.0
    z_5_5_1_6         DAY_5_5_1       1.0
    z_5_5_1_6         REQ_5_5         2.0
    z_5_5_1_6         OCC_5_1_3       -1.0
    z_5_5_1_6         OCC_5_1_4       -1.0
    z_5_5_1_6         CLS_5_1_3       -1.0
    z_5_5_1_6         CLS_5_1_4       -1.0
    z_5_5_1_7         OBJ           0.0
    z_5_5_1_7         DAY_5_5_1       1.0
    z_5_5_1_7         REQ_5_5         2.0
    z_5_5_1_7         OCC_5_1_4       -1.0
    z_5_5_1_7         OCC_5_1_5       -1.0
    z_5_5_1_7         CLS_5_1_4       -1.0
    z_5_5_1_7         CLS_5_1_5       -1.0
    z_5_5_2_0         OBJ           0.0
    z_5_5_2_0         DAY_5_5_2       1.0
    z_5_5_2_0         REQ_5_5         1.0
    z_5_5_2_0         OCC_5_2_0       -1.0
    z_5_5_2_0         CLS_5_2_0       -1.0
    z_5_5_2_1         OBJ           0.0
    z_5_5_2_1         DAY_5_5_2       1.0
    z_5_5_2_1         REQ_5_5         1.0
    z_5_5_2_1         OCC_5_2_1       -1.0
    z_5_5_2_1         CLS_5_2_1       -1.0
    z_5_5_2_2         OBJ           0.0
    z_5_5_2_2         DAY_5_5_2       1.0
    z_5_5_2_2         REQ_5_5         1.0
    z_5_5_2_2         OCC_5_2_2       -1.0
    z_5_5_2_2         CLS_5_2_2       -1.0
    z_5_5_2_3         OBJ           0.0
    z_5_5_2_3         DAY_5_5_2       1.0
    z_5_5_2_3         REQ_5_5         1.0
    z_5_5_2_3         OCC_5_2_4       -1.0
    z_5_5_2_3         CLS_5_2_4       -1.0
    z_5_5_2_4         OBJ           0.0
    z_5_5_2_4         DAY_5_5_2       1.0
    z_5_5_2_4         REQ_5_5         1.0
    z_5_5_2_4         OCC_5_2_5       -1.0
    z_5_5_2_4         CLS_5_2_5       -1.0
    z_5_5_2_5         OBJ           0.0
    z_5_5_2_5         DAY_5_5_2       1.0
    z_5_5_2_5         REQ_5_5         2.0
    z_5_5_2_5         OCC_5_2_0       -1.0
    z_5_5_2_5         OCC_5_2_1       -1.0
    z_5_5_2_5         CLS_5_2_0       -1.0
    z_5_5_2_5         CLS_5_2_1       -1.0
    z_5_5_2_6         OBJ           0.0
    z_5_5_2_6         DAY_5_5_2       1.0
    z_5_5_2_6         REQ_5_5         2.0
    z_5_5_2_6         OCC_5_2_1       -1.0
    z_5_5_2_6         OCC_5_2_2       -1.0
    z_5_5_2_6         CLS_5_2_1       -1.0
    z_5_5_2_6         CLS_5_2_2       -1.0
    z_5_5_2_7         OBJ           0.0
    z_5_5_2_7         DAY_5_5_2       1.0
    z_5_5_2_7         REQ_5_5         2.0
    z_5_5_2_7         OCC_5_2_4       -1.0
    z_5_5_2_7         OCC_5_2_5       -1.0
    z_5_5_2_7         CLS_5_2_4       -1.0
    z_5_5_2_7         CLS_5_2_5       -1.0
    z_5_5_3_0         OBJ           0.0
    z_5_5_3_0         DAY_5_5_3       1.0
    z_5_5_3_0         REQ_5_5         1.0
    z_5_5_3_0         OCC_5_3_0       -1.0
    z_5_5_3_0         CLS_5_3_0       -1.0
    z_5_5_3_1         OBJ           0.0
    z_5_5_3_1         DAY_5_5_3       1.0
    z_5_5_3_1         REQ_5_5         1.0
    z_5_5_3_1         OCC_5_3_1       -1.0
    z_5_5_3_1         CLS_5_3_1       -1.0
    z_5_5_3_2         OBJ           0.0
    z_5_5_3_2         DAY_5_5_3       1.0
    z_5_5_3_2         REQ_5_5         1.0
    z_5_5_3_2         OCC_5_3_2       -1.0
    z_5_5_3_2         CLS_5_3_2       -1.0
    z_5_5_3_3         OBJ           0.0
    z_5_5_3_3         DAY_5_5_3       1.0
    z_5_5_3_3         REQ_5_5         1.0
    z_5_5_3_3         OCC_5_3_3       -1.0
    z_5_5_3_3         CLS_5_3_3       -1.0
    z_5_5_3_4         OBJ           0.0
    z_5_5_3_4         DAY_5_5_3       1.0
    z_5_5_3_4         REQ_5_5         1.0
    z_5_5_3_4         OCC_5_3_4       -1.0
    z_5_5_3_4         CLS_5_3_4       -1.0
    z_5_5_3_5         OBJ           0.0
    z_5_5_3_5         DAY_5_5_3       1.0
    z_5_5_3_5         REQ_5_5         1.0
    z_5_5_3_5         OCC_5_3_5       -1.0
    z_5_5_3_5         CLS_5_3_5       -1.0
    z_5_5_3_6         OBJ           0.0
    z_5_5_3_6         DAY_5_5_3       1.0
    z_5_5_3_6         REQ_5_5         2.0
    z_5_5_3_6         OCC_5_3_0       -1.0
    z_5_5_3_6         OCC_5_3_1       -1.0
    z_5_5_3_6         CLS_5_3_0       -1.0
    z_5_5_3_6         CLS_5_3_1       -1.0
    z_5_5_3_7         OBJ           0.0
    z_5_5_3_7         DAY_5_5_3       1.0
    z_5_5_3_7         REQ_5_5         2.0
    z_5_5_3_7         OCC_5_3_1       -1.0
    z_5_5_3_7         OCC_5_3_2       -1.0
    z_5_5_3_7         CLS_5_3_1       -1.0
    z_5_5_3_7         CLS_5_3_2       -1.0
    z_5_5_3_8         OBJ           0.0
    z_5_5_3_8         DAY_5_5_3       1.0
    z_5_5_3_8         REQ_5_5         2.0
    z_5_5_3_8         OCC_5_3_2       -1.0
    z_5_5_3_8         OCC_5_3_3       -1.0
    z_5_5_3_8         CLS_5_3_2       -1.0
    z_5_5_3_8         CLS_5_3_3       -1.0
    z_5_5_3_9         OBJ           0.0
    z_5_5_3_9         DAY_5_5_3       1.0
    z_5_5_3_9         REQ_5_5         2.0
    z_5_5_3_9         OCC_5_3_3       -1.0
    z_5_5_3_9         OCC_5_3_4       -1.0
    z_5_5_3_9         CLS_5_3_3       -1.0
    z_5_5_3_9         CLS_5_3_4       -1.0
    z_5_5_3_10        OBJ           0.0
    z_5_5_3_10        DAY_5_5_3       1.0
    z_5_5_3_10        REQ_5_5         2.0
    z_5_5_3_10        OCC_5_3_4       -1.0
    z_5_5_3_10        OCC_5_3_5       -1.0
    z_5_5_3_10        CLS_5_3_4       -1.0
    z_5_5_3_10        CLS_5_3_5       -1.0
    w_0_0             OBJ           10.0
    w_0_0             WDEF_0_0_0      1.0
    w_0_0             WDEF_0_0_1      1.0
    w_0_0             WDEF_0_0_2      1.0
    w_0_0             WDEF_0_0_3      1.0
    w_0_0             WDEF_0_0_4      1.0
    w_0_0             WDEF_0_0_5      1.0
    w_0_1             OBJ           10.0
    w_0_1             WDEF_0_1_0      1.0
    w_0_1             WDEF_0_1_1      1.0
    w_0_1             WDEF_0_1_2      1.0
    w_0_1             WDEF_0_1_3      1.0
    w_0_1             WDEF_0_1_4      1.0
    w_0_1             WDEF_0_1_5      1.0
    w_0_2             OBJ           10.0
    w_0_2             WDEF_0_2_0      1.0
    w_0_2             WDEF_0_2_1      1.0
    w_0_2             WDEF_0_2_2      1.0
    w_0_2             WDEF_0_2_3      1.0
    w_0_2             WDEF_0_2_4      1.0
    w_0_2             WDEF_0_2_5      1.0
    w_0_3             OBJ           10.0
    w_0_3             WDEF_0_3_0      1.0
    w_0_3             WDEF_0_3_1      1.0
    w_0_3             WDEF_0_3_2      1.0
    w_0_3             WDEF_0_3_3      1.0
    w_0_3             WDEF_0_3_4      1.0
    w_0_3             WDEF_0_3_5      1.0
    w_0_4             OBJ           10.0
    w_0_4             WDEF_0_4_0      1.0
    w_0_4             WDEF_0_4_1      1.0
    w_0_4             WDEF_0_4_2      1.0
    w_0_4             WDEF_0_4_3      1.0
    w_0_4             WDEF_0_4_4      1.0
    w_0_4             WDEF_0_4_5      1.0
    w_1_0             OBJ           10.0
    w_1_0             WDEF_1_0_0      1.0
    w_1_0             WDEF_1_0_1      1.0
    w_1_0             WDEF_1_0_2      1.0
    w_1_0             WDEF_1_0_3      1.0
    w_1_0             WDEF_1_0_4      1.0
    w_1_0             WDEF_1_0_5      1.0
    w_1_1             OBJ           10.0
    w_1_1             WDEF_1_1_0      1.0
    w_1_1             WDEF_1_1_1      1.0
    w_1_1             WDEF_1_1_2      1.0
    w_1_1             WDEF_1_1_3      1.0
    w_1_1             WDEF_1_1_4      1.0
    w_1_1             WDEF_1_1_5      1.0
    w_1_2             OBJ           10.0
    w_1_2             WDEF_1_2_0      1.0
    w_1_2             WDEF_1_2_1      1.0
    w_1_2             WDEF_1_2_2      1.0
    w_1_2             WDEF_1_2_3      1.0
    w_1_2             WDEF_1_2_4      1.0
    w_1_2             WDEF_1_2_5      1.0
    w_1_3             OBJ           10.0
    w_1_3             WDEF_1_3_0      1.0
    w_1_3             WDEF_1_3_1      1.0
    w_1_3             WDEF_1_3_2      1.0
    w_1_3             WDEF_1_3_3      1.0
    w_1_3             WDEF_1_3_4      1.0
    w_1_3             WDEF_1_3_5      1.0
    w_1_4             OBJ           10.0
    w_1_4             WDEF_1_4_0      1.0
    w_1_4             WDEF_1_4_1      1.0
    w_1_4             WDEF_1_4_2      1.0
    w_1_4             WDEF_1_4_3      1.0
    w_1_4             WDEF_1_4_4      1.0
    w_1_4             WDEF_1_4_5      1.0
    w_2_0             OBJ           10.0
    w_2_0             WDEF_2_0_0      1.0
    w_2_0             WDEF_2_0_1      1.0
    w_2_0             WDEF_2_0_2      1.0
    w_2_0             WDEF_2_0_3      1.0
    w_2_0             WDEF_2_0_4      1.0
    w_2_0             WDEF_2_0_5      1.0
    w_2_1             OBJ           10.0
    w_2_1             WDEF_2_1_0      1.0
    w_2_1             WDEF_2_1_1      1.0
    w_2_1             WDEF_2_1_2      1.0
    w_2_1             WDEF_2_1_3      1.0
    w_2_1             WDEF_2_1_4      1.0
    w_2_1             WDEF_2_1_5      1.0
    w_2_2             OBJ           10.0
    w_2_2             WDEF_2_2_0      1.0
    w_2_2             WDEF_2_2_1      1.0
    w_2_2             WDEF_2_2_2      1.0
    w_2_2             WDEF_2_2_3      1.0
    w_2_2             WDEF_2_2_4      1.0
    w_2_2             WDEF_2_2_5      1.0
    w_2_3             OBJ           10.0
    w_2_3             WDEF_2_3_0      1.0
    w_2_3             WDEF_2_3_1      1.0
    w_2_3             WDEF_2_3_2      1.0
    w_2_3             WDEF_2_3_3      1.0
    w_2_3             WDEF_2_3_4      1.0
    w_2_3             WDEF_2_3_5      1.0
    w_2_4             OBJ           10.0
    w_2_4             WDEF_2_4_0      1.0
    w_2_4             WDEF_2_4_1      1.0
    w_2_4             WDEF_2_4_2      1.0
    w_2_4             WDEF_2_4_3      1.0
    w_2_4             WDEF_2_4_4      1.0
    w_2_4             WDEF_2_4_5      1.0
    w_3_0             OBJ           10.0
    w_3_0             WDEF_3_0_0      1.0
    w_3_0             WDEF_3_0_1      1.0
    w_3_0             WDEF_3_0_2      1.0
    w_3_0             WDEF_3_0_3      1.0
    w_3_0             WDEF_3_0_4      1.0
    w_3_0             WDEF_3_0_5      1.0
    w_3_1             OBJ           10.0
    w_3_1             WDEF_3_1_0      1.0
    w_3_1             WDEF_3_1_1      1.0
    w_3_1             WDEF_3_1_2      1.0
    w_3_1             WDEF_3_1_3      1.0
    w_3_1             WDEF_3_1_4      1.0
    w_3_1             WDEF_3_1_5      1.0
    w_3_2             OBJ           10.0
    w_3_2             WDEF_3_2_0      1.0
    w_3_2             WDEF_3_2_1      1.0
    w_3_2             WDEF_3_2_2      1.0
    w_3_2             WDEF_3_2_3      1.0
    w_3_2             WDEF_3_2_4      1.0
    w_3_2             WDEF_3_2_5      1.0
    w_3_3             OBJ           10.0
    w_3_3             WDEF_3_3_0      1.0
    w_3_3             WDEF_3_3_1      1.0
    w_3_3             WDEF_3_3_2      1.0
    w_3_3             WDEF_3_3_3      1.0
    w_3_3             WDEF_3_3_4      1.0
    w_3_3             WDEF_3_3_5      1.0
    w_3_4             OBJ           10.0
    w_3_4             WDEF_3_4_0      1.0
    w_3_4             WDEF_3_4_1      1.0
    w_3_4             WDEF_3_4_2      1.0
    w_3_4             WDEF_3_4_3      1.0
    w_3_4             WDEF_3_4_4      1.0
    w_3_4             WDEF_3_4_5      1.0
    w_4_0             OBJ           10.0
    w_4_0             WDEF_4_0_0      1.0
    w_4_0             WDEF_4_0_1      1.0
    w_4_0             WDEF_4_0_2      1.0
    w_4_0             WDEF_4_0_3      1.0
    w_4_0             WDEF_4_0_4      1.0
    w_4_0             WDEF_4_0_5      1.0
    w_4_1             OBJ           10.0
    w_4_1             WDEF_4_1_0      1.0
    w_4_1             WDEF_4_1_1      1.0
    w_4_1             WDEF_4_1_2      1.0
    w_4_1             WDEF_4_1_3      1.0
    w_4_1             WDEF_4_1_4      1.0
    w_4_1             WDEF_4_1_5      1.0
    w_4_2             OBJ           10.0
    w_4_2             WDEF_4_2_0      1.0
    w_4_2             WDEF_4_2_1      1.0
    w_4_2             WDEF_4_2_2      1.0
    w_4_2             WDEF_4_2_3      1.0
    w_4_2             WDEF_4_2_4      1.0
    w_4_2             WDEF_4_2_5      1.0
    w_4_3             OBJ           10.0
    w_4_3             WDEF_4_3_0      1.0
    w_4_3             WDEF_4_3_1      1.0
    w_4_3             WDEF_4_3_2      1.0
    w_4_3             WDEF_4_3_3      1.0
    w_4_3             WDEF_4_3_4      1.0
    w_4_3             WDEF_4_3_5      1.0
    w_4_4             OBJ           10.0
    w_4_4             WDEF_4_4_0      1.0
    w_4_4             WDEF_4_4_1      1.0
    w_4_4             WDEF_4_4_2      1.0
    w_4_4             WDEF_4_4_3      1.0
    w_4_4             WDEF_4_4_4      1.0
    w_4_4             WDEF_4_4_5      1.0
    w_5_0             OBJ           10.0
    w_5_0             WDEF_5_0_0      1.0
    w_5_0             WDEF_5_0_1      1.0
    w_5_0             WDEF_5_0_2      1.0
    w_5_0             WDEF_5_0_3      1.0
    w_5_0             WDEF_5_0_4      1.0
    w_5_0             WDEF_5_0_5      1.0
    w_5_1             OBJ           10.0
    w_5_1             WDEF_5_1_0      1.0
    w_5_1             WDEF_5_1_1      1.0
    w_5_1             WDEF_5_1_2      1.0
    w_5_1             WDEF_5_1_3      1.0
    w_5_1             WDEF_5_1_4      1.0
    w_5_1             WDEF_5_1_5      1.0
    w_5_2             OBJ           10.0
    w_5_2             WDEF_5_2_0      1.0
    w_5_2             WDEF_5_2_1      1.0
    w_5_2             WDEF_5_2_2      1.0
    w_5_2             WDEF_5_2_3      1.0
    w_5_2             WDEF_5_2_4      1.0
    w_5_2             WDEF_5_2_5      1.0
    w_5_3             OBJ           10.0
    w_5_3             WDEF_5_3_0      1.0
    w_5_3             WDEF_5_3_1      1.0
    w_5_3             WDEF_5_3_2      1.0
    w_5_3             WDEF_5_3_3      1.0
    w_5_3             WDEF_5_3_4      1.0
    w_5_3             WDEF_5_3_5      1.0
    w_5_4             OBJ           10.0
    w_5_4             WDEF_5_4_0      1.0
    w_5_4             WDEF_5_4_1      1.0
    w_5_4             WDEF_5_4_2      1.0
    w_5_4             WDEF_5_4_3      1.0
    w_5_4             WDEF_5_4_4      1.0
    w_5_4             WDEF_5_4_5      1.0
    w_6_0             OBJ           10.0
    w_6_0             WDEF_6_0_0      1.0
    w_6_0             WDEF_6_0_1      1.0
    w_6_0             WDEF_6_0_2      1.0
    w_6_0             WDEF_6_0_3      1.0
    w_6_0             WDEF_6_0_4      1.0
    w_6_0             WDEF_6_0_5      1.0
    w_6_1             OBJ           10.0
    w_6_1             WDEF_6_1_0      1.0
    w_6_1             WDEF_6_1_1      1.0
    w_6_1             WDEF_6_1_2      1.0
    w_6_1             WDEF_6_1_3      1.0
    w_6_1             WDEF_6_1_4      1.0
    w_6_1             WDEF_6_1_5      1.0
    w_6_2             OBJ           10.0
    w_6_2             WDEF_6_2_0      1.0
    w_6_2             WDEF_6_2_1      1.0
    w_6_2             WDEF_6_2_2      1.0
    w_6_2             WDEF_6_2_3      1.0
    w_6_2             WDEF_6_2_4      1.0
    w_6_2             WDEF_6_2_5      1.0
    w_6_3             OBJ           10.0
    w_6_3             WDEF_6_3_0      1.0
    w_6_3             WDEF_6_3_1      1.0
    w_6_3             WDEF_6_3_2      1.0
    w_6_3             WDEF_6_3_3      1.0
    w_6_3             WDEF_6_3_4      1.0
    w_6_3             WDEF_6_3_5      1.0
    w_6_4             OBJ           10.0
    w_6_4             WDEF_6_4_0      1.0
    w_6_4             WDEF_6_4_1      1.0
    w_6_4             WDEF_6_4_2      1.0
    w_6_4             WDEF_6_4_3      1.0
    w_6_4             WDEF_6_4_4      1.0
    w_6_4             WDEF_6_4_5      1.0
    w_7_0             OBJ           10.0
    w_7_0             WDEF_7_0_0      1.0
    w_7_0             WDEF_7_0_1      1.0
    w_7_0             WDEF_7_0_2      1.0
    w_7_0             WDEF_7_0_3      1.0
    w_7_0             WDEF_7_0_4      1.0
    w_7_0             WDEF_7_0_5      1.0
    w_7_1             OBJ           10.0
    w_7_1             WDEF_7_1_0      1.0
    w_7_1             WDEF_7_1_1      1.0
    w_7_1             WDEF_7_1_2      1.0
    w_7_1             WDEF_7_1_3      1.0
    w_7_1             WDEF_7_1_4      1.0
    w_7_1             WDEF_7_1_5      1.0
    w_7_2             OBJ           10.0
    w_7_2             WDEF_7_2_0      1.0
    w_7_2             WDEF_7_2_1      1.0
    w_7_2             WDEF_7_2_2      1.0
    w_7_2             WDEF_7_2_3      1.0
    w_7_2             WDEF_7_2_4      1.0
    w_7_2             WDEF_7_2_5      1.0
    w_7_3             OBJ           10.0
    w_7_3             WDEF_7_3_0      1.0
    w_7_3             WDEF_7_3_1      1.0
    w_7_3             WDEF_7_3_2      1.0
    w_7_3             WDEF_7_3_3      1.0
    w_7_3             WDEF_7_3_4      1.0
    w_7_3             WDEF_7_3_5      1.0
    w_7_4             OBJ           10.0
    w_7_4             WDEF_7_4_0      1.0
    w_7_4             WDEF_7_4_1      1.0
    w_7_4             WDEF_7_4_2      1.0
    w_7_4             WDEF_7_4_3      1.0
    w_7_4             WDEF_7_4_4      1.0
    w_7_4             WDEF_7_4_5      1.0
    MARK0001  'MARKER'                 'INTEND'
    o_0_0_0           OBJ           0.0
    o_0_0_0           OCC_0_0_0       1.0
    o_0_0_0           WDEF_0_0_0      -1.0
    o_0_0_0           BFO_0_0_1       -1.0
    o_0_0_0           GAP_0_0_0       1.0
    o_0_0_1           OBJ           0.0
    o_0_0_1           OCC_0_0_1       1.0
    o_0_0_1           WDEF_0_0_1      -1.0
    o_0_0_1           AFO_0_0_0       -1.0
    o_0_0_1           BFO_0_0_2       -1.0
    o_0_0_1           GAP_0_0_1       1.0
    o_0_0_2           OBJ           0.0
    o_0_0_2           OCC_0_0_2       1.0
    o_0_0_2           WDEF_0_0_2      -1.0
    o_0_0_2           AFO_0_0_1       -1.0
    o_0_0_2           BFO_0_0_3       -1.0
    o_0_0_2           GAP_0_0_2       1.0
    o_0_0_3           OBJ           0.0
    o_0_0_3           OCC_0_0_3       1.0
    o_0_0_3           WDEF_0_0_3      -1.0
    o_0_0_3           AFO_0_0_2       -1.0
    o_0_0_3           BFO_0_0_4       -1.0
    o_0_0_3           GAP_0_0_3       1.0
    o_0_0_4           OBJ           0.0
    o_0_0_4           OCC_0_0_4       1.0
    o_0_0_4           WDEF_0_0_4      -1.0
    o_0_0_4           AFO_0_0_3       -1.0
    o_0_0_4           BFO_0_0_5       -1.0
    o_0_0_4           GAP_0_0_4       1.0
    o_0_0_5           OBJ           0.0
    o_0_0_5           OCC_0_0_5       1.0
    o_0_0_5           WDEF_0_0_5      -1.0
    o_0_0_5           AFO_0_0_4       -1.0
    o_0_0_5           GAP_0_0_5       1.0
    o_0_1_0           OBJ           0.0
    o_0_1_0           OCC_0_1_0       1.0
    o_0_1_0           WDEF_0_1_0      -1.0
    o_0_1_0           BFO_0_1_1       -1.0
    o_0_1_0           GAP_0_1_0       1.0
    o_0_1_1           OBJ           0.0
    o_0_1_1           OCC_0_1_1       1.0
    o_0_1_1           WDEF_0_1_1      -1.0
    o_0_1_1           AFO_0_1_0       -1.0
    o_0_1_1           BFO_0_1_2       -1.0
    o_0_1_1           GAP_0_1_1       1.0
    o_0_1_2           OBJ           0.0
    o_0_1_2           OCC_0_1_2       1.0
    o_0_1_2           WDEF_0_1_2      -1.0
    o_0_1_2           AFO_0_1_1       -1.0
    o_0_1_2           BFO_0_1_3       -1.0
    o_0_1_2           GAP_0_1_2       1.0
    o_0_1_3           OBJ           0.0
    o_0_1_3           OCC_0_1_3       1.0
    o_0_1_3           WDEF_0_1_3      -1.0
    o_0_1_3           AFO_0_1_2       -1.0
    o_0_1_3           BFO_0_1_4       -1.0
    o_0_1_3           GAP_0_1_3       1.0
    o_0_1_4           OBJ           0.0
    o_0_1_4           OCC_0_1_4       1.0
    o_0_1_4           WDEF_0_1_4      -1.0
    o_0_1_4           AFO_0_1_3       -1.0
    o_0_1_4           BFO_0_1_5       -1.0
    o_0_1_4           GAP_0_1_4       1.0
    o_0_1_5           OBJ           0.0
    o_0_1_5           OCC_0_1_5       1.0
    o_0_1_5           WDEF_0_1_5      -1.0
    o_0_1_5           AFO_0_1_4       -1.0
    o_0_1_5           GAP_0_1_5       1.0
    o_0_2_0           OBJ           0.0
    o_0_2_0           OCC_0_2_0       1.0
    o_0_2_0           WDEF_0_2_0      -1.0
    o_0_2_0           BFO_0_2_1       -1.0
    o_0_2_0           GAP_0_2_0       1.0
    o_0_2_1           OBJ           0.0
    o_0_2_1           OCC_0_2_1       1.0
    o_0_2_1           WDEF_0_2_1      -1.0
    o_0_2_1           AFO_0_2_0       -1.0
    o_0_2_1           BFO_0_2_2       -1.0
    o_0_2_1           GAP_0_2_1       1.0
    o_0_2_2           OBJ           0.0
    o_0_2_2           OCC_0_2_2       1.0
    o_0_2_2           WDEF_0_2_2      -1.0
    o_0_2_2           AFO_0_2_1       -1.0
    o_0_2_2           BFO_0_2_3       -1.0
    o_0_2_2           GAP_0_2_2       1.0
    o_0_2_3           OBJ           0.0
    o_0_2_3           OCC_0_2_3       1.0
    o_0_2_3           WDEF_0_2_3      -1.0
    o_0_2_3           AFO_0_2_2       -1.0
    o_0_2_3           BFO_0_2_4       -1.0
    o_0_2_3           GAP_0_2_3       1.0
    o_0_2_4           OBJ           0.0
    o_0_2_4           OCC_0_2_4       1.0
    o_0_2_4           WDEF_0_2_4      -1.0
    o_0_2_4           AFO_0_2_3       -1.0
    o_0_2_4           BFO_0_2_5       -1.0
    o_0_2_4           GAP_0_2_4       1.0
    o_0_2_5           OBJ           0.0
    o_0_2_5           OCC_0_2_5       1.0
    o_0_2_5           WDEF_0_2_5      -1.0
    o_0_2_5           AFO_0_2_4       -1.0
    o_0_2_5           GAP_0_2_5       1.0
    o_0_3_0           OBJ           0.0
    o_0_3_0           OCC_0_3_0       1.0
    o_0_3_0           WDEF_0_3_0      -1.0
    o_0_3_0           BFO_0_3_1       -1.0
    o_0_3_0           GAP_0_3_0       1.0
    o_0_3_1           OBJ           0.0
    o_0_3_1           OCC_0_3_1       1.0
    o_0_3_1           WDEF_0_3_1      -1.0
    o_0_3_1           AFO_0_3_0       -1.0
    o_0_3_1           BFO_0_3_2       -1.0
    o_0_3_1           GAP_0_3_1       1.0
    o_0_3_2           OBJ           0.0
    o_0_3_2           OCC_0_3_2       1.0
    o_0_3_2           WDEF_0_3_2      -1.0
    o_0_3_2           AFO_0_3_1       -1.0
    o_0_3_2           BFO_0_3_3       -1.0
    o_0_3_2           GAP_0_3_2       1.0
    o_0_3_3           OBJ           0.0
    o_0_3_3           OCC_0_3_3       1.0
    o_0_3_3           WDEF_0_3_3      -1.0
    o_0_3_3           AFO_0_3_2       -1.0
    o_0_3_3           BFO_0_3_4       -1.0
    o_0_3_3           GAP_0_3_3       1.0
    o_0_3_4           OBJ           0.0
    o_0_3_4           OCC_0_3_4       1.0
    o_0_3_4           WDEF_0_3_4      -1.0
    o_0_3_4           AFO_0_3_3       -1.0
    o_0_3_4           BFO_0_3_5       -1.0
    o_0_3_4           GAP_0_3_4       1.0
    o_0_3_5           OBJ           0.0
    o_0_3_5           OCC_0_3_5       1.0
    o_0_3_5           WDEF_0_3_5      -1.0
    o_0_3_5           AFO_0_3_4       -1.0
    o_0_3_5           GAP_0_3_5       1.0
    o_0_4_0           OBJ           0.0
    o_0_4_0           OCC_0_4_0       1.0
    o_0_4_0           WDEF_0_4_0      -1.0
    o_0_4_0           BFO_0_4_1       -1.0
    o_0_4_0           GAP_0_4_0       1.0
    o_0_4_1           OBJ           0.0
    o_0_4_1           OCC_0_4_1       1.0
    o_0_4_1           WDEF_0_4_1      -1.0
    o_0_4_1           AFO_0_4_0       -1.0
    o_0_4_1           BFO_0_4_2       -1.0
    o_0_4_1           GAP_0_4_1       1.0
    o_0_4_2           OBJ           0.0
    o_0_4_2           OCC_0_4_2       1.0
    o_0_4_2           WDEF_0_4_2      -1.0
    o_0_4_2           AFO_0_4_1       -1.0
    o_0_4_2           BFO_0_4_3       -1.0
    o_0_4_2           GAP_0_4_2       1.0
    o_0_4_3           OBJ           0.0
    o_0_4_3           OCC_0_4_3       1.0
    o_0_4_3           WDEF_0_4_3      -1.0
    o_0_4_3           AFO_0_4_2       -1.0
    o_0_4_3           BFO_0_4_4       -1.0
    o_0_4_3           GAP_0_4_3       1.0
    o_0_4_4           OBJ           0.0
    o_0_4_4           OCC_0_4_4       1.0
    o_0_4_4           WDEF_0_4_4      -1.0
    o_0_4_4           AFO_0_4_3       -1.0
    o_0_4_4           BFO_0_4_5       -1.0
    o_0_4_4           GAP_0_4_4       1.0
    o_0_4_5           OBJ           0.0
    o_0_4_5           OCC_0_4_5       1.0
    o_0_4_5           WDEF_0_4_5      -1.0
    o_0_4_5           AFO_0_4_4       -1.0
    o_0_4_5           GAP_0_4_5       1.0
    o_1_0_0           OBJ           0.0
    o_1_0_0           OCC_1_0_0       1.0
    o_1_0_0           WDEF_1_0_0      -1.0
    o_1_0_0           BFO_1_0_1       -1.0
    o_1_0_0           GAP_1_0_0       1.0
    o_1_0_1           OBJ           0.0
    o_1_0_1           OCC_1_0_1       1.0
    o_1_0_1           WDEF_1_0_1      -1.0
    o_1_0_1           AFO_1_0_0       -1.0
    o_1_0_1           BFO_1_0_2       -1.0
    o_1_0_1           GAP_1_0_1       1.0
    o_1_0_2           OBJ           0.0
    o_1_0_2           OCC_1_0_2       1.0
    o_1_0_2           WDEF_1_0_2      -1.0
    o_1_0_2           AFO_1_0_1       -1.0
    o_1_0_2           BFO_1_0_3       -1.0
    o_1_0_2           GAP_1_0_2       1.0
    o_1_0_3           OBJ           0.0
    o_1_0_3           OCC_1_0_3       1.0
    o_1_0_3           WDEF_1_0_3      -1.0
    o_1_0_3           AFO_1_0_2       -1.0
    o_1_0_3           BFO_1_0_4       -1.0
    o_1_0_3           GAP_1_0_3       1.0
    o_1_0_4           OBJ           0.0
    o_1_0_4           OCC_1_0_4       1.0
    o_1_0_4           WDEF_1_0_4      -1.0
    o_1_0_4           AFO_1_0_3       -1.0
    o_1_0_4           BFO_1_0_5       -1.0
    o_1_0_4           GAP_1_0_4       1.0
    o_1_0_5           OBJ           0.0
    o_1_0_5           OCC_1_0_5       1.0
    o_1_0_5           WDEF_1_0_5      -1.0
    o_1_0_5           AFO_1_0_4       -1.0
    o_1_0_5           GAP_1_0_5       1.0
    o_1_1_0           OBJ           0.0
    o_1_1_0           OCC_1_1_0       1.0
    o_1_1_0           WDEF_1_1_0      -1.0
    o_1_1_0           BFO_1_1_1       -1.0
    o_1_1_0           GAP_1_1_0       1.0
    o_1_1_1           OBJ           0.0
    o_1_1_1           OCC_1_1_1       1.0
    o_1_1_1           WDEF_1_1_1      -1.0
    o_1_1_1           AFO_1_1_0       -1.0
    o_1_1_1           BFO_1_1_2       -1.0
    o_1_1_1           GAP_1_1_1       1.0
    o_1_1_2           OBJ           0.0
    o_1_1_2           OCC_1_1_2       1.0
    o_1_1_2           WDEF_1_1_2      -1.0
    o_1_1_2           AFO_1_1_1       -1.0
    o_1_1_2           BFO_1_1_3       -1.0
    o_1_1_2           GAP_1_1_2       1.0
    o_1_1_3           OBJ           0.0
    o_1_1_3           OCC_1_1_3       1.0
    o_1_1_3           WDEF_1_1_3      -1.0
    o_1_1_3           AFO_1_1_2       -1.0
    o_1_1_3           BFO_1_1_4       -1.0
    o_1_1_3           GAP_1_1_3       1.0
    o_1_1_4           OBJ           0.0
    o_1_1_4           OCC_1_1_4       1.0
    o_1_1_4           WDEF_1_1_4      -1.0
    o_1_1_4           AFO_1_1_3       -1.0
    o_1_1_4           BFO_1_1_5       -1.0
    o_1_1_4           GAP_1_1_4       1.0
    o_1_1_5           OBJ           0.0
    o_1_1_5           OCC_1_1_5       1.0
    o_1_1_5           WDEF_1_1_5      -1.0
    o_1_1_5           AFO_1_1_4       -1.0
    o_1_1_5           GAP_1_1_5       1.0
    o_1_2_0           OBJ           0.0
    o_1_2_0           OCC_1_2_0       1.0
    o_1_2_0           WDEF_1_2_0      -1.0
    o_1_2_0           BFO_1_2_1       -1.0
    o_1_2_0           GAP_1_2_0       1.0
    o_1_2_1           OBJ           0.0
    o_1_2_1           OCC_1_2_1       1.0
    o_1_2_1           WDEF_1_2_1      -1.0
    o_1_2_1           AFO_1_2_0       -1.0
    o_1_2_1           BFO_1_2_2       -1.0
    o_1_2_1           GAP_1_2_1       1.0
    o_1_2_2           OBJ           0.0
    o_1_2_2           OCC_1_2_2       1.0
    o_1_2_2           WDEF_1_2_2      -1.0
    o_1_2_2           AFO_1_2_1       -1.0
    o_1_2_2           BFO_1_2_3       -1.0
    o_1_2_2           GAP_1_2_2       1.0
    o_1_2_3           OBJ           0.0
    o_1_2_3           OCC_1_2_3       1.0
    o_1_2_3           WDEF_1_2_3      -1.0
    o_1_2_3           AFO_1_2_2       -1.0
    o_1_2_3           BFO_1_2_4       -1.0
    o_1_2_3           GAP_1_2_3       1.0
    o_1_2_4           OBJ           0.0
    o_1_2_4           OCC_1_2_4       1.0
    o_1_2_4           WDEF_1_2_4      -1.0
    o_1_2_4           AFO_1_2_3       -1.0
    o_1_2_4           BFO_1_2_5       -1.0
    o_1_2_4           GAP_1_2_4       1.0
    o_1_2_5           OBJ           0.0
    o_1_2_5           OCC_1_2_5       1.0
    o_1_2_5           WDEF_1_2_5      -1.0
    o_1_2_5           AFO_1_2_4       -1.0
    o_1_2_5           GAP_1_2_5       1.0
    o_1_3_0           OBJ           0.0
    o_1_3_0           OCC_1_3_0       1.0
    o_1_3_0           WDEF_1_3_0      -1.0
    o_1_3_0           BFO_1_3_1       -1.0
    o_1_3_0           GAP_1_3_0       1.0
    o_1_3_1           OBJ           0.0
    o_1_3_1           OCC_1_3_1       1.0
    o_1_3_1           WDEF_1_3_1      -1.0
    o_1_3_1           AFO_1_3_0       -1.0
    o_1_3_1           BFO_1_3_2       -1.0
    o_1_3_1           GAP_1_3_1       1.0
    o_1_3_2           OBJ           0.0
    o_1_3_2           OCC_1_3_2       1.0
    o_1_3_2           WDEF_1_3_2      -1.0
    o_1_3_2           AFO_1_3_1       -1.0
    o_1_3_2           BFO_1_3_3       -1.0
    o_1_3_2           GAP_1_3_2       1.0
    o_1_3_3           OBJ           0.0
    o_1_3_3           OCC_1_3_3       1.0
    o_1_3_3           WDEF_1_3_3      -1.0
    o_1_3_3           AFO_1_3_2       -1.0
    o_1_3_3           BFO_1_3_4       -1.0
    o_1_3_3           GAP_1_3_3       1.0
    o_1_3_4           OBJ           0.0
    o_1_3_4           OCC_1_3_4       1.0
    o_1_3_4           WDEF_1_3_4      -1.0
    o_1_3_4           AFO_1_3_3       -1.0
    o_1_3_4           BFO_1_3_5       -1.0
    o_1_3_4           GAP_1_3_4       1.0
    o_1_3_5           OBJ           0.0
    o_1_3_5           OCC_1_3_5       1.0
    o_1_3_5           WDEF_1_3_5      -1.0
    o_1_3_5           AFO_1_3_4       -1.0
    o_1_3_5           GAP_1_3_5       1.0
    o_1_4_0           OBJ           0.0
    o_1_4_0           OCC_1_4_0       1.0
    o_1_4_0           WDEF_1_4_0      -1.0
    o_1_4_0           BFO_1_4_1       -1.0
    o_1_4_0           GAP_1_4_0       1.0
    o_1_4_1           OBJ           0.0
    o_1_4_1           OCC_1_4_1       1.0
    o_1_4_1           WDEF_1_4_1      -1.0
    o_1_4_1           AFO_1_4_0       -1.0
    o_1_4_1           BFO_1_4_2       -1.0
    o_1_4_1           GAP_1_4_1       1.0
    o_1_4_2           OBJ           0.0
    o_1_4_2           OCC_1_4_2       1.0
    o_1_4_2           WDEF_1_4_2      -1.0
    o_1_4_2           AFO_1_4_1       -1.0
    o_1_4_2           BFO_1_4_3       -1.0
    o_1_4_2           GAP_1_4_2       1.0
    o_1_4_3           OBJ           0.0
    o_1_4_3           OCC_1_4_3       1.0
    o_1_4_3           WDEF_1_4_3      -1.0
    o_1_4_3           AFO_1_4_2       -1.0
    o_1_4_3           BFO_1_4_4       -1.0
    o_1_4_3           GAP_1_4_3       1.0
    o_1_4_4           OBJ           0.0
    o_1_4_4           OCC_1_4_4       1.0
    o_1_4_4           WDEF_1_4_4      -1.0
    o_1_4_4           AFO_1_4_3       -1.0
    o_1_4_4           BFO_1_4_5       -1.0
    o_1_4_4           GAP_1_4_4       1.0
    o_1_4_5           OBJ           0.0
    o_1_4_5           OCC_1_4_5       1.0
    o_1_4_5           WDEF_1_4_5      -1.0
    o_1_4_5           AFO_1_4_4       -1.0
    o_1_4_5           GAP_1_4_5       1.0
    o_2_0_0           OBJ           0.0
    o_2_0_0           OCC_2_0_0       1.0
    o_2_0_0           WDEF_2_0_0      -1.0
    o_2_0_0           BFO_2_0_1       -1.0
    o_2_0_0           GAP_2_0_0       1.0
    o_2_0_1           OBJ           0.0
    o_2_0_1           OCC_2_0_1       1.0
    o_2_0_1           WDEF_2_0_1      -1.0
    o_2_0_1           AFO_2_0_0       -1.0
    o_2_0_1           BFO_2_0_2       -1.0
    o_2_0_1           GAP_2_0_1       1.0
    o_2_0_2           OBJ           0.0
    o_2_0_2           OCC_2_0_2       1.0
    o_2_0_2           WDEF_2_0_2      -1.0
    o_2_0_2           AFO_2_0_1       -1.0
    o_2_0_2           BFO_2_0_3       -1.0
    o_2_0_2           GAP_2_0_2       1.0
    o_2_0_3           OBJ           0.0
    o_2_0_3           OCC_2_0_3       1.0
    o_2_0_3           WDEF_2_0_3      -1.0
    o_2_0_3           AFO_2_0_2       -1.0
    o_2_0_3           BFO_2_0_4       -1.0
    o_2_0_3           GAP_2_0_3       1.0
    o_2_0_4           OBJ           0.0
    o_2_0_4           OCC_2_0_4       1.0
    o_2_0_4           WDEF_2_0_4      -1.0
    o_2_0_4           AFO_2_0_3       -1.0
    o_2_0_4           BFO_2_0_5       -1.0
    o_2_0_4           GAP_2_0_4       1.0
    o_2_0_5           OBJ           0.0
    o_2_0_5           OCC_2_0_5       1.0
    o_2_0_5           WDEF_2_0_5      -1.0
    o_2_0_5           AFO_2_0_4       -1.0
    o_2_0_5           GAP_2_0_5       1.0
    o_2_1_0           OBJ           0.0
    o_2_1_0           OCC_2_1_0       1.0
    o_2_1_0           WDEF_2_1_0      -1.0
    o_2_1_0           BFO_2_1_1       -1.0
    o_2_1_0           GAP_2_1_0       1.0
    o_2_1_1           OBJ           0.0
    o_2_1_1           OCC_2_1_1       1.0
    o_2_1_1           WDEF_2_1_1      -1.0
    o_2_1_1           AFO_2_1_0       -1.0
    o_2_1_1           BFO_2_1_2       -1.0
    o_2_1_1           GAP_2_1_1       1.0
    o_2_1_2           OBJ           0.0
    o_2_1_2           OCC_2_1_2       1.0
    o_2_1_2           WDEF_2_1_2      -1.0
    o_2_1_2           AFO_2_1_1       -1.0
    o_2_1_2           BFO_2_1_3       -1.0
    o_2_1_2           GAP_2_1_2       1.0
    o_2_1_3           OBJ           0.0
    o_2_1_3           OCC_2_1_3       1.0
    o_2_1_3           WDEF_2_1_3      -1.0
    o_2_1_3           AFO_2_1_2       -1.0
    o_2_1_3           BFO_2_1_4       -1.0
    o_2_1_3           GAP_2_1_3       1.0
    o_2_1_4           OBJ           0.0
    o_2_1_4           OCC_2_1_4       1.0
    o_2_1_4           WDEF_2_1_4      -1.0
    o_2_1_4           AFO_2_1_3       -1.0
    o_2_1_4           BFO_2_1_5       -1.0
    o_2_1_4           GAP_2_1_4       1.0
    o_2_1_5           OBJ           0.0
    o_2_1_5           OCC_2_1_5       1.0
    o_2_1_5           WDEF_2_1_5      -1.0
    o_2_1_5           AFO_2_1_4       -1.0
    o_2_1_5           GAP_2_1_5       1.0
    o_2_2_0           OBJ           0.0
    o_2_2_0           OCC_2_2_0       1.0
    o_2_2_0           WDEF_2_2_0      -1.0
    o_2_2_0           BFO_2_2_1       -1.0
    o_2_2_0           GAP_2_2_0       1.0
    o_2_2_1           OBJ           0.0
    o_2_2_1           OCC_2_2_1       1.0
    o_2_2_1           WDEF_2_2_1      -1.0
    o_2_2_1           AFO_2_2_0       -1.0
    o_2_2_1           BFO_2_2_2       -1.0
    o_2_2_1           GAP_2_2_1       1.0
    o_2_2_2           OBJ           0.0
    o_2_2_2           OCC_2_2_2       1.0
    o_2_2_2           WDEF_2_2_2      -1.0
    o_2_2_2           AFO_2_2_1       -1.0
    o_2_2_2           BFO_2_2_3       -1.0
    o_2_2_2           GAP_2_2_2       1.0
    o_2_2_3           OBJ           0.0
    o_2_2_3           OCC_2_2_3       1.0
    o_2_2_3           WDEF_2_2_3      -1.0
    o_2_2_3           AFO_2_2_2       -1.0
    o_2_2_3           BFO_2_2_4       -1.0
    o_2_2_3           GAP_2_2_3       1.0
    o_2_2_4           OBJ           0.0
    o_2_2_4           OCC_2_2_4       1.0
    o_2_2_4           WDEF_2_2_4      -1.0
    o_2_2_4           AFO_2_2_3       -1.0
    o_2_2_4           BFO_2_2_5       -1.0
    o_2_2_4           GAP_2_2_4       1.0
    o_2_2_5           OBJ           0.0
    o_2_2_5           OCC_2_2_5       1.0
    o_2_2_5           WDEF_2_2_5      -1.0
    o_2_2_5           AFO_2_2_4       -1.0
    o_2_2_5           GAP_2_2_5       1.0
    o_2_3_0           OBJ           0.0
    o_2_3_0           OCC_2_3_0       1.0
    o_2_3_0           WDEF_2_3_0      -1.0
    o_2_3_0           BFO_2_3_1       -1.0
    o_2_3_0           GAP_2_3_0       1.0
    o_2_3_1           OBJ           0.0
    o_2_3_1           OCC_2_3_1       1.0
    o_2_3_1           WDEF_2_3_1      -1.0
    o_2_3_1           AFO_2_3_0       -1.0
    o_2_3_1           BFO_2_3_2       -1.0
    o_2_3_1           GAP_2_3_1       1.0
    o_2_3_2           OBJ           0.0
    o_2_3_2           OCC_2_3_2       1.0
    o_2_3_2           WDEF_2_3_2      -1.0
    o_2_3_2           AFO_2_3_1       -1.0
    o_2_3_2           BFO_2_3_3       -1.0
    o_2_3_2           GAP_2_3_2       1.0
    o_2_3_3           OBJ           0.0
    o_2_3_3           OCC_2_3_3       1.0
    o_2_3_3           WDEF_2_3_3      -1.0
    o_2_3_3           AFO_2_3_2       -1.0
    o_2_3_3           BFO_2_3_4       -1.0
    o_2_3_3           GAP_2_3_3       1.0
    o_2_3_4           OBJ           0.0
    o_2_3_4           OCC_2_3_4       1.0
    o_2_3_4           WDEF_2_3_4      -1.0
    o_2_3_4           AFO_2_3_3       -1.0
    o_2_3_4           BFO_2_3_5       -1.0
    o_2_3_4           GAP_2_3_4       1.0
    o_2_3_5           OBJ           0.0
    o_2_3_5           OCC_2_3_5       1.0
    o_2_3_5           WDEF_2_3_5      -1.0
    o_2_3_5           AFO_2_3_4       -1.0
    o_2_3_5           GAP_2_3_5       1.0
    o_2_4_0           OBJ           0.0
    o_2_4_0           OCC_2_4_0       1.0
    o_2_4_0           WDEF_2_4_0      -1.0
    o_2_4_0           BFO_2_4_1       -1.0
    o_2_4_0           GAP_2_4_0       1.0
    o_2_4_1           OBJ           0.0
    o_2_4_1           OCC_2_4_1       1.0
    o_2_4_1           WDEF_2_4_1      -1.0
    o_2_4_1           AFO_2_4_0       -1.0
    o_2_4_1           BFO_2_4_2       -1.0
    o_2_4_1           GAP_2_4_1       1.0
    o_2_4_2           OBJ           0.0
    o_2_4_2           OCC_2_4_2       1.0
    o_2_4_2           WDEF_2_4_2      -1.0
    o_2_4_2           AFO_2_4_1       -1.0
    o_2_4_2           BFO_2_4_3       -1.0
    o_2_4_2           GAP_2_4_2       1.0
    o_2_4_3           OBJ           0.0
    o_2_4_3           OCC_2_4_3       1.0
    o_2_4_3           WDEF_2_4_3      -1.0
    o_2_4_3           AFO_2_4_2       -1.0
    o_2_4_3           BFO_2_4_4       -1.0
    o_2_4_3           GAP_2_4_3       1.0
    o_2_4_4           OBJ           0.0
    o_2_4_4           OCC_2_4_4       1.0
    o_2_4_4           WDEF_2_4_4      -1.0
    o_2_4_4           AFO_2_4_3       -1.0
    o_2_4_4           BFO_2_4_5       -1.0
    o_2_4_4           GAP_2_4_4       1.0
    o_2_4_5           OBJ           0.0
    o_2_4_5           OCC_2_4_5       1.0
    o_2_4_5           WDEF_2_4_5      -1.0
    o_2_4_5           AFO_2_4_4       -1.0
    o_2_4_5           GAP_2_4_5       1.0
    o_3_0_0           OBJ           0.0
    o_3_0_0           OCC_3_0_0       1.0
    o_3_0_0           WDEF_3_0_0      -1.0
    o_3_0_0           BFO_3_0_1       -1.0
    o_3_0_0           GAP_3_0_0       1.0
    o_3_0_1           OBJ           0.0
    o_3_0_1           OCC_3_0_1       1.0
    o_3_0_1           WDEF_3_0_1      -1.0
    o_3_0_1           AFO_3_0_0       -1.0
    o_3_0_1           BFO_3_0_2       -1.0
    o_3_0_1           GAP_3_0_1       1.0
    o_3_0_2           OBJ           0.0
    o_3_0_2           OCC_3_0_2       1.0
    o_3_0_2           WDEF_3_0_2      -1.0
    o_3_0_2           AFO_3_0_1       -1.0
    o_3_0_2           BFO_3_0_3       -1.0
    o_3_0_2           GAP_3_0_2       1.0
    o_3_0_3           OBJ           0.0
    o_3_0_3           OCC_3_0_3       1.0
    o_3_0_3           WDEF_3_0_3      -1.0
    o_3_0_3           AFO_3_0_2       -1.0
    o_3_0_3           BFO_3_0_4       -1.0
    o_3_0_3           GAP_3_0_3       1.0
    o_3_0_4           OBJ           0.0
    o_3_0_4           OCC_3_0_4       1.0
    o_3_0_4           WDEF_3_0_4      -1.0
    o_3_0_4           AFO_3_0_3       -1.0
    o_3_0_4           BFO_3_0_5       -1.0
    o_3_0_4           GAP_3_0_4       1.0
    o_3_0_5           OBJ           0.0
    o_3_0_5           OCC_3_0_5       1.0
    o_3_0_5           WDEF_3_0_5      -1.0
    o_3_0_5           AFO_3_0_4       -1.0
    o_3_0_5           GAP_3_0_5       1.0
    o_3_1_0           OBJ           0.0
    o_3_1_0           OCC_3_1_0       1.0
    o_3_1_0           WDEF_3_1_0      -1.0
    o_3_1_0           BFO_3_1_1       -1.0
    o_3_1_0           GAP_3_1_0       1.0
    o_3_1_1           OBJ           0.0
    o_3_1_1           OCC_3_1_1       1.0
    o_3_1_1           WDEF_3_1_1      -1.0
    o_3_1_1           AFO_3_1_0       -1.0
    o_3_1_1           BFO_3_1_2       -1.0
    o_3_1_1           GAP_3_1_1       1.0
    o_3_1_2           OBJ           0.0
    o_3_1_2           OCC_3_1_2       1.0
    o_3_1_2           WDEF_3_1_2      -1.0
    o_3_1_2           AFO_3_1_1       -1.0
    o_3_1_2           BFO_3_1_3       -1.0
    o_3_1_2           GAP_3_1_2       1.0
    o_3_1_3           OBJ           0.0
    o_3_1_3           OCC_3_1_3       1.0
    o_3_1_3           WDEF_3_1_3      -1.0
    o_3_1_3           AFO_3_1_2       -1.0
    o_3_1_3           BFO_3_1_4       -1.0
    o_3_1_3           GAP_3_1_3       1.0
    o_3_1_4           OBJ           0.0
    o_3_1_4           OCC_3_1_4       1.0
    o_3_1_4           WDEF_3_1_4      -1.0
    o_3_1_4           AFO_3_1_3       -1.0
    o_3_1_4           BFO_3_1_5       -1.0
    o_3_1_4           GAP_3_1_4       1.0
    o_3_1_5           OBJ           0.0
    o_3_1_5           OCC_3_1_5       1.0
    o_3_1_5           WDEF_3_1_5      -1.0
    o_3_1_5           AFO_3_1_4       -1.0
    o_3_1_5           GAP_3_1_5       1.0
    o_3_2_0           OBJ           0.0
    o_3_2_0           OCC_3_2_0       1.0
    o_3_2_0           WDEF_3_2_0      -1.0
    o_3_2_0           BFO_3_2_1       -1.0
    o_3_2_0           GAP_3_2_0       1.0
    o_3_2_1           OBJ           0.0
    o_3_2_1           OCC_3_2_1       1.0
    o_3_2_1           WDEF_3_2_1      -1.0
    o_3_2_1           AFO_3_2_0       -1.0
    o_3_2_1           BFO_3_2_2       -1.0
    o_3_2_1           GAP_3_2_1       1.0
    o_3_2_2           OBJ           0.0
    o_3_2_2           OCC_3_2_2       1.0
    o_3_2_2           WDEF_3_2_2      -1.0
    o_3_2_2           AFO_3_2_1       -1.0
    o_3_2_2           BFO_3_2_3       -1.0
    o_3_2_2           GAP_3_2_2       1.0
    o_3_2_3           OBJ           0.0
    o_3_2_3           OCC_3_2_3       1.0
    o_3_2_3           WDEF_3_2_3      -1.0
    o_3_2_3           AFO_3_2_2       -1.0
    o_3_2_3           BFO_3_2_4       -1.0
    o_3_2_3           GAP_3_2_3       1.0
    o_3_2_4           OBJ           0.0
    o_3_2_4           OCC_3_2_4       1.0
    o_3_2_4           WDEF_3_2_4      -1.0
    o_3_2_4           AFO_3_2_3       -1.0
    o_3_2_4           BFO_3_2_5       -1.0
    o_3_2_4           GAP_3_2_4       1.0
    o_3_2_5           OBJ           0.0
    o_3_2_5           OCC_3_2_5       1.0
    o_3_2_5           WDEF_3_2_5      -1.0
    o_3_2_5           AFO_3_2_4       -1.0
    o_3_2_5           GAP_3_2_5       1.0
    o_3_3_0           OBJ           0.0
    o_3_3_0           OCC_3_3_0       1.0
    o_3_3_0           WDEF_3_3_0      -1.0
    o_3_3_0           BFO_3_3_1       -1.0
    o_3_3_0           GAP_3_3_0       1.0
    o_3_3_1           OBJ           0.0
    o_3_3_1           OCC_3_3_1       1.0
    o_3_3_1           WDEF_3_3_1      -1.0
    o_3_3_1           AFO_3_3_0       -1.0
    o_3_3_1           BFO_3_3_2       -1.0
    o_3_3_1           GAP_3_3_1       1.0
    o_3_3_2           OBJ           0.0
    o_3_3_2           OCC_3_3_2       1.0
    o_3_3_2           WDEF_3_3_2      -1.0
    o_3_3_2           AFO_3_3_1       -1.0
    o_3_3_2           BFO_3_3_3       -1.0
    o_3_3_2           GAP_3_3_2       1.0
    o_3_3_3           OBJ           0.0
    o_3_3_3           OCC_3_3_3       1.0
    o_3_3_3           WDEF_3_3_3      -1.0
    o_3_3_3           AFO_3_3_2       -1.0
    o_3_3_3           BFO_3_3_4       -1.0
    o_3_3_3           GAP_3_3_3       1.0
    o_3_3_4           OBJ           0.0
    o_3_3_4           OCC_3_3_4       1.0
    o_3_3_4           WDEF_3_3_4      -1.0
    o_3_3_4           AFO_3_3_3       -1.0
    o_3_3_4           BFO_3_3_5       -1.0
    o_3_3_4           GAP_3_3_4       1.0
    o_3_3_5           OBJ           0.0
    o_3_3_5           OCC_3_3_5       1.0
    o_3_3_5           WDEF_3_3_5      -1.0
    o_3_3_5           AFO_3_3_4       -1.0
    o_3_3_5           GAP_3_3_5       1.0
    o_3_4_0           OBJ           0.0
    o_3_4_0           OCC_3_4_0       1.0
    o_3_4_0           WDEF_3_4_0      -1.0
    o_3_4_0           BFO_3_4_1       -1.0
    o_3_4_0           GAP_3_4_0       1.0
    o_3_4_1           OBJ           0.0
    o_3_4_1           OCC_3_4_1       1.0
    o_3_4_1           WDEF_3_4_1      -1.0
    o_3_4_1           AFO_3_4_0       -1.0
    o_3_4_1           BFO_3_4_2       -1.0
    o_3_4_1           GAP_3_4_1       1.0
    o_3_4_2           OBJ           0.0
    o_3_4_2           OCC_3_4_2       1.0
    o_3_4_2           WDEF_3_4_2      -1.0
    o_3_4_2           AFO_3_4_1       -1.0
    o_3_4_2           BFO_3_4_3       -1.0
    o_3_4_2           GAP_3_4_2       1.0
    o_3_4_3           OBJ           0.0
    o_3_4_3           OCC_3_4_3       1.0
    o_3_4_3           WDEF_3_4_3      -1.0
    o_3_4_3           AFO_3_4_2       -1.0
    o_3_4_3           BFO_3_4_4       -1.0
    o_3_4_3           GAP_3_4_3       1.0
    o_3_4_4           OBJ           0.0
    o_3_4_4           OCC_3_4_4       1.0
    o_3_4_4           WDEF_3_4_4      -1.0
    o_3_4_4           AFO_3_4_3       -1.0
    o_3_4_4           BFO_3_4_5       -1.0
    o_3_4_4           GAP_3_4_4       1.0
    o_3_4_5           OBJ           0.0
    o_3_4_5           OCC_3_4_5       1.0
    o_3_4_5           WDEF_3_4_5      -1.0
    o_3_4_5           AFO_3_4_4       -1.0
    o_3_4_5           GAP_3_4_5       1.0
    o_4_0_0           OBJ           0.0
    o_4_0_0           OCC_4_0_0       1.0
    o_4_0_0           WDEF_4_0_0      -1.0
    o_4_0_0           BFO_4_0_1       -1.0
    o_4_0_0           GAP_4_0_0       1.0
    o_4_0_1           OBJ           0.0
    o_4_0_1           OCC_4_0_1       1.0
    o_4_0_1           WDEF_4_0_1      -1.0
    o_4_0_1           AFO_4_0_0       -1.0
    o_4_0_1           BFO_4_0_2       -1.0
    o_4_0_1           GAP_4_0_1       1.0
    o_4_0_2           OBJ           0.0
    o_4_0_2           OCC_4_0_2       1.0
    o_4_0_2           WDEF_4_0_2      -1.0
    o_4_0_2           AFO_4_0_1       -1.0
    o_4_0_2           BFO_4_0_3       -1.0
    o_4_0_2           GAP_4_0_2       1.0
    o_4_0_3           OBJ           0.0
    o_4_0_3           OCC_4_0_3       1.0
    o_4_0_3           WDEF_4_0_3      -1.0
    o_4_0_3           AFO_4_0_2       -1.0
    o_4_0_3           BFO_4_0_4       -1.0
    o_4_0_3           GAP_4_0_3       1.0
    o_4_0_4           OBJ           0.0
    o_4_0_4           OCC_4_0_4       1.0
    o_4_0_4           WDEF_4_0_4      -1.0
    o_4_0_4           AFO_4_0_3       -1.0
    o_4_0_4           BFO_4_0_5       -1.0
    o_4_0_4           GAP_4_0_4       1.0
    o_4_0_5           OBJ           0.0
    o_4_0_5           OCC_4_0_5       1.0
    o_4_0_5           WDEF_4_0_5      -1.0
    o_4_0_5           AFO_4_0_4       -1.0
    o_4_0_5           GAP_4_0_5       1.0
    o_4_1_0           OBJ           0.0
    o_4_1_0           OCC_4_1_0       1.0
    o_4_1_0           WDEF_4_1_0      -1.0
    o_4_1_0           BFO_4_1_1       -1.0
    o_4_1_0           GAP_4_1_0       1.0
    o_4_1_1           OBJ           0.0
    o_4_1_1           OCC_4_1_1       1.0
    o_4_1_1           WDEF_4_1_1      -1.0
    o_4_1_1           AFO_4_1_0       -1.0
    o_4_1_1           BFO_4_1_2       -1.0
    o_4_1_1           GAP_4_1_1       1.0
    o_4_1_2           OBJ           0.0
    o_4_1_2           OCC_4_1_2       1.0
    o_4_1_2           WDEF_4_1_2      -1.0
    o_4_1_2           AFO_4_1_1       -1.0
    o_4_1_2           BFO_4_1_3       -1.0
    o_4_1_2           GAP_4_1_2       1.0
    o_4_1_3           OBJ           0.0
    o_4_1_3           OCC_4_1_3       1.0
    o_4_1_3           WDEF_4_1_3      -1.0
    o_4_1_3           AFO_4_1_2       -1.0
    o_4_1_3           BFO_4_1_4       -1.0
    o_4_1_3           GAP_4_1_3       1.0
    o_4_1_4           OBJ           0.0
    o_4_1_4           OCC_4_1_4       1.0
    o_4_1_4           WDEF_4_1_4      -1.0
    o_4_1_4           AFO_4_1_3       -1.0
    o_4_1_4           BFO_4_1_5       -1.0
    o_4_1_4           GAP_4_1_4       1.0
    o_4_1_5           OBJ           0.0
    o_4_1_5           OCC_4_1_5       1.0
    o_4_1_5           WDEF_4_1_5      -1.0
    o_4_1_5           AFO_4_1_4       -1.0
    o_4_1_5           GAP_4_1_5       1.0
    o_4_2_0           OBJ           0.0
    o_4_2_0           OCC_4_2_0       1.0
    o_4_2_0           WDEF_4_2_0      -1.0
    o_4_2_0           BFO_4_2_1       -1.0
    o_4_2_0           GAP_4_2_0       1.0
    o_4_2_1           OBJ           0.0
    o_4_2_1           OCC_4_2_1       1.0
    o_4_2_1           WDEF_4_2_1      -1.0
    o_4_2_1           AFO_4_2_0       -1.0
    o_4_2_1           BFO_4_2_2       -1.0
    o_4_2_1           GAP_4_2_1       1.0
    o_4_2_2           OBJ           0.0
    o_4_2_2           OCC_4_2_2       1.0
    o_4_2_2           WDEF_4_2_2      -1.0
    o_4_2_2           AFO_4_2_1       -1.0
    o_4_2_2           BFO_4_2_3       -1.0
    o_4_2_2           GAP_4_2_2       1.0
    o_4_2_3           OBJ           0.0
    o_4_2_3           OCC_4_2_3       1.0
    o_4_2_3           WDEF_4_2_3      -1.0
    o_4_2_3           AFO_4_2_2       -1.0
    o_4_2_3           BFO_4_2_4       -1.0
    o_4_2_3           GAP_4_2_3       1.0
    o_4_2_4           OBJ           0.0
    o_4_2_4           OCC_4_2_4       1.0
    o_4_2_4           WDEF_4_2_4      -1.0
    o_4_2_4           AFO_4_2_3       -1.0
    o_4_2_4           BFO_4_2_5       -1.0
    o_4_2_4           GAP_4_2_4       1.0
    o_4_2_5           OBJ           0.0
    o_4_2_5           OCC_4_2_5       1.0
    o_4_2_5           WDEF_4_2_5      -1.0
    o_4_2_5           AFO_4_2_4       -1.0
    o_4_2_5           GAP_4_2_5       1.0
    o_4_3_0           OBJ           0.0
    o_4_3_0           OCC_4_3_0       1.0
    o_4_3_0           WDEF_4_3_0      -1.0
    o_4_3_0           BFO_4_3_1       -1.0
    o_4_3_0           GAP_4_3_0       1.0
    o_4_3_1           OBJ           0.0
    o_4_3_1           OCC_4_3_1       1.0
    o_4_3_1           WDEF_4_3_1      -1.0
    o_4_3_1           AFO_4_3_0       -1.0
    o_4_3_1           BFO_4_3_2       -1.0
    o_4_3_1           GAP_4_3_1       1.0
    o_4_3_2           OBJ           0.0
    o_4_3_2           OCC_4_3_2       1.0
    o_4_3_2           WDEF_4_3_2      -1.0
    o_4_3_2           AFO_4_3_1       -1.0
    o_4_3_2           BFO_4_3_3       -1.0
    o_4_3_2           GAP_4_3_2       1.0
    o_4_3_3           OBJ           0.0
    o_4_3_3           OCC_4_3_3       1.0
    o_4_3_3           WDEF_4_3_3      -1.0
    o_4_3_3           AFO_4_3_2       -1.0
    o_4_3_3           BFO_4_3_4       -1.0
    o_4_3_3           GAP_4_3_3       1.0
    o_4_3_4           OBJ           0.0
    o_4_3_4           OCC_4_3_4       1.0
    o_4_3_4           WDEF_4_3_4      -1.0
    o_4_3_4           AFO_4_3_3       -1.0
    o_4_3_4           BFO_4_3_5       -1.0
    o_4_3_4           GAP_4_3_4       1.0
    o_4_3_5           OBJ           0.0
    o_4_3_5           OCC_4_3_5       1.0
    o_4_3_5           WDEF_4_3_5      -1.0
    o_4_3_5           AFO_4_3_4       -1.0
    o_4_3_5           GAP_4_3_5       1.0
    o_4_4_0           OBJ           0.0
    o_4_4_0           OCC_4_4_0       1.0
    o_4_4_0           WDEF_4_4_0      -1.0
    o_4_4_0           BFO_4_4_1       -1.0
    o_4_4_0           GAP_4_4_0       1.0
    o_4_4_1           OBJ           0.0
    o_4_4_1           OCC_4_4_1       1.0
    o_4_4_1           WDEF_4_4_1      -1.0
    o_4_4_1           AFO_4_4_0       -1.0
    o_4_4_1           BFO_4_4_2       -1.0
    o_4_4_1           GAP_4_4_1       1.0
    o_4_4_2           OBJ           0.0
    o_4_4_2           OCC_4_4_2       1.0
    o_4_4_2           WDEF_4_4_2      -1.0
    o_4_4_2           AFO_4_4_1       -1.0
    o_4_4_2           BFO_4_4_3       -1.0
    o_4_4_2           GAP_4_4_2       1.0
    o_4_4_3           OBJ           0.0
    o_4_4_3           OCC_4_4_3       1.0
    o_4_4_3           WDEF_4_4_3      -1.0
    o_4_4_3           AFO_4_4_2       -1.0
    o_4_4_3           BFO_4_4_4       -1.0
    o_4_4_3           GAP_4_4_3       1.0
    o_4_4_4           OBJ           0.0
    o_4_4_4           OCC_4_4_4       1.0
    o_4_4_4           WDEF_4_4_4      -1.0
    o_4_4_4           AFO_4_4_3       -1.0
    o_4_4_4           BFO_4_4_5       -1.0
    o_4_4_4           GAP_4_4_4       1.0
    o_4_4_5           OBJ           0.0
    o_4_4_5           OCC_4_4_5       1.0
    o_4_4_5           WDEF_4_4_5      -1.0
    o_4_4_5           AFO_4_4_4       -1.0
    o_4_4_5           GAP_4_4_5       1.0
    o_5_0_0           OBJ           0.0
    o_5_0_0           OCC_5_0_0       1.0
    o_5_0_0           WDEF_5_0_0      -1.0
    o_5_0_0           BFO_5_0_1       -1.0
    o_5_0_0           GAP_5_0_0       1.0
    o_5_0_1           OBJ           0.0
    o_5_0_1           OCC_5_0_1       1.0
    o_5_0_1           WDEF_5_0_1      -1.0
    o_5_0_1           AFO_5_0_0       -1.0
    o_5_0_1           BFO_5_0_2       -1.0
    o_5_0_1           GAP_5_0_1       1.0
    o_5_0_2           OBJ           0.0
    o_5_0_2           OCC_5_0_2       1.0
    o_5_0_2           WDEF_5_0_2      -1.0
    o_5_0_2           AFO_5_0_1       -1.0
    o_5_0_2           BFO_5_0_3       -1.0
    o_5_0_2           GAP_5_0_2       1.0
    o_5_0_3           OBJ           0.0
    o_5_0_3           OCC_5_0_3       1.0
    o_5_0_3           WDEF_5_0_3      -1.0
    o_5_0_3           AFO_5_0_2       -1.0
    o_5_0_3           BFO_5_0_4       -1.0
    o_5_0_3           GAP_5_0_3       1.0
    o_5_0_4           OBJ           0.0
    o_5_0_4           OCC_5_0_4       1.0
    o_5_0_4           WDEF_5_0_4      -1.0
    o_5_0_4           AFO_5_0_3       -1.0
    o_5_0_4           BFO_5_0_5       -1.0
    o_5_0_4           GAP_5_0_4       1.0
    o_5_0_5           OBJ           0.0
    o_5_0_5           OCC_5_0_5       1.0
    o_5_0_5           WDEF_5_0_5      -1.0
    o_5_0_5           AFO_5_0_4       -1.0
    o_5_0_5           GAP_5_0_5       1.0
    o_5_1_0           OBJ           0.0
    o_5_1_0           OCC_5_1_0       1.0
    o_5_1_0           WDEF_5_1_0      -1.0
    o_5_1_0           BFO_5_1_1       -1.0
    o_5_1_0           GAP_5_1_0       1.0
    o_5_1_1           OBJ           0.0
    o_5_1_1           OCC_5_1_1       1.0
    o_5_1_1           WDEF_5_1_1      -1.0
    o_5_1_1           AFO_5_1_0       -1.0
    o_5_1_1           BFO_5_1_2       -1.0
    o_5_1_1           GAP_5_1_1       1.0
    o_5_1_2           OBJ           0.0
    o_5_1_2           OCC_5_1_2       1.0
    o_5_1_2           WDEF_5_1_2      -1.0
    o_5_1_2           AFO_5_1_1       -1.0
    o_5_1_2           BFO_5_1_3       -1.0
    o_5_1_2           GAP_5_1_2       1.0
    o_5_1_3           OBJ           0.0
    o_5_1_3           OCC_5_1_3       1.0
    o_5_1_3           WDEF_5_1_3      -1.0
    o_5_1_3           AFO_5_1_2       -1.0
    o_5_1_3           BFO_5_1_4       -1.0
    o_5_1_3           GAP_5_1_3       1.0
    o_5_1_4           OBJ           0.0
    o_5_1_4           OCC_5_1_4       1.0
    o_5_1_4           WDEF_5_1_4      -1.0
    o_5_1_4           AFO_5_1_3       -1.0
    o_5_1_4           BFO_5_1_5       -1.0
    o_5_1_4           GAP_5_1_4       1.0
    o_5_1_5           OBJ           0.0
    o_5_1_5           OCC_5_1_5       1.0
    o_5_1_5           WDEF_5_1_5      -1.0
    o_5_1_5           AFO_5_1_4       -1.0
    o_5_1_5           GAP_5_1_5       1.0
    o_5_2_0           OBJ           0.0
    o_5_2_0           OCC_5_2_0       1.0
    o_5_2_0           WDEF_5_2_0      -1.0
    o_5_2_0           BFO_5_2_1       -1.0
    o_5_2_0           GAP_5_2_0       1.0
    o_5_2_1           OBJ           0.0
    o_5_2_1           OCC_5_2_1       1.0
    o_5_2_1           WDEF_5_2_1      -1.0
    o_5_2_1           AFO_5_2_0       -1.0
    o_5_2_1           BFO_5_2_2       -1.0
    o_5_2_1           GAP_5_2_1       1.0
    o_5_2_2           OBJ           0.0
    o_5_2_2           OCC_5_2_2       1.0
    o_5_2_2           WDEF_5_2_2      -1.0
    o_5_2_2           AFO_5_2_1       -1.0
    o_5_2_2           BFO_5_2_3       -1.0
    o_5_2_2           GAP_5_2_2       1.0
    o_5_2_3           OBJ           0.0
    o_5_2_3           OCC_5_2_3       1.0
    o_5_2_3           WDEF_5_2_3      -1.0
    o_5_2_3           AFO_5_2_2       -1.0
    o_5_2_3           BFO_5_2_4       -1.0
    o_5_2_3           GAP_5_2_3       1.0
    o_5_2_4           OBJ           0.0
    o_5_2_4           OCC_5_2_4       1.0
    o_5_2_4           WDEF_5_2_4      -1.0
    o_5_2_4           AFO_5_2_3       -1.0
    o_5_2_4           BFO_5_2_5       -1.0
    o_5_2_4           GAP_5_2_4       1.0
    o_5_2_5           OBJ           0.0
    o_5_2_5           OCC_5_2_5       1.0
    o_5_2_5           WDEF_5_2_5      -1.0
    o_5_2_5           AFO_5_2_4       -1.0
    o_5_2_5           GAP_5_2_5       1.0
    o_5_3_0           OBJ           0.0
    o_5_3_0           OCC_5_3_0       1.0
    o_5_3_0           WDEF_5_3_0      -1.0
    o_5_3_0           BFO_5_3_1       -1.0
    o_5_3_0           GAP_5_3_0       1.0
    o_5_3_1           OBJ           0.0
    o_5_3_1           OCC_5_3_1       1.0
    o_5_3_1           WDEF_5_3_1      -1.0
    o_5_3_1           AFO_5_3_0       -1.0
    o_5_3_1           BFO_5_3_2       -1.0
    o_5_3_1           GAP_5_3_1       1.0
    o_5_3_2           OBJ           0.0
    o_5_3_2           OCC_5_3_2       1.0
    o_5_3_2           WDEF_5_3_2      -1.0
    o_5_3_2           AFO_5_3_1       -1.0
    o_5_3_2           BFO_5_3_3       -1.0
    o_5_3_2           GAP_5_3_2       1.0
    o_5_3_3           OBJ           0.0
    o_5_3_3           OCC_5_3_3       1.0
    o_5_3_3           WDEF_5_3_3      -1.0
    o_5_3_3           AFO_5_3_2       -1.0
    o_5_3_3           BFO_5_3_4       -1.0
    o_5_3_3           GAP_5_3_3       1.0
    o_5_3_4           OBJ           0.0
    o_5_3_4           OCC_5_3_4       1.0
    o_5_3_4           WDEF_5_3_4      -1.0
    o_5_3_4           AFO_5_3_3       -1.0
    o_5_3_4           BFO_5_3_5       -1.0
    o_5_3_4           GAP_5_3_4       1.0
    o_5_3_5           OBJ           0.0
    o_5_3_5           OCC_5_3_5       1.0
    o_5_3_5           WDEF_5_3_5      -1.0
    o_5_3_5           AFO_5_3_4       -1.0
    o_5_3_5           GAP_5_3_5       1.0
    o_5_4_0           OBJ           0.0
    o_5_4_0           OCC_5_4_0       1.0
    o_5_4_0           WDEF_5_4_0      -1.0
    o_5_4_0           BFO_5_4_1       -1.0
    o_5_4_0           GAP_5_4_0       1.0
    o_5_4_1           OBJ           0.0
    o_5_4_1           OCC_5_4_1       1.0
    o_5_4_1           WDEF_5_4_1      -1.0
    o_5_4_1           AFO_5_4_0       -1.0
    o_5_4_1           BFO_5_4_2       -1.0
    o_5_4_1           GAP_5_4_1       1.0
    o_5_4_2           OBJ           0.0
    o_5_4_2           OCC_5_4_2       1.0
    o_5_4_2           WDEF_5_4_2      -1.0
    o_5_4_2           AFO_5_4_1       -1.0
    o_5_4_2           BFO_5_4_3       -1.0
    o_5_4_2           GAP_5_4_2       1.0
    o_5_4_3           OBJ           0.0
    o_5_4_3           OCC_5_4_3       1.0
    o_5_4_3           WDEF_5_4_3      -1.0
    o_5_4_3           AFO_5_4_2       -1.0
    o_5_4_3           BFO_5_4_4       -1.0
    o_5_4_3           GAP_5_4_3       1.0
    o_5_4_4           OBJ           0.0
    o_5_4_4           OCC_5_4_4       1.0
    o_5_4_4           WDEF_5_4_4      -1.0
    o_5_4_4           AFO_5_4_3       -1.0
    o_5_4_4           BFO_5_4_5       -1.0
    o_5_4_4           GAP_5_4_4       1.0
    o_5_4_5           OBJ           0.0
    o_5_4_5           OCC_5_4_5       1.0
    o_5_4_5           WDEF_5_4_5      -1.0
    o_5_4_5           AFO_5_4_4       -1.0
    o_5_4_5           GAP_5_4_5       1.0
    o_6_0_0           OBJ           0.0
    o_6_0_0           OCC_6_0_0       1.0
    o_6_0_0           WDEF_6_0_0      -1.0
    o_6_0_0           BFO_6_0_1       -1.0
    o_6_0_0           GAP_6_0_0       1.0
    o_6_0_1           OBJ           0.0
    o_6_0_1           OCC_6_0_1       1.0
    o_6_0_1           WDEF_6_0_1      -1.0
    o_6_0_1           AFO_6_0_0       -1.0
    o_6_0_1           BFO_6_0_2       -1.0
    o_6_0_1           GAP_6_0_1       1.0
    o_6_0_2           OBJ           0.0
    o_6_0_2           OCC_6_0_2       1.0
    o_6_0_2           WDEF_6_0_2      -1.0
    o_6_0_2           AFO_6_0_1       -1.0
    o_6_0_2           BFO_6_0_3       -1.0
    o_6_0_2           GAP_6_0_2       1.0
    o_6_0_3           OBJ           0.0
    o_6_0_3           OCC_6_0_3       1.0
    o_6_0_3           WDEF_6_0_3      -1.0
    o_6_0_3           AFO_6_0_2       -1.0
    o_6_0_3           BFO_6_0_4       -1.0
    o_6_0_3           GAP_6_0_3       1.0
    o_6_0_4           OBJ           0.0
    o_6_0_4           OCC_6_0_4       1.0
    o_6_0_4           WDEF_6_0_4      -1.0
    o_6_0_4           AFO_6_0_3       -1.0
    o_6_0_4           BFO_6_0_5       -1.0
    o_6_0_4           GAP_6_0_4       1.0
    o_6_0_5           OBJ           0.0
    o_6_0_5           OCC_6_0_5       1.0
    o_6_0_5           WDEF_6_0_5      -1.0
    o_6_0_5           AFO_6_0_4       -1.0
    o_6_0_5           GAP_6_0_5       1.0
    o_6_1_0           OBJ           0.0
    o_6_1_0           OCC_6_1_0       1.0
    o_6_1_0           WDEF_6_1_0      -1.0
    o_6_1_0           BFO_6_1_1       -1.0
    o_6_1_0           GAP_6_1_0       1.0
    o_6_1_1           OBJ           0.0
    o_6_1_1           OCC_6_1_1       1.0
    o_6_1_1           WDEF_6_1_1      -1.0
    o_6_1_1           AFO_6_1_0       -1.0
    o_6_1_1           BFO_6_1_2       -1.0
    o_6_1_1           GAP_6_1_1       1.0
    o_6_1_2           OBJ           0.0
    o_6_1_2           OCC_6_1_2       1.0
    o_6_1_2           WDEF_6_1_2      -1.0
    o_6_1_2           AFO_6_1_1       -1.0
    o_6_1_2           BFO_6_1_3       -1.0
    o_6_1_2           GAP_6_1_2       1.0
    o_6_1_3           OBJ           0.0
    o_6_1_3           OCC_6_1_3       1.0
    o_6_1_3           WDEF_6_1_3      -1.0
    o_6_1_3           AFO_6_1_2       -1.0
    o_6_1_3           BFO_6_1_4       -1.0
    o_6_1_3           GAP_6_1_3       1.0
    o_6_1_4           OBJ           0.0
    o_6_1_4           OCC_6_1_4       1.0
    o_6_1_4           WDEF_6_1_4      -1.0
    o_6_1_4           AFO_6_1_3       -1.0
    o_6_1_4           BFO_6_1_5       -1.0
    o_6_1_4           GAP_6_1_4       1.0
    o_6_1_5           OBJ           0.0
    o_6_1_5           OCC_6_1_5       1.0
    o_6_1_5           WDEF_6_1_5      -1.0
    o_6_1_5           AFO_6_1_4       -1.0
    o_6_1_5           GAP_6_1_5       1.0
    o_6_2_0           OBJ           0.0
    o_6_2_0           OCC_6_2_0       1.0
    o_6_2_0           WDEF_6_2_0      -1.0
    o_6_2_0           BFO_6_2_1       -1.0
    o_6_2_0           GAP_6_2_0       1.0
    o_6_2_1           OBJ           0.0
    o_6_2_1           OCC_6_2_1       1.0
    o_6_2_1           WDEF_6_2_1      -1.0
    o_6_2_1           AFO_6_2_0       -1.0
    o_6_2_1           BFO_6_2_2       -1.0
    o_6_2_1           GAP_6_2_1       1.0
    o_6_2_2           OBJ           0.0
    o_6_2_2           OCC_6_2_2       1.0
    o_6_2_2           WDEF_6_2_2      -1.0
    o_6_2_2           AFO_6_2_1       -1.0
    o_6_2_2           BFO_6_2_3       -1.0
    o_6_2_2           GAP_6_2_2       1.0
    o_6_2_3           OBJ           0.0
    o_6_2_3           OCC_6_2_3       1.0
    o_6_2_3           WDEF_6_2_3      -1.0
    o_6_2_3           AFO_6_2_2       -1.0
    o_6_2_3           BFO_6_2_4       -1.0
    o_6_2_3           GAP_6_2_3       1.0
    o_6_2_4           OBJ           0.0
    o_6_2_4           OCC_6_2_4       1.0
    o_6_2_4           WDEF_6_2_4      -1.0
    o_6_2_4           AFO_6_2_3       -1.0
    o_6_2_4           BFO_6_2_5       -1.0
    o_6_2_4           GAP_6_2_4       1.0
    o_6_2_5           OBJ           0.0
    o_6_2_5           OCC_6_2_5       1.0
    o_6_2_5           WDEF_6_2_5      -1.0
    o_6_2_5           AFO_6_2_4       -1.0
    o_6_2_5           GAP_6_2_5       1.0
    o_6_3_0           OBJ           0.0
    o_6_3_0           OCC_6_3_0       1.0
    o_6_3_0           WDEF_6_3_0      -1.0
    o_6_3_0           BFO_6_3_1       -1.0
    o_6_3_0           GAP_6_3_0       1.0
    o_6_3_1           OBJ           0.0
    o_6_3_1           OCC_6_3_1       1.0
    o_6_3_1           WDEF_6_3_1      -1.0
    o_6_3_1           AFO_6_3_0       -1.0
    o_6_3_1           BFO_6_3_2       -1.0
    o_6_3_1           GAP_6_3_1       1.0
    o_6_3_2           OBJ           0.0
    o_6_3_2           OCC_6_3_2       1.0
    o_6_3_2           WDEF_6_3_2      -1.0
    o_6_3_2           AFO_6_3_1       -1.0
    o_6_3_2           BFO_6_3_3       -1.0
    o_6_3_2           GAP_6_3_2       1.0
    o_6_3_3           OBJ           0.0
    o_6_3_3           OCC_6_3_3       1.0
    o_6_3_3           WDEF_6_3_3      -1.0
    o_6_3_3           AFO_6_3_2       -1.0
    o_6_3_3           BFO_6_3_4       -1.0
    o_6_3_3           GAP_6_3_3       1.0
    o_6_3_4           OBJ           0.0
    o_6_3_4           OCC_6_3_4       1.0
    o_6_3_4           WDEF_6_3_4      -1.0
    o_6_3_4           AFO_6_3_3       -1.0
    o_6_3_4           BFO_6_3_5       -1.0
    o_6_3_4           GAP_6_3_4       1.0
    o_6_3_5           OBJ           0.0
    o_6_3_5           OCC_6_3_5       1.0
    o_6_3_5           WDEF_6_3_5      -1.0
    o_6_3_5           AFO_6_3_4       -1.0
    o_6_3_5           GAP_6_3_5       1.0
    o_6_4_0           OBJ           0.0
    o_6_4_0           OCC_6_4_0       1.0
    o_6_4_0           WDEF_6_4_0      -1.0
    o_6_4_0           BFO_6_4_1       -1.0
    o_6_4_0           GAP_6_4_0       1.0
    o_6_4_1           OBJ           0.0
    o_6_4_1           OCC_6_4_1       1.0
    o_6_4_1           WDEF_6_4_1      -1.0
    o_6_4_1           AFO_6_4_0       -1.0
    o_6_4_1           BFO_6_4_2       -1.0
    o_6_4_1           GAP_6_4_1       1.0
    o_6_4_2           OBJ           0.0
    o_6_4_2           OCC_6_4_2       1.0
    o_6_4_2           WDEF_6_4_2      -1.0
    o_6_4_2           AFO_6_4_1       -1.0
    o_6_4_2           BFO_6_4_3       -1.0
    o_6_4_2           GAP_6_4_2       1.0
    o_6_4_3           OBJ           0.0
    o_6_4_3           OCC_6_4_3       1.0
    o_6_4_3           WDEF_6_4_3      -1.0
    o_6_4_3           AFO_6_4_2       -1.0
    o_6_4_3           BFO_6_4_4       -1.0
    o_6_4_3           GAP_6_4_3       1.0
    o_6_4_4           OBJ           0.0
    o_6_4_4           OCC_6_4_4       1.0
    o_6_4_4           WDEF_6_4_4      -1.0
    o_6_4_4           AFO_6_4_3       -1.0
    o_6_4_4           BFO_6_4_5       -1.0
    o_6_4_4           GAP_6_4_4       1.0
    o_6_4_5           OBJ           0.0
    o_6_4_5           OCC_6_4_5       1.0
    o_6_4_5           WDEF_6_4_5      -1.0
    o_6_4_5           AFO_6_4_4       -1.0
    o_6_4_5           GAP_6_4_5       1.0
    o_7_0_0           OBJ           0.0
    o_7_0_0           OCC_7_0_0       1.0
    o_7_0_0           WDEF_7_0_0      -1.0
    o_7_0_0           BFO_7_0_1       -1.0
    o_7_0_0           GAP_7_0_0       1.0
    o_7_0_1           OBJ           0.0
    o_7_0_1           OCC_7_0_1       1.0
    o_7_0_1           WDEF_7_0_1      -1.0
    o_7_0_1           AFO_7_0_0       -1.0
    o_7_0_1           BFO_7_0_2       -1.0
    o_7_0_1           GAP_7_0_1       1.0
    o_7_0_2           OBJ           0.0
    o_7_0_2           OCC_7_0_2       1.0
    o_7_0_2           WDEF_7_0_2      -1.0
    o_7_0_2           AFO_7_0_1       -1.0
    o_7_0_2           BFO_7_0_3       -1.0
    o_7_0_2           GAP_7_0_2       1.0
    o_7_0_3           OBJ           0.0
    o_7_0_3           OCC_7_0_3       1.0
    o_7_0_3           WDEF_7_0_3      -1.0
    o_7_0_3           AFO_7_0_2       -1.0
    o_7_0_3           BFO_7_0_4       -1.0
    o_7_0_3           GAP_7_0_3       1.0
    o_7_0_4           OBJ           0.0
    o_7_0_4           OCC_7_0_4       1.0
    o_7_0_4           WDEF_7_0_4      -1.0
    o_7_0_4           AFO_7_0_3       -1.0
    o_7_0_4           BFO_7_0_5       -1.0
    o_7_0_4           GAP_7_0_4       1.0
    o_7_0_5           OBJ           0.0
    o_7_0_5           OCC_7_0_5       1.0
    o_7_0_5           WDEF_7_0_5      -1.0
    o_7_0_5           AFO_7_0_4       -1.0
    o_7_0_5           GAP_7_0_5       1.0
    o_7_1_0           OBJ           0.0
    o_7_1_0           OCC_7_1_0       1.0
    o_7_1_0           WDEF_7_1_0      -1.0
    o_7_1_0           BFO_7_1_1       -1.0
    o_7_1_0           GAP_7_1_0       1.0
    o_7_1_1           OBJ           0.0
    o_7_1_1           OCC_7_1_1       1.0
    o_7_1_1           WDEF_7_1_1      -1.0
    o_7_1_1           AFO_7_1_0       -1.0
    o_7_1_1           BFO_7_1_2       -1.0
    o_7_1_1           GAP_7_1_1       1.0
    o_7_1_2           OBJ           0.0
    o_7_1_2           OCC_7_1_2       1.0
    o_7_1_2           WDEF_7_1_2      -1.0
    o_7_1_2           AFO_7_1_1       -1.0
    o_7_1_2           BFO_7_1_3       -1.0
    o_7_1_2           GAP_7_1_2       1.0
    o_7_1_3           OBJ           0.0
    o_7_1_3           OCC_7_1_3       1.0
    o_7_1_3           WDEF_7_1_3      -1.0
    o_7_1_3           AFO_7_1_2       -1.0
    o_7_1_3           BFO_7_1_4       -1.0
    o_7_1_3           GAP_7_1_3       1.0
    o_7_1_4           OBJ           0.0
    o_7_1_4           OCC_7_1_4       1.0
    o_7_1_4           WDEF_7_1_4      -1.0
    o_7_1_4           AFO_7_1_3       -1.0
    o_7_1_4           BFO_7_1_5       -1.0
    o_7_1_4           GAP_7_1_4       1.0
    o_7_1_5           OBJ           0.0
    o_7_1_5           OCC_7_1_5       1.0
    o_7_1_5           WDEF_7_1_5      -1.0
    o_7_1_5           AFO_7_1_4       -1.0
    o_7_1_5           GAP_7_1_5       1.0
    o_7_2_0           OBJ           0.0
    o_7_2_0           OCC_7_2_0       1.0
    o_7_2_0           WDEF_7_2_0      -1.0
    o_7_2_0           BFO_7_2_1       -1.0
    o_7_2_0           GAP_7_2_0       1.0
    o_7_2_1           OBJ           0.0
    o_7_2_1           OCC_7_2_1       1.0
    o_7_2_1           WDEF_7_2_1      -1.0
    o_7_2_1           AFO_7_2_0       -1.0
    o_7_2_1           BFO_7_2_2       -1.0
    o_7_2_1           GAP_7_2_1       1.0
    o_7_2_2           OBJ           0.0
    o_7_2_2           OCC_7_2_2       1.0
    o_7_2_2           WDEF_7_2_2      -1.0
    o_7_2_2           AFO_7_2_1       -1.0
    o_7_2_2           BFO_7_2_3       -1.0
    o_7_2_2           GAP_7_2_2       1.0
    o_7_2_3           OBJ           0.0
    o_7_2_3           OCC_7_2_3       1.0
    o_7_2_3           WDEF_7_2_3      -1.0
    o_7_2_3           AFO_7_2_2       -1.0
    o_7_2_3           BFO_7_2_4       -1.0
    o_7_2_3           GAP_7_2_3       1.0
    o_7_2_4           OBJ           0.0
    o_7_2_4           OCC_7_2_4       1.0
    o_7_2_4           WDEF_7_2_4      -1.0
    o_7_2_4           AFO_7_2_3       -1.0
    o_7_2_4           BFO_7_2_5       -1.0
    o_7_2_4           GAP_7_2_4       1.0
    o_7_2_5           OBJ           0.0
    o_7_2_5           OCC_7_2_5       1.0
    o_7_2_5           WDEF_7_2_5      -1.0
    o_7_2_5           AFO_7_2_4       -1.0
    o_7_2_5           GAP_7_2_5       1.0
    o_7_3_0           OBJ           0.0
    o_7_3_0           OCC_7_3_0       1.0
    o_7_3_0           WDEF_7_3_0      -1.0
    o_7_3_0           BFO_7_3_1       -1.0
    o_7_3_0           GAP_7_3_0       1.0
    o_7_3_1           OBJ           0.0
    o_7_3_1           OCC_7_3_1       1.0
    o_7_3_1           WDEF_7_3_1      -1.0
    o_7_3_1           AFO_7_3_0       -1.0
    o_7_3_1           BFO_7_3_2       -1.0
    o_7_3_1           GAP_7_3_1       1.0
    o_7_3_2           OBJ           0.0
    o_7_3_2           OCC_7_3_2       1.0
    o_7_3_2           WDEF_7_3_2      -1.0
    o_7_3_2           AFO_7_3_1       -1.0
    o_7_3_2           BFO_7_3_3       -1.0
    o_7_3_2           GAP_7_3_2       1.0
    o_7_3_3           OBJ           0.0
    o_7_3_3           OCC_7_3_3       1.0
    o_7_3_3           WDEF_7_3_3      -1.0
    o_7_3_3           AFO_7_3_2       -1.0
    o_7_3_3           BFO_7_3_4       -1.0
    o_7_3_3           GAP_7_3_3       1.0
    o_7_3_4           OBJ           0.0
    o_7_3_4           OCC_7_3_4       1.0
    o_7_3_4           WDEF_7_3_4      -1.0
    o_7_3_4           AFO_7_3_3       -1.0
    o_7_3_4           BFO_7_3_5       -1.0
    o_7_3_4           GAP_7_3_4       1.0
    o_7_3_5           OBJ           0.0
    o_7_3_5           OCC_7_3_5       1.0
    o_7_3_5           WDEF_7_3_5      -1.0
    o_7_3_5           AFO_7_3_4       -1.0
    o_7_3_5           GAP_7_3_5       1.0
    o_7_4_0           OBJ           0.0
    o_7_4_0           OCC_7_4_0       1.0
    o_7_4_0           WDEF_7_4_0      -1.0
    o_7_4_0           BFO_7_4_1       -1.0
    o_7_4_0           GAP_7_4_0       1.0
    o_7_4_1           OBJ           0.0
    o_7_4_1           OCC_7_4_1       1.0
    o_7_4_1           WDEF_7_4_1      -1.0
    o_7_4_1           AFO_7_4_0       -1.0
    o_7_4_1           BFO_7_4_2       -1.0
    o_7_4_1           GAP_7_4_1       1.0
    o_7_4_2           OBJ           0.0
    o_7_4_2           OCC_7_4_2       1.0
    o_7_4_2           WDEF_7_4_2      -1.0
    o_7_4_2           AFO_7_4_1       -1.0
    o_7_4_2           BFO_7_4_3       -1.0
    o_7_4_2           GAP_7_4_2       1.0
    o_7_4_3           OBJ           0.0
    o_7_4_3           OCC_7_4_3       1.0
    o_7_4_3           WDEF_7_4_3      -1.0
    o_7_4_3           AFO_7_4_2       -1.0
    o_7_4_3           BFO_7_4_4       -1.0
    o_7_4_3           GAP_7_4_3       1.0
    o_7_4_4           OBJ           0.0
    o_7_4_4           OCC_7_4_4       1.0
    o_7_4_4           WDEF_7_4_4      -1.0
    o_7_4_4           AFO_7_4_3       -1.0
    o_7_4_4           BFO_7_4_5       -1.0
    o_7_4_4           GAP_7_4_4       1.0
    o_7_4_5           OBJ           0.0
    o_7_4_5           OCC_7_4_5       1.0
    o_7_4_5           WDEF_7_4_5      -1.0
    o_7_4_5           AFO_7_4_4       -1.0
    o_7_4_5           GAP_7_4_5       1.0
    e_0_0_0           OBJ           0.0
    e_0_0_0           CLS_0_0_0       1.0
    e_0_0_1           OBJ           0.0
    e_0_0_1           CLS_0_0_1       1.0
    e_0_0_2           OBJ           0.0
    e_0_0_2           CLS_0_0_2       1.0
    e_0_0_3           OBJ           0.0
    e_0_0_3           CLS_0_0_3       1.0
    e_0_0_4           OBJ           0.0
    e_0_0_4           CLS_0_0_4       1.0
    e_0_0_5           OBJ           0.0
    e_0_0_5           CLS_0_0_5       1.0
    e_0_1_0           OBJ           0.0
    e_0_1_0           CLS_0_1_0       1.0
    e_0_1_1           OBJ           0.0
    e_0_1_1           CLS_0_1_1       1.0
    e_0_1_2           OBJ           0.0
    e_0_1_2           CLS_0_1_2       1.0
    e_0_1_3           OBJ           0.0
    e_0_1_3           CLS_0_1_3       1.0
    e_0_1_4           OBJ           0.0
    e_0_1_4           CLS_0_1_4       1.0
    e_0_1_5           OBJ           0.0
    e_0_1_5           CLS_0_1_5       1.0
    e_0_2_0           OBJ           0.0
    e_0_2_0           CLS_0_2_0       1.0
    e_0_2_1           OBJ           0.0
    e_0_2_1           CLS_0_2_1       1.0
    e_0_2_2           OBJ           0.0
    e_0_2_2           CLS_0_2_2       1.0
    e_0_2_3           OBJ           0.0
    e_0_2_3           CLS_0_2_3       1.0
    e_0_2_4           OBJ           0.0
    e_0_2_4           CLS_0_2_4       1.0
    e_0_2_5           OBJ           0.0
    e_0_2_5           CLS_0_2_5       1.0
    e_0_3_0           OBJ           0.0
    e_0_3_0           CLS_0_3_0       1.0
    e_0_3_1           OBJ           0.0
    e_0_3_1           CLS_0_3_1       1.0
    e_0_3_2           OBJ           0.0
    e_0_3_2           CLS_0_3_2       1.0
    e_0_3_3           OBJ           0.0
    e_0_3_3           CLS_0_3_3       1.0
    e_0_3_4           OBJ           0.0
    e_0_3_4           CLS_0_3_4       1.0
    e_0_3_5           OBJ           0.0
    e_0_3_5           CLS_0_3_5       1.0
    e_0_4_0           OBJ           0.0
    e_0_4_0           CLS_0_4_0       1.0
    e_0_4_1           OBJ           0.0
    e_0_4_1           CLS_0_4_1       1.0
    e_0_4_2           OBJ           0.0
    e_0_4_2           CLS_0_4_2       1.0
    e_0_4_3           OBJ           0.0
    e_0_4_3           CLS_0_4_3       1.0
    e_0_4_4           OBJ           0.0
    e_0_4_4           CLS_0_4_4       1.0
    e_0_4_5           OBJ           0.0
    e_0_4_5           CLS_0_4_5       1.0
    e_1_0_0           OBJ           0.0
    e_1_0_0           CLS_1_0_0       1.0
    e_1_0_1           OBJ           0.0
    e_1_0_1           CLS_1_0_1       1.0
    e_1_0_2           OBJ           0.0
    e_1_0_2           CLS_1_0_2       1.0
    e_1_0_3           OBJ           0.0
    e_1_0_3           CLS_1_0_3       1.0
    e_1_0_4           OBJ           0.0
    e_1_0_4           CLS_1_0_4       1.0
    e_1_0_5           OBJ           0.0
    e_1_0_5           CLS_1_0_5       1.0
    e_1_1_0           OBJ           0.0
    e_1_1_0           CLS_1_1_0       1.0
    e_1_1_1           OBJ           0.0
    e_1_1_1           CLS_1_1_1       1.0
    e_1_1_2           OBJ           0.0
    e_1_1_2           CLS_1_1_2       1.0
    e_1_1_3           OBJ           0.0
    e_1_1_3           CLS_1_1_3       1.0
    e_1_1_4           OBJ           0.0
    e_1_1_4           CLS_1_1_4       1.0
    e_1_1_5           OBJ           0.0
    e_1_1_5           CLS_1_1_5       1.0
    e_1_2_0           OBJ           0.0
    e_1_2_0           CLS_1_2_0       1.0
    e_1_2_1           OBJ           0.0
    e_1_2_1           CLS_1_2_1       1.0
    e_1_2_2           OBJ           0.0
    e_1_2_2           CLS_1_2_2       1.0
    e_1_2_3           OBJ           0.0
    e_1_2_3           CLS_1_2_3       1.0
    e_1_2_4           OBJ           0.0
    e_1_2_4           CLS_1_2_4       1.0
    e_1_2_5           OBJ           0.0
    e_1_2_5           CLS_1_2_5       1.0
    e_1_3_0           OBJ           0.0
    e_1_3_0           CLS_1_3_0       1.0
    e_1_3_1           OBJ           0.0
    e_1_3_1           CLS_1_3_1       1.0
    e_1_3_2           OBJ           0.0
    e_1_3_2           CLS_1_3_2       1.0
    e_1_3_3           OBJ           0.0
    e_1_3_3           CLS_1_3_3       1.0
    e_1_3_4           OBJ           0.0
    e_1_3_4           CLS_1_3_4       1.0
    e_1_3_5           OBJ           0.0
    e_1_3_5           CLS_1_3_5       1.0
    e_1_4_0           OBJ           0.0
    e_1_4_0           CLS_1_4_0       1.0
    e_1_4_1           OBJ           0.0
    e_1_4_1           CLS_1_4_1       1.0
    e_1_4_2           OBJ           0.0
    e_1_4_2           CLS_1_4_2       1.0
    e_1_4_3           OBJ           0.0
    e_1_4_3           CLS_1_4_3       1.0
    e_1_4_4           OBJ           0.0
    e_1_4_4           CLS_1_4_4       1.0
    e_1_4_5           OBJ           0.0
    e_1_4_5           CLS_1_4_5       1.0
    e_2_0_0           OBJ           0.0
    e_2_0_0           CLS_2_0_0       1.0
    e_2_0_1           OBJ           0.0
    e_2_0_1           CLS_2_0_1       1.0
    e_2_0_2           OBJ           0.0
    e_2_0_2           CLS_2_0_2       1.0
    e_2_0_3           OBJ           0.0
    e_2_0_3           CLS_2_0_3       1.0
    e_2_0_4           OBJ           0.0
    e_2_0_4           CLS_2_0_4       1.0
    e_2_0_5           OBJ           0.0
    e_2_0_5           CLS_2_0_5       1.0
    e_2_1_0           OBJ           0.0
    e_2_1_0           CLS_2_1_0       1.0
    e_2_1_1           OBJ           0.0
    e_2_1_1           CLS_2_1_1       1.0
    e_2_1_2           OBJ           0.0
    e_2_1_2           CLS_2_1_2       1.0
    e_2_1_3           OBJ           0.0
    e_2_1_3           CLS_2_1_3       1.0
    e_2_1_4           OBJ           0.0
    e_2_1_4           CLS_2_1_4       1.0
    e_2_1_5           OBJ           0.0
    e_2_1_5           CLS_2_1_5       1.0
    e_2_2_0           OBJ           0.0
    e_2_2_0           CLS_2_2_0       1.0
    e_2_2_1           OBJ           0.0
    e_2_2_1           CLS_2_2_1       1.0
    e_2_2_2           OBJ           0.0
    e_2_2_2           CLS_2_2_2       1.0
    e_2_2_3           OBJ           0.0
    e_2_2_3           CLS_2_2_3       1.0
    e_2_2_4           OBJ           0.0
    e_2_2_4           CLS_2_2_4       1.0
    e_2_2_5           OBJ           0.0
    e_2_2_5           CLS_2_2_5       1.0
    e_2_3_0           OBJ           0.0
    e_2_3_0           CLS_2_3_0       1.0
    e_2_3_1           OBJ           0.0
    e_2_3_1           CLS_2_3_1       1.0
    e_2_3_2           OBJ           0.0
    e_2_3_2           CLS_2_3_2       1.0
    e_2_3_3           OBJ           0.0
    e_2_3_3           CLS_2_3_3       1.0
    e_2_3_4           OBJ           0.0
    e_2_3_4           CLS_2_3_4       1.0
    e_2_3_5           OBJ           0.0
    e_2_3_5           CLS_2_3_5       1.0
    e_2_4_0           OBJ           0.0
    e_2_4_0           CLS_2_4_0       1.0
    e_2_4_1           OBJ           0.0
    e_2_4_1           CLS_2_4_1       1.0
    e_2_4_2           OBJ           0.0
    e_2_4_2           CLS_2_4_2       1.0
    e_2_4_3           OBJ           0.0
    e_2_4_3           CLS_2_4_3       1.0
    e_2_4_4           OBJ           0.0
    e_2_4_4           CLS_2_4_4       1.0
    e_2_4_5           OBJ           0.0
    e_2_4_5           CLS_2_4_5       1.0
    e_3_0_0           OBJ           0.0
    e_3_0_0           CLS_3_0_0       1.0
    e_3_0_1           OBJ           0.0
    e_3_0_1           CLS_3_0_1       1.0
    e_3_0_2           OBJ           0.0
    e_3_0_2           CLS_3_0_2       1.0
    e_3_0_3           OBJ           0.0
    e_3_0_3           CLS_3_0_3       1.0
    e_3_0_4           OBJ           0.0
    e_3_0_4           CLS_3_0_4       1.0
    e_3_0_5           OBJ           0.0
    e_3_0_5           CLS_3_0_5       1.0
    e_3_1_0           OBJ           0.0
    e_3_1_0           CLS_3_1_0       1.0
    e_3_1_1           OBJ           0.0
    e_3_1_1           CLS_3_1_1       1.0
    e_3_1_2           OBJ           0.0
    e_3_1_2           CLS_3_1_2       1.0
    e_3_1_3           OBJ           0.0
    e_3_1_3           CLS_3_1_3       1.0
    e_3_1_4           OBJ           0.0
    e_3_1_4           CLS_3_1_4       1.0
    e_3_1_5           OBJ           0.0
    e_3_1_5           CLS_3_1_5       1.0
    e_3_2_0           OBJ           0.0
    e_3_2_0           CLS_3_2_0       1.0
    e_3_2_1           OBJ           0.0
    e_3_2_1           CLS_3_2_1       1.0
    e_3_2_2           OBJ           0.0
    e_3_2_2           CLS_3_2_2       1.0
    e_3_2_3           OBJ           0.0
    e_3_2_3           CLS_3_2_3       1.0
    e_3_2_4           OBJ           0.0
    e_3_2_4           CLS_3_2_4       1.0
    e_3_2_5           OBJ           0.0
    e_3_2_5           CLS_3_2_5       1.0
    e_3_3_0           OBJ           0.0
    e_3_3_0           CLS_3_3_0       1.0
    e_3_3_1           OBJ           0.0
    e_3_3_1           CLS_3_3_1       1.0
    e_3_3_2           OBJ           0.0
    e_3_3_2           CLS_3_3_2       1.0
    e_3_3_3           OBJ           0.0
    e_3_3_3           CLS_3_3_3       1.0
    e_3_3_4           OBJ           0.0
    e_3_3_4           CLS_3_3_4       1.0
    e_3_3_5           OBJ           0.0
    e_3_3_5           CLS_3_3_5       1.0
    e_3_4_0           OBJ           0.0
    e_3_4_0           CLS_3_4_0       1.0
    e_3_4_1           OBJ           0.0
    e_3_4_1           CLS_3_4_1       1.0
    e_3_4_2           OBJ           0.0
    e_3_4_2           CLS_3_4_2       1.0
    e_3_4_3           OBJ           0.0
    e_3_4_3           CLS_3_4_3       1.0
    e_3_4_4           OBJ           0.0
    e_3_4_4           CLS_3_4_4       1.0
    e_3_4_5           OBJ           0.0
    e_3_4_5           CLS_3_4_5       1.0
    e_4_0_0           OBJ           0.0
    e_4_0_0           CLS_4_0_0       1.0
    e_4_0_1           OBJ           0.0
    e_4_0_1           CLS_4_0_1       1.0
    e_4_0_2           OBJ           0.0
    e_4_0_2           CLS_4_0_2       1.0
    e_4_0_3           OBJ           0.0
    e_4_0_3           CLS_4_0_3       1.0
    e_4_0_4           OBJ           0.0
    e_4_0_4           CLS_4_0_4       1.0
    e_4_0_5           OBJ           0.0
    e_4_0_5           CLS_4_0_5       1.0
    e_4_1_0           OBJ           0.0
    e_4_1_0           CLS_4_1_0       1.0
    e_4_1_1           OBJ           0.0
    e_4_1_1           CLS_4_1_1       1.0
    e_4_1_2           OBJ           0.0
    e_4_1_2           CLS_4_1_2       1.0
    e_4_1_3           OBJ           0.0
    e_4_1_3           CLS_4_1_3       1.0
    e_4_1_4           OBJ           0.0
    e_4_1_4           CLS_4_1_4       1.0
    e_4_1_5           OBJ           0.0
    e_4_1_5           CLS_4_1_5       1.0
    e_4_2_0           OBJ           0.0
    e_4_2_0           CLS_4_2_0       1.0
    e_4_2_1           OBJ           0.0
    e_4_2_1           CLS_4_2_1       1.0
    e_4_2_2           OBJ           0.0
    e_4_2_2           CLS_4_2_2       1.0
    e_4_2_3           OBJ           0.0
    e_4_2_3           CLS_4_2_3       1.0
    e_4_2_4           OBJ           0.0
    e_4_2_4           CLS_4_2_4       1.0
    e_4_2_5           OBJ           0.0
    e_4_2_5           CLS_4_2_5       1.0
    e_4_3_0           OBJ           0.0
    e_4_3_0           CLS_4_3_0       1.0
    e_4_3_1           OBJ           0.0
    e_4_3_1           CLS_4_3_1       1.0
    e_4_3_2           OBJ           0.0
    e_4_3_2           CLS_4_3_2       1.0
    e_4_3_3           OBJ           0.0
    e_4_3_3           CLS_4_3_3       1.0
    e_4_3_4           OBJ           0.0
    e_4_3_4           CLS_4_3_4       1.0
    e_4_3_5           OBJ           0.0
    e_4_3_5           CLS_4_3_5       1.0
    e_4_4_0           OBJ           0.0
    e_4_4_0           CLS_4_4_0       1.0
    e_4_4_1           OBJ           0.0
    e_4_4_1           CLS_4_4_1       1.0
    e_4_4_2           OBJ           0.0
    e_4_4_2           CLS_4_4_2       1.0
    e_4_4_3           OBJ           0.0
    e_4_4_3           CLS_4_4_3       1.0
    e_4_4_4           OBJ           0.0
    e_4_4_4           CLS_4_4_4       1.0
    e_4_4_5           OBJ           0.0
    e_4_4_5           CLS_4_4_5       1.0
    e_5_0_0           OBJ           0.0
    e_5_0_0           CLS_5_0_0       1.0
    e_5_0_1           OBJ           0.0
    e_5_0_1           CLS_5_0_1       1.0
    e_5_0_2           OBJ           0.0
    e_5_0_2           CLS_5_0_2       1.0
    e_5_0_3           OBJ           0.0
    e_5_0_3           CLS_5_0_3       1.0
    e_5_0_4           OBJ           0.0
    e_5_0_4           CLS_5_0_4       1.0
    e_5_0_5           OBJ           0.0
    e_5_0_5           CLS_5_0_5       1.0
    e_5_1_0           OBJ           0.0
    e_5_1_0           CLS_5_1_0       1.0
    e_5_1_1           OBJ           0.0
    e_5_1_1           CLS_5_1_1       1.0
    e_5_1_2           OBJ           0.0
    e_5_1_2           CLS_5_1_2       1.0
    e_5_1_3           OBJ           0.0
    e_5_1_3           CLS_5_1_3       1.0
    e_5_1_4           OBJ           0.0
    e_5_1_4           CLS_5_1_4       1.0
    e_5_1_5           OBJ           0.0
    e_5_1_5           CLS_5_1_5       1.0
    e_5_2_0           OBJ           0.0
    e_5_2_0           CLS_5_2_0       1.0
    e_5_2_1           OBJ           0.0
    e_5_2_1           CLS_5_2_1       1.0
    e_5_2_2           OBJ           0.0
    e_5_2_2           CLS_5_2_2       1.0
    e_5_2_3           OBJ           0.0
    e_5_2_3           CLS_5_2_3       1.0
    e_5_2_4           OBJ           0.0
    e_5_2_4           CLS_5_2_4       1.0
    e_5_2_5           OBJ           0.0
    e_5_2_5           CLS_5_2_5       1.0
    e_5_3_0           OBJ           0.0
    e_5_3_0           CLS_5_3_0       1.0
    e_5_3_1           OBJ           0.0
    e_5_3_1           CLS_5_3_1       1.0
    e_5_3_2           OBJ           0.0
    e_5_3_2           CLS_5_3_2       1.0
    e_5_3_3           OBJ           0.0
    e_5_3_3           CLS_5_3_3       1.0
    e_5_3_4           OBJ           0.0
    e_5_3_4           CLS_5_3_4       1.0
    e_5_3_5           OBJ           0.0
    e_5_3_5           CLS_5_3_5       1.0
    e_5_4_0           OBJ           0.0
    e_5_4_0           CLS_5_4_0       1.0
    e_5_4_1           OBJ           0.0
    e_5_4_1           CLS_5_4_1       1.0
    e_5_4_2           OBJ           0.0
    e_5_4_2           CLS_5_4_2       1.0
    e_5_4_3           OBJ           0.0
    e_5_4_3           CLS_5_4_3       1.0
    e_5_4_4           OBJ           0.0
    e_5_4_4           CLS_5_4_4       1.0
    e_5_4_5           OBJ           0.0
    e_5_4_5           CLS_5_4_5       1.0
    bf_0_0_0          OBJ           0.0
    bf_0_0_0          BFCH_0_0_1      -1.0
    bf_0_0_0          GAP_0_0_0       -1.0
    af_0_0_0          OBJ           0.0
    af_0_0_0          AFCH_0_0_0      1.0
    af_0_0_0          AFO_0_0_0       1.0
    af_0_0_0          GAP_0_0_0       -1.0
    bf_0_0_1          OBJ           0.0
    bf_0_0_1          BFCH_0_0_1      1.0
    bf_0_0_1          BFO_0_0_1       1.0
    bf_0_0_1          BFCH_0_0_2      -1.0
    bf_0_0_1          GAP_0_0_1       -1.0
    af_0_0_1          OBJ           0.0
    af_0_0_1          AFCH_0_0_0      -1.0
    af_0_0_1          AFCH_0_0_1      1.0
    af_0_0_1          AFO_0_0_1       1.0
    af_0_0_1          GAP_0_0_1       -1.0
    bf_0_0_2          OBJ           0.0
    bf_0_0_2          BFCH_0_0_2      1.0
    bf_0_0_2          BFO_0_0_2       1.0
    bf_0_0_2          BFCH_0_0_3      -1.0
    bf_0_0_2          GAP_0_0_2       -1.0
    af_0_0_2          OBJ           0.0
    af_0_0_2          AFCH_0_0_1      -1.0
    af_0_0_2          AFCH_0_0_2      1.0
    af_0_0_2          AFO_0_0_2       1.0
    af_0_0_2          GAP_0_0_2       -1.0
    bf_0_0_3          OBJ           0.0
    bf_0_0_3          BFCH_0_0_3      1.0
    bf_0_0_3          BFO_0_0_3       1.0
    bf_0_0_3          BFCH_0_0_4      -1.0
    bf_0_0_3          GAP_0_0_3       -1.0
    af_0_0_3          OBJ           0.0
    af_0_0_3          AFCH_0_0_2      -1.0
    af_0_0_3          AFCH_0_0_3      1.0
    af_0_0_3          AFO_0_0_3       1.0
    af_0_0_3          GAP_0_0_3       -1.0
    bf_0_0_4          OBJ           0.0
    bf_0_0_4          BFCH_0_0_4      1.0
    bf_0_0_4          BFO_0_0_4       1.0
    bf_0_0_4          BFCH_0_0_5      -1.0
    bf_0_0_4          GAP_0_0_4       -1.0
    af_0_0_4          OBJ           0.0
    af_0_0_4          AFCH_0_0_3      -1.0
    af_0_0_4          AFCH_0_0_4      1.0
    af_0_0_4          AFO_0_0_4       1.0
    af_0_0_4          GAP_0_0_4       -1.0
    bf_0_0_5          OBJ           0.0
    bf_0_0_5          BFCH_0_0_5      1.0
    bf_0_0_5          BFO_0_0_5       1.0
    bf_0_0_5          GAP_0_0_5       -1.0
    af_0_0_5          OBJ           0.0
    af_0_0_5          AFCH_0_0_4      -1.0
    af_0_0_5          GAP_0_0_5       -1.0
    bf_0_1_0          OBJ           0.0
    bf_0_1_0          BFCH_0_1_1      -1.0
    bf_0_1_0          GAP_0_1_0       -1.0
    af_0_1_0          OBJ           0.0
    af_0_1_0          AFCH_0_1_0      1.0
    af_0_1_0          AFO_0_1_0       1.0
    af_0_1_0          GAP_0_1_0       -1.0
    bf_0_1_1          OBJ           0.0
    bf_0_1_1          BFCH_0_1_1      1.0
    bf_0_1_1          BFO_0_1_1       1.0
    bf_0_1_1          BFCH_0_1_2      -1.0
    bf_0_1_1          GAP_0_1_1       -1.0
    af_0_1_1          OBJ           0.0
    af_0_1_1          AFCH_0_1_0      -1.0
    af_0_1_1          AFCH_0_1_1      1.0
    af_0_1_1          AFO_0_1_1       1.0
    af_0_1_1          GAP_0_1_1       -1.0
    bf_0_1_2          OBJ           0.0
    bf_0_1_2          BFCH_0_1_2      1.0
    bf_0_1_2          BFO_0_1_2       1.0
    bf_0_1_2          BFCH_0_1_3      -1.0
    bf_0_1_2          GAP_0_1_2       -1.0
    af_0_1_2          OBJ           0.0
    af_0_1_2          AFCH_0_1_1      -1.0
    af_0_1_2          AFCH_0_1_2      1.0
    af_0_1_2          AFO_0_1_2       1.0
    af_0_1_2          GAP_0_1_2       -1.0
    bf_0_1_3          OBJ           0.0
    bf_0_1_3          BFCH_0_1_3      1.0
    bf_0_1_3          BFO_0_1_3       1.0
    bf_0_1_3          BFCH_0_1_4      -1.0
    bf_0_1_3          GAP_0_1_3       -1.0
    af_0_1_3          OBJ           0.0
    af_0_1_3          AFCH_0_1_2      -1.0
    af_0_1_3          AFCH_0_1_3      1.0
    af_0_1_3          AFO_0_1_3       1.0
    af_0_1_3          GAP_0_1_3       -1.0
    bf_0_1_4          OBJ           0.0
    bf_0_1_4          BFCH_0_1_4      1.0
    bf_0_1_4          BFO_0_1_4       1.0
    bf_0_1_4          BFCH_0_1_5      -1.0
    bf_0_1_4          GAP_0_1_4       -1.0
    af_0_1_4          OBJ           0.0
    af_0_1_4          AFCH_0_1_3      -1.0
    af_0_1_4          AFCH_0_1_4      1.0
    af_0_1_4          AFO_0_1_4       1.0
    af_0_1_4          GAP_0_1_4       -1.0
    bf_0_1_5          OBJ           0.0
    bf_0_1_5          BFCH_0_1_5      1.0
    bf_0_1_5          BFO_0_1_5       1.0
    bf_0_1_5          GAP_0_1_5       -1.0
    af_0_1_5          OBJ           0.0
    af_0_1_5          AFCH_0_1_4      -1.0
    af_0_1_5          GAP_0_1_5       -1.0
    bf_0_2_0          OBJ           0.0
    bf_0_2_0          BFCH_0_2_1      -1.0
    bf_0_2_0          GAP_0_2_0       -1.0
    af_0_2_0          OBJ           0.0
    af_0_2_0          AFCH_0_2_0      1.0
    af_0_2_0          AFO_0_2_0       1.0
    af_0_2_0          GAP_0_2_0       -1.0
    bf_0_2_1          OBJ           0.0
    bf_0_2_1          BFCH_0_2_1      1.0
    bf_0_2_1          BFO_0_2_1       1.0
    bf_0_2_1          BFCH_0_2_2      -1.0
    bf_0_2_1          GAP_0_2_1       -1.0
    af_0_2_1          OBJ           0.0
    af_0_2_1          AFCH_0_2_0      -1.0
    af_0_2_1          AFCH_0_2_1      1.0
    af_0_2_1          AFO_0_2_1       1.0
    af_0_2_1          GAP_0_2_1       -1.0
    bf_0_2_2          OBJ           0.0
    bf_0_2_2          BFCH_0_2_2      1.0
    bf_0_2_2          BFO_0_2_2       1.0
    bf_0_2_2          BFCH_0_2_3      -1.0
    bf_0_2_2          GAP_0_2_2       -1.0
    af_0_2_2          OBJ           0.0
    af_0_2_2          AFCH_0_2_1      -1.0
    af_0_2_2          AFCH_0_2_2      1.0
    af_0_2_2          AFO_0_2_2       1.0
    af_0_2_2          GAP_0_2_2       -1.0
    bf_0_2_3          OBJ           0.0
    bf_0_2_3          BFCH_0_2_3      1.0
    bf_0_2_3          BFO_0_2_3       1.0
    bf_0_2_3          BFCH_0_2_4      -1.0
    bf_0_2_3          GAP_0_2_3       -1.0
    af_0_2_3          OBJ           0.0
    af_0_2_3          AFCH_0_2_2      -1.0
    af_0_2_3          AFCH_0_2_3      1.0
    af_0_2_3          AFO_0_2_3       1.0
    af_0_2_3          GAP_0_2_3       -1.0
    bf_0_2_4          OBJ           0.0
    bf_0_2_4          BFCH_0_2_4      1.0
    bf_0_2_4          BFO_0_2_4       1.0
    bf_0_2_4          BFCH_0_2_5      -1.0
    bf_0_2_4          GAP_0_2_4       -1.0
    af_0_2_4          OBJ           0.0
    af_0_2_4          AFCH_0_2_3      -1.0
    af_0_2_4          AFCH_0_2_4      1.0
    af_0_2_4          AFO_0_2_4       1.0
    af_0_2_4          GAP_0_2_4       -1.0
    bf_0_2_5          OBJ           0.0
    bf_0_2_5          BFCH_0_2_5      1.0
    bf_0_2_5          BFO_0_2_5       1.0
    bf_0_2_5          GAP_0_2_5       -1.0
    af_0_2_5          OBJ           0.0
    af_0_2_5          AFCH_0_2_4      -1.0
    af_0_2_5          GAP_0_2_5       -1.0
    bf_0_3_0          OBJ           0.0
    bf_0_3_0          BFCH_0_3_1      -1.0
    bf_0_3_0          GAP_0_3_0       -1.0
    af_0_3_0          OBJ           0.0
    af_0_3_0          AFCH_0_3_0      1.0
    af_0_3_0          AFO_0_3_0       1.0
    af_0_3_0          GAP_0_3_0       -1.0
    bf_0_3_1          OBJ           0.0
    bf_0_3_1          BFCH_0_3_1      1.0
    bf_0_3_1          BFO_0_3_1       1.0
    bf_0_3_1          BFCH_0_3_2      -1.0
    bf_0_3_1          GAP_0_3_1       -1.0
    af_0_3_1          OBJ           0.0
    af_0_3_1          AFCH_0_3_0      -1.0
    af_0_3_1          AFCH_0_3_1      1.0
    af_0_3_1          AFO_0_3_1       1.0
    af_0_3_1          GAP_0_3_1       -1.0
    bf_0_3_2          OBJ           0.0
    bf_0_3_2          BFCH_0_3_2      1.0
    bf_0_3_2          BFO_0_3_2       1.0
    bf_0_3_2          BFCH_0_3_3      -1.0
    bf_0_3_2          GAP_0_3_2       -1.0
    af_0_3_2          OBJ           0.0
    af_0_3_2          AFCH_0_3_1      -1.0
    af_0_3_2          AFCH_0_3_2      1.0
    af_0_3_2          AFO_0_3_2       1.0
    af_0_3_2          GAP_0_3_2       -1.0
    bf_0_3_3          OBJ           0.0
    bf_0_3_3          BFCH_0_3_3      1.0
    bf_0_3_3          BFO_0_3_3       1.0
    bf_0_3_3          BFCH_0_3_4      -1.0
    bf_0_3_3          GAP_0_3_3       -1.0
    af_0_3_3          OBJ           0.0
    af_0_3_3          AFCH_0_3_2      -1.0
    af_0_3_3          AFCH_0_3_3      1.0
    af_0_3_3          AFO_0_3_3       1.0
    af_0_3_3          GAP_0_3_3       -1.0
    bf_0_3_4          OBJ           0.0
    bf_0_3_4          BFCH_0_3_4      1.0
    bf_0_3_4          BFO_0_3_4       1.0
    bf_0_3_4          BFCH_0_3_5      -1.0
    bf_0_3_4          GAP_0_3_4       -1.0
    af_0_3_4          OBJ           0.0
    af_0_3_4          AFCH_0_3_3      -1.0
    af_0_3_4          AFCH_0_3_4      1.0
    af_0_3_4          AFO_0_3_4       1.0
    af_0_3_4          GAP_0_3_4       -1.0
    bf_0_3_5          OBJ           0.0
    bf_0_3_5          BFCH_0_3_5      1.0
    bf_0_3_5          BFO_0_3_5       1.0
    bf_0_3_5          GAP_0_3_5       -1.0
    af_0_3_5          OBJ           0.0
    af_0_3_5          AFCH_0_3_4      -1.0
    af_0_3_5          GAP_0_3_5       -1.0
    bf_0_4_0          OBJ           0.0
    bf_0_4_0          BFCH_0_4_1      -1.0
    bf_0_4_0          GAP_0_4_0       -1.0
    af_0_4_0          OBJ           0.0
    af_0_4_0          AFCH_0_4_0      1.0
    af_0_4_0          AFO_0_4_0       1.0
    af_0_4_0          GAP_0_4_0       -1.0
    bf_0_4_1          OBJ           0.0
    bf_0_4_1          BFCH_0_4_1      1.0
    bf_0_4_1          BFO_0_4_1       1.0
    bf_0_4_1          BFCH_0_4_2      -1.0
    bf_0_4_1          GAP_0_4_1       -1.0
    af_0_4_1          OBJ           0.0
    af_0_4_1          AFCH_0_4_0      -1.0
    af_0_4_1          AFCH_0_4_1      1.0
    af_0_4_1          AFO_0_4_1       1.0
    af_0_4_1          GAP_0_4_1       -1.0
    bf_0_4_2          OBJ           0.0
    bf_0_4_2          BFCH_0_4_2      1.0
    bf_0_4_2          BFO_0_4_2       1.0
    bf_0_4_2          BFCH_0_4_3      -1.0
    bf_0_4_2          GAP_0_4_2       -1.0
    af_0_4_2          OBJ           0.0
    af_0_4_2          AFCH_0_4_1      -1.0
    af_0_4_2          AFCH_0_4_2      1.0
    af_0_4_2          AFO_0_4_2       1.0
    af_0_4_2          GAP_0_4_2       -1.0
    bf_0_4_3          OBJ           0.0
    bf_0_4_3          BFCH_0_4_3      1.0
    bf_0_4_3          BFO_0_4_3       1.0
    bf_0_4_3          BFCH_0_4_4      -1.0
    bf_0_4_3          GAP_0_4_3       -1.0
    af_0_4_3          OBJ           0.0
    af_0_4_3          AFCH_0_4_2      -1.0
    af_0_4_3          AFCH_0_4_3      1.0
    af_0_4_3          AFO_0_4_3       1.0
    af_0_4_3          GAP_0_4_3       -1.0
    bf_0_4_4          OBJ           0.0
    bf_0_4_4          BFCH_0_4_4      1.0
    bf_0_4_4          BFO_0_4_4       1.0
    bf_0_4_4          BFCH_0_4_5      -1.0
    bf_0_4_4          GAP_0_4_4       -1.0
    af_0_4_4          OBJ           0.0
    af_0_4_4          AFCH_0_4_3      -1.0
    af_0_4_4          AFCH_0_4_4      1.0
    af_0_4_4          AFO_0_4_4       1.0
    af_0_4_4          GAP_0_4_4       -1.0
    bf_0_4_5          OBJ           0.0
    bf_0_4_5          BFCH_0_4_5      1.0
    bf_0_4_5          BFO_0_4_5       1.0
    bf_0_4_5          GAP_0_4_5       -1.0
    af_0_4_5          OBJ           0.0
    af_0_4_5          AFCH_0_4_4      -1.0
    af_0_4_5          GAP_0_4_5       -1.0
    bf_1_0_0          OBJ           0.0
    bf_1_0_0          BFCH_1_0_1      -1.0
    bf_1_0_0          GAP_1_0_0       -1.0
    af_1_0_0          OBJ           0.0
    af_1_0_0          AFCH_1_0_0      1.0
    af_1_0_0          AFO_1_0_0       1.0
    af_1_0_0          GAP_1_0_0       -1.0
    bf_1_0_1          OBJ           0.0
    bf_1_0_1          BFCH_1_0_1      1.0
    bf_1_0_1          BFO_1_0_1       1.0
    bf_1_0_1          BFCH_1_0_2      -1.0
    bf_1_0_1          GAP_1_0_1       -1.0
    af_1_0_1          OBJ           0.0
    af_1_0_1          AFCH_1_0_0      -1.0
    af_1_0_1          AFCH_1_0_1      1.0
    af_1_0_1          AFO_1_0_1       1.0
    af_1_0_1          GAP_1_0_1       -1.0
    bf_1_0_2          OBJ           0.0
    bf_1_0_2          BFCH_1_0_2      1.0
    bf_1_0_2          BFO_1_0_2       1.0
    bf_1_0_2          BFCH_1_0_3      -1.0
    bf_1_0_2          GAP_1_0_2       -1.0
    af_1_0_2          OBJ           0.0
    af_1_0_2          AFCH_1_0_1      -1.0
    af_1_0_2          AFCH_1_0_2      1.0
    af_1_0_2          AFO_1_0_2       1.0
    af_1_0_2          GAP_1_0_2       -1.0
    bf_1_0_3          OBJ           0.0
    bf_1_0_3          BFCH_1_0_3      1.0
    bf_1_0_3          BFO_1_0_3       1.0
    bf_1_0_3          BFCH_1_0_4      -1.0
    bf_1_0_3          GAP_1_0_3       -1.0
    af_1_0_3          OBJ           0.0
    af_1_0_3          AFCH_1_0_2      -1.0
    af_1_0_3          AFCH_1_0_3      1.0
    af_1_0_3          AFO_1_0_3       1.0
    af_1_0_3          GAP_1_0_3       -1.0
    bf_1_0_4          OBJ           0.0
    bf_1_0_4          BFCH_1_0_4      1.0
    bf_1_0_4          BFO_1_0_4       1.0
    bf_1_0_4          BFCH_1_0_5      -1.0
    bf_1_0_4          GAP_1_0_4       -1.0
    af_1_0_4          OBJ           0.0
    af_1_0_4          AFCH_1_0_3      -1.0
    af_1_0_4          AFCH_1_0_4      1.0
    af_1_0_4          AFO_1_0_4       1.0
    af_1_0_4          GAP_1_0_4       -1.0
    bf_1_0_5          OBJ           0.0
    bf_1_0_5          BFCH_1_0_5      1.0
    bf_1_0_5          BFO_1_0_5       1.0
    bf_1_0_5          GAP_1_0_5       -1.0
    af_1_0_5          OBJ           0.0
    af_1_0_5          AFCH_1_0_4      -1.0
    af_1_0_5          GAP_1_0_5       -1.0
    bf_1_1_0          OBJ           0.0
    bf_1_1_0          BFCH_1_1_1      -1.0
    bf_1_1_0          GAP_1_1_0       -1.0
    af_1_1_0          OBJ           0.0
    af_1_1_0          AFCH_1_1_0      1.0
    af_1_1_0          AFO_1_1_0       1.0
    af_1_1_0          GAP_1_1_0       -1.0
    bf_1_1_1          OBJ           0.0
    bf_1_1_1          BFCH_1_1_1      1.0
    bf_1_1_1          BFO_1_1_1       1.0
    bf_1_1_1          BFCH_1_1_2      -1.0
    bf_1_1_1          GAP_1_1_1       -1.0
    af_1_1_1          OBJ           0.0
    af_1_1_1          AFCH_1_1_0      -1.0
    af_1_1_1          AFCH_1_1_1      1.0
    af_1_1_1          AFO_1_1_1       1.0
    af_1_1_1          GAP_1_1_1       -1.0
    bf_1_1_2          OBJ           0.0
    bf_1_1_2          BFCH_1_1_2      1.0
    bf_1_1_2          BFO_1_1_2       1.0
    bf_1_1_2          BFCH_1_1_3      -1.0
    bf_1_1_2          GAP_1_1_2       -1.0
    af_1_1_2          OBJ           0.0
    af_1_1_2          AFCH_1_1_1      -1.0
    af_1_1_2          AFCH_1_1_2      1.0
    af_1_1_2          AFO_1_1_2       1.0
    af_1_1_2          GAP_1_1_2       -1.0
    bf_1_1_3          OBJ           0.0
    bf_1_1_3          BFCH_1_1_3      1.0
    bf_1_1_3          BFO_1_1_3       1.0
    bf_1_1_3          BFCH_1_1_4      -1.0
    bf_1_1_3          GAP_1_1_3       -1.0
    af_1_1_3          OBJ           0.0
    af_1_1_3          AFCH_1_1_2      -1.0
    af_1_1_3          AFCH_1_1_3      1.0
    af_1_1_3          AFO_1_1_3       1.0
    af_1_1_3          GAP_1_1_3       -1.0
    bf_1_1_4          OBJ           0.0
    bf_1_1_4          BFCH_1_1_4      1.0
    bf_1_1_4          BFO_1_1_4       1.0
    bf_1_1_4          BFCH_1_1_5      -1.0
    bf_1_1_4          GAP_1_1_4       -1.0
    af_1_1_4          OBJ           0.0
    af_1_1_4          AFCH_1_1_3      -1.0
    af_1_1_4          AFCH_1_1_4      1.0
    af_1_1_4          AFO_1_1_4       1.0
    af_1_1_4          GAP_1_1_4       -1.0
    bf_1_1_5          OBJ           0.0
    bf_1_1_5          BFCH_1_1_5      1.0
    bf_1_1_5          BFO_1_1_5       1.0
    bf_1_1_5          GAP_1_1_5       -1.0
    af_1_1_5          OBJ           0.0
    af_1_1_5          AFCH_1_1_4      -1.0
    af_1_1_5          GAP_1_1_5       -1.0
    bf_1_2_0          OBJ           0.0
    bf_1_2_0          BFCH_1_2_1      -1.0
    bf_1_2_0          GAP_1_2_0       -1.0
    af_1_2_0          OBJ           0.0
    af_1_2_0          AFCH_1_2_0      1.0
    af_1_2_0          AFO_1_2_0       1.0
    af_1_2_0          GAP_1_2_0       -1.0
    bf_1_2_1          OBJ           0.0
    bf_1_2_1          BFCH_1_2_1      1.0
    bf_1_2_1          BFO_1_2_1       1.0
    bf_1_2_1          BFCH_1_2_2      -1.0
    bf_1_2_1          GAP_1_2_1       -1.0
    af_1_2_1          OBJ           0.0
    af_1_2_1          AFCH_1_2_0      -1.0
    af_1_2_1          AFCH_1_2_1      1.0
    af_1_2_1          AFO_1_2_1       1.0
    af_1_2_1          GAP_1_2_1       -1.0
    bf_1_2_2          OBJ           0.0
    bf_1_2_2          BFCH_1_2_2      1.0
    bf_1_2_2          BFO_1_2_2       1.0
    bf_1_2_2          BFCH_1_2_3      -1.0
    bf_1_2_2          GAP_1_2_2       -1.0
    af_1_2_2          OBJ           0.0
    af_1_2_2          AFCH_1_2_1      -1.0
    af_1_2_2          AFCH_1_2_2      1.0
    af_1_2_2          AFO_1_2_2       1.0
    af_1_2_2          GAP_1_2_2       -1.0
    bf_1_2_3          OBJ           0.0
    bf_1_2_3          BFCH_1_2_3      1.0
    bf_1_2_3          BFO_1_2_3       1.0
    bf_1_2_3          BFCH_1_2_4      -1.0
    bf_1_2_3          GAP_1_2_3       -1.0
    af_1_2_3          OBJ           0.0
    af_1_2_3          AFCH_1_2_2      -1.0
    af_1_2_3          AFCH_1_2_3      1.0
    af_1_2_3          AFO_1_2_3       1.0
    af_1_2_3          GAP_1_2_3       -1.0
    bf_1_2_4          OBJ           0.0
    bf_1_2_4          BFCH_1_2_4      1.0
    bf_1_2_4          BFO_1_2_4       1.0
    bf_1_2_4          BFCH_1_2_5      -1.0
    bf_1_2_4          GAP_1_2_4       -1.0
    af_1_2_4          OBJ           0.0
    af_1_2_4          AFCH_1_2_3      -1.0
    af_1_2_4          AFCH_1_2_4      1.0
    af_1_2_4          AFO_1_2_4       1.0
    af_1_2_4          GAP_1_2_4       -1.0
    bf_1_2_5          OBJ           0.0
    bf_1_2_5          BFCH_1_2_5      1.0
    bf_1_2_5          BFO_1_2_5       1.0
    bf_1_2_5          GAP_1_2_5       -1.0
    af_1_2_5          OBJ           0.0
    af_1_2_5          AFCH_1_2_4      -1.0
    af_1_2_5          GAP_1_2_5       -1.0
    bf_1_3_0          OBJ           0.0
    bf_1_3_0          BFCH_1_3_1      -1.0
    bf_1_3_0          GAP_1_3_0       -1.0
    af_1_3_0          OBJ           0.0
    af_1_3_0          AFCH_1_3_0      1.0
    af_1_3_0          AFO_1_3_0       1.0
    af_1_3_0          GAP_1_3_0       -1.0
    bf_1_3_1          OBJ           0.0
    bf_1_3_1          BFCH_1_3_1      1.0
    bf_1_3_1          BFO_1_3_1       1.0
    bf_1_3_1          BFCH_1_3_2      -1.0
    bf_1_3_1          GAP_1_3_1       -1.0
    af_1_3_1          OBJ           0.0
    af_1_3_1          AFCH_1_3_0      -1.0
    af_1_3_1          AFCH_1_3_1      1.0
    af_1_3_1          AFO_1_3_1       1.0
    af_1_3_1          GAP_1_3_1       -1.0
    bf_1_3_2          OBJ           0.0
    bf_1_3_2          BFCH_1_3_2      1.0
    bf_1_3_2          BFO_1_3_2       1.0
    bf_1_3_2          BFCH_1_3_3      -1.0
    bf_1_3_2          GAP_1_3_2       -1.0
    af_1_3_2          OBJ           0.0
    af_1_3_2          AFCH_1_3_1      -1.0
    af_1_3_2          AFCH_1_3_2      1.0
    af_1_3_2          AFO_1_3_2       1.0
    af_1_3_2          GAP_1_3_2       -1.0
    bf_1_3_3          OBJ           0.0
    bf_1_3_3          BFCH_1_3_3      1.0
    bf_1_3_3          BFO_1_3_3       1.0
    bf_1_3_3          BFCH_1_3_4      -1.0
    bf_1_3_3          GAP_1_3_3       -1.0
    af_1_3_3          OBJ           0.0
    af_1_3_3          AFCH_1_3_2      -1.0
    af_1_3_3          AFCH_1_3_3      1.0
    af_1_3_3          AFO_1_3_3       1.0
    af_1_3_3          GAP_1_3_3       -1.0
    bf_1_3_4          OBJ           0.0
    bf_1_3_4          BFCH_1_3_4      1.0
    bf_1_3_4          BFO_1_3_4       1.0
    bf_1_3_4          BFCH_1_3_5      -1.0
    bf_1_3_4          GAP_1_3_4       -1.0
    af_1_3_4          OBJ           0.0
    af_1_3_4          AFCH_1_3_3      -1.0
    af_1_3_4          AFCH_1_3_4      1.0
    af_1_3_4          AFO_1_3_4       1.0
    af_1_3_4          GAP_1_3_4       -1.0
    bf_1_3_5          OBJ           0.0
    bf_1_3_5          BFCH_1_3_5      1.0
    bf_1_3_5          BFO_1_3_5       1.0
    bf_1_3_5          GAP_1_3_5       -1.0
    af_1_3_5          OBJ           0.0
    af_1_3_5          AFCH_1_3_4      -1.0
    af_1_3_5          GAP_1_3_5       -1.0
    bf_1_4_0          OBJ           0.0
    bf_1_4_0          BFCH_1_4_1      -1.0
    bf_1_4_0          GAP_1_4_0       -1.0
    af_1_4_0          OBJ           0.0
    af_1_4_0          AFCH_1_4_0      1.0
    af_1_4_0          AFO_1_4_0       1.0
    af_1_4_0          GAP_1_4_0       -1.0
    bf_1_4_1          OBJ           0.0
    bf_1_4_1          BFCH_1_4_1      1.0
    bf_1_4_1          BFO_1_4_1       1.0
    bf_1_4_1          BFCH_1_4_2      -1.0
    bf_1_4_1          GAP_1_4_1       -1.0
    af_1_4_1          OBJ           0.0
    af_1_4_1          AFCH_1_4_0      -1.0
    af_1_4_1          AFCH_1_4_1      1.0
    af_1_4_1          AFO_1_4_1       1.0
    af_1_4_1          GAP_1_4_1       -1.0
    bf_1_4_2          OBJ           0.0
    bf_1_4_2          BFCH_1_4_2      1.0
    bf_1_4_2          BFO_1_4_2       1.0
    bf_1_4_2          BFCH_1_4_3      -1.0
    bf_1_4_2          GAP_1_4_2       -1.0
    af_1_4_2          OBJ           0.0
    af_1_4_2          AFCH_1_4_1      -1.0
    af_1_4_2          AFCH_1_4_2      1.0
    af_1_4_2          AFO_1_4_2       1.0
    af_1_4_2          GAP_1_4_2       -1.0
    bf_1_4_3          OBJ           0.0
    bf_1_4_3          BFCH_1_4_3      1.0
    bf_1_4_3          BFO_1_4_3       1.0
    bf_1_4_3          BFCH_1_4_4      -1.0
    bf_1_4_3          GAP_1_4_3       -1.0
    af_1_4_3          OBJ           0.0
    af_1_4_3          AFCH_1_4_2      -1.0
    af_1_4_3          AFCH_1_4_3      1.0
    af_1_4_3          AFO_1_4_3       1.0
    af_1_4_3          GAP_1_4_3       -1.0
    bf_1_4_4          OBJ           0.0
    bf_1_4_4          BFCH_1_4_4      1.0
    bf_1_4_4          BFO_1_4_4       1.0
    bf_1_4_4          BFCH_1_4_5      -1.0
    bf_1_4_4          GAP_1_4_4       -1.0
    af_1_4_4          OBJ           0.0
    af_1_4_4          AFCH_1_4_3      -1.0
    af_1_4_4          AFCH_1_4_4      1.0
    af_1_4_4          AFO_1_4_4       1.0
    af_1_4_4          GAP_1_4_4       -1.0
    bf_1_4_5          OBJ           0.0
    bf_1_4_5          BFCH_1_4_5      1.0
    bf_1_4_5          BFO_1_4_5       1.0
    bf_1_4_5          GAP_1_4_5       -1.0
    af_1_4_5          OBJ           0.0
    af_1_4_5          AFCH_1_4_4      -1.0
    af_1_4_5          GAP_1_4_5       -1.0
    bf_2_0_0          OBJ           0.0
    bf_2_0_0          BFCH_2_0_1      -1.0
    bf_2_0_0          GAP_2_0_0       -1.0
    af_2_0_0          OBJ           0.0
    af_2_0_0          AFCH_2_0_0      1.0
    af_2_0_0          AFO_2_0_0       1.0
    af_2_0_0          GAP_2_0_0       -1.0
    bf_2_0_1          OBJ           0.0
    bf_2_0_1          BFCH_2_0_1      1.0
    bf_2_0_1          BFO_2_0_1       1.0
    bf_2_0_1          BFCH_2_0_2      -1.0
    bf_2_0_1          GAP_2_0_1       -1.0
    af_2_0_1          OBJ           0.0
    af_2_0_1          AFCH_2_0_0      -1.0
    af_2_0_1          AFCH_2_0_1      1.0
    af_2_0_1          AFO_2_0_1       1.0
    af_2_0_1          GAP_2_0_1       -1.0
    bf_2_0_2          OBJ           0.0
    bf_2_0_2          BFCH_2_0_2      1.0
    bf_2_0_2          BFO_2_0_2       1.0
    bf_2_0_2          BFCH_2_0_3      -1.0
    bf_2_0_2          GAP_2_0_2       -1.0
    af_2_0_2          OBJ           0.0
    af_2_0_2          AFCH_2_0_1      -1.0
    af_2_0_2          AFCH_2_0_2      1.0
    af_2_0_2          AFO_2_0_2       1.0
    af_2_0_2          GAP_2_0_2       -1.0
    bf_2_0_3          OBJ           0.0
    bf_2_0_3          BFCH_2_0_3      1.0
    bf_2_0_3          BFO_2_0_3       1.0
    bf_2_0_3          BFCH_2_0_4      -1.0
    bf_2_0_3          GAP_2_0_3       -1.0
    af_2_0_3          OBJ           0.0
    af_2_0_3          AFCH_2_0_2      -1.0
    af_2_0_3          AFCH_2_0_3      1.0
    af_2_0_3          AFO_2_0_3       1.0
    af_2_0_3          GAP_2_0_3       -1.0
    bf_2_0_4          OBJ           0.0
    bf_2_0_4          BFCH_2_0_4      1.0
    bf_2_0_4          BFO_2_0_4       1.0
    bf_2_0_4          BFCH_2_0_5      -1.0
    bf_2_0_4          GAP_2_0_4       -1.0
    af_2_0_4          OBJ           0.0
    af_2_0_4          AFCH_2_0_3      -1.0
    af_2_0_4          AFCH_2_0_4      1.0
    af_2_0_4          AFO_2_0_4       1.0
    af_2_0_4          GAP_2_0_4       -1.0
    bf_2_0_5          OBJ           0.0
    bf_2_0_5          BFCH_2_0_5      1.0
    bf_2_0_5          BFO_2_0_5       1.0
    bf_2_0_5          GAP_2_0_5       -1.0
    af_2_0_5          OBJ           0.0
    af_2_0_5          AFCH_2_0_4      -1.0
    af_2_0_5          GAP_2_0_5       -1.0
    bf_2_1_0          OBJ           0.0
    bf_2_1_0          BFCH_2_1_1      -1.0
    bf_2_1_0          GAP_2_1_0       -1.0
    af_2_1_0          OBJ           0.0
    af_2_1_0          AFCH_2_1_0      1.0
    af_2_1_0          AFO_2_1_0       1.0
    af_2_1_0          GAP_2_1_0       -1.0
    bf_2_1_1          OBJ           0.0
    bf_2_1_1          BFCH_2_1_1      1.0
    bf_2_1_1          BFO_2_1_1       1.0
    bf_2_1_1          BFCH_2_1_2      -1.0
    bf_2_1_1          GAP_2_1_1       -1.0
    af_2_1_1          OBJ           0.0
    af_2_1_1          AFCH_2_1_0      -1.0
    af_2_1_1          AFCH_2_1_1      1.0
    af_2_1_1          AFO_2_1_1       1.0
    af_2_1_1          GAP_2_1_1       -1.0
    bf_2_1_2          OBJ           0.0
    bf_2_1_2          BFCH_2_1_2      1.0
    bf_2_1_2          BFO_2_1_2       1.0
    bf_2_1_2          BFCH_2_1_3      -1.0
    bf_2_1_2          GAP_2_1_2       -1.0
    af_2_1_2          OBJ           0.0
    af_2_1_2          AFCH_2_1_1      -1.0
    af_2_1_2          AFCH_2_1_2      1.0
    af_2_1_2          AFO_2_1_2       1.0
    af_2_1_2          GAP_2_1_2       -1.0
    bf_2_1_3          OBJ           0.0
    bf_2_1_3          BFCH_2_1_3      1.0
    bf_2_1_3          BFO_2_1_3       1.0
    bf_2_1_3          BFCH_2_1_4      -1.0
    bf_2_1_3          GAP_2_1_3       -1.0
    af_2_1_3          OBJ           0.0
    af_2_1_3          AFCH_2_1_2      -1.0
    af_2_1_3          AFCH_2_1_3      1.0
    af_2_1_3          AFO_2_1_3       1.0
    af_2_1_3          GAP_2_1_3       -1.0
    bf_2_1_4          OBJ           0.0
    bf_2_1_4          BFCH_2_1_4      1.0
    bf_2_1_4          BFO_2_1_4       1.0
    bf_2_1_4          BFCH_2_1_5      -1.0
    bf_2_1_4          GAP_2_1_4       -1.0
    af_2_1_4          OBJ           0.0
    af_2_1_4          AFCH_2_1_3      -1.0
    af_2_1_4          AFCH_2_1_4      1.0
    af_2_1_4          AFO_2_1_4       1.0
    af_2_1_4          GAP_2_1_4       -1.0
    bf_2_1_5          OBJ           0.0
    bf_2_1_5          BFCH_2_1_5      1.0
    bf_2_1_5          BFO_2_1_5       1.0
    bf_2_1_5          GAP_2_1_5       -1.0
    af_2_1_5          OBJ           0.0
    af_2_1_5          AFCH_2_1_4      -1.0
    af_2_1_5          GAP_2_1_5       -1.0
    bf_2_2_0          OBJ           0.0
    bf_2_2_0          BFCH_2_2_1      -1.0
    bf_2_2_0          GAP_2_2_0       -1.0
    af_2_2_0          OBJ           0.0
    af_2_2_0          AFCH_2_2_0      1.0
    af_2_2_0          AFO_2_2_0       1.0
    af_2_2_0          GAP_2_2_0       -1.0
    bf_2_2_1          OBJ           0.0
    bf_2_2_1          BFCH_2_2_1      1.0
    bf_2_2_1          BFO_2_2_1       1.0
    bf_2_2_1          BFCH_2_2_2      -1.0
    bf_2_2_1          GAP_2_2_1       -1.0
    af_2_2_1          OBJ           0.0
    af_2_2_1          AFCH_2_2_0      -1.0
    af_2_2_1          AFCH_2_2_1      1.0
    af_2_2_1          AFO_2_2_1       1.0
    af_2_2_1          GAP_2_2_1       -1.0
    bf_2_2_2          OBJ           0.0
    bf_2_2_2          BFCH_2_2_2      1.0
    bf_2_2_2          BFO_2_2_2       1.0
    bf_2_2_2          BFCH_2_2_3      -1.0
    bf_2_2_2          GAP_2_2_2       -1.0
    af_2_2_2          OBJ           0.0
    af_2_2_2          AFCH_2_2_1      -1.0
    af_2_2_2          AFCH_2_2_2      1.0
    af_2_2_2          AFO_2_2_2       1.0
    af_2_2_2          GAP_2_2_2       -1.0
    bf_2_2_3          OBJ           0.0
    bf_2_2_3          BFCH_2_2_3      1.0
    bf_2_2_3          BFO_2_2_3       1.0
    bf_2_2_3          BFCH_2_2_4      -1.0
    bf_2_2_3          GAP_2_2_3       -1.0
    af_2_2_3          OBJ           0.0
    af_2_2_3          AFCH_2_2_2      -1.0
    af_2_2_3          AFCH_2_2_3      1.0
    af_2_2_3          AFO_2_2_3       1.0
    af_2_2_3          GAP_2_2_3       -1.0
    bf_2_2_4          OBJ           0.0
    bf_2_2_4          BFCH_2_2_4      1.0
    bf_2_2_4          BFO_2_2_4       1.0
    bf_2_2_4          BFCH_2_2_5      -1.0
    bf_2_2_4          GAP_2_2_4       -1.0
    af_2_2_4          OBJ           0.0
    af_2_2_4          AFCH_2_2_3      -1.0
    af_2_2_4          AFCH_2_2_4      1.0
    af_2_2_4          AFO_2_2_4       1.0
    af_2_2_4          GAP_2_2_4       -1.0
    bf_2_2_5          OBJ           0.0
    bf_2_2_5          BFCH_2_2_5      1.0
    bf_2_2_5          BFO_2_2_5       1.0
    bf_2_2_5          GAP_2_2_5       -1.0
    af_2_2_5          OBJ           0.0
    af_2_2_5          AFCH_2_2_4      -1.0
    af_2_2_5          GAP_2_2_5       -1.0
    bf_2_3_0          OBJ           0.0
    bf_2_3_0          BFCH_2_3_1      -1.0
    bf_2_3_0          GAP_2_3_0       -1.0
    af_2_3_0          OBJ           0.0
    af_2_3_0          AFCH_2_3_0      1.0
    af_2_3_0          AFO_2_3_0       1.0
    af_2_3_0          GAP_2_3_0       -1.0
    bf_2_3_1          OBJ           0.0
    bf_2_3_1          BFCH_2_3_1      1.0
    bf_2_3_1          BFO_2_3_1       1.0
    bf_2_3_1          BFCH_2_3_2      -1.0
    bf_2_3_1          GAP_2_3_1       -1.0
    af_2_3_1          OBJ           0.0
    af_2_3_1          AFCH_2_3_0      -1.0
    af_2_3_1          AFCH_2_3_1      1.0
    af_2_3_1          AFO_2_3_1       1.0
    af_2_3_1          GAP_2_3_1       -1.0
    bf_2_3_2          OBJ           0.0
    bf_2_3_2          BFCH_2_3_2      1.0
    bf_2_3_2          BFO_2_3_2       1.0
    bf_2_3_2          BFCH_2_3_3      -1.0
    bf_2_3_2          GAP_2_3_2       -1.0
    af_2_3_2          OBJ           0.0
    af_2_3_2          AFCH_2_3_1      -1.0
    af_2_3_2          AFCH_2_3_2      1.0
    af_2_3_2          AFO_2_3_2       1.0
    af_2_3_2          GAP_2_3_2       -1.0
    bf_2_3_3          OBJ           0.0
    bf_2_3_3          BFCH_2_3_3      1.0
    bf_2_3_3          BFO_2_3_3       1.0
    bf_2_3_3          BFCH_2_3_4      -1.0
    bf_2_3_3          GAP_2_3_3       -1.0
    af_2_3_3          OBJ           0.0
    af_2_3_3          AFCH_2_3_2      -1.0
    af_2_3_3          AFCH_2_3_3      1.0
    af_2_3_3          AFO_2_3_3       1.0
    af_2_3_3          GAP_2_3_3       -1.0
    bf_2_3_4          OBJ           0.0
    bf_2_3_4          BFCH_2_3_4      1.0
    bf_2_3_4          BFO_2_3_4       1.0
    bf_2_3_4          BFCH_2_3_5      -1.0
    bf_2_3_4          GAP_2_3_4       -1.0
    af_2_3_4          OBJ           0.0
    af_2_3_4          AFCH_2_3_3      -1.0
    af_2_3_4          AFCH_2_3_4      1.0
    af_2_3_4          AFO_2_3_4       1.0
    af_2_3_4          GAP_2_3_4       -1.0
    bf_2_3_5          OBJ           0.0
    bf_2_3_5          BFCH_2_3_5      1.0
    bf_2_3_5          BFO_2_3_5       1.0
    bf_2_3_5          GAP_2_3_5       -1.0
    af_2_3_5          OBJ           0.0
    af_2_3_5          AFCH_2_3_4      -1.0
    af_2_3_5          GAP_2_3_5       -1.0
    bf_2_4_0          OBJ           0.0
    bf_2_4_0          BFCH_2_4_1      -1.0
    bf_2_4_0          GAP_2_4_0       -1.0
    af_2_4_0          OBJ           0.0
    af_2_4_0          AFCH_2_4_0      1.0
    af_2_4_0          AFO_2_4_0       1.0
    af_2_4_0          GAP_2_4_0       -1.0
    bf_2_4_1          OBJ           0.0
    bf_2_4_1          BFCH_2_4_1      1.0
    bf_2_4_1          BFO_2_4_1       1.0
    bf_2_4_1          BFCH_2_4_2      -1.0
    bf_2_4_1          GAP_2_4_1       -1.0
    af_2_4_1          OBJ           0.0
    af_2_4_1          AFCH_2_4_0      -1.0
    af_2_4_1          AFCH_2_4_1      1.0
    af_2_4_1          AFO_2_4_1       1.0
    af_2_4_1          GAP_2_4_1       -1.0
    bf_2_4_2          OBJ           0.0
    bf_2_4_2          BFCH_2_4_2      1.0
    bf_2_4_2          BFO_2_4_2       1.0
    bf_2_4_2          BFCH_2_4_3      -1.0
    bf_2_4_2          GAP_2_4_2       -1.0
    af_2_4_2          OBJ           0.0
    af_2_4_2          AFCH_2_4_1      -1.0
    af_2_4_2          AFCH_2_4_2      1.0
    af_2_4_2          AFO_2_4_2       1.0
    af_2_4_2          GAP_2_4_2       -1.0
    bf_2_4_3          OBJ           0.0
    bf_2_4_3          BFCH_2_4_3      1.0
    bf_2_4_3          BFO_2_4_3       1.0
    bf_2_4_3          BFCH_2_4_4      -1.0
    bf_2_4_3          GAP_2_4_3       -1.0
    af_2_4_3          OBJ           0.0
    af_2_4_3          AFCH_2_4_2      -1.0
    af_2_4_3          AFCH_2_4_3      1.0
    af_2_4_3          AFO_2_4_3       1.0
    af_2_4_3          GAP_2_4_3       -1.0
    bf_2_4_4          OBJ           0.0
    bf_2_4_4          BFCH_2_4_4      1.0
    bf_2_4_4          BFO_2_4_4       1.0
    bf_2_4_4          BFCH_2_4_5      -1.0
    bf_2_4_4          GAP_2_4_4       -1.0
    af_2_4_4          OBJ           0.0
    af_2_4_4          AFCH_2_4_3      -1.0
    af_2_4_4          AFCH_2_4_4      1.0
    af_2_4_4          AFO_2_4_4       1.0
    af_2_4_4          GAP_2_4_4       -1.0
    bf_2_4_5          OBJ           0.0
    bf_2_4_5          BFCH_2_4_5      1.0
    bf_2_4_5          BFO_2_4_5       1.0
    bf_2_4_5          GAP_2_4_5       -1.0
    af_2_4_5          OBJ           0.0
    af_2_4_5          AFCH_2_4_4      -1.0
    af_2_4_5          GAP_2_4_5       -1.0
    bf_3_0_0          OBJ           0.0
    bf_3_0_0          BFCH_3_0_1      -1.0
    bf_3_0_0          GAP_3_0_0       -1.0
    af_3_0_0          OBJ           0.0
    af_3_0_0          AFCH_3_0_0      1.0
    af_3_0_0          AFO_3_0_0       1.0
    af_3_0_0          GAP_3_0_0       -1.0
    bf_3_0_1          OBJ           0.0
    bf_3_0_1          BFCH_3_0_1      1.0
    bf_3_0_1          BFO_3_0_1       1.0
    bf_3_0_1          BFCH_3_0_2      -1.0
    bf_3_0_1          GAP_3_0_1       -1.0
    af_3_0_1          OBJ           0.0
    af_3_0_1          AFCH_3_0_0      -1.0
    af_3_0_1          AFCH_3_0_1      1.0
    af_3_0_1          AFO_3_0_1       1.0
    af_3_0_1          GAP_3_0_1       -1.0
    bf_3_0_2          OBJ           0.0
    bf_3_0_2          BFCH_3_0_2      1.0
    bf_3_0_2          BFO_3_0_2       1.0
    bf_3_0_2          BFCH_3_0_3      -1.0
    bf_3_0_2          GAP_3_0_2       -1.0
    af_3_0_2          OBJ           0.0
    af_3_0_2          AFCH_3_0_1      -1.0
    af_3_0_2          AFCH_3_0_2      1.0
    af_3_0_2          AFO_3_0_2       1.0
    af_3_0_2          GAP_3_0_2       -1.0
    bf_3_0_3          OBJ           0.0
    bf_3_0_3          BFCH_3_0_3      1.0
    bf_3_0_3          BFO_3_0_3       1.0
    bf_3_0_3          BFCH_3_0_4      -1.0
    bf_3_0_3          GAP_3_0_3       -1.0
    af_3_0_3          OBJ           0.0
    af_3_0_3          AFCH_3_0_2      -1.0
    af_3_0_3          AFCH_3_0_3      1.0
    af_3_0_3          AFO_3_0_3       1.0
    af_3_0_3          GAP_3_0_3       -1.0
    bf_3_0_4          OBJ           0.0
    bf_3_0_4          BFCH_3_0_4      1.0
    bf_3_0_4          BFO_3_0_4       1.0
    bf_3_0_4          BFCH_3_0_5      -1.0
    bf_3_0_4          GAP_3_0_4       -1.0
    af_3_0_4          OBJ           0.0
    af_3_0_4          AFCH_3_0_3      -1.0
    af_3_0_4          AFCH_3_0_4      1.0
    af_3_0_4          AFO_3_0_4       1.0
    af_3_0_4          GAP_3_0_4       -1.0
    bf_3_0_5          OBJ           0.0
    bf_3_0_5          BFCH_3_0_5      1.0
    bf_3_0_5          BFO_3_0_5       1.0
    bf_3_0_5          GAP_3_0_5       -1.0
    af_3_0_5          OBJ           0.0
    af_3_0_5          AFCH_3_0_4      -1.0
    af_3_0_5          GAP_3_0_5       -1.0
    bf_3_1_0          OBJ           0.0
    bf_3_1_0          BFCH_3_1_1      -1.0
    bf_3_1_0          GAP_3_1_0       -1.0
    af_3_1_0          OBJ           0.0
    af_3_1_0          AFCH_3_1_0      1.0
    af_3_1_0          AFO_3_1_0       1.0
    af_3_1_0          GAP_3_1_0       -1.0
    bf_3_1_1          OBJ           0.0
    bf_3_1_1          BFCH_3_1_1      1.0
    bf_3_1_1          BFO_3_1_1       1.0
    bf_3_1_1          BFCH_3_1_2      -1.0
    bf_3_1_1          GAP_3_1_1       -1.0
    af_3_1_1          OBJ           0.0
    af_3_1_1          AFCH_3_1_0      -1.0
    af_3_1_1          AFCH_3_1_1      1.0
    af_3_1_1          AFO_3_1_1       1.0
    af_3_1_1          GAP_3_1_1       -1.0
    bf_3_1_2          OBJ           0.0
    bf_3_1_2          BFCH_3_1_2      1.0
    bf_3_1_2          BFO_3_1_2       1.0
    bf_3_1_2          BFCH_3_1_3      -1.0
    bf_3_1_2          GAP_3_1_2       -1.0
    af_3_1_2          OBJ           0.0
    af_3_1_2          AFCH_3_1_1      -1.0
    af_3_1_2          AFCH_3_1_2      1.0
    af_3_1_2          AFO_3_1_2       1.0
    af_3_1_2          GAP_3_1_2       -1.0
    bf_3_1_3          OBJ           0.0
    bf_3_1_3          BFCH_3_1_3      1.0
    bf_3_1_3          BFO_3_1_3       1.0
    bf_3_1_3          BFCH_3_1_4      -1.0
    bf_3_1_3          GAP_3_1_3       -1.0
    af_3_1_3          OBJ           0.0
    af_3_1_3          AFCH_3_1_2      -1.0
    af_3_1_3          AFCH_3_1_3      1.0
    af_3_1_3          AFO_3_1_3       1.0
    af_3_1_3          GAP_3_1_3       -1.0
    bf_3_1_4          OBJ           0.0
    bf_3_1_4          BFCH_3_1_4      1.0
    bf_3_1_4          BFO_3_1_4       1.0
    bf_3_1_4          BFCH_3_1_5      -1.0
    bf_3_1_4          GAP_3_1_4       -1.0
    af_3_1_4          OBJ           0.0
    af_3_1_4          AFCH_3_1_3      -1.0
    af_3_1_4          AFCH_3_1_4      1.0
    af_3_1_4          AFO_3_1_4       1.0
    af_3_1_4          GAP_3_1_4       -1.0
    bf_3_1_5          OBJ           0.0
    bf_3_1_5          BFCH_3_1_5      1.0
    bf_3_1_5          BFO_3_1_5       1.0
    bf_3_1_5          GAP_3_1_5       -1.0
    af_3_1_5          OBJ           0.0
    af_3_1_5          AFCH_3_1_4      -1.0
    af_3_1_5          GAP_3_1_5       -1.0
    bf_3_2_0          OBJ           0.0
    bf_3_2_0          BFCH_3_2_1      -1.0
    bf_3_2_0          GAP_3_2_0       -1.0
    af_3_2_0          OBJ           0.0
    af_3_2_0          AFCH_3_2_0      1.0
    af_3_2_0          AFO_3_2_0       1.0
    af_3_2_0          GAP_3_2_0       -1.0
    bf_3_2_1          OBJ           0.0
    bf_3_2_1          BFCH_3_2_1      1.0
    bf_3_2_1          BFO_3_2_1       1.0
    bf_3_2_1          BFCH_3_2_2      -1.0
    bf_3_2_1          GAP_3_2_1       -1.0
    af_3_2_1          OBJ           0.0
    af_3_2_1          AFCH_3_2_0      -1.0
    af_3_2_1          AFCH_3_2_1      1.0
    af_3_2_1          AFO_3_2_1       1.0
    af_3_2_1          GAP_3_2_1       -1.0
    bf_3_2_2          OBJ           0.0
    bf_3_2_2          BFCH_3_2_2      1.0
    bf_3_2_2          BFO_3_2_2       1.0
    bf_3_2_2          BFCH_3_2_3      -1.0
    bf_3_2_2          GAP_3_2_2       -1.0
    af_3_2_2          OBJ           0.0
    af_3_2_2          AFCH_3_2_1      -1.0
    af_3_2_2          AFCH_3_2_2      1.0
    af_3_2_2          AFO_3_2_2       1.0
    af_3_2_2          GAP_3_2_2       -1.0
    bf_3_2_3          OBJ           0.0
    bf_3_2_3          BFCH_3_2_3      1.0
    bf_3_2_3          BFO_3_2_3       1.0
    bf_3_2_3          BFCH_3_2_4      -1.0
    bf_3_2_3          GAP_3_2_3       -1.0
    af_3_2_3          OBJ           0.0
    af_3_2_3          AFCH_3_2_2      -1.0
    af_3_2_3          AFCH_3_2_3      1.0
    af_3_2_3          AFO_3_2_3       1.0
    af_3_2_3          GAP_3_2_3       -1.0
    bf_3_2_4          OBJ           0.0
    bf_3_2_4          BFCH_3_2_4      1.0
    bf_3_2_4          BFO_3_2_4       1.0
    bf_3_2_4          BFCH_3_2_5      -1.0
    bf_3_2_4          GAP_3_2_4       -1.0
    af_3_2_4          OBJ           0.0
    af_3_2_4          AFCH_3_2_3      -1.0
    af_3_2_4          AFCH_3_2_4      1.0
    af_3_2_4          AFO_3_2_4       1.0
    af_3_2_4          GAP_3_2_4       -1.0
    bf_3_2_5          OBJ           0.0
    bf_3_2_5          BFCH_3_2_5      1.0
    bf_3_2_5          BFO_3_2_5       1.0
    bf_3_2_5          GAP_3_2_5       -1.0
    af_3_2_5          OBJ           0.0
    af_3_2_5          AFCH_3_2_4      -1.0
    af_3_2_5          GAP_3_2_5       -1.0
    bf_3_3_0          OBJ           0.0
    bf_3_3_0          BFCH_3_3_1      -1.0
    bf_3_3_0          GAP_3_3_0       -1.0
    af_3_3_0          OBJ           0.0
    af_3_3_0          AFCH_3_3_0      1.0
    af_3_3_0          AFO_3_3_0       1.0
    af_3_3_0          GAP_3_3_0       -1.0
    bf_3_3_1          OBJ           0.0
    bf_3_3_1          BFCH_3_3_1      1.0
    bf_3_3_1          BFO_3_3_1       1.0
    bf_3_3_1          BFCH_3_3_2      -1.0
    bf_3_3_1          GAP_3_3_1       -1.0
    af_3_3_1          OBJ           0.0
    af_3_3_1          AFCH_3_3_0      -1.0
    af_3_3_1          AFCH_3_3_1      1.0
    af_3_3_1          AFO_3_3_1       1.0
    af_3_3_1          GAP_3_3_1       -1.0
    bf_3_3_2          OBJ           0.0
    bf_3_3_2          BFCH_3_3_2      1.0
    bf_3_3_2          BFO_3_3_2       1.0
    bf_3_3_2          BFCH_3_3_3      -1.0
    bf_3_3_2          GAP_3_3_2       -1.0
    af_3_3_2          OBJ           0.0
    af_3_3_2          AFCH_3_3_1      -1.0
    af_3_3_2          AFCH_3_3_2      1.0
    af_3_3_2          AFO_3_3_2       1.0
    af_3_3_2          GAP_3_3_2       -1.0
    bf_3_3_3          OBJ           0.0
    bf_3_3_3          BFCH_3_3_3      1.0
    bf_3_3_3          BFO_3_3_3       1.0
    bf_3_3_3          BFCH_3_3_4      -1.0
    bf_3_3_3          GAP_3_3_3       -1.0
    af_3_3_3          OBJ           0.0
    af_3_3_3          AFCH_3_3_2      -1.0
    af_3_3_3          AFCH_3_3_3      1.0
    af_3_3_3          AFO_3_3_3       1.0
    af_3_3_3          GAP_3_3_3       -1.0
    bf_3_3_4          OBJ           0.0
    bf_3_3_4          BFCH_3_3_4      1.0
    bf_3_3_4          BFO_3_3_4       1.0
    bf_3_3_4          BFCH_3_3_5      -1.0
    bf_3_3_4          GAP_3_3_4       -1.0
    af_3_3_4          OBJ           0.0
    af_3_3_4          AFCH_3_3_3      -1.0
    af_3_3_4          AFCH_3_3_4      1.0
    af_3_3_4          AFO_3_3_4       1.0
    af_3_3_4          GAP_3_3_4       -1.0
    bf_3_3_5          OBJ           0.0
    bf_3_3_5          BFCH_3_3_5      1.0
    bf_3_3_5          BFO_3_3_5       1.0
    bf_3_3_5          GAP_3_3_5       -1.0
    af_3_3_5          OBJ           0.0
    af_3_3_5          AFCH_3_3_4      -1.0
    af_3_3_5          GAP_3_3_5       -1.0
    bf_3_4_0          OBJ           0.0
    bf_3_4_0          BFCH_3_4_1      -1.0
    bf_3_4_0          GAP_3_4_0       -1.0
    af_3_4_0          OBJ           0.0
    af_3_4_0          AFCH_3_4_0      1.0
    af_3_4_0          AFO_3_4_0       1.0
    af_3_4_0          GAP_3_4_0       -1.0
    bf_3_4_1          OBJ           0.0
    bf_3_4_1          BFCH_3_4_1      1.0
    bf_3_4_1          BFO_3_4_1       1.0
    bf_3_4_1          BFCH_3_4_2      -1.0
    bf_3_4_1          GAP_3_4_1       -1.0
    af_3_4_1          OBJ           0.0
    af_3_4_1          AFCH_3_4_0      -1.0
    af_3_4_1          AFCH_3_4_1      1.0
    af_3_4_1          AFO_3_4_1       1.0
    af_3_4_1          GAP_3_4_1       -1.0
    bf_3_4_2          OBJ           0.0
    bf_3_4_2          BFCH_3_4_2      1.0
    bf_3_4_2          BFO_3_4_2       1.0
    bf_3_4_2          BFCH_3_4_3      -1.0
    bf_3_4_2          GAP_3_4_2       -1.0
    af_3_4_2          OBJ           0.0
    af_3_4_2          AFCH_3_4_1      -1.0
    af_3_4_2          AFCH_3_4_2      1.0
    af_3_4_2          AFO_3_4_2       1.0
    af_3_4_2          GAP_3_4_2       -1.0
    bf_3_4_3          OBJ           0.0
    bf_3_4_3          BFCH_3_4_3      1.0
    bf_3_4_3          BFO_3_4_3       1.0
    bf_3_4_3          BFCH_3_4_4      -1.0
    bf_3_4_3          GAP_3_4_3       -1.0
    af_3_4_3          OBJ           0.0
    af_3_4_3          AFCH_3_4_2      -1.0
    af_3_4_3          AFCH_3_4_3      1.0
    af_3_4_3          AFO_3_4_3       1.0
    af_3_4_3          GAP_3_4_3       -1.0
    bf_3_4_4          OBJ           0.0
    bf_3_4_4          BFCH_3_4_4      1.0
    bf_3_4_4          BFO_3_4_4       1.0
    bf_3_4_4          BFCH_3_4_5      -1.0
    bf_3_4_4          GAP_3_4_4       -1.0
    af_3_4_4          OBJ           0.0
    af_3_4_4          AFCH_3_4_3      -1.0
    af_3_4_4          AFCH_3_4_4      1.0
    af_3_4_4          AFO_3_4_4       1.0
    af_3_4_4          GAP_3_4_4       -1.0
    bf_3_4_5          OBJ           0.0
    bf_3_4_5          BFCH_3_4_5      1.0
    bf_3_4_5          BFO_3_4_5       1.0
    bf_3_4_5          GAP_3_4_5       -1.0
    af_3_4_5          OBJ           0.0
    af_3_4_5          AFCH_3_4_4      -1.0
    af_3_4_5          GAP_3_4_5       -1.0
    bf_4_0_0          OBJ           0.0
    bf_4_0_0          BFCH_4_0_1      -1.0
    bf_4_0_0          GAP_4_0_0       -1.0
    af_4_0_0          OBJ           0.0
    af_4_0_0          AFCH_4_0_0      1.0
    af_4_0_0          AFO_4_0_0       1.0
    af_4_0_0          GAP_4_0_0       -1.0
    bf_4_0_1          OBJ           0.0
    bf_4_0_1          BFCH_4_0_1      1.0
    bf_4_0_1          BFO_4_0_1       1.0
    bf_4_0_1          BFCH_4_0_2      -1.0
    bf_4_0_1          GAP_4_0_1       -1.0
    af_4_0_1          OBJ           0.0
    af_4_0_1          AFCH_4_0_0      -1.0
    af_4_0_1          AFCH_4_0_1      1.0
    af_4_0_1          AFO_4_0_1       1.0
    af_4_0_1          GAP_4_0_1       -1.0
    bf_4_0_2          OBJ           0.0
    bf_4_0_2          BFCH_4_0_2      1.0
    bf_4_0_2          BFO_4_0_2       1.0
    bf_4_0_2          BFCH_4_0_3      -1.0
    bf_4_0_2          GAP_4_0_2       -1.0
    af_4_0_2          OBJ           0.0
    af_4_0_2          AFCH_4_0_1      -1.0
    af_4_0_2          AFCH_4_0_2      1.0
    af_4_0_2          AFO_4_0_2       1.0
    af_4_0_2          GAP_4_0_2       -1.0
    bf_4_0_3          OBJ           0.0
    bf_4_0_3          BFCH_4_0_3      1.0
    bf_4_0_3          BFO_4_0_3       1.0
    bf_4_0_3          BFCH_4_0_4      -1.0
    bf_4_0_3          GAP_4_0_3       -1.0
    af_4_0_3          OBJ           0.0
    af_4_0_3          AFCH_4_0_2      -1.0
    af_4_0_3          AFCH_4_0_3      1.0
    af_4_0_3          AFO_4_0_3       1.0
    af_4_0_3          GAP_4_0_3       -1.0
    bf_4_0_4          OBJ           0.0
    bf_4_0_4          BFCH_4_0_4      1.0
    bf_4_0_4          BFO_4_0_4       1.0
    bf_4_0_4          BFCH_4_0_5      -1.0
    bf_4_0_4          GAP_4_0_4       -1.0
    af_4_0_4          OBJ           0.0
    af_4_0_4          AFCH_4_0_3      -1.0
    af_4_0_4          AFCH_4_0_4      1.0
    af_4_0_4          AFO_4_0_4       1.0
    af_4_0_4          GAP_4_0_4       -1.0
    bf_4_0_5          OBJ           0.0
    bf_4_0_5          BFCH_4_0_5      1.0
    bf_4_0_5          BFO_4_0_5       1.0
    bf_4_0_5          GAP_4_0_5       -1.0
    af_4_0_5          OBJ           0.0
    af_4_0_5          AFCH_4_0_4      -1.0
    af_4_0_5          GAP_4_0_5       -1.0
    bf_4_1_0          OBJ           0.0
    bf_4_1_0          BFCH_4_1_1      -1.0
    bf_4_1_0          GAP_4_1_0       -1.0
    af_4_1_0          OBJ           0.0
    af_4_1_0          AFCH_4_1_0      1.0
    af_4_1_0          AFO_4_1_0       1.0
    af_4_1_0          GAP_4_1_0       -1.0
    bf_4_1_1          OBJ           0.0
    bf_4_1_1          BFCH_4_1_1      1.0
    bf_4_1_1          BFO_4_1_1       1.0
    bf_4_1_1          BFCH_4_1_2      -1.0
    bf_4_1_1          GAP_4_1_1       -1.0
    af_4_1_1          OBJ           0.0
    af_4_1_1          AFCH_4_1_0      -1.0
    af_4_1_1          AFCH_4_1_1      1.0
    af_4_1_1          AFO_4_1_1       1.0
    af_4_1_1          GAP_4_1_1       -1.0
    bf_4_1_2          OBJ           0.0
    bf_4_1_2          BFCH_4_1_2      1.0
    bf_4_1_2          BFO_4_1_2       1.0
    bf_4_1_2          BFCH_4_1_3      -1.0
    bf_4_1_2          GAP_4_1_2       -1.0
    af_4_1_2          OBJ           0.0
    af_4_1_2          AFCH_4_1_1      -1.0
    af_4_1_2          AFCH_4_1_2      1.0
    af_4_1_2          AFO_4_1_2       1.0
    af_4_1_2          GAP_4_1_2       -1.0
    bf_4_1_3          OBJ           0.0
    bf_4_1_3          BFCH_4_1_3      1.0
    bf_4_1_3          BFO_4_1_3       1.0
    bf_4_1_3          BFCH_4_1_4      -1.0
    bf_4_1_3          GAP_4_1_3       -1.0
    af_4_1_3          OBJ           0.0
    af_4_1_3          AFCH_4_1_2      -1.0
    af_4_1_3          AFCH_4_1_3      1.0
    af_4_1_3          AFO_4_1_3       1.0
    af_4_1_3          GAP_4_1_3       -1.0
    bf_4_1_4          OBJ           0.0
    bf_4_1_4          BFCH_4_1_4      1.0
    bf_4_1_4          BFO_4_1_4       1.0
    bf_4_1_4          BFCH_4_1_5      -1.0
    bf_4_1_4          GAP_4_1_4       -1.0
    af_4_1_4          OBJ           0.0
    af_4_1_4          AFCH_4_1_3      -1.0
    af_4_1_4          AFCH_4_1_4      1.0
    af_4_1_4          AFO_4_1_4       1.0
    af_4_1_4          GAP_4_1_4       -1.0
    bf_4_1_5          OBJ           0.0
    bf_4_1_5          BFCH_4_1_5      1.0
    bf_4_1_5          BFO_4_1_5       1.0
    bf_4_1_5          GAP_4_1_5       -1.0
    af_4_1_5          OBJ           0.0
    af_4_1_5          AFCH_4_1_4      -1.0
    af_4_1_5          GAP_4_1_5       -1.0
    bf_4_2_0          OBJ           0.0
    bf_4_2_0          BFCH_4_2_1      -1.0
    bf_4_2_0          GAP_4_2_0       -1.0
    af_4_2_0          OBJ           0.0
    af_4_2_0          AFCH_4_2_0      1.0
    af_4_2_0          AFO_4_2_0       1.0
    af_4_2_0          GAP_4_2_0       -1.0
    bf_4_2_1          OBJ           0.0
    bf_4_2_1          BFCH_4_2_1      1.0
    bf_4_2_1          BFO_4_2_1       1.0
    bf_4_2_1          BFCH_4_2_2      -1.0
    bf_4_2_1          GAP_4_2_1       -1.0
    af_4_2_1          OBJ           0.0
    af_4_2_1          AFCH_4_2_0      -1.0
    af_4_2_1          AFCH_4_2_1      1.0
    af_4_2_1          AFO_4_2_1       1.0
    af_4_2_1          GAP_4_2_1       -1.0
    bf_4_2_2          OBJ           0.0
    bf_4_2_2          BFCH_4_2_2      1.0
    bf_4_2_2          BFO_4_2_2       1.0
    bf_4_2_2          BFCH_4_2_3      -1.0
    bf_4_2_2          GAP_4_2_2       -1.0
    af_4_2_2          OBJ           0.0
    af_4_2_2          AFCH_4_2_1      -1.0
    af_4_2_2          AFCH_4_2_2      1.0
    af_4_2_2          AFO_4_2_2       1.0
    af_4_2_2          GAP_4_2_2       -1.0
    bf_4_2_3          OBJ           0.0
    bf_4_2_3          BFCH_4_2_3      1.0
    bf_4_2_3          BFO_4_2_3       1.0
    bf_4_2_3          BFCH_4_2_4      -1.0
    bf_4_2_3          GAP_4_2_3       -1.0
    af_4_2_3          OBJ           0.0
    af_4_2_3          AFCH_4_2_2      -1.0
    af_4_2_3          AFCH_4_2_3      1.0
    af_4_2_3          AFO_4_2_3       1.0
    af_4_2_3          GAP_4_2_3       -1.0
    bf_4_2_4          OBJ           0.0
    bf_4_2_4          BFCH_4_2_4      1.0
    bf_4_2_4          BFO_4_2_4       1.0
    bf_4_2_4          BFCH_4_2_5      -1.0
    bf_4_2_4          GAP_4_2_4       -1.0
    af_4_2_4          OBJ           0.0
    af_4_2_4          AFCH_4_2_3      -1.0
    af_4_2_4          AFCH_4_2_4      1.0
    af_4_2_4          AFO_4_2_4       1.0
    af_4_2_4          GAP_4_2_4       -1.0
    bf_4_2_5          OBJ           0.0
    bf_4_2_5          BFCH_4_2_5      1.0
    bf_4_2_5          BFO_4_2_5       1.0
    bf_4_2_5          GAP_4_2_5       -1.0
    af_4_2_5          OBJ           0.0
    af_4_2_5          AFCH_4_2_4      -1.0
    af_4_2_5          GAP_4_2_5       -1.0
    bf_4_3_0          OBJ           0.0
    bf_4_3_0          BFCH_4_3_1      -1.0
    bf_4_3_0          GAP_4_3_0       -1.0
    af_4_3_0          OBJ           0.0
    af_4_3_0          AFCH_4_3_0      1.0
    af_4_3_0          AFO_4_3_0       1.0
    af_4_3_0          GAP_4_3_0       -1.0
    bf_4_3_1          OBJ           0.0
    bf_4_3_1          BFCH_4_3_1      1.0
    bf_4_3_1          BFO_4_3_1       1.0
    bf_4_3_1          BFCH_4_3_2      -1.0
    bf_4_3_1          GAP_4_3_1       -1.0
    af_4_3_1          OBJ           0.0
    af_4_3_1          AFCH_4_3_0      -1.0
    af_4_3_1          AFCH_4_3_1      1.0
    af_4_3_1          AFO_4_3_1       1.0
    af_4_3_1          GAP_4_3_1       -1.0
    bf_4_3_2          OBJ           0.0
    bf_4_3_2          BFCH_4_3_2      1.0
    bf_4_3_2          BFO_4_3_2       1.0
    bf_4_3_2          BFCH_4_3_3      -1.0
    bf_4_3_2          GAP_4_3_2       -1.0
    af_4_3_2          OBJ           0.0
    af_4_3_2          AFCH_4_3_1      -1.0
    af_4_3_2          AFCH_4_3_2      1.0
    af_4_3_2          AFO_4_3_2       1.0
    af_4_3_2          GAP_4_3_2       -1.0
    bf_4_3_3          OBJ           0.0
    bf_4_3_3          BFCH_4_3_3      1.0
    bf_4_3_3          BFO_4_3_3       1.0
    bf_4_3_3          BFCH_4_3_4      -1.0
    bf_4_3_3          GAP_4_3_3       -1.0
    af_4_3_3          OBJ           0.0
    af_4_3_3          AFCH_4_3_2      -1.0
    af_4_3_3          AFCH_4_3_3      1.0
    af_4_3_3          AFO_4_3_3       1.0
    af_4_3_3          GAP_4_3_3       -1.0
    bf_4_3_4          OBJ           0.0
    bf_4_3_4          BFCH_4_3_4      1.0
    bf_4_3_4          BFO_4_3_4       1.0
    bf_4_3_4          BFCH_4_3_5      -1.0
    bf_4_3_4          GAP_4_3_4       -1.0
    af_4_3_4          OBJ           0.0
    af_4_3_4          AFCH_4_3_3      -1.0
    af_4_3_4          AFCH_4_3_4      1.0
    af_4_3_4          AFO_4_3_4       1.0
    af_4_3_4          GAP_4_3_4       -1.0
    bf_4_3_5          OBJ           0.0
    bf_4_3_5          BFCH_4_3_5      1.0
    bf_4_3_5          BFO_4_3_5       1.0
    bf_4_3_5          GAP_4_3_5       -1.0
    af_4_3_5          OBJ           0.0
    af_4_3_5          AFCH_4_3_4      -1.0
    af_4_3_5          GAP_4_3_5       -1.0
    bf_4_4_0          OBJ           0.0
    bf_4_4_0          BFCH_4_4_1      -1.0
    bf_4_4_0          GAP_4_4_0       -1.0
    af_4_4_0          OBJ           0.0
    af_4_4_0          AFCH_4_4_0      1.0
    af_4_4_0          AFO_4_4_0       1.0
    af_4_4_0          GAP_4_4_0       -1.0
    bf_4_4_1          OBJ           0.0
    bf_4_4_1          BFCH_4_4_1      1.0
    bf_4_4_1          BFO_4_4_1       1.0
    bf_4_4_1          BFCH_4_4_2      -1.0
    bf_4_4_1          GAP_4_4_1       -1.0
    af_4_4_1          OBJ           0.0
    af_4_4_1          AFCH_4_4_0      -1.0
    af_4_4_1          AFCH_4_4_1      1.0
    af_4_4_1          AFO_4_4_1       1.0
    af_4_4_1          GAP_4_4_1       -1.0
    bf_4_4_2          OBJ           0.0
    bf_4_4_2          BFCH_4_4_2      1.0
    bf_4_4_2          BFO_4_4_2       1.0
    bf_4_4_2          BFCH_4_4_3      -1.0
    bf_4_4_2          GAP_4_4_2       -1.0
    af_4_4_2          OBJ           0.0
    af_4_4_2          AFCH_4_4_1      -1.0
    af_4_4_2          AFCH_4_4_2      1.0
    af_4_4_2          AFO_4_4_2       1.0
    af_4_4_2          GAP_4_4_2       -1.0
    bf_4_4_3          OBJ           0.0
    bf_4_4_3          BFCH_4_4_3      1.0
    bf_4_4_3          BFO_4_4_3       1.0
    bf_4_4_3          BFCH_4_4_4      -1.0
    bf_4_4_3          GAP_4_4_3       -1.0
    af_4_4_3          OBJ           0.0
    af_4_4_3          AFCH_4_4_2      -1.0
    af_4_4_3          AFCH_4_4_3      1.0
    af_4_4_3          AFO_4_4_3       1.0
    af_4_4_3          GAP_4_4_3       -1.0
    bf_4_4_4          OBJ           0.0
    bf_4_4_4          BFCH_4_4_4      1.0
    bf_4_4_4          BFO_4_4_4       1.0
    bf_4_4_4          BFCH_4_4_5      -1.0
    bf_4_4_4          GAP_4_4_4       -1.0
    af_4_4_4          OBJ           0.0
    af_4_4_4          AFCH_4_4_3      -1.0
    af_4_4_4          AFCH_4_4_4      1.0
    af_4_4_4          AFO_4_4_4       1.0
    af_4_4_4          GAP_4_4_4       -1.0
    bf_4_4_5          OBJ           0.0
    bf_4_4_5          BFCH_4_4_5      1.0
    bf_4_4_5          BFO_4_4_5       1.0
    bf_4_4_5          GAP_4_4_5       -1.0
    af_4_4_5          OBJ           0.0
    af_4_4_5          AFCH_4_4_4      -1.0
    af_4_4_5          GAP_4_4_5       -1.0
    bf_5_0_0          OBJ           0.0
    bf_5_0_0          BFCH_5_0_1      -1.0
    bf_5_0_0          GAP_5_0_0       -1.0
    af_5_0_0          OBJ           0.0
    af_5_0_0          AFCH_5_0_0      1.0
    af_5_0_0          AFO_5_0_0       1.0
    af_5_0_0          GAP_5_0_0       -1.0
    bf_5_0_1          OBJ           0.0
    bf_5_0_1          BFCH_5_0_1      1.0
    bf_5_0_1          BFO_5_0_1       1.0
    bf_5_0_1          BFCH_5_0_2      -1.0
    bf_5_0_1          GAP_5_0_1       -1.0
    af_5_0_1          OBJ           0.0
    af_5_0_1          AFCH_5_0_0      -1.0
    af_5_0_1          AFCH_5_0_1      1.0
    af_5_0_1          AFO_5_0_1       1.0
    af_5_0_1          GAP_5_0_1       -1.0
    bf_5_0_2          OBJ           0.0
    bf_5_0_2          BFCH_5_0_2      1.0
    bf_5_0_2          BFO_5_0_2       1.0
    bf_5_0_2          BFCH_5_0_3      -1.0
    bf_5_0_2          GAP_5_0_2       -1.0
    af_5_0_2          OBJ           0.0
    af_5_0_2          AFCH_5_0_1      -1.0
    af_5_0_2          AFCH_5_0_2      1.0
    af_5_0_2          AFO_5_0_2       1.0
    af_5_0_2          GAP_5_0_2       -1.0
    bf_5_0_3          OBJ           0.0
    bf_5_0_3          BFCH_5_0_3      1.0
    bf_5_0_3          BFO_5_0_3       1.0
    bf_5_0_3          BFCH_5_0_4      -1.0
    bf_5_0_3          GAP_5_0_3       -1.0
    af_5_0_3          OBJ           0.0
    af_5_0_3          AFCH_5_0_2      -1.0
    af_5_0_3          AFCH_5_0_3      1.0
    af_5_0_3          AFO_5_0_3       1.0
    af_5_0_3          GAP_5_0_3       -1.0
    bf_5_0_4          OBJ           0.0
    bf_5_0_4          BFCH_5_0_4      1.0
    bf_5_0_4          BFO_5_0_4       1.0
    bf_5_0_4          BFCH_5_0_5      -1.0
    bf_5_0_4          GAP_5_0_4       -1.0
    af_5_0_4          OBJ           0.0
    af_5_0_4          AFCH_5_0_3      -1.0
    af_5_0_4          AFCH_5_0_4      1.0
    af_5_0_4          AFO_5_0_4       1.0
    af_5_0_4          GAP_5_0_4       -1.0
    bf_5_0_5          OBJ           0.0
    bf_5_0_5          BFCH_5_0_5      1.0
    bf_5_0_5          BFO_5_0_5       1.0
    bf_5_0_5          GAP_5_0_5       -1.0
    af_5_0_5          OBJ           0.0
    af_5_0_5          AFCH_5_0_4      -1.0
    af_5_0_5          GAP_5_0_5       -1.0
    bf_5_1_0          OBJ           0.0
    bf_5_1_0          BFCH_5_1_1      -1.0
    bf_5_1_0          GAP_5_1_0       -1.0
    af_5_1_0          OBJ           0.0
    af_5_1_0          AFCH_5_1_0      1.0
    af_5_1_0          AFO_5_1_0       1.0
    af_5_1_0          GAP_5_1_0       -1.0
    bf_5_1_1          OBJ           0.0
    bf_5_1_1          BFCH_5_1_1      1.0
    bf_5_1_1          BFO_5_1_1       1.0
    bf_5_1_1          BFCH_5_1_2      -1.0
    bf_5_1_1          GAP_5_1_1       -1.0
    af_5_1_1          OBJ           0.0
    af_5_1_1          AFCH_5_1_0      -1.0
    af_5_1_1          AFCH_5_1_1      1.0
    af_5_1_1          AFO_5_1_1       1.0
    af_5_1_1          GAP_5_1_1       -1.0
    bf_5_1_2          OBJ           0.0
    bf_5_1_2          BFCH_5_1_2      1.0
    bf_5_1_2          BFO_5_1_2       1.0
    bf_5_1_2          BFCH_5_1_3      -1.0
    bf_5_1_2          GAP_5_1_2       -1.0
    af_5_1_2          OBJ           0.0
    af_5_1_2          AFCH_5_1_1      -1.0
    af_5_1_2          AFCH_5_1_2      1.0
    af_5_1_2          AFO_5_1_2       1.0
    af_5_1_2          GAP_5_1_2       -1.0
    bf_5_1_3          OBJ           0.0
    bf_5_1_3          BFCH_5_1_3      1.0
    bf_5_1_3          BFO_5_1_3       1.0
    bf_5_1_3          BFCH_5_1_4      -1.0
    bf_5_1_3          GAP_5_1_3       -1.0
    af_5_1_3          OBJ           0.0
    af_5_1_3          AFCH_5_1_2      -1.0
    af_5_1_3          AFCH_5_1_3      1.0
    af_5_1_3          AFO_5_1_3       1.0
    af_5_1_3          GAP_5_1_3       -1.0
    bf_5_1_4          OBJ           0.0
    bf_5_1_4          BFCH_5_1_4      1.0
    bf_5_1_4          BFO_5_1_4       1.0
    bf_5_1_4          BFCH_5_1_5      -1.0
    bf_5_1_4          GAP_5_1_4       -1.0
    af_5_1_4          OBJ           0.0
    af_5_1_4          AFCH_5_1_3      -1.0
    af_5_1_4          AFCH_5_1_4      1.0
    af_5_1_4          AFO_5_1_4       1.0
    af_5_1_4          GAP_5_1_4       -1.0
    bf_5_1_5          OBJ           0.0
    bf_5_1_5          BFCH_5_1_5      1.0
    bf_5_1_5          BFO_5_1_5       1.0
    bf_5_1_5          GAP_5_1_5       -1.0
    af_5_1_5          OBJ           0.0
    af_5_1_5          AFCH_5_1_4      -1.0
    af_5_1_5          GAP_5_1_5       -1.0
    bf_5_2_0          OBJ           0.0
    bf_5_2_0          BFCH_5_2_1      -1.0
    bf_5_2_0          GAP_5_2_0       -1.0
    af_5_2_0          OBJ           0.0
    af_5_2_0          AFCH_5_2_0      1.0
    af_5_2_0          AFO_5_2_0       1.0
    af_5_2_0          GAP_5_2_0       -1.0
    bf_5_2_1          OBJ           0.0
    bf_5_2_1          BFCH_5_2_1      1.0
    bf_5_2_1          BFO_5_2_1       1.0
    bf_5_2_1          BFCH_5_2_2      -1.0
    bf_5_2_1          GAP_5_2_1       -1.0
    af_5_2_1          OBJ           0.0
    af_5_2_1          AFCH_5_2_0      -1.0
    af_5_2_1          AFCH_5_2_1      1.0
    af_5_2_1          AFO_5_2_1       1.0
    af_5_2_1          GAP_5_2_1       -1.0
    bf_5_2_2          OBJ           0.0
    bf_5_2_2          BFCH_5_2_2      1.0
    bf_5_2_2          BFO_5_2_2       1.0
    bf_5_2_2          BFCH_5_2_3      -1.0
    bf_5_2_2          GAP_5_2_2       -1.0
    af_5_2_2          OBJ           0.0
    af_5_2_2          AFCH_5_2_1      -1.0
    af_5_2_2          AFCH_5_2_2      1.0
    af_5_2_2          AFO_5_2_2       1.0
    af_5_2_2          GAP_5_2_2       -1.0
    bf_5_2_3          OBJ           0.0
    bf_5_2_3          BFCH_5_2_3      1.0
    bf_5_2_3          BFO_5_2_3       1.0
    bf_5_2_3          BFCH_5_2_4      -1.0
    bf_5_2_3          GAP_5_2_3       -1.0
    af_5_2_3          OBJ           0.0
    af_5_2_3          AFCH_5_2_2      -1.0
    af_5_2_3          AFCH_5_2_3      1.0
    af_5_2_3          AFO_5_2_3       1.0
    af_5_2_3          GAP_5_2_3       -1.0
    bf_5_2_4          OBJ           0.0
    bf_5_2_4          BFCH_5_2_4      1.0
    bf_5_2_4          BFO_5_2_4       1.0
    bf_5_2_4          BFCH_5_2_5      -1.0
    bf_5_2_4          GAP_5_2_4       -1.0
    af_5_2_4          OBJ           0.0
    af_5_2_4          AFCH_5_2_3      -1.0
    af_5_2_4          AFCH_5_2_4      1.0
    af_5_2_4          AFO_5_2_4       1.0
    af_5_2_4          GAP_5_2_4       -1.0
    bf_5_2_5          OBJ           0.0
    bf_5_2_5          BFCH_5_2_5      1.0
    bf_5_2_5          BFO_5_2_5       1.0
    bf_5_2_5          GAP_5_2_5       -1.0
    af_5_2_5          OBJ           0.0
    af_5_2_5          AFCH_5_2_4      -1.0
    af_5_2_5          GAP_5_2_5       -1.0
    bf_5_3_0          OBJ           0.0
    bf_5_3_0          BFCH_5_3_1      -1.0
    bf_5_3_0          GAP_5_3_0       -1.0
    af_5_3_0          OBJ           0.0
    af_5_3_0          AFCH_5_3_0      1.0
    af_5_3_0          AFO_5_3_0       1.0
    af_5_3_0          GAP_5_3_0       -1.0
    bf_5_3_1          OBJ           0.0
    bf_5_3_1          BFCH_5_3_1      1.0
    bf_5_3_1          BFO_5_3_1       1.0
    bf_5_3_1          BFCH_5_3_2      -1.0
    bf_5_3_1          GAP_5_3_1       -1.0
    af_5_3_1          OBJ           0.0
    af_5_3_1          AFCH_5_3_0      -1.0
    af_5_3_1          AFCH_5_3_1      1.0
    af_5_3_1          AFO_5_3_1       1.0
    af_5_3_1          GAP_5_3_1       -1.0
    bf_5_3_2          OBJ           0.0
    bf_5_3_2          BFCH_5_3_2      1.0
    bf_5_3_2          BFO_5_3_2       1.0
    bf_5_3_2          BFCH_5_3_3      -1.0
    bf_5_3_2          GAP_5_3_2       -1.0
    af_5_3_2          OBJ           0.0
    af_5_3_2          AFCH_5_3_1      -1.0
    af_5_3_2          AFCH_5_3_2      1.0
    af_5_3_2          AFO_5_3_2       1.0
    af_5_3_2          GAP_5_3_2       -1.0
    bf_5_3_3          OBJ           0.0
    bf_5_3_3          BFCH_5_3_3      1.0
    bf_5_3_3          BFO_5_3_3       1.0
    bf_5_3_3          BFCH_5_3_4      -1.0
    bf_5_3_3          GAP_5_3_3       -1.0
    af_5_3_3          OBJ           0.0
    af_5_3_3          AFCH_5_3_2      -1.0
    af_5_3_3          AFCH_5_3_3      1.0
    af_5_3_3          AFO_5_3_3       1.0
    af_5_3_3          GAP_5_3_3       -1.0
    bf_5_3_4          OBJ           0.0
    bf_5_3_4          BFCH_5_3_4      1.0
    bf_5_3_4          BFO_5_3_4       1.0
    bf_5_3_4          BFCH_5_3_5      -1.0
    bf_5_3_4          GAP_5_3_4       -1.0
    af_5_3_4          OBJ           0.0
    af_5_3_4          AFCH_5_3_3      -1.0
    af_5_3_4          AFCH_5_3_4      1.0
    af_5_3_4          AFO_5_3_4       1.0
    af_5_3_4          GAP_5_3_4       -1.0
    bf_5_3_5          OBJ           0.0
    bf_5_3_5          BFCH_5_3_5      1.0
    bf_5_3_5          BFO_5_3_5       1.0
    bf_5_3_5          GAP_5_3_5       -1.0
    af_5_3_5          OBJ           0.0
    af_5_3_5          AFCH_5_3_4      -1.0
    af_5_3_5          GAP_5_3_5       -1.0
    bf_5_4_0          OBJ           0.0
    bf_5_4_0          BFCH_5_4_1      -1.0
    bf_5_4_0          GAP_5_4_0       -1.0
    af_5_4_0          OBJ           0.0
    af_5_4_0          AFCH_5_4_0      1.0
    af_5_4_0          AFO_5_4_0       1.0
    af_5_4_0          GAP_5_4_0       -1.0
    bf_5_4_1          OBJ           0.0
    bf_5_4_1          BFCH_5_4_1      1.0
    bf_5_4_1          BFO_5_4_1       1.0
    bf_5_4_1          BFCH_5_4_2      -1.0
    bf_5_4_1          GAP_5_4_1       -1.0
    af_5_4_1          OBJ           0.0
    af_5_4_1          AFCH_5_4_0      -1.0
    af_5_4_1          AFCH_5_4_1      1.0
    af_5_4_1          AFO_5_4_1       1.0
    af_5_4_1          GAP_5_4_1       -1.0
    bf_5_4_2          OBJ           0.0
    bf_5_4_2          BFCH_5_4_2      1.0
    bf_5_4_2          BFO_5_4_2       1.0
    bf_5_4_2          BFCH_5_4_3      -1.0
    bf_5_4_2          GAP_5_4_2       -1.0
    af_5_4_2          OBJ           0.0
    af_5_4_2          AFCH_5_4_1      -1.0
    af_5_4_2          AFCH_5_4_2      1.0
    af_5_4_2          AFO_5_4_2       1.0
    af_5_4_2          GAP_5_4_2       -1.0
    bf_5_4_3          OBJ           0.0
    bf_5_4_3          BFCH_5_4_3      1.0
    bf_5_4_3          BFO_5_4_3       1.0
    bf_5_4_3          BFCH_5_4_4      -1.0
    bf_5_4_3          GAP_5_4_3       -1.0
    af_5_4_3          OBJ           0.0
    af_5_4_3          AFCH_5_4_2      -1.0
    af_5_4_3          AFCH_5_4_3      1.0
    af_5_4_3          AFO_5_4_3       1.0
    af_5_4_3          GAP_5_4_3       -1.0
    bf_5_4_4          OBJ           0.0
    bf_5_4_4          BFCH_5_4_4      1.0
    bf_5_4_4          BFO_5_4_4       1.0
    bf_5_4_4          BFCH_5_4_5      -1.0
    bf_5_4_4          GAP_5_4_4       -1.0
    af_5_4_4          OBJ           0.0
    af_5_4_4          AFCH_5_4_3      -1.0
    af_5_4_4          AFCH_5_4_4      1.0
    af_5_4_4          AFO_5_4_4       1.0
    af_5_4_4          GAP_5_4_4       -1.0
    bf_5_4_5          OBJ           0.0
    bf_5_4_5          BFCH_5_4_5      1.0
    bf_5_4_5          BFO_5_4_5       1.0
    bf_5_4_5          GAP_5_4_5       -1.0
    af_5_4_5          OBJ           0.0
    af_5_4_5          AFCH_5_4_4      -1.0
    af_5_4_5          GAP_5_4_5       -1.0
    bf_6_0_0          OBJ           0.0
    bf_6_0_0          BFCH_6_0_1      -1.0
    bf_6_0_0          GAP_6_0_0       -1.0
    af_6_0_0          OBJ           0.0
    af_6_0_0          AFCH_6_0_0      1.0
    af_6_0_0          AFO_6_0_0       1.0
    af_6_0_0          GAP_6_0_0       -1.0
    bf_6_0_1          OBJ           0.0
    bf_6_0_1          BFCH_6_0_1      1.0
    bf_6_0_1          BFO_6_0_1       1.0
    bf_6_0_1          BFCH_6_0_2      -1.0
    bf_6_0_1          GAP_6_0_1       -1.0
    af_6_0_1          OBJ           0.0
    af_6_0_1          AFCH_6_0_0      -1.0
    af_6_0_1          AFCH_6_0_1      1.0
    af_6_0_1          AFO_6_0_1       1.0
    af_6_0_1          GAP_6_0_1       -1.0
    bf_6_0_2          OBJ           0.0
    bf_6_0_2          BFCH_6_0_2      1.0
    bf_6_0_2          BFO_6_0_2       1.0
    bf_6_0_2          BFCH_6_0_3      -1.0
    bf_6_0_2          GAP_6_0_2       -1.0
    af_6_0_2          OBJ           0.0
    af_6_0_2          AFCH_6_0_1      -1.0
    af_6_0_2          AFCH_6_0_2      1.0
    af_6_0_2          AFO_6_0_2       1.0
    af_6_0_2          GAP_6_0_2       -1.0
    bf_6_0_3          OBJ           0.0
    bf_6_0_3          BFCH_6_0_3      1.0
    bf_6_0_3          BFO_6_0_3       1.0
    bf_6_0_3          BFCH_6_0_4      -1.0
    bf_6_0_3          GAP_6_0_3       -1.0
    af_6_0_3          OBJ           0.0
    af_6_0_3          AFCH_6_0_2      -1.0
    af_6_0_3          AFCH_6_0_3      1.0
    af_6_0_3          AFO_6_0_3       1.0
    af_6_0_3          GAP_6_0_3       -1.0
    bf_6_0_4          OBJ           0.0
    bf_6_0_4          BFCH_6_0_4      1.0
    bf_6_0_4          BFO_6_0_4       1.0
    bf_6_0_4          BFCH_6_0_5      -1.0
    bf_6_0_4          GAP_6_0_4       -1.0
    af_6_0_4          OBJ           0.0
    af_6_0_4          AFCH_6_0_3      -1.0
    af_6_0_4          AFCH_6_0_4      1.0
    af_6_0_4          AFO_6_0_4       1.0
    af_6_0_4          GAP_6_0_4       -1.0
    bf_6_0_5          OBJ           0.0
    bf_6_0_5          BFCH_6_0_5      1.0
    bf_6_0_5          BFO_6_0_5       1.0
    bf_6_0_5          GAP_6_0_5       -1.0
    af_6_0_5          OBJ           0.0
    af_6_0_5          AFCH_6_0_4      -1.0
    af_6_0_5          GAP_6_0_5       -1.0
    bf_6_1_0          OBJ           0.0
    bf_6_1_0          BFCH_6_1_1      -1.0
    bf_6_1_0          GAP_6_1_0       -1.0
    af_6_1_0          OBJ           0.0
    af_6_1_0          AFCH_6_1_0      1.0
    af_6_1_0          AFO_6_1_0       1.0
    af_6_1_0          GAP_6_1_0       -1.0
    bf_6_1_1          OBJ           0.0
    bf_6_1_1          BFCH_6_1_1      1.0
    bf_6_1_1          BFO_6_1_1       1.0
    bf_6_1_1          BFCH_6_1_2      -1.0
    bf_6_1_1          GAP_6_1_1       -1.0
    af_6_1_1          OBJ           0.0
    af_6_1_1          AFCH_6_1_0      -1.0
    af_6_1_1          AFCH_6_1_1      1.0
    af_6_1_1          AFO_6_1_1       1.0
    af_6_1_1          GAP_6_1_1       -1.0
    bf_6_1_2          OBJ           0.0
    bf_6_1_2          BFCH_6_1_2      1.0
    bf_6_1_2          BFO_6_1_2       1.0
    bf_6_1_2          BFCH_6_1_3      -1.0
    bf_6_1_2          GAP_6_1_2       -1.0
    af_6_1_2          OBJ           0.0
    af_6_1_2          AFCH_6_1_1      -1.0
    af_6_1_2          AFCH_6_1_2      1.0
    af_6_1_2          AFO_6_1_2       1.0
    af_6_1_2          GAP_6_1_2       -1.0
    bf_6_1_3          OBJ           0.0
    bf_6_1_3          BFCH_6_1_3      1.0
    bf_6_1_3          BFO_6_1_3       1.0
    bf_6_1_3          BFCH_6_1_4      -1.0
    bf_6_1_3          GAP_6_1_3       -1.0
    af_6_1_3          OBJ           0.0
    af_6_1_3          AFCH_6_1_2      -1.0
    af_6_1_3          AFCH_6_1_3      1.0
    af_6_1_3          AFO_6_1_3       1.0
    af_6_1_3          GAP_6_1_3       -1.0
    bf_6_1_4          OBJ           0.0
    bf_6_1_4          BFCH_6_1_4      1.0
    bf_6_1_4          BFO_6_1_4       1.0
    bf_6_1_4          BFCH_6_1_5      -1.0
    bf_6_1_4          GAP_6_1_4       -1.0
    af_6_1_4          OBJ           0.0
    af_6_1_4          AFCH_6_1_3      -1.0
    af_6_1_4          AFCH_6_1_4      1.0
    af_6_1_4          AFO_6_1_4       1.0
    af_6_1_4          GAP_6_1_4       -1.0
    bf_6_1_5          OBJ           0.0
    bf_6_1_5          BFCH_6_1_5      1.0
    bf_6_1_5          BFO_6_1_5       1.0
    bf_6_1_5          GAP_6_1_5       -1.0
    af_6_1_5          OBJ           0.0
    af_6_1_5          AFCH_6_1_4      -1.0
    af_6_1_5          GAP_6_1_5       -1.0
    bf_6_2_0          OBJ           0.0
    bf_6_2_0          BFCH_6_2_1      -1.0
    bf_6_2_0          GAP_6_2_0       -1.0
    af_6_2_0          OBJ           0.0
    af_6_2_0          AFCH_6_2_0      1.0
    af_6_2_0          AFO_6_2_0       1.0
    af_6_2_0          GAP_6_2_0       -1.0
    bf_6_2_1          OBJ           0.0
    bf_6_2_1          BFCH_6_2_1      1.0
    bf_6_2_1          BFO_6_2_1       1.0
    bf_6_2_1          BFCH_6_2_2      -1.0
    bf_6_2_1          GAP_6_2_1       -1.0
    af_6_2_1          OBJ           0.0
    af_6_2_1          AFCH_6_2_0      -1.0
    af_6_2_1          AFCH_6_2_1      1.0
    af_6_2_1          AFO_6_2_1       1.0
    af_6_2_1          GAP_6_2_1       -1.0
    bf_6_2_2          OBJ           0.0
    bf_6_2_2          BFCH_6_2_2      1.0
    bf_6_2_2          BFO_6_2_2       1.0
    bf_6_2_2          BFCH_6_2_3      -1.0
    bf_6_2_2          GAP_6_2_2       -1.0
    af_6_2_2          OBJ           0.0
    af_6_2_2          AFCH_6_2_1      -1.0
    af_6_2_2          AFCH_6_2_2      1.0
    af_6_2_2          AFO_6_2_2       1.0
    af_6_2_2          GAP_6_2_2       -1.0
    bf_6_2_3          OBJ           0.0
    bf_6_2_3          BFCH_6_2_3      1.0
    bf_6_2_3          BFO_6_2_3       1.0
    bf_6_2_3          BFCH_6_2_4      -1.0
    bf_6_2_3          GAP_6_2_3       -1.0
    af_6_2_3          OBJ           0.0
    af_6_2_3          AFCH_6_2_2      -1.0
    af_6_2_3          AFCH_6_2_3      1.0
    af_6_2_3          AFO_6_2_3       1.0
    af_6_2_3          GAP_6_2_3       -1.0
    bf_6_2_4          OBJ           0.0
    bf_6_2_4          BFCH_6_2_4      1.0
    bf_6_2_4          BFO_6_2_4       1.0
    bf_6_2_4          BFCH_6_2_5      -1.0
    bf_6_2_4          GAP_6_2_4       -1.0
    af_6_2_4          OBJ           0.0
    af_6_2_4          AFCH_6_2_3      -1.0
    af_6_2_4          AFCH_6_2_4      1.0
    af_6_2_4          AFO_6_2_4       1.0
    af_6_2_4          GAP_6_2_4       -1.0
    bf_6_2_5          OBJ           0.0
    bf_6_2_5          BFCH_6_2_5      1.0
    bf_6_2_5          BFO_6_2_5       1.0
    bf_6_2_5          GAP_6_2_5       -1.0
    af_6_2_5          OBJ           0.0
    af_6_2_5          AFCH_6_2_4      -1.0
    af_6_2_5          GAP_6_2_5       -1.0
    bf_6_3_0          OBJ           0.0
    bf_6_3_0          BFCH_6_3_1      -1.0
    bf_6_3_0          GAP_6_3_0       -1.0
    af_6_3_0          OBJ           0.0
    af_6_3_0          AFCH_6_3_0      1.0
    af_6_3_0          AFO_6_3_0       1.0
    af_6_3_0          GAP_6_3_0       -1.0
    bf_6_3_1          OBJ           0.0
    bf_6_3_1          BFCH_6_3_1      1.0
    bf_6_3_1          BFO_6_3_1       1.0
    bf_6_3_1          BFCH_6_3_2      -1.0
    bf_6_3_1          GAP_6_3_1       -1.0
    af_6_3_1          OBJ           0.0
    af_6_3_1          AFCH_6_3_0      -1.0
    af_6_3_1          AFCH_6_3_1      1.0
    af_6_3_1          AFO_6_3_1       1.0
    af_6_3_1          GAP_6_3_1       -1.0
    bf_6_3_2          OBJ           0.0
    bf_6_3_2          BFCH_6_3_2      1.0
    bf_6_3_2          BFO_6_3_2       1.0
    bf_6_3_2          BFCH_6_3_3      -1.0
    bf_6_3_2          GAP_6_3_2       -1.0
    af_6_3_2          OBJ           0.0
    af_6_3_2          AFCH_6_3_1      -1.0
    af_6_3_2          AFCH_6_3_2      1.0
    af_6_3_2          AFO_6_3_2       1.0
    af_6_3_2          GAP_6_3_2       -1.0
    bf_6_3_3          OBJ           0.0
    bf_6_3_3          BFCH_6_3_3      1.0
    bf_6_3_3          BFO_6_3_3       1.0
    bf_6_3_3          BFCH_6_3_4      -1.0
    bf_6_3_3          GAP_6_3_3       -1.0
    af_6_3_3          OBJ           0.0
    af_6_3_3          AFCH_6_3_2      -1.0
    af_6_3_3          AFCH_6_3_3      1.0
    af_6_3_3          AFO_6_3_3       1.0
    af_6_3_3          GAP_6_3_3       -1.0
    bf_6_3_4          OBJ           0.0
    bf_6_3_4          BFCH_6_3_4      1.0
    bf_6_3_4          BFO_6_3_4       1.0
    bf_6_3_4          BFCH_6_3_5      -1.0
    bf_6_3_4          GAP_6_3_4       -1.0
    af_6_3_4          OBJ           0.0
    af_6_3_4          AFCH_6_3_3      -1.0
    af_6_3_4          AFCH_6_3_4      1.0
    af_6_3_4          AFO_6_3_4       1.0
    af_6_3_4          GAP_6_3_4       -1.0
    bf_6_3_5          OBJ           0.0
    bf_6_3_5          BFCH_6_3_5      1.0
    bf_6_3_5          BFO_6_3_5       1.0
    bf_6_3_5          GAP_6_3_5       -1.0
    af_6_3_5          OBJ           0.0
    af_6_3_5          AFCH_6_3_4      -1.0
    af_6_3_5          GAP_6_3_5       -1.0
    bf_6_4_0          OBJ           0.0
    bf_6_4_0          BFCH_6_4_1      -1.0
    bf_6_4_0          GAP_6_4_0       -1.0
    af_6_4_0          OBJ           0.0
    af_6_4_0          AFCH_6_4_0      1.0
    af_6_4_0          AFO_6_4_0       1.0
    af_6_4_0          GAP_6_4_0       -1.0
    bf_6_4_1          OBJ           0.0
    bf_6_4_1          BFCH_6_4_1      1.0
    bf_6_4_1          BFO_6_4_1       1.0
    bf_6_4_1          BFCH_6_4_2      -1.0
    bf_6_4_1          GAP_6_4_1       -1.0
    af_6_4_1          OBJ           0.0
    af_6_4_1          AFCH_6_4_0      -1.0
    af_6_4_1          AFCH_6_4_1      1.0
    af_6_4_1          AFO_6_4_1       1.0
    af_6_4_1          GAP_6_4_1       -1.0
    bf_6_4_2          OBJ           0.0
    bf_6_4_2          BFCH_6_4_2      1.0
    bf_6_4_2          BFO_6_4_2       1.0
    bf_6_4_2          BFCH_6_4_3      -1.0
    bf_6_4_2          GAP_6_4_2       -1.0
    af_6_4_2          OBJ           0.0
    af_6_4_2          AFCH_6_4_1      -1.0
    af_6_4_2          AFCH_6_4_2      1.0
    af_6_4_2          AFO_6_4_2       1.0
    af_6_4_2          GAP_6_4_2       -1.0
    bf_6_4_3          OBJ           0.0
    bf_6_4_3          BFCH_6_4_3      1.0
    bf_6_4_3          BFO_6_4_3       1.0
    bf_6_4_3          BFCH_6_4_4      -1.0
    bf_6_4_3          GAP_6_4_3       -1.0
    af_6_4_3          OBJ           0.0
    af_6_4_3          AFCH_6_4_2      -1.0
    af_6_4_3          AFCH_6_4_3      1.0
    af_6_4_3          AFO_6_4_3       1.0
    af_6_4_3          GAP_6_4_3       -1.0
    bf_6_4_4          OBJ           0.0
    bf_6_4_4          BFCH_6_4_4      1.0
    bf_6_4_4          BFO_6_4_4       1.0
    bf_6_4_4          BFCH_6_4_5      -1.0
    bf_6_4_4          GAP_6_4_4       -1.0
    af_6_4_4          OBJ           0.0
    af_6_4_4          AFCH_6_4_3      -1.0
    af_6_4_4          AFCH_6_4_4      1.0
    af_6_4_4          AFO_6_4_4       1.0
    af_6_4_4          GAP_6_4_4       -1.0
    bf_6_4_5          OBJ           0.0
    bf_6_4_5          BFCH_6_4_5      1.0
    bf_6_4_5          BFO_6_4_5       1.0
    bf_6_4_5          GAP_6_4_5       -1.0
    af_6_4_5          OBJ           0.0
    af_6_4_5          AFCH_6_4_4      -1.0
    af_6_4_5          GAP_6_4_5       -1.0
    bf_7_0_0          OBJ           0.0
    bf_7_0_0          BFCH_7_0_1      -1.0
    bf_7_0_0          GAP_7_0_0       -1.0
    af_7_0_0          OBJ           0.0
    af_7_0_0          AFCH_7_0_0      1.0
    af_7_0_0          AFO_7_0_0       1.0
    af_7_0_0          GAP_7_0_0       -1.0
    bf_7_0_1          OBJ           0.0
    bf_7_0_1          BFCH_7_0_1      1.0
    bf_7_0_1          BFO_7_0_1       1.0
    bf_7_0_1          BFCH_7_0_2      -1.0
    bf_7_0_1          GAP_7_0_1       -1.0
    af_7_0_1          OBJ           0.0
    af_7_0_1          AFCH_7_0_0      -1.0
    af_7_0_1          AFCH_7_0_1      1.0
    af_7_0_1          AFO_7_0_1       1.0
    af_7_0_1          GAP_7_0_1       -1.0
    bf_7_0_2          OBJ           0.0
    bf_7_0_2          BFCH_7_0_2      1.0
    bf_7_0_2          BFO_7_0_2       1.0
    bf_7_0_2          BFCH_7_0_3      -1.0
    bf_7_0_2          GAP_7_0_2       -1.0
    af_7_0_2          OBJ           0.0
    af_7_0_2          AFCH_7_0_1      -1.0
    af_7_0_2          AFCH_7_0_2      1.0
    af_7_0_2          AFO_7_0_2       1.0
    af_7_0_2          GAP_7_0_2       -1.0
    bf_7_0_3          OBJ           0.0
    bf_7_0_3          BFCH_7_0_3      1.0
    bf_7_0_3          BFO_7_0_3       1.0
    bf_7_0_3          BFCH_7_0_4      -1.0
    bf_7_0_3          GAP_7_0_3       -1.0
    af_7_0_3          OBJ           0.0
    af_7_0_3          AFCH_7_0_2      -1.0
    af_7_0_3          AFCH_7_0_3      1.0
    af_7_0_3          AFO_7_0_3       1.0
    af_7_0_3          GAP_7_0_3       -1.0
    bf_7_0_4          OBJ           0.0
    bf_7_0_4          BFCH_7_0_4      1.0
    bf_7_0_4          BFO_7_0_4       1.0
    bf_7_0_4          BFCH_7_0_5      -1.0
    bf_7_0_4          GAP_7_0_4       -1.0
    af_7_0_4          OBJ           0.0
    af_7_0_4          AFCH_7_0_3      -1.0
    af_7_0_4          AFCH_7_0_4      1.0
    af_7_0_4          AFO_7_0_4       1.0
    af_7_0_4          GAP_7_0_4       -1.0
    bf_7_0_5          OBJ           0.0
    bf_7_0_5          BFCH_7_0_5      1.0
    bf_7_0_5          BFO_7_0_5       1.0
    bf_7_0_5          GAP_7_0_5       -1.0
    af_7_0_5          OBJ           0.0
    af_7_0_5          AFCH_7_0_4      -1.0
    af_7_0_5          GAP_7_0_5       -1.0
    bf_7_1_0          OBJ           0.0
    bf_7_1_0          BFCH_7_1_1      -1.0
    bf_7_1_0          GAP_7_1_0       -1.0
    af_7_1_0          OBJ           0.0
    af_7_1_0          AFCH_7_1_0      1.0
    af_7_1_0          AFO_7_1_0       1.0
    af_7_1_0          GAP_7_1_0       -1.0
    bf_7_1_1          OBJ           0.0
    bf_7_1_1          BFCH_7_1_1      1.0
    bf_7_1_1          BFO_7_1_1       1.0
    bf_7_1_1          BFCH_7_1_2      -1.0
    bf_7_1_1          GAP_7_1_1       -1.0
    af_7_1_1          OBJ           0.0
    af_7_1_1          AFCH_7_1_0      -1.0
    af_7_1_1          AFCH_7_1_1      1.0
    af_7_1_1          AFO_7_1_1       1.0
    af_7_1_1          GAP_7_1_1       -1.0
    bf_7_1_2          OBJ           0.0
    bf_7_1_2          BFCH_7_1_2      1.0
    bf_7_1_2          BFO_7_1_2       1.0
    bf_7_1_2          BFCH_7_1_3      -1.0
    bf_7_1_2          GAP_7_1_2       -1.0
    af_7_1_2          OBJ           0.0
    af_7_1_2          AFCH_7_1_1      -1.0
    af_7_1_2          AFCH_7_1_2      1.0
    af_7_1_2          AFO_7_1_2       1.0
    af_7_1_2          GAP_7_1_2       -1.0
    bf_7_1_3          OBJ           0.0
    bf_7_1_3          BFCH_7_1_3      1.0
    bf_7_1_3          BFO_7_1_3       1.0
    bf_7_1_3          BFCH_7_1_4      -1.0
    bf_7_1_3          GAP_7_1_3       -1.0
    af_7_1_3          OBJ           0.0
    af_7_1_3          AFCH_7_1_2      -1.0
    af_7_1_3          AFCH_7_1_3      1.0
    af_7_1_3          AFO_7_1_3       1.0
    af_7_1_3          GAP_7_1_3       -1.0
    bf_7_1_4          OBJ           0.0
    bf_7_1_4          BFCH_7_1_4      1.0
    bf_7_1_4          BFO_7_1_4       1.0
    bf_7_1_4          BFCH_7_1_5      -1.0
    bf_7_1_4          GAP_7_1_4       -1.0
    af_7_1_4          OBJ           0.0
    af_7_1_4          AFCH_7_1_3      -1.0
    af_7_1_4          AFCH_7_1_4      1.0
    af_7_1_4          AFO_7_1_4       1.0
    af_7_1_4          GAP_7_1_4       -1.0
    bf_7_1_5          OBJ           0.0
    bf_7_1_5          BFCH_7_1_5      1.0
    bf_7_1_5          BFO_7_1_5       1.0
    bf_7_1_5          GAP_7_1_5       -1.0
    af_7_1_5          OBJ           0.0
    af_7_1_5          AFCH_7_1_4      -1.0
    af_7_1_5          GAP_7_1_5       -1.0
    bf_7_2_0          OBJ           0.0
    bf_7_2_0          BFCH_7_2_1      -1.0
    bf_7_2_0          GAP_7_2_0       -1.0
    af_7_2_0          OBJ           0.0
    af_7_2_0          AFCH_7_2_0      1.0
    af_7_2_0          AFO_7_2_0       1.0
    af_7_2_0          GAP_7_2_0       -1.0
    bf_7_2_1          OBJ           0.0
    bf_7_2_1          BFCH_7_2_1      1.0
    bf_7_2_1          BFO_7_2_1       1.0
    bf_7_2_1          BFCH_7_2_2      -1.0
    bf_7_2_1          GAP_7_2_1       -1.0
    af_7_2_1          OBJ           0.0
    af_7_2_1          AFCH_7_2_0      -1.0
    af_7_2_1          AFCH_7_2_1      1.0
    af_7_2_1          AFO_7_2_1       1.0
    af_7_2_1          GAP_7_2_1       -1.0
    bf_7_2_2          OBJ           0.0
    bf_7_2_2          BFCH_7_2_2      1.0
    bf_7_2_2          BFO_7_2_2       1.0
    bf_7_2_2          BFCH_7_2_3      -1.0
    bf_7_2_2          GAP_7_2_2       -1.0
    af_7_2_2          OBJ           0.0
    af_7_2_2          AFCH_7_2_1      -1.0
    af_7_2_2          AFCH_7_2_2      1.0
    af_7_2_2          AFO_7_2_2       1.0
    af_7_2_2          GAP_7_2_2       -1.0
    bf_7_2_3          OBJ           0.0
    bf_7_2_3          BFCH_7_2_3      1.0
    bf_7_2_3          BFO_7_2_3       1.0
    bf_7_2_3          BFCH_7_2_4      -1.0
    bf_7_2_3          GAP_7_2_3       -1.0
    af_7_2_3          OBJ           0.0
    af_7_2_3          AFCH_7_2_2      -1.0
    af_7_2_3          AFCH_7_2_3      1.0
    af_7_2_3          AFO_7_2_3       1.0
    af_7_2_3          GAP_7_2_3       -1.0
    bf_7_2_4          OBJ           0.0
    bf_7_2_4          BFCH_7_2_4      1.0
    bf_7_2_4          BFO_7_2_4       1.0
    bf_7_2_4          BFCH_7_2_5      -1.0
    bf_7_2_4          GAP_7_2_4       -1.0
    af_7_2_4          OBJ           0.0
    af_7_2_4          AFCH_7_2_3      -1.0
    af_7_2_4          AFCH_7_2_4      1.0
    af_7_2_4          AFO_7_2_4       1.0
    af_7_2_4          GAP_7_2_4       -1.0
    bf_7_2_5          OBJ           0.0
    bf_7_2_5          BFCH_7_2_5      1.0
    bf_7_2_5          BFO_7_2_5       1.0
    bf_7_2_5          GAP_7_2_5       -1.0
    af_7_2_5          OBJ           0.0
    af_7_2_5          AFCH_7_2_4      -1.0
    af_7_2_5          GAP_7_2_5       -1.0
    bf_7_3_0          OBJ           0.0
    bf_7_3_0          BFCH_7_3_1      -1.0
    bf_7_3_0          GAP_7_3_0       -1.0
    af_7_3_0          OBJ           0.0
    af_7_3_0          AFCH_7_3_0      1.0
    af_7_3_0          AFO_7_3_0       1.0
    af_7_3_0          GAP_7_3_0       -1.0
    bf_7_3_1          OBJ           0.0
    bf_7_3_1          BFCH_7_3_1      1.0
    bf_7_3_1          BFO_7_3_1       1.0
    bf_7_3_1          BFCH_7_3_2      -1.0
    bf_7_3_1          GAP_7_3_1       -1.0
    af_7_3_1          OBJ           0.0
    af_7_3_1          AFCH_7_3_0      -1.0
    af_7_3_1          AFCH_7_3_1      1.0
    af_7_3_1          AFO_7_3_1       1.0
    af_7_3_1          GAP_7_3_1       -1.0
    bf_7_3_2          OBJ           0.0
    bf_7_3_2          BFCH_7_3_2      1.0
    bf_7_3_2          BFO_7_3_2       1.0
    bf_7_3_2          BFCH_7_3_3      -1.0
    bf_7_3_2          GAP_7_3_2       -1.0
    af_7_3_2          OBJ           0.0
    af_7_3_2          AFCH_7_3_1      -1.0
    af_7_3_2          AFCH_7_3_2      1.0
    af_7_3_2          AFO_7_3_2       1.0
    af_7_3_2          GAP_7_3_2       -1.0
    bf_7_3_3          OBJ           0.0
    bf_7_3_3          BFCH_7_3_3      1.0
    bf_7_3_3          BFO_7_3_3       1.0
    bf_7_3_3          BFCH_7_3_4      -1.0
    bf_7_3_3          GAP_7_3_3       -1.0
    af_7_3_3          OBJ           0.0
    af_7_3_3          AFCH_7_3_2      -1.0
    af_7_3_3          AFCH_7_3_3      1.0
    af_7_3_3          AFO_7_3_3       1.0
    af_7_3_3          GAP_7_3_3       -1.0
    bf_7_3_4          OBJ           0.0
    bf_7_3_4          BFCH_7_3_4      1.0
    bf_7_3_4          BFO_7_3_4       1.0
    bf_7_3_4          BFCH_7_3_5      -1.0
    bf_7_3_4          GAP_7_3_4       -1.0
    af_7_3_4          OBJ           0.0
    af_7_3_4          AFCH_7_3_3      -1.0
    af_7_3_4          AFCH_7_3_4      1.0
    af_7_3_4          AFO_7_3_4       1.0
    af_7_3_4          GAP_7_3_4       -1.0
    bf_7_3_5          OBJ           0.0
    bf_7_3_5          BFCH_7_3_5      1.0
    bf_7_3_5          BFO_7_3_5       1.0
    bf_7_3_5          GAP_7_3_5       -1.0
    af_7_3_5          OBJ           0.0
    af_7_3_5          AFCH_7_3_4      -1.0
    af_7_3_5          GAP_7_3_5       -1.0
    bf_7_4_0          OBJ           0.0
    bf_7_4_0          BFCH_7_4_1      -1.0
    bf_7_4_0          GAP_7_4_0       -1.0
    af_7_4_0          OBJ           0.0
    af_7_4_0          AFCH_7_4_0      1.0
    af_7_4_0          AFO_7_4_0       1.0
    af_7_4_0          GAP_7_4_0       -1.0
    bf_7_4_1          OBJ           0.0
    bf_7_4_1          BFCH_7_4_1      1.0
    bf_7_4_1          BFO_7_4_1       1.0
    bf_7_4_1          BFCH_7_4_2      -1.0
    bf_7_4_1          GAP_7_4_1       -1.0
    af_7_4_1          OBJ           0.0
    af_7_4_1          AFCH_7_4_0      -1.0
    af_7_4_1          AFCH_7_4_1      1.0
    af_7_4_1          AFO_7_4_1       1.0
    af_7_4_1          GAP_7_4_1       -1.0
    bf_7_4_2          OBJ           0.0
    bf_7_4_2          BFCH_7_4_2      1.0
    bf_7_4_2          BFO_7_4_2       1.0
    bf_7_4_2          BFCH_7_4_3      -1.0
    bf_7_4_2          GAP_7_4_2       -1.0
    af_7_4_2          OBJ           0.0
    af_7_4_2          AFCH_7_4_1      -1.0
    af_7_4_2          AFCH_7_4_2      1.0
    af_7_4_2          AFO_7_4_2       1.0
    af_7_4_2          GAP_7_4_2       -1.0
    bf_7_4_3          OBJ           0.0
    bf_7_4_3          BFCH_7_4_3      1.0
    bf_7_4_3          BFO_7_4_3       1.0
    bf_7_4_3          BFCH_7_4_4      -1.0
    bf_7_4_3          GAP_7_4_3       -1.0
    af_7_4_3          OBJ           0.0
    af_7_4_3          AFCH_7_4_2      -1.0
    af_7_4_3          AFCH_7_4_3      1.0
    af_7_4_3          AFO_7_4_3       1.0
    af_7_4_3          GAP_7_4_3       -1.0
    bf_7_4_4          OBJ           0.0
    bf_7_4_4          BFCH_7_4_4      1.0
    bf_7_4_4          BFO_7_4_4       1.0
    bf_7_4_4          BFCH_7_4_5      -1.0
    bf_7_4_4          GAP_7_4_4       -1.0
    af_7_4_4          OBJ           0.0
    af_7_4_4          AFCH_7_4_3      -1.0
    af_7_4_4          AFCH_7_4_4      1.0
    af_7_4_4          AFO_7_4_4       1.0
    af_7_4_4          GAP_7_4_4       -1.0
    bf_7_4_5          OBJ           0.0
    bf_7_4_5          BFCH_7_4_5      1.0
    bf_7_4_5          BFO_7_4_5       1.0
    bf_7_4_5          GAP_7_4_5       -1.0
    af_7_4_5          OBJ           0.0
    af_7_4_5          AFCH_7_4_4      -1.0
    af_7_4_5          GAP_7_4_5       -1.0
    gp_0_0_0          OBJ           1.0
    gp_0_0_0          GAP_0_0_0       1.0
    gp_0_0_1          OBJ           1.0
    gp_0_0_1          GAP_0_0_1       1.0
    gp_0_0_2          OBJ           1.0
    gp_0_0_2          GAP_0_0_2       1.0
    gp_0_0_3          OBJ           1.0
    gp_0_0_3          GAP_0_0_3       1.0
    gp_0_0_4          OBJ           1.0
    gp_0_0_4          GAP_0_0_4       1.0
    gp_0_0_5          OBJ           1.0
    gp_0_0_5          GAP_0_0_5       1.0
    gp_0_1_0          OBJ           1.0
    gp_0_1_0          GAP_0_1_0       1.0
    gp_0_1_1          OBJ           1.0
    gp_0_1_1          GAP_0_1_1       1.0
    gp_0_1_2          OBJ           1.0
    gp_0_1_2          GAP_0_1_2       1.0
    gp_0_1_3          OBJ           1.0
    gp_0_1_3          GAP_0_1_3       1.0
    gp_0_1_4          OBJ           1.0
    gp_0_1_4          GAP_0_1_4       1.0
    gp_0_1_5          OBJ           1.0
    gp_0_1_5          GAP_0_1_5       1.0
    gp_0_2_0          OBJ           1.0
    gp_0_2_0          GAP_0_2_0       1.0
    gp_0_2_1          OBJ           1.0
    gp_0_2_1          GAP_0_2_1       1.0
    gp_0_2_2          OBJ           1.0
    gp_0_2_2          GAP_0_2_2       1.0
    gp_0_2_3          OBJ           1.0
    gp_0_2_3          GAP_0_2_3       1.0
    gp_0_2_4          OBJ           1.0
    gp_0_2_4          GAP_0_2_4       1.0
    gp_0_2_5          OBJ           1.0
    gp_0_2_5          GAP_0_2_5       1.0
    gp_0_3_0          OBJ           1.0
    gp_0_3_0          GAP_0_3_0       1.0
    gp_0_3_1          OBJ           1.0
    gp_0_3_1          GAP_0_3_1       1.0
    gp_0_3_2          OBJ           1.0
    gp_0_3_2          GAP_0_3_2       1.0
    gp_0_3_3          OBJ           1.0
    gp_0_3_3          GAP_0_3_3       1.0
    gp_0_3_4          OBJ           1.0
    gp_0_3_4          GAP_0_3_4       1.0
    gp_0_3_5          OBJ           1.0
    gp_0_3_5          GAP_0_3_5       1.0
    gp_0_4_0          OBJ           1.0
    gp_0_4_0          GAP_0_4_0       1.0
    gp_0_4_1          OBJ           1.0
    gp_0_4_1          GAP_0_4_1       1.0
    gp_0_4_2          OBJ           1.0
    gp_0_4_2          GAP_0_4_2       1.0
    gp_0_4_3          OBJ           1.0
    gp_0_4_3          GAP_0_4_3       1.0
    gp_0_4_4          OBJ           1.0
    gp_0_4_4          GAP_0_4_4       1.0
    gp_0_4_5          OBJ           1.0
    gp_0_4_5          GAP_0_4_5       1.0
    gp_1_0_0          OBJ           1.0
    gp_1_0_0          GAP_1_0_0       1.0
    gp_1_0_1          OBJ           1.0
    gp_1_0_1          GAP_1_0_1       1.0
    gp_1_0_2          OBJ           1.0
    gp_1_0_2          GAP_1_0_2       1.0
    gp_1_0_3          OBJ           1.0
    gp_1_0_3          GAP_1_0_3       1.0
    gp_1_0_4          OBJ           1.0
    gp_1_0_4          GAP_1_0_4       1.0
    gp_1_0_5          OBJ           1.0
    gp_1_0_5          GAP_1_0_5       1.0
    gp_1_1_0          OBJ           1.0
    gp_1_1_0          GAP_1_1_0       1.0
    gp_1_1_1          OBJ           1.0
    gp_1_1_1          GAP_1_1_1       1.0
    gp_1_1_2          OBJ           1.0
    gp_1_1_2          GAP_1_1_2       1.0
    gp_1_1_3          OBJ           1.0
    gp_1_1_3          GAP_1_1_3       1.0
    gp_1_1_4          OBJ           1.0
    gp_1_1_4          GAP_1_1_4       1.0
    gp_1_1_5          OBJ           1.0
    gp_1_1_5          GAP_1_1_5       1.0
    gp_1_2_0          OBJ           1.0
    gp_1_2_0          GAP_1_2_0       1.0
    gp_1_2_1          OBJ           1.0
    gp_1_2_1          GAP_1_2_1       1.0
    gp_1_2_2          OBJ           1.0
    gp_1_2_2          GAP_1_2_2       1.0
    gp_1_2_3          OBJ           1.0
    gp_1_2_3          GAP_1_2_3       1.0
    gp_1_2_4          OBJ           1.0
    gp_1_2_4          GAP_1_2_4       1.0
    gp_1_2_5          OBJ           1.0
    gp_1_2_5          GAP_1_2_5       1.0
    gp_1_3_0          OBJ           1.0
    gp_1_3_0          GAP_1_3_0       1.0
    gp_1_3_1          OBJ           1.0
    gp_1_3_1          GAP_1_3_1       1.0
    gp_1_3_2          OBJ           1.0
    gp_1_3_2          GAP_1_3_2       1.0
    gp_1_3_3          OBJ           1.0
    gp_1_3_3          GAP_1_3_3       1.0
    gp_1_3_4          OBJ           1.0
    gp_1_3_4          GAP_1_3_4       1.0
    gp_1_3_5          OBJ           1.0
    gp_1_3_5          GAP_1_3_5       1.0
    gp_1_4_0          OBJ           1.0
    gp_1_4_0          GAP_1_4_0       1.0
    gp_1_4_1          OBJ           1.0
    gp_1_4_1          GAP_1_4_1       1.0
    gp_1_4_2          OBJ           1.0
    gp_1_4_2          GAP_1_4_2       1.0
    gp_1_4_3          OBJ           1.0
    gp_1_4_3          GAP_1_4_3       1.0
    gp_1_4_4          OBJ           1.0
    gp_1_4_4          GAP_1_4_4       1.0
    gp_1_4_5          OBJ           1.0
    gp_1_4_5          GAP_1_4_5       1.0
    gp_2_0_0          OBJ           1.0
    gp_2_0_0          GAP_2_0_0       1.0
    gp_2_0_1          OBJ           1.0
    gp_2_0_1          GAP_2_0_1       1.0
    gp_2_0_2          OBJ           1.0
    gp_2_0_2          GAP_2_0_2       1.0
    gp_2_0_3          OBJ           1.0
    gp_2_0_3          GAP_2_0_3       1.0
    gp_2_0_4          OBJ           1.0
    gp_2_0_4          GAP_2_0_4       1.0
    gp_2_0_5          OBJ           1.0
    gp_2_0_5          GAP_2_0_5       1.0
    gp_2_1_0          OBJ           1.0
    gp_2_1_0          GAP_2_1_0       1.0
    gp_2_1_1          OBJ           1.0
    gp_2_1_1          GAP_2_1_1       1.0
    gp_2_1_2          OBJ           1.0
    gp_2_1_2          GAP_2_1_2       1.0
    gp_2_1_3          OBJ           1.0
    gp_2_1_3          GAP_2_1_3       1.0
    gp_2_1_4          OBJ           1.0
    gp_2_1_4          GAP_2_1_4       1.0
    gp_2_1_5          OBJ           1.0
    gp_2_1_5          GAP_2_1_5       1.0
    gp_2_2_0          OBJ           1.0
    gp_2_2_0          GAP_2_2_0       1.0
    gp_2_2_1          OBJ           1.0
    gp_2_2_1          GAP_2_2_1       1.0
    gp_2_2_2          OBJ           1.0
    gp_2_2_2          GAP_2_2_2       1.0
    gp_2_2_3          OBJ           1.0
    gp_2_2_3          GAP_2_2_3       1.0
    gp_2_2_4          OBJ           1.0
    gp_2_2_4          GAP_2_2_4       1.0
    gp_2_2_5          OBJ           1.0
    gp_2_2_5          GAP_2_2_5       1.0
    gp_2_3_0          OBJ           1.0
    gp_2_3_0          GAP_2_3_0       1.0
    gp_2_3_1          OBJ           1.0
    gp_2_3_1          GAP_2_3_1       1.0
    gp_2_3_2          OBJ           1.0
    gp_2_3_2          GAP_2_3_2       1.0
    gp_2_3_3          OBJ           1.0
    gp_2_3_3          GAP_2_3_3       1.0
    gp_2_3_4          OBJ           1.0
    gp_2_3_4          GAP_2_3_4       1.0
    gp_2_3_5          OBJ           1.0
    gp_2_3_5          GAP_2_3_5       1.0
    gp_2_4_0          OBJ           1.0
    gp_2_4_0          GAP_2_4_0       1.0
    gp_2_4_1          OBJ           1.0
    gp_2_4_1          GAP_2_4_1       1.0
    gp_2_4_2          OBJ           1.0
    gp_2_4_2          GAP_2_4_2       1.0
    gp_2_4_3          OBJ           1.0
    gp_2_4_3          GAP_2_4_3       1.0
    gp_2_4_4          OBJ           1.0
    gp_2_4_4          GAP_2_4_4       1.0
    gp_2_4_5          OBJ           1.0
    gp_2_4_5          GAP_2_4_5       1.0
    gp_3_0_0          OBJ           1.0
    gp_3_0_0          GAP_3_0_0       1.0
    gp_3_0_1          OBJ           1.0
    gp_3_0_1          GAP_3_0_1       1.0
    gp_3_0_2          OBJ           1.0
    gp_3_0_2          GAP_3_0_2       1.0
    gp_3_0_3          OBJ           1.0
    gp_3_0_3          GAP_3_0_3       1.0
    gp_3_0_4          OBJ           1.0
    gp_3_0_4          GAP_3_0_4       1.0
    gp_3_0_5          OBJ           1.0
    gp_3_0_5          GAP_3_0_5       1.0
    gp_3_1_0          OBJ           1.0
    gp_3_1_0          GAP_3_1_0       1.0
    gp_3_1_1          OBJ           1.0
    gp_3_1_1          GAP_3_1_1       1.0
    gp_3_1_2          OBJ           1.0
    gp_3_1_2          GAP_3_1_2       1.0
    gp_3_1_3          OBJ           1.0
    gp_3_1_3          GAP_3_1_3       1.0
    gp_3_1_4          OBJ           1.0
    gp_3_1_4          GAP_3_1_4       1.0
    gp_3_1_5          OBJ           1.0
    gp_3_1_5          GAP_3_1_5       1.0
    gp_3_2_0          OBJ           1.0
    gp_3_2_0          GAP_3_2_0       1.0
    gp_3_2_1          OBJ           1.0
    gp_3_2_1          GAP_3_2_1       1.0
    gp_3_2_2          OBJ           1.0
    gp_3_2_2          GAP_3_2_2       1.0
    gp_3_2_3          OBJ           1.0
    gp_3_2_3          GAP_3_2_3       1.0
    gp_3_2_4          OBJ           1.0
    gp_3_2_4          GAP_3_2_4       1.0
    gp_3_2_5          OBJ           1.0
    gp_3_2_5          GAP_3_2_5       1.0
    gp_3_3_0          OBJ           1.0
    gp_3_3_0          GAP_3_3_0       1.0
    gp_3_3_1          OBJ           1.0
    gp_3_3_1          GAP_3_3_1       1.0
    gp_3_3_2          OBJ           1.0
    gp_3_3_2          GAP_3_3_2       1.0
    gp_3_3_3          OBJ           1.0
    gp_3_3_3          GAP_3_3_3       1.0
    gp_3_3_4          OBJ           1.0
    gp_3_3_4          GAP_3_3_4       1.0
    gp_3_3_5          OBJ           1.0
    gp_3_3_5          GAP_3_3_5       1.0
    gp_3_4_0          OBJ           1.0
    gp_3_4_0          GAP_3_4_0       1.0
    gp_3_4_1          OBJ           1.0
    gp_3_4_1          GAP_3_4_1       1.0
    gp_3_4_2          OBJ           1.0
    gp_3_4_2          GAP_3_4_2       1.0
    gp_3_4_3          OBJ           1.0
    gp_3_4_3          GAP_3_4_3       1.0
    gp_3_4_4          OBJ           1.0
    gp_3_4_4          GAP_3_4_4       1.0
    gp_3_4_5          OBJ           1.0
    gp_3_4_5          GAP_3_4_5       1.0
    gp_4_0_0          OBJ           1.0
    gp_4_0_0          GAP_4_0_0       1.0
    gp_4_0_1          OBJ           1.0
    gp_4_0_1          GAP_4_0_1       1.0
    gp_4_0_2          OBJ           1.0
    gp_4_0_2          GAP_4_0_2       1.0
    gp_4_0_3          OBJ           1.0
    gp_4_0_3          GAP_4_0_3       1.0
    gp_4_0_4          OBJ           1.0
    gp_4_0_4          GAP_4_0_4       1.0
    gp_4_0_5          OBJ           1.0
    gp_4_0_5          GAP_4_0_5       1.0
    gp_4_1_0          OBJ           1.0
    gp_4_1_0          GAP_4_1_0       1.0
    gp_4_1_1          OBJ           1.0
    gp_4_1_1          GAP_4_1_1       1.0
    gp_4_1_2          OBJ           1.0
    gp_4_1_2          GAP_4_1_2       1.0
    gp_4_1_3          OBJ           1.0
    gp_4_1_3          GAP_4_1_3       1.0
    gp_4_1_4          OBJ           1.0
    gp_4_1_4          GAP_4_1_4       1.0
    gp_4_1_5          OBJ           1.0
    gp_4_1_5          GAP_4_1_5       1.0
    gp_4_2_0          OBJ           1.0
    gp_4_2_0          GAP_4_2_0       1.0
    gp_4_2_1          OBJ           1.0
    gp_4_2_1          GAP_4_2_1       1.0
    gp_4_2_2          OBJ           1.0
    gp_4_2_2          GAP_4_2_2       1.0
    gp_4_2_3          OBJ           1.0
    gp_4_2_3          GAP_4_2_3       1.0
    gp_4_2_4          OBJ           1.0
    gp_4_2_4          GAP_4_2_4       1.0
    gp_4_2_5          OBJ           1.0
    gp_4_2_5          GAP_4_2_5       1.0
    gp_4_3_0          OBJ           1.0
    gp_4_3_0          GAP_4_3_0       1.0
    gp_4_3_1          OBJ           1.0
    gp_4_3_1          GAP_4_3_1       1.0
    gp_4_3_2          OBJ           1.0
    gp_4_3_2          GAP_4_3_2       1.0
    gp_4_3_3          OBJ           1.0
    gp_4_3_3          GAP_4_3_3       1.0
    gp_4_3_4          OBJ           1.0
    gp_4_3_4          GAP_4_3_4       1.0
    gp_4_3_5          OBJ           1.0
    gp_4_3_5          GAP_4_3_5       1.0
    gp_4_4_0          OBJ           1.0
    gp_4_4_0          GAP_4_4_0       1.0
    gp_4_4_1          OBJ           1.0
    gp_4_4_1          GAP_4_4_1       1.0
    gp_4_4_2          OBJ           1.0
    gp_4_4_2          GAP_4_4_2       1.0
    gp_4_4_3          OBJ           1.0
    gp_4_4_3          GAP_4_4_3       1.0
    gp_4_4_4          OBJ           1.0
    gp_4_4_4          GAP_4_4_4       1.0
    gp_4_4_5          OBJ           1.0
    gp_4_4_5          GAP_4_4_5       1.0
    gp_5_0_0          OBJ           1.0
    gp_5_0_0          GAP_5_0_0       1.0
    gp_5_0_1          OBJ           1.0
    gp_5_0_1          GAP_5_0_1       1.0
    gp_5_0_2          OBJ           1.0
    gp_5_0_2          GAP_5_0_2       1.0
    gp_5_0_3          OBJ           1.0
    gp_5_0_3          GAP_5_0_3       1.0
    gp_5_0_4          OBJ           1.0
    gp_5_0_4          GAP_5_0_4       1.0
    gp_5_0_5          OBJ           1.0
    gp_5_0_5          GAP_5_0_5       1.0
    gp_5_1_0          OBJ           1.0
    gp_5_1_0          GAP_5_1_0       1.0
    gp_5_1_1          OBJ           1.0
    gp_5_1_1          GAP_5_1_1       1.0
    gp_5_1_2          OBJ           1.0
    gp_5_1_2          GAP_5_1_2       1.0
    gp_5_1_3          OBJ           1.0
    gp_5_1_3          GAP_5_1_3       1.0
    gp_5_1_4          OBJ           1.0
    gp_5_1_4          GAP_5_1_4       1.0
    gp_5_1_5          OBJ           1.0
    gp_5_1_5          GAP_5_1_5       1.0
    gp_5_2_0          OBJ           1.0
    gp_5_2_0          GAP_5_2_0       1.0
    gp_5_2_1          OBJ           1.0
    gp_5_2_1          GAP_5_2_1       1.0
    gp_5_2_2          OBJ           1.0
    gp_5_2_2          GAP_5_2_2       1.0
    gp_5_2_3          OBJ           1.0
    gp_5_2_3          GAP_5_2_3       1.0
    gp_5_2_4          OBJ           1.0
    gp_5_2_4          GAP_5_2_4       1.0
    gp_5_2_5          OBJ           1.0
    gp_5_2_5          GAP_5_2_5       1.0
    gp_5_3_0          OBJ           1.0
    gp_5_3_0          GAP_5_3_0       1.0
    gp_5_3_1          OBJ           1.0
    gp_5_3_1          GAP_5_3_1       1.0
    gp_5_3_2          OBJ           1.0
    gp_5_3_2          GAP_5_3_2       1.0
    gp_5_3_3          OBJ           1.0
    gp_5_3_3          GAP_5_3_3       1.0
    gp_5_3_4          OBJ           1.0
    gp_5_3_4          GAP_5_3_4       1.0
    gp_5_3_5          OBJ           1.0
    gp_5_3_5          GAP_5_3_5       1.0
    gp_5_4_0          OBJ           1.0
    gp_5_4_0          GAP_5_4_0       1.0
    gp_5_4_1          OBJ           1.0
    gp_5_4_1          GAP_5_4_1       1.0
    gp_5_4_2          OBJ           1.0
    gp_5_4_2          GAP_5_4_2       1.0
    gp_5_4_3          OBJ           1.0
    gp_5_4_3          GAP_5_4_3       1.0
    gp_5_4_4          OBJ           1.0
    gp_5_4_4          GAP_5_4_4       1.0
    gp_5_4_5          OBJ           1.0
    gp_5_4_5          GAP_5_4_5       1.0
    gp_6_0_0          OBJ           1.0
    gp_6_0_0          GAP_6_0_0       1.0
    gp_6_0_1          OBJ           1.0
    gp_6_0_1          GAP_6_0_1       1.0
    gp_6_0_2          OBJ           1.0
    gp_6_0_2          GAP_6_0_2       1.0
    gp_6_0_3          OBJ           1.0
    gp_6_0_3          GAP_6_0_3       1.0
    gp_6_0_4          OBJ           1.0
    gp_6_0_4          GAP_6_0_4       1.0
    gp_6_0_5          OBJ           1.0
    gp_6_0_5          GAP_6_0_5       1.0
    gp_6_1_0          OBJ           1.0
    gp_6_1_0          GAP_6_1_0       1.0
    gp_6_1_1          OBJ           1.0
    gp_6_1_1          GAP_6_1_1       1.0
    gp_6_1_2          OBJ           1.0
    gp_6_1_2          GAP_6_1_2       1.0
    gp_6_1_3          OBJ           1.0
    gp_6_1_3          GAP_6_1_3       1.0
    gp_6_1_4          OBJ           1.0
    gp_6_1_4          GAP_6_1_4       1.0
    gp_6_1_5          OBJ           1.0
    gp_6_1_5          GAP_6_1_5       1.0
    gp_6_2_0          OBJ           1.0
    gp_6_2_0          GAP_6_2_0       1.0
    gp_6_2_1          OBJ           1.0
    gp_6_2_1          GAP_6_2_1       1.0
    gp_6_2_2          OBJ           1.0
    gp_6_2_2          GAP_6_2_2       1.0
    gp_6_2_3          OBJ           1.0
    gp_6_2_3          GAP_6_2_3       1.0
    gp_6_2_4          OBJ           1.0
    gp_6_2_4          GAP_6_2_4       1.0
    gp_6_2_5          OBJ           1.0
    gp_6_2_5          GAP_6_2_5       1.0
    gp_6_3_0          OBJ           1.0
    gp_6_3_0          GAP_6_3_0       1.0
    gp_6_3_1          OBJ           1.0
    gp_6_3_1          GAP_6_3_1       1.0
    gp_6_3_2          OBJ           1.0
    gp_6_3_2          GAP_6_3_2       1.0
    gp_6_3_3          OBJ           1.0
    gp_6_3_3          GAP_6_3_3       1.0
    gp_6_3_4          OBJ           1.0
    gp_6_3_4          GAP_6_3_4       1.0
    gp_6_3_5          OBJ           1.0
    gp_6_3_5          GAP_6_3_5       1.0
    gp_6_4_0          OBJ           1.0
    gp_6_4_0          GAP_6_4_0       1.0
    gp_6_4_1          OBJ           1.0
    gp_6_4_1          GAP_6_4_1       1.0
    gp_6_4_2          OBJ           1.0
    gp_6_4_2          GAP_6_4_2       1.0
    gp_6_4_3          OBJ           1.0
    gp_6_4_3          GAP_6_4_3       1.0
    gp_6_4_4          OBJ           1.0
    gp_6_4_4          GAP_6_4_4       1.0
    gp_6_4_5          OBJ           1.0
    gp_6_4_5          GAP_6_4_5       1.0
    gp_7_0_0          OBJ           1.0
    gp_7_0_0          GAP_7_0_0       1.0
    gp_7_0_1          OBJ           1.0
    gp_7_0_1          GAP_7_0_1       1.0
    gp_7_0_2          OBJ           1.0
    gp_7_0_2          GAP_7_0_2       1.0
    gp_7_0_3          OBJ           1.0
    gp_7_0_3          GAP_7_0_3       1.0
    gp_7_0_4          OBJ           1.0
    gp_7_0_4          GAP_7_0_4       1.0
    gp_7_0_5          OBJ           1.0
    gp_7_0_5          GAP_7_0_5       1.0
    gp_7_1_0          OBJ           1.0
    gp_7_1_0          GAP_7_1_0       1.0
    gp_7_1_1          OBJ           1.0
    gp_7_1_1          GAP_7_1_1       1.0
    gp_7_1_2          OBJ           1.0
    gp_7_1_2          GAP_7_1_2       1.0
    gp_7_1_3          OBJ           1.0
    gp_7_1_3          GAP_7_1_3       1.0
    gp_7_1_4          OBJ           1.0
    gp_7_1_4          GAP_7_1_4       1.0
    gp_7_1_5          OBJ           1.0
    gp_7_1_5          GAP_7_1_5       1.0
    gp_7_2_0          OBJ           1.0
    gp_7_2_0          GAP_7_2_0       1.0
    gp_7_2_1          OBJ           1.0
    gp_7_2_1          GAP_7_2_1       1.0
    gp_7_2_2          OBJ           1.0
    gp_7_2_2          GAP_7_2_2       1.0
    gp_7_2_3          OBJ           1.0
    gp_7_2_3          GAP_7_2_3       1.0
    gp_7_2_4          OBJ           1.0
    gp_7_2_4          GAP_7_2_4       1.0
    gp_7_2_5          OBJ           1.0
    gp_7_2_5          GAP_7_2_5       1.0
    gp_7_3_0          OBJ           1.0
    gp_7_3_0          GAP_7_3_0       1.0
    gp_7_3_1          OBJ           1.0
    gp_7_3_1          GAP_7_3_1       1.0
    gp_7_3_2          OBJ           1.0
    gp_7_3_2          GAP_7_3_2       1.0
    gp_7_3_3          OBJ           1.0
    gp_7_3_3          GAP_7_3_3       1.0
    gp_7_3_4          OBJ           1.0
    gp_7_3_4          GAP_7_3_4       1.0
    gp_7_3_5          OBJ           1.0
    gp_7_3_5          GAP_7_3_5       1.0
    gp_7_4_0          OBJ           1.0
    gp_7_4_0          GAP_7_4_0       1.0
    gp_7_4_1          OBJ           1.0
    gp_7_4_1          GAP_7_4_1       1.0
    gp_7_4_2          OBJ           1.0
    gp_7_4_2          GAP_7_4_2       1.0
    gp_7_4_3          OBJ           1.0
    gp_7_4_3          GAP_7_4_3       1.0
    gp_7_4_4          OBJ           1.0
    gp_7_4_4          GAP_7_4_4       1.0
    gp_7_4_5          OBJ           1.0
    gp_7_4_5          GAP_7_4_5       1.0
RHS
    RHS           DAY_0_1_0       1.0
    RHS           DAY_0_1_1       1.0
    RHS           DAY_0_1_2       1.0
    RHS           DAY_0_1_3       1.0
    RHS           DAY_0_1_4       1.0
    RHS           REQ_0_1         2.0
    RHS           DAY_0_3_0       1.0
    RHS           DAY_0_3_1       1.0
    RHS           DAY_0_3_2       1.0
    RHS           DAY_0_3_3       1.0
    RHS           DAY_0_3_4       1.0
    RHS           REQ_0_3         4.0
    RHS           DAY_0_4_0       1.0
    RHS           DAY_0_4_1       1.0
    RHS           DAY_0_4_2       1.0
    RHS           DAY_0_4_3       1.0
    RHS           DAY_0_4_4       1.0
    RHS           REQ_0_4         3.0
    RHS           DAY_0_5_0       1.0
    RHS           DAY_0_5_1       1.0
    RHS           DAY_0_5_2       1.0
    RHS           DAY_0_5_3       1.0
    RHS           DAY_0_5_4       1.0
    RHS           REQ_0_5         2.0
    RHS           DAY_1_2_0       1.0
    RHS           DAY_1_2_1       1.0
    RHS           DAY_1_2_2       1.0
    RHS           DAY_1_2_3       1.0
    RHS           DAY_1_2_4       1.0
    RHS           REQ_1_2         3.0
    RHS           DAY_1_5_0       1.0
    RHS           DAY_1_5_1       1.0
    RHS           DAY_1_5_2       1.0
    RHS           DAY_1_5_3       1.0
    RHS           DAY_1_5_4       1.0
    RHS           REQ_1_5         4.0
    RHS           DAY_1_6_0       1.0
    RHS           DAY_1_6_1       1.0
    RHS           DAY_1_6_2       1.0
    RHS           DAY_1_6_3       1.0
    RHS           DAY_1_6_4       1.0
    RHS           REQ_1_6         4.0
    RHS           DAY_1_7_0       1.0
    RHS           DAY_1_7_1       1.0
    RHS           DAY_1_7_2       1.0
    RHS           DAY_1_7_3       1.0
    RHS           DAY_1_7_4       1.0
    RHS           REQ_1_7         4.0
    RHS           DAY_2_0_0       1.0
    RHS           DAY_2_0_1       1.0
    RHS           DAY_2_0_2       1.0
    RHS           DAY_2_0_3       1.0
    RHS           DAY_2_0_4       1.0
    RHS           REQ_2_0         2.0
    RHS           DAY_2_2_0       1.0
    RHS           DAY_2_2_1       1.0
    RHS           DAY_2_2_2       1.0
    RHS           DAY_2_2_3       1.0
    RHS           DAY_2_2_4       1.0
    RHS           REQ_2_2         4.0
    RHS           DAY_2_3_0       1.0
    RHS           DAY_2_3_1       1.0
    RHS           DAY_2_3_2       1.0
    RHS           DAY_2_3_3       1.0
    RHS           DAY_2_3_4       1.0
    RHS           REQ_2_3         2.0
    RHS           DAY_2_5_0       1.0
    RHS           DAY_2_5_1       1.0
    RHS           DAY_2_5_2       1.0
    RHS           DAY_2_5_3       1.0
    RHS           DAY_2_5_4       1.0
    RHS           REQ_2_5         3.0
    RHS           DAY_2_6_0       1.0
    RHS           DAY_2_6_1       1.0
    RHS           DAY_2_6_2       1.0
    RHS           DAY_2_6_3       1.0
    RHS           DAY_2_6_4       1.0
    RHS           REQ_2_6         3.0
    RHS           DAY_3_2_0       1.0
    RHS           DAY_3_2_1       1.0
    RHS           DAY_3_2_2       1.0
    RHS           DAY_3_2_3       1.0
    RHS           DAY_3_2_4       1.0
    RHS           REQ_3_2         3.0
    RHS           DAY_3_5_0       1.0
    RHS           DAY_3_5_1       1.0
    RHS           DAY_3_5_2       1.0
    RHS           DAY_3_5_3       1.0
    RHS           DAY_3_5_4       1.0
    RHS           REQ_3_5         4.0
    RHS           DAY_3_6_0       1.0
    RHS           DAY_3_6_1       1.0
    RHS           DAY_3_6_2       1.0
    RHS           DAY_3_6_3       1.0
    RHS           DAY_3_6_4       1.0
    RHS           REQ_3_6         4.0
    RHS           DAY_3_7_0       1.0
    RHS           DAY_3_7_1       1.0
    RHS           DAY_3_7_2       1.0
    RHS           DAY_3_7_3       1.0
    RHS           DAY_3_7_4       1.0
    RHS           REQ_3_7         3.0
    RHS           DAY_4_2_0       1.0
    RHS           DAY_4_2_1       1.0
    RHS           DAY_4_2_2       1.0
    RHS           DAY_4_2_3       1.0
    RHS           DAY_4_2_4       1.0
    RHS           REQ_4_2         4.0
    RHS           DAY_4_3_0       1.0
    RHS           DAY_4_3_1       1.0
    RHS           DAY_4_3_2       1.0
    RHS           DAY_4_3_3       1.0
    RHS           DAY_4_3_4       1.0
    RHS           REQ_4_3         3.0
    RHS           DAY_4_4_0       1.0
    RHS           DAY_4_4_1       1.0
    RHS           DAY_4_4_2       1.0
    RHS           DAY_4_4_3       1.0
    RHS           DAY_4_4_4       1.0
    RHS           REQ_4_4         3.0
    RHS           DAY_4_5_0       1.0
    RHS           DAY_4_5_1       1.0
    RHS           DAY_4_5_2       1.0
    RHS           DAY_4_5_3       1.0
    RHS           DAY_4_5_4       1.0
    RHS           REQ_4_5         4.0
    RHS           DAY_4_6_0       1.0
    RHS           DAY_4_6_1       1.0
    RHS           DAY_4_6_2       1.0
    RHS           DAY_4_6_3       1.0
    RHS           DAY_4_6_4       1.0
    RHS           REQ_4_6         3.0
    RHS           DAY_4_7_0       1.0
    RHS           DAY_4_7_1       1.0
    RHS           DAY_4_7_2       1.0
    RHS           DAY_4_7_3       1.0
    RHS           DAY_4_7_4       1.0
    RHS           REQ_4_7         4.0
    RHS           DAY_5_0_0       1.0
    RHS           DAY_5_0_1       1.0
    RHS           DAY_5_0_2       1.0
    RHS           DAY_5_0_3       1.0
    RHS           DAY_5_0_4       1.0
    RHS           REQ_5_0         2.0
    RHS           DAY_5_1_0       1.0
    RHS           DAY_5_1_1       1.0
    RHS           DAY_5_1_2       1.0
    RHS           DAY_5_1_3       1.0
    RHS           DAY_5_1_4       1.0
    RHS           REQ_5_1         3.0
    RHS           DAY_5_2_0       1.0
    RHS           DAY_5_2_1       1.0
    RHS           DAY_5_2_2       1.0
    RHS           DAY_5_2_3       1.0
    RHS           DAY_5_2_4       1.0
    RHS           REQ_5_2         3.0
    RHS           DAY_5_3_0       1.0
    RHS           DAY_5_3_1       1.0
    RHS           DAY_5_3_2       1.0
    RHS           DAY_5_3_3       1.0
    RHS           DAY_5_3_4       1.0
    RHS           REQ_5_3         3.0
    RHS           DAY_5_4_0       1.0
    RHS           DAY_5_4_1       1.0
    RHS           DAY_5_4_2       1.0
    RHS           DAY_5_4_3       1.0
    RHS           DAY_5_4_4       1.0
    RHS           REQ_5_4         4.0
    RHS           DAY_5_5_0       1.0
    RHS           DAY_5_5_1       1.0
    RHS           DAY_5_5_2       1.0
    RHS           DAY_5_5_3       1.0
    RHS           DAY_5_5_4       1.0
    RHS           REQ_5_5         4.0
    RHS           OCC_0_0_0       0.0
    RHS           OCC_0_0_1       0.0
    RHS           OCC_0_0_2       0.0
    RHS           OCC_0_0_3       0.0
    RHS           OCC_0_0_4       0.0
    RHS           OCC_0_0_5       0.0
    RHS           OCC_0_1_0       0.0
    RHS           OCC_0_1_1       0.0
    RHS           OCC_0_1_2       0.0
    RHS           OCC_0_1_3       0.0
    RHS           OCC_0_1_4       0.0
    RHS           OCC_0_1_5       0.0
    RHS           OCC_0_2_0       0.0
    RHS           OCC_0_2_1       0.0
    RHS           OCC_0_2_2       0.0
    RHS           OCC_0_2_3       0.0
    RHS           OCC_0_2_4       0.0
    RHS           OCC_0_2_5       0.0
    RHS           OCC_0_3_0       0.0
    RHS           OCC_0_3_1       0.0
    RHS           OCC_0_3_2       0.0
    RHS           OCC_0_3_3       0.0
    RHS           OCC_0_3_4       0.0
    RHS           OCC_0_3_5       0.0
    RHS           OCC_0_4_0       0.0
    RHS           OCC_0_4_1       0.0
    RHS           OCC_0_4_2       0.0
    RHS           OCC_0_4_3       0.0
    RHS           OCC_0_4_4       0.0
    RHS           OCC_0_4_5       0.0
    RHS           OCC_1_0_0       0.0
    RHS           OCC_1_0_1       0.0
    RHS           OCC_1_0_2       0.0
    RHS           OCC_1_0_3       0.0
    RHS           OCC_1_0_4       0.0
    RHS           OCC_1_0_5       0.0
    RHS           OCC_1_1_0       0.0
    RHS           OCC_1_1_1       0.0
    RHS           OCC_1_1_2       0.0
    RHS           OCC_1_1_3       0.0
    RHS           OCC_1_1_4       0.0
    RHS           OCC_1_1_5       0.0
    RHS           OCC_1_2_0       0.0
    RHS           OCC_1_2_1       0.0
    RHS           OCC_1_2_2       0.0
    RHS           OCC_1_2_3       0.0
    RHS           OCC_1_2_4       0.0
    RHS           OCC_1_2_5       0.0
    RHS           OCC_1_3_0       0.0
    RHS           OCC_1_3_1       0.0
    RHS           OCC_1_3_2       0.0
    RHS           OCC_1_3_3       0.0
    RHS           OCC_1_3_4       0.0
    RHS           OCC_1_3_5       0.0
    RHS           OCC_1_4_0       0.0
    RHS           OCC_1_4_1       0.0
    RHS           OCC_1_4_2       0.0
    RHS           OCC_1_4_3       0.0
    RHS           OCC_1_4_4       0.0
    RHS           OCC_1_4_5       0.0
    RHS           OCC_2_0_0       0.0
    RHS           OCC_2_0_1       0.0
    RHS           OCC_2_0_2       0.0
    RHS           OCC_2_0_3       0.0
    RHS           OCC_2_0_4       0.0
    RHS           OCC_2_0_5       0.0
    RHS           OCC_2_1_0       0.0
    RHS           OCC_2_1_1       0.0
    RHS           OCC_2_1_2       0.0
    RHS           OCC_2_1_3       0.0
    RHS           OCC_2_1_4       0.0
    RHS           OCC_2_1_5       0.0
    RHS           OCC_2_2_0       0.0
    RHS           OCC_2_2_1       0.0
    RHS           OCC_2_2_2       0.0
    RHS           OCC_2_2_3       0.0
    RHS           OCC_2_2_4       0.0
    RHS           OCC_2_2_5       0.0
    RHS           OCC_2_3_0       0.0
    RHS           OCC_2_3_1       0.0
    RHS           OCC_2_3_2       0.0
    RHS           OCC_2_3_3       0.0
    RHS           OCC_2_3_4       0.0
    RHS           OCC_2_3_5       0.0
    RHS           OCC_2_4_0       0.0
    RHS           OCC_2_4_1       0.0
    RHS           OCC_2_4_2       0.0
    RHS           OCC_2_4_3       0.0
    RHS           OCC_2_4_4       0.0
    RHS           OCC_2_4_5       0.0
    RHS           OCC_3_0_0       0.0
    RHS           OCC_3_0_1       0.0
    RHS           OCC_3_0_2       0.0
    RHS           OCC_3_0_3       0.0
    RHS           OCC_3_0_4       0.0
    RHS           OCC_3_0_5       0.0
    RHS           OCC_3_1_0       0.0
    RHS           OCC_3_1_1       0.0
    RHS           OCC_3_1_2       0.0
    RHS           OCC_3_1_3       0.0
    RHS           OCC_3_1_4       0.0
    RHS           OCC_3_1_5       0.0
    RHS           OCC_3_2_0       0.0
    RHS           OCC_3_2_1       0.0
    RHS           OCC_3_2_2       0.0
    RHS           OCC_3_2_3       0.0
    RHS           OCC_3_2_4       0.0
    RHS           OCC_3_2_5       0.0
    RHS           OCC_3_3_0       0.0
    RHS           OCC_3_3_1       0.0
    RHS           OCC_3_3_2       0.0
    RHS           OCC_3_3_3       0.0
    RHS           OCC_3_3_4       0.0
    RHS           OCC_3_3_5       0.0
    RHS           OCC_3_4_0       0.0
    RHS           OCC_3_4_1       0.0
    RHS           OCC_3_4_2       0.0
    RHS           OCC_3_4_3       0.0
    RHS           OCC_3_4_4       0.0
    RHS           OCC_3_4_5       0.0
    RHS           OCC_4_0_0       0.0
    RHS           OCC_4_0_1       0.0
    RHS           OCC_4_0_2       0.0
    RHS           OCC_4_0_3       0.0
    RHS           OCC_4_0_4       0.0
    RHS           OCC_4_0_5       0.0
    RHS           OCC_4_1_0       0.0
    RHS           OCC_4_1_1       0.0
    RHS           OCC_4_1_2       0.0
    RHS           OCC_4_1_3       0.0
    RHS           OCC_4_1_4       0.0
    RHS           OCC_4_1_5       0.0
    RHS           OCC_4_2_0       0.0
    RHS           OCC_4_2_1       0.0
    RHS           OCC_4_2_2       0.0
    RHS           OCC_4_2_3       0.0
    RHS           OCC_4_2_4       0.0
    RHS           OCC_4_2_5       0.0
    RHS           OCC_4_3_0       0.0
    RHS           OCC_4_3_1       0.0
    RHS           OCC_4_3_2       0.0
    RHS           OCC_4_3_3       0.0
    RHS           OCC_4_3_4       0.0
    RHS           OCC_4_3_5       0.0
    RHS           OCC_4_4_0       0.0
    RHS           OCC_4_4_1       0.0
    RHS           OCC_4_4_2       0.0
    RHS           OCC_4_4_3       0.0
    RHS           OCC_4_4_4       0.0
    RHS           OCC_4_4_5       0.0
    RHS           OCC_5_0_0       0.0
    RHS           OCC_5_0_1       0.0
    RHS           OCC_5_0_2       0.0
    RHS           OCC_5_0_3       0.0
    RHS           OCC_5_0_4       0.0
    RHS           OCC_5_0_5       0.0
    RHS           OCC_5_1_0       0.0
    RHS           OCC_5_1_1       0.0
    RHS           OCC_5_1_2       0.0
    RHS           OCC_5_1_3       0.0
    RHS           OCC_5_1_4       0.0
    RHS           OCC_5_1_5       0.0
    RHS           OCC_5_2_0       0.0
    RHS           OCC_5_2_1       0.0
    RHS           OCC_5_2_2       0.0
    RHS           OCC_5_2_3       0.0
    RHS           OCC_5_2_4       0.0
    RHS           OCC_5_2_5       0.0
    RHS           OCC_5_3_0       0.0
    RHS           OCC_5_3_1       0.0
    RHS           OCC_5_3_2       0.0
    RHS           OCC_5_3_3       0.0
    RHS           OCC_5_3_4       0.0
    RHS           OCC_5_3_5       0.0
    RHS           OCC_5_4_0       0.0
    RHS           OCC_5_4_1       0.0
    RHS           OCC_5_4_2       0.0
    RHS           OCC_5_4_3       0.0
    RHS           OCC_5_4_4       0.0
    RHS           OCC_5_4_5       0.0
    RHS           OCC_6_0_0       0.0
    RHS           OCC_6_0_1       0.0
    RHS           OCC_6_0_2       0.0
    RHS           OCC_6_0_3       0.0
    RHS           OCC_6_0_4       0.0
    RHS           OCC_6_0_5       0.0
    RHS           OCC_6_1_0       0.0
    RHS           OCC_6_1_1       0.0
    RHS           OCC_6_1_2       0.0
    RHS           OCC_6_1_3       0.0
    RHS           OCC_6_1_4       0.0
    RHS           OCC_6_1_5       0.0
    RHS           OCC_6_2_0       0.0
    RHS           OCC_6_2_1       0.0
    RHS           OCC_6_2_2       0.0
    RHS           OCC_6_2_3       0.0
    RHS           OCC_6_2_4       0.0
    RHS           OCC_6_2_5       0.0
    RHS           OCC_6_3_0       0.0
    RHS           OCC_6_3_1       0.0
    RHS           OCC_6_3_2       0.0
    RHS           OCC_6_3_3       0.0
    RHS           OCC_6_3_4       0.0
    RHS           OCC_6_3_5       0.0
    RHS           OCC_6_4_0       0.0
    RHS           OCC_6_4_1       0.0
    RHS           OCC_6_4_2       0.0
    RHS           OCC_6_4_3       0.0
    RHS           OCC_6_4_4       0.0
    RHS           OCC_6_4_5       0.0
    RHS           OCC_7_0_0       0.0
    RHS           OCC_7_0_1       0.0
    RHS           OCC_7_0_2       0.0
    RHS           OCC_7_0_3       0.0
    RHS           OCC_7_0_4       0.0
    RHS           OCC_7_0_5       0.0
    RHS           OCC_7_1_0       0.0
    RHS           OCC_7_1_1       0.0
    RHS           OCC_7_1_2       0.0
    RHS           OCC_7_1_3       0.0
    RHS           OCC_7_1_4       0.0
    RHS           OCC_7_1_5       0.0
    RHS           OCC_7_2_0       0.0
    RHS           OCC_7_2_1       0.0
    RHS           OCC_7_2_2       0.0
    RHS           OCC_7_2_3       0.0
    RHS           OCC_7_2_4       0.0
    RHS           OCC_7_2_5       0.0
    RHS           OCC_7_3_0       0.0
    RHS           OCC_7_3_1       0.0
    RHS           OCC_7_3_2       0.0
    RHS           OCC_7_3_3       0.0
    RHS           OCC_7_3_4       0.0
    RHS           OCC_7_3_5       0.0
    RHS           OCC_7_4_0       0.0
    RHS           OCC_7_4_1       0.0
    RHS           OCC_7_4_2       0.0
    RHS           OCC_7_4_3       0.0
    RHS           OCC_7_4_4       0.0
    RHS           OCC_7_4_5       0.0
    RHS           CLS_0_0_0       0.0
    RHS           CLS_0_0_1       0.0
    RHS           CLS_0_0_2       0.0
    RHS           CLS_0_0_3       0.0
    RHS           CLS_0_0_4       0.0
    RHS           CLS_0_0_5       0.0
    RHS           CLS_0_1_0       0.0
    RHS           CLS_0_1_1       0.0
    RHS           CLS_0_1_2       0.0
    RHS           CLS_0_1_3       0.0
    RHS           CLS_0_1_4       0.0
    RHS           CLS_0_1_5       0.0
    RHS           CLS_0_2_0       0.0
    RHS           CLS_0_2_1       0.0
    RHS           CLS_0_2_2       0.0
    RHS           CLS_0_2_3       0.0
    RHS           CLS_0_2_4       0.0
    RHS           CLS_0_2_5       0.0
    RHS           CLS_0_3_0       0.0
    RHS           CLS_0_3_1       0.0
    RHS           CLS_0_3_2       0.0
    RHS           CLS_0_3_3       0.0
    RHS           CLS_0_3_4       0.0
    RHS           CLS_0_3_5       0.0
    RHS           CLS_0_4_0       0.0
    RHS           CLS_0_4_1       0.0
    RHS           CLS_0_4_2       0.0
    RHS           CLS_0_4_3       0.0
    RHS           CLS_0_4_4       0.0
    RHS           CLS_0_4_5       0.0
    RHS           CLS_1_0_0       0.0
    RHS           CLS_1_0_1       0.0
    RHS           CLS_1_0_2       0.0
    RHS           CLS_1_0_3       0.0
    RHS           CLS_1_0_4       0.0
    RHS           CLS_1_0_5       0.0
    RHS           CLS_1_1_0       0.0
    RHS           CLS_1_1_1       0.0
    RHS           CLS_1_1_2       0.0
    RHS           CLS_1_1_3       0.0
    RHS           CLS_1_1_4       0.0
    RHS           CLS_1_1_5       0.0
    RHS           CLS_1_2_0       0.0
    RHS           CLS_1_2_1       0.0
    RHS           CLS_1_2_2       0.0
    RHS           CLS_1_2_3       0.0
    RHS           CLS_1_2_4       0.0
    RHS           CLS_1_2_5       0.0
    RHS           CLS_1_3_0       0.0
    RHS           CLS_1_3_1       0.0
    RHS           CLS_1_3_2       0.0
    RHS           CLS_1_3_3       0.0
    RHS           CLS_1_3_4       0.0
    RHS           CLS_1_3_5       0.0
    RHS           CLS_1_4_0       0.0
    RHS           CLS_1_4_1       0.0
    RHS           CLS_1_4_2       0.0
    RHS           CLS_1_4_3       0.0
    RHS           CLS_1_4_4       0.0
    RHS           CLS_1_4_5       0.0
    RHS           CLS_2_0_0       0.0
    RHS           CLS_2_0_1       0.0
    RHS           CLS_2_0_2       0.0
    RHS           CLS_2_0_3       0.0
    RHS           CLS_2_0_4       0.0
    RHS           CLS_2_0_5       0.0
    RHS           CLS_2_1_0       0.0
    RHS           CLS_2_1_1       0.0
    RHS           CLS_2_1_2       0.0
    RHS           CLS_2_1_3       0.0
    RHS           CLS_2_1_4       0.0
    RHS           CLS_2_1_5       0.0
    RHS           CLS_2_2_0       0.0
    RHS           CLS_2_2_1       0.0
    RHS           CLS_2_2_2       0.0
    RHS           CLS_2_2_3       0.0
    RHS           CLS_2_2_4       0.0
    RHS           CLS_2_2_5       0.0
    RHS           CLS_2_3_0       0.0
    RHS           CLS_2_3_1       0.0
    RHS           CLS_2_3_2       0.0
    RHS           CLS_2_3_3       0.0
    RHS           CLS_2_3_4       0.0
    RHS           CLS_2_3_5       0.0
    RHS           CLS_2_4_0       0.0
    RHS           CLS_2_4_1       0.0
    RHS           CLS_2_4_2       0.0
    RHS           CLS_2_4_3       0.0
    RHS           CLS_2_4_4       0.0
    RHS           CLS_2_4_5       0.0
    RHS           CLS_3_0_0       0.0
    RHS           CLS_3_0_1       0.0
    RHS           CLS_3_0_2       0.0
    RHS           CLS_3_0_3       0.0
    RHS           CLS_3_0_4       0.0
    RHS           CLS_3_0_5       0.0
    RHS           CLS_3_1_0       0.0
    RHS           CLS_3_1_1       0.0
    RHS           CLS_3_1_2       0.0
    RHS           CLS_3_1_3       0.0
    RHS           CLS_3_1_4       0.0
    RHS           CLS_3_1_5       0.0
    RHS           CLS_3_2_0       0.0
    RHS           CLS_3_2_1       0.0
    RHS           CLS_3_2_2       0.0
    RHS           CLS_3_2_3       0.0
    RHS           CLS_3_2_4       0.0
    RHS           CLS_3_2_5       0.0
    RHS           CLS_3_3_0       0.0
    RHS           CLS_3_3_1       0.0
    RHS           CLS_3_3_2       0.0
    RHS           CLS_3_3_3       0.0
    RHS           CLS_3_3_4       0.0
    RHS           CLS_3_3_5       0.0
    RHS           CLS_3_4_0       0.0
    RHS           CLS_3_4_1       0.0
    RHS           CLS_3_4_2       0.0
    RHS           CLS_3_4_3       0.0
    RHS           CLS_3_4_4       0.0
    RHS           CLS_3_4_5       0.0
    RHS           CLS_4_0_0       0.0
    RHS           CLS_4_0_1       0.0
    RHS           CLS_4_0_2       0.0
    RHS           CLS_4_0_3       0.0
    RHS           CLS_4_0_4       0.0
    RHS           CLS_4_0_5       0.0
    RHS           CLS_4_1_0       0.0
    RHS           CLS_4_1_1       0.0
    RHS           CLS_4_1_2       0.0
    RHS           CLS_4_1_3       0.0
    RHS           CLS_4_1_4       0.0
    RHS           CLS_4_1_5       0.0
    RHS           CLS_4_2_0       0.0
    RHS           CLS_4_2_1       0.0
    RHS           CLS_4_2_2       0.0
    RHS           CLS_4_2_3       0.0
    RHS           CLS_4_2_4       0.0
    RHS           CLS_4_2_5       0.0
    RHS           CLS_4_3_0       0.0
    RHS           CLS_4_3_1       0.0
    RHS           CLS_4_3_2       0.0
    RHS           CLS_4_3_3       0.0
    RHS           CLS_4_3_4       0.0
    RHS           CLS_4_3_5       0.0
    RHS           CLS_4_4_0       0.0
    RHS           CLS_4_4_1       0.0
    RHS           CLS_4_4_2       0.0
    RHS           CLS_4_4_3       0.0
    RHS           CLS_4_4_4       0.0
    RHS           CLS_4_4_5       0.0
    RHS           CLS_5_0_0       0.0
    RHS           CLS_5_0_1       0.0
    RHS           CLS_5_0_2       0.0
    RHS           CLS_5_0_3       0.0
    RHS           CLS_5_0_4       0.0
    RHS           CLS_5_0_5       0.0
    RHS           CLS_5_1_0       0.0
    RHS           CLS_5_1_1       0.0
    RHS           CLS_5_1_2       0.0
    RHS           CLS_5_1_3       0.0
    RHS           CLS_5_1_4       0.0
    RHS           CLS_5_1_5       0.0
    RHS           CLS_5_2_0       0.0
    RHS           CLS_5_2_1       0.0
    RHS           CLS_5_2_2       0.0
    RHS           CLS_5_2_3       0.0
    RHS           CLS_5_2_4       0.0
    RHS           CLS_5_2_5       0.0
    RHS           CLS_5_3_0       0.0
    RHS           CLS_5_3_1       0.0
    RHS           CLS_5_3_2       0.0
    RHS           CLS_5_3_3       0.0
    RHS           CLS_5_3_4       0.0
    RHS           CLS_5_3_5       0.0
    RHS           CLS_5_4_0       0.0
    RHS           CLS_5_4_1       0.0
    RHS           CLS_5_4_2       0.0
    RHS           CLS_5_4_3       0.0
    RHS           CLS_5_4_4       0.0
    RHS           CLS_5_4_5       0.0
    RHS           WDEF_0_0_0      0.0
    RHS           WDEF_0_0_1      0.0
    RHS           WDEF_0_0_2      0.0
    RHS           WDEF_0_0_3      0.0
    RHS           WDEF_0_0_4      0.0
    RHS           WDEF_0_0_5      0.0
    RHS           WDEF_0_1_0      0.0
    RHS           WDEF_0_1_1      0.0
    RHS           WDEF_0_1_2      0.0
    RHS           WDEF_0_1_3      0.0
    RHS           WDEF_0_1_4      0.0
    RHS           WDEF_0_1_5      0.0
    RHS           WDEF_0_2_0      0.0
    RHS           WDEF_0_2_1      0.0
    RHS           WDEF_0_2_2      0.0
    RHS           WDEF_0_2_3      0.0
    RHS           WDEF_0_2_4      0.0
    RHS           WDEF_0_2_5      0.0
    RHS           WDEF_0_3_0      0.0
    RHS           WDEF_0_3_1      0.0
    RHS           WDEF_0_3_2      0.0
    RHS           WDEF_0_3_3      0.0
    RHS           WDEF_0_3_4      0.0
    RHS           WDEF_0_3_5      0.0
    RHS           WDEF_0_4_0      0.0
    RHS           WDEF_0_4_1      0.0
    RHS           WDEF_0_4_2      0.0
    RHS           WDEF_0_4_3      0.0
    RHS           WDEF_0_4_4      0.0
    RHS           WDEF_0_4_5      0.0
    RHS           WDEF_1_0_0      0.0
    RHS           WDEF_1_0_1      0.0
    RHS           WDEF_1_0_2      0.0
    RHS           WDEF_1_0_3      0.0
    RHS           WDEF_1_0_4      0.0
    RHS           WDEF_1_0_5      0.0
    RHS           WDEF_1_1_0      0.0
    RHS           WDEF_1_1_1      0.0
    RHS           WDEF_1_1_2      0.0
    RHS           WDEF_1_1_3      0.0
    RHS           WDEF_1_1_4      0.0
    RHS           WDEF_1_1_5      0.0
    RHS           WDEF_1_2_0      0.0
    RHS           WDEF_1_2_1      0.0
    RHS           WDEF_1_2_2      0.0
    RHS           WDEF_1_2_3      0.0
    RHS           WDEF_1_2_4      0.0
    RHS           WDEF_1_2_5      0.0
    RHS           WDEF_1_3_0      0.0
    RHS           WDEF_1_3_1      0.0
    RHS           WDEF_1_3_2      0.0
    RHS           WDEF_1_3_3      0.0
    RHS           WDEF_1_3_4      0.0
    RHS           WDEF_1_3_5      0.0
    RHS           WDEF_1_4_0      0.0
    RHS           WDEF_1_4_1      0.0
    RHS           WDEF_1_4_2      0.0
    RHS           WDEF_1_4_3      0.0
    RHS           WDEF_1_4_4      0.0
    RHS           WDEF_1_4_5      0.0
    RHS           WDEF_2_0_0      0.0
    RHS           WDEF_2_0_1      0.0
    RHS           WDEF_2_0_2      0.0
    RHS           WDEF_2_0_3      0.0
    RHS           WDEF_2_0_4      0.0
    RHS           WDEF_2_0_5      0.0
    RHS           WDEF_2_1_0      0.0
    RHS           WDEF_2_1_1      0.0
    RHS           WDEF_2_1_2      0.0
    RHS           WDEF_2_1_3      0.0
    RHS           WDEF_2_1_4      0.0
    RHS           WDEF_2_1_5      0.0
    RHS           WDEF_2_2_0      0.0
    RHS           WDEF_2_2_1      0.0
    RHS           WDEF_2_2_2      0.0
    RHS           WDEF_2_2_3      0.0
    RHS           WDEF_2_2_4      0.0
    RHS           WDEF_2_2_5      0.0
    RHS           WDEF_2_3_0      0.0
    RHS           WDEF_2_3_1      0.0
    RHS           WDEF_2_3_2      0.0
    RHS           WDEF_2_3_3      0.0
    RHS           WDEF_2_3_4      0.0
    RHS           WDEF_2_3_5      0.0
    RHS           WDEF_2_4_0      0.0
    RHS           WDEF_2_4_1      0.0
    RHS           WDEF_2_4_2      0.0
    RHS           WDEF_2_4_3      0.0
    RHS           WDEF_2_4_4      0.0
    RHS           WDEF_2_4_5      0.0
    RHS           WDEF_3_0_0      0.0
    RHS           WDEF_3_0_1      0.0
    RHS           WDEF_3_0_2      0.0
    RHS           WDEF_3_0_3      0.0
    RHS           WDEF_3_0_4      0.0
    RHS           WDEF_3_0_5      0.0
    RHS           WDEF_3_1_0      0.0
    RHS           WDEF_3_1_1      0.0
    RHS           WDEF_3_1_2      0.0
    RHS           WDEF_3_1_3      0.0
    RHS           WDEF_3_1_4      0.0
    RHS           WDEF_3_1_5      0.0
    RHS           WDEF_3_2_0      0.0
    RHS           WDEF_3_2_1      0.0
    RHS           WDEF_3_2_2      0.0
    RHS           WDEF_3_2_3      0.0
    RHS           WDEF_3_2_4      0.0
    RHS           WDEF_3_2_5      0.0
    RHS           WDEF_3_3_0      0.0
    RHS           WDEF_3_3_1      0.0
    RHS           WDEF_3_3_2      0.0
    RHS           WDEF_3_3_3      0.0
    RHS           WDEF_3_3_4      0.0
    RHS           WDEF_3_3_5      0.0
    RHS           WDEF_3_4_0      0.0
    RHS           WDEF_3_4_1      0.0
    RHS           WDEF_3_4_2      0.0
    RHS           WDEF_3_4_3      0.0
    RHS           WDEF_3_4_4      0.0
    RHS           WDEF_3_4_5      0.0
    RHS           WDEF_4_0_0      0.0
    RHS           WDEF_4_0_1      0.0
    RHS           WDEF_4_0_2      0.0
    RHS           WDEF_4_0_3      0.0
    RHS           WDEF_4_0_4      0.0
    RHS           WDEF_4_0_5      0.0
    RHS           WDEF_4_1_0      0.0
    RHS           WDEF_4_1_1      0.0
    RHS           WDEF_4_1_2      0.0
    RHS           WDEF_4_1_3      0.0
    RHS           WDEF_4_1_4      0.0
    RHS           WDEF_4_1_5      0.0
    RHS           WDEF_4_2_0      0.0
    RHS           WDEF_4_2_1      0.0
    RHS           WDEF_4_2_2      0.0
    RHS           WDEF_4_2_3      0.0
    RHS           WDEF_4_2_4      0.0
    RHS           WDEF_4_2_5      0.0
    RHS           WDEF_4_3_0      0.0
    RHS           WDEF_4_3_1      0.0
    RHS           WDEF_4_3_2      0.0
    RHS           WDEF_4_3_3      0.0
    RHS           WDEF_4_3_4      0.0
    RHS           WDEF_4_3_5      0.0
    RHS           WDEF_4_4_0      0.0
    RHS           WDEF_4_4_1      0.0
    RHS           WDEF_4_4_2      0.0
    RHS           WDEF_4_4_3      0.0
    RHS           WDEF_4_4_4      0.0
    RHS           WDEF_4_4_5      0.0
    RHS           WDEF_5_0_0      0.0
    RHS           WDEF_5_0_1      0.0
    RHS           WDEF_5_0_2      0.0
    RHS           WDEF_5_0_3      0.0
    RHS           WDEF_5_0_4      0.0
    RHS           WDEF_5_0_5      0.0
    RHS           WDEF_5_1_0      0.0
    RHS           WDEF_5_1_1      0.0
    RHS           WDEF_5_1_2      0.0
    RHS           WDEF_5_1_3      0.0
    RHS           WDEF_5_1_4      0.0
    RHS           WDEF_5_1_5      0.0
    RHS           WDEF_5_2_0      0.0
    RHS           WDEF_5_2_1      0.0
    RHS           WDEF_5_2_2      0.0
    RHS           WDEF_5_2_3      0.0
    RHS           WDEF_5_2_4      0.0
    RHS           WDEF_5_2_5      0.0
    RHS           WDEF_5_3_0      0.0
    RHS           WDEF_5_3_1      0.0
    RHS           WDEF_5_3_2      0.0
    RHS           WDEF_5_3_3      0.0
    RHS           WDEF_5_3_4      0.0
    RHS           WDEF_5_3_5      0.0
    RHS           WDEF_5_4_0      0.0
    RHS           WDEF_5_4_1      0.0
    RHS           WDEF_5_4_2      0.0
    RHS           WDEF_5_4_3      0.0
    RHS           WDEF_5_4_4      0.0
    RHS           WDEF_5_4_5      0.0
    RHS           WDEF_6_0_0      0.0
    RHS           WDEF_6_0_1      0.0
    RHS           WDEF_6_0_2      0.0
    RHS           WDEF_6_0_3      0.0
    RHS           WDEF_6_0_4      0.0
    RHS           WDEF_6_0_5      0.0
    RHS           WDEF_6_1_0      0.0
    RHS           WDEF_6_1_1      0.0
    RHS           WDEF_6_1_2      0.0
    RHS           WDEF_6_1_3      0.0
    RHS           WDEF_6_1_4      0.0
    RHS           WDEF_6_1_5      0.0
    RHS           WDEF_6_2_0      0.0
    RHS           WDEF_6_2_1      0.0
    RHS           WDEF_6_2_2      0.0
    RHS           WDEF_6_2_3      0.0
    RHS           WDEF_6_2_4      0.0
    RHS           WDEF_6_2_5      0.0
    RHS           WDEF_6_3_0      0.0
    RHS           WDEF_6_3_1      0.0
    RHS           WDEF_6_3_2      0.0
    RHS           WDEF_6_3_3      0.0
    RHS           WDEF_6_3_4      0.0
    RHS           WDEF_6_3_5      0.0
    RHS           WDEF_6_4_0      0.0
    RHS           WDEF_6_4_1      0.0
    RHS           WDEF_6_4_2      0.0
    RHS           WDEF_6_4_3      0.0
    RHS           WDEF_6_4_4      0.0
    RHS           WDEF_6_4_5      0.0
    RHS           WDEF_7_0_0      0.0
    RHS           WDEF_7_0_1      0.0
    RHS           WDEF_7_0_2      0.0
    RHS           WDEF_7_0_3      0.0
    RHS           WDEF_7_0_4      0.0
    RHS           WDEF_7_0_5      0.0
    RHS           WDEF_7_1_0      0.0
    RHS           WDEF_7_1_1      0.0
    RHS           WDEF_7_1_2      0.0
    RHS           WDEF_7_1_3      0.0
    RHS           WDEF_7_1_4      0.0
    RHS           WDEF_7_1_5      0.0
    RHS           WDEF_7_2_0      0.0
    RHS           WDEF_7_2_1      0.0
    RHS           WDEF_7_2_2      0.0
    RHS           WDEF_7_2_3      0.0
    RHS           WDEF_7_2_4      0.0
    RHS           WDEF_7_2_5      0.0
    RHS           WDEF_7_3_0      0.0
    RHS           WDEF_7_3_1      0.0
    RHS           WDEF_7_3_2      0.0
    RHS           WDEF_7_3_3      0.0
    RHS           WDEF_7_3_4      0.0
    RHS           WDEF_7_3_5      0.0
    RHS           WDEF_7_4_0      0.0
    RHS           WDEF_7_4_1      0.0
    RHS           WDEF_7_4_2      0.0
    RHS           WDEF_7_4_3      0.0
    RHS           WDEF_7_4_4      0.0
    RHS           WDEF_7_4_5      0.0
    RHS           AFCH_0_0_0      0.0
    RHS           AFO_0_0_0       0.0
    RHS           BFCH_0_0_1      0.0
    RHS           BFO_0_0_1       0.0
    RHS           AFCH_0_0_1      0.0
    RHS           AFO_0_0_1       0.0
    RHS           BFCH_0_0_2      0.0
    RHS           BFO_0_0_2       0.0
    RHS           AFCH_0_0_2      0.0
    RHS           AFO_0_0_2       0.0
    RHS           BFCH_0_0_3      0.0
    RHS           BFO_0_0_3       0.0
    RHS           AFCH_0_0_3      0.0
    RHS           AFO_0_0_3       0.0
    RHS           BFCH_0_0_4      0.0
    RHS           BFO_0_0_4       0.0
    RHS           AFCH_0_0_4      0.0
    RHS           AFO_0_0_4       0.0
    RHS           BFCH_0_0_5      0.0
    RHS           BFO_0_0_5       0.0
    RHS           AFCH_0_1_0      0.0
    RHS           AFO_0_1_0       0.0
    RHS           BFCH_0_1_1      0.0
    RHS           BFO_0_1_1       0.0
    RHS           AFCH_0_1_1      0.0
    RHS           AFO_0_1_1       0.0
    RHS           BFCH_0_1_2      0.0
    RHS           BFO_0_1_2       0.0
    RHS           AFCH_0_1_2      0.0
    RHS           AFO_0_1_2       0.0
    RHS           BFCH_0_1_3      0.0
    RHS           BFO_0_1_3       0.0
    RHS           AFCH_0_1_3      0.0
    RHS           AFO_0_1_3       0.0
    RHS           BFCH_0_1_4      0.0
    RHS           BFO_0_1_4       0.0
    RHS           AFCH_0_1_4      0.0
    RHS           AFO_0_1_4       0.0
    RHS           BFCH_0_1_5      0.0
    RHS           BFO_0_1_5       0.0
    RHS           AFCH_0_2_0      0.0
    RHS           AFO_0_2_0       0.0
    RHS           BFCH_0_2_1      0.0
    RHS           BFO_0_2_1       0.0
    RHS           AFCH_0_2_1      0.0
    RHS           AFO_0_2_1       0.0
    RHS           BFCH_0_2_2      0.0
    RHS           BFO_0_2_2       0.0
    RHS           AFCH_0_2_2      0.0
    RHS           AFO_0_2_2       0.0
    RHS           BFCH_0_2_3      0.0
    RHS           BFO_0_2_3       0.0
    RHS           AFCH_0_2_3      0.0
    RHS           AFO_0_2_3       0.0
    RHS           BFCH_0_2_4      0.0
    RHS           BFO_0_2_4       0.0
    RHS           AFCH_0_2_4      0.0
    RHS           AFO_0_2_4       0.0
    RHS           BFCH_0_2_5      0.0
    RHS           BFO_0_2_5       0.0
    RHS           AFCH_0_3_0      0.0
    RHS           AFO_0_3_0       0.0
    RHS           BFCH_0_3_1      0.0
    RHS           BFO_0_3_1       0.0
    RHS           AFCH_0_3_1      0.0
    RHS           AFO_0_3_1       0.0
    RHS           BFCH_0_3_2      0.0
    RHS           BFO_0_3_2       0.0
    RHS           AFCH_0_3_2      0.0
    RHS           AFO_0_3_2       0.0
    RHS           BFCH_0_3_3      0.0
    RHS           BFO_0_3_3       0.0
    RHS           AFCH_0_3_3      0.0
    RHS           AFO_0_3_3       0.0
    RHS           BFCH_0_3_4      0.0
    RHS           BFO_0_3_4       0.0
    RHS           AFCH_0_3_4      0.0
    RHS           AFO_0_3_4       0.0
    RHS           BFCH_0_3_5      0.0
    RHS           BFO_0_3_5       0.0
    RHS           AFCH_0_4_0      0.0
    RHS           AFO_0_4_0       0.0
    RHS           BFCH_0_4_1      0.0
    RHS           BFO_0_4_1       0.0
    RHS           AFCH_0_4_1      0.0
    RHS           AFO_0_4_1       0.0
    RHS           BFCH_0_4_2      0.0
    RHS           BFO_0_4_2       0.0
    RHS           AFCH_0_4_2      0.0
    RHS           AFO_0_4_2       0.0
    RHS           BFCH_0_4_3      0.0
    RHS           BFO_0_4_3       0.0
    RHS           AFCH_0_4_3      0.0
    RHS           AFO_0_4_3       0.0
    RHS           BFCH_0_4_4      0.0
    RHS           BFO_0_4_4       0.0
    RHS           AFCH_0_4_4      0.0
    RHS           AFO_0_4_4       0.0
    RHS           BFCH_0_4_5      0.0
    RHS           BFO_0_4_5       0.0
    RHS           AFCH_1_0_0      0.0
    RHS           AFO_1_0_0       0.0
    RHS           BFCH_1_0_1      0.0
    RHS           BFO_1_0_1       0.0
    RHS           AFCH_1_0_1      0.0
    RHS           AFO_1_0_1       0.0
    RHS           BFCH_1_0_2      0.0
    RHS           BFO_1_0_2       0.0
    RHS           AFCH_1_0_2      0.0
    RHS           AFO_1_0_2       0.0
    RHS           BFCH_1_0_3      0.0
    RHS           BFO_1_0_3       0.0
    RHS           AFCH_1_0_3      0.0
    RHS           AFO_1_0_3       0.0
    RHS           BFCH_1_0_4      0.0
    RHS           BFO_1_0_4       0.0
    RHS           AFCH_1_0_4      0.0
    RHS           AFO_1_0_4       0.0
    RHS           BFCH_1_0_5      0.0
    RHS           BFO_1_0_5       0.0
    RHS           AFCH_1_1_0      0.0
    RHS           AFO_1_1_0       0.0
    RHS           BFCH_1_1_1      0.0
    RHS           BFO_1_1_1       0.0
    RHS           AFCH_1_1_1      0.0
    RHS           AFO_1_1_1       0.0
    RHS           BFCH_1_1_2      0.0
    RHS           BFO_1_1_2       0.0
    RHS           AFCH_1_1_2      0.0
    RHS           AFO_1_1_2       0.0
    RHS           BFCH_1_1_3      0.0
    RHS           BFO_1_1_3       0.0
    RHS           AFCH_1_1_3      0.0
    RHS           AFO_1_1_3       0.0
    RHS           BFCH_1_1_4      0.0
    RHS           BFO_1_1_4       0.0
    RHS           AFCH_1_1_4      0.0
    RHS           AFO_1_1_4       0.0
    RHS           BFCH_1_1_5      0.0
    RHS           BFO_1_1_5       0.0
    RHS           AFCH_1_2_0      0.0
    RHS           AFO_1_2_0       0.0
    RHS           BFCH_1_2_1      0.0
    RHS           BFO_1_2_1       0.0
    RHS           AFCH_1_2_1      0.0
    RHS           AFO_1_2_1       0.0
    RHS           BFCH_1_2_2      0.0
    RHS           BFO_1_2_2       0.0
    RHS           AFCH_1_2_2      0.0
    RHS           AFO_1_2_2       0.0
    RHS           BFCH_1_2_3      0.0
    RHS           BFO_1_2_3       0.0
    RHS           AFCH_1_2_3      0.0
    RHS           AFO_1_2_3       0.0
    RHS           BFCH_1_2_4      0.0
    RHS           BFO_1_2_4       0.0
    RHS           AFCH_1_2_4      0.0
    RHS           AFO_1_2_4       0.0
    RHS           BFCH_1_2_5      0.0
    RHS           BFO_1_2_5       0.0
    RHS           AFCH_1_3_0      0.0
    RHS           AFO_1_3_0       0.0
    RHS           BFCH_1_3_1      0.0
    RHS           BFO_1_3_1       0.0
    RHS           AFCH_1_3_1      0.0
    RHS           AFO_1_3_1       0.0
    RHS           BFCH_1_3_2      0.0
    RHS           BFO_1_3_2       0.0
    RHS           AFCH_1_3_2      0.0
    RHS           AFO_1_3_2       0.0
    RHS           BFCH_1_3_3      0.0
    RHS           BFO_1_3_3       0.0
    RHS           AFCH_1_3_3      0.0
    RHS           AFO_1_3_3       0.0
    RHS           BFCH_1_3_4      0.0
    RHS           BFO_1_3_4       0.0
    RHS           AFCH_1_3_4      0.0
    RHS           AFO_1_3_4       0.0
    RHS           BFCH_1_3_5      0.0
    RHS           BFO_1_3_5       0.0
    RHS           AFCH_1_4_0      0.0
    RHS           AFO_1_4_0       0.0
    RHS           BFCH_1_4_1      0.0
    RHS           BFO_1_4_1       0.0
    RHS           AFCH_1_4_1      0.0
    RHS           AFO_1_4_1       0.0
    RHS           BFCH_1_4_2      0.0
    RHS           BFO_1_4_2       0.0
    RHS           AFCH_1_4_2      0.0
    RHS           AFO_1_4_2       0.0
    RHS           BFCH_1_4_3      0.0
    RHS           BFO_1_4_3       0.0
    RHS           AFCH_1_4_3      0.0
    RHS           AFO_1_4_3       0.0
    RHS           BFCH_1_4_4      0.0
    RHS           BFO_1_4_4       0.0
    RHS           AFCH_1_4_4      0.0
    RHS           AFO_1_4_4       0.0
    RHS           BFCH_1_4_5      0.0
    RHS           BFO_1_4_5       0.0
    RHS           AFCH_2_0_0      0.0
    RHS           AFO_2_0_0       0.0
    RHS           BFCH_2_0_1      0.0
    RHS           BFO_2_0_1       0.0
    RHS           AFCH_2_0_1      0.0
    RHS           AFO_2_0_1       0.0
    RHS           BFCH_2_0_2      0.0
    RHS           BFO_2_0_2       0.0
    RHS           AFCH_2_0_2      0.0
    RHS           AFO_2_0_2       0.0
    RHS           BFCH_2_0_3      0.0
    RHS           BFO_2_0_3       0.0
    RHS           AFCH_2_0_3      0.0
    RHS           AFO_2_0_3       0.0
    RHS           BFCH_2_0_4      0.0
    RHS           BFO_2_0_4       0.0
    RHS           AFCH_2_0_4      0.0
    RHS           AFO_2_0_4       0.0
    RHS           BFCH_2_0_5      0.0
    RHS           BFO_2_0_5       0.0
    RHS           AFCH_2_1_0      0.0
    RHS           AFO_2_1_0       0.0
    RHS           BFCH_2_1_1      0.0
    RHS           BFO_2_1_1       0.0
    RHS           AFCH_2_1_1      0.0
    RHS           AFO_2_1_1       0.0
    RHS           BFCH_2_1_2      0.0
    RHS           BFO_2_1_2       0.0
    RHS           AFCH_2_1_2      0.0
    RHS           AFO_2_1_2       0.0
    RHS           BFCH_2_1_3      0.0
    RHS           BFO_2_1_3       0.0
    RHS           AFCH_2_1_3      0.0
    RHS           AFO_2_1_3       0.0
    RHS           BFCH_2_1_4      0.0
    RHS           BFO_2_1_4       0.0
    RHS           AFCH_2_1_4      0.0
    RHS           AFO_2_1_4       0.0
    RHS           BFCH_2_1_5      0.0
    RHS           BFO_2_1_5       0.0
    RHS           AFCH_2_2_0      0.0
    RHS           AFO_2_2_0       0.0
    RHS           BFCH_2_2_1      0.0
    RHS           BFO_2_2_1       0.0
    RHS           AFCH_2_2_1      0.0
    RHS           AFO_2_2_1       0.0
    RHS           BFCH_2_2_2      0.0
    RHS           BFO_2_2_2       0.0
    RHS           AFCH_2_2_2      0.0
    RHS           AFO_2_2_2       0.0
    RHS           BFCH_2_2_3      0.0
    RHS           BFO_2_2_3       0.0
    RHS           AFCH_2_2_3      0.0
    RHS           AFO_2_2_3       0.0
    RHS           BFCH_2_2_4      0.0
    RHS           BFO_2_2_4       0.0
    RHS           AFCH_2_2_4      0.0
    RHS           AFO_2_2_4       0.0
    RHS           BFCH_2_2_5      0.0
    RHS           BFO_2_2_5       0.0
    RHS           AFCH_2_3_0      0.0
    RHS           AFO_2_3_0       0.0
    RHS           BFCH_2_3_1      0.0
    RHS           BFO_2_3_1       0.0
    RHS           AFCH_2_3_1      0.0
    RHS           AFO_2_3_1       0.0
    RHS           BFCH_2_3_2      0.0
    RHS           BFO_2_3_2       0.0
    RHS           AFCH_2_3_2      0.0
    RHS           AFO_2_3_2       0.0
    RHS           BFCH_2_3_3      0.0
    RHS           BFO_2_3_3       0.0
    RHS           AFCH_2_3_3      0.0
    RHS           AFO_2_3_3       0.0
    RHS           BFCH_2_3_4      0.0
    RHS           BFO_2_3_4       0.0
    RHS           AFCH_2_3_4      0.0
    RHS           AFO_2_3_4       0.0
    RHS           BFCH_2_3_5      0.0
    RHS           BFO_2_3_5       0.0
    RHS           AFCH_2_4_0      0.0
    RHS           AFO_2_4_0       0.0
    RHS           BFCH_2_4_1      0.0
    RHS           BFO_2_4_1       0.0
    RHS           AFCH_2_4_1      0.0
    RHS           AFO_2_4_1       0.0
    RHS           BFCH_2_4_2      0.0
    RHS           BFO_2_4_2       0.0
    RHS           AFCH_2_4_2      0.0
    RHS           AFO_2_4_2       0.0
    RHS           BFCH_2_4_3      0.0
    RHS           BFO_2_4_3       0.0
    RHS           AFCH_2_4_3      0.0
    RHS           AFO_2_4_3       0.0
    RHS           BFCH_2_4_4      0.0
    RHS           BFO_2_4_4       0.0
    RHS           AFCH_2_4_4      0.0
    RHS           AFO_2_4_4       0.0
    RHS           BFCH_2_4_5      0.0
    RHS           BFO_2_4_5       0.0
    RHS           AFCH_3_0_0      0.0
    RHS           AFO_3_0_0       0.0
    RHS           BFCH_3_0_1      0.0
    RHS           BFO_3_0_1       0.0
    RHS           AFCH_3_0_1      0.0
    RHS           AFO_3_0_1       0.0
    RHS           BFCH_3_0_2      0.0
    RHS           BFO_3_0_2       0.0
    RHS           AFCH_3_0_2      0.0
    RHS           AFO_3_0_2       0.0
    RHS           BFCH_3_0_3      0.0
    RHS           BFO_3_0_3       0.0
    RHS           AFCH_3_0_3      0.0
    RHS           AFO_3_0_3       0.0
    RHS           BFCH_3_0_4      0.0
    RHS           BFO_3_0_4       0.0
    RHS           AFCH_3_0_4      0.0
    RHS           AFO_3_0_4       0.0
    RHS           BFCH_3_0_5      0.0
    RHS           BFO_3_0_5       0.0
    RHS           AFCH_3_1_0      0.0
    RHS           AFO_3_1_0       0.0
    RHS           BFCH_3_1_1      0.0
    RHS           BFO_3_1_1       0.0
    RHS           AFCH_3_1_1      0.0
    RHS           AFO_3_1_1       0.0
    RHS           BFCH_3_1_2      0.0
    RHS           BFO_3_1_2       0.0
    RHS           AFCH_3_1_2      0.0
    RHS           AFO_3_1_2       0.0
    RHS           BFCH_3_1_3      0.0
    RHS           BFO_3_1_3       0.0
    RHS           AFCH_3_1_3      0.0
    RHS           AFO_3_1_3       0.0
    RHS           BFCH_3_1_4      0.0
    RHS           BFO_3_1_4       0.0
    RHS           AFCH_3_1_4      0.0
    RHS           AFO_3_1_4       0.0
    RHS           BFCH_3_1_5      0.0
    RHS           BFO_3_1_5       0.0
    RHS           AFCH_3_2_0      0.0
    RHS           AFO_3_2_0       0.0
    RHS           BFCH_3_2_1      0.0
    RHS           BFO_3_2_1       0.0
    RHS           AFCH_3_2_1      0.0
    RHS           AFO_3_2_1       0.0
    RHS           BFCH_3_2_2      0.0
    RHS           BFO_3_2_2       0.0
    RHS           AFCH_3_2_2      0.0
    RHS           AFO_3_2_2       0.0
    RHS           BFCH_3_2_3      0.0
    RHS           BFO_3_2_3       0.0
    RHS           AFCH_3_2_3      0.0
    RHS           AFO_3_2_3       0.0
    RHS           BFCH_3_2_4      0.0
    RHS           BFO_3_2_4       0.0
    RHS           AFCH_3_2_4      0.0
    RHS           AFO_3_2_4       0.0
    RHS           BFCH_3_2_5      0.0
    RHS           BFO_3_2_5       0.0
    RHS           AFCH_3_3_0      0.0
    RHS           AFO_3_3_0       0.0
    RHS           BFCH_3_3_1      0.0
    RHS           BFO_3_3_1       0.0
    RHS           AFCH_3_3_1      0.0
    RHS           AFO_3_3_1       0.0
    RHS           BFCH_3_3_2      0.0
    RHS           BFO_3_3_2       0.0
    RHS           AFCH_3_3_2      0.0
    RHS           AFO_3_3_2       0.0
    RHS           BFCH_3_3_3      0.0
    RHS           BFO_3_3_3       0.0
    RHS           AFCH_3_3_3      0.0
    RHS           AFO_3_3_3       0.0
    RHS           BFCH_3_3_4      0.0
    RHS           BFO_3_3_4       0.0
    RHS           AFCH_3_3_4      0.0
    RHS           AFO_3_3_4       0.0
    RHS           BFCH_3_3_5      0.0
    RHS           BFO_3_3_5       0.0
    RHS           AFCH_3_4_0      0.0
    RHS           AFO_3_4_0       0.0
    RHS           BFCH_3_4_1      0.0
    RHS           BFO_3_4_1       0.0
    RHS           AFCH_3_4_1      0.0
    RHS           AFO_3_4_1       0.0
    RHS           BFCH_3_4_2      0.0
    RHS           BFO_3_4_2       0.0
    RHS           AFCH_3_4_2      0.0
    RHS           AFO_3_4_2       0.0
    RHS           BFCH_3_4_3      0.0
    RHS           BFO_3_4_3       0.0
    RHS           AFCH_3_4_3      0.0
    RHS           AFO_3_4_3       0.0
    RHS           BFCH_3_4_4      0.0
    RHS           BFO_3_4_4       0.0
    RHS           AFCH_3_4_4      0.0
    RHS           AFO_3_4_4       0.0
    RHS           BFCH_3_4_5      0.0
    RHS           BFO_3_4_5       0.0
    RHS           AFCH_4_0_0      0.0
    RHS           AFO_4_0_0       0.0
    RHS           BFCH_4_0_1      0.0
    RHS           BFO_4_0_1       0.0
    RHS           AFCH_4_0_1      0.0
    RHS           AFO_4_0_1       0.0
    RHS           BFCH_4_0_2      0.0
    RHS           BFO_4_0_2       0.0
    RHS           AFCH_4_0_2      0.0
    RHS           AFO_4_0_2       0.0
    RHS           BFCH_4_0_3      0.0
    RHS           BFO_4_0_3       0.0
    RHS           AFCH_4_0_3      0.0
    RHS           AFO_4_0_3       0.0
    RHS           BFCH_4_0_4      0.0
    RHS           BFO_4_0_4       0.0
    RHS           AFCH_4_0_4      0.0
    RHS           AFO_4_0_4       0.0
    RHS           BFCH_4_0_5      0.0
    RHS           BFO_4_0_5       0.0
    RHS           AFCH_4_1_0      0.0
    RHS           AFO_4_1_0       0.0
    RHS           BFCH_4_1_1      0.0
    RHS           BFO_4_1_1       0.0
    RHS           AFCH_4_1_1      0.0
    RHS           AFO_4_1_1       0.0
    RHS           BFCH_4_1_2      0.0
    RHS           BFO_4_1_2       0.0
    RHS           AFCH_4_1_2      0.0
    RHS           AFO_4_1_2       0.0
    RHS           BFCH_4_1_3      0.0
    RHS           BFO_4_1_3       0.0
    RHS           AFCH_4_1_3      0.0
    RHS           AFO_4_1_3       0.0
    RHS           BFCH_4_1_4      0.0
    RHS           BFO_4_1_4       0.0
    RHS           AFCH_4_1_4      0.0
    RHS           AFO_4_1_4       0.0
    RHS           BFCH_4_1_5      0.0
    RHS           BFO_4_1_5       0.0
    RHS           AFCH_4_2_0      0.0
    RHS           AFO_4_2_0       0.0
    RHS           BFCH_4_2_1      0.0
    RHS           BFO_4_2_1       0.0
    RHS           AFCH_4_2_1      0.0
    RHS           AFO_4_2_1       0.0
    RHS           BFCH_4_2_2      0.0
    RHS           BFO_4_2_2       0.0
    RHS           AFCH_4_2_2      0.0
    RHS           AFO_4_2_2       0.0
    RHS           BFCH_4_2_3      0.0
    RHS           BFO_4_2_3       0.0
    RHS           AFCH_4_2_3      0.0
    RHS           AFO_4_2_3       0.0
    RHS           BFCH_4_2_4      0.0
    RHS           BFO_4_2_4       0.0
    RHS           AFCH_4_2_4      0.0
    RHS           AFO_4_2_4       0.0
    RHS           BFCH_4_2_5      0.0
    RHS           BFO_4_2_5       0.0
    RHS           AFCH_4_3_0      0.0
    RHS           AFO_4_3_0       0.0
    RHS           BFCH_4_3_1      0.0
    RHS           BFO_4_3_1       0.0
    RHS           AFCH_4_3_1      0.0
    RHS           AFO_4_3_1       0.0
    RHS           BFCH_4_3_2      0.0
    RHS           BFO_4_3_2       0.0
    RHS           AFCH_4_3_2      0.0
    RHS           AFO_4_3_2       0.0
    RHS           BFCH_4_3_3      0.0
    RHS           BFO_4_3_3       0.0
    RHS           AFCH_4_3_3      0.0
    RHS           AFO_4_3_3       0.0
    RHS           BFCH_4_3_4      0.0
    RHS           BFO_4_3_4       0.0
    RHS           AFCH_4_3_4      0.0
    RHS           AFO_4_3_4       0.0
    RHS           BFCH_4_3_5      0.0
    RHS           BFO_4_3_5       0.0
    RHS           AFCH_4_4_0      0.0
    RHS           AFO_4_4_0       0.0
    RHS           BFCH_4_4_1      0.0
    RHS           BFO_4_4_1       0.0
    RHS           AFCH_4_4_1      0.0
    RHS           AFO_4_4_1       0.0
    RHS           BFCH_4_4_2      0.0
    RHS           BFO_4_4_2       0.0
    RHS           AFCH_4_4_2      0.0
    RHS           AFO_4_4_2       0.0
    RHS           BFCH_4_4_3      0.0
    RHS           BFO_4_4_3       0.0
    RHS           AFCH_4_4_3      0.0
    RHS           AFO_4_4_3       0.0
    RHS           BFCH_4_4_4      0.0
    RHS           BFO_4_4_4       0.0
    RHS           AFCH_4_4_4      0.0
    RHS           AFO_4_4_4       0.0
    RHS           BFCH_4_4_5      0.0
    RHS           BFO_4_4_5       0.0
    RHS           AFCH_5_0_0      0.0
    RHS           AFO_5_0_0       0.0
    RHS           BFCH_5_0_1      0.0
    RHS           BFO_5_0_1       0.0
    RHS           AFCH_5_0_1      0.0
    RHS           AFO_5_0_1       0.0
    RHS           BFCH_5_0_2      0.0
    RHS           BFO_5_0_2       0.0
    RHS           AFCH_5_0_2      0.0
    RHS           AFO_5_0_2       0.0
    RHS           BFCH_5_0_3      0.0
    RHS           BFO_5_0_3       0.0
    RHS           AFCH_5_0_3      0.0
    RHS           AFO_5_0_3       0.0
    RHS           BFCH_5_0_4      0.0
    RHS           BFO_5_0_4       0.0
    RHS           AFCH_5_0_4      0.0
    RHS           AFO_5_0_4       0.0
    RHS           BFCH_5_0_5      0.0
    RHS           BFO_5_0_5       0.0
    RHS           AFCH_5_1_0      0.0
    RHS           AFO_5_1_0       0.0
    RHS           BFCH_5_1_1      0.0
    RHS           BFO_5_1_1       0.0
    RHS           AFCH_5_1_1      0.0
    RHS           AFO_5_1_1       0.0
    RHS           BFCH_5_1_2      0.0
    RHS           BFO_5_1_2       0.0
    RHS           AFCH_5_1_2      0.0
    RHS           AFO_5_1_2       0.0
    RHS           BFCH_5_1_3      0.0
    RHS           BFO_5_1_3       0.0
    RHS           AFCH_5_1_3      0.0
    RHS           AFO_5_1_3       0.0
    RHS           BFCH_5_1_4      0.0
    RHS           BFO_5_1_4       0.0
    RHS           AFCH_5_1_4      0.0
    RHS           AFO_5_1_4       0.0
    RHS           BFCH_5_1_5      0.0
    RHS           BFO_5_1_5       0.0
    RHS           AFCH_5_2_0      0.0
    RHS           AFO_5_2_0       0.0
    RHS           BFCH_5_2_1      0.0
    RHS           BFO_5_2_1       0.0
    RHS           AFCH_5_2_1      0.0
    RHS           AFO_5_2_1       0.0
    RHS           BFCH_5_2_2      0.0
    RHS           BFO_5_2_2       0.0
    RHS           AFCH_5_2_2      0.0
    RHS           AFO_5_2_2       0.0
    RHS           BFCH_5_2_3      0.0
    RHS           BFO_5_2_3       0.0
    RHS           AFCH_5_2_3      0.0
    RHS           AFO_5_2_3       0.0
    RHS           BFCH_5_2_4      0.0
    RHS           BFO_5_2_4       0.0
    RHS           AFCH_5_2_4      0.0
    RHS           AFO_5_2_4       0.0
    RHS           BFCH_5_2_5      0.0
    RHS           BFO_5_2_5       0.0
    RHS           AFCH_5_3_0      0.0
    RHS           AFO_5_3_0       0.0
    RHS           BFCH_5_3_1      0.0
    RHS           BFO_5_3_1       0.0
    RHS           AFCH_5_3_1      0.0
    RHS           AFO_5_3_1       0.0
    RHS           BFCH_5_3_2      0.0
    RHS           BFO_5_3_2       0.0
    RHS           AFCH_5_3_2      0.0
    RHS           AFO_5_3_2       0.0
    RHS           BFCH_5_3_3      0.0
    RHS           BFO_5_3_3       0.0
    RHS           AFCH_5_3_3      0.0
    RHS           AFO_5_3_3       0.0
    RHS           BFCH_5_3_4      0.0
    RHS           BFO_5_3_4       0.0
    RHS           AFCH_5_3_4      0.0
    RHS           AFO_5_3_4       0.0
    RHS           BFCH_5_3_5      0.0
    RHS           BFO_5_3_5       0.0
    RHS           AFCH_5_4_0      0.0
    RHS           AFO_5_4_0       0.0
    RHS           BFCH_5_4_1      0.0
    RHS           BFO_5_4_1       0.0
    RHS           AFCH_5_4_1      0.0
    RHS           AFO_5_4_1       0.0
    RHS           BFCH_5_4_2      0.0
    RHS           BFO_5_4_2       0.0
    RHS           AFCH_5_4_2      0.0
    RHS           AFO_5_4_2       0.0
    RHS           BFCH_5_4_3      0.0
    RHS           BFO_5_4_3       0.0
    RHS           AFCH_5_4_3      0.0
    RHS           AFO_5_4_3       0.0
    RHS           BFCH_5_4_4      0.0
    RHS           BFO_5_4_4       0.0
    RHS           AFCH_5_4_4      0.0
    RHS           AFO_5_4_4       0.0
    RHS           BFCH_5_4_5      0.0
    RHS           BFO_5_4_5       0.0
    RHS           AFCH_6_0_0      0.0
    RHS           AFO_6_0_0       0.0
    RHS           BFCH_6_0_1      0.0
    RHS           BFO_6_0_1       0.0
    RHS           AFCH_6_0_1      0.0
    RHS           AFO_6_0_1       0.0
    RHS           BFCH_6_0_2      0.0
    RHS           BFO_6_0_2       0.0
    RHS           AFCH_6_0_2      0.0
    RHS           AFO_6_0_2       0.0
    RHS           BFCH_6_0_3      0.0
    RHS           BFO_6_0_3       0.0
    RHS           AFCH_6_0_3      0.0
    RHS           AFO_6_0_3       0.0
    RHS           BFCH_6_0_4      0.0
    RHS           BFO_6_0_4       0.0
    RHS           AFCH_6_0_4      0.0
    RHS           AFO_6_0_4       0.0
    RHS           BFCH_6_0_5      0.0
    RHS           BFO_6_0_5       0.0
    RHS           AFCH_6_1_0      0.0
    RHS           AFO_6_1_0       0.0
    RHS           BFCH_6_1_1      0.0
    RHS           BFO_6_1_1       0.0
    RHS           AFCH_6_1_1      0.0
    RHS           AFO_6_1_1       0.0
    RHS           BFCH_6_1_2      0.0
    RHS           BFO_6_1_2       0.0
    RHS           AFCH_6_1_2      0.0
    RHS           AFO_6_1_2       0.0
    RHS           BFCH_6_1_3      0.0
    RHS           BFO_6_1_3       0.0
    RHS           AFCH_6_1_3      0.0
    RHS           AFO_6_1_3       0.0
    RHS           BFCH_6_1_4      0.0
    RHS           BFO_6_1_4       0.0
    RHS           AFCH_6_1_4      0.0
    RHS           AFO_6_1_4       0.0
    RHS           BFCH_6_1_5      0.0
    RHS           BFO_6_1_5       0.0
    RHS           AFCH_6_2_0      0.0
    RHS           AFO_6_2_0       0.0
    RHS           BFCH_6_2_1      0.0
    RHS           BFO_6_2_1       0.0
    RHS           AFCH_6_2_1      0.0
    RHS           AFO_6_2_1       0.0
    RHS           BFCH_6_2_2      0.0
    RHS           BFO_6_2_2       0.0
    RHS           AFCH_6_2_2      0.0
    RHS           AFO_6_2_2       0.0
    RHS           BFCH_6_2_3      0.0
    RHS           BFO_6_2_3       0.0
    RHS           AFCH_6_2_3      0.0
    RHS           AFO_6_2_3       0.0
    RHS           BFCH_6_2_4      0.0
    RHS           BFO_6_2_4       0.0
    RHS           AFCH_6_2_4      0.0
    RHS           AFO_6_2_4       0.0
    RHS           BFCH_6_2_5      0.0
    RHS           BFO_6_2_5       0.0
    RHS           AFCH_6_3_0      0.0
    RHS           AFO_6_3_0       0.0
    RHS           BFCH_6_3_1      0.0
    RHS           BFO_6_3_1       0.0
    RHS           AFCH_6_3_1      0.0
    RHS           AFO_6_3_1       0.0
    RHS           BFCH_6_3_2      0.0
    RHS           BFO_6_3_2       0.0
    RHS           AFCH_6_3_2      0.0
    RHS           AFO_6_3_2       0.0
    RHS           BFCH_6_3_3      0.0
    RHS           BFO_6_3_3       0.0
    RHS           AFCH_6_3_3      0.0
    RHS           AFO_6_3_3       0.0
    RHS           BFCH_6_3_4      0.0
    RHS           BFO_6_3_4       0.0
    RHS           AFCH_6_3_4      0.0
    RHS           AFO_6_3_4       0.0
    RHS           BFCH_6_3_5      0.0
    RHS           BFO_6_3_5       0.0
    RHS           AFCH_6_4_0      0.0
    RHS           AFO_6_4_0       0.0
    RHS           BFCH_6_4_1      0.0
    RHS           BFO_6_4_1       0.0
    RHS           AFCH_6_4_1      0.0
    RHS           AFO_6_4_1       0.0
    RHS           BFCH_6_4_2      0.0
    RHS           BFO_6_4_2       0.0
    RHS           AFCH_6_4_2      0.0
    RHS           AFO_6_4_2       0.0
    RHS           BFCH_6_4_3      0.0
    RHS           BFO_6_4_3       0.0
    RHS           AFCH_6_4_3      0.0
    RHS           AFO_6_4_3       0.0
    RHS           BFCH_6_4_4      0.0
    RHS           BFO_6_4_4       0.0
    RHS           AFCH_6_4_4      0.0
    RHS           AFO_6_4_4       0.0
    RHS           BFCH_6_4_5      0.0
    RHS           BFO_6_4_5       0.0
    RHS           AFCH_7_0_0      0.0
    RHS           AFO_7_0_0       0.0
    RHS           BFCH_7_0_1      0.0
    RHS           BFO_7_0_1       0.0
    RHS           AFCH_7_0_1      0.0
    RHS           AFO_7_0_1       0.0
    RHS           BFCH_7_0_2      0.0
    RHS           BFO_7_0_2       0.0
    RHS           AFCH_7_0_2      0.0
    RHS           AFO_7_0_2       0.0
    RHS           BFCH_7_0_3      0.0
    RHS           BFO_7_0_3       0.0
    RHS           AFCH_7_0_3      0.0
    RHS           AFO_7_0_3       0.0
    RHS           BFCH_7_0_4      0.0
    RHS           BFO_7_0_4       0.0
    RHS           AFCH_7_0_4      0.0
    RHS           AFO_7_0_4       0.0
    RHS           BFCH_7_0_5      0.0
    RHS           BFO_7_0_5       0.0
    RHS           AFCH_7_1_0      0.0
    RHS           AFO_7_1_0       0.0
    RHS           BFCH_7_1_1      0.0
    RHS           BFO_7_1_1       0.0
    RHS           AFCH_7_1_1      0.0
    RHS           AFO_7_1_1       0.0
    RHS           BFCH_7_1_2      0.0
    RHS           BFO_7_1_2       0.0
    RHS           AFCH_7_1_2      0.0
    RHS           AFO_7_1_2       0.0
    RHS           BFCH_7_1_3      0.0
    RHS           BFO_7_1_3       0.0
    RHS           AFCH_7_1_3      0.0
    RHS           AFO_7_1_3       0.0
    RHS           BFCH_7_1_4      0.0
    RHS           BFO_7_1_4       0.0
    RHS           AFCH_7_1_4      0.0
    RHS           AFO_7_1_4       0.0
    RHS           BFCH_7_1_5      0.0
    RHS           BFO_7_1_5       0.0
    RHS           AFCH_7_2_0      0.0
    RHS           AFO_7_2_0       0.0
    RHS           BFCH_7_2_1      0.0
    RHS           BFO_7_2_1       0.0
    RHS           AFCH_7_2_1      0.0
    RHS           AFO_7_2_1       0.0
    RHS           BFCH_7_2_2      0.0
    RHS           BFO_7_2_2       0.0
    RHS           AFCH_7_2_2      0.0
    RHS           AFO_7_2_2       0.0
    RHS           BFCH_7_2_3      0.0
    RHS           BFO_7_2_3       0.0
    RHS           AFCH_7_2_3      0.0
    RHS           AFO_7_2_3       0.0
    RHS           BFCH_7_2_4      0.0
    RHS           BFO_7_2_4       0.0
    RHS           AFCH_7_2_4      0.0
    RHS           AFO_7_2_4       0.0
    RHS           BFCH_7_2_5      0.0
    RHS           BFO_7_2_5       0.0
    RHS           AFCH_7_3_0      0.0
    RHS           AFO_7_3_0       0.0
    RHS           BFCH_7_3_1      0.0
    RHS           BFO_7_3_1       0.0
    RHS           AFCH_7_3_1      0.0
    RHS           AFO_7_3_1       0.0
    RHS           BFCH_7_3_2      0.0
    RHS           BFO_7_3_2       0.0
    RHS           AFCH_7_3_2      0.0
    RHS           AFO_7_3_2       0.0
    RHS           BFCH_7_3_3      0.0
    RHS           BFO_7_3_3       0.0
    RHS           AFCH_7_3_3      0.0
    RHS           AFO_7_3_3       0.0
    RHS           BFCH_7_3_4      0.0
    RHS           BFO_7_3_4       0.0
    RHS           AFCH_7_3_4      0.0
    RHS           AFO_7_3_4       0.0
    RHS           BFCH_7_3_5      0.0
    RHS           BFO_7_3_5       0.0
    RHS           AFCH_7_4_0      0.0
    RHS           AFO_7_4_0       0.0
    RHS           BFCH_7_4_1      0.0
    RHS           BFO_7_4_1       0.0
    RHS           AFCH_7_4_1      0.0
    RHS           AFO_7_4_1       0.0
    RHS           BFCH_7_4_2      0.0
    RHS           BFO_7_4_2       0.0
    RHS           AFCH_7_4_2      0.0
    RHS           AFO_7_4_2       0.0
    RHS           BFCH_7_4_3      0.0
    RHS           BFO_7_4_3       0.0
    RHS           AFCH_7_4_3      0.0
    RHS           AFO_7_4_3       0.0
    RHS           BFCH_7_4_4      0.0
    RHS           BFO_7_4_4       0.0
    RHS           AFCH_7_4_4      0.0
    RHS           AFO_7_4_4       0.0
    RHS           BFCH_7_4_5      0.0
    RHS           BFO_7_4_5       0.0
    RHS           GAP_0_0_0       -1.0
    RHS           GAP_0_0_1       -1.0
    RHS           GAP_0_0_2       -1.0
    RHS           GAP_0_0_3       -1.0
    RHS           GAP_0_0_4       -1.0
    RHS           GAP_0_0_5       -1.0
    RHS           GAP_0_1_0       -1.0
    RHS           GAP_0_1_1       -1.0
    RHS           GAP_0_1_2       -1.0
    RHS           GAP_0_1_3       -1.0
    RHS           GAP_0_1_4       -1.0
    RHS           GAP_0_1_5       -1.0
    RHS           GAP_0_2_0       -1.0
    RHS           GAP_0_2_1       -1.0
    RHS           GAP_0_2_2       -1.0
    RHS           GAP_0_2_3       -1.0
    RHS           GAP_0_2_4       -1.0
    RHS           GAP_0_2_5       -1.0
    RHS           GAP_0_3_0       -1.0
    RHS           GAP_0_3_1       -1.0
    RHS           GAP_0_3_2       -1.0
    RHS           GAP_0_3_3       -1.0
    RHS           GAP_0_3_4       -1.0
    RHS           GAP_0_3_5       -1.0
    RHS           GAP_0_4_0       -1.0
    RHS           GAP_0_4_1       -1.0
    RHS           GAP_0_4_2       -1.0
    RHS           GAP_0_4_3       -1.0
    RHS           GAP_0_4_4       -1.0
    RHS           GAP_0_4_5       -1.0
    RHS           GAP_1_0_0       -1.0
    RHS           GAP_1_0_1       -1.0
    RHS           GAP_1_0_2       -1.0
    RHS           GAP_1_0_3       -1.0
    RHS           GAP_1_0_4       -1.0
    RHS           GAP_1_0_5       -1.0
    RHS           GAP_1_1_0       -1.0
    RHS           GAP_1_1_1       -1.0
    RHS           GAP_1_1_2       -1.0
    RHS           GAP_1_1_3       -1.0
    RHS           GAP_1_1_4       -1.0
    RHS           GAP_1_1_5       -1.0
    RHS           GAP_1_2_0       -1.0
    RHS           GAP_1_2_1       -1.0
    RHS           GAP_1_2_2       -1.0
    RHS           GAP_1_2_3       -1.0
    RHS           GAP_1_2_4       -1.0
    RHS           GAP_1_2_5       -1.0
    RHS           GAP_1_3_0       -1.0
    RHS           GAP_1_3_1       -1.0
    RHS           GAP_1_3_2       -1.0
    RHS           GAP_1_3_3       -1.0
    RHS           GAP_1_3_4       -1.0
    RHS           GAP_1_3_5       -1.0
    RHS           GAP_1_4_0       -1.0
    RHS           GAP_1_4_1       -1.0
    RHS           GAP_1_4_2       -1.0
    RHS           GAP_1_4_3       -1.0
    RHS           GAP_1_4_4       -1.0
    RHS           GAP_1_4_5       -1.0
    RHS           GAP_2_0_0       -1.0
    RHS           GAP_2_0_1       -1.0
    RHS           GAP_2_0_2       -1.0
    RHS           GAP_2_0_3       -1.0
    RHS           GAP_2_0_4       -1.0
    RHS           GAP_2_0_5       -1.0
    RHS           GAP_2_1_0       -1.0
    RHS           GAP_2_1_1       -1.0
    RHS           GAP_2_1_2       -1.0
    RHS           GAP_2_1_3       -1.0
    RHS           GAP_2_1_4       -1.0
    RHS           GAP_2_1_5       -1.0
    RHS           GAP_2_2_0       -1.0
    RHS           GAP_2_2_1       -1.0
    RHS           GAP_2_2_2       -1.0
    RHS           GAP_2_2_3       -1.0
    RHS           GAP_2_2_4       -1.0
    RHS           GAP_2_2_5       -1.0
    RHS           GAP_2_3_0       -1.0
    RHS           GAP_2_3_1       -1.0
    RHS           GAP_2_3_2       -1.0
    RHS           GAP_2_3_3       -1.0
    RHS           GAP_2_3_4       -1.0
    RHS           GAP_2_3_5       -1.0
    RHS           GAP_2_4_0       -1.0
    RHS           GAP_2_4_1       -1.0
    RHS           GAP_2_4_2       -1.0
    RHS           GAP_2_4_3       -1.0
    RHS           GAP_2_4_4       -1.0
    RHS           GAP_2_4_5       -1.0
    RHS           GAP_3_0_0       -1.0
    RHS           GAP_3_0_1       -1.0
    RHS           GAP_3_0_2       -1.0
    RHS           GAP_3_0_3       -1.0
    RHS           GAP_3_0_4       -1.0
    RHS           GAP_3_0_5       -1.0
    RHS           GAP_3_1_0       -1.0
    RHS           GAP_3_1_1       -1.0
    RHS           GAP_3_1_2       -1.0
    RHS           GAP_3_1_3       -1.0
    RHS           GAP_3_1_4       -1.0
    RHS           GAP_3_1_5       -1.0
    RHS           GAP_3_2_0       -1.0
    RHS           GAP_3_2_1       -1.0
    RHS           GAP_3_2_2       -1.0
    RHS           GAP_3_2_3       -1.0
    RHS           GAP_3_2_4       -1.0
    RHS           GAP_3_2_5       -1.0
    RHS           GAP_3_3_0       -1.0
    RHS           GAP_3_3_1       -1.0
    RHS           GAP_3_3_2       -1.0
    RHS           GAP_3_3_3       -1.0
    RHS           GAP_3_3_4       -1.0
    RHS           GAP_3_3_5       -1.0
    RHS           GAP_3_4_0       -1.0
    RHS           GAP_3_4_1       -1.0
    RHS           GAP_3_4_2       -1.0
    RHS           GAP_3_4_3       -1.0
    RHS           GAP_3_4_4       -1.0
    RHS           GAP_3_4_5       -1.0
    RHS           GAP_4_0_0       -1.0
    RHS           GAP_4_0_1       -1.0
    RHS           GAP_4_0_2       -1.0
    RHS           GAP_4_0_3       -1.0
    RHS           GAP_4_0_4       -1.0
    RHS           GAP_4_0_5       -1.0
    RHS           GAP_4_1_0       -1.0
    RHS           GAP_4_1_1       -1.0
    RHS           GAP_4_1_2       -1.0
    RHS           GAP_4_1_3       -1.0
    RHS           GAP_4_1_4       -1.0
    RHS           GAP_4_1_5       -1.0
    RHS           GAP_4_2_0       -1.0
    RHS           GAP_4_2_1       -1.0
    RHS           GAP_4_2_2       -1.0
    RHS           GAP_4_2_3       -1.0
    RHS           GAP_4_2_4       -1.0
    RHS           GAP_4_2_5       -1.0
    RHS           GAP_4_3_0       -1.0
    RHS           GAP_4_3_1       -1.0
    RHS           GAP_4_3_2       -1.0
    RHS           GAP_4_3_3       -1.0
    RHS           GAP_4_3_4       -1.0
    RHS           GAP_4_3_5       -1.0
    RHS           GAP_4_4_0       -1.0
    RHS           GAP_4_4_1       -1.0
    RHS           GAP_4_4_2       -1.0
    RHS           GAP_4_4_3       -1.0
    RHS           GAP_4_4_4       -1.0
    RHS           GAP_4_4_5       -1.0
    RHS           GAP_5_0_0       -1.0
    RHS           GAP_5_0_1       -1.0
    RHS           GAP_5_0_2       -1.0
    RHS           GAP_5_0_3       -1.0
    RHS           GAP_5_0_4       -1.0
    RHS           GAP_5_0_5       -1.0
    RHS           GAP_5_1_0       -1.0
    RHS           GAP_5_1_1       -1.0
    RHS           GAP_5_1_2       -1.0
    RHS           GAP_5_1_3       -1.0
    RHS           GAP_5_1_4       -1.0
    RHS           GAP_5_1_5       -1.0
    RHS           GAP_5_2_0       -1.0
    RHS           GAP_5_2_1       -1.0
    RHS           GAP_5_2_2       -1.0
    RHS           GAP_5_2_3       -1.0
    RHS           GAP_5_2_4       -1.0
    RHS           GAP_5_2_5       -1.0
    RHS           GAP_5_3_0       -1.0
    RHS           GAP_5_3_1       -1.0
    RHS           GAP_5_3_2       -1.0
    RHS           GAP_5_3_3       -1.0
    RHS           GAP_5_3_4       -1.0
    RHS           GAP_5_3_5       -1.0
    RHS           GAP_5_4_0       -1.0
    RHS           GAP_5_4_1       -1.0
    RHS           GAP_5_4_2       -1.0
    RHS           GAP_5_4_3       -1.0
    RHS           GAP_5_4_4       -1.0
    RHS           GAP_5_4_5       -1.0
    RHS           GAP_6_0_0       -1.0
    RHS           GAP_6_0_1       -1.0
    RHS           GAP_6_0_2       -1.0
    RHS           GAP_6_0_3       -1.0
    RHS           GAP_6_0_4       -1.0
    RHS           GAP_6_0_5       -1.0
    RHS           GAP_6_1_0       -1.0
    RHS           GAP_6_1_1       -1.0
    RHS           GAP_6_1_2       -1.0
    RHS           GAP_6_1_3       -1.0
    RHS           GAP_6_1_4       -1.0
    RHS           GAP_6_1_5       -1.0
    RHS           GAP_6_2_0       -1.0
    RHS           GAP_6_2_1       -1.0
    RHS           GAP_6_2_2       -1.0
    RHS           GAP_6_2_3       -1.0
    RHS           GAP_6_2_4       -1.0
    RHS           GAP_6_2_5       -1.0
    RHS           GAP_6_3_0       -1.0
    RHS           GAP_6_3_1       -1.0
    RHS           GAP_6_3_2       -1.0
    RHS           GAP_6_3_3       -1.0
    RHS           GAP_6_3_4       -1.0
    RHS           GAP_6_3_5       -1.0
    RHS           GAP_6_4_0       -1.0
    RHS           GAP_6_4_1       -1.0
    RHS           GAP_6_4_2       -1.0
    RHS           GAP_6_4_3       -1.0
    RHS           GAP_6_4_4       -1.0
    RHS           GAP_6_4_5       -1.0
    RHS           GAP_7_0_0       -1.0
    RHS           GAP_7_0_1       -1.0
    RHS           GAP_7_0_2       -1.0
    RHS           GAP_7_0_3       -1.0
    RHS           GAP_7_0_4       -1.0
    RHS           GAP_7_0_5       -1.0
    RHS           GAP_7_1_0       -1.0
    RHS           GAP_7_1_1       -1.0
    RHS           GAP_7_1_2       -1.0
    RHS           GAP_7_1_3       -1.0
    RHS           GAP_7_1_4       -1.0
    RHS           GAP_7_1_5       -1.0
    RHS           GAP_7_2_0       -1.0
    RHS           GAP_7_2_1       -1.0
    RHS           GAP_7_2_2       -1.0
    RHS           GAP_7_2_3       -1.0
    RHS           GAP_7_2_4       -1.0
    RHS           GAP_7_2_5       -1.0
    RHS           GAP_7_3_0       -1.0
    RHS           GAP_7_3_1       -1.0
    RHS           GAP_7_3_2       -1.0
    RHS           GAP_7_3_3       -1.0
    RHS           GAP_7_3_4       -1.0
    RHS           GAP_7_3_5       -1.0
    RHS           GAP_7_4_0       -1.0
    RHS           GAP_7_4_1       -1.0
    RHS           GAP_7_4_2       -1.0
    RHS           GAP_7_4_3       -1.0
    RHS           GAP_7_4_4       -1.0
    RHS           GAP_7_4_5       -1.0
BOUNDS
 BV BOUND         z_0_1_0_0
 BV BOUND         z_0_1_0_1
 BV BOUND         z_0_1_0_2
 BV BOUND         z_0_1_0_3
 BV BOUND         z_0_1_0_4
 BV BOUND         z_0_1_0_5
 BV BOUND         z_0_1_0_6
 BV BOUND         z_0_1_0_7
 BV BOUND         z_0_1_0_8
 BV BOUND         z_0_1_0_9
 BV BOUND         z_0_1_0_10
 BV BOUND         z_0_1_1_0
 BV BOUND         z_0_1_1_1
 BV BOUND         z_0_1_1_2
 BV BOUND         z_0_1_1_3
 BV BOUND         z_0_1_1_4
 BV BOUND         z_0_1_1_5
 BV BOUND         z_0_1_1_6
 BV BOUND         z_0_1_1_7
 BV BOUND         z_0_1_1_8
 BV BOUND         z_0_1_1_9
 BV BOUND         z_0_1_1_10
 BV BOUND         z_0_1_2_0
 BV BOUND         z_0_1_2_1
 BV BOUND         z_0_1_2_2
 BV BOUND         z_0_1_2_3
 BV BOUND         z_0_1_2_4
 BV BOUND         z_0_1_2_5
 BV BOUND         z_0_1_2_6
 BV BOUND         z_0_1_2_7
 BV BOUND         z_0_1_2_8
 BV BOUND         z_0_1_2_9
 BV BOUND         z_0_1_2_10
 BV BOUND         z_0_1_3_0
 BV BOUND         z_0_1_3_1
 BV BOUND         z_0_1_3_2
 BV BOUND         z_0_1_3_3
 BV BOUND         z_0_1_3_4
 BV BOUND         z_0_1_3_5
 BV BOUND         z_0_1_4_0
 BV BOUND         z_0_1_4_1
 BV BOUND         z_0_1_4_2
 BV BOUND         z_0_1_4_3
 BV BOUND         z_0_1_4_4
 BV BOUND         z_0_1_4_5
 BV BOUND         z_0_1_4_6
 BV BOUND         z_0_1_4_7
 BV BOUND         z_0_1_4_8
 BV BOUND         z_0_1_4_9
 BV BOUND         z_0_1_4_10
 BV BOUND         z_0_3_0_0
 BV BOUND         z_0_3_0_1
 BV BOUND         z_0_3_0_2
 BV BOUND         z_0_3_0_3
 BV BOUND         z_0_3_0_4
 BV BOUND         z_0_3_0_5
 BV BOUND         z_0_3_0_6
 BV BOUND         z_0_3_0_7
 BV BOUND         z_0_3_2_0
 BV BOUND         z_0_3_2_1
 BV BOUND         z_0_3_2_2
 BV BOUND         z_0_3_2_3
 BV BOUND         z_0_3_2_4
 BV BOUND         z_0_3_2_5
 BV BOUND         z_0_3_2_6
 BV BOUND         z_0_3_2_7
 BV BOUND         z_0_3_2_8
 BV BOUND         z_0_3_2_9
 BV BOUND         z_0_3_2_10
 BV BOUND         z_0_3_3_0
 BV BOUND         z_0_3_3_1
 BV BOUND         z_0_3_3_2
 BV BOUND         z_0_3_3_3
 BV BOUND         z_0_3_3_4
 BV BOUND         z_0_3_3_5
 BV BOUND         z_0_3_3_6
 BV BOUND         z_0_3_3_7
 BV BOUND         z_0_3_3_8
 BV BOUND         z_0_3_4_0
 BV BOUND         z_0_3_4_1
 BV BOUND         z_0_3_4_2
 BV BOUND         z_0_3_4_3
 BV BOUND         z_0_3_4_4
 BV BOUND         z_0_3_4_5
 BV BOUND         z_0_3_4_6
 BV BOUND         z_0_3_4_7
 BV BOUND         z_0_3_4_8
 BV BOUND         z_0_3_4_9
 BV BOUND         z_0_3_4_10
 BV BOUND         z_0_4_0_0
 BV BOUND         z_0_4_0_1
 BV BOUND         z_0_4_0_2
 BV BOUND         z_0_4_0_3
 BV BOUND         z_0_4_0_4
 BV BOUND         z_0_4_0_5
 BV BOUND         z_0_4_0_6
 BV BOUND         z_0_4_0_7
 BV BOUND         z_0_4_1_0
 BV BOUND         z_0_4_1_1
 BV BOUND         z_0_4_1_2
 BV BOUND         z_0_4_1_3
 BV BOUND         z_0_4_1_4
 BV BOUND         z_0_4_1_5
 BV BOUND         z_0_4_1_6
 BV BOUND         z_0_4_1_7
 BV BOUND         z_0_4_1_8
 BV BOUND         z_0_4_1_9
 BV BOUND         z_0_4_1_10
 BV BOUND         z_0_4_2_0
 BV BOUND         z_0_4_2_1
 BV BOUND         z_0_4_2_2
 BV BOUND         z_0_4_2_3
 BV BOUND         z_0_4_2_4
 BV BOUND         z_0_4_2_5
 BV BOUND         z_0_4_2_6
 BV BOUND         z_0_4_2_7
 BV BOUND         z_0_4_2_8
 BV BOUND         z_0_4_2_9
 BV BOUND         z_0_4_2_10
 BV BOUND         z_0_4_3_0
 BV BOUND         z_0_4_3_1
 BV BOUND         z_0_4_3_2
 BV BOUND         z_0_4_3_3
 BV BOUND         z_0_4_3_4
 BV BOUND         z_0_4_3_5
 BV BOUND         z_0_4_3_6
 BV BOUND         z_0_4_3_7
 BV BOUND         z_0_4_3_8
 BV BOUND         z_0_4_3_9
 BV BOUND         z_0_4_3_10
 BV BOUND         z_0_4_4_0
 BV BOUND         z_0_4_4_1
 BV BOUND         z_0_4_4_2
 BV BOUND         z_0_4_4_3
 BV BOUND         z_0_4_4_4
 BV BOUND         z_0_4_4_5
 BV BOUND         z_0_4_4_6
 BV BOUND         z_0_4_4_7
 BV BOUND         z_0_4_4_8
 BV BOUND         z_0_4_4_9
 BV BOUND         z_0_4_4_10
 BV BOUND         z_0_5_0_0
 BV BOUND         z_0_5_0_1
 BV BOUND         z_0_5_0_2
 BV BOUND         z_0_5_0_3
 BV BOUND         z_0_5_0_4
 BV BOUND         z_0_5_0_5
 BV BOUND         z_0_5_0_6
 BV BOUND         z_0_5_0_7
 BV BOUND         z_0_5_0_8
 BV BOUND         z_0_5_0_9
 BV BOUND         z_0_5_0_10
 BV BOUND         z_0_5_1_0
 BV BOUND         z_0_5_1_1
 BV BOUND         z_0_5_1_2
 BV BOUND         z_0_5_1_3
 BV BOUND         z_0_5_1_4
 BV BOUND         z_0_5_1_5
 BV BOUND         z_0_5_1_6
 BV BOUND         z_0_5_1_7
 BV BOUND         z_0_5_2_0
 BV BOUND         z_0_5_2_1
 BV BOUND         z_0_5_2_2
 BV BOUND         z_0_5_2_3
 BV BOUND         z_0_5_2_4
 BV BOUND         z_0_5_2_5
 BV BOUND         z_0_5_2_6
 BV BOUND         z_0_5_2_7
 BV BOUND         z_0_5_3_0
 BV BOUND         z_0_5_3_1
 BV BOUND         z_0_5_3_2
 BV BOUND         z_0_5_3_3
 BV BOUND         z_0_5_3_4
 BV BOUND         z_0_5_3_5
 BV BOUND         z_0_5_3_6
 BV BOUND         z_0_5_3_7
 BV BOUND         z_0_5_3_8
 BV BOUND         z_0_5_3_9
 BV BOUND         z_0_5_3_10
 BV BOUND         z_1_2_0_0
 BV BOUND         z_1_2_0_1
 BV BOUND         z_1_2_0_2
 BV BOUND         z_1_2_0_3
 BV BOUND         z_1_2_0_4
 BV BOUND         z_1_2_0_5
 BV BOUND         z_1_2_0_6
 BV BOUND         z_1_2_0_7
 BV BOUND         z_1_2_0_8
 BV BOUND         z_1_2_1_0
 BV BOUND         z_1_2_1_1
 BV BOUND         z_1_2_1_2
 BV BOUND         z_1_2_1_3
 BV BOUND         z_1_2_1_4
 BV BOUND         z_1_2_1_5
 BV BOUND         z_1_2_1_6
 BV BOUND         z_1_2_1_7
 BV BOUND         z_1_2_1_8
 BV BOUND         z_1_2_1_9
 BV BOUND         z_1_2_1_10
 BV BOUND         z_1_2_2_0
 BV BOUND         z_1_2_2_1
 BV BOUND         z_1_2_2_2
 BV BOUND         z_1_2_2_3
 BV BOUND         z_1_2_2_4
 BV BOUND         z_1_2_2_5
 BV BOUND         z_1_2_2_6
 BV BOUND         z_1_2_2_7
 BV BOUND         z_1_2_2_8
 BV BOUND         z_1_2_3_0
 BV BOUND         z_1_2_3_1
 BV BOUND         z_1_2_3_2
 BV BOUND         z_1_2_3_3
 BV BOUND         z_1_2_3_4
 BV BOUND         z_1_2_3_5
 BV BOUND         z_1_2_3_6
 BV BOUND         z_1_2_3_7
 BV BOUND         z_1_2_3_8
 BV BOUND         z_1_2_3_9
 BV BOUND         z_1_2_3_10
 BV BOUND         z_1_2_4_0
 BV BOUND         z_1_2_4_1
 BV BOUND         z_1_2_4_2
 BV BOUND         z_1_2_4_3
 BV BOUND         z_1_2_4_4
 BV BOUND         z_1_5_0_0
 BV BOUND         z_1_5_0_1
 BV BOUND         z_1_5_0_2
 BV BOUND         z_1_5_0_3
 BV BOUND         z_1_5_0_4
 BV BOUND         z_1_5_0_5
 BV BOUND         z_1_5_0_6
 BV BOUND         z_1_5_0_7
 BV BOUND         z_1_5_0_8
 BV BOUND         z_1_5_0_9
 BV BOUND         z_1_5_0_10
 BV BOUND         z_1_5_1_0
 BV BOUND         z_1_5_1_1
 BV BOUND         z_1_5_1_2
 BV BOUND         z_1_5_1_3
 BV BOUND         z_1_5_1_4
 BV BOUND         z_1_5_1_5
 BV BOUND         z_1_5_1_6
 BV BOUND         z_1_5_1_7
 BV BOUND         z_1_5_2_0
 BV BOUND         z_1_5_2_1
 BV BOUND         z_1_5_2_2
 BV BOUND         z_1_5_2_3
 BV BOUND         z_1_5_2_4
 BV BOUND         z_1_5_2_5
 BV BOUND         z_1_5_2_6
 BV BOUND         z_1_5_2_7
 BV BOUND         z_1_5_3_0
 BV BOUND         z_1_5_3_1
 BV BOUND         z_1_5_3_2
 BV BOUND         z_1_5_3_3
 BV BOUND         z_1_5_3_4
 BV BOUND         z_1_5_3_5
 BV BOUND         z_1_5_3_6
 BV BOUND         z_1_5_3_7
 BV BOUND         z_1_5_3_8
 BV BOUND         z_1_5_3_9
 BV BOUND         z_1_5_3_10
 BV BOUND         z_1_6_0_0
 BV BOUND         z_1_6_0_1
 BV BOUND         z_1_6_0_2
 BV BOUND         z_1_6_0_3
 BV BOUND         z_1_6_0_4
 BV BOUND         z_1_6_0_5
 BV BOUND         z_1_6_0_6
 BV BOUND         z_1_6_0_7
 BV BOUND         z_1_6_0_8
 BV BOUND         z_1_6_0_9
 BV BOUND         z_1_6_0_10
 BV BOUND         z_1_6_1_0
 BV BOUND         z_1_6_1_1
 BV BOUND         z_1_6_1_2
 BV BOUND         z_1_6_1_3
 BV BOUND         z_1_6_1_4
 BV BOUND         z_1_6_1_5
 BV BOUND         z_1_6_1_6
 BV BOUND         z_1_6_1_7
 BV BOUND         z_1_6_1_8
 BV BOUND         z_1_6_1_9
 BV BOUND         z_1_6_1_10
 BV BOUND         z_1_6_2_0
 BV BOUND         z_1_6_2_1
 BV BOUND         z_1_6_2_2
 BV BOUND         z_1_6_2_3
 BV BOUND         z_1_6_2_4
 BV BOUND         z_1_6_2_5
 BV BOUND         z_1_6_2_6
 BV BOUND         z_1_6_2_7
 BV BOUND         z_1_6_2_8
 BV BOUND         z_1_6_3_0
 BV BOUND         z_1_6_3_1
 BV BOUND         z_1_6_3_2
 BV BOUND         z_1_6_3_3
 BV BOUND         z_1_6_3_4
 BV BOUND         z_1_6_3_5
 BV BOUND         z_1_6_3_6
 BV BOUND         z_1_6_3_7
 BV BOUND         z_1_6_4_0
 BV BOUND         z_1_6_4_1
 BV BOUND         z_1_6_4_2
 BV BOUND         z_1_6_4_3
 BV BOUND         z_1_6_4_4
 BV BOUND         z_1_6_4_5
 BV BOUND         z_1_6_4_6
 BV BOUND         z_1_6_4_7
 BV BOUND         z_1_6_4_8
 BV BOUND         z_1_6_4_9
 BV BOUND         z_1_6_4_10
 BV BOUND         z_1_7_0_0
 BV BOUND         z_1_7_0_1
 BV BOUND         z_1_7_0_2
 BV BOUND         z_1_7_0_3
 BV BOUND         z_1_7_0_4
 BV BOUND         z_1_7_0_5
 BV BOUND         z_1_7_0_6
 BV BOUND         z_1_7_0_7
 BV BOUND         z_1_7_1_0
 BV BOUND         z_1_7_1_1
 BV BOUND         z_1_7_1_2
 BV BOUND         z_1_7_1_3
 BV BOUND         z_1_7_1_4
 BV BOUND         z_1_7_1_5
 BV BOUND         z_1_7_1_6
 BV BOUND         z_1_7_1_7
 BV BOUND         z_1_7_1_8
 BV BOUND         z_1_7_1_9
 BV BOUND         z_1_7_1_10
 BV BOUND         z_1_7_2_0
 BV BOUND         z_1_7_2_1
 BV BOUND         z_1_7_2_2
 BV BOUND         z_1_7_2_3
 BV BOUND         z_1_7_2_4
 BV BOUND         z_1_7_2_5
 BV BOUND         z_1_7_2_6
 BV BOUND         z_1_7_2_7
 BV BOUND         z_1_7_2_8
 BV BOUND         z_1_7_2_9
 BV BOUND         z_1_7_2_10
 BV BOUND         z_1_7_3_0
 BV BOUND         z_1_7_3_1
 BV BOUND         z_1_7_3_2
 BV BOUND         z_1_7_3_3
 BV BOUND         z_1_7_3_4
 BV BOUND         z_1_7_3_5
 BV BOUND         z_1_7_3_6
 BV BOUND         z_1_7_3_7
 BV BOUND         z_1_7_3_8
 BV BOUND         z_1_7_3_9
 BV BOUND         z_1_7_3_10
 BV BOUND         z_1_7_4_0
 BV BOUND         z_1_7_4_1
 BV BOUND         z_1_7_4_2
 BV BOUND         z_1_7_4_3
 BV BOUND         z_1_7_4_4
 BV BOUND         z_1_7_4_5
 BV BOUND         z_1_7_4_6
 BV BOUND         z_1_7_4_7
 BV BOUND         z_1_7_4_8
 BV BOUND         z_1_7_4_9
 BV BOUND         z_1_7_4_10
 BV BOUND         z_2_0_0_0
 BV BOUND         z_2_0_0_1
 BV BOUND         z_2_0_0_2
 BV BOUND         z_2_0_0_3
 BV BOUND         z_2_0_0_4
 BV BOUND         z_2_0_0_5
 BV BOUND         z_2_0_0_6
 BV BOUND         z_2_0_0_7
 BV BOUND         z_2_0_0_8
 BV BOUND         z_2_0_0_9
 BV BOUND         z_2_0_0_10
 BV BOUND         z_2_0_1_0
 BV BOUND         z_2_0_1_1
 BV BOUND         z_2_0_1_2
 BV BOUND         z_2_0_1_3
 BV BOUND         z_2_0_1_4
 BV BOUND         z_2_0_1_5
 BV BOUND         z_2_0_1_6
 BV BOUND         z_2_0_1_7
 BV BOUND         z_2_0_1_8
 BV BOUND         z_2_0_1_9
 BV BOUND         z_2_0_1_10
 BV BOUND         z_2_0_2_0
 BV BOUND         z_2_0_2_1
 BV BOUND         z_2_0_2_2
 BV BOUND         z_2_0_2_3
 BV BOUND         z_2_0_2_4
 BV BOUND         z_2_0_2_5
 BV BOUND         z_2_0_2_6
 BV BOUND         z_2_0_2_7
 BV BOUND         z_2_0_2_8
 BV BOUND         z_2_0_2_9
 BV BOUND         z_2_0_2_10
 BV BOUND         z_2_0_3_0
 BV BOUND         z_2_0_3_1
 BV BOUND         z_2_0_3_2
 BV BOUND         z_2_0_3_3
 BV BOUND         z_2_0_3_4
 BV BOUND         z_2_0_3_5
 BV BOUND         z_2_0_3_6
 BV BOUND         z_2_0_3_7
 BV BOUND         z_2_0_4_0
 BV BOUND         z_2_0_4_1
 BV BOUND         z_2_0_4_2
 BV BOUND         z_2_0_4_3
 BV BOUND         z_2_0_4_4
 BV BOUND         z_2_0_4_5
 BV BOUND         z_2_0_4_6
 BV BOUND         z_2_0_4_7
 BV BOUND         z_2_0_4_8
 BV BOUND         z_2_0_4_9
 BV BOUND         z_2_0_4_10
 BV BOUND         z_2_2_0_0
 BV BOUND         z_2_2_0_1
 BV BOUND         z_2_2_0_2
 BV BOUND         z_2_2_0_3
 BV BOUND         z_2_2_0_4
 BV BOUND         z_2_2_0_5
 BV BOUND         z_2_2_0_6
 BV BOUND         z_2_2_0_7
 BV BOUND         z_2_2_0_8
 BV BOUND         z_2_2_1_0
 BV BOUND         z_2_2_1_1
 BV BOUND         z_2_2_1_2
 BV BOUND         z_2_2_1_3
 BV BOUND         z_2_2_1_4
 BV BOUND         z_2_2_1_5
 BV BOUND         z_2_2_1_6
 BV BOUND         z_2_2_1_7
 BV BOUND         z_2_2_1_8
 BV BOUND         z_2_2_1_9
 BV BOUND         z_2_2_1_10
 BV BOUND         z_2_2_2_0
 BV BOUND         z_2_2_2_1
 BV BOUND         z_2_2_2_2
 BV BOUND         z_2_2_2_3
 BV BOUND         z_2_2_2_4
 BV BOUND         z_2_2_2_5
 BV BOUND         z_2_2_2_6
 BV BOUND         z_2_2_2_7
 BV BOUND         z_2_2_2_8
 BV BOUND         z_2_2_3_0
 BV BOUND         z_2_2_3_1
 BV BOUND         z_2_2_3_2
 BV BOUND         z_2_2_3_3
 BV BOUND         z_2_2_3_4
 BV BOUND         z_2_2_3_5
 BV BOUND         z_2_2_3_6
 BV BOUND         z_2_2_3_7
 BV BOUND         z_2_2_3_8
 BV BOUND         z_2_2_3_9
 BV BOUND         z_2_2_3_10
 BV BOUND         z_2_2_4_0
 BV BOUND         z_2_2_4_1
 BV BOUND         z_2_2_4_2
 BV BOUND         z_2_2_4_3
 BV BOUND         z_2_2_4_4
 BV BOUND         z_2_3_0_0
 BV BOUND         z_2_3_0_1
 BV BOUND         z_2_3_0_2
 BV BOUND         z_2_3_0_3
 BV BOUND         z_2_3_0_4
 BV BOUND         z_2_3_0_5
 BV BOUND         z_2_3_0_6
 BV BOUND         z_2_3_0_7
 BV BOUND         z_2_3_2_0
 BV BOUND         z_2_3_2_1
 BV BOUND         z_2_3_2_2
 BV BOUND         z_2_3_2_3
 BV BOUND         z_2_3_2_4
 BV BOUND         z_2_3_2_5
 BV BOUND         z_2_3_2_6
 BV BOUND         z_2_3_2_7
 BV BOUND         z_2_3_2_8
 BV BOUND         z_2_3_2_9
 BV BOUND         z_2_3_2_10
 BV BOUND         z_2_3_3_0
 BV BOUND         z_2_3_3_1
 BV BOUND         z_2_3_3_2
 BV BOUND         z_2_3_3_3
 BV BOUND         z_2_3_3_4
 BV BOUND         z_2_3_3_5
 BV BOUND         z_2_3_3_6
 BV BOUND         z_2_3_3_7
 BV BOUND         z_2_3_3_8
 BV BOUND         z_2_3_4_0
 BV BOUND         z_2_3_4_1
 BV BOUND         z_2_3_4_2
 BV BOUND         z_2_3_4_3
 BV BOUND         z_2_3_4_4
 BV BOUND         z_2_3_4_5
 BV BOUND         z_2_3_4_6
 BV BOUND         z_2_3_4_7
 BV BOUND         z_2_3_4_8
 BV BOUND         z_2_3_4_9
 BV BOUND         z_2_3_4_10
 BV BOUND         z_2_5_0_0
 BV BOUND         z_2_5_0_1
 BV BOUND         z_2_5_0_2
 BV BOUND         z_2_5_0_3
 BV BOUND         z_2_5_0_4
 BV BOUND         z_2_5_0_5
 BV BOUND         z_2_5_0_6
 BV BOUND         z_2_5_0_7
 BV BOUND         z_2_5_0_8
 BV BOUND         z_2_5_0_9
 BV BOUND         z_2_5_0_10
 BV BOUND         z_2_5_1_0
 BV BOUND         z_2_5_1_1
 BV BOUND         z_2_5_1_2
 BV BOUND         z_2_5_1_3
 BV BOUND         z_2_5_1_4
 BV BOUND         z_2_5_1_5
 BV BOUND         z_2_5_1_6
 BV BOUND         z_2_5_1_7
 BV BOUND         z_2_5_2_0
 BV BOUND         z_2_5_2_1
 BV BOUND         z_2_5_2_2
 BV BOUND         z_2_5_2_3
 BV BOUND         z_2_5_2_4
 BV BOUND         z_2_5_2_5
 BV BOUND         z_2_5_2_6
 BV BOUND         z_2_5_2_7
 BV BOUND         z_2_5_3_0
 BV BOUND         z_2_5_3_1
 BV BOUND         z_2_5_3_2
 BV BOUND         z_2_5_3_3
 BV BOUND         z_2_5_3_4
 BV BOUND         z_2_5_3_5
 BV BOUND         z_2_5_3_6
 BV BOUND         z_2_5_3_7
 BV BOUND         z_2_5_3_8
 BV BOUND         z_2_5_3_9
 BV BOUND         z_2_5_3_10
 BV BOUND         z_2_6_0_0
 BV BOUND         z_2_6_0_1
 BV BOUND         z_2_6_0_2
 BV BOUND         z_2_6_0_3
 BV BOUND         z_2_6_0_4
 BV BOUND         z_2_6_0_5
 BV BOUND         z_2_6_0_6
 BV BOUND         z_2_6_0_7
 BV BOUND         z_2_6_0_8
 BV BOUND         z_2_6_0_9
 BV BOUND         z_2_6_0_10
 BV BOUND         z_2_6_1_0
 BV BOUND         z_2_6_1_1
 BV BOUND         z_2_6_1_2
 BV BOUND         z_2_6_1_3
 BV BOUND         z_2_6_1_4
 BV BOUND         z_2_6_1_5
 BV BOUND         z_2_6_1_6
 BV BOUND         z_2_6_1_7
 BV BOUND         z_2_6_1_8
 BV BOUND         z_2_6_1_9
 BV BOUND         z_2_6_1_10
 BV BOUND         z_2_6_2_0
 BV BOUND         z_2_6_2_1
 BV BOUND         z_2_6_2_2
 BV BOUND         z_2_6_2_3
 BV BOUND         z_2_6_2_4
 BV BOUND         z_2_6_2_5
 BV BOUND         z_2_6_2_6
 BV BOUND         z_2_6_2_7
 BV BOUND         z_2_6_2_8
 BV BOUND         z_2_6_3_0
 BV BOUND         z_2_6_3_1
 BV BOUND         z_2_6_3_2
 BV BOUND         z_2_6_3_3
 BV BOUND         z_2_6_3_4
 BV BOUND         z_2_6_3_5
 BV BOUND         z_2_6_3_6
 BV BOUND         z_2_6_3_7
 BV BOUND         z_2_6_4_0
 BV BOUND         z_2_6_4_1
 BV BOUND         z_2_6_4_2
 BV BOUND         z_2_6_4_3
 BV BOUND         z_2_6_4_4
 BV BOUND         z_2_6_4_5
 BV BOUND         z_2_6_4_6
 BV BOUND         z_2_6_4_7
 BV BOUND         z_2_6_4_8
 BV BOUND         z_2_6_4_9
 BV BOUND         z_2_6_4_10
 BV BOUND         z_3_2_0_0
 BV BOUND         z_3_2_0_1
 BV BOUND         z_3_2_0_2
 BV BOUND         z_3_2_0_3
 BV BOUND         z_3_2_0_4
 BV BOUND         z_3_2_0_5
 BV BOUND         z_3_2_0_6
 BV BOUND         z_3_2_0_7
 BV BOUND         z_3_2_0_8
 BV BOUND         z_3_2_1_0
 BV BOUND         z_3_2_1_1
 BV BOUND         z_3_2_1_2
 BV BOUND         z_3_2_1_3
 BV BOUND         z_3_2_1_4
 BV BOUND         z_3_2_1_5
 BV BOUND         z_3_2_1_6
 BV BOUND         z_3_2_1_7
 BV BOUND         z_3_2_1_8
 BV BOUND         z_3_2_1_9
 BV BOUND         z_3_2_1_10
 BV BOUND         z_3_2_2_0
 BV BOUND         z_3_2_2_1
 BV BOUND         z_3_2_2_2
 BV BOUND         z_3_2_2_3
 BV BOUND         z_3_2_2_4
 BV BOUND         z_3_2_2_5
 BV BOUND         z_3_2_2_6
 BV BOUND         z_3_2_2_7
 BV BOUND         z_3_2_2_8
 BV BOUND         z_3_2_3_0
 BV BOUND         z_3_2_3_1
 BV BOUND         z_3_2_3_2
 BV BOUND         z_3_2_3_3
 BV BOUND         z_3_2_3_4
 BV BOUND         z_3_2_3_5
 BV BOUND         z_3_2_3_6
 BV BOUND         z_3_2_3_7
 BV BOUND         z_3_2_3_8
 BV BOUND         z_3_2_3_9
 BV BOUND         z_3_2_3_10
 BV BOUND         z_3_2_4_0
 BV BOUND         z_3_2_4_1
 BV BOUND         z_3_2_4_2
 BV BOUND         z_3_2_4_3
 BV BOUND         z_3_2_4_4
 BV BOUND         z_3_5_0_0
 BV BOUND         z_3_5_0_1
 BV BOUND         z_3_5_0_2
 BV BOUND         z_3_5_0_3
 BV BOUND         z_3_5_0_4
 BV BOUND         z_3_5_0_5
 BV BOUND         z_3_5_0_6
 BV BOUND         z_3_5_0_7
 BV BOUND         z_3_5_0_8
 BV BOUND         z_3_5_0_9
 BV BOUND         z_3_5_0_10
 BV BOUND         z_3_5_1_0
 BV BOUND         z_3_5_1_1
 BV BOUND         z_3_5_1_2
 BV BOUND         z_3_5_1_3
 BV BOUND         z_3_5_1_4
 BV BOUND         z_3_5_1_5
 BV BOUND         z_3_5_1_6
 BV BOUND         z_3_5_1_7
 BV BOUND         z_3_5_2_0
 BV BOUND         z_3_5_2_1
 BV BOUND         z_3_5_2_2
 BV BOUND         z_3_5_2_3
 BV BOUND         z_3_5_2_4
 BV BOUND         z_3_5_2_5
 BV BOUND         z_3_5_2_6
 BV BOUND         z_3_5_2_7
 BV BOUND         z_3_5_3_0
 BV BOUND         z_3_5_3_1
 BV BOUND         z_3_5_3_2
 BV BOUND         z_3_5_3_3
 BV BOUND         z_3_5_3_4
 BV BOUND         z_3_5_3_5
 BV BOUND         z_3_5_3_6
 BV BOUND         z_3_5_3_7
 BV BOUND         z_3_5_3_8
 BV BOUND         z_3_5_3_9
 BV BOUND         z_3_5_3_10
 BV BOUND         z_3_6_0_0
 BV BOUND         z_3_6_0_1
 BV BOUND         z_3_6_0_2
 BV BOUND         z_3_6_0_3
 BV BOUND         z_3_6_0_4
 BV BOUND         z_3_6_0_5
 BV BOUND         z_3_6_0_6
 BV BOUND         z_3_6_0_7
 BV BOUND         z_3_6_0_8
 BV BOUND         z_3_6_0_9
 BV BOUND         z_3_6_0_10
 BV BOUND         z_3_6_1_0
 BV BOUND         z_3_6_1_1
 BV BOUND         z_3_6_1_2
 BV BOUND         z_3_6_1_3
 BV BOUND         z_3_6_1_4
 BV BOUND         z_3_6_1_5
 BV BOUND         z_3_6_1_6
 BV BOUND         z_3_6_1_7
 BV BOUND         z_3_6_1_8
 BV BOUND         z_3_6_1_9
 BV BOUND         z_3_6_1_10
 BV BOUND         z_3_6_2_0
 BV BOUND         z_3_6_2_1
 BV BOUND         z_3_6_2_2
 BV BOUND         z_3_6_2_3
 BV BOUND         z_3_6_2_4
 BV BOUND         z_3_6_2_5
 BV BOUND         z_3_6_2_6
 BV BOUND         z_3_6_2_7
 BV BOUND         z_3_6_2_8
 BV BOUND         z_3_6_3_0
 BV BOUND         z_3_6_3_1
 BV BOUND         z_3_6_3_2
 BV BOUND         z_3_6_3_3
 BV BOUND         z_3_6_3_4
 BV BOUND         z_3_6_3_5
 BV BOUND         z_3_6_3_6
 BV BOUND         z_3_6_3_7
 BV BOUND         z_3_6_4_0
 BV BOUND         z_3_6_4_1
 BV BOUND         z_3_6_4_2
 BV BOUND         z_3_6_4_3
 BV BOUND         z_3_6_4_4
 BV BOUND         z_3_6_4_5
 BV BOUND         z_3_6_4_6
 BV BOUND         z_3_6_4_7
 BV BOUND         z_3_6_4_8
 BV BOUND         z_3_6_4_9
 BV BOUND         z_3_6_4_10
 BV BOUND         z_3_7_0_0
 BV BOUND         z_3_7_0_1
 BV BOUND         z_3_7_0_2
 BV BOUND         z_3_7_0_3
 BV BOUND         z_3_7_0_4
 BV BOUND         z_3_7_0_5
 BV BOUND         z_3_7_0_6
 BV BOUND         z_3_7_0_7
 BV BOUND         z_3_7_1_0
 BV BOUND         z_3_7_1_1
 BV BOUND         z_3_7_1_2
 BV BOUND         z_3_7_1_3
 BV BOUND         z_3_7_1_4
 BV BOUND         z_3_7_1_5
 BV BOUND         z_3_7_1_6
 BV BOUND         z_3_7_1_7
 BV BOUND         z_3_7_1_8
 BV BOUND         z_3_7_1_9
 BV BOUND         z_3_7_1_10
 BV BOUND         z_3_7_2_0
 BV BOUND         z_3_7_2_1
 BV BOUND         z_3_7_2_2
 BV BOUND         z_3_7_2_3
 BV BOUND         z_3_7_2_4
 BV BOUND         z_3_7_2_5
 BV BOUND         z_3_7_2_6
 BV BOUND         z_3_7_2_7
 BV BOUND         z_3_7_2_8
 BV BOUND         z_3_7_2_9
 BV BOUND         z_3_7_2_10
 BV BOUND         z_3_7_3_0
 BV BOUND         z_3_7_3_1
 BV BOUND         z_3_7_3_2
 BV BOUND         z_3_7_3_3
 BV BOUND         z_3_7_3_4
 BV BOUND         z_3_7_3_5
 BV BOUND         z_3_7_3_6
 BV BOUND         z_3_7_3_7
 BV BOUND         z_3_7_3_8
 BV BOUND         z_3_7_3_9
 BV BOUND         z_3_7_3_10
 BV BOUND         z_3_7_4_0
 BV BOUND         z_3_7_4_1
 BV BOUND         z_3_7_4_2
 BV BOUND         z_3_7_4_3
 BV BOUND         z_3_7_4_4
 BV BOUND         z_3_7_4_5
 BV BOUND         z_3_7_4_6
 BV BOUND         z_3_7_4_7
 BV BOUND         z_3_7_4_8
 BV BOUND         z_3_7_4_9
 BV BOUND         z_3_7_4_10
 BV BOUND         z_4_2_0_0
 BV BOUND         z_4_2_0_1
 BV BOUND         z_4_2_0_2
 BV BOUND         z_4_2_0_3
 BV BOUND         z_4_2_0_4
 BV BOUND         z_4_2_0_5
 BV BOUND         z_4_2_0_6
 BV BOUND         z_4_2_0_7
 BV BOUND         z_4_2_0_8
 BV BOUND         z_4_2_1_0
 BV BOUND         z_4_2_1_1
 BV BOUND         z_4_2_1_2
 BV BOUND         z_4_2_1_3
 BV BOUND         z_4_2_1_4
 BV BOUND         z_4_2_1_5
 BV BOUND         z_4_2_1_6
 BV BOUND         z_4_2_1_7
 BV BOUND         z_4_2_1_8
 BV BOUND         z_4_2_1_9
 BV BOUND         z_4_2_1_10
 BV BOUND         z_4_2_2_0
 BV BOUND         z_4_2_2_1
 BV BOUND         z_4_2_2_2
 BV BOUND         z_4_2_2_3
 BV BOUND         z_4_2_2_4
 BV BOUND         z_4_2_2_5
 BV BOUND         z_4_2_2_6
 BV BOUND         z_4_2_2_7
 BV BOUND         z_4_2_2_8
 BV BOUND         z_4_2_3_0
 BV BOUND         z_4_2_3_1
 BV BOUND         z_4_2_3_2
 BV BOUND         z_4_2_3_3
 BV BOUND         z_4_2_3_4
 BV BOUND         z_4_2_3_5
 BV BOUND         z_4_2_3_6
 BV BOUND         z_4_2_3_7
 BV BOUND         z_4_2_3_8
 BV BOUND         z_4_2_3_9
 BV BOUND         z_4_2_3_10
 BV BOUND         z_4_2_4_0
 BV BOUND         z_4_2_4_1
 BV BOUND         z_4_2_4_2
 BV BOUND         z_4_2_4_3
 BV BOUND         z_4_2_4_4
 BV BOUND         z_4_3_0_0
 BV BOUND         z_4_3_0_1
 BV BOUND         z_4_3_0_2
 BV BOUND         z_4_3_0_3
 BV BOUND         z_4_3_0_4
 BV BOUND         z_4_3_0_5
 BV BOUND         z_4_3_0_6
 BV BOUND         z_4_3_0_7
 BV BOUND         z_4_3_2_0
 BV BOUND         z_4_3_2_1
 BV BOUND         z_4_3_2_2
 BV BOUND         z_4_3_2_3
 BV BOUND         z_4_3_2_4
 BV BOUND         z_4_3_2_5
 BV BOUND         z_4_3_2_6
 BV BOUND         z_4_3_2_7
 BV BOUND         z_4_3_2_8
 BV BOUND         z_4_3_2_9
 BV BOUND         z_4_3_2_10
 BV BOUND         z_4_3_3_0
 BV BOUND         z_4_3_3_1
 BV BOUND         z_4_3_3_2
 BV BOUND         z_4_3_3_3
 BV BOUND         z_4_3_3_4
 BV BOUND         z_4_3_3_5
 BV BOUND         z_4_3_3_6
 BV BOUND         z_4_3_3_7
 BV BOUND         z_4_3_3_8
 BV BOUND         z_4_3_4_0
 BV BOUND         z_4_3_4_1
 BV BOUND         z_4_3_4_2
 BV BOUND         z_4_3_4_3
 BV BOUND         z_4_3_4_4
 BV BOUND         z_4_3_4_5
 BV BOUND         z_4_3_4_6
 BV BOUND         z_4_3_4_7
 BV BOUND         z_4_3_4_8
 BV BOUND         z_4_3_4_9
 BV BOUND         z_4_3_4_10
 BV BOUND         z_4_4_0_0
 BV BOUND         z_4_4_0_1
 BV BOUND         z_4_4_0_2
 BV BOUND         z_4_4_0_3
 BV BOUND         z_4_4_0_4
 BV BOUND         z_4_4_0_5
 BV BOUND         z_4_4_0_6
 BV BOUND         z_4_4_0_7
 BV BOUND         z_4_4_1_0
 BV BOUND         z_4_4_1_1
 BV BOUND         z_4_4_1_2
 BV BOUND         z_4_4_1_3
 BV BOUND         z_4_4_1_4
 BV BOUND         z_4_4_1_5
 BV BOUND         z_4_4_1_6
 BV BOUND         z_4_4_1_7
 BV BOUND         z_4_4_1_8
 BV BOUND         z_4_4_1_9
 BV BOUND         z_4_4_1_10
 BV BOUND         z_4_4_2_0
 BV BOUND         z_4_4_2_1
 BV BOUND         z_4_4_2_2
 BV BOUND         z_4_4_2_3
 BV BOUND         z_4_4_2_4
 BV BOUND         z_4_4_2_5
 BV BOUND         z_4_4_2_6
 BV BOUND         z_4_4_2_7
 BV BOUND         z_4_4_2_8
 BV BOUND         z_4_4_2_9
 BV BOUND         z_4_4_2_10
 BV BOUND         z_4_4_3_0
 BV BOUND         z_4_4_3_1
 BV BOUND         z_4_4_3_2
 BV BOUND         z_4_4_3_3
 BV BOUND         z_4_4_3_4
 BV BOUND         z_4_4_3_5
 BV BOUND         z_4_4_3_6
 BV BOUND         z_4_4_3_7
 BV BOUND         z_4_4_3_8
 BV BOUND         z_4_4_3_9
 BV BOUND         z_4_4_3_10
 BV BOUND         z_4_4_4_0
 BV BOUND         z_4_4_4_1
 BV BOUND         z_4_4_4_2
 BV BOUND         z_4_4_4_3
 BV BOUND         z_4_4_4_4
 BV BOUND         z_4_4_4_5
 BV BOUND         z_4_4_4_6
 BV BOUND         z_4_4_4_7
 BV BOUND         z_4_4_4_8
 BV BOUND         z_4_4_4_9
 BV BOUND         z_4_4_4_10
 BV BOUND         z_4_5_0_0
 BV BOUND         z_4_5_0_1
 BV BOUND         z_4_5_0_2
 BV BOUND         z_4_5_0_3
 BV BOUND         z_4_5_0_4
 BV BOUND         z_4_5_0_5
 BV BOUND         z_4_5_0_6
 BV BOUND         z_4_5_0_7
 BV BOUND         z_4_5_0_8
 BV BOUND         z_4_5_0_9
 BV BOUND         z_4_5_0_10
 BV BOUND         z_4_5_1_0
 BV BOUND         z_4_5_1_1
 BV BOUND         z_4_5_1_2
 BV BOUND         z_4_5_1_3
 BV BOUND         z_4_5_1_4
 BV BOUND         z_4_5_1_5
 BV BOUND         z_4_5_1_6
 BV BOUND         z_4_5_1_7
 BV BOUND         z_4_5_2_0
 BV BOUND         z_4_5_2_1
 BV BOUND         z_4_5_2_2
 BV BOUND         z_4_5_2_3
 BV BOUND         z_4_5_2_4
 BV BOUND         z_4_5_2_5
 BV BOUND         z_4_5_2_6
 BV BOUND         z_4_5_2_7
 BV BOUND         z_4_5_3_0
 BV BOUND         z_4_5_3_1
 BV BOUND         z_4_5_3_2
 BV BOUND         z_4_5_3_3
 BV BOUND         z_4_5_3_4
 BV BOUND         z_4_5_3_5
 BV BOUND         z_4_5_3_6
 BV BOUND         z_4_5_3_7
 BV BOUND         z_4_5_3_8
 BV BOUND         z_4_5_3_9
 BV BOUND         z_4_5_3_10
 BV BOUND         z_4_6_0_0
 BV BOUND         z_4_6_0_1
 BV BOUND         z_4_6_0_2
 BV BOUND         z_4_6_0_3
 BV BOUND         z_4_6_0_4
 BV BOUND         z_4_6_0_5
 BV BOUND         z_4_6_0_6
 BV BOUND         z_4_6_0_7
 BV BOUND         z_4_6_0_8
 BV BOUND         z_4_6_0_9
 BV BOUND         z_4_6_0_10
 BV BOUND         z_4_6_1_0
 BV BOUND         z_4_6_1_1
 BV BOUND         z_4_6_1_2
 BV BOUND         z_4_6_1_3
 BV BOUND         z_4_6_1_4
 BV BOUND         z_4_6_1_5
 BV BOUND         z_4_6_1_6
 BV BOUND         z_4_6_1_7
 BV BOUND         z_4_6_1_8
 BV BOUND         z_4_6_1_9
 BV BOUND         z_4_6_1_10
 BV BOUND         z_4_6_2_0
 BV BOUND         z_4_6_2_1
 BV BOUND         z_4_6_2_2
 BV BOUND         z_4_6_2_3
 BV BOUND         z_4_6_2_4
 BV BOUND         z_4_6_2_5
 BV BOUND         z_4_6_2_6
 BV BOUND         z_4_6_2_7
 BV BOUND         z_4_6_2_8
 BV BOUND         z_4_6_3_0
 BV BOUND         z_4_6_3_1
 BV BOUND         z_4_6_3_2
 BV BOUND         z_4_6_3_3
 BV BOUND         z_4_6_3_4
 BV BOUND         z_4_6_3_5
 BV BOUND         z_4_6_3_6
 BV BOUND         z_4_6_3_7
 BV BOUND         z_4_6_4_0
 BV BOUND         z_4_6_4_1
 BV BOUND         z_4_6_4_2
 BV BOUND         z_4_6_4_3
 BV BOUND         z_4_6_4_4
 BV BOUND         z_4_6_4_5
 BV BOUND         z_4_6_4_6
 BV BOUND         z_4_6_4_7
 BV BOUND         z_4_6_4_8
 BV BOUND         z_4_6_4_9
 BV BOUND         z_4_6_4_10
 BV BOUND         z_4_7_0_0
 BV BOUND         z_4_7_0_1
 BV BOUND         z_4_7_0_2
 BV BOUND         z_4_7_0_3
 BV BOUND         z_4_7_0_4
 BV BOUND         z_4_7_0_5
 BV BOUND         z_4_7_0_6
 BV BOUND         z_4_7_0_7
 BV BOUND         z_4_7_1_0
 BV BOUND         z_4_7_1_1
 BV BOUND         z_4_7_1_2
 BV BOUND         z_4_7_1_3
 BV BOUND         z_4_7_1_4
 BV BOUND         z_4_7_1_5
 BV BOUND         z_4_7_1_6
 BV BOUND         z_4_7_1_7
 BV BOUND         z_4_7_1_8
 BV BOUND         z_4_7_1_9
 BV BOUND         z_4_7_1_10
 BV BOUND         z_4_7_2_0
 BV BOUND         z_4_7_2_1
 BV BOUND         z_4_7_2_2
 BV BOUND         z_4_7_2_3
 BV BOUND         z_4_7_2_4
 BV BOUND         z_4_7_2_5
 BV BOUND         z_4_7_2_6
 BV BOUND         z_4_7_2_7
 BV BOUND         z_4_7_2_8
 BV BOUND         z_4_7_2_9
 BV BOUND         z_4_7_2_10
 BV BOUND         z_4_7_3_0
 BV BOUND         z_4_7_3_1
 BV BOUND         z_4_7_3_2
 BV BOUND         z_4_7_3_3
 BV BOUND         z_4_7_3_4
 BV BOUND         z_4_7_3_5
 BV BOUND         z_4_7_3_6
 BV BOUND         z_4_7_3_7
 BV BOUND         z_4_7_3_8
 BV BOUND         z_4_7_3_9
 BV BOUND         z_4_7_3_10
 BV BOUND         z_4_7_4_0
 BV BOUND         z_4_7_4_1
 BV BOUND         z_4_7_4_2
 BV BOUND         z_4_7_4_3
 BV BOUND         z_4_7_4_4
 BV BOUND         z_4_7_4_5
 BV BOUND         z_4_7_4_6
 BV BOUND         z_4_7_4_7
 BV BOUND         z_4_7_4_8
 BV BOUND         z_4_7_4_9
 BV BOUND         z_4_7_4_10
 BV BOUND         z_5_0_0_0
 BV BOUND         z_5_0_0_1
 BV BOUND         z_5_0_0_2
 BV BOUND         z_5_0_0_3
 BV BOUND         z_5_0_0_4
 BV BOUND         z_5_0_0_5
 BV BOUND         z_5_0_0_6
 BV BOUND         z_5_0_0_7
 BV BOUND         z_5_0_0_8
 BV BOUND         z_5_0_0_9
 BV BOUND         z_5_0_0_10
 BV BOUND         z_5_0_1_0
 BV BOUND         z_5_0_1_1
 BV BOUND         z_5_0_1_2
 BV BOUND         z_5_0_1_3
 BV BOUND         z_5_0_1_4
 BV BOUND         z_5_0_1_5
 BV BOUND         z_5_0_1_6
 BV BOUND         z_5_0_1_7
 BV BOUND         z_5_0_1_8
 BV BOUND         z_5_0_1_9
 BV BOUND         z_5_0_1_10
 BV BOUND         z_5_0_2_0
 BV BOUND         z_5_0_2_1
 BV BOUND         z_5_0_2_2
 BV BOUND         z_5_0_2_3
 BV BOUND         z_5_0_2_4
 BV BOUND         z_5_0_2_5
 BV BOUND         z_5_0_2_6
 BV BOUND         z_5_0_2_7
 BV BOUND         z_5_0_2_8
 BV BOUND         z_5_0_2_9
 BV BOUND         z_5_0_2_10
 BV BOUND         z_5_0_3_0
 BV BOUND         z_5_0_3_1
 BV BOUND         z_5_0_3_2
 BV BOUND         z_5_0_3_3
 BV BOUND         z_5_0_3_4
 BV BOUND         z_5_0_3_5
 BV BOUND         z_5_0_3_6
 BV BOUND         z_5_0_3_7
 BV BOUND         z_5_0_4_0
 BV BOUND         z_5_0_4_1
 BV BOUND         z_5_0_4_2
 BV BOUND         z_5_0_4_3
 BV BOUND         z_5_0_4_4
 BV BOUND         z_5_0_4_5
 BV BOUND         z_5_0_4_6
 BV BOUND         z_5_0_4_7
 BV BOUND         z_5_0_4_8
 BV BOUND         z_5_0_4_9
 BV BOUND         z_5_0_4_10
 BV BOUND         z_5_1_0_0
 BV BOUND         z_5_1_0_1
 BV BOUND         z_5_1_0_2
 BV BOUND         z_5_1_0_3
 BV BOUND         z_5_1_0_4
 BV BOUND         z_5_1_0_5
 BV BOUND         z_5_1_0_6
 BV BOUND         z_5_1_0_7
 BV BOUND         z_5_1_0_8
 BV BOUND         z_5_1_0_9
 BV BOUND         z_5_1_0_10
 BV BOUND         z_5_1_1_0
 BV BOUND         z_5_1_1_1
 BV BOUND         z_5_1_1_2
 BV BOUND         z_5_1_1_3
 BV BOUND         z_5_1_1_4
 BV BOUND         z_5_1_1_5
 BV BOUND         z_5_1_1_6
 BV BOUND         z_5_1_1_7
 BV BOUND         z_5_1_1_8
 BV BOUND         z_5_1_1_9
 BV BOUND         z_5_1_1_10
 BV BOUND         z_5_1_2_0
 BV BOUND         z_5_1_2_1
 BV BOUND         z_5_1_2_2
 BV BOUND         z_5_1_2_3
 BV BOUND         z_5_1_2_4
 BV BOUND         z_5_1_2_5
 BV BOUND         z_5_1_2_6
 BV BOUND         z_5_1_2_7
 BV BOUND         z_5_1_2_8
 BV BOUND         z_5_1_2_9
 BV BOUND         z_5_1_2_10
 BV BOUND         z_5_1_3_0
 BV BOUND         z_5_1_3_1
 BV BOUND         z_5_1_3_2
 BV BOUND         z_5_1_3_3
 BV BOUND         z_5_1_3_4
 BV BOUND         z_5_1_3_5
 BV BOUND         z_5_1_4_0
 BV BOUND         z_5_1_4_1
 BV BOUND         z_5_1_4_2
 BV BOUND         z_5_1_4_3
 BV BOUND         z_5_1_4_4
 BV BOUND         z_5_1_4_5
 BV BOUND         z_5_1_4_6
 BV BOUND         z_5_1_4_7
 BV BOUND         z_5_1_4_8
 BV BOUND         z_5_1_4_9
 BV BOUND         z_5_1_4_10
 BV BOUND         z_5_2_0_0
 BV BOUND         z_5_2_0_1
 BV BOUND         z_5_2_0_2
 BV BOUND         z_5_2_0_3
 BV BOUND         z_5_2_0_4
 BV BOUND         z_5_2_0_5
 BV BOUND         z_5_2_0_6
 BV BOUND         z_5_2_0_7
 BV BOUND         z_5_2_0_8
 BV BOUND         z_5_2_1_0
 BV BOUND         z_5_2_1_1
 BV BOUND         z_5_2_1_2
 BV BOUND         z_5_2_1_3
 BV BOUND         z_5_2_1_4
 BV BOUND         z_5_2_1_5
 BV BOUND         z_5_2_1_6
 BV BOUND         z_5_2_1_7
 BV BOUND         z_5_2_1_8
 BV BOUND         z_5_2_1_9
 BV BOUND         z_5_2_1_10
 BV BOUND         z_5_2_2_0
 BV BOUND         z_5_2_2_1
 BV BOUND         z_5_2_2_2
 BV BOUND         z_5_2_2_3
 BV BOUND         z_5_2_2_4
 BV BOUND         z_5_2_2_5
 BV BOUND         z_5_2_2_6
 BV BOUND         z_5_2_2_7
 BV BOUND         z_5_2_2_8
 BV BOUND         z_5_2_3_0
 BV BOUND         z_5_2_3_1
 BV BOUND         z_5_2_3_2
 BV BOUND         z_5_2_3_3
 BV BOUND         z_5_2_3_4
 BV BOUND         z_5_2_3_5
 BV BOUND         z_5_2_3_6
 BV BOUND         z_5_2_3_7
 BV BOUND         z_5_2_3_8
 BV BOUND         z_5_2_3_9
 BV BOUND         z_5_2_3_10
 BV BOUND         z_5_2_4_0
 BV BOUND         z_5_2_4_1
 BV BOUND         z_5_2_4_2
 BV BOUND         z_5_2_4_3
 BV BOUND         z_5_2_4_4
 BV BOUND         z_5_3_0_0
 BV BOUND         z_5_3_0_1
 BV BOUND         z_5_3_0_2
 BV BOUND         z_5_3_0_3
 BV BOUND         z_5_3_0_4
 BV BOUND         z_5_3_0_5
 BV BOUND         z_5_3_0_6
 BV BOUND         z_5_3_0_7
 BV BOUND         z_5_3_2_0
 BV BOUND         z_5_3_2_1
 BV BOUND         z_5_3_2_2
 BV BOUND         z_5_3_2_3
 BV BOUND         z_5_3_2_4
 BV BOUND         z_5_3_2_5
 BV BOUND         z_5_3_2_6
 BV BOUND         z_5_3_2_7
 BV BOUND         z_5_3_2_8
 BV BOUND         z_5_3_2_9
 BV BOUND         z_5_3_2_10
 BV BOUND         z_5_3_3_0
 BV BOUND         z_5_3_3_1
 BV BOUND         z_5_3_3_2
 BV BOUND         z_5_3_3_3
 BV BOUND         z_5_3_3_4
 BV BOUND         z_5_3_3_5
 BV BOUND         z_5_3_3_6
 BV BOUND         z_5_3_3_7
 BV BOUND         z_5_3_3_8
 BV BOUND         z_5_3_4_0
 BV BOUND         z_5_3_4_1
 BV BOUND         z_5_3_4_2
 BV BOUND         z_5_3_4_3
 BV BOUND         z_5_3_4_4
 BV BOUND         z_5_3_4_5
 BV BOUND         z_5_3_4_6
 BV BOUND         z_5_3_4_7
 BV BOUND         z_5_3_4_8
 BV BOUND         z_5_3_4_9
 BV BOUND         z_5_3_4_10
 BV BOUND         z_5_4_0_0
 BV BOUND         z_5_4_0_1
 BV BOUND         z_5_4_0_2
 BV BOUND         z_5_4_0_3
 BV BOUND         z_5_4_0_4
 BV BOUND         z_5_4_0_5
 BV BOUND         z_5_4_0_6
 BV BOUND         z_5_4_0_7
 BV BOUND         z_5_4_1_0
 BV BOUND         z_5_4_1_1
 BV BOUND         z_5_4_1_2
 BV BOUND         z_5_4_1_3
 BV BOUND         z_5_4_1_4
 BV BOUND         z_5_4_1_5
 BV BOUND         z_5_4_1_6
 BV BOUND         z_5_4_1_7
 BV BOUND         z_5_4_1_8
 BV BOUND         z_5_4_1_9
 BV BOUND         z_5_4_1_10
 BV BOUND         z_5_4_2_0
 BV BOUND         z_5_4_2_1
 BV BOUND         z_5_4_2_2
 BV BOUND         z_5_4_2_3
 BV BOUND         z_5_4_2_4
 BV BOUND         z_5_4_2_5
 BV BOUND         z_5_4_2_6
 BV BOUND         z_5_4_2_7
 BV BOUND         z_5_4_2_8
 BV BOUND         z_5_4_2_9
 BV BOUND         z_5_4_2_10
 BV BOUND         z_5_4_3_0
 BV BOUND         z_5_4_3_1
 BV BOUND         z_5_4_3_2
 BV BOUND         z_5_4_3_3
 BV BOUND         z_5_4_3_4
 BV BOUND         z_5_4_3_5
 BV BOUND         z_5_4_3_6
 BV BOUND         z_5_4_3_7
 BV BOUND         z_5_4_3_8
 BV BOUND         z_5_4_3_9
 BV BOUND         z_5_4_3_10
 BV BOUND         z_5_4_4_0
 BV BOUND         z_5_4_4_1
 BV BOUND         z_5_4_4_2
 BV BOUND         z_5_4_4_3
 BV BOUND         z_5_4_4_4
 BV BOUND         z_5_4_4_5
 BV BOUND         z_5_4_4_6
 BV BOUND         z_5_4_4_7
 BV BOUND         z_5_4_4_8
 BV BOUND         z_5_4_4_9
 BV BOUND         z_5_4_4_10
 BV BOUND         z_5_5_0_0
 BV BOUND         z_5_5_0_1
 BV BOUND         z_5_5_0_2
 BV BOUND         z_5_5_0_3
 BV BOUND         z_5_5_0_4
 BV BOUND         z_5_5_0_5
 BV BOUND         z_5_5_0_6
 BV BOUND         z_5_5_0_7
 BV BOUND         z_5_5_0_8
 BV BOUND         z_5_5_0_9
 BV BOUND         z_5_5_0_10
 BV BOUND         z_5_5_1_0
 BV BOUND         z_5_5_1_1
 BV BOUND         z_5_5_1_2
 BV BOUND         z_5_5_1_3
 BV BOUND         z_5_5_1_4
 BV BOUND         z_5_5_1_5
 BV BOUND         z_5_5_1_6
 BV BOUND         z_5_5_1_7
 BV BOUND         z_5_5_2_0
 BV BOUND         z_5_5_2_1
 BV BOUND         z_5_5_2_2
 BV BOUND         z_5_5_2_3
 BV BOUND         z_5_5_2_4
 BV BOUND         z_5_5_2_5
 BV BOUND         z_5_5_2_6
 BV BOUND         z_5_5_2_7
 BV BOUND         z_5_5_3_0
 BV BOUND         z_5_5_3_1
 BV BOUND         z_5_5_3_2
 BV BOUND         z_5_5_3_3
 BV BOUND         z_5_5_3_4
 BV BOUND         z_5_5_3_5
 BV BOUND         z_5_5_3_6
 BV BOUND         z_5_5_3_7
 BV BOUND         z_5_5_3_8
 BV BOUND         z_5_5_3_9
 BV BOUND         z_5_5_3_10
 BV BOUND         w_0_0
 BV BOUND         w_0_1
 BV BOUND         w_0_2
 BV BOUND         w_0_3
 BV BOUND         w_0_4
 BV BOUND         w_1_0
 BV BOUND         w_1_1
 BV BOUND         w_1_2
 BV BOUND         w_1_3
 BV BOUND         w_1_4
 BV BOUND         w_2_0
 BV BOUND         w_2_1
 BV BOUND         w_2_2
 BV BOUND         w_2_3
 BV BOUND         w_2_4
 BV BOUND         w_3_0
 BV BOUND         w_3_1
 BV BOUND         w_3_2
 BV BOUND         w_3_3
 BV BOUND         w_3_4
 BV BOUND         w_4_0
 BV BOUND         w_4_1
 BV BOUND         w_4_2
 BV BOUND         w_4_3
 BV BOUND         w_4_4
 BV BOUND         w_5_0
 BV BOUND         w_5_1
 BV BOUND         w_5_2
 BV BOUND         w_5_3
 BV BOUND         w_5_4
 BV BOUND         w_6_0
 BV BOUND         w_6_1
 BV BOUND         w_6_2
 BV BOUND         w_6_3
 BV BOUND         w_6_4
 BV BOUND         w_7_0
 BV BOUND         w_7_1
 BV BOUND         w_7_2
 BV BOUND         w_7_3
 BV BOUND         w_7_4
 UP BOUND         o_0_0_0          1.0
 UP BOUND         o_0_0_1          1.0
 UP BOUND         o_0_0_2          1.0
 UP BOUND         o_0_0_3          1.0
 UP BOUND         o_0_0_4          1.0
 UP BOUND         o_0_0_5          1.0
 UP BOUND         o_0_1_0          1.0
 UP BOUND         o_0_1_1          1.0
 UP BOUND         o_0_1_2          1.0
 UP BOUND         o_0_1_3          1.0
 UP BOUND         o_0_1_4          1.0
 UP BOUND         o_0_1_5          1.0
 UP BOUND         o_0_2_0          1.0
 UP BOUND         o_0_2_1          1.0
 UP BOUND         o_0_2_2          1.0
 UP BOUND         o_0_2_3          1.0
 UP BOUND         o_0_2_4          1.0
 UP BOUND         o_0_2_5          1.0
 UP BOUND         o_0_3_0          1.0
 UP BOUND         o_0_3_1          1.0
 UP BOUND         o_0_3_2          1.0
 UP BOUND         o_0_3_3          1.0
 UP BOUND         o_0_3_4          1.0
 UP BOUND         o_0_3_5          1.0
 UP BOUND         o_0_4_0          1.0
 UP BOUND         o_0_4_1          1.0
 UP BOUND         o_0_4_2          1.0
 UP BOUND         o_0_4_3          1.0
 UP BOUND         o_0_4_4          1.0
 UP BOUND         o_0_4_5          1.0
 UP BOUND         o_1_0_0          1.0
 UP BOUND         o_1_0_1          1.0
 UP BOUND         o_1_0_2          1.0
 UP BOUND         o_1_0_3          1.0
 UP BOUND         o_1_0_4          1.0
 UP BOUND         o_1_0_5          1.0
 UP BOUND         o_1_1_0          1.0
 UP BOUND         o_1_1_1          1.0
 UP BOUND         o_1_1_2          1.0
 UP BOUND         o_1_1_3          1.0
 UP BOUND         o_1_1_4          1.0
 UP BOUND         o_1_1_5          1.0
 UP BOUND         o_1_2_0          1.0
 UP BOUND         o_1_2_1          1.0
 UP BOUND         o_1_2_2          1.0
 UP BOUND         o_1_2_3          1.0
 UP BOUND         o_1_2_4          1.0
 UP BOUND         o_1_2_5          1.0
 UP BOUND         o_1_3_0          1.0
 UP BOUND         o_1_3_1          1.0
 UP BOUND         o_1_3_2          1.0
 UP BOUND         o_1_3_3          1.0
 UP BOUND         o_1_3_4          1.0
 UP BOUND         o_1_3_5          1.0
 UP BOUND         o_1_4_0          1.0
 UP BOUND         o_1_4_1          1.0
 UP BOUND         o_1_4_2          1.0
 UP BOUND         o_1_4_3          1.0
 UP BOUND         o_1_4_4          1.0
 UP BOUND         o_1_4_5          1.0
 UP BOUND         o_2_0_0          1.0
 UP BOUND         o_2_0_1          1.0
 UP BOUND         o_2_0_2          1.0
 UP BOUND         o_2_0_3          1.0
 UP BOUND         o_2_0_4          1.0
 UP BOUND         o_2_0_5          1.0
 UP BOUND         o_2_1_0          1.0
 UP BOUND         o_2_1_1          1.0
 UP BOUND         o_2_1_2          1.0
 UP BOUND         o_2_1_3          1.0
 UP BOUND         o_2_1_4          1.0
 UP BOUND         o_2_1_5          1.0
 UP BOUND         o_2_2_0          1.0
 UP BOUND         o_2_2_1          1.0
 UP BOUND         o_2_2_2          1.0
 UP BOUND         o_2_2_3          1.0
 UP BOUND         o_2_2_4          1.0
 UP BOUND         o_2_2_5          1.0
 UP BOUND         o_2_3_0          1.0
 UP BOUND         o_2_3_1          1.0
 UP BOUND         o_2_3_2          1.0
 UP BOUND         o_2_3_3          1.0
 UP BOUND         o_2_3_4          1.0
 UP BOUND         o_2_3_5          1.0
 UP BOUND         o_2_4_0          1.0
 UP BOUND         o_2_4_1          1.0
 UP BOUND         o_2_4_2          1.0
 UP BOUND         o_2_4_3          1.0
 UP BOUND         o_2_4_4          1.0
 UP BOUND         o_2_4_5          1.0
 UP BOUND         o_3_0_0          1.0
 UP BOUND         o_3_0_1          1.0
 UP BOUND         o_3_0_2          1.0
 UP BOUND         o_3_0_3          1.0
 UP BOUND         o_3_0_4          1.0
 UP BOUND         o_3_0_5          1.0
 UP BOUND         o_3_1_0          1.0
 UP BOUND         o_3_1_1          1.0
 UP BOUND         o_3_1_2          1.0
 UP BOUND         o_3_1_3          1.0
 UP BOUND         o_3_1_4          1.0
 UP BOUND         o_3_1_5          1.0
 UP BOUND         o_3_2_0          1.0
 UP BOUND         o_3_2_1          1.0
 UP BOUND         o_3_2_2          1.0
 UP BOUND         o_3_2_3          1.0
 UP BOUND         o_3_2_4          1.0
 UP BOUND         o_3_2_5          1.0
 UP BOUND         o_3_3_0          1.0
 UP BOUND         o_3_3_1          1.0
 UP BOUND         o_3_3_2          1.0
 UP BOUND         o_3_3_3          1.0
 UP BOUND         o_3_3_4          1.0
 UP BOUND         o_3_3_5          1.0
 UP BOUND         o_3_4_0          1.0
 UP BOUND         o_3_4_1          1.0
 UP BOUND         o_3_4_2          1.0
 UP BOUND         o_3_4_3          1.0
 UP BOUND         o_3_4_4          1.0
 UP BOUND         o_3_4_5          1.0
 UP BOUND         o_4_0_0          1.0
 UP BOUND         o_4_0_1          1.0
 UP BOUND         o_4_0_2          1.0
 UP BOUND         o_4_0_3          1.0
 UP BOUND         o_4_0_4          1.0
 UP BOUND         o_4_0_5          1.0
 UP BOUND         o_4_1_0          1.0
 UP BOUND         o_4_1_1          1.0
 UP BOUND         o_4_1_2          1.0
 UP BOUND         o_4_1_3          1.0
 UP BOUND         o_4_1_4          1.0
 UP BOUND         o_4_1_5          1.0
 UP BOUND         o_4_2_0          1.0
 UP BOUND         o_4_2_1          1.0
 UP BOUND         o_4_2_2          1.0
 UP BOUND         o_4_2_3          1.0
 UP BOUND         o_4_2_4          1.0
 UP BOUND         o_4_2_5          1.0
 UP BOUND         o_4_3_0          1.0
 UP BOUND         o_4_3_1          1.0
 UP BOUND         o_4_3_2          1.0
 UP BOUND         o_4_3_3          1.0
 UP BOUND         o_4_3_4          1.0
 UP BOUND         o_4_3_5          1.0
 UP BOUND         o_4_4_0          1.0
 UP BOUND         o_4_4_1          1.0
 UP BOUND         o_4_4_2          1.0
 UP BOUND         o_4_4_3          1.0
 UP BOUND         o_4_4_4          1.0
 UP BOUND         o_4_4_5          1.0
 UP BOUND         o_5_0_0          1.0
 UP BOUND         o_5_0_1          1.0
 UP BOUND         o_5_0_2          1.0
 UP BOUND         o_5_0_3          1.0
 UP BOUND         o_5_0_4          1.0
 UP BOUND         o_5_0_5          1.0
 UP BOUND         o_5_1_0          1.0
 UP BOUND         o_5_1_1          1.0
 UP BOUND         o_5_1_2          1.0
 UP BOUND         o_5_1_3          1.0
 UP BOUND         o_5_1_4          1.0
 UP BOUND         o_5_1_5          1.0
 UP BOUND         o_5_2_0          1.0
 UP BOUND         o_5_2_1          1.0
 UP BOUND         o_5_2_2          1.0
 UP BOUND         o_5_2_3          1.0
 UP BOUND         o_5_2_4          1.0
 UP BOUND         o_5_2_5          1.0
 UP BOUND         o_5_3_0          1.0
 UP BOUND         o_5_3_1          1.0
 UP BOUND         o_5_3_2          1.0
 UP BOUND         o_5_3_3          1.0
 UP BOUND         o_5_3_4          1.0
 UP BOUND         o_5_3_5          1.0
 UP BOUND         o_5_4_0          1.0
 UP BOUND         o_5_4_1          1.0
 UP BOUND         o_5_4_2          1.0
 UP BOUND         o_5_4_3          1.0
 UP BOUND         o_5_4_4          1.0
 UP BOUND         o_5_4_5          1.0
 UP BOUND         o_6_0_0          1.0
 UP BOUND         o_6_0_1          1.0
 UP BOUND         o_6_0_2          1.0
 UP BOUND         o_6_0_3          1.0
 UP BOUND         o_6_0_4          1.0
 UP BOUND         o_6_0_5          1.0
 UP BOUND         o_6_1_0          1.0
 UP BOUND         o_6_1_1          1.0
 UP BOUND         o_6_1_2          1.0
 UP BOUND         o_6_1_3          1.0
 UP BOUND         o_6_1_4          1.0
 UP BOUND         o_6_1_5          1.0
 UP BOUND         o_6_2_0          1.0
 UP BOUND         o_6_2_1          1.0
 UP BOUND         o_6_2_2          1.0
 UP BOUND         o_6_2_3          1.0
 UP BOUND         o_6_2_4          1.0
 UP BOUND         o_6_2_5          1.0
 UP BOUND         o_6_3_0          1.0
 UP BOUND         o_6_3_1          1.0
 UP BOUND         o_6_3_2          1.0
 UP BOUND         o_6_3_3          1.0
 UP BOUND         o_6_3_4          1.0
 UP BOUND         o_6_3_5          1.0
 UP BOUND         o_6_4_0          1.0
 UP BOUND         o_6_4_1          1.0
 UP BOUND         o_6_4_2          1.0
 UP BOUND         o_6_4_3          1.0
 UP BOUND         o_6_4_4          1.0
 UP BOUND         o_6_4_5          1.0
 UP BOUND         o_7_0_0          1.0
 UP BOUND         o_7_0_1          1.0
 UP BOUND         o_7_0_2          1.0
 UP BOUND         o_7_0_3          1.0
 UP BOUND         o_7_0_4          1.0
 UP BOUND         o_7_0_5          1.0
 UP BOUND         o_7_1_0          1.0
 UP BOUND         o_7_1_1          1.0
 UP BOUND         o_7_1_2          1.0
 UP BOUND         o_7_1_3          1.0
 UP BOUND         o_7_1_4          1.0
 UP BOUND         o_7_1_5          1.0
 UP BOUND         o_7_2_0          1.0
 UP BOUND         o_7_2_1          1.0
 UP BOUND         o_7_2_2          1.0
 UP BOUND         o_7_2_3          1.0
 UP BOUND         o_7_2_4          1.0
 UP BOUND         o_7_2_5          1.0
 UP BOUND         o_7_3_0          1.0
 UP BOUND         o_7_3_1          1.0
 UP BOUND         o_7_3_2          1.0
 UP BOUND         o_7_3_3          1.0
 UP BOUND         o_7_3_4          1.0
 UP BOUND         o_7_3_5          1.0
 UP BOUND         o_7_4_0          1.0
 UP BOUND         o_7_4_1          1.0
 UP BOUND         o_7_4_2          1.0
 UP BOUND         o_7_4_3          1.0
 UP BOUND         o_7_4_4          1.0
 UP BOUND         o_7_4_5          1.0
 UP BOUND         e_0_0_0          1.0
 UP BOUND         e_0_0_1          1.0
 UP BOUND         e_0_0_2          1.0
 UP BOUND         e_0_0_3          1.0
 UP BOUND         e_0_0_4          1.0
 UP BOUND         e_0_0_5          1.0
 UP BOUND         e_0_1_0          1.0
 UP BOUND         e_0_1_1          1.0
 UP BOUND         e_0_1_2          1.0
 UP BOUND         e_0_1_3          1.0
 UP BOUND         e_0_1_4          1.0
 UP BOUND         e_0_1_5          1.0
 UP BOUND         e_0_2_0          1.0
 UP BOUND         e_0_2_1          1.0
 UP BOUND         e_0_2_2          1.0
 UP BOUND         e_0_2_3          1.0
 UP BOUND         e_0_2_4          1.0
 UP BOUND         e_0_2_5          1.0
 UP BOUND         e_0_3_0          1.0
 UP BOUND         e_0_3_1          1.0
 UP BOUND         e_0_3_2          1.0
 UP BOUND         e_0_3_3          1.0
 UP BOUND         e_0_3_4          1.0
 UP BOUND         e_0_3_5          1.0
 UP BOUND         e_0_4_0          1.0
 UP BOUND         e_0_4_1          1.0
 UP BOUND         e_0_4_2          1.0
 UP BOUND         e_0_4_3          1.0
 UP BOUND         e_0_4_4          1.0
 UP BOUND         e_0_4_5          1.0
 UP BOUND         e_1_0_0          1.0
 UP BOUND         e_1_0_1          1.0
 UP BOUND         e_1_0_2          1.0
 UP BOUND         e_1_0_3          1.0
 UP BOUND         e_1_0_4          1.0
 UP BOUND         e_1_0_5          1.0
 UP BOUND         e_1_1_0          1.0
 UP BOUND         e_1_1_1          1.0
 UP BOUND         e_1_1_2          1.0
 UP BOUND         e_1_1_3          1.0
 UP BOUND         e_1_1_4          1.0
 UP BOUND         e_1_1_5          1.0
 UP BOUND         e_1_2_0          1.0
 UP BOUND         e_1_2_1          1.0
 UP BOUND         e_1_2_2          1.0
 UP BOUND         e_1_2_3          1.0
 UP BOUND         e_1_2_4          1.0
 UP BOUND         e_1_2_5          1.0
 UP BOUND         e_1_3_0          1.0
 UP BOUND         e_1_3_1          1.0
 UP BOUND         e_1_3_2          1.0
 UP BOUND         e_1_3_3          1.0
 UP BOUND         e_1_3_4          1.0
 UP BOUND         e_1_3_5          1.0
 UP BOUND         e_1_4_0          1.0
 UP BOUND         e_1_4_1          1.0
 UP BOUND         e_1_4_2          1.0
 UP BOUND         e_1_4_3          1.0
 UP BOUND         e_1_4_4          1.0
 UP BOUND         e_1_4_5          1.0
 UP BOUND         e_2_0_0          1.0
 UP BOUND         e_2_0_1          1.0
 UP BOUND         e_2_0_2          1.0
 UP BOUND         e_2_0_3          1.0
 UP BOUND         e_2_0_4          1.0
 UP BOUND         e_2_0_5          1.0
 UP BOUND         e_2_1_0          1.0
 UP BOUND         e_2_1_1          1.0
 UP BOUND         e_2_1_2          1.0
 UP BOUND         e_2_1_3          1.0
 UP BOUND         e_2_1_4          1.0
 UP BOUND         e_2_1_5          1.0
 UP BOUND         e_2_2_0          1.0
 UP BOUND         e_2_2_1          1.0
 UP BOUND         e_2_2_2          1.0
 UP BOUND         e_2_2_3          1.0
 UP BOUND         e_2_2_4          1.0
 UP BOUND         e_2_2_5          1.0
 UP BOUND         e_2_3_0          1.0
 UP BOUND         e_2_3_1          1.0
 UP BOUND         e_2_3_2          1.0
 UP BOUND         e_2_3_3          1.0
 UP BOUND         e_2_3_4          1.0
 UP BOUND         e_2_3_5          1.0
 UP BOUND         e_2_4_0          1.0
 UP BOUND         e_2_4_1          1.0
 UP BOUND         e_2_4_2          1.0
 UP BOUND         e_2_4_3          1.0
 UP BOUND         e_2_4_4          1.0
 UP BOUND         e_2_4_5          1.0
 UP BOUND         e_3_0_0          1.0
 UP BOUND         e_3_0_1          1.0
 UP BOUND         e_3_0_2          1.0
 UP BOUND         e_3_0_3          1.0
 UP BOUND         e_3_0_4          1.0
 UP BOUND         e_3_0_5          1.0
 UP BOUND         e_3_1_0          1.0
 UP BOUND         e_3_1_1          1.0
 UP BOUND         e_3_1_2          1.0
 UP BOUND         e_3_1_3          1.0
 UP BOUND         e_3_1_4          1.0
 UP BOUND         e_3_1_5          1.0
 UP BOUND         e_3_2_0          1.0
 UP BOUND         e_3_2_1          1.0
 UP BOUND         e_3_2_2          1.0
 UP BOUND         e_3_2_3          1.0
 UP BOUND         e_3_2_4          1.0
 UP BOUND         e_3_2_5          1.0
 UP BOUND         e_3_3_0          1.0
 UP BOUND         e_3_3_1          1.0
 UP BOUND         e_3_3_2          1.0
 UP BOUND         e_3_3_3          1.0
 UP BOUND         e_3_3_4          1.0
 UP BOUND         e_3_3_5          1.0
 UP BOUND         e_3_4_0          1.0
 UP BOUND         e_3_4_1          1.0
 UP BOUND         e_3_4_2          1.0
 UP BOUND         e_3_4_3          1.0
 UP BOUND         e_3_4_4          1.0
 UP BOUND         e_3_4_5          1.0
 UP BOUND         e_4_0_0          1.0
 UP BOUND         e_4_0_1          1.0
 UP BOUND         e_4_0_2          1.0
 UP BOUND         e_4_0_3          1.0
 UP BOUND         e_4_0_4          1.0
 UP BOUND         e_4_0_5          1.0
 UP BOUND         e_4_1_0          1.0
 UP BOUND         e_4_1_1          1.0
 UP BOUND         e_4_1_2          1.0
 UP BOUND         e_4_1_3          1.0
 UP BOUND         e_4_1_4          1.0
 UP BOUND         e_4_1_5          1.0
 UP BOUND         e_4_2_0          1.0
 UP BOUND         e_4_2_1          1.0
 UP BOUND         e_4_2_2          1.0
 UP BOUND         e_4_2_3          1.0
 UP BOUND         e_4_2_4          1.0
 UP BOUND         e_4_2_5          1.0
 UP BOUND         e_4_3_0          1.0
 UP BOUND         e_4_3_1          1.0
 UP BOUND         e_4_3_2          1.0
 UP BOUND         e_4_3_3          1.0
 UP BOUND         e_4_3_4          1.0
 UP BOUND         e_4_3_5          1.0
 UP BOUND         e_4_4_0          1.0
 UP BOUND         e_4_4_1          1.0
 UP BOUND         e_4_4_2          1.0
 UP BOUND         e_4_4_3          1.0
 UP BOUND         e_4_4_4          1.0
 UP BOUND         e_4_4_5          1.0
 UP BOUND         e_5_0_0          1.0
 UP BOUND         e_5_0_1          1.0
 UP BOUND         e_5_0_2          1.0
 UP BOUND         e_5_0_3          1.0
 UP BOUND         e_5_0_4          1.0
 UP BOUND         e_5_0_5          1.0
 UP BOUND         e_5_1_0          1.0
 UP BOUND         e_5_1_1          1.0
 UP BOUND         e_5_1_2          1.0
 UP BOUND         e_5_1_3          1.0
 UP BOUND         e_5_1_4          1.0
 UP BOUND         e_5_1_5          1.0
 UP BOUND         e_5_2_0          1.0
 UP BOUND         e_5_2_1          1.0
 UP BOUND         e_5_2_2          1.0
 UP BOUND         e_5_2_3          1.0
 UP BOUND         e_5_2_4          1.0
 UP BOUND         e_5_2_5          1.0
 UP BOUND         e_5_3_0          1.0
 UP BOUND         e_5_3_1          1.0
 UP BOUND         e_5_3_2          1.0
 UP BOUND         e_5_3_3          1.0
 UP BOUND         e_5_3_4          1.0
 UP BOUND         e_5_3_5          1.0
 UP BOUND         e_5_4_0          1.0
 UP BOUND         e_5_4_1          1.0
 UP BOUND         e_5_4_2          1.0
 UP BOUND         e_5_4_3          1.0
 UP BOUND         e_5_4_4          1.0
 UP BOUND         e_5_4_5          1.0
 FX BOUND         bf_0_0_0          0.0
 UP BOUND         af_0_0_0          1.0
 UP BOUND         bf_0_0_1          1.0
 UP BOUND         af_0_0_1          1.0
 UP BOUND         bf_0_0_2          1.0
 UP BOUND         af_0_0_2          1.0
 UP BOUND         bf_0_0_3          1.0
 UP BOUND         af_0_0_3          1.0
 UP BOUND         bf_0_0_4          1.0
 UP BOUND         af_0_0_4          1.0
 UP BOUND         bf_0_0_5          1.0
 FX BOUND         af_0_0_5          0.0
 FX BOUND         bf_0_1_0          0.0
 UP BOUND         af_0_1_0          1.0
 UP BOUND         bf_0_1_1          1.0
 UP BOUND         af_0_1_1          1.0
 UP BOUND         bf_0_1_2          1.0
 UP BOUND         af_0_1_2          1.0
 UP BOUND         bf_0_1_3          1.0
 UP BOUND         af_0_1_3          1.0
 UP BOUND         bf_0_1_4          1.0
 UP BOUND         af_0_1_4          1.0
 UP BOUND         bf_0_1_5          1.0
 FX BOUND         af_0_1_5          0.0
 FX BOUND         bf_0_2_0          0.0
 UP BOUND         af_0_2_0          1.0
 UP BOUND         bf_0_2_1          1.0
 UP BOUND         af_0_2_1          1.0
 UP BOUND         bf_0_2_2          1.0
 UP BOUND         af_0_2_2          1.0
 UP BOUND         bf_0_2_3          1.0
 UP BOUND         af_0_2_3          1.0
 UP BOUND         bf_0_2_4          1.0
 UP BOUND         af_0_2_4          1.0
 UP BOUND         bf_0_2_5          1.0
 FX BOUND         af_0_2_5          0.0
 FX BOUND         bf_0_3_0          0.0
 UP BOUND         af_0_3_0          1.0
 UP BOUND         bf_0_3_1          1.0
 UP BOUND         af_0_3_1          1.0
 UP BOUND         bf_0_3_2          1.0
 UP BOUND         af_0_3_2          1.0
 UP BOUND         bf_0_3_3          1.0
 UP BOUND         af_0_3_3          1.0
 UP BOUND         bf_0_3_4          1.0
 UP BOUND         af_0_3_4          1.0
 UP BOUND         bf_0_3_5          1.0
 FX BOUND         af_0_3_5          0.0
 FX BOUND         bf_0_4_0          0.0
 UP BOUND         af_0_4_0          1.0
 UP BOUND         bf_0_4_1          1.0
 UP BOUND         af_0_4_1          1.0
 UP BOUND         bf_0_4_2          1.0
 UP BOUND         af_0_4_2          1.0
 UP BOUND         bf_0_4_3          1.0
 UP BOUND         af_0_4_3          1.0
 UP BOUND         bf_0_4_4          1.0
 UP BOUND         af_0_4_4          1.0
 UP BOUND         bf_0_4_5          1.0
 FX BOUND         af_0_4_5          0.0
 FX BOUND         bf_1_0_0          0.0
 UP BOUND         af_1_0_0          1.0
 UP BOUND         bf_1_0_1          1.0
 UP BOUND         af_1_0_1          1.0
 UP BOUND         bf_1_0_2          1.0
 UP BOUND         af_1_0_2          1.0
 UP BOUND         bf_1_0_3          1.0
 UP BOUND         af_1_0_3          1.0
 UP BOUND         bf_1_0_4          1.0
 UP BOUND         af_1_0_4          1.0
 UP BOUND         bf_1_0_5          1.0
 FX BOUND         af_1_0_5          0.0
 FX BOUND         bf_1_1_0          0.0
 UP BOUND         af_1_1_0          1.0
 UP BOUND         bf_1_1_1          1.0
 UP BOUND         af_1_1_1          1.0
 UP BOUND         bf_1_1_2          1.0
 UP BOUND         af_1_1_2          1.0
 UP BOUND         bf_1_1_3          1.0
 UP BOUND         af_1_1_3          1.0
 UP BOUND         bf_1_1_4          1.0
 UP BOUND         af_1_1_4          1.0
 UP BOUND         bf_1_1_5          1.0
 FX BOUND         af_1_1_5          0.0
 FX BOUND         bf_1_2_0          0.0
 UP BOUND         af_1_2_0          1.0
 UP BOUND         bf_1_2_1          1.0
 UP BOUND         af_1_2_1          1.0
 UP BOUND         bf_1_2_2          1.0
 UP BOUND         af_1_2_2          1.0
 UP BOUND         bf_1_2_3          1.0
 UP BOUND         af_1_2_3          1.0
 UP BOUND         bf_1_2_4          1.0
 UP BOUND         af_1_2_4          1.0
 UP BOUND         bf_1_2_5          1.0
 FX BOUND         af_1_2_5          0.0
 FX BOUND         bf_1_3_0          0.0
 UP BOUND         af_1_3_0          1.0
 UP BOUND         bf_1_3_1          1.0
 UP BOUND         af_1_3_1          1.0
 UP BOUND         bf_1_3_2          1.0
 UP BOUND         af_1_3_2          1.0
 UP BOUND         bf_1_3_3          1.0
 UP BOUND         af_1_3_3          1.0
 UP BOUND         bf_1_3_4          1.0
 UP BOUND         af_1_3_4          1.0
 UP BOUND         bf_1_3_5          1.0
 FX BOUND         af_1_3_5          0.0
 FX BOUND         bf_1_4_0          0.0
 UP BOUND         af_1_4_0          1.0
 UP BOUND         bf_1_4_1          1.0
 UP BOUND         af_1_4_1          1.0
 UP BOUND         bf_1_4_2          1.0
 UP BOUND         af_1_4_2          1.0
 UP BOUND         bf_1_4_3          1.0
 UP BOUND         af_1_4_3          1.0
 UP BOUND         bf_1_4_4          1.0
 UP BOUND         af_1_4_4          1.0
 UP BOUND         bf_1_4_5          1.0
 FX BOUND         af_1_4_5          0.0
 FX BOUND         bf_2_0_0          0.0
 UP BOUND         af_2_0_0          1.0
 UP BOUND         bf_2_0_1          1.0
 UP BOUND         af_2_0_1          1.0
 UP BOUND         bf_2_0_2          1.0
 UP BOUND         af_2_0_2          1.0
 UP BOUND         bf_2_0_3          1.0
 UP BOUND         af_2_0_3          1.0
 UP BOUND         bf_2_0_4          1.0
 UP BOUND         af_2_0_4          1.0
 UP BOUND         bf_2_0_5          1.0
 FX BOUND         af_2_0_5          0.0
 FX BOUND         bf_2_1_0          0.0
 UP BOUND         af_2_1_0          1.0
 UP BOUND         bf_2_1_1          1.0
 UP BOUND         af_2_1_1          1.0
 UP BOUND         bf_2_1_2          1.0
 UP BOUND         af_2_1_2          1.0
 UP BOUND         bf_2_1_3          1.0
 UP BOUND         af_2_1_3          1.0
 UP BOUND         bf_2_1_4          1.0
 UP BOUND         af_2_1_4          1.0
 UP BOUND         bf_2_1_5          1.0
 FX BOUND         af_2_1_5          0.0
 FX BOUND         bf_2_2_0          0.0
 UP BOUND         af_2_2_0          1.0
 UP BOUND         bf_2_2_1          1.0
 UP BOUND         af_2_2_1          1.0
 UP BOUND         bf_2_2_2          1.0
 UP BOUND         af_2_2_2          1.0
 UP BOUND         bf_2_2_3          1.0
 UP BOUND         af_2_2_3          1.0
 UP BOUND         bf_2_2_4          1.0
 UP BOUND         af_2_2_4          1.0
 UP BOUND         bf_2_2_5          1.0
 FX BOUND         af_2_2_5          0.0
 FX BOUND         bf_2_3_0          0.0
 UP BOUND         af_2_3_0          1.0
 UP BOUND         bf_2_3_1          1.0
 UP BOUND         af_2_3_1          1.0
 UP BOUND         bf_2_3_2          1.0
 UP BOUND         af_2_3_2          1.0
 UP BOUND         bf_2_3_3          1.0
 UP BOUND         af_2_3_3          1.0
 UP BOUND         bf_2_3_4          1.0
 UP BOUND         af_2_3_4          1.0
 UP BOUND         bf_2_3_5          1.0
 FX BOUND         af_2_3_5          0.0
 FX BOUND         bf_2_4_0          0.0
 UP BOUND         af_2_4_0          1.0
 UP BOUND         bf_2_4_1          1.0
 UP BOUND         af_2_4_1          1.0
 UP BOUND         bf_2_4_2          1.0
 UP BOUND         af_2_4_2          1.0
 UP BOUND         bf_2_4_3          1.0
 UP BOUND         af_2_4_3          1.0
 UP BOUND         bf_2_4_4          1.0
 UP BOUND         af_2_4_4          1.0
 UP BOUND         bf_2_4_5          1.0
 FX BOUND         af_2_4_5          0.0
 FX BOUND         bf_3_0_0          0.0
 UP BOUND         af_3_0_0          1.0
 UP BOUND         bf_3_0_1          1.0
 UP BOUND         af_3_0_1          1.0
 UP BOUND         bf_3_0_2          1.0
 UP BOUND         af_3_0_2          1.0
 UP BOUND         bf_3_0_3          1.0
 UP BOUND         af_3_0_3          1.0
 UP BOUND         bf_3_0_4          1.0
 UP BOUND         af_3_0_4          1.0
 UP BOUND         bf_3_0_5          1.0
 FX BOUND         af_3_0_5          0.0
 FX BOUND         bf_3_1_0          0.0
 UP BOUND         af_3_1_0          1.0
 UP BOUND         bf_3_1_1          1.0
 UP BOUND         af_3_1_1          1.0
 UP BOUND         bf_3_1_2          1.0
 UP BOUND         af_3_1_2          1.0
 UP BOUND         bf_3_1_3          1.0
 UP BOUND         af_3_1_3          1.0
 UP BOUND         bf_3_1_4          1.0
 UP BOUND         af_3_1_4          1.0
 UP BOUND         bf_3_1_5          1.0
 FX BOUND         af_3_1_5          0.0
 FX BOUND         bf_3_2_0          0.0
 UP BOUND         af_3_2_0          1.0
 UP BOUND         bf_3_2_1          1.0
 UP BOUND         af_3_2_1          1.0
 UP BOUND         bf_3_2_2          1.0
 UP BOUND         af_3_2_2          1.0
 UP BOUND         bf_3_2_3          1.0
 UP BOUND         af_3_2_3          1.0
 UP BOUND         bf_3_2_4          1.0
 UP BOUND         af_3_2_4          1.0
 UP BOUND         bf_3_2_5          1.0
 FX BOUND         af_3_2_5          0.0
 FX BOUND         bf_3_3_0          0.0
 UP BOUND         af_3_3_0          1.0
 UP BOUND         bf_3_3_1          1.0
 UP BOUND         af_3_3_1          1.0
 UP BOUND         bf_3_3_2          1.0
 UP BOUND         af_3_3_2          1.0
 UP BOUND         bf_3_3_3          1.0
 UP BOUND         af_3_3_3          1.0
 UP BOUND         bf_3_3_4          1.0
 UP BOUND         af_3_3_4          1.0
 UP BOUND         bf_3_3_5          1.0
 FX BOUND         af_3_3_5          0.0
 FX BOUND         bf_3_4_0          0.0
 UP BOUND         af_3_4_0          1.0
 UP BOUND         bf_3_4_1          1.0
 UP BOUND         af_3_4_1          1.0
 UP BOUND         bf_3_4_2          1.0
 UP BOUND         af_3_4_2          1.0
 UP BOUND         bf_3_4_3          1.0
 UP BOUND         af_3_4_3          1.0
 UP BOUND         bf_3_4_4          1.0
 UP BOUND         af_3_4_4          1.0
 UP BOUND         bf_3_4_5          1.0
 FX BOUND         af_3_4_5          0.0
 FX BOUND         bf_4_0_0          0.0
 UP BOUND         af_4_0_0          1.0
 UP BOUND         bf_4_0_1          1.0
 UP BOUND         af_4_0_1          1.0
 UP BOUND         bf_4_0_2          1.0
 UP BOUND         af_4_0_2          1.0
 UP BOUND         bf_4_0_3          1.0
 UP BOUND         af_4_0_3          1.0
 UP BOUND         bf_4_0_4          1.0
 UP BOUND         af_4_0_4          1.0
 UP BOUND         bf_4_0_5          1.0
 FX BOUND         af_4_0_5          0.0
 FX BOUND         bf_4_1_0          0.0
 UP BOUND         af_4_1_0          1.0
 UP BOUND         bf_4_1_1          1.0
 UP BOUND         af_4_1_1          1.0
 UP BOUND         bf_4_1_2          1.0
 UP BOUND         af_4_1_2          1.0
 UP BOUND         bf_4_1_3          1.0
 UP BOUND         af_4_1_3          1.0
 UP BOUND         bf_4_1_4          1.0
 UP BOUND         af_4_1_4          1.0
 UP BOUND         bf_4_1_5          1.0
 FX BOUND         af_4_1_5          0.0
 FX BOUND         bf_4_2_0          0.0
 UP BOUND         af_4_2_0          1.0
 UP BOUND         bf_4_2_1          1.0
 UP BOUND         af_4_2_1          1.0
 UP BOUND         bf_4_2_2          1.0
 UP BOUND         af_4_2_2          1.0
 UP BOUND         bf_4_2_3          1.0
 UP BOUND         af_4_2_3          1.0
 UP BOUND         bf_4_2_4          1.0
 UP BOUND         af_4_2_4          1.0
 UP BOUND         bf_4_2_5          1.0
 FX BOUND         af_4_2_5          0.0
 FX BOUND         bf_4_3_0          0.0
 UP BOUND         af_4_3_0          1.0
 UP BOUND         bf_4_3_1          1.0
 UP BOUND         af_4_3_1          1.0
 UP BOUND         bf_4_3_2          1.0
 UP BOUND         af_4_3_2          1.0
 UP BOUND         bf_4_3_3          1.0
 UP BOUND         af_4_3_3          1.0
 UP BOUND         bf_4_3_4          1.0
 UP BOUND         af_4_3_4          1.0
 UP BOUND         bf_4_3_5          1.0
 FX BOUND         af_4_3_5          0.0
 FX BOUND         bf_4_4_0          0.0
 UP BOUND         af_4_4_0          1.0
 UP BOUND         bf_4_4_1          1.0
 UP BOUND         af_4_4_1          1.0
 UP BOUND         bf_4_4_2          1.0
 UP BOUND         af_4_4_2          1.0
 UP BOUND         bf_4_4_3          1.0
 UP BOUND         af_4_4_3          1.0
 UP BOUND         bf_4_4_4          1.0
 UP BOUND         af_4_4_4          1.0
 UP BOUND         bf_4_4_5          1.0
 FX BOUND         af_4_4_5          0.0
 FX BOUND         bf_5_0_0          0.0
 UP BOUND         af_5_0_0          1.0
 UP BOUND         bf_5_0_1          1.0
 UP BOUND         af_5_0_1          1.0
 UP BOUND         bf_5_0_2          1.0
 UP BOUND         af_5_0_2          1.0
 UP BOUND         bf_5_0_3          1.0
 UP BOUND         af_5_0_3          1.0
 UP BOUND         bf_5_0_4          1.0
 UP BOUND         af_5_0_4          1.0
 UP BOUND         bf_5_0_5          1.0
 FX BOUND         af_5_0_5          0.0
 FX BOUND         bf_5_1_0          0.0
 UP BOUND         af_5_1_0          1.0
 UP BOUND         bf_5_1_1          1.0
 UP BOUND         af_5_1_1          1.0
 UP BOUND         bf_5_1_2          1.0
 UP BOUND         af_5_1_2          1.0
 UP BOUND         bf_5_1_3          1.0
 UP BOUND         af_5_1_3          1.0
 UP BOUND         bf_5_1_4          1.0
 UP BOUND         af_5_1_4          1.0
 UP BOUND         bf_5_1_5          1.0
 FX BOUND         af_5_1_5          0.0
 FX BOUND         bf_5_2_0          0.0
 UP BOUND         af_5_2_0          1.0
 UP BOUND         bf_5_2_1          1.0
 UP BOUND         af_5_2_1          1.0
 UP BOUND         bf_5_2_2          1.0
 UP BOUND         af_5_2_2          1.0
 UP BOUND         bf_5_2_3          1.0
 UP BOUND         af_5_2_3          1.0
 UP BOUND         bf_5_2_4          1.0
 UP BOUND         af_5_2_4          1.0
 UP BOUND         bf_5_2_5          1.0
 FX BOUND         af_5_2_5          0.0
 FX BOUND         bf_5_3_0          0.0
 UP BOUND         af_5_3_0          1.0
 UP BOUND         bf_5_3_1          1.0
 UP BOUND         af_5_3_1          1.0
 UP BOUND         bf_5_3_2          1.0
 UP BOUND         af_5_3_2          1.0
 UP BOUND         bf_5_3_3          1.0
 UP BOUND         af_5_3_3          1.0
 UP BOUND         bf_5_3_4          1.0
 UP BOUND         af_5_3_4          1.0
 UP BOUND         bf_5_3_5          1.0
 FX BOUND         af_5_3_5          0.0
 FX BOUND         bf_5_4_0          0.0
 UP BOUND         af_5_4_0          1.0
 UP BOUND         bf_5_4_1          1.0
 UP BOUND         af_5_4_1          1.0
 UP BOUND         bf_5_4_2          1.0
 UP BOUND         af_5_4_2          1.0
 UP BOUND         bf_5_4_3          1.0
 UP BOUND         af_5_4_3          1.0
 UP BOUND         bf_5_4_4          1.0
 UP BOUND         af_5_4_4          1.0
 UP BOUND         bf_5_4_5          1.0
 FX BOUND         af_5_4_5          0.0
 FX BOUND         bf_6_0_0          0.0
 UP BOUND         af_6_0_0          1.0
 UP BOUND         bf_6_0_1          1.0
 UP BOUND         af_6_0_1          1.0
 UP BOUND         bf_6_0_2          1.0
 UP BOUND         af_6_0_2          1.0
 UP BOUND         bf_6_0_3          1.0
 UP BOUND         af_6_0_3          1.0
 UP BOUND         bf_6_0_4          1.0
 UP BOUND         af_6_0_4          1.0
 UP BOUND         bf_6_0_5          1.0
 FX BOUND         af_6_0_5          0.0
 FX BOUND         bf_6_1_0          0.0
 UP BOUND         af_6_1_0          1.0
 UP BOUND         bf_6_1_1          1.0
 UP BOUND         af_6_1_1          1.0
 UP BOUND         bf_6_1_2          1.0
 UP BOUND         af_6_1_2          1.0
 UP BOUND         bf_6_1_3          1.0
 UP BOUND         af_6_1_3          1.0
 UP BOUND         bf_6_1_4          1.0
 UP BOUND         af_6_1_4          1.0
 UP BOUND         bf_6_1_5          1.0
 FX BOUND         af_6_1_5          0.0
 FX BOUND         bf_6_2_0          0.0
 UP BOUND         af_6_2_0          1.0
 UP BOUND         bf_6_2_1          1.0
 UP BOUND         af_6_2_1          1.0
 UP BOUND         bf_6_2_2          1.0
 UP BOUND         af_6_2_2          1.0
 UP BOUND         bf_6_2_3          1.0
 UP BOUND         af_6_2_3          1.0
 UP BOUND         bf_6_2_4          1.0
 UP BOUND         af_6_2_4          1.0
 UP BOUND         bf_6_2_5          1.0
 FX BOUND         af_6_2_5          0.0
 FX BOUND         bf_6_3_0          0.0
 UP BOUND         af_6_3_0          1.0
 UP BOUND         bf_6_3_1          1.0
 UP BOUND         af_6_3_1          1.0
 UP BOUND         bf_6_3_2          1.0
 UP BOUND         af_6_3_2          1.0
 UP BOUND         bf_6_3_3          1.0
 UP BOUND         af_6_3_3          1.0
 UP BOUND         bf_6_3_4          1.0
 UP BOUND         af_6_3_4          1.0
 UP BOUND         bf_6_3_5          1.0
 FX BOUND         af_6_3_5          0.0
 FX BOUND         bf_6_4_0          0.0
 UP BOUND         af_6_4_0          1.0
 UP BOUND         bf_6_4_1          1.0
 UP BOUND         af_6_4_1          1.0
 UP BOUND         bf_6_4_2          1.0
 UP BOUND         af_6_4_2          1.0
 UP BOUND         bf_6_4_3          1.0
 UP BOUND         af_6_4_3          1.0
 UP BOUND         bf_6_4_4          1.0
 UP BOUND         af_6_4_4          1.0
 UP BOUND         bf_6_4_5          1.0
 FX BOUND         af_6_4_5          0.0
 FX BOUND         bf_7_0_0          0.0
 UP BOUND         af_7_0_0          1.0
 UP BOUND         bf_7_0_1          1.0
 UP BOUND         af_7_0_1          1.0
 UP BOUND         bf_7_0_2          1.0
 UP BOUND         af_7_0_2          1.0
 UP BOUND         bf_7_0_3          1.0
 UP BOUND         af_7_0_3          1.0
 UP BOUND         bf_7_0_4          1.0
 UP BOUND         af_7_0_4          1.0
 UP BOUND         bf_7_0_5          1.0
 FX BOUND         af_7_0_5          0.0
 FX BOUND         bf_7_1_0          0.0
 UP BOUND         af_7_1_0          1.0
 UP BOUND         bf_7_1_1          1.0
 UP BOUND         af_7_1_1          1.0
 UP BOUND         bf_7_1_2          1.0
 UP BOUND         af_7_1_2          1.0
 UP BOUND         bf_7_1_3          1.0
 UP BOUND         af_7_1_3          1.0
 UP BOUND         bf_7_1_4          1.0
 UP BOUND         af_7_1_4          1.0
 UP BOUND         bf_7_1_5          1.0
 FX BOUND         af_7_1_5          0.0
 FX BOUND         bf_7_2_0          0.0
 UP BOUND         af_7_2_0          1.0
 UP BOUND         bf_7_2_1          1.0
 UP BOUND         af_7_2_1          1.0
 UP BOUND         bf_7_2_2          1.0
 UP BOUND         af_7_2_2          1.0
 UP BOUND         bf_7_2_3          1.0
 UP BOUND         af_7_2_3          1.0
 UP BOUND         bf_7_2_4          1.0
 UP BOUND         af_7_2_4          1.0
 UP BOUND         bf_7_2_5          1.0
 FX BOUND         af_7_2_5          0.0
 FX BOUND         bf_7_3_0          0.0
 UP BOUND         af_7_3_0          1.0
 UP BOUND         bf_7_3_1          1.0
 UP BOUND         af_7_3_1          1.0
 UP BOUND         bf_7_3_2          1.0
 UP BOUND         af_7_3_2          1.0
 UP BOUND         bf_7_3_3          1.0
 UP BOUND         af_7_3_3          1.0
 UP BOUND         bf_7_3_4          1.0
 UP BOUND         af_7_3_4          1.0
 UP BOUND         bf_7_3_5          1.0
 FX BOUND         af_7_3_5          0.0
 FX BOUND         bf_7_4_0          0.0
 UP BOUND         af_7_4_0          1.0
 UP BOUND         bf_7_4_1          1.0
 UP BOUND         af_7_4_1          1.0
 UP BOUND         bf_7_4_2          1.0
 UP BOUND         af_7_4_2          1.0
 UP BOUND         bf_7_4_3          1.0
 UP BOUND         af_7_4_3          1.0
 UP BOUND         bf_7_4_4          1.0
 UP BOUND         af_7_4_4          1.0
 UP BOUND         bf_7_4_5          1.0
 FX BOUND         af_7_4_5          0.0
 UP BOUND         gp_0_0_0          1.0
 UP BOUND         gp_0_0_1          1.0
 UP BOUND         gp_0_0_2          1.0
 UP BOUND         gp_0_0_3          1.0
 UP BOUND         gp_0_0_4          1.0
 UP BOUND         gp_0_0_5          1.0
 UP BOUND         gp_0_1_0          1.0
 UP BOUND         gp_0_1_1          1.0
 UP BOUND         gp_0_1_2          1.0
 UP BOUND         gp_0_1_3          1.0
 UP BOUND         gp_0_1_4          1.0
 UP BOUND         gp_0_1_5          1.0
 UP BOUND         gp_0_2_0          1.0
 UP BOUND         gp_0_2_1          1.0
 UP BOUND         gp_0_2_2          1.0
 UP BOUND         gp_0_2_3          1.0
 UP BOUND         gp_0_2_4          1.0
 UP BOUND         gp_0_2_5          1.0
 UP BOUND         gp_0_3_0          1.0
 UP BOUND         gp_0_3_1          1.0
 UP BOUND         gp_0_3_2          1.0
 UP BOUND         gp_0_3_3          1.0
 UP BOUND         gp_0_3_4          1.0
 UP BOUND         gp_0_3_5          1.0
 UP BOUND         gp_0_4_0          1.0
 UP BOUND         gp_0_4_1          1.0
 UP BOUND         gp_0_4_2          1.0
 UP BOUND         gp_0_4_3          1.0
 UP BOUND         gp_0_4_4          1.0
 UP BOUND         gp_0_4_5          1.0
 UP BOUND         gp_1_0_0          1.0
 UP BOUND         gp_1_0_1          1.0
 UP BOUND         gp_1_0_2          1.0
 UP BOUND         gp_1_0_3          1.0
 UP BOUND         gp_1_0_4          1.0
 UP BOUND         gp_1_0_5          1.0
 UP BOUND         gp_1_1_0          1.0
 UP BOUND         gp_1_1_1          1.0
 UP BOUND         gp_1_1_2          1.0
 UP BOUND         gp_1_1_3          1.0
 UP BOUND         gp_1_1_4          1.0
 UP BOUND         gp_1_1_5          1.0
 UP BOUND         gp_1_2_0          1.0
 UP BOUND         gp_1_2_1          1.0
 UP BOUND         gp_1_2_2          1.0
 UP BOUND         gp_1_2_3          1.0
 UP BOUND         gp_1_2_4          1.0
 UP BOUND         gp_1_2_5          1.0
 UP BOUND         gp_1_3_0          1.0
 UP BOUND         gp_1_3_1          1.0
 UP BOUND         gp_1_3_2          1.0
 UP BOUND         gp_1_3_3          1.0
 UP BOUND         gp_1_3_4          1.0
 UP BOUND         gp_1_3_5          1.0
 UP BOUND         gp_1_4_0          1.0
 UP BOUND         gp_1_4_1          1.0
 UP BOUND         gp_1_4_2          1.0
 UP BOUND         gp_1_4_3          1.0
 UP BOUND         gp_1_4_4          1.0
 UP BOUND         gp_1_4_5          1.0
 UP BOUND         gp_2_0_0          1.0
 UP BOUND         gp_2_0_1          1.0
 UP BOUND         gp_2_0_2          1.0
 UP BOUND         gp_2_0_3          1.0
 UP BOUND         gp_2_0_4          1.0
 UP BOUND         gp_2_0_5          1.0
 UP BOUND         gp_2_1_0          1.0
 UP BOUND         gp_2_1_1          1.0
 UP BOUND         gp_2_1_2          1.0
 UP BOUND         gp_2_1_3          1.0
 UP BOUND         gp_2_1_4          1.0
 UP BOUND         gp_2_1_5          1.0
 UP BOUND         gp_2_2_0          1.0
 UP BOUND         gp_2_2_1          1.0
 UP BOUND         gp_2_2_2          1.0
 UP BOUND         gp_2_2_3          1.0
 UP BOUND         gp_2_2_4          1.0
 UP BOUND         gp_2_2_5          1.0
 UP BOUND         gp_2_3_0          1.0
 UP BOUND         gp_2_3_1          1.0
 UP BOUND         gp_2_3_2          1.0
 UP BOUND         gp_2_3_3          1.0
 UP BOUND         gp_2_3_4          1.0
 UP BOUND         gp_2_3_5          1.0
 UP BOUND         gp_2_4_0          1.0
 UP BOUND         gp_2_4_1          1.0
 UP BOUND         gp_2_4_2          1.0
 UP BOUND         gp_2_4_3          1.0
 UP BOUND         gp_2_4_4          1.0
 UP BOUND         gp_2_4_5          1.0
 UP BOUND         gp_3_0_0          1.0
 UP BOUND         gp_3_0_1          1.0
 UP BOUND         gp_3_0_2          1.0
 UP BOUND         gp_3_0_3          1.0
 UP BOUND         gp_3_0_4          1.0
 UP BOUND         gp_3_0_5          1.0
 UP BOUND         gp_3_1_0          1.0
 UP BOUND         gp_3_1_1          1.0
 UP BOUND         gp_3_1_2          1.0
 UP BOUND         gp_3_1_3          1.0
 UP BOUND         gp_3_1_4          1.0
 UP BOUND         gp_3_1_5          1.0
 UP BOUND         gp_3_2_0          1.0
 UP BOUND         gp_3_2_1          1.0
 UP BOUND         gp_3_2_2          1.0
 UP BOUND         gp_3_2_3          1.0
 UP BOUND         gp_3_2_4          1.0
 UP BOUND         gp_3_2_5          1.0
 UP BOUND         gp_3_3_0          1.0
 UP BOUND         gp_3_3_1          1.0
 UP BOUND         gp_3_3_2          1.0
 UP BOUND         gp_3_3_3          1.0
 UP BOUND         gp_3_3_4          1.0
 UP BOUND         gp_3_3_5          1.0
 UP BOUND         gp_3_4_0          1.0
 UP BOUND         gp_3_4_1          1.0
 UP BOUND         gp_3_4_2          1.0
 UP BOUND         gp_3_4_3          1.0
 UP BOUND         gp_3_4_4          1.0
 UP BOUND         gp_3_4_5          1.0
 UP BOUND         gp_4_0_0          1.0
 UP BOUND         gp_4_0_1          1.0
 UP BOUND         gp_4_0_2          1.0
 UP BOUND         gp_4_0_3          1.0
 UP BOUND         gp_4_0_4          1.0
 UP BOUND         gp_4_0_5          1.0
 UP BOUND         gp_4_1_0          1.0
 UP BOUND         gp_4_1_1          1.0
 UP BOUND         gp_4_1_2          1.0
 UP BOUND         gp_4_1_3          1.0
 UP BOUND         gp_4_1_4          1.0
 UP BOUND         gp_4_1_5          1.0
 UP BOUND         gp_4_2_0          1.0
 UP BOUND         gp_4_2_1          1.0
 UP BOUND         gp_4_2_2          1.0
 UP BOUND         gp_4_2_3          1.0
 UP BOUND         gp_4_2_4          1.0
 UP BOUND         gp_4_2_5          1.0
 UP BOUND         gp_4_3_0          1.0
 UP BOUND         gp_4_3_1          1.0
 UP BOUND         gp_4_3_2          1.0
 UP BOUND         gp_4_3_3          1.0
 UP BOUND         gp_4_3_4          1.0
 UP BOUND         gp_4_3_5          1.0
 UP BOUND         gp_4_4_0          1.0
 UP BOUND         gp_4_4_1          1.0
 UP BOUND         gp_4_4_2          1.0
 UP BOUND         gp_4_4_3          1.0
 UP BOUND         gp_4_4_4          1.0
 UP BOUND         gp_4_4_5          1.0
 UP BOUND         gp_5_0_0          1.0
 UP BOUND         gp_5_0_1          1.0
 UP BOUND         gp_5_0_2          1.0
 UP BOUND         gp_5_0_3          1.0
 UP BOUND         gp_5_0_4          1.0
 UP BOUND         gp_5_0_5          1.0
 UP BOUND         gp_5_1_0          1.0
 UP BOUND         gp_5_1_1          1.0
 UP BOUND         gp_5_1_2          1.0
 UP BOUND         gp_5_1_3          1.0
 UP BOUND         gp_5_1_4          1.0
 UP BOUND         gp_5_1_5          1.0
 UP BOUND         gp_5_2_0          1.0
 UP BOUND         gp_5_2_1          1.0
 UP BOUND         gp_5_2_2          1.0
 UP BOUND         gp_5_2_3          1.0
 UP BOUND         gp_5_2_4          1.0
 UP BOUND         gp_5_2_5          1.0
 UP BOUND         gp_5_3_0          1.0
 UP BOUND         gp_5_3_1          1.0
 UP BOUND         gp_5_3_2          1.0
 UP BOUND         gp_5_3_3          1.0
 UP BOUND         gp_5_3_4          1.0
 UP BOUND         gp_5_3_5          1.0
 UP BOUND         gp_5_4_0          1.0
 UP BOUND         gp_5_4_1          1.0
 UP BOUND         gp_5_4_2          1.0
 UP BOUND         gp_5_4_3          1.0
 UP BOUND         gp_5_4_4          1.0
 UP BOUND         gp_5_4_5          1.0
 UP BOUND         gp_6_0_0          1.0
 UP BOUND         gp_6_0_1          1.0
 UP BOUND         gp_6_0_2          1.0
 UP BOUND         gp_6_0_3          1.0
 UP BOUND         gp_6_0_4          1.0
 UP BOUND         gp_6_0_5          1.0
 UP BOUND         gp_6_1_0          1.0
 UP BOUND         gp_6_1_1          1.0
 UP BOUND         gp_6_1_2          1.0
 UP BOUND         gp_6_1_3          1.0
 UP BOUND         gp_6_1_4          1.0
 UP BOUND         gp_6_1_5          1.0
 UP BOUND         gp_6_2_0          1.0
 UP BOUND         gp_6_2_1          1.0
 UP BOUND         gp_6_2_2          1.0
 UP BOUND         gp_6_2_3          1.0
 UP BOUND         gp_6_2_4          1.0
 UP BOUND         gp_6_2_5          1.0
 UP BOUND         gp_6_3_0          1.0
 UP BOUND         gp_6_3_1          1.0
 UP BOUND         gp_6_3_2          1.0
 UP BOUND         gp_6_3_3          1.0
 UP BOUND         gp_6_3_4          1.0
 UP BOUND         gp_6_3_5          1.0
 UP BOUND         gp_6_4_0          1.0
 UP BOUND         gp_6_4_1          1.0
 UP BOUND         gp_6_4_2          1.0
 UP BOUND         gp_6_4_3          1.0
 UP BOUND         gp_6_4_4          1.0
 UP BOUND         gp_6_4_5          1.0
 UP BOUND         gp_7_0_0          1.0
 UP BOUND         gp_7_0_1          1.0
 UP BOUND         gp_7_0_2          1.0
 UP BOUND         gp_7_0_3          1.0
 UP BOUND         gp_7_0_4          1.0
 UP BOUND         gp_7_0_5          1.0
 UP BOUND         gp_7_1_0          1.0
 UP BOUND         gp_7_1_1          1.0
 UP BOUND         gp_7_1_2          1.0
 UP BOUND         gp_7_1_3          1.0
 UP BOUND         gp_7_1_4          1.0
 UP BOUND         gp_7_1_5          1.0
 UP BOUND         gp_7_2_0          1.0
 UP BOUND         gp_7_2_1          1.0
 UP BOUND         gp_7_2_2          1.0
 UP BOUND         gp_7_2_3          1.0
 UP BOUND         gp_7_2_4          1.0
 UP BOUND         gp_7_2_5          1.0
 UP BOUND         gp_7_3_0          1.0
 UP BOUND         gp_7_3_1          1.0
 UP BOUND         gp_7_3_2          1.0
 UP BOUND         gp_7_3_3          1.0
 UP BOUND         gp_7_3_4          1.0
 UP BOUND         gp_7_3_5          1.0
 UP BOUND         gp_7_4_0          1.0
 UP BOUND         gp_7_4_1          1.0
 UP BOUND         gp_7_4_2          1.0
 UP BOUND         gp_7_4_3          1.0
 UP BOUND         gp_7_4_4          1.0
 UP BOUND         gp_7_4_5          1.0
ENDATA
