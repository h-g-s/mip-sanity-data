NAME          jssp_search_n9_m7_skewed_pt1-20_s3
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_0_5
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_1_5
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_2_5
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_3_5
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_4_5
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_5_5
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  prec_6_5
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_7_4
 G  prec_7_5
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_8_4
 G  prec_8_5
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_0_7_5
 G  disj2_0_7_5
 G  disj1_0_8_5
 G  disj2_0_8_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_1_7_5
 G  disj2_1_7_5
 G  disj1_1_8_5
 G  disj2_1_8_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_2_7_5
 G  disj2_2_7_5
 G  disj1_2_8_5
 G  disj2_2_8_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_3_7_5
 G  disj2_3_7_5
 G  disj1_3_8_5
 G  disj2_3_8_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_4_7_5
 G  disj2_4_7_5
 G  disj1_4_8_5
 G  disj2_4_8_5
 G  disj1_5_6_5
 G  disj2_5_6_5
 G  disj1_5_7_5
 G  disj2_5_7_5
 G  disj1_5_8_5
 G  disj2_5_8_5
 G  disj1_6_7_5
 G  disj2_6_7_5
 G  disj1_6_8_5
 G  disj2_6_8_5
 G  disj1_7_8_5
 G  disj2_7_8_5
 G  disj1_0_1_6
 G  disj2_0_1_6
 G  disj1_0_2_6
 G  disj2_0_2_6
 G  disj1_0_3_6
 G  disj2_0_3_6
 G  disj1_0_4_6
 G  disj2_0_4_6
 G  disj1_0_5_6
 G  disj2_0_5_6
 G  disj1_0_6_6
 G  disj2_0_6_6
 G  disj1_0_7_6
 G  disj2_0_7_6
 G  disj1_0_8_6
 G  disj2_0_8_6
 G  disj1_1_2_6
 G  disj2_1_2_6
 G  disj1_1_3_6
 G  disj2_1_3_6
 G  disj1_1_4_6
 G  disj2_1_4_6
 G  disj1_1_5_6
 G  disj2_1_5_6
 G  disj1_1_6_6
 G  disj2_1_6_6
 G  disj1_1_7_6
 G  disj2_1_7_6
 G  disj1_1_8_6
 G  disj2_1_8_6
 G  disj1_2_3_6
 G  disj2_2_3_6
 G  disj1_2_4_6
 G  disj2_2_4_6
 G  disj1_2_5_6
 G  disj2_2_5_6
 G  disj1_2_6_6
 G  disj2_2_6_6
 G  disj1_2_7_6
 G  disj2_2_7_6
 G  disj1_2_8_6
 G  disj2_2_8_6
 G  disj1_3_4_6
 G  disj2_3_4_6
 G  disj1_3_5_6
 G  disj2_3_5_6
 G  disj1_3_6_6
 G  disj2_3_6_6
 G  disj1_3_7_6
 G  disj2_3_7_6
 G  disj1_3_8_6
 G  disj2_3_8_6
 G  disj1_4_5_6
 G  disj2_4_5_6
 G  disj1_4_6_6
 G  disj2_4_6_6
 G  disj1_4_7_6
 G  disj2_4_7_6
 G  disj1_4_8_6
 G  disj2_4_8_6
 G  disj1_5_6_6
 G  disj2_5_6_6
 G  disj1_5_7_6
 G  disj2_5_7_6
 G  disj1_5_8_6
 G  disj2_5_8_6
 G  disj1_6_7_6
 G  disj2_6_7_6
 G  disj1_6_8_6
 G  disj2_6_8_6
 G  disj1_7_8_6
 G  disj2_7_8_6
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_0  -1.0
    x_0_0     disj2_0_1_0  1.0
    x_0_0     disj1_0_2_0  -1.0
    x_0_0     disj2_0_2_0  1.0
    x_0_0     disj1_0_3_0  -1.0
    x_0_0     disj2_0_3_0  1.0
    x_0_0     disj1_0_4_0  -1.0
    x_0_0     disj2_0_4_0  1.0
    x_0_0     disj1_0_5_0  -1.0
    x_0_0     disj2_0_5_0  1.0
    x_0_0     disj1_0_6_0  -1.0
    x_0_0     disj2_0_6_0  1.0
    x_0_0     disj1_0_7_0  -1.0
    x_0_0     disj2_0_7_0  1.0
    x_0_0     disj1_0_8_0  -1.0
    x_0_0     disj2_0_8_0  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_2  -1.0
    x_0_1     disj2_0_1_2  1.0
    x_0_1     disj1_0_2_2  -1.0
    x_0_1     disj2_0_2_2  1.0
    x_0_1     disj1_0_3_2  -1.0
    x_0_1     disj2_0_3_2  1.0
    x_0_1     disj1_0_4_2  -1.0
    x_0_1     disj2_0_4_2  1.0
    x_0_1     disj1_0_5_2  -1.0
    x_0_1     disj2_0_5_2  1.0
    x_0_1     disj1_0_6_2  -1.0
    x_0_1     disj2_0_6_2  1.0
    x_0_1     disj1_0_7_2  -1.0
    x_0_1     disj2_0_7_2  1.0
    x_0_1     disj1_0_8_2  -1.0
    x_0_1     disj2_0_8_2  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_3  -1.0
    x_0_2     disj2_0_1_3  1.0
    x_0_2     disj1_0_2_3  -1.0
    x_0_2     disj2_0_2_3  1.0
    x_0_2     disj1_0_3_3  -1.0
    x_0_2     disj2_0_3_3  1.0
    x_0_2     disj1_0_4_3  -1.0
    x_0_2     disj2_0_4_3  1.0
    x_0_2     disj1_0_5_3  -1.0
    x_0_2     disj2_0_5_3  1.0
    x_0_2     disj1_0_6_3  -1.0
    x_0_2     disj2_0_6_3  1.0
    x_0_2     disj1_0_7_3  -1.0
    x_0_2     disj2_0_7_3  1.0
    x_0_2     disj1_0_8_3  -1.0
    x_0_2     disj2_0_8_3  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_6  -1.0
    x_0_3     disj2_0_1_6  1.0
    x_0_3     disj1_0_2_6  -1.0
    x_0_3     disj2_0_2_6  1.0
    x_0_3     disj1_0_3_6  -1.0
    x_0_3     disj2_0_3_6  1.0
    x_0_3     disj1_0_4_6  -1.0
    x_0_3     disj2_0_4_6  1.0
    x_0_3     disj1_0_5_6  -1.0
    x_0_3     disj2_0_5_6  1.0
    x_0_3     disj1_0_6_6  -1.0
    x_0_3     disj2_0_6_6  1.0
    x_0_3     disj1_0_7_6  -1.0
    x_0_3     disj2_0_7_6  1.0
    x_0_3     disj1_0_8_6  -1.0
    x_0_3     disj2_0_8_6  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_5  -1.0
    x_0_4     disj2_0_1_5  1.0
    x_0_4     disj1_0_2_5  -1.0
    x_0_4     disj2_0_2_5  1.0
    x_0_4     disj1_0_3_5  -1.0
    x_0_4     disj2_0_3_5  1.0
    x_0_4     disj1_0_4_5  -1.0
    x_0_4     disj2_0_4_5  1.0
    x_0_4     disj1_0_5_5  -1.0
    x_0_4     disj2_0_5_5  1.0
    x_0_4     disj1_0_6_5  -1.0
    x_0_4     disj2_0_6_5  1.0
    x_0_4     disj1_0_7_5  -1.0
    x_0_4     disj2_0_7_5  1.0
    x_0_4     disj1_0_8_5  -1.0
    x_0_4     disj2_0_8_5  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     prec_0_5  -1.0
    x_0_5     disj1_0_1_4  -1.0
    x_0_5     disj2_0_1_4  1.0
    x_0_5     disj1_0_2_4  -1.0
    x_0_5     disj2_0_2_4  1.0
    x_0_5     disj1_0_3_4  -1.0
    x_0_5     disj2_0_3_4  1.0
    x_0_5     disj1_0_4_4  -1.0
    x_0_5     disj2_0_4_4  1.0
    x_0_5     disj1_0_5_4  -1.0
    x_0_5     disj2_0_5_4  1.0
    x_0_5     disj1_0_6_4  -1.0
    x_0_5     disj2_0_6_4  1.0
    x_0_5     disj1_0_7_4  -1.0
    x_0_5     disj2_0_7_4  1.0
    x_0_5     disj1_0_8_4  -1.0
    x_0_5     disj2_0_8_4  1.0
    x_0_6     prec_0_5  1.0
    x_0_6     mksp_0    -1.0
    x_0_6     disj1_0_1_1  -1.0
    x_0_6     disj2_0_1_1  1.0
    x_0_6     disj1_0_2_1  -1.0
    x_0_6     disj2_0_2_1  1.0
    x_0_6     disj1_0_3_1  -1.0
    x_0_6     disj2_0_3_1  1.0
    x_0_6     disj1_0_4_1  -1.0
    x_0_6     disj2_0_4_1  1.0
    x_0_6     disj1_0_5_1  -1.0
    x_0_6     disj2_0_5_1  1.0
    x_0_6     disj1_0_6_1  -1.0
    x_0_6     disj2_0_6_1  1.0
    x_0_6     disj1_0_7_1  -1.0
    x_0_6     disj2_0_7_1  1.0
    x_0_6     disj1_0_8_1  -1.0
    x_0_6     disj2_0_8_1  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_0     disj1_1_7_1  -1.0
    x_1_0     disj2_1_7_1  1.0
    x_1_0     disj1_1_8_1  -1.0
    x_1_0     disj2_1_8_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_5  1.0
    x_1_1     disj2_0_1_5  -1.0
    x_1_1     disj1_1_2_5  -1.0
    x_1_1     disj2_1_2_5  1.0
    x_1_1     disj1_1_3_5  -1.0
    x_1_1     disj2_1_3_5  1.0
    x_1_1     disj1_1_4_5  -1.0
    x_1_1     disj2_1_4_5  1.0
    x_1_1     disj1_1_5_5  -1.0
    x_1_1     disj2_1_5_5  1.0
    x_1_1     disj1_1_6_5  -1.0
    x_1_1     disj2_1_6_5  1.0
    x_1_1     disj1_1_7_5  -1.0
    x_1_1     disj2_1_7_5  1.0
    x_1_1     disj1_1_8_5  -1.0
    x_1_1     disj2_1_8_5  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_2  1.0
    x_1_2     disj2_0_1_2  -1.0
    x_1_2     disj1_1_2_2  -1.0
    x_1_2     disj2_1_2_2  1.0
    x_1_2     disj1_1_3_2  -1.0
    x_1_2     disj2_1_3_2  1.0
    x_1_2     disj1_1_4_2  -1.0
    x_1_2     disj2_1_4_2  1.0
    x_1_2     disj1_1_5_2  -1.0
    x_1_2     disj2_1_5_2  1.0
    x_1_2     disj1_1_6_2  -1.0
    x_1_2     disj2_1_6_2  1.0
    x_1_2     disj1_1_7_2  -1.0
    x_1_2     disj2_1_7_2  1.0
    x_1_2     disj1_1_8_2  -1.0
    x_1_2     disj2_1_8_2  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_0  1.0
    x_1_3     disj2_0_1_0  -1.0
    x_1_3     disj1_1_2_0  -1.0
    x_1_3     disj2_1_2_0  1.0
    x_1_3     disj1_1_3_0  -1.0
    x_1_3     disj2_1_3_0  1.0
    x_1_3     disj1_1_4_0  -1.0
    x_1_3     disj2_1_4_0  1.0
    x_1_3     disj1_1_5_0  -1.0
    x_1_3     disj2_1_5_0  1.0
    x_1_3     disj1_1_6_0  -1.0
    x_1_3     disj2_1_6_0  1.0
    x_1_3     disj1_1_7_0  -1.0
    x_1_3     disj2_1_7_0  1.0
    x_1_3     disj1_1_8_0  -1.0
    x_1_3     disj2_1_8_0  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_3  1.0
    x_1_4     disj2_0_1_3  -1.0
    x_1_4     disj1_1_2_3  -1.0
    x_1_4     disj2_1_2_3  1.0
    x_1_4     disj1_1_3_3  -1.0
    x_1_4     disj2_1_3_3  1.0
    x_1_4     disj1_1_4_3  -1.0
    x_1_4     disj2_1_4_3  1.0
    x_1_4     disj1_1_5_3  -1.0
    x_1_4     disj2_1_5_3  1.0
    x_1_4     disj1_1_6_3  -1.0
    x_1_4     disj2_1_6_3  1.0
    x_1_4     disj1_1_7_3  -1.0
    x_1_4     disj2_1_7_3  1.0
    x_1_4     disj1_1_8_3  -1.0
    x_1_4     disj2_1_8_3  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     prec_1_5  -1.0
    x_1_5     disj1_0_1_4  1.0
    x_1_5     disj2_0_1_4  -1.0
    x_1_5     disj1_1_2_4  -1.0
    x_1_5     disj2_1_2_4  1.0
    x_1_5     disj1_1_3_4  -1.0
    x_1_5     disj2_1_3_4  1.0
    x_1_5     disj1_1_4_4  -1.0
    x_1_5     disj2_1_4_4  1.0
    x_1_5     disj1_1_5_4  -1.0
    x_1_5     disj2_1_5_4  1.0
    x_1_5     disj1_1_6_4  -1.0
    x_1_5     disj2_1_6_4  1.0
    x_1_5     disj1_1_7_4  -1.0
    x_1_5     disj2_1_7_4  1.0
    x_1_5     disj1_1_8_4  -1.0
    x_1_5     disj2_1_8_4  1.0
    x_1_6     prec_1_5  1.0
    x_1_6     mksp_1    -1.0
    x_1_6     disj1_0_1_6  1.0
    x_1_6     disj2_0_1_6  -1.0
    x_1_6     disj1_1_2_6  -1.0
    x_1_6     disj2_1_2_6  1.0
    x_1_6     disj1_1_3_6  -1.0
    x_1_6     disj2_1_3_6  1.0
    x_1_6     disj1_1_4_6  -1.0
    x_1_6     disj2_1_4_6  1.0
    x_1_6     disj1_1_5_6  -1.0
    x_1_6     disj2_1_5_6  1.0
    x_1_6     disj1_1_6_6  -1.0
    x_1_6     disj2_1_6_6  1.0
    x_1_6     disj1_1_7_6  -1.0
    x_1_6     disj2_1_7_6  1.0
    x_1_6     disj1_1_8_6  -1.0
    x_1_6     disj2_1_8_6  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_6  1.0
    x_2_0     disj2_0_2_6  -1.0
    x_2_0     disj1_1_2_6  1.0
    x_2_0     disj2_1_2_6  -1.0
    x_2_0     disj1_2_3_6  -1.0
    x_2_0     disj2_2_3_6  1.0
    x_2_0     disj1_2_4_6  -1.0
    x_2_0     disj2_2_4_6  1.0
    x_2_0     disj1_2_5_6  -1.0
    x_2_0     disj2_2_5_6  1.0
    x_2_0     disj1_2_6_6  -1.0
    x_2_0     disj2_2_6_6  1.0
    x_2_0     disj1_2_7_6  -1.0
    x_2_0     disj2_2_7_6  1.0
    x_2_0     disj1_2_8_6  -1.0
    x_2_0     disj2_2_8_6  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_4  1.0
    x_2_1     disj2_0_2_4  -1.0
    x_2_1     disj1_1_2_4  1.0
    x_2_1     disj2_1_2_4  -1.0
    x_2_1     disj1_2_3_4  -1.0
    x_2_1     disj2_2_3_4  1.0
    x_2_1     disj1_2_4_4  -1.0
    x_2_1     disj2_2_4_4  1.0
    x_2_1     disj1_2_5_4  -1.0
    x_2_1     disj2_2_5_4  1.0
    x_2_1     disj1_2_6_4  -1.0
    x_2_1     disj2_2_6_4  1.0
    x_2_1     disj1_2_7_4  -1.0
    x_2_1     disj2_2_7_4  1.0
    x_2_1     disj1_2_8_4  -1.0
    x_2_1     disj2_2_8_4  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_3  1.0
    x_2_2     disj2_0_2_3  -1.0
    x_2_2     disj1_1_2_3  1.0
    x_2_2     disj2_1_2_3  -1.0
    x_2_2     disj1_2_3_3  -1.0
    x_2_2     disj2_2_3_3  1.0
    x_2_2     disj1_2_4_3  -1.0
    x_2_2     disj2_2_4_3  1.0
    x_2_2     disj1_2_5_3  -1.0
    x_2_2     disj2_2_5_3  1.0
    x_2_2     disj1_2_6_3  -1.0
    x_2_2     disj2_2_6_3  1.0
    x_2_2     disj1_2_7_3  -1.0
    x_2_2     disj2_2_7_3  1.0
    x_2_2     disj1_2_8_3  -1.0
    x_2_2     disj2_2_8_3  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_1  1.0
    x_2_3     disj2_0_2_1  -1.0
    x_2_3     disj1_1_2_1  1.0
    x_2_3     disj2_1_2_1  -1.0
    x_2_3     disj1_2_3_1  -1.0
    x_2_3     disj2_2_3_1  1.0
    x_2_3     disj1_2_4_1  -1.0
    x_2_3     disj2_2_4_1  1.0
    x_2_3     disj1_2_5_1  -1.0
    x_2_3     disj2_2_5_1  1.0
    x_2_3     disj1_2_6_1  -1.0
    x_2_3     disj2_2_6_1  1.0
    x_2_3     disj1_2_7_1  -1.0
    x_2_3     disj2_2_7_1  1.0
    x_2_3     disj1_2_8_1  -1.0
    x_2_3     disj2_2_8_1  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_5  1.0
    x_2_4     disj2_0_2_5  -1.0
    x_2_4     disj1_1_2_5  1.0
    x_2_4     disj2_1_2_5  -1.0
    x_2_4     disj1_2_3_5  -1.0
    x_2_4     disj2_2_3_5  1.0
    x_2_4     disj1_2_4_5  -1.0
    x_2_4     disj2_2_4_5  1.0
    x_2_4     disj1_2_5_5  -1.0
    x_2_4     disj2_2_5_5  1.0
    x_2_4     disj1_2_6_5  -1.0
    x_2_4     disj2_2_6_5  1.0
    x_2_4     disj1_2_7_5  -1.0
    x_2_4     disj2_2_7_5  1.0
    x_2_4     disj1_2_8_5  -1.0
    x_2_4     disj2_2_8_5  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     prec_2_5  -1.0
    x_2_5     disj1_0_2_0  1.0
    x_2_5     disj2_0_2_0  -1.0
    x_2_5     disj1_1_2_0  1.0
    x_2_5     disj2_1_2_0  -1.0
    x_2_5     disj1_2_3_0  -1.0
    x_2_5     disj2_2_3_0  1.0
    x_2_5     disj1_2_4_0  -1.0
    x_2_5     disj2_2_4_0  1.0
    x_2_5     disj1_2_5_0  -1.0
    x_2_5     disj2_2_5_0  1.0
    x_2_5     disj1_2_6_0  -1.0
    x_2_5     disj2_2_6_0  1.0
    x_2_5     disj1_2_7_0  -1.0
    x_2_5     disj2_2_7_0  1.0
    x_2_5     disj1_2_8_0  -1.0
    x_2_5     disj2_2_8_0  1.0
    x_2_6     prec_2_5  1.0
    x_2_6     mksp_2    -1.0
    x_2_6     disj1_0_2_2  1.0
    x_2_6     disj2_0_2_2  -1.0
    x_2_6     disj1_1_2_2  1.0
    x_2_6     disj2_1_2_2  -1.0
    x_2_6     disj1_2_3_2  -1.0
    x_2_6     disj2_2_3_2  1.0
    x_2_6     disj1_2_4_2  -1.0
    x_2_6     disj2_2_4_2  1.0
    x_2_6     disj1_2_5_2  -1.0
    x_2_6     disj2_2_5_2  1.0
    x_2_6     disj1_2_6_2  -1.0
    x_2_6     disj2_2_6_2  1.0
    x_2_6     disj1_2_7_2  -1.0
    x_2_6     disj2_2_7_2  1.0
    x_2_6     disj1_2_8_2  -1.0
    x_2_6     disj2_2_8_2  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_0  1.0
    x_3_0     disj2_0_3_0  -1.0
    x_3_0     disj1_1_3_0  1.0
    x_3_0     disj2_1_3_0  -1.0
    x_3_0     disj1_2_3_0  1.0
    x_3_0     disj2_2_3_0  -1.0
    x_3_0     disj1_3_4_0  -1.0
    x_3_0     disj2_3_4_0  1.0
    x_3_0     disj1_3_5_0  -1.0
    x_3_0     disj2_3_5_0  1.0
    x_3_0     disj1_3_6_0  -1.0
    x_3_0     disj2_3_6_0  1.0
    x_3_0     disj1_3_7_0  -1.0
    x_3_0     disj2_3_7_0  1.0
    x_3_0     disj1_3_8_0  -1.0
    x_3_0     disj2_3_8_0  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_3  1.0
    x_3_1     disj2_0_3_3  -1.0
    x_3_1     disj1_1_3_3  1.0
    x_3_1     disj2_1_3_3  -1.0
    x_3_1     disj1_2_3_3  1.0
    x_3_1     disj2_2_3_3  -1.0
    x_3_1     disj1_3_4_3  -1.0
    x_3_1     disj2_3_4_3  1.0
    x_3_1     disj1_3_5_3  -1.0
    x_3_1     disj2_3_5_3  1.0
    x_3_1     disj1_3_6_3  -1.0
    x_3_1     disj2_3_6_3  1.0
    x_3_1     disj1_3_7_3  -1.0
    x_3_1     disj2_3_7_3  1.0
    x_3_1     disj1_3_8_3  -1.0
    x_3_1     disj2_3_8_3  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_5  1.0
    x_3_2     disj2_0_3_5  -1.0
    x_3_2     disj1_1_3_5  1.0
    x_3_2     disj2_1_3_5  -1.0
    x_3_2     disj1_2_3_5  1.0
    x_3_2     disj2_2_3_5  -1.0
    x_3_2     disj1_3_4_5  -1.0
    x_3_2     disj2_3_4_5  1.0
    x_3_2     disj1_3_5_5  -1.0
    x_3_2     disj2_3_5_5  1.0
    x_3_2     disj1_3_6_5  -1.0
    x_3_2     disj2_3_6_5  1.0
    x_3_2     disj1_3_7_5  -1.0
    x_3_2     disj2_3_7_5  1.0
    x_3_2     disj1_3_8_5  -1.0
    x_3_2     disj2_3_8_5  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_1  1.0
    x_3_3     disj2_0_3_1  -1.0
    x_3_3     disj1_1_3_1  1.0
    x_3_3     disj2_1_3_1  -1.0
    x_3_3     disj1_2_3_1  1.0
    x_3_3     disj2_2_3_1  -1.0
    x_3_3     disj1_3_4_1  -1.0
    x_3_3     disj2_3_4_1  1.0
    x_3_3     disj1_3_5_1  -1.0
    x_3_3     disj2_3_5_1  1.0
    x_3_3     disj1_3_6_1  -1.0
    x_3_3     disj2_3_6_1  1.0
    x_3_3     disj1_3_7_1  -1.0
    x_3_3     disj2_3_7_1  1.0
    x_3_3     disj1_3_8_1  -1.0
    x_3_3     disj2_3_8_1  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_4  1.0
    x_3_4     disj2_0_3_4  -1.0
    x_3_4     disj1_1_3_4  1.0
    x_3_4     disj2_1_3_4  -1.0
    x_3_4     disj1_2_3_4  1.0
    x_3_4     disj2_2_3_4  -1.0
    x_3_4     disj1_3_4_4  -1.0
    x_3_4     disj2_3_4_4  1.0
    x_3_4     disj1_3_5_4  -1.0
    x_3_4     disj2_3_5_4  1.0
    x_3_4     disj1_3_6_4  -1.0
    x_3_4     disj2_3_6_4  1.0
    x_3_4     disj1_3_7_4  -1.0
    x_3_4     disj2_3_7_4  1.0
    x_3_4     disj1_3_8_4  -1.0
    x_3_4     disj2_3_8_4  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     prec_3_5  -1.0
    x_3_5     disj1_0_3_2  1.0
    x_3_5     disj2_0_3_2  -1.0
    x_3_5     disj1_1_3_2  1.0
    x_3_5     disj2_1_3_2  -1.0
    x_3_5     disj1_2_3_2  1.0
    x_3_5     disj2_2_3_2  -1.0
    x_3_5     disj1_3_4_2  -1.0
    x_3_5     disj2_3_4_2  1.0
    x_3_5     disj1_3_5_2  -1.0
    x_3_5     disj2_3_5_2  1.0
    x_3_5     disj1_3_6_2  -1.0
    x_3_5     disj2_3_6_2  1.0
    x_3_5     disj1_3_7_2  -1.0
    x_3_5     disj2_3_7_2  1.0
    x_3_5     disj1_3_8_2  -1.0
    x_3_5     disj2_3_8_2  1.0
    x_3_6     prec_3_5  1.0
    x_3_6     mksp_3    -1.0
    x_3_6     disj1_0_3_6  1.0
    x_3_6     disj2_0_3_6  -1.0
    x_3_6     disj1_1_3_6  1.0
    x_3_6     disj2_1_3_6  -1.0
    x_3_6     disj1_2_3_6  1.0
    x_3_6     disj2_2_3_6  -1.0
    x_3_6     disj1_3_4_6  -1.0
    x_3_6     disj2_3_4_6  1.0
    x_3_6     disj1_3_5_6  -1.0
    x_3_6     disj2_3_5_6  1.0
    x_3_6     disj1_3_6_6  -1.0
    x_3_6     disj2_3_6_6  1.0
    x_3_6     disj1_3_7_6  -1.0
    x_3_6     disj2_3_7_6  1.0
    x_3_6     disj1_3_8_6  -1.0
    x_3_6     disj2_3_8_6  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_4  1.0
    x_4_0     disj2_0_4_4  -1.0
    x_4_0     disj1_1_4_4  1.0
    x_4_0     disj2_1_4_4  -1.0
    x_4_0     disj1_2_4_4  1.0
    x_4_0     disj2_2_4_4  -1.0
    x_4_0     disj1_3_4_4  1.0
    x_4_0     disj2_3_4_4  -1.0
    x_4_0     disj1_4_5_4  -1.0
    x_4_0     disj2_4_5_4  1.0
    x_4_0     disj1_4_6_4  -1.0
    x_4_0     disj2_4_6_4  1.0
    x_4_0     disj1_4_7_4  -1.0
    x_4_0     disj2_4_7_4  1.0
    x_4_0     disj1_4_8_4  -1.0
    x_4_0     disj2_4_8_4  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_6  1.0
    x_4_1     disj2_0_4_6  -1.0
    x_4_1     disj1_1_4_6  1.0
    x_4_1     disj2_1_4_6  -1.0
    x_4_1     disj1_2_4_6  1.0
    x_4_1     disj2_2_4_6  -1.0
    x_4_1     disj1_3_4_6  1.0
    x_4_1     disj2_3_4_6  -1.0
    x_4_1     disj1_4_5_6  -1.0
    x_4_1     disj2_4_5_6  1.0
    x_4_1     disj1_4_6_6  -1.0
    x_4_1     disj2_4_6_6  1.0
    x_4_1     disj1_4_7_6  -1.0
    x_4_1     disj2_4_7_6  1.0
    x_4_1     disj1_4_8_6  -1.0
    x_4_1     disj2_4_8_6  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_5  1.0
    x_4_2     disj2_0_4_5  -1.0
    x_4_2     disj1_1_4_5  1.0
    x_4_2     disj2_1_4_5  -1.0
    x_4_2     disj1_2_4_5  1.0
    x_4_2     disj2_2_4_5  -1.0
    x_4_2     disj1_3_4_5  1.0
    x_4_2     disj2_3_4_5  -1.0
    x_4_2     disj1_4_5_5  -1.0
    x_4_2     disj2_4_5_5  1.0
    x_4_2     disj1_4_6_5  -1.0
    x_4_2     disj2_4_6_5  1.0
    x_4_2     disj1_4_7_5  -1.0
    x_4_2     disj2_4_7_5  1.0
    x_4_2     disj1_4_8_5  -1.0
    x_4_2     disj2_4_8_5  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_2  1.0
    x_4_3     disj2_0_4_2  -1.0
    x_4_3     disj1_1_4_2  1.0
    x_4_3     disj2_1_4_2  -1.0
    x_4_3     disj1_2_4_2  1.0
    x_4_3     disj2_2_4_2  -1.0
    x_4_3     disj1_3_4_2  1.0
    x_4_3     disj2_3_4_2  -1.0
    x_4_3     disj1_4_5_2  -1.0
    x_4_3     disj2_4_5_2  1.0
    x_4_3     disj1_4_6_2  -1.0
    x_4_3     disj2_4_6_2  1.0
    x_4_3     disj1_4_7_2  -1.0
    x_4_3     disj2_4_7_2  1.0
    x_4_3     disj1_4_8_2  -1.0
    x_4_3     disj2_4_8_2  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_0  1.0
    x_4_4     disj2_0_4_0  -1.0
    x_4_4     disj1_1_4_0  1.0
    x_4_4     disj2_1_4_0  -1.0
    x_4_4     disj1_2_4_0  1.0
    x_4_4     disj2_2_4_0  -1.0
    x_4_4     disj1_3_4_0  1.0
    x_4_4     disj2_3_4_0  -1.0
    x_4_4     disj1_4_5_0  -1.0
    x_4_4     disj2_4_5_0  1.0
    x_4_4     disj1_4_6_0  -1.0
    x_4_4     disj2_4_6_0  1.0
    x_4_4     disj1_4_7_0  -1.0
    x_4_4     disj2_4_7_0  1.0
    x_4_4     disj1_4_8_0  -1.0
    x_4_4     disj2_4_8_0  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     prec_4_5  -1.0
    x_4_5     disj1_0_4_1  1.0
    x_4_5     disj2_0_4_1  -1.0
    x_4_5     disj1_1_4_1  1.0
    x_4_5     disj2_1_4_1  -1.0
    x_4_5     disj1_2_4_1  1.0
    x_4_5     disj2_2_4_1  -1.0
    x_4_5     disj1_3_4_1  1.0
    x_4_5     disj2_3_4_1  -1.0
    x_4_5     disj1_4_5_1  -1.0
    x_4_5     disj2_4_5_1  1.0
    x_4_5     disj1_4_6_1  -1.0
    x_4_5     disj2_4_6_1  1.0
    x_4_5     disj1_4_7_1  -1.0
    x_4_5     disj2_4_7_1  1.0
    x_4_5     disj1_4_8_1  -1.0
    x_4_5     disj2_4_8_1  1.0
    x_4_6     prec_4_5  1.0
    x_4_6     mksp_4    -1.0
    x_4_6     disj1_0_4_3  1.0
    x_4_6     disj2_0_4_3  -1.0
    x_4_6     disj1_1_4_3  1.0
    x_4_6     disj2_1_4_3  -1.0
    x_4_6     disj1_2_4_3  1.0
    x_4_6     disj2_2_4_3  -1.0
    x_4_6     disj1_3_4_3  1.0
    x_4_6     disj2_3_4_3  -1.0
    x_4_6     disj1_4_5_3  -1.0
    x_4_6     disj2_4_5_3  1.0
    x_4_6     disj1_4_6_3  -1.0
    x_4_6     disj2_4_6_3  1.0
    x_4_6     disj1_4_7_3  -1.0
    x_4_6     disj2_4_7_3  1.0
    x_4_6     disj1_4_8_3  -1.0
    x_4_6     disj2_4_8_3  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_6  1.0
    x_5_0     disj2_0_5_6  -1.0
    x_5_0     disj1_1_5_6  1.0
    x_5_0     disj2_1_5_6  -1.0
    x_5_0     disj1_2_5_6  1.0
    x_5_0     disj2_2_5_6  -1.0
    x_5_0     disj1_3_5_6  1.0
    x_5_0     disj2_3_5_6  -1.0
    x_5_0     disj1_4_5_6  1.0
    x_5_0     disj2_4_5_6  -1.0
    x_5_0     disj1_5_6_6  -1.0
    x_5_0     disj2_5_6_6  1.0
    x_5_0     disj1_5_7_6  -1.0
    x_5_0     disj2_5_7_6  1.0
    x_5_0     disj1_5_8_6  -1.0
    x_5_0     disj2_5_8_6  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_5  1.0
    x_5_1     disj2_0_5_5  -1.0
    x_5_1     disj1_1_5_5  1.0
    x_5_1     disj2_1_5_5  -1.0
    x_5_1     disj1_2_5_5  1.0
    x_5_1     disj2_2_5_5  -1.0
    x_5_1     disj1_3_5_5  1.0
    x_5_1     disj2_3_5_5  -1.0
    x_5_1     disj1_4_5_5  1.0
    x_5_1     disj2_4_5_5  -1.0
    x_5_1     disj1_5_6_5  -1.0
    x_5_1     disj2_5_6_5  1.0
    x_5_1     disj1_5_7_5  -1.0
    x_5_1     disj2_5_7_5  1.0
    x_5_1     disj1_5_8_5  -1.0
    x_5_1     disj2_5_8_5  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_4  1.0
    x_5_2     disj2_0_5_4  -1.0
    x_5_2     disj1_1_5_4  1.0
    x_5_2     disj2_1_5_4  -1.0
    x_5_2     disj1_2_5_4  1.0
    x_5_2     disj2_2_5_4  -1.0
    x_5_2     disj1_3_5_4  1.0
    x_5_2     disj2_3_5_4  -1.0
    x_5_2     disj1_4_5_4  1.0
    x_5_2     disj2_4_5_4  -1.0
    x_5_2     disj1_5_6_4  -1.0
    x_5_2     disj2_5_6_4  1.0
    x_5_2     disj1_5_7_4  -1.0
    x_5_2     disj2_5_7_4  1.0
    x_5_2     disj1_5_8_4  -1.0
    x_5_2     disj2_5_8_4  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_2  1.0
    x_5_3     disj2_0_5_2  -1.0
    x_5_3     disj1_1_5_2  1.0
    x_5_3     disj2_1_5_2  -1.0
    x_5_3     disj1_2_5_2  1.0
    x_5_3     disj2_2_5_2  -1.0
    x_5_3     disj1_3_5_2  1.0
    x_5_3     disj2_3_5_2  -1.0
    x_5_3     disj1_4_5_2  1.0
    x_5_3     disj2_4_5_2  -1.0
    x_5_3     disj1_5_6_2  -1.0
    x_5_3     disj2_5_6_2  1.0
    x_5_3     disj1_5_7_2  -1.0
    x_5_3     disj2_5_7_2  1.0
    x_5_3     disj1_5_8_2  -1.0
    x_5_3     disj2_5_8_2  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_3  1.0
    x_5_4     disj2_0_5_3  -1.0
    x_5_4     disj1_1_5_3  1.0
    x_5_4     disj2_1_5_3  -1.0
    x_5_4     disj1_2_5_3  1.0
    x_5_4     disj2_2_5_3  -1.0
    x_5_4     disj1_3_5_3  1.0
    x_5_4     disj2_3_5_3  -1.0
    x_5_4     disj1_4_5_3  1.0
    x_5_4     disj2_4_5_3  -1.0
    x_5_4     disj1_5_6_3  -1.0
    x_5_4     disj2_5_6_3  1.0
    x_5_4     disj1_5_7_3  -1.0
    x_5_4     disj2_5_7_3  1.0
    x_5_4     disj1_5_8_3  -1.0
    x_5_4     disj2_5_8_3  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     prec_5_5  -1.0
    x_5_5     disj1_0_5_1  1.0
    x_5_5     disj2_0_5_1  -1.0
    x_5_5     disj1_1_5_1  1.0
    x_5_5     disj2_1_5_1  -1.0
    x_5_5     disj1_2_5_1  1.0
    x_5_5     disj2_2_5_1  -1.0
    x_5_5     disj1_3_5_1  1.0
    x_5_5     disj2_3_5_1  -1.0
    x_5_5     disj1_4_5_1  1.0
    x_5_5     disj2_4_5_1  -1.0
    x_5_5     disj1_5_6_1  -1.0
    x_5_5     disj2_5_6_1  1.0
    x_5_5     disj1_5_7_1  -1.0
    x_5_5     disj2_5_7_1  1.0
    x_5_5     disj1_5_8_1  -1.0
    x_5_5     disj2_5_8_1  1.0
    x_5_6     prec_5_5  1.0
    x_5_6     mksp_5    -1.0
    x_5_6     disj1_0_5_0  1.0
    x_5_6     disj2_0_5_0  -1.0
    x_5_6     disj1_1_5_0  1.0
    x_5_6     disj2_1_5_0  -1.0
    x_5_6     disj1_2_5_0  1.0
    x_5_6     disj2_2_5_0  -1.0
    x_5_6     disj1_3_5_0  1.0
    x_5_6     disj2_3_5_0  -1.0
    x_5_6     disj1_4_5_0  1.0
    x_5_6     disj2_4_5_0  -1.0
    x_5_6     disj1_5_6_0  -1.0
    x_5_6     disj2_5_6_0  1.0
    x_5_6     disj1_5_7_0  -1.0
    x_5_6     disj2_5_7_0  1.0
    x_5_6     disj1_5_8_0  -1.0
    x_5_6     disj2_5_8_0  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_1  1.0
    x_6_0     disj2_0_6_1  -1.0
    x_6_0     disj1_1_6_1  1.0
    x_6_0     disj2_1_6_1  -1.0
    x_6_0     disj1_2_6_1  1.0
    x_6_0     disj2_2_6_1  -1.0
    x_6_0     disj1_3_6_1  1.0
    x_6_0     disj2_3_6_1  -1.0
    x_6_0     disj1_4_6_1  1.0
    x_6_0     disj2_4_6_1  -1.0
    x_6_0     disj1_5_6_1  1.0
    x_6_0     disj2_5_6_1  -1.0
    x_6_0     disj1_6_7_1  -1.0
    x_6_0     disj2_6_7_1  1.0
    x_6_0     disj1_6_8_1  -1.0
    x_6_0     disj2_6_8_1  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_0  1.0
    x_6_1     disj2_0_6_0  -1.0
    x_6_1     disj1_1_6_0  1.0
    x_6_1     disj2_1_6_0  -1.0
    x_6_1     disj1_2_6_0  1.0
    x_6_1     disj2_2_6_0  -1.0
    x_6_1     disj1_3_6_0  1.0
    x_6_1     disj2_3_6_0  -1.0
    x_6_1     disj1_4_6_0  1.0
    x_6_1     disj2_4_6_0  -1.0
    x_6_1     disj1_5_6_0  1.0
    x_6_1     disj2_5_6_0  -1.0
    x_6_1     disj1_6_7_0  -1.0
    x_6_1     disj2_6_7_0  1.0
    x_6_1     disj1_6_8_0  -1.0
    x_6_1     disj2_6_8_0  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_5  1.0
    x_6_2     disj2_0_6_5  -1.0
    x_6_2     disj1_1_6_5  1.0
    x_6_2     disj2_1_6_5  -1.0
    x_6_2     disj1_2_6_5  1.0
    x_6_2     disj2_2_6_5  -1.0
    x_6_2     disj1_3_6_5  1.0
    x_6_2     disj2_3_6_5  -1.0
    x_6_2     disj1_4_6_5  1.0
    x_6_2     disj2_4_6_5  -1.0
    x_6_2     disj1_5_6_5  1.0
    x_6_2     disj2_5_6_5  -1.0
    x_6_2     disj1_6_7_5  -1.0
    x_6_2     disj2_6_7_5  1.0
    x_6_2     disj1_6_8_5  -1.0
    x_6_2     disj2_6_8_5  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_3  1.0
    x_6_3     disj2_0_6_3  -1.0
    x_6_3     disj1_1_6_3  1.0
    x_6_3     disj2_1_6_3  -1.0
    x_6_3     disj1_2_6_3  1.0
    x_6_3     disj2_2_6_3  -1.0
    x_6_3     disj1_3_6_3  1.0
    x_6_3     disj2_3_6_3  -1.0
    x_6_3     disj1_4_6_3  1.0
    x_6_3     disj2_4_6_3  -1.0
    x_6_3     disj1_5_6_3  1.0
    x_6_3     disj2_5_6_3  -1.0
    x_6_3     disj1_6_7_3  -1.0
    x_6_3     disj2_6_7_3  1.0
    x_6_3     disj1_6_8_3  -1.0
    x_6_3     disj2_6_8_3  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_2  1.0
    x_6_4     disj2_0_6_2  -1.0
    x_6_4     disj1_1_6_2  1.0
    x_6_4     disj2_1_6_2  -1.0
    x_6_4     disj1_2_6_2  1.0
    x_6_4     disj2_2_6_2  -1.0
    x_6_4     disj1_3_6_2  1.0
    x_6_4     disj2_3_6_2  -1.0
    x_6_4     disj1_4_6_2  1.0
    x_6_4     disj2_4_6_2  -1.0
    x_6_4     disj1_5_6_2  1.0
    x_6_4     disj2_5_6_2  -1.0
    x_6_4     disj1_6_7_2  -1.0
    x_6_4     disj2_6_7_2  1.0
    x_6_4     disj1_6_8_2  -1.0
    x_6_4     disj2_6_8_2  1.0
    x_6_5     prec_6_4  1.0
    x_6_5     prec_6_5  -1.0
    x_6_5     disj1_0_6_6  1.0
    x_6_5     disj2_0_6_6  -1.0
    x_6_5     disj1_1_6_6  1.0
    x_6_5     disj2_1_6_6  -1.0
    x_6_5     disj1_2_6_6  1.0
    x_6_5     disj2_2_6_6  -1.0
    x_6_5     disj1_3_6_6  1.0
    x_6_5     disj2_3_6_6  -1.0
    x_6_5     disj1_4_6_6  1.0
    x_6_5     disj2_4_6_6  -1.0
    x_6_5     disj1_5_6_6  1.0
    x_6_5     disj2_5_6_6  -1.0
    x_6_5     disj1_6_7_6  -1.0
    x_6_5     disj2_6_7_6  1.0
    x_6_5     disj1_6_8_6  -1.0
    x_6_5     disj2_6_8_6  1.0
    x_6_6     prec_6_5  1.0
    x_6_6     mksp_6    -1.0
    x_6_6     disj1_0_6_4  1.0
    x_6_6     disj2_0_6_4  -1.0
    x_6_6     disj1_1_6_4  1.0
    x_6_6     disj2_1_6_4  -1.0
    x_6_6     disj1_2_6_4  1.0
    x_6_6     disj2_2_6_4  -1.0
    x_6_6     disj1_3_6_4  1.0
    x_6_6     disj2_3_6_4  -1.0
    x_6_6     disj1_4_6_4  1.0
    x_6_6     disj2_4_6_4  -1.0
    x_6_6     disj1_5_6_4  1.0
    x_6_6     disj2_5_6_4  -1.0
    x_6_6     disj1_6_7_4  -1.0
    x_6_6     disj2_6_7_4  1.0
    x_6_6     disj1_6_8_4  -1.0
    x_6_6     disj2_6_8_4  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_6  1.0
    x_7_0     disj2_0_7_6  -1.0
    x_7_0     disj1_1_7_6  1.0
    x_7_0     disj2_1_7_6  -1.0
    x_7_0     disj1_2_7_6  1.0
    x_7_0     disj2_2_7_6  -1.0
    x_7_0     disj1_3_7_6  1.0
    x_7_0     disj2_3_7_6  -1.0
    x_7_0     disj1_4_7_6  1.0
    x_7_0     disj2_4_7_6  -1.0
    x_7_0     disj1_5_7_6  1.0
    x_7_0     disj2_5_7_6  -1.0
    x_7_0     disj1_6_7_6  1.0
    x_7_0     disj2_6_7_6  -1.0
    x_7_0     disj1_7_8_6  -1.0
    x_7_0     disj2_7_8_6  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_4  1.0
    x_7_1     disj2_0_7_4  -1.0
    x_7_1     disj1_1_7_4  1.0
    x_7_1     disj2_1_7_4  -1.0
    x_7_1     disj1_2_7_4  1.0
    x_7_1     disj2_2_7_4  -1.0
    x_7_1     disj1_3_7_4  1.0
    x_7_1     disj2_3_7_4  -1.0
    x_7_1     disj1_4_7_4  1.0
    x_7_1     disj2_4_7_4  -1.0
    x_7_1     disj1_5_7_4  1.0
    x_7_1     disj2_5_7_4  -1.0
    x_7_1     disj1_6_7_4  1.0
    x_7_1     disj2_6_7_4  -1.0
    x_7_1     disj1_7_8_4  -1.0
    x_7_1     disj2_7_8_4  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_1  1.0
    x_7_2     disj2_0_7_1  -1.0
    x_7_2     disj1_1_7_1  1.0
    x_7_2     disj2_1_7_1  -1.0
    x_7_2     disj1_2_7_1  1.0
    x_7_2     disj2_2_7_1  -1.0
    x_7_2     disj1_3_7_1  1.0
    x_7_2     disj2_3_7_1  -1.0
    x_7_2     disj1_4_7_1  1.0
    x_7_2     disj2_4_7_1  -1.0
    x_7_2     disj1_5_7_1  1.0
    x_7_2     disj2_5_7_1  -1.0
    x_7_2     disj1_6_7_1  1.0
    x_7_2     disj2_6_7_1  -1.0
    x_7_2     disj1_7_8_1  -1.0
    x_7_2     disj2_7_8_1  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_3  1.0
    x_7_3     disj2_0_7_3  -1.0
    x_7_3     disj1_1_7_3  1.0
    x_7_3     disj2_1_7_3  -1.0
    x_7_3     disj1_2_7_3  1.0
    x_7_3     disj2_2_7_3  -1.0
    x_7_3     disj1_3_7_3  1.0
    x_7_3     disj2_3_7_3  -1.0
    x_7_3     disj1_4_7_3  1.0
    x_7_3     disj2_4_7_3  -1.0
    x_7_3     disj1_5_7_3  1.0
    x_7_3     disj2_5_7_3  -1.0
    x_7_3     disj1_6_7_3  1.0
    x_7_3     disj2_6_7_3  -1.0
    x_7_3     disj1_7_8_3  -1.0
    x_7_3     disj2_7_8_3  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     prec_7_4  -1.0
    x_7_4     disj1_0_7_2  1.0
    x_7_4     disj2_0_7_2  -1.0
    x_7_4     disj1_1_7_2  1.0
    x_7_4     disj2_1_7_2  -1.0
    x_7_4     disj1_2_7_2  1.0
    x_7_4     disj2_2_7_2  -1.0
    x_7_4     disj1_3_7_2  1.0
    x_7_4     disj2_3_7_2  -1.0
    x_7_4     disj1_4_7_2  1.0
    x_7_4     disj2_4_7_2  -1.0
    x_7_4     disj1_5_7_2  1.0
    x_7_4     disj2_5_7_2  -1.0
    x_7_4     disj1_6_7_2  1.0
    x_7_4     disj2_6_7_2  -1.0
    x_7_4     disj1_7_8_2  -1.0
    x_7_4     disj2_7_8_2  1.0
    x_7_5     prec_7_4  1.0
    x_7_5     prec_7_5  -1.0
    x_7_5     disj1_0_7_5  1.0
    x_7_5     disj2_0_7_5  -1.0
    x_7_5     disj1_1_7_5  1.0
    x_7_5     disj2_1_7_5  -1.0
    x_7_5     disj1_2_7_5  1.0
    x_7_5     disj2_2_7_5  -1.0
    x_7_5     disj1_3_7_5  1.0
    x_7_5     disj2_3_7_5  -1.0
    x_7_5     disj1_4_7_5  1.0
    x_7_5     disj2_4_7_5  -1.0
    x_7_5     disj1_5_7_5  1.0
    x_7_5     disj2_5_7_5  -1.0
    x_7_5     disj1_6_7_5  1.0
    x_7_5     disj2_6_7_5  -1.0
    x_7_5     disj1_7_8_5  -1.0
    x_7_5     disj2_7_8_5  1.0
    x_7_6     prec_7_5  1.0
    x_7_6     mksp_7    -1.0
    x_7_6     disj1_0_7_0  1.0
    x_7_6     disj2_0_7_0  -1.0
    x_7_6     disj1_1_7_0  1.0
    x_7_6     disj2_1_7_0  -1.0
    x_7_6     disj1_2_7_0  1.0
    x_7_6     disj2_2_7_0  -1.0
    x_7_6     disj1_3_7_0  1.0
    x_7_6     disj2_3_7_0  -1.0
    x_7_6     disj1_4_7_0  1.0
    x_7_6     disj2_4_7_0  -1.0
    x_7_6     disj1_5_7_0  1.0
    x_7_6     disj2_5_7_0  -1.0
    x_7_6     disj1_6_7_0  1.0
    x_7_6     disj2_6_7_0  -1.0
    x_7_6     disj1_7_8_0  -1.0
    x_7_6     disj2_7_8_0  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_0  1.0
    x_8_0     disj2_0_8_0  -1.0
    x_8_0     disj1_1_8_0  1.0
    x_8_0     disj2_1_8_0  -1.0
    x_8_0     disj1_2_8_0  1.0
    x_8_0     disj2_2_8_0  -1.0
    x_8_0     disj1_3_8_0  1.0
    x_8_0     disj2_3_8_0  -1.0
    x_8_0     disj1_4_8_0  1.0
    x_8_0     disj2_4_8_0  -1.0
    x_8_0     disj1_5_8_0  1.0
    x_8_0     disj2_5_8_0  -1.0
    x_8_0     disj1_6_8_0  1.0
    x_8_0     disj2_6_8_0  -1.0
    x_8_0     disj1_7_8_0  1.0
    x_8_0     disj2_7_8_0  -1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_3  1.0
    x_8_1     disj2_0_8_3  -1.0
    x_8_1     disj1_1_8_3  1.0
    x_8_1     disj2_1_8_3  -1.0
    x_8_1     disj1_2_8_3  1.0
    x_8_1     disj2_2_8_3  -1.0
    x_8_1     disj1_3_8_3  1.0
    x_8_1     disj2_3_8_3  -1.0
    x_8_1     disj1_4_8_3  1.0
    x_8_1     disj2_4_8_3  -1.0
    x_8_1     disj1_5_8_3  1.0
    x_8_1     disj2_5_8_3  -1.0
    x_8_1     disj1_6_8_3  1.0
    x_8_1     disj2_6_8_3  -1.0
    x_8_1     disj1_7_8_3  1.0
    x_8_1     disj2_7_8_3  -1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_1  1.0
    x_8_2     disj2_0_8_1  -1.0
    x_8_2     disj1_1_8_1  1.0
    x_8_2     disj2_1_8_1  -1.0
    x_8_2     disj1_2_8_1  1.0
    x_8_2     disj2_2_8_1  -1.0
    x_8_2     disj1_3_8_1  1.0
    x_8_2     disj2_3_8_1  -1.0
    x_8_2     disj1_4_8_1  1.0
    x_8_2     disj2_4_8_1  -1.0
    x_8_2     disj1_5_8_1  1.0
    x_8_2     disj2_5_8_1  -1.0
    x_8_2     disj1_6_8_1  1.0
    x_8_2     disj2_6_8_1  -1.0
    x_8_2     disj1_7_8_1  1.0
    x_8_2     disj2_7_8_1  -1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_5  1.0
    x_8_3     disj2_0_8_5  -1.0
    x_8_3     disj1_1_8_5  1.0
    x_8_3     disj2_1_8_5  -1.0
    x_8_3     disj1_2_8_5  1.0
    x_8_3     disj2_2_8_5  -1.0
    x_8_3     disj1_3_8_5  1.0
    x_8_3     disj2_3_8_5  -1.0
    x_8_3     disj1_4_8_5  1.0
    x_8_3     disj2_4_8_5  -1.0
    x_8_3     disj1_5_8_5  1.0
    x_8_3     disj2_5_8_5  -1.0
    x_8_3     disj1_6_8_5  1.0
    x_8_3     disj2_6_8_5  -1.0
    x_8_3     disj1_7_8_5  1.0
    x_8_3     disj2_7_8_5  -1.0
    x_8_4     prec_8_3  1.0
    x_8_4     prec_8_4  -1.0
    x_8_4     disj1_0_8_4  1.0
    x_8_4     disj2_0_8_4  -1.0
    x_8_4     disj1_1_8_4  1.0
    x_8_4     disj2_1_8_4  -1.0
    x_8_4     disj1_2_8_4  1.0
    x_8_4     disj2_2_8_4  -1.0
    x_8_4     disj1_3_8_4  1.0
    x_8_4     disj2_3_8_4  -1.0
    x_8_4     disj1_4_8_4  1.0
    x_8_4     disj2_4_8_4  -1.0
    x_8_4     disj1_5_8_4  1.0
    x_8_4     disj2_5_8_4  -1.0
    x_8_4     disj1_6_8_4  1.0
    x_8_4     disj2_6_8_4  -1.0
    x_8_4     disj1_7_8_4  1.0
    x_8_4     disj2_7_8_4  -1.0
    x_8_5     prec_8_4  1.0
    x_8_5     prec_8_5  -1.0
    x_8_5     disj1_0_8_6  1.0
    x_8_5     disj2_0_8_6  -1.0
    x_8_5     disj1_1_8_6  1.0
    x_8_5     disj2_1_8_6  -1.0
    x_8_5     disj1_2_8_6  1.0
    x_8_5     disj2_2_8_6  -1.0
    x_8_5     disj1_3_8_6  1.0
    x_8_5     disj2_3_8_6  -1.0
    x_8_5     disj1_4_8_6  1.0
    x_8_5     disj2_4_8_6  -1.0
    x_8_5     disj1_5_8_6  1.0
    x_8_5     disj2_5_8_6  -1.0
    x_8_5     disj1_6_8_6  1.0
    x_8_5     disj2_6_8_6  -1.0
    x_8_5     disj1_7_8_6  1.0
    x_8_5     disj2_7_8_6  -1.0
    x_8_6     prec_8_5  1.0
    x_8_6     mksp_8    -1.0
    x_8_6     disj1_0_8_2  1.0
    x_8_6     disj2_0_8_2  -1.0
    x_8_6     disj1_1_8_2  1.0
    x_8_6     disj2_1_8_2  -1.0
    x_8_6     disj1_2_8_2  1.0
    x_8_6     disj2_2_8_2  -1.0
    x_8_6     disj1_3_8_2  1.0
    x_8_6     disj2_3_8_2  -1.0
    x_8_6     disj1_4_8_2  1.0
    x_8_6     disj2_4_8_2  -1.0
    x_8_6     disj1_5_8_2  1.0
    x_8_6     disj2_5_8_2  -1.0
    x_8_6     disj1_6_8_2  1.0
    x_8_6     disj2_6_8_2  -1.0
    x_8_6     disj1_7_8_2  1.0
    x_8_6     disj2_7_8_2  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  725
    y_0_1_0   disj2_0_1_0  -725
    y_0_1_1   disj1_0_1_1  725
    y_0_1_1   disj2_0_1_1  -725
    y_0_1_2   disj1_0_1_2  725
    y_0_1_2   disj2_0_1_2  -725
    y_0_1_3   disj1_0_1_3  725
    y_0_1_3   disj2_0_1_3  -725
    y_0_1_4   disj1_0_1_4  725
    y_0_1_4   disj2_0_1_4  -725
    y_0_1_5   disj1_0_1_5  725
    y_0_1_5   disj2_0_1_5  -725
    y_0_1_6   disj1_0_1_6  725
    y_0_1_6   disj2_0_1_6  -725
    y_0_2_0   disj1_0_2_0  725
    y_0_2_0   disj2_0_2_0  -725
    y_0_2_1   disj1_0_2_1  725
    y_0_2_1   disj2_0_2_1  -725
    y_0_2_2   disj1_0_2_2  725
    y_0_2_2   disj2_0_2_2  -725
    y_0_2_3   disj1_0_2_3  725
    y_0_2_3   disj2_0_2_3  -725
    y_0_2_4   disj1_0_2_4  725
    y_0_2_4   disj2_0_2_4  -725
    y_0_2_5   disj1_0_2_5  725
    y_0_2_5   disj2_0_2_5  -725
    y_0_2_6   disj1_0_2_6  725
    y_0_2_6   disj2_0_2_6  -725
    y_0_3_0   disj1_0_3_0  725
    y_0_3_0   disj2_0_3_0  -725
    y_0_3_1   disj1_0_3_1  725
    y_0_3_1   disj2_0_3_1  -725
    y_0_3_2   disj1_0_3_2  725
    y_0_3_2   disj2_0_3_2  -725
    y_0_3_3   disj1_0_3_3  725
    y_0_3_3   disj2_0_3_3  -725
    y_0_3_4   disj1_0_3_4  725
    y_0_3_4   disj2_0_3_4  -725
    y_0_3_5   disj1_0_3_5  725
    y_0_3_5   disj2_0_3_5  -725
    y_0_3_6   disj1_0_3_6  725
    y_0_3_6   disj2_0_3_6  -725
    y_0_4_0   disj1_0_4_0  725
    y_0_4_0   disj2_0_4_0  -725
    y_0_4_1   disj1_0_4_1  725
    y_0_4_1   disj2_0_4_1  -725
    y_0_4_2   disj1_0_4_2  725
    y_0_4_2   disj2_0_4_2  -725
    y_0_4_3   disj1_0_4_3  725
    y_0_4_3   disj2_0_4_3  -725
    y_0_4_4   disj1_0_4_4  725
    y_0_4_4   disj2_0_4_4  -725
    y_0_4_5   disj1_0_4_5  725
    y_0_4_5   disj2_0_4_5  -725
    y_0_4_6   disj1_0_4_6  725
    y_0_4_6   disj2_0_4_6  -725
    y_0_5_0   disj1_0_5_0  725
    y_0_5_0   disj2_0_5_0  -725
    y_0_5_1   disj1_0_5_1  725
    y_0_5_1   disj2_0_5_1  -725
    y_0_5_2   disj1_0_5_2  725
    y_0_5_2   disj2_0_5_2  -725
    y_0_5_3   disj1_0_5_3  725
    y_0_5_3   disj2_0_5_3  -725
    y_0_5_4   disj1_0_5_4  725
    y_0_5_4   disj2_0_5_4  -725
    y_0_5_5   disj1_0_5_5  725
    y_0_5_5   disj2_0_5_5  -725
    y_0_5_6   disj1_0_5_6  725
    y_0_5_6   disj2_0_5_6  -725
    y_0_6_0   disj1_0_6_0  725
    y_0_6_0   disj2_0_6_0  -725
    y_0_6_1   disj1_0_6_1  725
    y_0_6_1   disj2_0_6_1  -725
    y_0_6_2   disj1_0_6_2  725
    y_0_6_2   disj2_0_6_2  -725
    y_0_6_3   disj1_0_6_3  725
    y_0_6_3   disj2_0_6_3  -725
    y_0_6_4   disj1_0_6_4  725
    y_0_6_4   disj2_0_6_4  -725
    y_0_6_5   disj1_0_6_5  725
    y_0_6_5   disj2_0_6_5  -725
    y_0_6_6   disj1_0_6_6  725
    y_0_6_6   disj2_0_6_6  -725
    y_0_7_0   disj1_0_7_0  725
    y_0_7_0   disj2_0_7_0  -725
    y_0_7_1   disj1_0_7_1  725
    y_0_7_1   disj2_0_7_1  -725
    y_0_7_2   disj1_0_7_2  725
    y_0_7_2   disj2_0_7_2  -725
    y_0_7_3   disj1_0_7_3  725
    y_0_7_3   disj2_0_7_3  -725
    y_0_7_4   disj1_0_7_4  725
    y_0_7_4   disj2_0_7_4  -725
    y_0_7_5   disj1_0_7_5  725
    y_0_7_5   disj2_0_7_5  -725
    y_0_7_6   disj1_0_7_6  725
    y_0_7_6   disj2_0_7_6  -725
    y_0_8_0   disj1_0_8_0  725
    y_0_8_0   disj2_0_8_0  -725
    y_0_8_1   disj1_0_8_1  725
    y_0_8_1   disj2_0_8_1  -725
    y_0_8_2   disj1_0_8_2  725
    y_0_8_2   disj2_0_8_2  -725
    y_0_8_3   disj1_0_8_3  725
    y_0_8_3   disj2_0_8_3  -725
    y_0_8_4   disj1_0_8_4  725
    y_0_8_4   disj2_0_8_4  -725
    y_0_8_5   disj1_0_8_5  725
    y_0_8_5   disj2_0_8_5  -725
    y_0_8_6   disj1_0_8_6  725
    y_0_8_6   disj2_0_8_6  -725
    y_1_2_0   disj1_1_2_0  725
    y_1_2_0   disj2_1_2_0  -725
    y_1_2_1   disj1_1_2_1  725
    y_1_2_1   disj2_1_2_1  -725
    y_1_2_2   disj1_1_2_2  725
    y_1_2_2   disj2_1_2_2  -725
    y_1_2_3   disj1_1_2_3  725
    y_1_2_3   disj2_1_2_3  -725
    y_1_2_4   disj1_1_2_4  725
    y_1_2_4   disj2_1_2_4  -725
    y_1_2_5   disj1_1_2_5  725
    y_1_2_5   disj2_1_2_5  -725
    y_1_2_6   disj1_1_2_6  725
    y_1_2_6   disj2_1_2_6  -725
    y_1_3_0   disj1_1_3_0  725
    y_1_3_0   disj2_1_3_0  -725
    y_1_3_1   disj1_1_3_1  725
    y_1_3_1   disj2_1_3_1  -725
    y_1_3_2   disj1_1_3_2  725
    y_1_3_2   disj2_1_3_2  -725
    y_1_3_3   disj1_1_3_3  725
    y_1_3_3   disj2_1_3_3  -725
    y_1_3_4   disj1_1_3_4  725
    y_1_3_4   disj2_1_3_4  -725
    y_1_3_5   disj1_1_3_5  725
    y_1_3_5   disj2_1_3_5  -725
    y_1_3_6   disj1_1_3_6  725
    y_1_3_6   disj2_1_3_6  -725
    y_1_4_0   disj1_1_4_0  725
    y_1_4_0   disj2_1_4_0  -725
    y_1_4_1   disj1_1_4_1  725
    y_1_4_1   disj2_1_4_1  -725
    y_1_4_2   disj1_1_4_2  725
    y_1_4_2   disj2_1_4_2  -725
    y_1_4_3   disj1_1_4_3  725
    y_1_4_3   disj2_1_4_3  -725
    y_1_4_4   disj1_1_4_4  725
    y_1_4_4   disj2_1_4_4  -725
    y_1_4_5   disj1_1_4_5  725
    y_1_4_5   disj2_1_4_5  -725
    y_1_4_6   disj1_1_4_6  725
    y_1_4_6   disj2_1_4_6  -725
    y_1_5_0   disj1_1_5_0  725
    y_1_5_0   disj2_1_5_0  -725
    y_1_5_1   disj1_1_5_1  725
    y_1_5_1   disj2_1_5_1  -725
    y_1_5_2   disj1_1_5_2  725
    y_1_5_2   disj2_1_5_2  -725
    y_1_5_3   disj1_1_5_3  725
    y_1_5_3   disj2_1_5_3  -725
    y_1_5_4   disj1_1_5_4  725
    y_1_5_4   disj2_1_5_4  -725
    y_1_5_5   disj1_1_5_5  725
    y_1_5_5   disj2_1_5_5  -725
    y_1_5_6   disj1_1_5_6  725
    y_1_5_6   disj2_1_5_6  -725
    y_1_6_0   disj1_1_6_0  725
    y_1_6_0   disj2_1_6_0  -725
    y_1_6_1   disj1_1_6_1  725
    y_1_6_1   disj2_1_6_1  -725
    y_1_6_2   disj1_1_6_2  725
    y_1_6_2   disj2_1_6_2  -725
    y_1_6_3   disj1_1_6_3  725
    y_1_6_3   disj2_1_6_3  -725
    y_1_6_4   disj1_1_6_4  725
    y_1_6_4   disj2_1_6_4  -725
    y_1_6_5   disj1_1_6_5  725
    y_1_6_5   disj2_1_6_5  -725
    y_1_6_6   disj1_1_6_6  725
    y_1_6_6   disj2_1_6_6  -725
    y_1_7_0   disj1_1_7_0  725
    y_1_7_0   disj2_1_7_0  -725
    y_1_7_1   disj1_1_7_1  725
    y_1_7_1   disj2_1_7_1  -725
    y_1_7_2   disj1_1_7_2  725
    y_1_7_2   disj2_1_7_2  -725
    y_1_7_3   disj1_1_7_3  725
    y_1_7_3   disj2_1_7_3  -725
    y_1_7_4   disj1_1_7_4  725
    y_1_7_4   disj2_1_7_4  -725
    y_1_7_5   disj1_1_7_5  725
    y_1_7_5   disj2_1_7_5  -725
    y_1_7_6   disj1_1_7_6  725
    y_1_7_6   disj2_1_7_6  -725
    y_1_8_0   disj1_1_8_0  725
    y_1_8_0   disj2_1_8_0  -725
    y_1_8_1   disj1_1_8_1  725
    y_1_8_1   disj2_1_8_1  -725
    y_1_8_2   disj1_1_8_2  725
    y_1_8_2   disj2_1_8_2  -725
    y_1_8_3   disj1_1_8_3  725
    y_1_8_3   disj2_1_8_3  -725
    y_1_8_4   disj1_1_8_4  725
    y_1_8_4   disj2_1_8_4  -725
    y_1_8_5   disj1_1_8_5  725
    y_1_8_5   disj2_1_8_5  -725
    y_1_8_6   disj1_1_8_6  725
    y_1_8_6   disj2_1_8_6  -725
    y_2_3_0   disj1_2_3_0  725
    y_2_3_0   disj2_2_3_0  -725
    y_2_3_1   disj1_2_3_1  725
    y_2_3_1   disj2_2_3_1  -725
    y_2_3_2   disj1_2_3_2  725
    y_2_3_2   disj2_2_3_2  -725
    y_2_3_3   disj1_2_3_3  725
    y_2_3_3   disj2_2_3_3  -725
    y_2_3_4   disj1_2_3_4  725
    y_2_3_4   disj2_2_3_4  -725
    y_2_3_5   disj1_2_3_5  725
    y_2_3_5   disj2_2_3_5  -725
    y_2_3_6   disj1_2_3_6  725
    y_2_3_6   disj2_2_3_6  -725
    y_2_4_0   disj1_2_4_0  725
    y_2_4_0   disj2_2_4_0  -725
    y_2_4_1   disj1_2_4_1  725
    y_2_4_1   disj2_2_4_1  -725
    y_2_4_2   disj1_2_4_2  725
    y_2_4_2   disj2_2_4_2  -725
    y_2_4_3   disj1_2_4_3  725
    y_2_4_3   disj2_2_4_3  -725
    y_2_4_4   disj1_2_4_4  725
    y_2_4_4   disj2_2_4_4  -725
    y_2_4_5   disj1_2_4_5  725
    y_2_4_5   disj2_2_4_5  -725
    y_2_4_6   disj1_2_4_6  725
    y_2_4_6   disj2_2_4_6  -725
    y_2_5_0   disj1_2_5_0  725
    y_2_5_0   disj2_2_5_0  -725
    y_2_5_1   disj1_2_5_1  725
    y_2_5_1   disj2_2_5_1  -725
    y_2_5_2   disj1_2_5_2  725
    y_2_5_2   disj2_2_5_2  -725
    y_2_5_3   disj1_2_5_3  725
    y_2_5_3   disj2_2_5_3  -725
    y_2_5_4   disj1_2_5_4  725
    y_2_5_4   disj2_2_5_4  -725
    y_2_5_5   disj1_2_5_5  725
    y_2_5_5   disj2_2_5_5  -725
    y_2_5_6   disj1_2_5_6  725
    y_2_5_6   disj2_2_5_6  -725
    y_2_6_0   disj1_2_6_0  725
    y_2_6_0   disj2_2_6_0  -725
    y_2_6_1   disj1_2_6_1  725
    y_2_6_1   disj2_2_6_1  -725
    y_2_6_2   disj1_2_6_2  725
    y_2_6_2   disj2_2_6_2  -725
    y_2_6_3   disj1_2_6_3  725
    y_2_6_3   disj2_2_6_3  -725
    y_2_6_4   disj1_2_6_4  725
    y_2_6_4   disj2_2_6_4  -725
    y_2_6_5   disj1_2_6_5  725
    y_2_6_5   disj2_2_6_5  -725
    y_2_6_6   disj1_2_6_6  725
    y_2_6_6   disj2_2_6_6  -725
    y_2_7_0   disj1_2_7_0  725
    y_2_7_0   disj2_2_7_0  -725
    y_2_7_1   disj1_2_7_1  725
    y_2_7_1   disj2_2_7_1  -725
    y_2_7_2   disj1_2_7_2  725
    y_2_7_2   disj2_2_7_2  -725
    y_2_7_3   disj1_2_7_3  725
    y_2_7_3   disj2_2_7_3  -725
    y_2_7_4   disj1_2_7_4  725
    y_2_7_4   disj2_2_7_4  -725
    y_2_7_5   disj1_2_7_5  725
    y_2_7_5   disj2_2_7_5  -725
    y_2_7_6   disj1_2_7_6  725
    y_2_7_6   disj2_2_7_6  -725
    y_2_8_0   disj1_2_8_0  725
    y_2_8_0   disj2_2_8_0  -725
    y_2_8_1   disj1_2_8_1  725
    y_2_8_1   disj2_2_8_1  -725
    y_2_8_2   disj1_2_8_2  725
    y_2_8_2   disj2_2_8_2  -725
    y_2_8_3   disj1_2_8_3  725
    y_2_8_3   disj2_2_8_3  -725
    y_2_8_4   disj1_2_8_4  725
    y_2_8_4   disj2_2_8_4  -725
    y_2_8_5   disj1_2_8_5  725
    y_2_8_5   disj2_2_8_5  -725
    y_2_8_6   disj1_2_8_6  725
    y_2_8_6   disj2_2_8_6  -725
    y_3_4_0   disj1_3_4_0  725
    y_3_4_0   disj2_3_4_0  -725
    y_3_4_1   disj1_3_4_1  725
    y_3_4_1   disj2_3_4_1  -725
    y_3_4_2   disj1_3_4_2  725
    y_3_4_2   disj2_3_4_2  -725
    y_3_4_3   disj1_3_4_3  725
    y_3_4_3   disj2_3_4_3  -725
    y_3_4_4   disj1_3_4_4  725
    y_3_4_4   disj2_3_4_4  -725
    y_3_4_5   disj1_3_4_5  725
    y_3_4_5   disj2_3_4_5  -725
    y_3_4_6   disj1_3_4_6  725
    y_3_4_6   disj2_3_4_6  -725
    y_3_5_0   disj1_3_5_0  725
    y_3_5_0   disj2_3_5_0  -725
    y_3_5_1   disj1_3_5_1  725
    y_3_5_1   disj2_3_5_1  -725
    y_3_5_2   disj1_3_5_2  725
    y_3_5_2   disj2_3_5_2  -725
    y_3_5_3   disj1_3_5_3  725
    y_3_5_3   disj2_3_5_3  -725
    y_3_5_4   disj1_3_5_4  725
    y_3_5_4   disj2_3_5_4  -725
    y_3_5_5   disj1_3_5_5  725
    y_3_5_5   disj2_3_5_5  -725
    y_3_5_6   disj1_3_5_6  725
    y_3_5_6   disj2_3_5_6  -725
    y_3_6_0   disj1_3_6_0  725
    y_3_6_0   disj2_3_6_0  -725
    y_3_6_1   disj1_3_6_1  725
    y_3_6_1   disj2_3_6_1  -725
    y_3_6_2   disj1_3_6_2  725
    y_3_6_2   disj2_3_6_2  -725
    y_3_6_3   disj1_3_6_3  725
    y_3_6_3   disj2_3_6_3  -725
    y_3_6_4   disj1_3_6_4  725
    y_3_6_4   disj2_3_6_4  -725
    y_3_6_5   disj1_3_6_5  725
    y_3_6_5   disj2_3_6_5  -725
    y_3_6_6   disj1_3_6_6  725
    y_3_6_6   disj2_3_6_6  -725
    y_3_7_0   disj1_3_7_0  725
    y_3_7_0   disj2_3_7_0  -725
    y_3_7_1   disj1_3_7_1  725
    y_3_7_1   disj2_3_7_1  -725
    y_3_7_2   disj1_3_7_2  725
    y_3_7_2   disj2_3_7_2  -725
    y_3_7_3   disj1_3_7_3  725
    y_3_7_3   disj2_3_7_3  -725
    y_3_7_4   disj1_3_7_4  725
    y_3_7_4   disj2_3_7_4  -725
    y_3_7_5   disj1_3_7_5  725
    y_3_7_5   disj2_3_7_5  -725
    y_3_7_6   disj1_3_7_6  725
    y_3_7_6   disj2_3_7_6  -725
    y_3_8_0   disj1_3_8_0  725
    y_3_8_0   disj2_3_8_0  -725
    y_3_8_1   disj1_3_8_1  725
    y_3_8_1   disj2_3_8_1  -725
    y_3_8_2   disj1_3_8_2  725
    y_3_8_2   disj2_3_8_2  -725
    y_3_8_3   disj1_3_8_3  725
    y_3_8_3   disj2_3_8_3  -725
    y_3_8_4   disj1_3_8_4  725
    y_3_8_4   disj2_3_8_4  -725
    y_3_8_5   disj1_3_8_5  725
    y_3_8_5   disj2_3_8_5  -725
    y_3_8_6   disj1_3_8_6  725
    y_3_8_6   disj2_3_8_6  -725
    y_4_5_0   disj1_4_5_0  725
    y_4_5_0   disj2_4_5_0  -725
    y_4_5_1   disj1_4_5_1  725
    y_4_5_1   disj2_4_5_1  -725
    y_4_5_2   disj1_4_5_2  725
    y_4_5_2   disj2_4_5_2  -725
    y_4_5_3   disj1_4_5_3  725
    y_4_5_3   disj2_4_5_3  -725
    y_4_5_4   disj1_4_5_4  725
    y_4_5_4   disj2_4_5_4  -725
    y_4_5_5   disj1_4_5_5  725
    y_4_5_5   disj2_4_5_5  -725
    y_4_5_6   disj1_4_5_6  725
    y_4_5_6   disj2_4_5_6  -725
    y_4_6_0   disj1_4_6_0  725
    y_4_6_0   disj2_4_6_0  -725
    y_4_6_1   disj1_4_6_1  725
    y_4_6_1   disj2_4_6_1  -725
    y_4_6_2   disj1_4_6_2  725
    y_4_6_2   disj2_4_6_2  -725
    y_4_6_3   disj1_4_6_3  725
    y_4_6_3   disj2_4_6_3  -725
    y_4_6_4   disj1_4_6_4  725
    y_4_6_4   disj2_4_6_4  -725
    y_4_6_5   disj1_4_6_5  725
    y_4_6_5   disj2_4_6_5  -725
    y_4_6_6   disj1_4_6_6  725
    y_4_6_6   disj2_4_6_6  -725
    y_4_7_0   disj1_4_7_0  725
    y_4_7_0   disj2_4_7_0  -725
    y_4_7_1   disj1_4_7_1  725
    y_4_7_1   disj2_4_7_1  -725
    y_4_7_2   disj1_4_7_2  725
    y_4_7_2   disj2_4_7_2  -725
    y_4_7_3   disj1_4_7_3  725
    y_4_7_3   disj2_4_7_3  -725
    y_4_7_4   disj1_4_7_4  725
    y_4_7_4   disj2_4_7_4  -725
    y_4_7_5   disj1_4_7_5  725
    y_4_7_5   disj2_4_7_5  -725
    y_4_7_6   disj1_4_7_6  725
    y_4_7_6   disj2_4_7_6  -725
    y_4_8_0   disj1_4_8_0  725
    y_4_8_0   disj2_4_8_0  -725
    y_4_8_1   disj1_4_8_1  725
    y_4_8_1   disj2_4_8_1  -725
    y_4_8_2   disj1_4_8_2  725
    y_4_8_2   disj2_4_8_2  -725
    y_4_8_3   disj1_4_8_3  725
    y_4_8_3   disj2_4_8_3  -725
    y_4_8_4   disj1_4_8_4  725
    y_4_8_4   disj2_4_8_4  -725
    y_4_8_5   disj1_4_8_5  725
    y_4_8_5   disj2_4_8_5  -725
    y_4_8_6   disj1_4_8_6  725
    y_4_8_6   disj2_4_8_6  -725
    y_5_6_0   disj1_5_6_0  725
    y_5_6_0   disj2_5_6_0  -725
    y_5_6_1   disj1_5_6_1  725
    y_5_6_1   disj2_5_6_1  -725
    y_5_6_2   disj1_5_6_2  725
    y_5_6_2   disj2_5_6_2  -725
    y_5_6_3   disj1_5_6_3  725
    y_5_6_3   disj2_5_6_3  -725
    y_5_6_4   disj1_5_6_4  725
    y_5_6_4   disj2_5_6_4  -725
    y_5_6_5   disj1_5_6_5  725
    y_5_6_5   disj2_5_6_5  -725
    y_5_6_6   disj1_5_6_6  725
    y_5_6_6   disj2_5_6_6  -725
    y_5_7_0   disj1_5_7_0  725
    y_5_7_0   disj2_5_7_0  -725
    y_5_7_1   disj1_5_7_1  725
    y_5_7_1   disj2_5_7_1  -725
    y_5_7_2   disj1_5_7_2  725
    y_5_7_2   disj2_5_7_2  -725
    y_5_7_3   disj1_5_7_3  725
    y_5_7_3   disj2_5_7_3  -725
    y_5_7_4   disj1_5_7_4  725
    y_5_7_4   disj2_5_7_4  -725
    y_5_7_5   disj1_5_7_5  725
    y_5_7_5   disj2_5_7_5  -725
    y_5_7_6   disj1_5_7_6  725
    y_5_7_6   disj2_5_7_6  -725
    y_5_8_0   disj1_5_8_0  725
    y_5_8_0   disj2_5_8_0  -725
    y_5_8_1   disj1_5_8_1  725
    y_5_8_1   disj2_5_8_1  -725
    y_5_8_2   disj1_5_8_2  725
    y_5_8_2   disj2_5_8_2  -725
    y_5_8_3   disj1_5_8_3  725
    y_5_8_3   disj2_5_8_3  -725
    y_5_8_4   disj1_5_8_4  725
    y_5_8_4   disj2_5_8_4  -725
    y_5_8_5   disj1_5_8_5  725
    y_5_8_5   disj2_5_8_5  -725
    y_5_8_6   disj1_5_8_6  725
    y_5_8_6   disj2_5_8_6  -725
    y_6_7_0   disj1_6_7_0  725
    y_6_7_0   disj2_6_7_0  -725
    y_6_7_1   disj1_6_7_1  725
    y_6_7_1   disj2_6_7_1  -725
    y_6_7_2   disj1_6_7_2  725
    y_6_7_2   disj2_6_7_2  -725
    y_6_7_3   disj1_6_7_3  725
    y_6_7_3   disj2_6_7_3  -725
    y_6_7_4   disj1_6_7_4  725
    y_6_7_4   disj2_6_7_4  -725
    y_6_7_5   disj1_6_7_5  725
    y_6_7_5   disj2_6_7_5  -725
    y_6_7_6   disj1_6_7_6  725
    y_6_7_6   disj2_6_7_6  -725
    y_6_8_0   disj1_6_8_0  725
    y_6_8_0   disj2_6_8_0  -725
    y_6_8_1   disj1_6_8_1  725
    y_6_8_1   disj2_6_8_1  -725
    y_6_8_2   disj1_6_8_2  725
    y_6_8_2   disj2_6_8_2  -725
    y_6_8_3   disj1_6_8_3  725
    y_6_8_3   disj2_6_8_3  -725
    y_6_8_4   disj1_6_8_4  725
    y_6_8_4   disj2_6_8_4  -725
    y_6_8_5   disj1_6_8_5  725
    y_6_8_5   disj2_6_8_5  -725
    y_6_8_6   disj1_6_8_6  725
    y_6_8_6   disj2_6_8_6  -725
    y_7_8_0   disj1_7_8_0  725
    y_7_8_0   disj2_7_8_0  -725
    y_7_8_1   disj1_7_8_1  725
    y_7_8_1   disj2_7_8_1  -725
    y_7_8_2   disj1_7_8_2  725
    y_7_8_2   disj2_7_8_2  -725
    y_7_8_3   disj1_7_8_3  725
    y_7_8_3   disj2_7_8_3  -725
    y_7_8_4   disj1_7_8_4  725
    y_7_8_4   disj2_7_8_4  -725
    y_7_8_5   disj1_7_8_5  725
    y_7_8_5   disj2_7_8_5  -725
    y_7_8_6   disj1_7_8_6  725
    y_7_8_6   disj2_7_8_6  -725
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  2
    RHS       prec_0_1  8
    RHS       prec_0_2  4
    RHS       prec_0_3  50
    RHS       prec_0_4  9
    RHS       prec_0_5  3
    RHS       prec_1_0  57
    RHS       prec_1_1  21
    RHS       prec_1_2  5
    RHS       prec_1_3  7
    RHS       prec_1_4  7
    RHS       prec_1_5  10
    RHS       prec_2_0  7
    RHS       prec_2_1  5
    RHS       prec_2_2  7
    RHS       prec_2_3  9
    RHS       prec_2_4  10
    RHS       prec_2_5  6
    RHS       prec_3_0  10
    RHS       prec_3_1  4
    RHS       prec_3_2  10
    RHS       prec_3_3  2
    RHS       prec_3_4  60
    RHS       prec_3_5  2
    RHS       prec_4_0  1
    RHS       prec_4_1  1
    RHS       prec_4_2  10
    RHS       prec_4_3  5
    RHS       prec_4_4  1
    RHS       prec_4_5  2
    RHS       prec_5_0  22
    RHS       prec_5_1  6
    RHS       prec_5_2  3
    RHS       prec_5_3  7
    RHS       prec_5_4  9
    RHS       prec_5_5  10
    RHS       prec_6_0  7
    RHS       prec_6_1  9
    RHS       prec_6_2  6
    RHS       prec_6_3  46
    RHS       prec_6_4  6
    RHS       prec_6_5  59
    RHS       prec_7_0  5
    RHS       prec_7_1  1
    RHS       prec_7_2  1
    RHS       prec_7_3  5
    RHS       prec_7_4  5
    RHS       prec_7_5  6
    RHS       prec_8_0  21
    RHS       prec_8_1  3
    RHS       prec_8_2  4
    RHS       prec_8_3  5
    RHS       prec_8_4  3
    RHS       prec_8_5  2
    RHS       mksp_0    3
    RHS       mksp_1    3
    RHS       mksp_2    1
    RHS       mksp_3    2
    RHS       mksp_4    54
    RHS       mksp_5    2
    RHS       mksp_6    3
    RHS       mksp_7    31
    RHS       mksp_8    40
    RHS       disj1_0_1_0  2
    RHS       disj2_0_1_0  -718
    RHS       disj1_0_2_0  2
    RHS       disj2_0_2_0  -719
    RHS       disj1_0_3_0  2
    RHS       disj2_0_3_0  -715
    RHS       disj1_0_4_0  2
    RHS       disj2_0_4_0  -724
    RHS       disj1_0_5_0  2
    RHS       disj2_0_5_0  -723
    RHS       disj1_0_6_0  2
    RHS       disj2_0_6_0  -716
    RHS       disj1_0_7_0  2
    RHS       disj2_0_7_0  -694
    RHS       disj1_0_8_0  2
    RHS       disj2_0_8_0  -704
    RHS       disj1_1_2_0  7
    RHS       disj2_1_2_0  -719
    RHS       disj1_1_3_0  7
    RHS       disj2_1_3_0  -715
    RHS       disj1_1_4_0  7
    RHS       disj2_1_4_0  -724
    RHS       disj1_1_5_0  7
    RHS       disj2_1_5_0  -723
    RHS       disj1_1_6_0  7
    RHS       disj2_1_6_0  -716
    RHS       disj1_1_7_0  7
    RHS       disj2_1_7_0  -694
    RHS       disj1_1_8_0  7
    RHS       disj2_1_8_0  -704
    RHS       disj1_2_3_0  6
    RHS       disj2_2_3_0  -715
    RHS       disj1_2_4_0  6
    RHS       disj2_2_4_0  -724
    RHS       disj1_2_5_0  6
    RHS       disj2_2_5_0  -723
    RHS       disj1_2_6_0  6
    RHS       disj2_2_6_0  -716
    RHS       disj1_2_7_0  6
    RHS       disj2_2_7_0  -694
    RHS       disj1_2_8_0  6
    RHS       disj2_2_8_0  -704
    RHS       disj1_3_4_0  10
    RHS       disj2_3_4_0  -724
    RHS       disj1_3_5_0  10
    RHS       disj2_3_5_0  -723
    RHS       disj1_3_6_0  10
    RHS       disj2_3_6_0  -716
    RHS       disj1_3_7_0  10
    RHS       disj2_3_7_0  -694
    RHS       disj1_3_8_0  10
    RHS       disj2_3_8_0  -704
    RHS       disj1_4_5_0  1
    RHS       disj2_4_5_0  -723
    RHS       disj1_4_6_0  1
    RHS       disj2_4_6_0  -716
    RHS       disj1_4_7_0  1
    RHS       disj2_4_7_0  -694
    RHS       disj1_4_8_0  1
    RHS       disj2_4_8_0  -704
    RHS       disj1_5_6_0  2
    RHS       disj2_5_6_0  -716
    RHS       disj1_5_7_0  2
    RHS       disj2_5_7_0  -694
    RHS       disj1_5_8_0  2
    RHS       disj2_5_8_0  -704
    RHS       disj1_6_7_0  9
    RHS       disj2_6_7_0  -694
    RHS       disj1_6_8_0  9
    RHS       disj2_6_8_0  -704
    RHS       disj1_7_8_0  31
    RHS       disj2_7_8_0  -704
    RHS       disj1_0_1_1  3
    RHS       disj2_0_1_1  -668
    RHS       disj1_0_2_1  3
    RHS       disj2_0_2_1  -716
    RHS       disj1_0_3_1  3
    RHS       disj2_0_3_1  -723
    RHS       disj1_0_4_1  3
    RHS       disj2_0_4_1  -723
    RHS       disj1_0_5_1  3
    RHS       disj2_0_5_1  -715
    RHS       disj1_0_6_1  3
    RHS       disj2_0_6_1  -718
    RHS       disj1_0_7_1  3
    RHS       disj2_0_7_1  -724
    RHS       disj1_0_8_1  3
    RHS       disj2_0_8_1  -721
    RHS       disj1_1_2_1  57
    RHS       disj2_1_2_1  -716
    RHS       disj1_1_3_1  57
    RHS       disj2_1_3_1  -723
    RHS       disj1_1_4_1  57
    RHS       disj2_1_4_1  -723
    RHS       disj1_1_5_1  57
    RHS       disj2_1_5_1  -715
    RHS       disj1_1_6_1  57
    RHS       disj2_1_6_1  -718
    RHS       disj1_1_7_1  57
    RHS       disj2_1_7_1  -724
    RHS       disj1_1_8_1  57
    RHS       disj2_1_8_1  -721
    RHS       disj1_2_3_1  9
    RHS       disj2_2_3_1  -723
    RHS       disj1_2_4_1  9
    RHS       disj2_2_4_1  -723
    RHS       disj1_2_5_1  9
    RHS       disj2_2_5_1  -715
    RHS       disj1_2_6_1  9
    RHS       disj2_2_6_1  -718
    RHS       disj1_2_7_1  9
    RHS       disj2_2_7_1  -724
    RHS       disj1_2_8_1  9
    RHS       disj2_2_8_1  -721
    RHS       disj1_3_4_1  2
    RHS       disj2_3_4_1  -723
    RHS       disj1_3_5_1  2
    RHS       disj2_3_5_1  -715
    RHS       disj1_3_6_1  2
    RHS       disj2_3_6_1  -718
    RHS       disj1_3_7_1  2
    RHS       disj2_3_7_1  -724
    RHS       disj1_3_8_1  2
    RHS       disj2_3_8_1  -721
    RHS       disj1_4_5_1  2
    RHS       disj2_4_5_1  -715
    RHS       disj1_4_6_1  2
    RHS       disj2_4_6_1  -718
    RHS       disj1_4_7_1  2
    RHS       disj2_4_7_1  -724
    RHS       disj1_4_8_1  2
    RHS       disj2_4_8_1  -721
    RHS       disj1_5_6_1  10
    RHS       disj2_5_6_1  -718
    RHS       disj1_5_7_1  10
    RHS       disj2_5_7_1  -724
    RHS       disj1_5_8_1  10
    RHS       disj2_5_8_1  -721
    RHS       disj1_6_7_1  7
    RHS       disj2_6_7_1  -724
    RHS       disj1_6_8_1  7
    RHS       disj2_6_8_1  -721
    RHS       disj1_7_8_1  1
    RHS       disj2_7_8_1  -721
    RHS       disj1_0_1_2  8
    RHS       disj2_0_1_2  -720
    RHS       disj1_0_2_2  8
    RHS       disj2_0_2_2  -724
    RHS       disj1_0_3_2  8
    RHS       disj2_0_3_2  -723
    RHS       disj1_0_4_2  8
    RHS       disj2_0_4_2  -720
    RHS       disj1_0_5_2  8
    RHS       disj2_0_5_2  -718
    RHS       disj1_0_6_2  8
    RHS       disj2_0_6_2  -719
    RHS       disj1_0_7_2  8
    RHS       disj2_0_7_2  -720
    RHS       disj1_0_8_2  8
    RHS       disj2_0_8_2  -685
    RHS       disj1_1_2_2  5
    RHS       disj2_1_2_2  -724
    RHS       disj1_1_3_2  5
    RHS       disj2_1_3_2  -723
    RHS       disj1_1_4_2  5
    RHS       disj2_1_4_2  -720
    RHS       disj1_1_5_2  5
    RHS       disj2_1_5_2  -718
    RHS       disj1_1_6_2  5
    RHS       disj2_1_6_2  -719
    RHS       disj1_1_7_2  5
    RHS       disj2_1_7_2  -720
    RHS       disj1_1_8_2  5
    RHS       disj2_1_8_2  -685
    RHS       disj1_2_3_2  1
    RHS       disj2_2_3_2  -723
    RHS       disj1_2_4_2  1
    RHS       disj2_2_4_2  -720
    RHS       disj1_2_5_2  1
    RHS       disj2_2_5_2  -718
    RHS       disj1_2_6_2  1
    RHS       disj2_2_6_2  -719
    RHS       disj1_2_7_2  1
    RHS       disj2_2_7_2  -720
    RHS       disj1_2_8_2  1
    RHS       disj2_2_8_2  -685
    RHS       disj1_3_4_2  2
    RHS       disj2_3_4_2  -720
    RHS       disj1_3_5_2  2
    RHS       disj2_3_5_2  -718
    RHS       disj1_3_6_2  2
    RHS       disj2_3_6_2  -719
    RHS       disj1_3_7_2  2
    RHS       disj2_3_7_2  -720
    RHS       disj1_3_8_2  2
    RHS       disj2_3_8_2  -685
    RHS       disj1_4_5_2  5
    RHS       disj2_4_5_2  -718
    RHS       disj1_4_6_2  5
    RHS       disj2_4_6_2  -719
    RHS       disj1_4_7_2  5
    RHS       disj2_4_7_2  -720
    RHS       disj1_4_8_2  5
    RHS       disj2_4_8_2  -685
    RHS       disj1_5_6_2  7
    RHS       disj2_5_6_2  -719
    RHS       disj1_5_7_2  7
    RHS       disj2_5_7_2  -720
    RHS       disj1_5_8_2  7
    RHS       disj2_5_8_2  -685
    RHS       disj1_6_7_2  6
    RHS       disj2_6_7_2  -720
    RHS       disj1_6_8_2  6
    RHS       disj2_6_8_2  -685
    RHS       disj1_7_8_2  5
    RHS       disj2_7_8_2  -685
    RHS       disj1_0_1_3  4
    RHS       disj2_0_1_3  -718
    RHS       disj1_0_2_3  4
    RHS       disj2_0_2_3  -718
    RHS       disj1_0_3_3  4
    RHS       disj2_0_3_3  -721
    RHS       disj1_0_4_3  4
    RHS       disj2_0_4_3  -671
    RHS       disj1_0_5_3  4
    RHS       disj2_0_5_3  -716
    RHS       disj1_0_6_3  4
    RHS       disj2_0_6_3  -679
    RHS       disj1_0_7_3  4
    RHS       disj2_0_7_3  -720
    RHS       disj1_0_8_3  4
    RHS       disj2_0_8_3  -722
    RHS       disj1_1_2_3  7
    RHS       disj2_1_2_3  -718
    RHS       disj1_1_3_3  7
    RHS       disj2_1_3_3  -721
    RHS       disj1_1_4_3  7
    RHS       disj2_1_4_3  -671
    RHS       disj1_1_5_3  7
    RHS       disj2_1_5_3  -716
    RHS       disj1_1_6_3  7
    RHS       disj2_1_6_3  -679
    RHS       disj1_1_7_3  7
    RHS       disj2_1_7_3  -720
    RHS       disj1_1_8_3  7
    RHS       disj2_1_8_3  -722
    RHS       disj1_2_3_3  7
    RHS       disj2_2_3_3  -721
    RHS       disj1_2_4_3  7
    RHS       disj2_2_4_3  -671
    RHS       disj1_2_5_3  7
    RHS       disj2_2_5_3  -716
    RHS       disj1_2_6_3  7
    RHS       disj2_2_6_3  -679
    RHS       disj1_2_7_3  7
    RHS       disj2_2_7_3  -720
    RHS       disj1_2_8_3  7
    RHS       disj2_2_8_3  -722
    RHS       disj1_3_4_3  4
    RHS       disj2_3_4_3  -671
    RHS       disj1_3_5_3  4
    RHS       disj2_3_5_3  -716
    RHS       disj1_3_6_3  4
    RHS       disj2_3_6_3  -679
    RHS       disj1_3_7_3  4
    RHS       disj2_3_7_3  -720
    RHS       disj1_3_8_3  4
    RHS       disj2_3_8_3  -722
    RHS       disj1_4_5_3  54
    RHS       disj2_4_5_3  -716
    RHS       disj1_4_6_3  54
    RHS       disj2_4_6_3  -679
    RHS       disj1_4_7_3  54
    RHS       disj2_4_7_3  -720
    RHS       disj1_4_8_3  54
    RHS       disj2_4_8_3  -722
    RHS       disj1_5_6_3  9
    RHS       disj2_5_6_3  -679
    RHS       disj1_5_7_3  9
    RHS       disj2_5_7_3  -720
    RHS       disj1_5_8_3  9
    RHS       disj2_5_8_3  -722
    RHS       disj1_6_7_3  46
    RHS       disj2_6_7_3  -720
    RHS       disj1_6_8_3  46
    RHS       disj2_6_8_3  -722
    RHS       disj1_7_8_3  5
    RHS       disj2_7_8_3  -722
    RHS       disj1_0_1_4  3
    RHS       disj2_0_1_4  -715
    RHS       disj1_0_2_4  3
    RHS       disj2_0_2_4  -720
    RHS       disj1_0_3_4  3
    RHS       disj2_0_3_4  -665
    RHS       disj1_0_4_4  3
    RHS       disj2_0_4_4  -724
    RHS       disj1_0_5_4  3
    RHS       disj2_0_5_4  -722
    RHS       disj1_0_6_4  3
    RHS       disj2_0_6_4  -722
    RHS       disj1_0_7_4  3
    RHS       disj2_0_7_4  -724
    RHS       disj1_0_8_4  3
    RHS       disj2_0_8_4  -722
    RHS       disj1_1_2_4  10
    RHS       disj2_1_2_4  -720
    RHS       disj1_1_3_4  10
    RHS       disj2_1_3_4  -665
    RHS       disj1_1_4_4  10
    RHS       disj2_1_4_4  -724
    RHS       disj1_1_5_4  10
    RHS       disj2_1_5_4  -722
    RHS       disj1_1_6_4  10
    RHS       disj2_1_6_4  -722
    RHS       disj1_1_7_4  10
    RHS       disj2_1_7_4  -724
    RHS       disj1_1_8_4  10
    RHS       disj2_1_8_4  -722
    RHS       disj1_2_3_4  5
    RHS       disj2_2_3_4  -665
    RHS       disj1_2_4_4  5
    RHS       disj2_2_4_4  -724
    RHS       disj1_2_5_4  5
    RHS       disj2_2_5_4  -722
    RHS       disj1_2_6_4  5
    RHS       disj2_2_6_4  -722
    RHS       disj1_2_7_4  5
    RHS       disj2_2_7_4  -724
    RHS       disj1_2_8_4  5
    RHS       disj2_2_8_4  -722
    RHS       disj1_3_4_4  60
    RHS       disj2_3_4_4  -724
    RHS       disj1_3_5_4  60
    RHS       disj2_3_5_4  -722
    RHS       disj1_3_6_4  60
    RHS       disj2_3_6_4  -722
    RHS       disj1_3_7_4  60
    RHS       disj2_3_7_4  -724
    RHS       disj1_3_8_4  60
    RHS       disj2_3_8_4  -722
    RHS       disj1_4_5_4  1
    RHS       disj2_4_5_4  -722
    RHS       disj1_4_6_4  1
    RHS       disj2_4_6_4  -722
    RHS       disj1_4_7_4  1
    RHS       disj2_4_7_4  -724
    RHS       disj1_4_8_4  1
    RHS       disj2_4_8_4  -722
    RHS       disj1_5_6_4  3
    RHS       disj2_5_6_4  -722
    RHS       disj1_5_7_4  3
    RHS       disj2_5_7_4  -724
    RHS       disj1_5_8_4  3
    RHS       disj2_5_8_4  -722
    RHS       disj1_6_7_4  3
    RHS       disj2_6_7_4  -724
    RHS       disj1_6_8_4  3
    RHS       disj2_6_8_4  -722
    RHS       disj1_7_8_4  1
    RHS       disj2_7_8_4  -722
    RHS       disj1_0_1_5  9
    RHS       disj2_0_1_5  -704
    RHS       disj1_0_2_5  9
    RHS       disj2_0_2_5  -715
    RHS       disj1_0_3_5  9
    RHS       disj2_0_3_5  -715
    RHS       disj1_0_4_5  9
    RHS       disj2_0_4_5  -715
    RHS       disj1_0_5_5  9
    RHS       disj2_0_5_5  -719
    RHS       disj1_0_6_5  9
    RHS       disj2_0_6_5  -719
    RHS       disj1_0_7_5  9
    RHS       disj2_0_7_5  -719
    RHS       disj1_0_8_5  9
    RHS       disj2_0_8_5  -720
    RHS       disj1_1_2_5  21
    RHS       disj2_1_2_5  -715
    RHS       disj1_1_3_5  21
    RHS       disj2_1_3_5  -715
    RHS       disj1_1_4_5  21
    RHS       disj2_1_4_5  -715
    RHS       disj1_1_5_5  21
    RHS       disj2_1_5_5  -719
    RHS       disj1_1_6_5  21
    RHS       disj2_1_6_5  -719
    RHS       disj1_1_7_5  21
    RHS       disj2_1_7_5  -719
    RHS       disj1_1_8_5  21
    RHS       disj2_1_8_5  -720
    RHS       disj1_2_3_5  10
    RHS       disj2_2_3_5  -715
    RHS       disj1_2_4_5  10
    RHS       disj2_2_4_5  -715
    RHS       disj1_2_5_5  10
    RHS       disj2_2_5_5  -719
    RHS       disj1_2_6_5  10
    RHS       disj2_2_6_5  -719
    RHS       disj1_2_7_5  10
    RHS       disj2_2_7_5  -719
    RHS       disj1_2_8_5  10
    RHS       disj2_2_8_5  -720
    RHS       disj1_3_4_5  10
    RHS       disj2_3_4_5  -715
    RHS       disj1_3_5_5  10
    RHS       disj2_3_5_5  -719
    RHS       disj1_3_6_5  10
    RHS       disj2_3_6_5  -719
    RHS       disj1_3_7_5  10
    RHS       disj2_3_7_5  -719
    RHS       disj1_3_8_5  10
    RHS       disj2_3_8_5  -720
    RHS       disj1_4_5_5  10
    RHS       disj2_4_5_5  -719
    RHS       disj1_4_6_5  10
    RHS       disj2_4_6_5  -719
    RHS       disj1_4_7_5  10
    RHS       disj2_4_7_5  -719
    RHS       disj1_4_8_5  10
    RHS       disj2_4_8_5  -720
    RHS       disj1_5_6_5  6
    RHS       disj2_5_6_5  -719
    RHS       disj1_5_7_5  6
    RHS       disj2_5_7_5  -719
    RHS       disj1_5_8_5  6
    RHS       disj2_5_8_5  -720
    RHS       disj1_6_7_5  6
    RHS       disj2_6_7_5  -719
    RHS       disj1_6_8_5  6
    RHS       disj2_6_8_5  -720
    RHS       disj1_7_8_5  6
    RHS       disj2_7_8_5  -720
    RHS       disj1_0_1_6  50
    RHS       disj2_0_1_6  -722
    RHS       disj1_0_2_6  50
    RHS       disj2_0_2_6  -718
    RHS       disj1_0_3_6  50
    RHS       disj2_0_3_6  -723
    RHS       disj1_0_4_6  50
    RHS       disj2_0_4_6  -724
    RHS       disj1_0_5_6  50
    RHS       disj2_0_5_6  -703
    RHS       disj1_0_6_6  50
    RHS       disj2_0_6_6  -666
    RHS       disj1_0_7_6  50
    RHS       disj2_0_7_6  -720
    RHS       disj1_0_8_6  50
    RHS       disj2_0_8_6  -723
    RHS       disj1_1_2_6  3
    RHS       disj2_1_2_6  -718
    RHS       disj1_1_3_6  3
    RHS       disj2_1_3_6  -723
    RHS       disj1_1_4_6  3
    RHS       disj2_1_4_6  -724
    RHS       disj1_1_5_6  3
    RHS       disj2_1_5_6  -703
    RHS       disj1_1_6_6  3
    RHS       disj2_1_6_6  -666
    RHS       disj1_1_7_6  3
    RHS       disj2_1_7_6  -720
    RHS       disj1_1_8_6  3
    RHS       disj2_1_8_6  -723
    RHS       disj1_2_3_6  7
    RHS       disj2_2_3_6  -723
    RHS       disj1_2_4_6  7
    RHS       disj2_2_4_6  -724
    RHS       disj1_2_5_6  7
    RHS       disj2_2_5_6  -703
    RHS       disj1_2_6_6  7
    RHS       disj2_2_6_6  -666
    RHS       disj1_2_7_6  7
    RHS       disj2_2_7_6  -720
    RHS       disj1_2_8_6  7
    RHS       disj2_2_8_6  -723
    RHS       disj1_3_4_6  2
    RHS       disj2_3_4_6  -724
    RHS       disj1_3_5_6  2
    RHS       disj2_3_5_6  -703
    RHS       disj1_3_6_6  2
    RHS       disj2_3_6_6  -666
    RHS       disj1_3_7_6  2
    RHS       disj2_3_7_6  -720
    RHS       disj1_3_8_6  2
    RHS       disj2_3_8_6  -723
    RHS       disj1_4_5_6  1
    RHS       disj2_4_5_6  -703
    RHS       disj1_4_6_6  1
    RHS       disj2_4_6_6  -666
    RHS       disj1_4_7_6  1
    RHS       disj2_4_7_6  -720
    RHS       disj1_4_8_6  1
    RHS       disj2_4_8_6  -723
    RHS       disj1_5_6_6  22
    RHS       disj2_5_6_6  -666
    RHS       disj1_5_7_6  22
    RHS       disj2_5_7_6  -720
    RHS       disj1_5_8_6  22
    RHS       disj2_5_8_6  -723
    RHS       disj1_6_7_6  59
    RHS       disj2_6_7_6  -720
    RHS       disj1_6_8_6  59
    RHS       disj2_6_8_6  -723
    RHS       disj1_7_8_6  5
    RHS       disj2_7_8_6  -723
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_1_6
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_2_6
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_3_6
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_4_6
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_5_6
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_0_6_6
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_7_5
 BV BOUND     y_0_7_6
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_8_5
 BV BOUND     y_0_8_6
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_2_6
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_3_6
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_4_6
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_5_6
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_1_6_6
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_7_5
 BV BOUND     y_1_7_6
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_8_5
 BV BOUND     y_1_8_6
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_3_6
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_4_6
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_5_6
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_2_6_6
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_7_5
 BV BOUND     y_2_7_6
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_8_5
 BV BOUND     y_2_8_6
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_4_6
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_5_6
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_3_6_6
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_7_5
 BV BOUND     y_3_7_6
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_8_5
 BV BOUND     y_3_8_6
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_5_6
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_4_6_6
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_7_5
 BV BOUND     y_4_7_6
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_8_5
 BV BOUND     y_4_8_6
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
 BV BOUND     y_5_6_6
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_7_5
 BV BOUND     y_5_7_6
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_8_5
 BV BOUND     y_5_8_6
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_7_5
 BV BOUND     y_6_7_6
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_8_5
 BV BOUND     y_6_8_6
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_8_5
 BV BOUND     y_7_8_6
ENDATA
