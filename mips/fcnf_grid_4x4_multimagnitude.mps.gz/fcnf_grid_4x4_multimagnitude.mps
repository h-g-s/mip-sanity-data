NAME          fcnf_grid_4x4_multimagnitude
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
COLUMNS
    x_0         OBJ       0.13
    x_0         flow_0      1.0
    x_0         flow_1      -1.0
    x_0         link_0      1.0
    x_1         OBJ       2.02
    x_1         flow_0      1.0
    x_1         flow_4      -1.0
    x_1         link_1      1.0
    x_2         OBJ       3.93
    x_2         flow_1      1.0
    x_2         flow_2      -1.0
    x_2         link_2      1.0
    x_3         OBJ       3.64
    x_3         flow_1      1.0
    x_3         flow_5      -1.0
    x_3         link_3      1.0
    x_4         OBJ       0.18
    x_4         flow_1      1.0
    x_4         flow_0      -1.0
    x_4         link_4      1.0
    x_5         OBJ       0.15
    x_5         flow_2      1.0
    x_5         flow_3      -1.0
    x_5         link_5      1.0
    x_6         OBJ       2.47
    x_6         flow_2      1.0
    x_6         flow_6      -1.0
    x_6         link_6      1.0
    x_7         OBJ       1.77
    x_7         flow_2      1.0
    x_7         flow_1      -1.0
    x_7         link_7      1.0
    x_8         OBJ       2.88
    x_8         flow_3      1.0
    x_8         flow_7      -1.0
    x_8         link_8      1.0
    x_9         OBJ       4.28
    x_9         flow_3      1.0
    x_9         flow_2      -1.0
    x_9         link_9      1.0
    x_10        OBJ       0.19
    x_10        flow_4      1.0
    x_10        flow_5      -1.0
    x_10        link_10     1.0
    x_11        OBJ       4.91
    x_11        flow_4      1.0
    x_11        flow_8      -1.0
    x_11        link_11     1.0
    x_12        OBJ       4.11
    x_12        flow_4      1.0
    x_12        flow_0      -1.0
    x_12        link_12     1.0
    x_13        OBJ       1.47
    x_13        flow_5      1.0
    x_13        flow_6      -1.0
    x_13        link_13     1.0
    x_14        OBJ       4.32
    x_14        flow_5      1.0
    x_14        flow_9      -1.0
    x_14        link_14     1.0
    x_15        OBJ       3.58
    x_15        flow_5      1.0
    x_15        flow_4      -1.0
    x_15        link_15     1.0
    x_16        OBJ       4.7
    x_16        flow_5      1.0
    x_16        flow_1      -1.0
    x_16        link_16     1.0
    x_17        OBJ       2.31
    x_17        flow_6      1.0
    x_17        flow_7      -1.0
    x_17        link_17     1.0
    x_18        OBJ       2.63
    x_18        flow_6      1.0
    x_18        flow_10     -1.0
    x_18        link_18     1.0
    x_19        OBJ       0.14
    x_19        flow_6      1.0
    x_19        flow_5      -1.0
    x_19        link_19     1.0
    x_20        OBJ       2.29
    x_20        flow_6      1.0
    x_20        flow_2      -1.0
    x_20        link_20     1.0
    x_21        OBJ       4.93
    x_21        flow_7      1.0
    x_21        flow_11     -1.0
    x_21        link_21     1.0
    x_22        OBJ       2.01
    x_22        flow_7      1.0
    x_22        flow_6      -1.0
    x_22        link_22     1.0
    x_23        OBJ       4.54
    x_23        flow_7      1.0
    x_23        flow_3      -1.0
    x_23        link_23     1.0
    x_24        OBJ       0.15
    x_24        flow_8      1.0
    x_24        flow_9      -1.0
    x_24        link_24     1.0
    x_25        OBJ       3.23
    x_25        flow_8      1.0
    x_25        flow_12     -1.0
    x_25        link_25     1.0
    x_26        OBJ       3.32
    x_26        flow_8      1.0
    x_26        flow_4      -1.0
    x_26        link_26     1.0
    x_27        OBJ       2.91
    x_27        flow_9      1.0
    x_27        flow_10     -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.56
    x_28        flow_9      1.0
    x_28        flow_13     -1.0
    x_28        link_28     1.0
    x_29        OBJ       2.61
    x_29        flow_9      1.0
    x_29        flow_8      -1.0
    x_29        link_29     1.0
    x_30        OBJ       2.61
    x_30        flow_9      1.0
    x_30        flow_5      -1.0
    x_30        link_30     1.0
    x_31        OBJ       3.21
    x_31        flow_10     1.0
    x_31        flow_11     -1.0
    x_31        link_31     1.0
    x_32        OBJ       2.91
    x_32        flow_10     1.0
    x_32        flow_14     -1.0
    x_32        link_32     1.0
    x_33        OBJ       4.47
    x_33        flow_10     1.0
    x_33        flow_9      -1.0
    x_33        link_33     1.0
    x_34        OBJ       2.56
    x_34        flow_10     1.0
    x_34        flow_6      -1.0
    x_34        link_34     1.0
    x_35        OBJ       2.1
    x_35        flow_11     1.0
    x_35        flow_15     -1.0
    x_35        link_35     1.0
    x_36        OBJ       2.16
    x_36        flow_11     1.0
    x_36        flow_10     -1.0
    x_36        link_36     1.0
    x_37        OBJ       3.14
    x_37        flow_11     1.0
    x_37        flow_7      -1.0
    x_37        link_37     1.0
    x_38        OBJ       0.06
    x_38        flow_12     1.0
    x_38        flow_13     -1.0
    x_38        link_38     1.0
    x_39        OBJ       1.97
    x_39        flow_12     1.0
    x_39        flow_8      -1.0
    x_39        link_39     1.0
    x_40        OBJ       0.18
    x_40        flow_13     1.0
    x_40        flow_14     -1.0
    x_40        link_40     1.0
    x_41        OBJ       3.46
    x_41        flow_13     1.0
    x_41        flow_12     -1.0
    x_41        link_41     1.0
    x_42        OBJ       4.96
    x_42        flow_13     1.0
    x_42        flow_9      -1.0
    x_42        link_42     1.0
    x_43        OBJ       1.62
    x_43        flow_14     1.0
    x_43        flow_15     -1.0
    x_43        link_43     1.0
    x_44        OBJ       2.95
    x_44        flow_14     1.0
    x_44        flow_13     -1.0
    x_44        link_44     1.0
    x_45        OBJ       1.3
    x_45        flow_14     1.0
    x_45        flow_10     -1.0
    x_45        link_45     1.0
    x_46        OBJ       0.06
    x_46        flow_15     1.0
    x_46        flow_14     -1.0
    x_46        link_46     1.0
    x_47        OBJ       0.14
    x_47        flow_15     1.0
    x_47        flow_11     -1.0
    x_47        link_47     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       27.38
    y_0         link_0      -714.0
    y_1         OBJ       18.01
    y_1         link_1      -7.0
    y_2         OBJ       13.22
    y_2         link_2      -6.0
    y_3         OBJ       10.8
    y_3         link_3      -7.0
    y_4         OBJ       20.85
    y_4         link_4      -207.0
    y_5         OBJ       48.3
    y_5         link_5      -689.0
    y_6         OBJ       16.79
    y_6         link_6      -5.0
    y_7         OBJ       16.4
    y_7         link_7      -8.0
    y_8         OBJ       18.6
    y_8         link_8      -4.0
    y_9         OBJ       13.88
    y_9         link_9      -8.0
    y_10        OBJ       40.5
    y_10        link_10     -675.0
    y_11        OBJ       10.55
    y_11        link_11     -4.0
    y_12        OBJ       13.84
    y_12        link_12     -7.0
    y_13        OBJ       16.45
    y_13        link_13     -6.0
    y_14        OBJ       16.79
    y_14        link_14     -6.0
    y_15        OBJ       13.09
    y_15        link_15     -7.0
    y_16        OBJ       17.46
    y_16        link_16     -5.0
    y_17        OBJ       12.93
    y_17        link_17     -3.0
    y_18        OBJ       18.42
    y_18        link_18     -7.0
    y_19        OBJ       26.39
    y_19        link_19     -680.0
    y_20        OBJ       9.62
    y_20        link_20     -3.0
    y_21        OBJ       13.27
    y_21        link_21     -6.0
    y_22        OBJ       16.69
    y_22        link_22     -5.0
    y_23        OBJ       7.68
    y_23        link_23     -6.0
    y_24        OBJ       24.7
    y_24        link_24     -211.0
    y_25        OBJ       12.51
    y_25        link_25     -3.0
    y_26        OBJ       13.9
    y_26        link_26     -5.0
    y_27        OBJ       5.25
    y_27        link_27     -6.0
    y_28        OBJ       15.29
    y_28        link_28     -5.0
    y_29        OBJ       17.86
    y_29        link_29     -6.0
    y_30        OBJ       19.78
    y_30        link_30     -5.0
    y_31        OBJ       11.13
    y_31        link_31     -5.0
    y_32        OBJ       6.87
    y_32        link_32     -5.0
    y_33        OBJ       8.23
    y_33        link_33     -6.0
    y_34        OBJ       13.42
    y_34        link_34     -3.0
    y_35        OBJ       18.96
    y_35        link_35     -7.0
    y_36        OBJ       11.78
    y_36        link_36     -3.0
    y_37        OBJ       16.75
    y_37        link_37     -8.0
    y_38        OBJ       34.56
    y_38        link_38     -480.0
    y_39        OBJ       16.56
    y_39        link_39     -3.0
    y_40        OBJ       48.16
    y_40        link_40     -309.0
    y_41        OBJ       14.22
    y_41        link_41     -3.0
    y_42        OBJ       16.54
    y_42        link_42     -4.0
    y_43        OBJ       12.85
    y_43        link_43     -4.0
    y_44        OBJ       5.81
    y_44        link_44     -4.0
    y_45        OBJ       19.76
    y_45        link_45     -6.0
    y_46        OBJ       25.83
    y_46        link_46     -719.0
    y_47        OBJ       35.39
    y_47        link_47     -266.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      6
    RHS       flow_15     -6
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
ENDATA
