NAME          cvrp_search_n14_k2_uniform_clustered
ROWS
 N  OBJ
 E  OUT1
 E  IN1
 E  FLOW1
 E  OUT2
 E  IN2
 E  FLOW2
 E  OUT3
 E  IN3
 E  FLOW3
 E  OUT4
 E  IN4
 E  FLOW4
 E  OUT5
 E  IN5
 E  FLOW5
 E  OUT6
 E  IN6
 E  FLOW6
 E  OUT7
 E  IN7
 E  FLOW7
 E  OUT8
 E  IN8
 E  FLOW8
 E  OUT9
 E  IN9
 E  FLOW9
 E  OUT10
 E  IN10
 E  FLOW10
 E  OUT11
 E  IN11
 E  FLOW11
 E  OUT12
 E  IN12
 E  FLOW12
 E  OUT13
 E  IN13
 E  FLOW13
 E  OUT14
 E  IN14
 E  FLOW14
 L  FLEET
 L  CAP0
 L  CAP1
 L  CAP2
 L  CAP3
 L  CAP4
 L  CAP5
 L  CAP6
 L  CAP7
 L  CAP8
 L  CAP9
 L  CAP10
 L  CAP11
 L  CAP12
 L  CAP13
 L  CAP14
 L  CAP15
 L  CAP16
 L  CAP17
 L  CAP18
 L  CAP19
 L  CAP20
 L  CAP21
 L  CAP22
 L  CAP23
 L  CAP24
 L  CAP25
 L  CAP26
 L  CAP27
 L  CAP28
 L  CAP29
 L  CAP30
 L  CAP31
 L  CAP32
 L  CAP33
 L  CAP34
 L  CAP35
 L  CAP36
 L  CAP37
 L  CAP38
 L  CAP39
 L  CAP40
 L  CAP41
 L  CAP42
 L  CAP43
 L  CAP44
 L  CAP45
 L  CAP46
 L  CAP47
 L  CAP48
 L  CAP49
 L  CAP50
 L  CAP51
 L  CAP52
 L  CAP53
 L  CAP54
 L  CAP55
 L  CAP56
 L  CAP57
 L  CAP58
 L  CAP59
 L  CAP60
 L  CAP61
 L  CAP62
 L  CAP63
 L  CAP64
 L  CAP65
 L  CAP66
 L  CAP67
 L  CAP68
 L  CAP69
 L  CAP70
 L  CAP71
 L  CAP72
 L  CAP73
 L  CAP74
 L  CAP75
 L  CAP76
 L  CAP77
 L  CAP78
 L  CAP79
 L  CAP80
 L  CAP81
 L  CAP82
 L  CAP83
 L  CAP84
 L  CAP85
 L  CAP86
 L  CAP87
 L  CAP88
 L  CAP89
 L  CAP90
 L  CAP91
 L  CAP92
 L  CAP93
 L  CAP94
 L  CAP95
 L  CAP96
 L  CAP97
 L  CAP98
 L  CAP99
 L  CAP100
 L  CAP101
 L  CAP102
 L  CAP103
 L  CAP104
 L  CAP105
 L  CAP106
 L  CAP107
 L  CAP108
 L  CAP109
 L  CAP110
 L  CAP111
 L  CAP112
 L  CAP113
 L  CAP114
 L  CAP115
 L  CAP116
 L  CAP117
 L  CAP118
 L  CAP119
 L  CAP120
 L  CAP121
 L  CAP122
 L  CAP123
 L  CAP124
 L  CAP125
 L  CAP126
 L  CAP127
 L  CAP128
 L  CAP129
 L  CAP130
 L  CAP131
 L  CAP132
 L  CAP133
 L  CAP134
 L  CAP135
 L  CAP136
 L  CAP137
 L  CAP138
 L  CAP139
 L  CAP140
 L  CAP141
 L  CAP142
 L  CAP143
 L  CAP144
 L  CAP145
 L  CAP146
 L  CAP147
 L  CAP148
 L  CAP149
 L  CAP150
 L  CAP151
 L  CAP152
 L  CAP153
 L  CAP154
 L  CAP155
 L  CAP156
 L  CAP157
 L  CAP158
 L  CAP159
 L  CAP160
 L  CAP161
 L  CAP162
 L  CAP163
 L  CAP164
 L  CAP165
 L  CAP166
 L  CAP167
 L  CAP168
 L  CAP169
 L  CAP170
 L  CAP171
 L  CAP172
 L  CAP173
 L  CAP174
 L  CAP175
 L  CAP176
 L  CAP177
 L  CAP178
 L  CAP179
 L  CAP180
 L  CAP181
 L  CAP182
 L  CAP183
 L  CAP184
 L  CAP185
 L  CAP186
 L  CAP187
 L  CAP188
 L  CAP189
 L  CAP190
 L  CAP191
 L  CAP192
 L  CAP193
 L  CAP194
 L  CAP195
 G  DLBO1
 L  DUBO1
 G  DLBO2
 L  DUBO2
 G  DLBO3
 L  DUBO3
 G  DLBO4
 L  DUBO4
 G  DLBO5
 L  DUBO5
 G  DLBO6
 L  DUBO6
 G  DLBO7
 L  DUBO7
 G  DLBO8
 L  DUBO8
 G  DLBO9
 L  DUBO9
 G  DLBO10
 L  DUBO10
 G  DLBO11
 L  DUBO11
 G  DLBO12
 L  DUBO12
 G  DLBO13
 L  DUBO13
 G  DLBO14
 L  DUBO14
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0_1          OBJ       24.06
    x0_1          IN1      1
    x0_1          FLOW1   -1
    x0_1          FLEET      1
    x0_1          CAP0    45
    x0_2          OBJ       20.76
    x0_2          IN2      1
    x0_2          FLOW2   -1
    x0_2          FLEET      1
    x0_2          CAP1    45
    x0_3          OBJ       27.20
    x0_3          IN3      1
    x0_3          FLOW3   -1
    x0_3          FLEET      1
    x0_3          CAP2    45
    x0_4          OBJ       12.13
    x0_4          IN4      1
    x0_4          FLOW4   -1
    x0_4          FLEET      1
    x0_4          CAP3    45
    x0_5          OBJ       51.62
    x0_5          IN5      1
    x0_5          FLOW5   -1
    x0_5          FLEET      1
    x0_5          CAP4    45
    x0_6          OBJ       7.94
    x0_6          IN6      1
    x0_6          FLOW6   -1
    x0_6          FLEET      1
    x0_6          CAP5    45
    x0_7          OBJ       20.71
    x0_7          IN7      1
    x0_7          FLOW7   -1
    x0_7          FLEET      1
    x0_7          CAP6    45
    x0_8          OBJ       6.78
    x0_8          IN8      1
    x0_8          FLOW8   -1
    x0_8          FLEET      1
    x0_8          CAP7    45
    x0_9          OBJ       30.71
    x0_9          IN9      1
    x0_9          FLOW9   -1
    x0_9          FLEET      1
    x0_9          CAP8    45
    x0_10         OBJ       10.79
    x0_10         IN10      1
    x0_10         FLOW10   -1
    x0_10         FLEET      1
    x0_10         CAP9    45
    x0_11         OBJ       33.11
    x0_11         IN11      1
    x0_11         FLOW11   -1
    x0_11         FLEET      1
    x0_11         CAP10    45
    x0_12         OBJ       19.06
    x0_12         IN12      1
    x0_12         FLOW12   -1
    x0_12         FLEET      1
    x0_12         CAP11    45
    x0_13         OBJ       34.82
    x0_13         IN13      1
    x0_13         FLOW13   -1
    x0_13         FLEET      1
    x0_13         CAP12    45
    x0_14         OBJ       25.03
    x0_14         IN14      1
    x0_14         FLOW14   -1
    x0_14         FLEET      1
    x0_14         CAP13    45
    x1_0          OBJ       24.06
    x1_0          OUT1     1
    x1_0          FLOW1    1
    x1_2          OBJ       29.79
    x1_2          OUT1     1
    x1_2          IN2      1
    x1_2          FLOW1    1
    x1_2          FLOW2   -1
    x1_2          CAP14    45
    x1_3          OBJ       13.89
    x1_3          OUT1     1
    x1_3          IN3      1
    x1_3          FLOW1    1
    x1_3          FLOW3   -1
    x1_3          CAP15    45
    x1_4          OBJ       30.45
    x1_4          OUT1     1
    x1_4          IN4      1
    x1_4          FLOW1    1
    x1_4          FLOW4   -1
    x1_4          CAP16    45
    x1_5          OBJ       27.71
    x1_5          OUT1     1
    x1_5          IN5      1
    x1_5          FLOW1    1
    x1_5          FLOW5   -1
    x1_5          CAP17    45
    x1_6          OBJ       31.72
    x1_6          OUT1     1
    x1_6          IN6      1
    x1_6          FLOW1    1
    x1_6          FLOW6   -1
    x1_6          CAP18    45
    x1_7          OBJ       25.54
    x1_7          OUT1     1
    x1_7          IN7      1
    x1_7          FLOW1    1
    x1_7          FLOW7   -1
    x1_7          CAP19    45
    x1_8          OBJ       20.17
    x1_8          OUT1     1
    x1_8          IN8      1
    x1_8          FLOW1    1
    x1_8          FLOW8   -1
    x1_8          CAP20    45
    x1_9          OBJ       10.92
    x1_9          OUT1     1
    x1_9          IN9      1
    x1_9          FLOW1    1
    x1_9          FLOW9   -1
    x1_9          CAP21    45
    x1_10         OBJ       32.45
    x1_10         OUT1     1
    x1_10         IN10      1
    x1_10         FLOW1    1
    x1_10         FLOW10   -1
    x1_10         CAP22    45
    x1_11         OBJ       31.87
    x1_11         OUT1     1
    x1_11         IN11      1
    x1_11         FLOW1    1
    x1_11         FLOW11   -1
    x1_11         CAP23    45
    x1_12         OBJ       39.14
    x1_12         OUT1     1
    x1_12         IN12      1
    x1_12         FLOW1    1
    x1_12         FLOW12   -1
    x1_12         CAP24    45
    x1_13         OBJ       11.19
    x1_13         OUT1     1
    x1_13         IN13      1
    x1_13         FLOW1    1
    x1_13         FLOW13   -1
    x1_13         CAP25    45
    x1_14         OBJ       25.53
    x1_14         OUT1     1
    x1_14         IN14      1
    x1_14         FLOW1    1
    x1_14         FLOW14   -1
    x1_14         CAP26    45
    x2_0          OBJ       20.76
    x2_0          OUT2     1
    x2_0          FLOW2    1
    x2_1          OBJ       29.79
    x2_1          OUT2     1
    x2_1          IN1      1
    x2_1          FLOW2    1
    x2_1          FLOW1   -1
    x2_1          CAP27    45
    x2_3          OBJ       40.29
    x2_3          OUT2     1
    x2_3          IN3      1
    x2_3          FLOW2    1
    x2_3          FLOW3   -1
    x2_3          CAP28    45
    x2_4          OBJ       11.41
    x2_4          OUT2     1
    x2_4          IN4      1
    x2_4          FLOW2    1
    x2_4          FLOW4   -1
    x2_4          CAP29    45
    x2_5          OBJ       54.86
    x2_5          OUT2     1
    x2_5          IN5      1
    x2_5          FLOW2    1
    x2_5          FLOW5   -1
    x2_5          CAP30    45
    x2_6          OBJ       25.15
    x2_6          OUT2     1
    x2_6          IN6      1
    x2_6          FLOW2    1
    x2_6          FLOW6   -1
    x2_6          CAP31    45
    x2_7          OBJ       40.25
    x2_7          OUT2     1
    x2_7          IN7      1
    x2_7          FLOW2    1
    x2_7          FLOW7   -1
    x2_7          CAP32    45
    x2_8          OBJ       15.69
    x2_8          OUT2     1
    x2_8          IN8      1
    x2_8          FLOW2    1
    x2_8          FLOW8   -1
    x2_8          CAP33    45
    x2_9          OBJ       28.77
    x2_9          OUT2     1
    x2_9          IN9      1
    x2_9          FLOW2    1
    x2_9          FLOW9   -1
    x2_9          CAP34    45
    x2_10         OBJ       16.20
    x2_10         OUT2     1
    x2_10         IN10      1
    x2_10         FLOW2    1
    x2_10         FLOW10   -1
    x2_10         CAP35    45
    x2_11         OBJ       51.96
    x2_11         OUT2     1
    x2_11         IN11      1
    x2_11         FLOW2    1
    x2_11         FLOW11   -1
    x2_11         CAP36    45
    x2_12         OBJ       38.19
    x2_12         OUT2     1
    x2_12         IN12      1
    x2_12         FLOW2    1
    x2_12         FLOW12   -1
    x2_12         CAP37    45
    x2_13         OBJ       40.24
    x2_13         OUT2     1
    x2_13         IN13      1
    x2_13         FLOW2    1
    x2_13         FLOW13   -1
    x2_13         CAP38    45
    x2_14         OBJ       9.10
    x2_14         OUT2     1
    x2_14         IN14      1
    x2_14         FLOW2    1
    x2_14         FLOW14   -1
    x2_14         CAP39    45
    x3_0          OBJ       27.20
    x3_0          OUT3     1
    x3_0          FLOW3    1
    x3_1          OBJ       13.89
    x3_1          OUT3     1
    x3_1          IN1      1
    x3_1          FLOW3    1
    x3_1          FLOW1   -1
    x3_1          CAP40    45
    x3_2          OBJ       40.29
    x3_2          OUT3     1
    x3_2          IN2      1
    x3_2          FLOW3    1
    x3_2          FLOW2   -1
    x3_2          CAP41    45
    x3_4          OBJ       37.40
    x3_4          OUT3     1
    x3_4          IN4      1
    x3_4          FLOW3    1
    x3_4          FLOW4   -1
    x3_4          CAP42    45
    x3_5          OBJ       29.65
    x3_5          OUT3     1
    x3_5          IN5      1
    x3_5          FLOW3    1
    x3_5          FLOW5   -1
    x3_5          CAP43    45
    x3_6          OBJ       33.00
    x3_6          OUT3     1
    x3_6          IN6      1
    x3_6          FLOW3    1
    x3_6          FLOW6   -1
    x3_6          CAP44    45
    x3_7          OBJ       16.91
    x3_7          OUT3     1
    x3_7          IN7      1
    x3_7          FLOW3    1
    x3_7          FLOW7   -1
    x3_7          CAP45    45
    x3_8          OBJ       26.71
    x3_8          OUT3     1
    x3_8          IN8      1
    x3_8          FLOW3    1
    x3_8          FLOW8   -1
    x3_8          CAP46    45
    x3_9          OBJ       24.23
    x3_9          OUT3     1
    x3_9          IN9      1
    x3_9          FLOW3    1
    x3_9          FLOW9   -1
    x3_9          CAP47    45
    x3_10         OBJ       37.70
    x3_10         OUT3     1
    x3_10         IN10      1
    x3_10         FLOW3    1
    x3_10         FLOW10   -1
    x3_10         CAP48    45
    x3_11         OBJ       18.93
    x3_11         OUT3     1
    x3_11         IN11      1
    x3_11         FLOW3    1
    x3_11         FLOW11   -1
    x3_11         CAP49    45
    x3_12         OBJ       35.65
    x3_12         OUT3     1
    x3_12         IN12      1
    x3_12         FLOW3    1
    x3_12         FLOW12   -1
    x3_12         CAP50    45
    x3_13         OBJ       15.17
    x3_13         OUT3     1
    x3_13         IN13      1
    x3_13         FLOW3    1
    x3_13         FLOW13   -1
    x3_13         CAP51    45
    x3_14         OBJ       38.01
    x3_14         OUT3     1
    x3_14         IN14      1
    x3_14         FLOW3    1
    x3_14         FLOW14   -1
    x3_14         CAP52    45
    x4_0          OBJ       12.13
    x4_0          OUT4     1
    x4_0          FLOW4    1
    x4_1          OBJ       30.45
    x4_1          OUT4     1
    x4_1          IN1      1
    x4_1          FLOW4    1
    x4_1          FLOW1   -1
    x4_1          CAP53    45
    x4_2          OBJ       11.41
    x4_2          OUT4     1
    x4_2          IN2      1
    x4_2          FLOW4    1
    x4_2          FLOW2   -1
    x4_2          CAP54    45
    x4_3          OBJ       37.40
    x4_3          OUT4     1
    x4_3          IN3      1
    x4_3          FLOW4    1
    x4_3          FLOW3   -1
    x4_3          CAP55    45
    x4_5          OBJ       57.79
    x4_5          OUT4     1
    x4_5          IN5      1
    x4_5          FLOW4    1
    x4_5          FLOW5   -1
    x4_5          CAP56    45
    x4_6          OBJ       14.22
    x4_6          OUT4     1
    x4_6          IN6      1
    x4_6          FLOW4    1
    x4_6          FLOW6   -1
    x4_6          CAP57    45
    x4_7          OBJ       32.84
    x4_7          OUT4     1
    x4_7          IN7      1
    x4_7          FLOW4    1
    x4_7          FLOW7   -1
    x4_7          CAP58    45
    x4_8          OBJ       10.78
    x4_8          OUT4     1
    x4_8          IN8      1
    x4_8          FLOW4    1
    x4_8          FLOW8   -1
    x4_8          CAP59    45
    x4_9          OBJ       33.38
    x4_9          OUT4     1
    x4_9          IN9      1
    x4_9          FLOW4    1
    x4_9          FLOW9   -1
    x4_9          CAP60    45
    x4_10         OBJ       4.81
    x4_10         OUT4     1
    x4_10         IN10      1
    x4_10         FLOW4    1
    x4_10         FLOW10   -1
    x4_10         CAP61    45
    x4_11         OBJ       45.22
    x4_11         OUT4     1
    x4_11         IN11      1
    x4_11         FLOW4    1
    x4_11         FLOW11   -1
    x4_11         CAP62    45
    x4_12         OBJ       27.21
    x4_12         OUT4     1
    x4_12         IN12      1
    x4_12         FLOW4    1
    x4_12         FLOW12   -1
    x4_12         CAP63    45
    x4_13         OBJ       41.63
    x4_13         OUT4     1
    x4_13         IN13      1
    x4_13         FLOW4    1
    x4_13         FLOW13   -1
    x4_13         CAP64    45
    x4_14         OBJ       19.07
    x4_14         OUT4     1
    x4_14         IN14      1
    x4_14         FLOW4    1
    x4_14         FLOW14   -1
    x4_14         CAP65    45
    x5_0          OBJ       51.62
    x5_0          OUT5     1
    x5_0          FLOW5    1
    x5_1          OBJ       27.71
    x5_1          OUT5     1
    x5_1          IN1      1
    x5_1          FLOW5    1
    x5_1          FLOW1   -1
    x5_1          CAP66    45
    x5_2          OBJ       54.86
    x5_2          OUT5     1
    x5_2          IN2      1
    x5_2          FLOW5    1
    x5_2          FLOW2   -1
    x5_2          CAP67    45
    x5_3          OBJ       29.65
    x5_3          OUT5     1
    x5_3          IN3      1
    x5_3          FLOW5    1
    x5_3          FLOW3   -1
    x5_3          CAP68    45
    x5_4          OBJ       57.79
    x5_4          OUT5     1
    x5_4          IN4      1
    x5_4          FLOW5    1
    x5_4          FLOW4   -1
    x5_4          CAP69    45
    x5_6          OBJ       59.03
    x5_6          OUT5     1
    x5_6          IN6      1
    x5_6          FLOW5    1
    x5_6          FLOW6   -1
    x5_6          CAP70    45
    x5_7          OBJ       46.56
    x5_7          OUT5     1
    x5_7          IN7      1
    x5_7          FLOW5    1
    x5_7          FLOW7   -1
    x5_7          CAP71    45
    x5_8          OBJ       47.82
    x5_8          OUT5     1
    x5_8          IN8      1
    x5_8          FLOW5    1
    x5_8          FLOW8   -1
    x5_8          CAP72    45
    x5_9          OBJ       26.28
    x5_9          OUT5     1
    x5_9          IN9      1
    x5_9          FLOW5    1
    x5_9          FLOW9   -1
    x5_9          CAP73    45
    x5_10         OBJ       60.10
    x5_10         OUT5     1
    x5_10         IN10      1
    x5_10         FLOW5    1
    x5_10         FLOW10   -1
    x5_10         CAP74    45
    x5_11         OBJ       45.76
    x5_11         OUT5     1
    x5_11         IN11      1
    x5_11         FLOW5    1
    x5_11         FLOW11   -1
    x5_11         CAP75    45
    x5_12         OBJ       64.53
    x5_12         OUT5     1
    x5_12         IN12      1
    x5_12         FLOW5    1
    x5_12         FLOW12   -1
    x5_12         CAP76    45
    x5_13         OBJ       16.83
    x5_13         OUT5     1
    x5_13         IN13      1
    x5_13         FLOW5    1
    x5_13         FLOW13   -1
    x5_13         CAP77    45
    x5_14         OBJ       47.93
    x5_14         OUT5     1
    x5_14         IN14      1
    x5_14         FLOW5    1
    x5_14         FLOW14   -1
    x5_14         CAP78    45
    x6_0          OBJ       7.94
    x6_0          OUT6     1
    x6_0          FLOW6    1
    x6_1          OBJ       31.72
    x6_1          OUT6     1
    x6_1          IN1      1
    x6_1          FLOW6    1
    x6_1          FLOW1   -1
    x6_1          CAP79    45
    x6_2          OBJ       25.15
    x6_2          OUT6     1
    x6_2          IN2      1
    x6_2          FLOW6    1
    x6_2          FLOW2   -1
    x6_2          CAP80    45
    x6_3          OBJ       33.00
    x6_3          OUT6     1
    x6_3          IN3      1
    x6_3          FLOW6    1
    x6_3          FLOW3   -1
    x6_3          CAP81    45
    x6_4          OBJ       14.22
    x6_4          OUT6     1
    x6_4          IN4      1
    x6_4          FLOW6    1
    x6_4          FLOW4   -1
    x6_4          CAP82    45
    x6_5          OBJ       59.03
    x6_5          OUT6     1
    x6_5          IN5      1
    x6_5          FLOW6    1
    x6_5          FLOW5   -1
    x6_5          CAP83    45
    x6_7          OBJ       22.58
    x6_7          OUT6     1
    x6_7          IN7      1
    x6_7          FLOW6    1
    x6_7          FLOW7   -1
    x6_7          CAP84    45
    x6_8          OBJ       14.21
    x6_8          OUT6     1
    x6_8          IN8      1
    x6_8          FLOW6    1
    x6_8          FLOW8   -1
    x6_8          CAP85    45
    x6_9          OBJ       38.65
    x6_9          OUT6     1
    x6_9          IN9      1
    x6_9          FLOW6    1
    x6_9          FLOW9   -1
    x6_9          CAP86    45
    x6_10         OBJ       10.27
    x6_10         OUT6     1
    x6_10         IN10      1
    x6_10         FLOW6    1
    x6_10         FLOW10   -1
    x6_10         CAP87    45
    x6_11         OBJ       34.93
    x6_11         OUT6     1
    x6_11         IN11      1
    x6_11         FLOW6    1
    x6_11         FLOW11   -1
    x6_11         CAP88    45
    x6_12         OBJ       13.05
    x6_12         OUT6     1
    x6_12         IN12      1
    x6_12         FLOW6    1
    x6_12         FLOW12   -1
    x6_12         CAP89    45
    x6_13         OBJ       42.21
    x6_13         OUT6     1
    x6_13         IN13      1
    x6_13         FLOW6    1
    x6_13         FLOW13   -1
    x6_13         CAP90    45
    x6_14         OBJ       31.17
    x6_14         OUT6     1
    x6_14         IN14      1
    x6_14         FLOW6    1
    x6_14         FLOW14   -1
    x6_14         CAP91    45
    x7_0          OBJ       20.71
    x7_0          OUT7     1
    x7_0          FLOW7    1
    x7_1          OBJ       25.54
    x7_1          OUT7     1
    x7_1          IN1      1
    x7_1          FLOW7    1
    x7_1          FLOW1   -1
    x7_1          CAP92    45
    x7_2          OBJ       40.25
    x7_2          OUT7     1
    x7_2          IN2      1
    x7_2          FLOW7    1
    x7_2          FLOW2   -1
    x7_2          CAP93    45
    x7_3          OBJ       16.91
    x7_3          OUT7     1
    x7_3          IN3      1
    x7_3          FLOW7    1
    x7_3          FLOW3   -1
    x7_3          CAP94    45
    x7_4          OBJ       32.84
    x7_4          OUT7     1
    x7_4          IN4      1
    x7_4          FLOW7    1
    x7_4          FLOW4   -1
    x7_4          CAP95    45
    x7_5          OBJ       46.56
    x7_5          OUT7     1
    x7_5          IN5      1
    x7_5          FLOW7    1
    x7_5          FLOW5   -1
    x7_5          CAP96    45
    x7_6          OBJ       22.58
    x7_6          OUT7     1
    x7_6          IN6      1
    x7_6          FLOW7    1
    x7_6          FLOW6   -1
    x7_6          CAP97    45
    x7_8          OBJ       24.56
    x7_8          OUT7     1
    x7_8          IN8      1
    x7_8          FLOW7    1
    x7_8          FLOW8   -1
    x7_8          CAP98    45
    x7_9          OBJ       36.26
    x7_9          OUT7     1
    x7_9          IN9      1
    x7_9          FLOW7    1
    x7_9          FLOW9   -1
    x7_9          CAP99    45
    x7_10         OBJ       30.96
    x7_10         OUT7     1
    x7_10         IN10      1
    x7_10         FLOW7    1
    x7_10         FLOW10   -1
    x7_10         CAP100    45
    x7_11         OBJ       12.51
    x7_11         OUT7     1
    x7_11         IN11      1
    x7_11         FLOW7    1
    x7_11         FLOW11   -1
    x7_11         CAP101    45
    x7_12         OBJ       20.20
    x7_12         OUT7     1
    x7_12         IN12      1
    x7_12         FLOW7    1
    x7_12         FLOW12   -1
    x7_12         CAP102    45
    x7_13         OBJ       31.42
    x7_13         OUT7     1
    x7_13         IN13      1
    x7_13         FLOW7    1
    x7_13         FLOW13   -1
    x7_13         CAP103    45
    x7_14         OBJ       41.78
    x7_14         OUT7     1
    x7_14         IN14      1
    x7_14         FLOW7    1
    x7_14         FLOW14   -1
    x7_14         CAP104    45
    x8_0          OBJ       6.78
    x8_0          OUT8     1
    x8_0          FLOW8    1
    x8_1          OBJ       20.17
    x8_1          OUT8     1
    x8_1          IN1      1
    x8_1          FLOW8    1
    x8_1          FLOW1   -1
    x8_1          CAP105    45
    x8_2          OBJ       15.69
    x8_2          OUT8     1
    x8_2          IN2      1
    x8_2          FLOW8    1
    x8_2          FLOW2   -1
    x8_2          CAP106    45
    x8_3          OBJ       26.71
    x8_3          OUT8     1
    x8_3          IN3      1
    x8_3          FLOW8    1
    x8_3          FLOW3   -1
    x8_3          CAP107    45
    x8_4          OBJ       10.78
    x8_4          OUT8     1
    x8_4          IN4      1
    x8_4          FLOW8    1
    x8_4          FLOW4   -1
    x8_4          CAP108    45
    x8_5          OBJ       47.82
    x8_5          OUT8     1
    x8_5          IN5      1
    x8_5          FLOW8    1
    x8_5          FLOW5   -1
    x8_5          CAP109    45
    x8_6          OBJ       14.21
    x8_6          OUT8     1
    x8_6          IN6      1
    x8_6          FLOW8    1
    x8_6          FLOW6   -1
    x8_6          CAP110    45
    x8_7          OBJ       24.56
    x8_7          OUT8     1
    x8_7          IN7      1
    x8_7          FLOW8    1
    x8_7          FLOW7   -1
    x8_7          CAP111    45
    x8_9          OBJ       25.05
    x8_9          OUT8     1
    x8_9          IN9      1
    x8_9          FLOW8    1
    x8_9          FLOW9   -1
    x8_9          CAP112    45
    x8_10         OBJ       12.28
    x8_10         OUT8     1
    x8_10         IN10      1
    x8_10         FLOW8    1
    x8_10         FLOW10   -1
    x8_10         CAP113    45
    x8_11         OBJ       36.36
    x8_11         OUT8     1
    x8_11         IN11      1
    x8_11         FLOW8    1
    x8_11         FLOW11   -1
    x8_11         CAP114    45
    x8_12         OBJ       25.84
    x8_12         OUT8     1
    x8_12         IN12      1
    x8_12         FLOW8    1
    x8_12         FLOW12   -1
    x8_12         CAP115    45
    x8_13         OBJ       31.33
    x8_13         OUT8     1
    x8_13         IN13      1
    x8_13         FLOW8    1
    x8_13         FLOW13   -1
    x8_13         CAP116    45
    x8_14         OBJ       18.55
    x8_14         OUT8     1
    x8_14         IN14      1
    x8_14         FLOW8    1
    x8_14         FLOW14   -1
    x8_14         CAP117    45
    x9_0          OBJ       30.71
    x9_0          OUT9     1
    x9_0          FLOW9    1
    x9_1          OBJ       10.92
    x9_1          OUT9     1
    x9_1          IN1      1
    x9_1          FLOW9    1
    x9_1          FLOW1   -1
    x9_1          CAP118    45
    x9_2          OBJ       28.77
    x9_2          OUT9     1
    x9_2          IN2      1
    x9_2          FLOW9    1
    x9_2          FLOW2   -1
    x9_2          CAP119    45
    x9_3          OBJ       24.23
    x9_3          OUT9     1
    x9_3          IN3      1
    x9_3          FLOW9    1
    x9_3          FLOW3   -1
    x9_3          CAP120    45
    x9_4          OBJ       33.38
    x9_4          OUT9     1
    x9_4          IN4      1
    x9_4          FLOW9    1
    x9_4          FLOW4   -1
    x9_4          CAP121    45
    x9_5          OBJ       26.28
    x9_5          OUT9     1
    x9_5          IN5      1
    x9_5          FLOW9    1
    x9_5          FLOW5   -1
    x9_5          CAP122    45
    x9_6          OBJ       38.65
    x9_6          OUT9     1
    x9_6          IN6      1
    x9_6          FLOW9    1
    x9_6          FLOW6   -1
    x9_6          CAP123    45
    x9_7          OBJ       36.26
    x9_7          OUT9     1
    x9_7          IN7      1
    x9_7          FLOW9    1
    x9_7          FLOW7   -1
    x9_7          CAP124    45
    x9_8          OBJ       25.05
    x9_8          OUT9     1
    x9_8          IN8      1
    x9_8          FLOW9    1
    x9_8          FLOW8   -1
    x9_8          CAP125    45
    x9_10         OBJ       36.62
    x9_10         OUT9     1
    x9_10         IN10      1
    x9_10         FLOW9    1
    x9_10         FLOW10   -1
    x9_10         CAP126    45
    x9_11         OBJ       42.69
    x9_11         OUT9     1
    x9_11         IN11      1
    x9_11         FLOW9    1
    x9_11         FLOW11   -1
    x9_11         CAP127    45
    x9_12         OBJ       47.99
    x9_12         OUT9     1
    x9_12         IN12      1
    x9_12         FLOW9    1
    x9_12         FLOW12   -1
    x9_12         CAP128    45
    x9_13         OBJ       14.42
    x9_13         OUT9     1
    x9_13         IN13      1
    x9_13         FLOW9    1
    x9_13         FLOW13   -1
    x9_13         CAP129    45
    x9_14         OBJ       21.67
    x9_14         OUT9     1
    x9_14         IN14      1
    x9_14         FLOW9    1
    x9_14         FLOW14   -1
    x9_14         CAP130    45
    x10_0         OBJ       10.79
    x10_0         OUT10     1
    x10_0         FLOW10    1
    x10_1         OBJ       32.45
    x10_1         OUT10     1
    x10_1         IN1      1
    x10_1         FLOW10    1
    x10_1         FLOW1   -1
    x10_1         CAP131    45
    x10_2         OBJ       16.20
    x10_2         OUT10     1
    x10_2         IN2      1
    x10_2         FLOW10    1
    x10_2         FLOW2   -1
    x10_2         CAP132    45
    x10_3         OBJ       37.70
    x10_3         OUT10     1
    x10_3         IN3      1
    x10_3         FLOW10    1
    x10_3         FLOW3   -1
    x10_3         CAP133    45
    x10_4         OBJ       4.81
    x10_4         OUT10     1
    x10_4         IN4      1
    x10_4         FLOW10    1
    x10_4         FLOW4   -1
    x10_4         CAP134    45
    x10_5         OBJ       60.10
    x10_5         OUT10     1
    x10_5         IN5      1
    x10_5         FLOW10    1
    x10_5         FLOW5   -1
    x10_5         CAP135    45
    x10_6         OBJ       10.27
    x10_6         OUT10     1
    x10_6         IN6      1
    x10_6         FLOW10    1
    x10_6         FLOW6   -1
    x10_6         CAP136    45
    x10_7         OBJ       30.96
    x10_7         OUT10     1
    x10_7         IN7      1
    x10_7         FLOW10    1
    x10_7         FLOW7   -1
    x10_7         CAP137    45
    x10_8         OBJ       12.28
    x10_8         OUT10     1
    x10_8         IN8      1
    x10_8         FLOW10    1
    x10_8         FLOW8   -1
    x10_8         CAP138    45
    x10_9         OBJ       36.62
    x10_9         OUT10     1
    x10_9         IN9      1
    x10_9         FLOW10    1
    x10_9         FLOW9   -1
    x10_9         CAP139    45
    x10_11        OBJ       43.46
    x10_11        OUT10     1
    x10_11        IN11      1
    x10_11        FLOW10    1
    x10_11        FLOW11   -1
    x10_11        CAP140    45
    x10_12        OBJ       22.96
    x10_12        OUT10     1
    x10_12        IN12      1
    x10_12        FLOW10    1
    x10_12        FLOW12   -1
    x10_12        CAP141    45
    x10_13        OBJ       43.60
    x10_13        OUT10     1
    x10_13        IN13      1
    x10_13        FLOW10    1
    x10_13        FLOW13   -1
    x10_13        CAP142    45
    x10_14        OBJ       23.78
    x10_14        OUT10     1
    x10_14        IN14      1
    x10_14        FLOW10    1
    x10_14        FLOW14   -1
    x10_14        CAP143    45
    x11_0         OBJ       33.11
    x11_0         OUT11     1
    x11_0         FLOW11    1
    x11_1         OBJ       31.87
    x11_1         OUT11     1
    x11_1         IN1      1
    x11_1         FLOW11    1
    x11_1         FLOW1   -1
    x11_1         CAP144    45
    x11_2         OBJ       51.96
    x11_2         OUT11     1
    x11_2         IN2      1
    x11_2         FLOW11    1
    x11_2         FLOW2   -1
    x11_2         CAP145    45
    x11_3         OBJ       18.93
    x11_3         OUT11     1
    x11_3         IN3      1
    x11_3         FLOW11    1
    x11_3         FLOW3   -1
    x11_3         CAP146    45
    x11_4         OBJ       45.22
    x11_4         OUT11     1
    x11_4         IN4      1
    x11_4         FLOW11    1
    x11_4         FLOW4   -1
    x11_4         CAP147    45
    x11_5         OBJ       45.76
    x11_5         OUT11     1
    x11_5         IN5      1
    x11_5         FLOW11    1
    x11_5         FLOW5   -1
    x11_5         CAP148    45
    x11_6         OBJ       34.93
    x11_6         OUT11     1
    x11_6         IN6      1
    x11_6         FLOW11    1
    x11_6         FLOW6   -1
    x11_6         CAP149    45
    x11_7         OBJ       12.51
    x11_7         OUT11     1
    x11_7         IN7      1
    x11_7         FLOW11    1
    x11_7         FLOW7   -1
    x11_7         CAP150    45
    x11_8         OBJ       36.36
    x11_8         OUT11     1
    x11_8         IN8      1
    x11_8         FLOW11    1
    x11_8         FLOW8   -1
    x11_8         CAP151    45
    x11_9         OBJ       42.69
    x11_9         OUT11     1
    x11_9         IN9      1
    x11_9         FLOW11    1
    x11_9         FLOW9   -1
    x11_9         CAP152    45
    x11_10        OBJ       43.46
    x11_10        OUT11     1
    x11_10        IN10      1
    x11_10        FLOW11    1
    x11_10        FLOW10   -1
    x11_10        CAP153    45
    x11_12        OBJ       30.25
    x11_12        OUT11     1
    x11_12        IN12      1
    x11_12        FLOW11    1
    x11_12        FLOW12   -1
    x11_12        CAP154    45
    x11_13        OBJ       33.73
    x11_13        OUT11     1
    x11_13        IN13      1
    x11_13        FLOW11    1
    x11_13        FLOW13   -1
    x11_13        CAP155    45
    x11_14        OBJ       52.42
    x11_14        OUT11     1
    x11_14        IN14      1
    x11_14        FLOW11    1
    x11_14        FLOW14   -1
    x11_14        CAP156    45
    x12_0         OBJ       19.06
    x12_0         OUT12     1
    x12_0         FLOW12    1
    x12_1         OBJ       39.14
    x12_1         OUT12     1
    x12_1         IN1      1
    x12_1         FLOW12    1
    x12_1         FLOW1   -1
    x12_1         CAP157    45
    x12_2         OBJ       38.19
    x12_2         OUT12     1
    x12_2         IN2      1
    x12_2         FLOW12    1
    x12_2         FLOW2   -1
    x12_2         CAP158    45
    x12_3         OBJ       35.65
    x12_3         OUT12     1
    x12_3         IN3      1
    x12_3         FLOW12    1
    x12_3         FLOW3   -1
    x12_3         CAP159    45
    x12_4         OBJ       27.21
    x12_4         OUT12     1
    x12_4         IN4      1
    x12_4         FLOW12    1
    x12_4         FLOW4   -1
    x12_4         CAP160    45
    x12_5         OBJ       64.53
    x12_5         OUT12     1
    x12_5         IN5      1
    x12_5         FLOW12    1
    x12_5         FLOW5   -1
    x12_5         CAP161    45
    x12_6         OBJ       13.05
    x12_6         OUT12     1
    x12_6         IN6      1
    x12_6         FLOW12    1
    x12_6         FLOW6   -1
    x12_6         CAP162    45
    x12_7         OBJ       20.20
    x12_7         OUT12     1
    x12_7         IN7      1
    x12_7         FLOW12    1
    x12_7         FLOW7   -1
    x12_7         CAP163    45
    x12_8         OBJ       25.84
    x12_8         OUT12     1
    x12_8         IN8      1
    x12_8         FLOW12    1
    x12_8         FLOW8   -1
    x12_8         CAP164    45
    x12_9         OBJ       47.99
    x12_9         OUT12     1
    x12_9         IN9      1
    x12_9         FLOW12    1
    x12_9         FLOW9   -1
    x12_9         CAP165    45
    x12_10        OBJ       22.96
    x12_10        OUT12     1
    x12_10        IN10      1
    x12_10        FLOW12    1
    x12_10        FLOW10   -1
    x12_10        CAP166    45
    x12_11        OBJ       30.25
    x12_11        OUT12     1
    x12_11        IN11      1
    x12_11        FLOW12    1
    x12_11        FLOW11   -1
    x12_11        CAP167    45
    x12_13        OBJ       48.13
    x12_13        OUT12     1
    x12_13        IN13      1
    x12_13        FLOW12    1
    x12_13        FLOW13   -1
    x12_13        CAP168    45
    x12_14        OBJ       43.83
    x12_14        OUT12     1
    x12_14        IN14      1
    x12_14        FLOW12    1
    x12_14        FLOW14   -1
    x12_14        CAP169    45
    x13_0         OBJ       34.82
    x13_0         OUT13     1
    x13_0         FLOW13    1
    x13_1         OBJ       11.19
    x13_1         OUT13     1
    x13_1         IN1      1
    x13_1         FLOW13    1
    x13_1         FLOW1   -1
    x13_1         CAP170    45
    x13_2         OBJ       40.24
    x13_2         OUT13     1
    x13_2         IN2      1
    x13_2         FLOW13    1
    x13_2         FLOW2   -1
    x13_2         CAP171    45
    x13_3         OBJ       15.17
    x13_3         OUT13     1
    x13_3         IN3      1
    x13_3         FLOW13    1
    x13_3         FLOW3   -1
    x13_3         CAP172    45
    x13_4         OBJ       41.63
    x13_4         OUT13     1
    x13_4         IN4      1
    x13_4         FLOW13    1
    x13_4         FLOW4   -1
    x13_4         CAP173    45
    x13_5         OBJ       16.83
    x13_5         OUT13     1
    x13_5         IN5      1
    x13_5         FLOW13    1
    x13_5         FLOW5   -1
    x13_5         CAP174    45
    x13_6         OBJ       42.21
    x13_6         OUT13     1
    x13_6         IN6      1
    x13_6         FLOW13    1
    x13_6         FLOW6   -1
    x13_6         CAP175    45
    x13_7         OBJ       31.42
    x13_7         OUT13     1
    x13_7         IN7      1
    x13_7         FLOW13    1
    x13_7         FLOW7   -1
    x13_7         CAP176    45
    x13_8         OBJ       31.33
    x13_8         OUT13     1
    x13_8         IN8      1
    x13_8         FLOW13    1
    x13_8         FLOW8   -1
    x13_8         CAP177    45
    x13_9         OBJ       14.42
    x13_9         OUT13     1
    x13_9         IN9      1
    x13_9         FLOW13    1
    x13_9         FLOW9   -1
    x13_9         CAP178    45
    x13_10        OBJ       43.60
    x13_10        OUT13     1
    x13_10        IN10      1
    x13_10        FLOW13    1
    x13_10        FLOW10   -1
    x13_10        CAP179    45
    x13_11        OBJ       33.73
    x13_11        OUT13     1
    x13_11        IN11      1
    x13_11        FLOW13    1
    x13_11        FLOW11   -1
    x13_11        CAP180    45
    x13_12        OBJ       48.13
    x13_12        OUT13     1
    x13_12        IN12      1
    x13_12        FLOW13    1
    x13_12        FLOW12   -1
    x13_12        CAP181    45
    x13_14        OBJ       34.73
    x13_14        OUT13     1
    x13_14        IN14      1
    x13_14        FLOW13    1
    x13_14        FLOW14   -1
    x13_14        CAP182    45
    x14_0         OBJ       25.03
    x14_0         OUT14     1
    x14_0         FLOW14    1
    x14_1         OBJ       25.53
    x14_1         OUT14     1
    x14_1         IN1      1
    x14_1         FLOW14    1
    x14_1         FLOW1   -1
    x14_1         CAP183    45
    x14_2         OBJ       9.10
    x14_2         OUT14     1
    x14_2         IN2      1
    x14_2         FLOW14    1
    x14_2         FLOW2   -1
    x14_2         CAP184    45
    x14_3         OBJ       38.01
    x14_3         OUT14     1
    x14_3         IN3      1
    x14_3         FLOW14    1
    x14_3         FLOW3   -1
    x14_3         CAP185    45
    x14_4         OBJ       19.07
    x14_4         OUT14     1
    x14_4         IN4      1
    x14_4         FLOW14    1
    x14_4         FLOW4   -1
    x14_4         CAP186    45
    x14_5         OBJ       47.93
    x14_5         OUT14     1
    x14_5         IN5      1
    x14_5         FLOW14    1
    x14_5         FLOW5   -1
    x14_5         CAP187    45
    x14_6         OBJ       31.17
    x14_6         OUT14     1
    x14_6         IN6      1
    x14_6         FLOW14    1
    x14_6         FLOW6   -1
    x14_6         CAP188    45
    x14_7         OBJ       41.78
    x14_7         OUT14     1
    x14_7         IN7      1
    x14_7         FLOW14    1
    x14_7         FLOW7   -1
    x14_7         CAP189    45
    x14_8         OBJ       18.55
    x14_8         OUT14     1
    x14_8         IN8      1
    x14_8         FLOW14    1
    x14_8         FLOW8   -1
    x14_8         CAP190    45
    x14_9         OBJ       21.67
    x14_9         OUT14     1
    x14_9         IN9      1
    x14_9         FLOW14    1
    x14_9         FLOW9   -1
    x14_9         CAP191    45
    x14_10        OBJ       23.78
    x14_10        OUT14     1
    x14_10        IN10      1
    x14_10        FLOW14    1
    x14_10        FLOW10   -1
    x14_10        CAP192    45
    x14_11        OBJ       52.42
    x14_11        OUT14     1
    x14_11        IN11      1
    x14_11        FLOW14    1
    x14_11        FLOW11   -1
    x14_11        CAP193    45
    x14_12        OBJ       43.83
    x14_12        OUT14     1
    x14_12        IN12      1
    x14_12        FLOW14    1
    x14_12        FLOW12   -1
    x14_12        CAP194    45
    x14_13        OBJ       34.73
    x14_13        OUT14     1
    x14_13        IN13      1
    x14_13        FLOW14    1
    x14_13        FLOW13   -1
    x14_13        CAP195    45
    MARK0000  'MARKER'                 'INTEND'
    u1            CAP0    -1
    u1            CAP14     1
    u1            CAP15     1
    u1            CAP16     1
    u1            CAP17     1
    u1            CAP18     1
    u1            CAP19     1
    u1            CAP20     1
    u1            CAP21     1
    u1            CAP22     1
    u1            CAP23     1
    u1            CAP24     1
    u1            CAP25     1
    u1            CAP26     1
    u1            CAP27    -1
    u1            CAP40    -1
    u1            CAP53    -1
    u1            CAP66    -1
    u1            CAP79    -1
    u1            CAP92    -1
    u1            CAP105    -1
    u1            CAP118    -1
    u1            CAP131    -1
    u1            CAP144    -1
    u1            CAP157    -1
    u1            CAP170    -1
    u1            CAP183    -1
    u1            DLBO1    1
    u1            DUBO1    1
    u2            CAP1    -1
    u2            CAP14    -1
    u2            CAP27     1
    u2            CAP28     1
    u2            CAP29     1
    u2            CAP30     1
    u2            CAP31     1
    u2            CAP32     1
    u2            CAP33     1
    u2            CAP34     1
    u2            CAP35     1
    u2            CAP36     1
    u2            CAP37     1
    u2            CAP38     1
    u2            CAP39     1
    u2            CAP41    -1
    u2            CAP54    -1
    u2            CAP67    -1
    u2            CAP80    -1
    u2            CAP93    -1
    u2            CAP106    -1
    u2            CAP119    -1
    u2            CAP132    -1
    u2            CAP145    -1
    u2            CAP158    -1
    u2            CAP171    -1
    u2            CAP184    -1
    u2            DLBO2    1
    u2            DUBO2    1
    u3            CAP2    -1
    u3            CAP15    -1
    u3            CAP28    -1
    u3            CAP40     1
    u3            CAP41     1
    u3            CAP42     1
    u3            CAP43     1
    u3            CAP44     1
    u3            CAP45     1
    u3            CAP46     1
    u3            CAP47     1
    u3            CAP48     1
    u3            CAP49     1
    u3            CAP50     1
    u3            CAP51     1
    u3            CAP52     1
    u3            CAP55    -1
    u3            CAP68    -1
    u3            CAP81    -1
    u3            CAP94    -1
    u3            CAP107    -1
    u3            CAP120    -1
    u3            CAP133    -1
    u3            CAP146    -1
    u3            CAP159    -1
    u3            CAP172    -1
    u3            CAP185    -1
    u3            DLBO3    1
    u3            DUBO3    1
    u4            CAP3    -1
    u4            CAP16    -1
    u4            CAP29    -1
    u4            CAP42    -1
    u4            CAP53     1
    u4            CAP54     1
    u4            CAP55     1
    u4            CAP56     1
    u4            CAP57     1
    u4            CAP58     1
    u4            CAP59     1
    u4            CAP60     1
    u4            CAP61     1
    u4            CAP62     1
    u4            CAP63     1
    u4            CAP64     1
    u4            CAP65     1
    u4            CAP69    -1
    u4            CAP82    -1
    u4            CAP95    -1
    u4            CAP108    -1
    u4            CAP121    -1
    u4            CAP134    -1
    u4            CAP147    -1
    u4            CAP160    -1
    u4            CAP173    -1
    u4            CAP186    -1
    u4            DLBO4    1
    u4            DUBO4    1
    u5            CAP4    -1
    u5            CAP17    -1
    u5            CAP30    -1
    u5            CAP43    -1
    u5            CAP56    -1
    u5            CAP66     1
    u5            CAP67     1
    u5            CAP68     1
    u5            CAP69     1
    u5            CAP70     1
    u5            CAP71     1
    u5            CAP72     1
    u5            CAP73     1
    u5            CAP74     1
    u5            CAP75     1
    u5            CAP76     1
    u5            CAP77     1
    u5            CAP78     1
    u5            CAP83    -1
    u5            CAP96    -1
    u5            CAP109    -1
    u5            CAP122    -1
    u5            CAP135    -1
    u5            CAP148    -1
    u5            CAP161    -1
    u5            CAP174    -1
    u5            CAP187    -1
    u5            DLBO5    1
    u5            DUBO5    1
    u6            CAP5    -1
    u6            CAP18    -1
    u6            CAP31    -1
    u6            CAP44    -1
    u6            CAP57    -1
    u6            CAP70    -1
    u6            CAP79     1
    u6            CAP80     1
    u6            CAP81     1
    u6            CAP82     1
    u6            CAP83     1
    u6            CAP84     1
    u6            CAP85     1
    u6            CAP86     1
    u6            CAP87     1
    u6            CAP88     1
    u6            CAP89     1
    u6            CAP90     1
    u6            CAP91     1
    u6            CAP97    -1
    u6            CAP110    -1
    u6            CAP123    -1
    u6            CAP136    -1
    u6            CAP149    -1
    u6            CAP162    -1
    u6            CAP175    -1
    u6            CAP188    -1
    u6            DLBO6    1
    u6            DUBO6    1
    u7            CAP6    -1
    u7            CAP19    -1
    u7            CAP32    -1
    u7            CAP45    -1
    u7            CAP58    -1
    u7            CAP71    -1
    u7            CAP84    -1
    u7            CAP92     1
    u7            CAP93     1
    u7            CAP94     1
    u7            CAP95     1
    u7            CAP96     1
    u7            CAP97     1
    u7            CAP98     1
    u7            CAP99     1
    u7            CAP100     1
    u7            CAP101     1
    u7            CAP102     1
    u7            CAP103     1
    u7            CAP104     1
    u7            CAP111    -1
    u7            CAP124    -1
    u7            CAP137    -1
    u7            CAP150    -1
    u7            CAP163    -1
    u7            CAP176    -1
    u7            CAP189    -1
    u7            DLBO7    1
    u7            DUBO7    1
    u8            CAP7    -1
    u8            CAP20    -1
    u8            CAP33    -1
    u8            CAP46    -1
    u8            CAP59    -1
    u8            CAP72    -1
    u8            CAP85    -1
    u8            CAP98    -1
    u8            CAP105     1
    u8            CAP106     1
    u8            CAP107     1
    u8            CAP108     1
    u8            CAP109     1
    u8            CAP110     1
    u8            CAP111     1
    u8            CAP112     1
    u8            CAP113     1
    u8            CAP114     1
    u8            CAP115     1
    u8            CAP116     1
    u8            CAP117     1
    u8            CAP125    -1
    u8            CAP138    -1
    u8            CAP151    -1
    u8            CAP164    -1
    u8            CAP177    -1
    u8            CAP190    -1
    u8            DLBO8    1
    u8            DUBO8    1
    u9            CAP8    -1
    u9            CAP21    -1
    u9            CAP34    -1
    u9            CAP47    -1
    u9            CAP60    -1
    u9            CAP73    -1
    u9            CAP86    -1
    u9            CAP99    -1
    u9            CAP112    -1
    u9            CAP118     1
    u9            CAP119     1
    u9            CAP120     1
    u9            CAP121     1
    u9            CAP122     1
    u9            CAP123     1
    u9            CAP124     1
    u9            CAP125     1
    u9            CAP126     1
    u9            CAP127     1
    u9            CAP128     1
    u9            CAP129     1
    u9            CAP130     1
    u9            CAP139    -1
    u9            CAP152    -1
    u9            CAP165    -1
    u9            CAP178    -1
    u9            CAP191    -1
    u9            DLBO9    1
    u9            DUBO9    1
    u10           CAP9    -1
    u10           CAP22    -1
    u10           CAP35    -1
    u10           CAP48    -1
    u10           CAP61    -1
    u10           CAP74    -1
    u10           CAP87    -1
    u10           CAP100    -1
    u10           CAP113    -1
    u10           CAP126    -1
    u10           CAP131     1
    u10           CAP132     1
    u10           CAP133     1
    u10           CAP134     1
    u10           CAP135     1
    u10           CAP136     1
    u10           CAP137     1
    u10           CAP138     1
    u10           CAP139     1
    u10           CAP140     1
    u10           CAP141     1
    u10           CAP142     1
    u10           CAP143     1
    u10           CAP153    -1
    u10           CAP166    -1
    u10           CAP179    -1
    u10           CAP192    -1
    u10           DLBO10    1
    u10           DUBO10    1
    u11           CAP10    -1
    u11           CAP23    -1
    u11           CAP36    -1
    u11           CAP49    -1
    u11           CAP62    -1
    u11           CAP75    -1
    u11           CAP88    -1
    u11           CAP101    -1
    u11           CAP114    -1
    u11           CAP127    -1
    u11           CAP140    -1
    u11           CAP144     1
    u11           CAP145     1
    u11           CAP146     1
    u11           CAP147     1
    u11           CAP148     1
    u11           CAP149     1
    u11           CAP150     1
    u11           CAP151     1
    u11           CAP152     1
    u11           CAP153     1
    u11           CAP154     1
    u11           CAP155     1
    u11           CAP156     1
    u11           CAP167    -1
    u11           CAP180    -1
    u11           CAP193    -1
    u11           DLBO11    1
    u11           DUBO11    1
    u12           CAP11    -1
    u12           CAP24    -1
    u12           CAP37    -1
    u12           CAP50    -1
    u12           CAP63    -1
    u12           CAP76    -1
    u12           CAP89    -1
    u12           CAP102    -1
    u12           CAP115    -1
    u12           CAP128    -1
    u12           CAP141    -1
    u12           CAP154    -1
    u12           CAP157     1
    u12           CAP158     1
    u12           CAP159     1
    u12           CAP160     1
    u12           CAP161     1
    u12           CAP162     1
    u12           CAP163     1
    u12           CAP164     1
    u12           CAP165     1
    u12           CAP166     1
    u12           CAP167     1
    u12           CAP168     1
    u12           CAP169     1
    u12           CAP181    -1
    u12           CAP194    -1
    u12           DLBO12    1
    u12           DUBO12    1
    u13           CAP12    -1
    u13           CAP25    -1
    u13           CAP38    -1
    u13           CAP51    -1
    u13           CAP64    -1
    u13           CAP77    -1
    u13           CAP90    -1
    u13           CAP103    -1
    u13           CAP116    -1
    u13           CAP129    -1
    u13           CAP142    -1
    u13           CAP155    -1
    u13           CAP168    -1
    u13           CAP170     1
    u13           CAP171     1
    u13           CAP172     1
    u13           CAP173     1
    u13           CAP174     1
    u13           CAP175     1
    u13           CAP176     1
    u13           CAP177     1
    u13           CAP178     1
    u13           CAP179     1
    u13           CAP180     1
    u13           CAP181     1
    u13           CAP182     1
    u13           CAP195    -1
    u13           DLBO13    1
    u13           DUBO13    1
    u14           CAP13    -1
    u14           CAP26    -1
    u14           CAP39    -1
    u14           CAP52    -1
    u14           CAP65    -1
    u14           CAP78    -1
    u14           CAP91    -1
    u14           CAP104    -1
    u14           CAP117    -1
    u14           CAP130    -1
    u14           CAP143    -1
    u14           CAP156    -1
    u14           CAP169    -1
    u14           CAP182    -1
    u14           CAP183     1
    u14           CAP184     1
    u14           CAP185     1
    u14           CAP186     1
    u14           CAP187     1
    u14           CAP188     1
    u14           CAP189     1
    u14           CAP190     1
    u14           CAP191     1
    u14           CAP192     1
    u14           CAP193     1
    u14           CAP194     1
    u14           CAP195     1
    u14           DLBO14    1
    u14           DUBO14    1
RHS
    RHS1      OUT1      1
    RHS1      IN1       1
    RHS1      OUT2      1
    RHS1      IN2       1
    RHS1      OUT3      1
    RHS1      IN3       1
    RHS1      OUT4      1
    RHS1      IN4       1
    RHS1      OUT5      1
    RHS1      IN5       1
    RHS1      OUT6      1
    RHS1      IN6       1
    RHS1      OUT7      1
    RHS1      IN7       1
    RHS1      OUT8      1
    RHS1      IN8       1
    RHS1      OUT9      1
    RHS1      IN9       1
    RHS1      OUT10      1
    RHS1      IN10       1
    RHS1      OUT11      1
    RHS1      IN11       1
    RHS1      OUT12      1
    RHS1      IN12       1
    RHS1      OUT13      1
    RHS1      IN13       1
    RHS1      OUT14      1
    RHS1      IN14       1
    RHS1      FLEET      2
    RHS1      CAP0     39
    RHS1      CAP1     41
    RHS1      CAP2     41
    RHS1      CAP3     39
    RHS1      CAP4     40
    RHS1      CAP5     41
    RHS1      CAP6     41
    RHS1      CAP7     41
    RHS1      CAP8     39
    RHS1      CAP9     41
    RHS1      CAP10     39
    RHS1      CAP11     39
    RHS1      CAP12     39
    RHS1      CAP13     41
    RHS1      CAP14     41
    RHS1      CAP15     41
    RHS1      CAP16     39
    RHS1      CAP17     40
    RHS1      CAP18     41
    RHS1      CAP19     41
    RHS1      CAP20     41
    RHS1      CAP21     39
    RHS1      CAP22     41
    RHS1      CAP23     39
    RHS1      CAP24     39
    RHS1      CAP25     39
    RHS1      CAP26     41
    RHS1      CAP27     39
    RHS1      CAP28     41
    RHS1      CAP29     39
    RHS1      CAP30     40
    RHS1      CAP31     41
    RHS1      CAP32     41
    RHS1      CAP33     41
    RHS1      CAP34     39
    RHS1      CAP35     41
    RHS1      CAP36     39
    RHS1      CAP37     39
    RHS1      CAP38     39
    RHS1      CAP39     41
    RHS1      CAP40     39
    RHS1      CAP41     41
    RHS1      CAP42     39
    RHS1      CAP43     40
    RHS1      CAP44     41
    RHS1      CAP45     41
    RHS1      CAP46     41
    RHS1      CAP47     39
    RHS1      CAP48     41
    RHS1      CAP49     39
    RHS1      CAP50     39
    RHS1      CAP51     39
    RHS1      CAP52     41
    RHS1      CAP53     39
    RHS1      CAP54     41
    RHS1      CAP55     41
    RHS1      CAP56     40
    RHS1      CAP57     41
    RHS1      CAP58     41
    RHS1      CAP59     41
    RHS1      CAP60     39
    RHS1      CAP61     41
    RHS1      CAP62     39
    RHS1      CAP63     39
    RHS1      CAP64     39
    RHS1      CAP65     41
    RHS1      CAP66     39
    RHS1      CAP67     41
    RHS1      CAP68     41
    RHS1      CAP69     39
    RHS1      CAP70     41
    RHS1      CAP71     41
    RHS1      CAP72     41
    RHS1      CAP73     39
    RHS1      CAP74     41
    RHS1      CAP75     39
    RHS1      CAP76     39
    RHS1      CAP77     39
    RHS1      CAP78     41
    RHS1      CAP79     39
    RHS1      CAP80     41
    RHS1      CAP81     41
    RHS1      CAP82     39
    RHS1      CAP83     40
    RHS1      CAP84     41
    RHS1      CAP85     41
    RHS1      CAP86     39
    RHS1      CAP87     41
    RHS1      CAP88     39
    RHS1      CAP89     39
    RHS1      CAP90     39
    RHS1      CAP91     41
    RHS1      CAP92     39
    RHS1      CAP93     41
    RHS1      CAP94     41
    RHS1      CAP95     39
    RHS1      CAP96     40
    RHS1      CAP97     41
    RHS1      CAP98     41
    RHS1      CAP99     39
    RHS1      CAP100     41
    RHS1      CAP101     39
    RHS1      CAP102     39
    RHS1      CAP103     39
    RHS1      CAP104     41
    RHS1      CAP105     39
    RHS1      CAP106     41
    RHS1      CAP107     41
    RHS1      CAP108     39
    RHS1      CAP109     40
    RHS1      CAP110     41
    RHS1      CAP111     41
    RHS1      CAP112     39
    RHS1      CAP113     41
    RHS1      CAP114     39
    RHS1      CAP115     39
    RHS1      CAP116     39
    RHS1      CAP117     41
    RHS1      CAP118     39
    RHS1      CAP119     41
    RHS1      CAP120     41
    RHS1      CAP121     39
    RHS1      CAP122     40
    RHS1      CAP123     41
    RHS1      CAP124     41
    RHS1      CAP125     41
    RHS1      CAP126     41
    RHS1      CAP127     39
    RHS1      CAP128     39
    RHS1      CAP129     39
    RHS1      CAP130     41
    RHS1      CAP131     39
    RHS1      CAP132     41
    RHS1      CAP133     41
    RHS1      CAP134     39
    RHS1      CAP135     40
    RHS1      CAP136     41
    RHS1      CAP137     41
    RHS1      CAP138     41
    RHS1      CAP139     39
    RHS1      CAP140     39
    RHS1      CAP141     39
    RHS1      CAP142     39
    RHS1      CAP143     41
    RHS1      CAP144     39
    RHS1      CAP145     41
    RHS1      CAP146     41
    RHS1      CAP147     39
    RHS1      CAP148     40
    RHS1      CAP149     41
    RHS1      CAP150     41
    RHS1      CAP151     41
    RHS1      CAP152     39
    RHS1      CAP153     41
    RHS1      CAP154     39
    RHS1      CAP155     39
    RHS1      CAP156     41
    RHS1      CAP157     39
    RHS1      CAP158     41
    RHS1      CAP159     41
    RHS1      CAP160     39
    RHS1      CAP161     40
    RHS1      CAP162     41
    RHS1      CAP163     41
    RHS1      CAP164     41
    RHS1      CAP165     39
    RHS1      CAP166     41
    RHS1      CAP167     39
    RHS1      CAP168     39
    RHS1      CAP169     41
    RHS1      CAP170     39
    RHS1      CAP171     41
    RHS1      CAP172     41
    RHS1      CAP173     39
    RHS1      CAP174     40
    RHS1      CAP175     41
    RHS1      CAP176     41
    RHS1      CAP177     41
    RHS1      CAP178     39
    RHS1      CAP179     41
    RHS1      CAP180     39
    RHS1      CAP181     39
    RHS1      CAP182     41
    RHS1      CAP183     39
    RHS1      CAP184     41
    RHS1      CAP185     41
    RHS1      CAP186     39
    RHS1      CAP187     40
    RHS1      CAP188     41
    RHS1      CAP189     41
    RHS1      CAP190     41
    RHS1      CAP191     39
    RHS1      CAP192     41
    RHS1      CAP193     39
    RHS1      CAP194     39
    RHS1      CAP195     39
    RHS1      DLBO1    6
    RHS1      DUBO1    45
    RHS1      DLBO2    4
    RHS1      DUBO2    45
    RHS1      DLBO3    4
    RHS1      DUBO3    45
    RHS1      DLBO4    6
    RHS1      DUBO4    45
    RHS1      DLBO5    5
    RHS1      DUBO5    45
    RHS1      DLBO6    4
    RHS1      DUBO6    45
    RHS1      DLBO7    4
    RHS1      DUBO7    45
    RHS1      DLBO8    4
    RHS1      DUBO8    45
    RHS1      DLBO9    6
    RHS1      DUBO9    45
    RHS1      DLBO10    4
    RHS1      DUBO10    45
    RHS1      DLBO11    6
    RHS1      DUBO11    45
    RHS1      DLBO12    6
    RHS1      DUBO12    45
    RHS1      DLBO13    6
    RHS1      DUBO13    45
    RHS1      DLBO14    4
    RHS1      DUBO14    45
BOUNDS
ENDATA
