NAME          sppc_t60_p180_c60_s8
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 E  PART_4
 E  PART_5
 E  PART_6
 E  PART_7
 E  PART_8
 E  PART_9
 E  PART_10
 E  PART_11
 E  PART_12
 E  PART_13
 E  PART_14
 E  PART_15
 E  PART_16
 E  PART_17
 E  PART_18
 E  PART_19
 E  PART_20
 E  PART_21
 E  PART_22
 E  PART_23
 E  PART_24
 E  PART_25
 E  PART_26
 E  PART_27
 E  PART_28
 E  PART_29
 E  PART_30
 E  PART_31
 E  PART_32
 E  PART_33
 E  PART_34
 E  PART_35
 E  PART_36
 E  PART_37
 E  PART_38
 E  PART_39
 E  PART_40
 E  PART_41
 E  PART_42
 E  PART_43
 E  PART_44
 E  PART_45
 E  PART_46
 E  PART_47
 E  PART_48
 E  PART_49
 E  PART_50
 E  PART_51
 E  PART_52
 E  PART_53
 E  PART_54
 E  PART_55
 E  PART_56
 E  PART_57
 E  PART_58
 E  PART_59
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
 L  PACK_20
 L  PACK_21
 L  PACK_22
 L  PACK_23
 L  PACK_24
 L  PACK_25
 L  PACK_26
 L  PACK_27
 L  PACK_28
 L  PACK_29
 L  PACK_30
 L  PACK_31
 L  PACK_32
 L  PACK_33
 L  PACK_34
 L  PACK_35
 L  PACK_36
 L  PACK_37
 L  PACK_38
 L  PACK_39
 L  PACK_40
 L  PACK_41
 L  PACK_42
 L  PACK_43
 L  PACK_44
 L  PACK_45
 L  PACK_46
 L  PACK_47
 L  PACK_48
 L  PACK_49
 L  PACK_50
 L  PACK_51
 L  PACK_52
 L  PACK_53
 L  PACK_54
 L  PACK_55
 L  PACK_56
 L  PACK_57
 L  PACK_58
 L  PACK_59
 L  PACK_60
 L  PACK_61
 L  PACK_62
 L  PACK_63
 L  PACK_64
 L  PACK_65
 L  PACK_66
 L  PACK_67
 L  PACK_68
 L  PACK_69
 L  PACK_70
 L  PACK_71
 L  PACK_72
 L  PACK_73
 L  PACK_74
 L  PACK_75
 L  PACK_76
 L  PACK_77
 L  PACK_78
 L  PACK_79
 L  PACK_80
 L  PACK_81
 L  PACK_82
 L  PACK_83
 L  PACK_84
 L  PACK_85
 L  PACK_86
 L  PACK_87
 L  PACK_88
 L  PACK_89
 L  PACK_90
 L  PACK_91
 L  PACK_92
 L  PACK_93
 L  PACK_94
 L  PACK_95
 L  PACK_96
 L  PACK_97
 L  PACK_98
 L  PACK_99
 L  PACK_100
 L  PACK_101
 L  PACK_102
 L  PACK_103
 L  PACK_104
 L  PACK_105
 L  PACK_106
 L  PACK_107
 L  PACK_108
 L  PACK_109
 L  PACK_110
 L  PACK_111
 L  PACK_112
 L  PACK_113
 L  PACK_114
 L  PACK_115
 L  PACK_116
 L  PACK_117
 L  PACK_118
 L  PACK_119
 L  PACK_120
 L  PACK_121
 L  PACK_122
 L  PACK_123
 L  PACK_124
 L  PACK_125
 L  PACK_126
 L  PACK_127
 L  PACK_128
 L  PACK_129
 L  PACK_130
 L  PACK_131
 L  PACK_132
 L  PACK_133
 L  PACK_134
 L  PACK_135
 L  PACK_136
 L  PACK_137
 L  PACK_138
 L  PACK_139
 L  PACK_140
 L  PACK_141
 L  PACK_142
 L  PACK_143
 L  PACK_144
 L  PACK_145
 L  PACK_146
 L  PACK_147
 L  PACK_148
 L  PACK_149
 L  PACK_150
 L  PACK_151
 L  PACK_152
 L  PACK_153
 L  PACK_154
 L  PACK_155
 L  PACK_156
 L  PACK_157
 L  PACK_158
 L  PACK_159
 L  PACK_160
 L  PACK_161
 L  PACK_162
 L  PACK_163
 L  PACK_164
 L  PACK_165
 L  PACK_166
 L  PACK_167
 L  PACK_168
 L  PACK_169
 L  PACK_170
 L  PACK_171
 L  PACK_172
 L  PACK_173
 L  PACK_174
 L  PACK_175
 L  PACK_176
 L  PACK_177
 L  PACK_178
 L  PACK_179
 G  COVER_0
 G  COVER_1
 G  COVER_2
 G  COVER_3
 G  COVER_4
 G  COVER_5
 G  COVER_6
 G  COVER_7
 G  COVER_8
 G  COVER_9
 G  COVER_10
 G  COVER_11
 G  COVER_12
 G  COVER_13
 G  COVER_14
 G  COVER_15
 G  COVER_16
 G  COVER_17
 G  COVER_18
 G  COVER_19
 G  COVER_20
 G  COVER_21
 G  COVER_22
 G  COVER_23
 G  COVER_24
 G  COVER_25
 G  COVER_26
 G  COVER_27
 G  COVER_28
 G  COVER_29
 G  COVER_30
 G  COVER_31
 G  COVER_32
 G  COVER_33
 G  COVER_34
 G  COVER_35
 G  COVER_36
 G  COVER_37
 G  COVER_38
 G  COVER_39
 G  COVER_40
 G  COVER_41
 G  COVER_42
 G  COVER_43
 G  COVER_44
 G  COVER_45
 G  COVER_46
 G  COVER_47
 G  COVER_48
 G  COVER_49
 G  COVER_50
 G  COVER_51
 G  COVER_52
 G  COVER_53
 G  COVER_54
 G  COVER_55
 G  COVER_56
 G  COVER_57
 G  COVER_58
 G  COVER_59
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0             OBJ           17
    x_0             PART_0          1.0
    x_0             PACK_47         1.0
    x_0             PACK_54         1.0
    x_0             PACK_153        1.0
    x_0             PACK_177        1.0
    x_1             OBJ           9
    x_1             PART_0          1.0
    x_1             PACK_138        1.0
    x_1             COVER_0         1.0
    x_1             COVER_44        1.0
    x_2             OBJ           25
    x_2             PART_0          1.0
    x_2             COVER_29        1.0
    x_2             COVER_32        1.0
    x_3             OBJ           6
    x_3             PART_0          1.0
    x_3             PACK_2          1.0
    x_3             PACK_81         1.0
    x_3             PACK_90         1.0
    x_3             PACK_144        1.0
    x_3             PACK_151        1.0
    x_3             COVER_6         1.0
    x_3             COVER_28        1.0
    x_3             COVER_51        1.0
    x_4             OBJ           25
    x_4             PART_1          1.0
    x_4             PACK_150        1.0
    x_4             COVER_19        1.0
    x_4             COVER_45        1.0
    x_5             OBJ           21
    x_5             PART_1          1.0
    x_5             PACK_17         1.0
    x_5             PACK_21         1.0
    x_5             PACK_72         1.0
    x_5             PACK_160        1.0
    x_6             OBJ           11
    x_6             PART_1          1.0
    x_6             PACK_11         1.0
    x_6             PACK_23         1.0
    x_6             PACK_26         1.0
    x_6             PACK_103        1.0
    x_6             PACK_108        1.0
    x_6             PACK_133        1.0
    x_6             COVER_14        1.0
    x_6             COVER_34        1.0
    x_7             OBJ           5
    x_7             PART_2          1.0
    x_7             PACK_31         1.0
    x_7             PACK_51         1.0
    x_7             PACK_52         1.0
    x_7             PACK_66         1.0
    x_7             COVER_23        1.0
    x_8             OBJ           19
    x_8             PART_2          1.0
    x_8             PACK_9          1.0
    x_8             COVER_35        1.0
    x_9             OBJ           20
    x_9             PART_2          1.0
    x_9             PACK_116        1.0
    x_9             PACK_126        1.0
    x_9             PACK_147        1.0
    x_9             PACK_152        1.0
    x_9             PACK_177        1.0
    x_10            OBJ           19
    x_10            PART_2          1.0
    x_10            PACK_62         1.0
    x_10            PACK_65         1.0
    x_10            PACK_77         1.0
    x_10            PACK_94         1.0
    x_10            PACK_154        1.0
    x_11            OBJ           17
    x_11            PART_2          1.0
    x_11            PACK_25         1.0
    x_11            PACK_29         1.0
    x_11            PACK_56         1.0
    x_11            COVER_31        1.0
    x_11            COVER_41        1.0
    x_11            COVER_43        1.0
    x_12            OBJ           29
    x_12            PART_2          1.0
    x_12            PACK_3          1.0
    x_12            PACK_102        1.0
    x_12            PACK_137        1.0
    x_12            COVER_58        1.0
    x_13            OBJ           7
    x_13            PART_3          1.0
    x_13            PACK_82         1.0
    x_13            PACK_114        1.0
    x_13            PACK_125        1.0
    x_13            COVER_1         1.0
    x_13            COVER_4         1.0
    x_13            COVER_28        1.0
    x_13            COVER_31        1.0
    x_13            COVER_44        1.0
    x_14            OBJ           20
    x_14            PART_3          1.0
    x_14            PACK_22         1.0
    x_14            PACK_61         1.0
    x_14            PACK_138        1.0
    x_14            PACK_146        1.0
    x_15            OBJ           12
    x_15            PART_3          1.0
    x_15            PACK_81         1.0
    x_15            PACK_123        1.0
    x_15            PACK_152        1.0
    x_15            COVER_22        1.0
    x_16            OBJ           22
    x_16            PART_3          1.0
    x_16            PACK_101        1.0
    x_16            COVER_3         1.0
    x_17            OBJ           18
    x_17            PART_4          1.0
    x_17            PACK_53         1.0
    x_17            COVER_8         1.0
    x_17            COVER_57        1.0
    x_18            OBJ           20
    x_18            PART_4          1.0
    x_18            PACK_90         1.0
    x_18            PACK_108        1.0
    x_18            PACK_138        1.0
    x_19            OBJ           17
    x_19            PART_4          1.0
    x_19            PACK_135        1.0
    x_19            PACK_146        1.0
    x_20            OBJ           8
    x_20            PART_4          1.0
    x_20            PACK_64         1.0
    x_20            PACK_84         1.0
    x_20            PACK_89         1.0
    x_20            PACK_126        1.0
    x_20            PACK_140        1.0
    x_20            PACK_143        1.0
    x_20            PACK_166        1.0
    x_21            OBJ           26
    x_21            PART_4          1.0
    x_22            OBJ           28
    x_22            PART_5          1.0
    x_22            PACK_28         1.0
    x_22            PACK_121        1.0
    x_22            PACK_163        1.0
    x_22            COVER_39        1.0
    x_23            OBJ           17
    x_23            PART_5          1.0
    x_23            PACK_97         1.0
    x_23            PACK_105        1.0
    x_23            PACK_111        1.0
    x_23            PACK_179        1.0
    x_23            COVER_32        1.0
    x_24            OBJ           8
    x_24            PART_5          1.0
    x_24            PACK_136        1.0
    x_24            PACK_176        1.0
    x_25            OBJ           12
    x_25            PART_6          1.0
    x_25            PACK_7          1.0
    x_25            PACK_17         1.0
    x_25            PACK_40         1.0
    x_25            PACK_42         1.0
    x_25            PACK_61         1.0
    x_25            PACK_88         1.0
    x_25            PACK_93         1.0
    x_25            PACK_131        1.0
    x_26            OBJ           23
    x_26            PART_6          1.0
    x_26            COVER_48        1.0
    x_26            COVER_49        1.0
    x_26            COVER_56        1.0
    x_27            OBJ           20
    x_27            PART_6          1.0
    x_27            PACK_35         1.0
    x_27            PACK_127        1.0
    x_27            PACK_142        1.0
    x_27            PACK_177        1.0
    x_28            OBJ           7
    x_28            PART_7          1.0
    x_28            PACK_28         1.0
    x_28            PACK_91         1.0
    x_29            OBJ           30
    x_29            PART_7          1.0
    x_29            PACK_73         1.0
    x_29            PACK_146        1.0
    x_29            COVER_16        1.0
    x_29            COVER_22        1.0
    x_29            COVER_30        1.0
    x_30            OBJ           6
    x_30            PART_7          1.0
    x_30            PACK_1          1.0
    x_30            PACK_112        1.0
    x_30            PACK_131        1.0
    x_30            PACK_166        1.0
    x_30            PACK_171        1.0
    x_30            COVER_58        1.0
    x_31            OBJ           20
    x_31            PART_7          1.0
    x_31            PACK_2          1.0
    x_31            PACK_144        1.0
    x_31            PACK_161        1.0
    x_31            PACK_164        1.0
    x_31            PACK_167        1.0
    x_31            COVER_0         1.0
    x_31            COVER_36        1.0
    x_31            COVER_57        1.0
    x_32            OBJ           19
    x_32            PART_8          1.0
    x_32            PACK_6          1.0
    x_32            PACK_9          1.0
    x_32            PACK_14         1.0
    x_32            PACK_65         1.0
    x_32            PACK_77         1.0
    x_32            PACK_132        1.0
    x_33            OBJ           29
    x_33            PART_8          1.0
    x_34            OBJ           14
    x_34            PART_8          1.0
    x_34            PACK_47         1.0
    x_34            PACK_145        1.0
    x_34            PACK_149        1.0
    x_34            PACK_153        1.0
    x_34            PACK_163        1.0
    x_35            OBJ           22
    x_35            PART_8          1.0
    x_35            PACK_35         1.0
    x_35            PACK_86         1.0
    x_35            PACK_96         1.0
    x_35            PACK_157        1.0
    x_36            OBJ           9
    x_36            PART_9          1.0
    x_36            PACK_3          1.0
    x_36            PACK_62         1.0
    x_36            PACK_63         1.0
    x_36            PACK_75         1.0
    x_36            PACK_86         1.0
    x_36            PACK_108        1.0
    x_36            PACK_110        1.0
    x_36            COVER_16        1.0
    x_37            OBJ           10
    x_37            PART_9          1.0
    x_37            PACK_60         1.0
    x_37            COVER_2         1.0
    x_38            OBJ           8
    x_38            PART_9          1.0
    x_38            PACK_36         1.0
    x_38            PACK_43         1.0
    x_38            PACK_100        1.0
    x_38            PACK_177        1.0
    x_38            COVER_32        1.0
    x_39            OBJ           30
    x_39            PART_9          1.0
    x_39            PACK_157        1.0
    x_40            OBJ           15
    x_40            PART_9          1.0
    x_40            PACK_2          1.0
    x_40            PACK_72         1.0
    x_40            PACK_102        1.0
    x_40            PACK_144        1.0
    x_40            COVER_13        1.0
    x_40            COVER_21        1.0
    x_41            OBJ           21
    x_41            PART_10         1.0
    x_41            PACK_10         1.0
    x_41            PACK_15         1.0
    x_41            PACK_76         1.0
    x_41            PACK_132        1.0
    x_41            PACK_153        1.0
    x_41            PACK_175        1.0
    x_41            COVER_0         1.0
    x_41            COVER_37        1.0
    x_41            COVER_54        1.0
    x_42            OBJ           11
    x_42            PART_10         1.0
    x_42            PACK_12         1.0
    x_42            PACK_44         1.0
    x_42            PACK_65         1.0
    x_42            PACK_70         1.0
    x_42            PACK_107        1.0
    x_42            PACK_113        1.0
    x_43            OBJ           14
    x_43            PART_10         1.0
    x_43            PACK_40         1.0
    x_43            PACK_83         1.0
    x_43            PACK_174        1.0
    x_43            COVER_0         1.0
    x_43            COVER_53        1.0
    x_44            OBJ           24
    x_44            PART_10         1.0
    x_44            PACK_155        1.0
    x_44            COVER_55        1.0
    x_45            OBJ           16
    x_45            PART_10         1.0
    x_45            PACK_64         1.0
    x_45            PACK_89         1.0
    x_45            COVER_10        1.0
    x_45            COVER_55        1.0
    x_46            OBJ           7
    x_46            PART_11         1.0
    x_46            PACK_13         1.0
    x_46            PACK_83         1.0
    x_46            PACK_85         1.0
    x_46            COVER_7         1.0
    x_47            OBJ           21
    x_47            PART_11         1.0
    x_47            PACK_29         1.0
    x_47            PACK_35         1.0
    x_47            PACK_65         1.0
    x_47            PACK_91         1.0
    x_47            PACK_112        1.0
    x_47            PACK_118        1.0
    x_48            OBJ           22
    x_48            PART_11         1.0
    x_48            PACK_36         1.0
    x_48            PACK_160        1.0
    x_48            COVER_27        1.0
    x_49            OBJ           12
    x_49            PART_11         1.0
    x_49            PACK_19         1.0
    x_49            PACK_58         1.0
    x_49            PACK_69         1.0
    x_49            PACK_79         1.0
    x_49            PACK_80         1.0
    x_49            PACK_87         1.0
    x_49            PACK_141        1.0
    x_49            PACK_167        1.0
    x_49            COVER_11        1.0
    x_50            OBJ           27
    x_50            PART_11         1.0
    x_50            COVER_12        1.0
    x_50            COVER_13        1.0
    x_50            COVER_24        1.0
    x_50            COVER_42        1.0
    x_50            COVER_59        1.0
    x_51            OBJ           26
    x_51            PART_12         1.0
    x_51            PACK_42         1.0
    x_51            COVER_13        1.0
    x_51            COVER_46        1.0
    x_52            OBJ           15
    x_52            PART_12         1.0
    x_52            PACK_2          1.0
    x_52            PACK_82         1.0
    x_52            PACK_98         1.0
    x_52            PACK_133        1.0
    x_53            OBJ           12
    x_53            PART_12         1.0
    x_53            PACK_18         1.0
    x_53            PACK_56         1.0
    x_53            PACK_119        1.0
    x_53            COVER_47        1.0
    x_54            OBJ           13
    x_54            PART_12         1.0
    x_54            PACK_57         1.0
    x_54            PACK_93         1.0
    x_54            PACK_96         1.0
    x_54            PACK_103        1.0
    x_54            PACK_160        1.0
    x_54            COVER_55        1.0
    x_55            OBJ           13
    x_55            PART_13         1.0
    x_55            PACK_113        1.0
    x_55            PACK_116        1.0
    x_55            COVER_40        1.0
    x_56            OBJ           28
    x_56            PART_13         1.0
    x_56            COVER_8         1.0
    x_56            COVER_31        1.0
    x_56            COVER_44        1.0
    x_57            OBJ           14
    x_57            PART_13         1.0
    x_57            PACK_55         1.0
    x_57            PACK_156        1.0
    x_58            OBJ           17
    x_58            PART_14         1.0
    x_58            PACK_26         1.0
    x_58            PACK_35         1.0
    x_58            PACK_88         1.0
    x_58            PACK_92         1.0
    x_58            PACK_131        1.0
    x_59            OBJ           23
    x_59            PART_14         1.0
    x_59            PACK_177        1.0
    x_59            COVER_40        1.0
    x_60            OBJ           10
    x_60            PART_14         1.0
    x_60            PACK_95         1.0
    x_60            PACK_154        1.0
    x_60            PACK_174        1.0
    x_60            COVER_25        1.0
    x_61            OBJ           5
    x_61            PART_14         1.0
    x_61            PACK_13         1.0
    x_61            PACK_38         1.0
    x_61            PACK_128        1.0
    x_62            OBJ           11
    x_62            PART_14         1.0
    x_62            PACK_45         1.0
    x_62            PACK_171        1.0
    x_62            COVER_58        1.0
    x_63            OBJ           10
    x_63            PART_14         1.0
    x_63            PACK_65         1.0
    x_63            PACK_113        1.0
    x_63            COVER_52        1.0
    x_64            OBJ           22
    x_64            PART_15         1.0
    x_64            COVER_36        1.0
    x_64            COVER_49        1.0
    x_65            OBJ           17
    x_65            PART_15         1.0
    x_66            OBJ           15
    x_66            PART_15         1.0
    x_66            PACK_37         1.0
    x_66            PACK_113        1.0
    x_66            COVER_35        1.0
    x_66            COVER_54        1.0
    x_67            OBJ           10
    x_67            PART_15         1.0
    x_67            PACK_8          1.0
    x_67            PACK_56         1.0
    x_67            PACK_60         1.0
    x_67            PACK_126        1.0
    x_67            COVER_16        1.0
    x_68            OBJ           18
    x_68            PART_15         1.0
    x_68            PACK_20         1.0
    x_68            PACK_23         1.0
    x_68            PACK_35         1.0
    x_68            PACK_133        1.0
    x_69            OBJ           18
    x_69            PART_16         1.0
    x_69            PACK_8          1.0
    x_69            PACK_98         1.0
    x_69            COVER_2         1.0
    x_69            COVER_6         1.0
    x_70            OBJ           29
    x_70            PART_16         1.0
    x_70            PACK_40         1.0
    x_70            COVER_14        1.0
    x_71            OBJ           18
    x_71            PART_16         1.0
    x_71            PACK_67         1.0
    x_71            COVER_31        1.0
    x_72            OBJ           18
    x_72            PART_16         1.0
    x_72            PACK_2          1.0
    x_72            PACK_48         1.0
    x_72            PACK_66         1.0
    x_72            PACK_119        1.0
    x_73            OBJ           7
    x_73            PART_17         1.0
    x_73            PACK_20         1.0
    x_73            PACK_30         1.0
    x_73            PACK_167        1.0
    x_73            COVER_27        1.0
    x_74            OBJ           14
    x_74            PART_17         1.0
    x_74            PACK_24         1.0
    x_74            PACK_64         1.0
    x_74            PACK_97         1.0
    x_74            PACK_107        1.0
    x_74            PACK_174        1.0
    x_74            PACK_176        1.0
    x_75            OBJ           23
    x_75            PART_17         1.0
    x_75            PACK_56         1.0
    x_75            COVER_3         1.0
    x_75            COVER_23        1.0
    x_76            OBJ           23
    x_76            PART_18         1.0
    x_76            PACK_17         1.0
    x_76            PACK_51         1.0
    x_76            PACK_136        1.0
    x_76            COVER_8         1.0
    x_76            COVER_17        1.0
    x_77            OBJ           21
    x_77            PART_18         1.0
    x_77            PACK_53         1.0
    x_77            PACK_62         1.0
    x_77            PACK_111        1.0
    x_77            PACK_138        1.0
    x_77            PACK_155        1.0
    x_78            OBJ           21
    x_78            PART_18         1.0
    x_78            PACK_18         1.0
    x_78            PACK_83         1.0
    x_78            COVER_38        1.0
    x_78            COVER_44        1.0
    x_79            OBJ           21
    x_79            PART_19         1.0
    x_79            PACK_51         1.0
    x_79            PACK_52         1.0
    x_80            OBJ           29
    x_80            PART_19         1.0
    x_80            COVER_21        1.0
    x_80            COVER_39        1.0
    x_80            COVER_52        1.0
    x_81            OBJ           9
    x_81            PART_19         1.0
    x_81            PACK_21         1.0
    x_81            PACK_79         1.0
    x_81            PACK_96         1.0
    x_81            PACK_114        1.0
    x_81            PACK_171        1.0
    x_81            COVER_44        1.0
    x_82            OBJ           7
    x_82            PART_19         1.0
    x_82            PACK_39         1.0
    x_82            PACK_67         1.0
    x_82            PACK_68         1.0
    x_82            PACK_85         1.0
    x_82            PACK_121        1.0
    x_82            PACK_137        1.0
    x_82            PACK_158        1.0
    x_82            PACK_179        1.0
    x_82            COVER_13        1.0
    x_83            OBJ           11
    x_83            PART_19         1.0
    x_83            PACK_72         1.0
    x_83            PACK_99         1.0
    x_83            COVER_31        1.0
    x_83            COVER_42        1.0
    x_84            OBJ           27
    x_84            PART_20         1.0
    x_84            PACK_160        1.0
    x_84            COVER_17        1.0
    x_84            COVER_25        1.0
    x_84            COVER_47        1.0
    x_85            OBJ           17
    x_85            PART_20         1.0
    x_85            PACK_1          1.0
    x_85            PACK_106        1.0
    x_85            PACK_141        1.0
    x_85            PACK_178        1.0
    x_85            COVER_43        1.0
    x_86            OBJ           8
    x_86            PART_20         1.0
    x_86            COVER_20        1.0
    x_87            OBJ           15
    x_87            PART_21         1.0
    x_87            PACK_7          1.0
    x_87            PACK_28         1.0
    x_87            PACK_45         1.0
    x_87            PACK_50         1.0
    x_87            PACK_115        1.0
    x_87            PACK_168        1.0
    x_88            OBJ           16
    x_88            PART_21         1.0
    x_88            PACK_166        1.0
    x_89            OBJ           22
    x_89            PART_21         1.0
    x_90            OBJ           20
    x_90            PART_21         1.0
    x_90            PACK_1          1.0
    x_90            PACK_40         1.0
    x_90            PACK_71         1.0
    x_90            PACK_73         1.0
    x_90            PACK_74         1.0
    x_90            PACK_127        1.0
    x_90            PACK_145        1.0
    x_90            PACK_152        1.0
    x_90            COVER_1         1.0
    x_90            COVER_11        1.0
    x_90            COVER_14        1.0
    x_90            COVER_28        1.0
    x_90            COVER_50        1.0
    x_91            OBJ           11
    x_91            PART_21         1.0
    x_91            PACK_13         1.0
    x_91            PACK_32         1.0
    x_91            PACK_54         1.0
    x_91            PACK_148        1.0
    x_91            PACK_177        1.0
    x_92            OBJ           6
    x_92            PART_22         1.0
    x_92            PACK_56         1.0
    x_92            PACK_68         1.0
    x_92            PACK_76         1.0
    x_92            PACK_142        1.0
    x_92            COVER_6         1.0
    x_93            OBJ           10
    x_93            PART_22         1.0
    x_93            PACK_31         1.0
    x_93            PACK_85         1.0
    x_93            PACK_99         1.0
    x_93            COVER_8         1.0
    x_93            COVER_47        1.0
    x_94            OBJ           24
    x_94            PART_22         1.0
    x_94            PACK_72         1.0
    x_94            COVER_15        1.0
    x_95            OBJ           19
    x_95            PART_23         1.0
    x_95            PACK_20         1.0
    x_95            PACK_163        1.0
    x_95            COVER_10        1.0
    x_96            OBJ           8
    x_96            PART_23         1.0
    x_96            PACK_62         1.0
    x_96            PACK_89         1.0
    x_96            PACK_126        1.0
    x_96            COVER_41        1.0
    x_97            OBJ           7
    x_97            PART_23         1.0
    x_97            PACK_9          1.0
    x_97            PACK_10         1.0
    x_97            PACK_46         1.0
    x_97            PACK_149        1.0
    x_97            PACK_150        1.0
    x_97            PACK_153        1.0
    x_97            PACK_167        1.0
    x_97            PACK_177        1.0
    x_98            OBJ           25
    x_98            PART_23         1.0
    x_98            PACK_43         1.0
    x_98            PACK_105        1.0
    x_98            PACK_139        1.0
    x_98            COVER_37        1.0
    x_99            OBJ           12
    x_99            PART_23         1.0
    x_99            PACK_104        1.0
    x_99            PACK_132        1.0
    x_99            PACK_133        1.0
    x_99            PACK_135        1.0
    x_99            PACK_146        1.0
    x_100           OBJ           9
    x_100           PART_24         1.0
    x_100           PACK_6          1.0
    x_100           PACK_8          1.0
    x_100           PACK_32         1.0
    x_100           PACK_101        1.0
    x_100           PACK_116        1.0
    x_100           PACK_137        1.0
    x_100           PACK_146        1.0
    x_101           OBJ           17
    x_101           PART_24         1.0
    x_101           PACK_3          1.0
    x_101           PACK_74         1.0
    x_101           PACK_117        1.0
    x_101           PACK_118        1.0
    x_101           PACK_140        1.0
    x_102           OBJ           8
    x_102           PART_24         1.0
    x_102           PACK_15         1.0
    x_102           PACK_41         1.0
    x_102           PACK_48         1.0
    x_102           PACK_86         1.0
    x_102           PACK_178        1.0
    x_102           COVER_10        1.0
    x_103           OBJ           23
    x_103           PART_24         1.0
    x_103           PACK_67         1.0
    x_103           PACK_114        1.0
    x_103           COVER_22        1.0
    x_103           COVER_50        1.0
    x_104           OBJ           19
    x_104           PART_24         1.0
    x_104           PACK_33         1.0
    x_104           PACK_58         1.0
    x_104           PACK_149        1.0
    x_104           PACK_156        1.0
    x_104           PACK_173        1.0
    x_104           COVER_11        1.0
    x_104           COVER_50        1.0
    x_105           OBJ           9
    x_105           PART_24         1.0
    x_105           PACK_45         1.0
    x_105           PACK_54         1.0
    x_105           PACK_83         1.0
    x_105           PACK_121        1.0
    x_105           PACK_123        1.0
    x_105           PACK_136        1.0
    x_105           PACK_161        1.0
    x_105           PACK_162        1.0
    x_106           OBJ           7
    x_106           PART_25         1.0
    x_106           PACK_87         1.0
    x_106           PACK_96         1.0
    x_106           PACK_154        1.0
    x_106           COVER_45        1.0
    x_106           COVER_47        1.0
    x_107           OBJ           20
    x_107           PART_25         1.0
    x_108           OBJ           17
    x_108           PART_25         1.0
    x_108           PACK_0          1.0
    x_108           PACK_48         1.0
    x_108           PACK_125        1.0
    x_109           OBJ           16
    x_109           PART_25         1.0
    x_109           PACK_16         1.0
    x_109           PACK_152        1.0
    x_109           COVER_43        1.0
    x_110           OBJ           29
    x_110           PART_25         1.0
    x_110           PACK_36         1.0
    x_110           PACK_175        1.0
    x_110           COVER_0         1.0
    x_111           OBJ           12
    x_111           PART_25         1.0
    x_111           PACK_37         1.0
    x_111           PACK_42         1.0
    x_111           PACK_55         1.0
    x_111           PACK_57         1.0
    x_111           PACK_68         1.0
    x_111           PACK_80         1.0
    x_112           OBJ           22
    x_112           PART_26         1.0
    x_112           COVER_53        1.0
    x_112           COVER_54        1.0
    x_112           COVER_56        1.0
    x_113           OBJ           19
    x_113           PART_26         1.0
    x_113           PACK_58         1.0
    x_113           PACK_147        1.0
    x_113           PACK_150        1.0
    x_113           PACK_170        1.0
    x_113           COVER_23        1.0
    x_113           COVER_29        1.0
    x_114           OBJ           8
    x_114           PART_26         1.0
    x_114           PACK_22         1.0
    x_114           PACK_59         1.0
    x_114           PACK_99         1.0
    x_115           OBJ           22
    x_115           PART_27         1.0
    x_115           COVER_18        1.0
    x_115           COVER_30        1.0
    x_116           OBJ           5
    x_116           PART_27         1.0
    x_116           PACK_9          1.0
    x_116           PACK_106        1.0
    x_116           PACK_172        1.0
    x_116           PACK_173        1.0
    x_117           OBJ           16
    x_117           PART_27         1.0
    x_117           PACK_10         1.0
    x_117           PACK_11         1.0
    x_117           PACK_30         1.0
    x_117           PACK_33         1.0
    x_117           PACK_47         1.0
    x_117           COVER_4         1.0
    x_117           COVER_5         1.0
    x_117           COVER_59        1.0
    x_118           OBJ           7
    x_118           PART_28         1.0
    x_118           PACK_15         1.0
    x_118           PACK_34         1.0
    x_118           PACK_72         1.0
    x_118           PACK_79         1.0
    x_118           PACK_95         1.0
    x_118           PACK_118        1.0
    x_118           PACK_136        1.0
    x_118           PACK_178        1.0
    x_118           PACK_179        1.0
    x_119           OBJ           21
    x_119           PART_28         1.0
    x_119           PACK_85         1.0
    x_119           PACK_86         1.0
    x_119           PACK_97         1.0
    x_119           PACK_161        1.0
    x_119           PACK_169        1.0
    x_119           PACK_173        1.0
    x_119           COVER_3         1.0
    x_119           COVER_16        1.0
    x_120           OBJ           11
    x_120           PART_28         1.0
    x_120           PACK_59         1.0
    x_120           PACK_62         1.0
    x_120           PACK_99         1.0
    x_120           PACK_111        1.0
    x_120           COVER_7         1.0
    x_120           COVER_23        1.0
    x_121           OBJ           21
    x_121           PART_28         1.0
    x_121           PACK_4          1.0
    x_121           PACK_25         1.0
    x_121           PACK_140        1.0
    x_121           PACK_167        1.0
    x_121           COVER_19        1.0
    x_121           COVER_27        1.0
    x_122           OBJ           25
    x_122           PART_28         1.0
    x_123           OBJ           15
    x_123           PART_28         1.0
    x_123           PACK_83         1.0
    x_123           COVER_37        1.0
    x_124           OBJ           21
    x_124           PART_29         1.0
    x_124           PACK_76         1.0
    x_124           PACK_78         1.0
    x_124           PACK_153        1.0
    x_125           OBJ           11
    x_125           PART_29         1.0
    x_125           PACK_82         1.0
    x_125           PACK_121        1.0
    x_125           PACK_151        1.0
    x_125           PACK_163        1.0
    x_125           PACK_166        1.0
    x_125           COVER_9         1.0
    x_126           OBJ           5
    x_126           PART_29         1.0
    x_126           PACK_155        1.0
    x_126           PACK_175        1.0
    x_126           COVER_25        1.0
    x_126           COVER_46        1.0
    x_127           OBJ           14
    x_127           PART_29         1.0
    x_127           PACK_8          1.0
    x_127           PACK_24         1.0
    x_127           PACK_69         1.0
    x_127           PACK_97         1.0
    x_127           PACK_107        1.0
    x_127           PACK_109        1.0
    x_127           PACK_171        1.0
    x_128           OBJ           14
    x_128           PART_29         1.0
    x_128           PACK_83         1.0
    x_128           PACK_136        1.0
    x_128           PACK_178        1.0
    x_128           COVER_8         1.0
    x_128           COVER_36        1.0
    x_129           OBJ           23
    x_129           PART_29         1.0
    x_129           PACK_174        1.0
    x_130           OBJ           12
    x_130           PART_30         1.0
    x_130           PACK_89         1.0
    x_130           PACK_105        1.0
    x_130           PACK_134        1.0
    x_130           PACK_142        1.0
    x_130           PACK_163        1.0
    x_130           COVER_29        1.0
    x_131           OBJ           14
    x_131           PART_30         1.0
    x_131           COVER_18        1.0
    x_131           COVER_27        1.0
    x_132           OBJ           7
    x_132           PART_30         1.0
    x_132           PACK_57         1.0
    x_132           PACK_100        1.0
    x_132           PACK_103        1.0
    x_132           PACK_109        1.0
    x_132           PACK_119        1.0
    x_132           COVER_10        1.0
    x_132           COVER_20        1.0
    x_133           OBJ           30
    x_133           PART_30         1.0
    x_133           PACK_2          1.0
    x_133           COVER_16        1.0
    x_134           OBJ           18
    x_134           PART_30         1.0
    x_134           PACK_37         1.0
    x_135           OBJ           21
    x_135           PART_31         1.0
    x_135           PACK_24         1.0
    x_135           PACK_26         1.0
    x_135           PACK_81         1.0
    x_135           PACK_139        1.0
    x_135           PACK_158        1.0
    x_135           PACK_170        1.0
    x_136           OBJ           14
    x_136           PART_31         1.0
    x_136           PACK_72         1.0
    x_136           PACK_75         1.0
    x_136           PACK_156        1.0
    x_136           PACK_159        1.0
    x_136           COVER_25        1.0
    x_137           OBJ           27
    x_137           PART_31         1.0
    x_137           PACK_95         1.0
    x_138           OBJ           14
    x_138           PART_31         1.0
    x_138           PACK_49         1.0
    x_138           PACK_79         1.0
    x_138           PACK_90         1.0
    x_138           PACK_110        1.0
    x_138           PACK_120        1.0
    x_138           COVER_12        1.0
    x_138           COVER_16        1.0
    x_138           COVER_20        1.0
    x_138           COVER_29        1.0
    x_139           OBJ           8
    x_139           PART_31         1.0
    x_139           PACK_12         1.0
    x_139           PACK_70         1.0
    x_139           PACK_147        1.0
    x_139           PACK_161        1.0
    x_140           OBJ           16
    x_140           PART_32         1.0
    x_140           PACK_75         1.0
    x_140           PACK_106        1.0
    x_140           PACK_121        1.0
    x_141           OBJ           17
    x_141           PART_32         1.0
    x_141           PACK_5          1.0
    x_141           PACK_33         1.0
    x_141           PACK_39         1.0
    x_141           PACK_44         1.0
    x_141           PACK_76         1.0
    x_141           PACK_86         1.0
    x_141           PACK_112        1.0
    x_141           COVER_22        1.0
    x_142           OBJ           14
    x_142           PART_32         1.0
    x_142           PACK_92         1.0
    x_142           PACK_109        1.0
    x_142           COVER_25        1.0
    x_143           OBJ           25
    x_143           PART_32         1.0
    x_143           COVER_1         1.0
    x_144           OBJ           17
    x_144           PART_33         1.0
    x_144           PACK_3          1.0
    x_144           PACK_67         1.0
    x_144           PACK_134        1.0
    x_144           PACK_157        1.0
    x_144           COVER_52        1.0
    x_145           OBJ           21
    x_145           PART_33         1.0
    x_145           PACK_104        1.0
    x_145           PACK_127        1.0
    x_145           PACK_159        1.0
    x_145           COVER_38        1.0
    x_146           OBJ           16
    x_146           PART_33         1.0
    x_146           PACK_52         1.0
    x_146           PACK_137        1.0
    x_146           PACK_156        1.0
    x_146           PACK_176        1.0
    x_147           OBJ           27
    x_147           PART_33         1.0
    x_147           PACK_22         1.0
    x_147           PACK_65         1.0
    x_147           PACK_147        1.0
    x_147           COVER_59        1.0
    x_148           OBJ           18
    x_148           PART_33         1.0
    x_148           PACK_11         1.0
    x_148           PACK_16         1.0
    x_148           PACK_63         1.0
    x_148           PACK_122        1.0
    x_149           OBJ           21
    x_149           PART_34         1.0
    x_149           PACK_20         1.0
    x_149           PACK_36         1.0
    x_149           PACK_97         1.0
    x_149           PACK_127        1.0
    x_150           OBJ           21
    x_150           PART_34         1.0
    x_150           PACK_66         1.0
    x_150           PACK_71         1.0
    x_150           PACK_92         1.0
    x_150           PACK_138        1.0
    x_151           OBJ           7
    x_151           PART_34         1.0
    x_151           PACK_31         1.0
    x_151           PACK_113        1.0
    x_151           COVER_58        1.0
    x_152           OBJ           26
    x_152           PART_34         1.0
    x_152           PACK_15         1.0
    x_152           PACK_153        1.0
    x_152           COVER_9         1.0
    x_152           COVER_14        1.0
    x_152           COVER_28        1.0
    x_153           OBJ           29
    x_153           PART_35         1.0
    x_153           PACK_100        1.0
    x_153           PACK_176        1.0
    x_153           COVER_26        1.0
    x_154           OBJ           13
    x_154           PART_35         1.0
    x_154           PACK_86         1.0
    x_154           PACK_137        1.0
    x_154           PACK_169        1.0
    x_155           OBJ           18
    x_155           PART_35         1.0
    x_155           PACK_11         1.0
    x_155           PACK_27         1.0
    x_155           PACK_41         1.0
    x_155           PACK_135        1.0
    x_155           COVER_18        1.0
    x_155           COVER_24        1.0
    x_156           OBJ           8
    x_156           PART_35         1.0
    x_156           PACK_77         1.0
    x_156           COVER_47        1.0
    x_157           OBJ           13
    x_157           PART_36         1.0
    x_157           PACK_5          1.0
    x_157           PACK_43         1.0
    x_158           OBJ           21
    x_158           PART_36         1.0
    x_158           PACK_0          1.0
    x_158           PACK_78         1.0
    x_158           PACK_119        1.0
    x_158           PACK_131        1.0
    x_159           OBJ           26
    x_159           PART_36         1.0
    x_159           PACK_6          1.0
    x_159           COVER_43        1.0
    x_159           COVER_52        1.0
    x_159           COVER_53        1.0
    x_160           OBJ           13
    x_160           PART_36         1.0
    x_160           PACK_9          1.0
    x_160           PACK_63         1.0
    x_160           PACK_88         1.0
    x_160           PACK_89         1.0
    x_160           PACK_130        1.0
    x_161           OBJ           18
    x_161           PART_36         1.0
    x_161           PACK_15         1.0
    x_161           PACK_39         1.0
    x_161           PACK_66         1.0
    x_161           PACK_112        1.0
    x_161           PACK_125        1.0
    x_161           PACK_166        1.0
    x_162           OBJ           12
    x_162           PART_37         1.0
    x_162           PACK_5          1.0
    x_162           PACK_75         1.0
    x_162           PACK_129        1.0
    x_163           OBJ           12
    x_163           PART_37         1.0
    x_163           PACK_37         1.0
    x_163           PACK_45         1.0
    x_163           PACK_54         1.0
    x_163           COVER_55        1.0
    x_164           OBJ           30
    x_164           PART_37         1.0
    x_164           PACK_57         1.0
    x_165           OBJ           19
    x_165           PART_37         1.0
    x_165           PACK_18         1.0
    x_165           COVER_32        1.0
    x_166           OBJ           21
    x_166           PART_38         1.0
    x_166           PACK_37         1.0
    x_166           PACK_124        1.0
    x_166           PACK_155        1.0
    x_166           PACK_163        1.0
    x_166           COVER_19        1.0
    x_167           OBJ           25
    x_167           PART_38         1.0
    x_167           PACK_41         1.0
    x_167           COVER_2         1.0
    x_167           COVER_11        1.0
    x_168           OBJ           16
    x_168           PART_38         1.0
    x_168           PACK_7          1.0
    x_168           PACK_11         1.0
    x_168           PACK_42         1.0
    x_168           PACK_165        1.0
    x_168           COVER_33        1.0
    x_169           OBJ           20
    x_169           PART_38         1.0
    x_169           PACK_14         1.0
    x_169           PACK_44         1.0
    x_169           PACK_70         1.0
    x_169           PACK_123        1.0
    x_169           PACK_143        1.0
    x_169           PACK_144        1.0
    x_169           PACK_157        1.0
    x_170           OBJ           28
    x_170           PART_39         1.0
    x_170           PACK_88         1.0
    x_170           COVER_3         1.0
    x_170           COVER_10        1.0
    x_170           COVER_17        1.0
    x_170           COVER_35        1.0
    x_170           COVER_48        1.0
    x_170           COVER_51        1.0
    x_171           OBJ           7
    x_171           PART_39         1.0
    x_171           PACK_46         1.0
    x_171           PACK_93         1.0
    x_171           PACK_104        1.0
    x_171           PACK_138        1.0
    x_171           COVER_5         1.0
    x_172           OBJ           10
    x_172           PART_39         1.0
    x_172           PACK_27         1.0
    x_172           PACK_94         1.0
    x_172           PACK_111        1.0
    x_173           OBJ           24
    x_173           PART_40         1.0
    x_173           PACK_33         1.0
    x_173           PACK_158        1.0
    x_173           COVER_24        1.0
    x_173           COVER_27        1.0
    x_173           COVER_28        1.0
    x_173           COVER_33        1.0
    x_174           OBJ           5
    x_174           PART_40         1.0
    x_174           PACK_53         1.0
    x_174           PACK_98         1.0
    x_174           PACK_139        1.0
    x_174           COVER_19        1.0
    x_175           OBJ           11
    x_175           PART_40         1.0
    x_175           PACK_7          1.0
    x_175           PACK_18         1.0
    x_175           COVER_22        1.0
    x_175           COVER_30        1.0
    x_175           COVER_56        1.0
    x_176           OBJ           13
    x_176           PART_40         1.0
    x_176           PACK_8          1.0
    x_176           PACK_21         1.0
    x_176           PACK_37         1.0
    x_176           PACK_43         1.0
    x_176           PACK_60         1.0
    x_176           PACK_116        1.0
    x_176           PACK_135        1.0
    x_176           PACK_162        1.0
    x_176           PACK_165        1.0
    x_176           COVER_35        1.0
    x_177           OBJ           7
    x_177           PART_40         1.0
    x_177           PACK_28         1.0
    x_177           PACK_73         1.0
    x_177           PACK_77         1.0
    x_177           PACK_95         1.0
    x_177           PACK_97         1.0
    x_177           PACK_110        1.0
    x_177           PACK_156        1.0
    x_177           COVER_26        1.0
    x_178           OBJ           8
    x_178           PART_40         1.0
    x_178           PACK_38         1.0
    x_178           PACK_50         1.0
    x_178           PACK_133        1.0
    x_179           OBJ           14
    x_179           PART_41         1.0
    x_179           PACK_23         1.0
    x_179           PACK_89         1.0
    x_179           PACK_146        1.0
    x_179           PACK_149        1.0
    x_179           PACK_158        1.0
    x_179           COVER_34        1.0
    x_179           COVER_48        1.0
    x_180           OBJ           7
    x_180           PART_41         1.0
    x_180           PACK_8          1.0
    x_180           PACK_49         1.0
    x_180           PACK_93         1.0
    x_180           PACK_102        1.0
    x_180           PACK_164        1.0
    x_181           OBJ           9
    x_181           PART_41         1.0
    x_181           PACK_60         1.0
    x_181           PACK_61         1.0
    x_181           PACK_75         1.0
    x_181           PACK_115        1.0
    x_181           PACK_157        1.0
    x_181           PACK_159        1.0
    x_181           PACK_167        1.0
    x_181           COVER_24        1.0
    x_182           OBJ           27
    x_182           PART_41         1.0
    x_182           PACK_45         1.0
    x_182           COVER_4         1.0
    x_182           COVER_5         1.0
    x_182           COVER_11        1.0
    x_182           COVER_20        1.0
    x_182           COVER_25        1.0
    x_183           OBJ           7
    x_183           PART_41         1.0
    x_183           PACK_9          1.0
    x_183           PACK_52         1.0
    x_183           PACK_92         1.0
    x_183           PACK_104        1.0
    x_183           PACK_109        1.0
    x_183           PACK_127        1.0
    x_183           COVER_51        1.0
    x_184           OBJ           15
    x_184           PART_41         1.0
    x_184           PACK_34         1.0
    x_184           PACK_141        1.0
    x_184           PACK_162        1.0
    x_184           COVER_9         1.0
    x_184           COVER_10        1.0
    x_184           COVER_47        1.0
    x_185           OBJ           24
    x_185           PART_42         1.0
    x_185           PACK_60         1.0
    x_185           PACK_79         1.0
    x_185           COVER_41        1.0
    x_186           OBJ           16
    x_186           PART_42         1.0
    x_186           PACK_11         1.0
    x_186           PACK_84         1.0
    x_186           PACK_111        1.0
    x_187           OBJ           7
    x_187           PART_42         1.0
    x_187           PACK_12         1.0
    x_187           PACK_23         1.0
    x_187           PACK_78         1.0
    x_187           PACK_95         1.0
    x_187           PACK_133        1.0
    x_187           PACK_134        1.0
    x_187           PACK_157        1.0
    x_187           COVER_35        1.0
    x_188           OBJ           27
    x_188           PART_43         1.0
    x_188           PACK_167        1.0
    x_188           COVER_12        1.0
    x_188           COVER_46        1.0
    x_189           OBJ           12
    x_189           PART_43         1.0
    x_189           PACK_42         1.0
    x_189           PACK_49         1.0
    x_189           PACK_74         1.0
    x_189           PACK_82         1.0
    x_189           PACK_128        1.0
    x_190           OBJ           14
    x_190           PART_43         1.0
    x_190           COVER_30        1.0
    x_191           OBJ           16
    x_191           PART_43         1.0
    x_191           PACK_10         1.0
    x_191           PACK_38         1.0
    x_191           PACK_39         1.0
    x_191           PACK_51         1.0
    x_191           PACK_87         1.0
    x_191           PACK_117        1.0
    x_191           PACK_123        1.0
    x_191           PACK_150        1.0
    x_191           PACK_165        1.0
    x_191           COVER_2         1.0
    x_191           COVER_23        1.0
    x_192           OBJ           30
    x_192           PART_44         1.0
    x_192           PACK_119        1.0
    x_192           COVER_20        1.0
    x_193           OBJ           8
    x_193           PART_44         1.0
    x_193           PACK_38         1.0
    x_193           PACK_117        1.0
    x_193           COVER_24        1.0
    x_193           COVER_49        1.0
    x_194           OBJ           16
    x_194           PART_44         1.0
    x_194           PACK_61         1.0
    x_194           PACK_125        1.0
    x_194           PACK_130        1.0
    x_194           PACK_132        1.0
    x_194           PACK_150        1.0
    x_195           OBJ           18
    x_195           PART_44         1.0
    x_195           PACK_27         1.0
    x_195           PACK_36         1.0
    x_195           PACK_71         1.0
    x_195           PACK_106        1.0
    x_195           PACK_179        1.0
    x_196           OBJ           10
    x_196           PART_44         1.0
    x_196           PACK_4          1.0
    x_196           PACK_33         1.0
    x_196           PACK_43         1.0
    x_196           PACK_60         1.0
    x_196           PACK_63         1.0
    x_196           PACK_105        1.0
    x_196           PACK_152        1.0
    x_196           COVER_26        1.0
    x_197           OBJ           17
    x_197           PART_45         1.0
    x_197           PACK_13         1.0
    x_197           PACK_22         1.0
    x_197           PACK_91         1.0
    x_197           PACK_94         1.0
    x_197           PACK_103        1.0
    x_197           PACK_115        1.0
    x_197           PACK_145        1.0
    x_197           PACK_174        1.0
    x_197           PACK_179        1.0
    x_198           OBJ           9
    x_198           PART_45         1.0
    x_198           PACK_5          1.0
    x_198           PACK_14         1.0
    x_198           PACK_99         1.0
    x_198           COVER_56        1.0
    x_199           OBJ           28
    x_199           PART_45         1.0
    x_199           COVER_21        1.0
    x_199           COVER_53        1.0
    x_200           OBJ           7
    x_200           PART_45         1.0
    x_200           PACK_143        1.0
    x_200           PACK_169        1.0
    x_200           COVER_13        1.0
    x_201           OBJ           12
    x_201           PART_46         1.0
    x_201           PACK_56         1.0
    x_201           PACK_118        1.0
    x_201           PACK_134        1.0
    x_201           PACK_149        1.0
    x_201           PACK_172        1.0
    x_201           COVER_31        1.0
    x_202           OBJ           7
    x_202           PART_46         1.0
    x_202           PACK_0          1.0
    x_202           PACK_75         1.0
    x_202           PACK_146        1.0
    x_202           COVER_45        1.0
    x_203           OBJ           26
    x_203           PART_46         1.0
    x_203           COVER_3         1.0
    x_203           COVER_9         1.0
    x_204           OBJ           11
    x_204           PART_47         1.0
    x_204           PACK_0          1.0
    x_204           PACK_155        1.0
    x_204           COVER_48        1.0
    x_205           OBJ           8
    x_205           PART_47         1.0
    x_205           PACK_119        1.0
    x_205           PACK_164        1.0
    x_206           OBJ           22
    x_206           PART_47         1.0
    x_206           PACK_7          1.0
    x_206           PACK_92         1.0
    x_206           COVER_38        1.0
    x_206           COVER_50        1.0
    x_206           COVER_57        1.0
    x_207           OBJ           6
    x_207           PART_47         1.0
    x_207           PACK_38         1.0
    x_207           PACK_122        1.0
    x_207           PACK_127        1.0
    x_207           PACK_141        1.0
    x_207           COVER_15        1.0
    x_208           OBJ           22
    x_208           PART_48         1.0
    x_208           PACK_28         1.0
    x_208           PACK_105        1.0
    x_208           PACK_123        1.0
    x_208           PACK_147        1.0
    x_208           PACK_160        1.0
    x_209           OBJ           27
    x_209           PART_48         1.0
    x_210           OBJ           14
    x_210           PART_48         1.0
    x_210           PACK_45         1.0
    x_210           PACK_66         1.0
    x_210           PACK_168        1.0
    x_210           PACK_172        1.0
    x_210           COVER_48        1.0
    x_211           OBJ           12
    x_211           PART_48         1.0
    x_211           PACK_50         1.0
    x_211           PACK_87         1.0
    x_211           PACK_106        1.0
    x_211           PACK_170        1.0
    x_211           COVER_27        1.0
    x_212           OBJ           23
    x_212           PART_49         1.0
    x_212           PACK_80         1.0
    x_212           PACK_172        1.0
    x_212           COVER_4         1.0
    x_213           OBJ           9
    x_213           PART_49         1.0
    x_213           PACK_65         1.0
    x_213           PACK_120        1.0
    x_213           PACK_131        1.0
    x_213           PACK_150        1.0
    x_213           COVER_41        1.0
    x_214           OBJ           9
    x_214           PART_49         1.0
    x_214           COVER_45        1.0
    x_215           OBJ           12
    x_215           PART_49         1.0
    x_215           PACK_88         1.0
    x_215           PACK_112        1.0
    x_216           OBJ           15
    x_216           PART_49         1.0
    x_216           PACK_6          1.0
    x_216           PACK_53         1.0
    x_216           PACK_92         1.0
    x_216           PACK_99         1.0
    x_216           COVER_39        1.0
    x_217           OBJ           11
    x_217           PART_49         1.0
    x_217           PACK_16         1.0
    x_217           PACK_173        1.0
    x_217           COVER_8         1.0
    x_218           OBJ           10
    x_218           PART_50         1.0
    x_218           PACK_70         1.0
    x_218           PACK_74         1.0
    x_218           PACK_91         1.0
    x_218           PACK_159        1.0
    x_218           COVER_28        1.0
    x_219           OBJ           24
    x_219           PART_50         1.0
    x_219           COVER_6         1.0
    x_219           COVER_7         1.0
    x_220           OBJ           19
    x_220           PART_50         1.0
    x_220           PACK_39         1.0
    x_220           PACK_60         1.0
    x_220           PACK_80         1.0
    x_220           PACK_82         1.0
    x_220           PACK_85         1.0
    x_220           PACK_158        1.0
    x_221           OBJ           6
    x_221           PART_50         1.0
    x_221           PACK_0          1.0
    x_221           PACK_13         1.0
    x_221           PACK_58         1.0
    x_221           PACK_95         1.0
    x_221           PACK_106        1.0
    x_221           PACK_148        1.0
    x_222           OBJ           19
    x_222           PART_50         1.0
    x_222           PACK_19         1.0
    x_222           PACK_30         1.0
    x_222           PACK_50         1.0
    x_223           OBJ           14
    x_223           PART_50         1.0
    x_223           PACK_69         1.0
    x_223           PACK_79         1.0
    x_223           PACK_100        1.0
    x_223           PACK_134        1.0
    x_224           OBJ           16
    x_224           PART_51         1.0
    x_224           PACK_5          1.0
    x_224           PACK_40         1.0
    x_224           PACK_69         1.0
    x_224           PACK_96         1.0
    x_224           PACK_122        1.0
    x_224           PACK_164        1.0
    x_225           OBJ           20
    x_225           PART_51         1.0
    x_225           PACK_21         1.0
    x_225           PACK_26         1.0
    x_225           PACK_34         1.0
    x_225           PACK_129        1.0
    x_225           COVER_5         1.0
    x_225           COVER_56        1.0
    x_226           OBJ           16
    x_226           PART_51         1.0
    x_226           PACK_42         1.0
    x_226           PACK_101        1.0
    x_227           OBJ           30
    x_227           PART_51         1.0
    x_227           PACK_98         1.0
    x_228           OBJ           10
    x_228           PART_51         1.0
    x_228           PACK_25         1.0
    x_228           PACK_72         1.0
    x_228           PACK_131        1.0
    x_228           PACK_144        1.0
    x_228           PACK_171        1.0
    x_228           COVER_23        1.0
    x_229           OBJ           14
    x_229           PART_51         1.0
    x_229           PACK_33         1.0
    x_229           PACK_61         1.0
    x_229           PACK_90         1.0
    x_229           PACK_124        1.0
    x_229           PACK_132        1.0
    x_229           PACK_148        1.0
    x_230           OBJ           9
    x_230           PART_52         1.0
    x_230           PACK_25         1.0
    x_230           PACK_46         1.0
    x_230           PACK_129        1.0
    x_230           PACK_147        1.0
    x_230           PACK_160        1.0
    x_231           OBJ           13
    x_231           PART_52         1.0
    x_231           PACK_54         1.0
    x_231           PACK_104        1.0
    x_231           PACK_121        1.0
    x_231           PACK_135        1.0
    x_231           PACK_148        1.0
    x_231           PACK_162        1.0
    x_231           PACK_171        1.0
    x_231           COVER_14        1.0
    x_231           COVER_48        1.0
    x_232           OBJ           20
    x_232           PART_52         1.0
    x_232           PACK_64         1.0
    x_232           PACK_113        1.0
    x_232           PACK_123        1.0
    x_232           PACK_124        1.0
    x_233           OBJ           30
    x_233           PART_52         1.0
    x_233           COVER_11        1.0
    x_233           COVER_19        1.0
    x_234           OBJ           22
    x_234           PART_52         1.0
    x_234           PACK_176        1.0
    x_234           COVER_21        1.0
    x_234           COVER_40        1.0
    x_235           OBJ           21
    x_235           PART_53         1.0
    x_235           PACK_16         1.0
    x_235           PACK_31         1.0
    x_235           PACK_47         1.0
    x_235           PACK_59         1.0
    x_235           PACK_64         1.0
    x_235           PACK_94         1.0
    x_235           PACK_114        1.0
    x_235           COVER_9         1.0
    x_235           COVER_30        1.0
    x_235           COVER_43        1.0
    x_236           OBJ           28
    x_236           PART_53         1.0
    x_237           OBJ           9
    x_237           PART_53         1.0
    x_237           PACK_104        1.0
    x_237           PACK_115        1.0
    x_238           OBJ           20
    x_238           PART_53         1.0
    x_238           PACK_30         1.0
    x_238           PACK_38         1.0
    x_238           PACK_90         1.0
    x_238           PACK_159        1.0
    x_238           COVER_6         1.0
    x_238           COVER_30        1.0
    x_239           OBJ           20
    x_239           PART_53         1.0
    x_239           PACK_21         1.0
    x_239           PACK_68         1.0
    x_239           PACK_73         1.0
    x_239           PACK_142        1.0
    x_239           PACK_157        1.0
    x_240           OBJ           17
    x_240           PART_54         1.0
    x_240           PACK_120        1.0
    x_240           PACK_130        1.0
    x_241           OBJ           22
    x_241           PART_54         1.0
    x_241           PACK_18         1.0
    x_241           PACK_138        1.0
    x_241           COVER_46        1.0
    x_241           COVER_52        1.0
    x_242           OBJ           6
    x_242           PART_54         1.0
    x_242           PACK_6          1.0
    x_242           PACK_20         1.0
    x_242           PACK_49         1.0
    x_242           PACK_84         1.0
    x_242           PACK_108        1.0
    x_242           PACK_128        1.0
    x_242           COVER_3         1.0
    x_243           OBJ           14
    x_243           PART_55         1.0
    x_243           PACK_70         1.0
    x_243           PACK_143        1.0
    x_243           PACK_150        1.0
    x_244           OBJ           16
    x_244           PART_55         1.0
    x_244           PACK_118        1.0
    x_244           PACK_175        1.0
    x_244           COVER_15        1.0
    x_245           OBJ           17
    x_245           PART_55         1.0
    x_245           PACK_5          1.0
    x_245           PACK_33         1.0
    x_245           PACK_101        1.0
    x_245           PACK_137        1.0
    x_246           OBJ           5
    x_246           PART_55         1.0
    x_246           PACK_54         1.0
    x_246           PACK_68         1.0
    x_246           PACK_90         1.0
    x_246           PACK_115        1.0
    x_246           PACK_121        1.0
    x_246           PACK_139        1.0
    x_247           OBJ           24
    x_247           PART_55         1.0
    x_247           PACK_27         1.0
    x_248           OBJ           24
    x_248           PART_56         1.0
    x_248           COVER_26        1.0
    x_249           OBJ           19
    x_249           PART_56         1.0
    x_249           PACK_42         1.0
    x_249           PACK_50         1.0
    x_250           OBJ           9
    x_250           PART_56         1.0
    x_250           PACK_10         1.0
    x_250           PACK_44         1.0
    x_250           PACK_63         1.0
    x_250           PACK_92         1.0
    x_250           COVER_32        1.0
    x_251           OBJ           8
    x_251           PART_57         1.0
    x_251           PACK_29         1.0
    x_251           COVER_57        1.0
    x_252           OBJ           16
    x_252           PART_57         1.0
    x_252           PACK_13         1.0
    x_252           PACK_94         1.0
    x_252           PACK_173        1.0
    x_253           OBJ           21
    x_253           PART_57         1.0
    x_253           PACK_84         1.0
    x_253           PACK_103        1.0
    x_253           COVER_7         1.0
    x_254           OBJ           6
    x_254           PART_57         1.0
    x_254           PACK_17         1.0
    x_254           PACK_55         1.0
    x_254           PACK_56         1.0
    x_254           PACK_102        1.0
    x_254           PACK_109        1.0
    x_254           PACK_156        1.0
    x_254           COVER_19        1.0
    x_255           OBJ           27
    x_255           PART_57         1.0
    x_255           PACK_4          1.0
    x_255           PACK_123        1.0
    x_255           COVER_2         1.0
    x_255           COVER_5         1.0
    x_255           COVER_24        1.0
    x_256           OBJ           16
    x_256           PART_57         1.0
    x_256           PACK_66         1.0
    x_256           PACK_77         1.0
    x_256           PACK_87         1.0
    x_256           PACK_88         1.0
    x_256           PACK_140        1.0
    x_256           PACK_169        1.0
    x_257           OBJ           8
    x_257           PART_58         1.0
    x_257           COVER_17        1.0
    x_258           OBJ           29
    x_258           PART_58         1.0
    x_258           PACK_1          1.0
    x_258           PACK_31         1.0
    x_258           COVER_2         1.0
    x_258           COVER_34        1.0
    x_259           OBJ           10
    x_259           PART_58         1.0
    x_259           PACK_32         1.0
    x_259           PACK_41         1.0
    x_259           PACK_53         1.0
    x_259           PACK_93         1.0
    x_259           PACK_151        1.0
    x_259           PACK_153        1.0
    x_260           OBJ           16
    x_260           PART_59         1.0
    x_260           PACK_29         1.0
    x_260           PACK_53         1.0
    x_260           PACK_110        1.0
    x_260           PACK_115        1.0
    x_260           COVER_33        1.0
    x_261           OBJ           16
    x_261           PART_59         1.0
    x_261           PACK_87         1.0
    x_261           PACK_109        1.0
    x_261           PACK_136        1.0
    x_261           PACK_162        1.0
    x_261           COVER_18        1.0
    x_262           OBJ           16
    x_262           PART_59         1.0
    x_262           PACK_4          1.0
    x_262           PACK_19         1.0
    x_262           PACK_32         1.0
    x_262           PACK_47         1.0
    x_262           PACK_48         1.0
    x_262           PACK_120        1.0
    x_262           PACK_168        1.0
    x_262           COVER_17        1.0
    x_263           OBJ           28
    x_263           PART_59         1.0
    x_263           PACK_116        1.0
    x_263           PACK_125        1.0
    x_263           PACK_129        1.0
    x_263           COVER_42        1.0
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           PART_0          1.0
    RHS           PART_1          1.0
    RHS           PART_2          1.0
    RHS           PART_3          1.0
    RHS           PART_4          1.0
    RHS           PART_5          1.0
    RHS           PART_6          1.0
    RHS           PART_7          1.0
    RHS           PART_8          1.0
    RHS           PART_9          1.0
    RHS           PART_10         1.0
    RHS           PART_11         1.0
    RHS           PART_12         1.0
    RHS           PART_13         1.0
    RHS           PART_14         1.0
    RHS           PART_15         1.0
    RHS           PART_16         1.0
    RHS           PART_17         1.0
    RHS           PART_18         1.0
    RHS           PART_19         1.0
    RHS           PART_20         1.0
    RHS           PART_21         1.0
    RHS           PART_22         1.0
    RHS           PART_23         1.0
    RHS           PART_24         1.0
    RHS           PART_25         1.0
    RHS           PART_26         1.0
    RHS           PART_27         1.0
    RHS           PART_28         1.0
    RHS           PART_29         1.0
    RHS           PART_30         1.0
    RHS           PART_31         1.0
    RHS           PART_32         1.0
    RHS           PART_33         1.0
    RHS           PART_34         1.0
    RHS           PART_35         1.0
    RHS           PART_36         1.0
    RHS           PART_37         1.0
    RHS           PART_38         1.0
    RHS           PART_39         1.0
    RHS           PART_40         1.0
    RHS           PART_41         1.0
    RHS           PART_42         1.0
    RHS           PART_43         1.0
    RHS           PART_44         1.0
    RHS           PART_45         1.0
    RHS           PART_46         1.0
    RHS           PART_47         1.0
    RHS           PART_48         1.0
    RHS           PART_49         1.0
    RHS           PART_50         1.0
    RHS           PART_51         1.0
    RHS           PART_52         1.0
    RHS           PART_53         1.0
    RHS           PART_54         1.0
    RHS           PART_55         1.0
    RHS           PART_56         1.0
    RHS           PART_57         1.0
    RHS           PART_58         1.0
    RHS           PART_59         1.0
    RHS           PACK_0          1.0
    RHS           PACK_1          1.0
    RHS           PACK_2          1.0
    RHS           PACK_3          1.0
    RHS           PACK_4          1.0
    RHS           PACK_5          1.0
    RHS           PACK_6          1.0
    RHS           PACK_7          1.0
    RHS           PACK_8          1.0
    RHS           PACK_9          1.0
    RHS           PACK_10         1.0
    RHS           PACK_11         1.0
    RHS           PACK_12         1.0
    RHS           PACK_13         1.0
    RHS           PACK_14         1.0
    RHS           PACK_15         1.0
    RHS           PACK_16         1.0
    RHS           PACK_17         1.0
    RHS           PACK_18         1.0
    RHS           PACK_19         1.0
    RHS           PACK_20         1.0
    RHS           PACK_21         1.0
    RHS           PACK_22         1.0
    RHS           PACK_23         1.0
    RHS           PACK_24         1.0
    RHS           PACK_25         1.0
    RHS           PACK_26         1.0
    RHS           PACK_27         1.0
    RHS           PACK_28         1.0
    RHS           PACK_29         1.0
    RHS           PACK_30         1.0
    RHS           PACK_31         1.0
    RHS           PACK_32         1.0
    RHS           PACK_33         1.0
    RHS           PACK_34         1.0
    RHS           PACK_35         1.0
    RHS           PACK_36         1.0
    RHS           PACK_37         1.0
    RHS           PACK_38         1.0
    RHS           PACK_39         1.0
    RHS           PACK_40         1.0
    RHS           PACK_41         1.0
    RHS           PACK_42         1.0
    RHS           PACK_43         1.0
    RHS           PACK_44         1.0
    RHS           PACK_45         1.0
    RHS           PACK_46         1.0
    RHS           PACK_47         1.0
    RHS           PACK_48         1.0
    RHS           PACK_49         1.0
    RHS           PACK_50         1.0
    RHS           PACK_51         1.0
    RHS           PACK_52         1.0
    RHS           PACK_53         1.0
    RHS           PACK_54         1.0
    RHS           PACK_55         1.0
    RHS           PACK_56         1.0
    RHS           PACK_57         1.0
    RHS           PACK_58         1.0
    RHS           PACK_59         1.0
    RHS           PACK_60         1.0
    RHS           PACK_61         1.0
    RHS           PACK_62         1.0
    RHS           PACK_63         1.0
    RHS           PACK_64         1.0
    RHS           PACK_65         1.0
    RHS           PACK_66         1.0
    RHS           PACK_67         1.0
    RHS           PACK_68         1.0
    RHS           PACK_69         1.0
    RHS           PACK_70         1.0
    RHS           PACK_71         1.0
    RHS           PACK_72         1.0
    RHS           PACK_73         1.0
    RHS           PACK_74         1.0
    RHS           PACK_75         1.0
    RHS           PACK_76         1.0
    RHS           PACK_77         1.0
    RHS           PACK_78         1.0
    RHS           PACK_79         1.0
    RHS           PACK_80         1.0
    RHS           PACK_81         1.0
    RHS           PACK_82         1.0
    RHS           PACK_83         1.0
    RHS           PACK_84         1.0
    RHS           PACK_85         1.0
    RHS           PACK_86         1.0
    RHS           PACK_87         1.0
    RHS           PACK_88         1.0
    RHS           PACK_89         1.0
    RHS           PACK_90         1.0
    RHS           PACK_91         1.0
    RHS           PACK_92         1.0
    RHS           PACK_93         1.0
    RHS           PACK_94         1.0
    RHS           PACK_95         1.0
    RHS           PACK_96         1.0
    RHS           PACK_97         1.0
    RHS           PACK_98         1.0
    RHS           PACK_99         1.0
    RHS           PACK_100        1.0
    RHS           PACK_101        1.0
    RHS           PACK_102        1.0
    RHS           PACK_103        1.0
    RHS           PACK_104        1.0
    RHS           PACK_105        1.0
    RHS           PACK_106        1.0
    RHS           PACK_107        1.0
    RHS           PACK_108        1.0
    RHS           PACK_109        1.0
    RHS           PACK_110        1.0
    RHS           PACK_111        1.0
    RHS           PACK_112        1.0
    RHS           PACK_113        1.0
    RHS           PACK_114        1.0
    RHS           PACK_115        1.0
    RHS           PACK_116        1.0
    RHS           PACK_117        1.0
    RHS           PACK_118        1.0
    RHS           PACK_119        1.0
    RHS           PACK_120        1.0
    RHS           PACK_121        1.0
    RHS           PACK_122        1.0
    RHS           PACK_123        1.0
    RHS           PACK_124        1.0
    RHS           PACK_125        1.0
    RHS           PACK_126        1.0
    RHS           PACK_127        1.0
    RHS           PACK_128        1.0
    RHS           PACK_129        1.0
    RHS           PACK_130        1.0
    RHS           PACK_131        1.0
    RHS           PACK_132        1.0
    RHS           PACK_133        1.0
    RHS           PACK_134        1.0
    RHS           PACK_135        1.0
    RHS           PACK_136        1.0
    RHS           PACK_137        1.0
    RHS           PACK_138        1.0
    RHS           PACK_139        1.0
    RHS           PACK_140        1.0
    RHS           PACK_141        1.0
    RHS           PACK_142        1.0
    RHS           PACK_143        1.0
    RHS           PACK_144        1.0
    RHS           PACK_145        1.0
    RHS           PACK_146        1.0
    RHS           PACK_147        1.0
    RHS           PACK_148        1.0
    RHS           PACK_149        1.0
    RHS           PACK_150        1.0
    RHS           PACK_151        1.0
    RHS           PACK_152        1.0
    RHS           PACK_153        1.0
    RHS           PACK_154        1.0
    RHS           PACK_155        1.0
    RHS           PACK_156        1.0
    RHS           PACK_157        1.0
    RHS           PACK_158        1.0
    RHS           PACK_159        1.0
    RHS           PACK_160        1.0
    RHS           PACK_161        1.0
    RHS           PACK_162        1.0
    RHS           PACK_163        1.0
    RHS           PACK_164        1.0
    RHS           PACK_165        1.0
    RHS           PACK_166        1.0
    RHS           PACK_167        1.0
    RHS           PACK_168        1.0
    RHS           PACK_169        1.0
    RHS           PACK_170        1.0
    RHS           PACK_171        1.0
    RHS           PACK_172        1.0
    RHS           PACK_173        1.0
    RHS           PACK_174        1.0
    RHS           PACK_175        1.0
    RHS           PACK_176        1.0
    RHS           PACK_177        1.0
    RHS           PACK_178        1.0
    RHS           PACK_179        1.0
    RHS           COVER_0         1.0
    RHS           COVER_1         1.0
    RHS           COVER_2         1.0
    RHS           COVER_3         1.0
    RHS           COVER_4         1.0
    RHS           COVER_5         1.0
    RHS           COVER_6         1.0
    RHS           COVER_7         1.0
    RHS           COVER_8         1.0
    RHS           COVER_9         1.0
    RHS           COVER_10        1.0
    RHS           COVER_11        1.0
    RHS           COVER_12        1.0
    RHS           COVER_13        1.0
    RHS           COVER_14        1.0
    RHS           COVER_15        1.0
    RHS           COVER_16        1.0
    RHS           COVER_17        1.0
    RHS           COVER_18        1.0
    RHS           COVER_19        1.0
    RHS           COVER_20        1.0
    RHS           COVER_21        1.0
    RHS           COVER_22        1.0
    RHS           COVER_23        1.0
    RHS           COVER_24        1.0
    RHS           COVER_25        1.0
    RHS           COVER_26        1.0
    RHS           COVER_27        1.0
    RHS           COVER_28        1.0
    RHS           COVER_29        1.0
    RHS           COVER_30        1.0
    RHS           COVER_31        1.0
    RHS           COVER_32        1.0
    RHS           COVER_33        1.0
    RHS           COVER_34        1.0
    RHS           COVER_35        1.0
    RHS           COVER_36        1.0
    RHS           COVER_37        1.0
    RHS           COVER_38        1.0
    RHS           COVER_39        1.0
    RHS           COVER_40        1.0
    RHS           COVER_41        1.0
    RHS           COVER_42        1.0
    RHS           COVER_43        1.0
    RHS           COVER_44        1.0
    RHS           COVER_45        1.0
    RHS           COVER_46        1.0
    RHS           COVER_47        1.0
    RHS           COVER_48        1.0
    RHS           COVER_49        1.0
    RHS           COVER_50        1.0
    RHS           COVER_51        1.0
    RHS           COVER_52        1.0
    RHS           COVER_53        1.0
    RHS           COVER_54        1.0
    RHS           COVER_55        1.0
    RHS           COVER_56        1.0
    RHS           COVER_57        1.0
    RHS           COVER_58        1.0
    RHS           COVER_59        1.0
BOUNDS
 BV BOUND         x_0
 BV BOUND         x_1
 BV BOUND         x_2
 BV BOUND         x_3
 BV BOUND         x_4
 BV BOUND         x_5
 BV BOUND         x_6
 BV BOUND         x_7
 BV BOUND         x_8
 BV BOUND         x_9
 BV BOUND         x_10
 BV BOUND         x_11
 BV BOUND         x_12
 BV BOUND         x_13
 BV BOUND         x_14
 BV BOUND         x_15
 BV BOUND         x_16
 BV BOUND         x_17
 BV BOUND         x_18
 BV BOUND         x_19
 BV BOUND         x_20
 BV BOUND         x_21
 BV BOUND         x_22
 BV BOUND         x_23
 BV BOUND         x_24
 BV BOUND         x_25
 BV BOUND         x_26
 BV BOUND         x_27
 BV BOUND         x_28
 BV BOUND         x_29
 BV BOUND         x_30
 BV BOUND         x_31
 BV BOUND         x_32
 BV BOUND         x_33
 BV BOUND         x_34
 BV BOUND         x_35
 BV BOUND         x_36
 BV BOUND         x_37
 BV BOUND         x_38
 BV BOUND         x_39
 BV BOUND         x_40
 BV BOUND         x_41
 BV BOUND         x_42
 BV BOUND         x_43
 BV BOUND         x_44
 BV BOUND         x_45
 BV BOUND         x_46
 BV BOUND         x_47
 BV BOUND         x_48
 BV BOUND         x_49
 BV BOUND         x_50
 BV BOUND         x_51
 BV BOUND         x_52
 BV BOUND         x_53
 BV BOUND         x_54
 BV BOUND         x_55
 BV BOUND         x_56
 BV BOUND         x_57
 BV BOUND         x_58
 BV BOUND         x_59
 BV BOUND         x_60
 BV BOUND         x_61
 BV BOUND         x_62
 BV BOUND         x_63
 BV BOUND         x_64
 BV BOUND         x_65
 BV BOUND         x_66
 BV BOUND         x_67
 BV BOUND         x_68
 BV BOUND         x_69
 BV BOUND         x_70
 BV BOUND         x_71
 BV BOUND         x_72
 BV BOUND         x_73
 BV BOUND         x_74
 BV BOUND         x_75
 BV BOUND         x_76
 BV BOUND         x_77
 BV BOUND         x_78
 BV BOUND         x_79
 BV BOUND         x_80
 BV BOUND         x_81
 BV BOUND         x_82
 BV BOUND         x_83
 BV BOUND         x_84
 BV BOUND         x_85
 BV BOUND         x_86
 BV BOUND         x_87
 BV BOUND         x_88
 BV BOUND         x_89
 BV BOUND         x_90
 BV BOUND         x_91
 BV BOUND         x_92
 BV BOUND         x_93
 BV BOUND         x_94
 BV BOUND         x_95
 BV BOUND         x_96
 BV BOUND         x_97
 BV BOUND         x_98
 BV BOUND         x_99
 BV BOUND         x_100
 BV BOUND         x_101
 BV BOUND         x_102
 BV BOUND         x_103
 BV BOUND         x_104
 BV BOUND         x_105
 BV BOUND         x_106
 BV BOUND         x_107
 BV BOUND         x_108
 BV BOUND         x_109
 BV BOUND         x_110
 BV BOUND         x_111
 BV BOUND         x_112
 BV BOUND         x_113
 BV BOUND         x_114
 BV BOUND         x_115
 BV BOUND         x_116
 BV BOUND         x_117
 BV BOUND         x_118
 BV BOUND         x_119
 BV BOUND         x_120
 BV BOUND         x_121
 BV BOUND         x_122
 BV BOUND         x_123
 BV BOUND         x_124
 BV BOUND         x_125
 BV BOUND         x_126
 BV BOUND         x_127
 BV BOUND         x_128
 BV BOUND         x_129
 BV BOUND         x_130
 BV BOUND         x_131
 BV BOUND         x_132
 BV BOUND         x_133
 BV BOUND         x_134
 BV BOUND         x_135
 BV BOUND         x_136
 BV BOUND         x_137
 BV BOUND         x_138
 BV BOUND         x_139
 BV BOUND         x_140
 BV BOUND         x_141
 BV BOUND         x_142
 BV BOUND         x_143
 BV BOUND         x_144
 BV BOUND         x_145
 BV BOUND         x_146
 BV BOUND         x_147
 BV BOUND         x_148
 BV BOUND         x_149
 BV BOUND         x_150
 BV BOUND         x_151
 BV BOUND         x_152
 BV BOUND         x_153
 BV BOUND         x_154
 BV BOUND         x_155
 BV BOUND         x_156
 BV BOUND         x_157
 BV BOUND         x_158
 BV BOUND         x_159
 BV BOUND         x_160
 BV BOUND         x_161
 BV BOUND         x_162
 BV BOUND         x_163
 BV BOUND         x_164
 BV BOUND         x_165
 BV BOUND         x_166
 BV BOUND         x_167
 BV BOUND         x_168
 BV BOUND         x_169
 BV BOUND         x_170
 BV BOUND         x_171
 BV BOUND         x_172
 BV BOUND         x_173
 BV BOUND         x_174
 BV BOUND         x_175
 BV BOUND         x_176
 BV BOUND         x_177
 BV BOUND         x_178
 BV BOUND         x_179
 BV BOUND         x_180
 BV BOUND         x_181
 BV BOUND         x_182
 BV BOUND         x_183
 BV BOUND         x_184
 BV BOUND         x_185
 BV BOUND         x_186
 BV BOUND         x_187
 BV BOUND         x_188
 BV BOUND         x_189
 BV BOUND         x_190
 BV BOUND         x_191
 BV BOUND         x_192
 BV BOUND         x_193
 BV BOUND         x_194
 BV BOUND         x_195
 BV BOUND         x_196
 BV BOUND         x_197
 BV BOUND         x_198
 BV BOUND         x_199
 BV BOUND         x_200
 BV BOUND         x_201
 BV BOUND         x_202
 BV BOUND         x_203
 BV BOUND         x_204
 BV BOUND         x_205
 BV BOUND         x_206
 BV BOUND         x_207
 BV BOUND         x_208
 BV BOUND         x_209
 BV BOUND         x_210
 BV BOUND         x_211
 BV BOUND         x_212
 BV BOUND         x_213
 BV BOUND         x_214
 BV BOUND         x_215
 BV BOUND         x_216
 BV BOUND         x_217
 BV BOUND         x_218
 BV BOUND         x_219
 BV BOUND         x_220
 BV BOUND         x_221
 BV BOUND         x_222
 BV BOUND         x_223
 BV BOUND         x_224
 BV BOUND         x_225
 BV BOUND         x_226
 BV BOUND         x_227
 BV BOUND         x_228
 BV BOUND         x_229
 BV BOUND         x_230
 BV BOUND         x_231
 BV BOUND         x_232
 BV BOUND         x_233
 BV BOUND         x_234
 BV BOUND         x_235
 BV BOUND         x_236
 BV BOUND         x_237
 BV BOUND         x_238
 BV BOUND         x_239
 BV BOUND         x_240
 BV BOUND         x_241
 BV BOUND         x_242
 BV BOUND         x_243
 BV BOUND         x_244
 BV BOUND         x_245
 BV BOUND         x_246
 BV BOUND         x_247
 BV BOUND         x_248
 BV BOUND         x_249
 BV BOUND         x_250
 BV BOUND         x_251
 BV BOUND         x_252
 BV BOUND         x_253
 BV BOUND         x_254
 BV BOUND         x_255
 BV BOUND         x_256
 BV BOUND         x_257
 BV BOUND         x_258
 BV BOUND         x_259
 BV BOUND         x_260
 BV BOUND         x_261
 BV BOUND         x_262
 BV BOUND         x_263
ENDATA
