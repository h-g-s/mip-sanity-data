NAME          steiner_grid5x5_t4_sparse
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 L  cap_0_1
 L  cap_0_5
 L  cap_1_2
 L  cap_1_6
 L  cap_2_3
 L  cap_2_7
 L  cap_3_4
 L  cap_3_8
 L  cap_4_9
 L  cap_5_6
 L  cap_5_10
 L  cap_6_7
 L  cap_6_11
 L  cap_7_8
 L  cap_7_12
 L  cap_8_9
 L  cap_8_13
 L  cap_9_14
 L  cap_10_11
 L  cap_10_15
 L  cap_11_12
 L  cap_11_16
 L  cap_12_13
 L  cap_12_17
 L  cap_13_14
 L  cap_13_18
 L  cap_14_19
 L  cap_15_16
 L  cap_15_20
 L  cap_16_17
 L  cap_16_21
 L  cap_17_18
 L  cap_17_22
 L  cap_18_19
 L  cap_18_23
 L  cap_19_24
 L  cap_20_21
 L  cap_21_22
 L  cap_22_23
 L  cap_23_24
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       1.0
    x_0_1     cap_0_1   -4
    x_0_5     OBJ       1.0
    x_0_5     cap_0_5   -4
    x_1_2     OBJ       1.0
    x_1_2     cap_1_2   -4
    x_1_6     OBJ       1.0
    x_1_6     cap_1_6   -4
    x_2_3     OBJ       1.0
    x_2_3     cap_2_3   -4
    x_2_7     OBJ       1.0
    x_2_7     cap_2_7   -4
    x_3_4     OBJ       1.0
    x_3_4     cap_3_4   -4
    x_3_8     OBJ       1.0
    x_3_8     cap_3_8   -4
    x_4_9     OBJ       1.0
    x_4_9     cap_4_9   -4
    x_5_6     OBJ       1.0
    x_5_6     cap_5_6   -4
    x_5_10    OBJ       1.0
    x_5_10    cap_5_10  -4
    x_6_7     OBJ       1.0
    x_6_7     cap_6_7   -4
    x_6_11    OBJ       1.0
    x_6_11    cap_6_11  -4
    x_7_8     OBJ       1.0
    x_7_8     cap_7_8   -4
    x_7_12    OBJ       1.0
    x_7_12    cap_7_12  -4
    x_8_9     OBJ       1.0
    x_8_9     cap_8_9   -4
    x_8_13    OBJ       1.0
    x_8_13    cap_8_13  -4
    x_9_14    OBJ       1.0
    x_9_14    cap_9_14  -4
    x_10_11   OBJ       1.0
    x_10_11   cap_10_11  -4
    x_10_15   OBJ       1.0
    x_10_15   cap_10_15  -4
    x_11_12   OBJ       1.0
    x_11_12   cap_11_12  -4
    x_11_16   OBJ       1.0
    x_11_16   cap_11_16  -4
    x_12_13   OBJ       1.0
    x_12_13   cap_12_13  -4
    x_12_17   OBJ       1.0
    x_12_17   cap_12_17  -4
    x_13_14   OBJ       1.0
    x_13_14   cap_13_14  -4
    x_13_18   OBJ       1.0
    x_13_18   cap_13_18  -4
    x_14_19   OBJ       1.0
    x_14_19   cap_14_19  -4
    x_15_16   OBJ       1.0
    x_15_16   cap_15_16  -4
    x_15_20   OBJ       1.0
    x_15_20   cap_15_20  -4
    x_16_17   OBJ       1.0
    x_16_17   cap_16_17  -4
    x_16_21   OBJ       1.0
    x_16_21   cap_16_21  -4
    x_17_18   OBJ       1.0
    x_17_18   cap_17_18  -4
    x_17_22   OBJ       1.0
    x_17_22   cap_17_22  -4
    x_18_19   OBJ       1.0
    x_18_19   cap_18_19  -4
    x_18_23   OBJ       1.0
    x_18_23   cap_18_23  -4
    x_19_24   OBJ       1.0
    x_19_24   cap_19_24  -4
    x_20_21   OBJ       1.0
    x_20_21   cap_20_21  -4
    x_21_22   OBJ       1.0
    x_21_22   cap_21_22  -4
    x_22_23   OBJ       1.0
    x_22_23   cap_22_23  -4
    x_23_24   OBJ       1.0
    x_23_24   cap_23_24  -4
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_5     flow_0    1.0
    f_0_5     flow_5    -1.0
    f_0_5     cap_0_5   1.0
    f_5_0     flow_0    -1.0
    f_5_0     flow_5    1.0
    f_5_0     cap_0_5   1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_6     flow_1    1.0
    f_1_6     flow_6    -1.0
    f_1_6     cap_1_6   1.0
    f_6_1     flow_1    -1.0
    f_6_1     flow_6    1.0
    f_6_1     cap_1_6   1.0
    f_2_3     flow_2    1.0
    f_2_3     flow_3    -1.0
    f_2_3     cap_2_3   1.0
    f_3_2     flow_2    -1.0
    f_3_2     flow_3    1.0
    f_3_2     cap_2_3   1.0
    f_2_7     flow_2    1.0
    f_2_7     flow_7    -1.0
    f_2_7     cap_2_7   1.0
    f_7_2     flow_2    -1.0
    f_7_2     flow_7    1.0
    f_7_2     cap_2_7   1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_8     flow_3    1.0
    f_3_8     flow_8    -1.0
    f_3_8     cap_3_8   1.0
    f_8_3     flow_3    -1.0
    f_8_3     flow_8    1.0
    f_8_3     cap_3_8   1.0
    f_4_9     flow_4    1.0
    f_4_9     flow_9    -1.0
    f_4_9     cap_4_9   1.0
    f_9_4     flow_4    -1.0
    f_9_4     flow_9    1.0
    f_9_4     cap_4_9   1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_10    flow_5    1.0
    f_5_10    flow_10   -1.0
    f_5_10    cap_5_10  1.0
    f_10_5    flow_5    -1.0
    f_10_5    flow_10   1.0
    f_10_5    cap_5_10  1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_11    flow_6    1.0
    f_6_11    flow_11   -1.0
    f_6_11    cap_6_11  1.0
    f_11_6    flow_6    -1.0
    f_11_6    flow_11   1.0
    f_11_6    cap_6_11  1.0
    f_7_8     flow_7    1.0
    f_7_8     flow_8    -1.0
    f_7_8     cap_7_8   1.0
    f_8_7     flow_7    -1.0
    f_8_7     flow_8    1.0
    f_8_7     cap_7_8   1.0
    f_7_12    flow_7    1.0
    f_7_12    flow_12   -1.0
    f_7_12    cap_7_12  1.0
    f_12_7    flow_7    -1.0
    f_12_7    flow_12   1.0
    f_12_7    cap_7_12  1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
    f_8_13    flow_8    1.0
    f_8_13    flow_13   -1.0
    f_8_13    cap_8_13  1.0
    f_13_8    flow_8    -1.0
    f_13_8    flow_13   1.0
    f_13_8    cap_8_13  1.0
    f_9_14    flow_9    1.0
    f_9_14    flow_14   -1.0
    f_9_14    cap_9_14  1.0
    f_14_9    flow_9    -1.0
    f_14_9    flow_14   1.0
    f_14_9    cap_9_14  1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
    f_10_15   flow_10   1.0
    f_10_15   flow_15   -1.0
    f_10_15   cap_10_15  1.0
    f_15_10   flow_10   -1.0
    f_15_10   flow_15   1.0
    f_15_10   cap_10_15  1.0
    f_11_12   flow_11   1.0
    f_11_12   flow_12   -1.0
    f_11_12   cap_11_12  1.0
    f_12_11   flow_11   -1.0
    f_12_11   flow_12   1.0
    f_12_11   cap_11_12  1.0
    f_11_16   flow_11   1.0
    f_11_16   flow_16   -1.0
    f_11_16   cap_11_16  1.0
    f_16_11   flow_11   -1.0
    f_16_11   flow_16   1.0
    f_16_11   cap_11_16  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_12_17   flow_12   1.0
    f_12_17   flow_17   -1.0
    f_12_17   cap_12_17  1.0
    f_17_12   flow_12   -1.0
    f_17_12   flow_17   1.0
    f_17_12   cap_12_17  1.0
    f_13_14   flow_13   1.0
    f_13_14   flow_14   -1.0
    f_13_14   cap_13_14  1.0
    f_14_13   flow_13   -1.0
    f_14_13   flow_14   1.0
    f_14_13   cap_13_14  1.0
    f_13_18   flow_13   1.0
    f_13_18   flow_18   -1.0
    f_13_18   cap_13_18  1.0
    f_18_13   flow_13   -1.0
    f_18_13   flow_18   1.0
    f_18_13   cap_13_18  1.0
    f_14_19   flow_14   1.0
    f_14_19   flow_19   -1.0
    f_14_19   cap_14_19  1.0
    f_19_14   flow_14   -1.0
    f_19_14   flow_19   1.0
    f_19_14   cap_14_19  1.0
    f_15_16   flow_15   1.0
    f_15_16   flow_16   -1.0
    f_15_16   cap_15_16  1.0
    f_16_15   flow_15   -1.0
    f_16_15   flow_16   1.0
    f_16_15   cap_15_16  1.0
    f_15_20   flow_15   1.0
    f_15_20   flow_20   -1.0
    f_15_20   cap_15_20  1.0
    f_20_15   flow_15   -1.0
    f_20_15   flow_20   1.0
    f_20_15   cap_15_20  1.0
    f_16_17   flow_16   1.0
    f_16_17   flow_17   -1.0
    f_16_17   cap_16_17  1.0
    f_17_16   flow_16   -1.0
    f_17_16   flow_17   1.0
    f_17_16   cap_16_17  1.0
    f_16_21   flow_16   1.0
    f_16_21   flow_21   -1.0
    f_16_21   cap_16_21  1.0
    f_21_16   flow_16   -1.0
    f_21_16   flow_21   1.0
    f_21_16   cap_16_21  1.0
    f_17_18   flow_17   1.0
    f_17_18   flow_18   -1.0
    f_17_18   cap_17_18  1.0
    f_18_17   flow_17   -1.0
    f_18_17   flow_18   1.0
    f_18_17   cap_17_18  1.0
    f_17_22   flow_17   1.0
    f_17_22   flow_22   -1.0
    f_17_22   cap_17_22  1.0
    f_22_17   flow_17   -1.0
    f_22_17   flow_22   1.0
    f_22_17   cap_17_22  1.0
    f_18_19   flow_18   1.0
    f_18_19   flow_19   -1.0
    f_18_19   cap_18_19  1.0
    f_19_18   flow_18   -1.0
    f_19_18   flow_19   1.0
    f_19_18   cap_18_19  1.0
    f_18_23   flow_18   1.0
    f_18_23   flow_23   -1.0
    f_18_23   cap_18_23  1.0
    f_23_18   flow_18   -1.0
    f_23_18   flow_23   1.0
    f_23_18   cap_18_23  1.0
    f_19_24   flow_19   1.0
    f_19_24   flow_24   -1.0
    f_19_24   cap_19_24  1.0
    f_24_19   flow_19   -1.0
    f_24_19   flow_24   1.0
    f_24_19   cap_19_24  1.0
    f_20_21   flow_20   1.0
    f_20_21   flow_21   -1.0
    f_20_21   cap_20_21  1.0
    f_21_20   flow_20   -1.0
    f_21_20   flow_21   1.0
    f_21_20   cap_20_21  1.0
    f_21_22   flow_21   1.0
    f_21_22   flow_22   -1.0
    f_21_22   cap_21_22  1.0
    f_22_21   flow_21   -1.0
    f_22_21   flow_22   1.0
    f_22_21   cap_21_22  1.0
    f_22_23   flow_22   1.0
    f_22_23   flow_23   -1.0
    f_22_23   cap_22_23  1.0
    f_23_22   flow_22   -1.0
    f_23_22   flow_23   1.0
    f_23_22   cap_22_23  1.0
    f_23_24   flow_23   1.0
    f_23_24   flow_24   -1.0
    f_23_24   cap_23_24  1.0
    f_24_23   flow_23   -1.0
    f_24_23   flow_24   1.0
    f_24_23   cap_23_24  1.0
RHS
    RHS       flow_0    4
    RHS       flow_3    -1
    RHS       flow_6    -1
    RHS       flow_11   -1
    RHS       flow_14   -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_5
 BV BOUND     x_1_2
 BV BOUND     x_1_6
 BV BOUND     x_2_3
 BV BOUND     x_2_7
 BV BOUND     x_3_4
 BV BOUND     x_3_8
 BV BOUND     x_4_9
 BV BOUND     x_5_6
 BV BOUND     x_5_10
 BV BOUND     x_6_7
 BV BOUND     x_6_11
 BV BOUND     x_7_8
 BV BOUND     x_7_12
 BV BOUND     x_8_9
 BV BOUND     x_8_13
 BV BOUND     x_9_14
 BV BOUND     x_10_11
 BV BOUND     x_10_15
 BV BOUND     x_11_12
 BV BOUND     x_11_16
 BV BOUND     x_12_13
 BV BOUND     x_12_17
 BV BOUND     x_13_14
 BV BOUND     x_13_18
 BV BOUND     x_14_19
 BV BOUND     x_15_16
 BV BOUND     x_15_20
 BV BOUND     x_16_17
 BV BOUND     x_16_21
 BV BOUND     x_17_18
 BV BOUND     x_17_22
 BV BOUND     x_18_19
 BV BOUND     x_18_23
 BV BOUND     x_19_24
 BV BOUND     x_20_21
 BV BOUND     x_21_22
 BV BOUND     x_22_23
 BV BOUND     x_23_24
 UP BOUND     f_0_1     4
 UP BOUND     f_1_0     4
 UP BOUND     f_0_5     4
 UP BOUND     f_5_0     4
 UP BOUND     f_1_2     4
 UP BOUND     f_2_1     4
 UP BOUND     f_1_6     4
 UP BOUND     f_6_1     4
 UP BOUND     f_2_3     4
 UP BOUND     f_3_2     4
 UP BOUND     f_2_7     4
 UP BOUND     f_7_2     4
 UP BOUND     f_3_4     4
 UP BOUND     f_4_3     4
 UP BOUND     f_3_8     4
 UP BOUND     f_8_3     4
 UP BOUND     f_4_9     4
 UP BOUND     f_9_4     4
 UP BOUND     f_5_6     4
 UP BOUND     f_6_5     4
 UP BOUND     f_5_10    4
 UP BOUND     f_10_5    4
 UP BOUND     f_6_7     4
 UP BOUND     f_7_6     4
 UP BOUND     f_6_11    4
 UP BOUND     f_11_6    4
 UP BOUND     f_7_8     4
 UP BOUND     f_8_7     4
 UP BOUND     f_7_12    4
 UP BOUND     f_12_7    4
 UP BOUND     f_8_9     4
 UP BOUND     f_9_8     4
 UP BOUND     f_8_13    4
 UP BOUND     f_13_8    4
 UP BOUND     f_9_14    4
 UP BOUND     f_14_9    4
 UP BOUND     f_10_11   4
 UP BOUND     f_11_10   4
 UP BOUND     f_10_15   4
 UP BOUND     f_15_10   4
 UP BOUND     f_11_12   4
 UP BOUND     f_12_11   4
 UP BOUND     f_11_16   4
 UP BOUND     f_16_11   4
 UP BOUND     f_12_13   4
 UP BOUND     f_13_12   4
 UP BOUND     f_12_17   4
 UP BOUND     f_17_12   4
 UP BOUND     f_13_14   4
 UP BOUND     f_14_13   4
 UP BOUND     f_13_18   4
 UP BOUND     f_18_13   4
 UP BOUND     f_14_19   4
 UP BOUND     f_19_14   4
 UP BOUND     f_15_16   4
 UP BOUND     f_16_15   4
 UP BOUND     f_15_20   4
 UP BOUND     f_20_15   4
 UP BOUND     f_16_17   4
 UP BOUND     f_17_16   4
 UP BOUND     f_16_21   4
 UP BOUND     f_21_16   4
 UP BOUND     f_17_18   4
 UP BOUND     f_18_17   4
 UP BOUND     f_17_22   4
 UP BOUND     f_22_17   4
 UP BOUND     f_18_19   4
 UP BOUND     f_19_18   4
 UP BOUND     f_18_23   4
 UP BOUND     f_23_18   4
 UP BOUND     f_19_24   4
 UP BOUND     f_24_19   4
 UP BOUND     f_20_21   4
 UP BOUND     f_21_20   4
 UP BOUND     f_21_22   4
 UP BOUND     f_22_21   4
 UP BOUND     f_22_23   4
 UP BOUND     f_23_22   4
 UP BOUND     f_23_24   4
 UP BOUND     f_24_23   4
ENDATA
