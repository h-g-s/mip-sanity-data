NAME          jssp_search_n7_m6_uniform_pt1-20_s1
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_5_6_5
 G  disj2_5_6_5
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_2  -1.0
    x_0_0     disj2_0_1_2  1.0
    x_0_0     disj1_0_2_2  -1.0
    x_0_0     disj2_0_2_2  1.0
    x_0_0     disj1_0_3_2  -1.0
    x_0_0     disj2_0_3_2  1.0
    x_0_0     disj1_0_4_2  -1.0
    x_0_0     disj2_0_4_2  1.0
    x_0_0     disj1_0_5_2  -1.0
    x_0_0     disj2_0_5_2  1.0
    x_0_0     disj1_0_6_2  -1.0
    x_0_0     disj2_0_6_2  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_3  -1.0
    x_0_1     disj2_0_1_3  1.0
    x_0_1     disj1_0_2_3  -1.0
    x_0_1     disj2_0_2_3  1.0
    x_0_1     disj1_0_3_3  -1.0
    x_0_1     disj2_0_3_3  1.0
    x_0_1     disj1_0_4_3  -1.0
    x_0_1     disj2_0_4_3  1.0
    x_0_1     disj1_0_5_3  -1.0
    x_0_1     disj2_0_5_3  1.0
    x_0_1     disj1_0_6_3  -1.0
    x_0_1     disj2_0_6_3  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_5  -1.0
    x_0_2     disj2_0_1_5  1.0
    x_0_2     disj1_0_2_5  -1.0
    x_0_2     disj2_0_2_5  1.0
    x_0_2     disj1_0_3_5  -1.0
    x_0_2     disj2_0_3_5  1.0
    x_0_2     disj1_0_4_5  -1.0
    x_0_2     disj2_0_4_5  1.0
    x_0_2     disj1_0_5_5  -1.0
    x_0_2     disj2_0_5_5  1.0
    x_0_2     disj1_0_6_5  -1.0
    x_0_2     disj2_0_6_5  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_0  -1.0
    x_0_3     disj2_0_1_0  1.0
    x_0_3     disj1_0_2_0  -1.0
    x_0_3     disj2_0_2_0  1.0
    x_0_3     disj1_0_3_0  -1.0
    x_0_3     disj2_0_3_0  1.0
    x_0_3     disj1_0_4_0  -1.0
    x_0_3     disj2_0_4_0  1.0
    x_0_3     disj1_0_5_0  -1.0
    x_0_3     disj2_0_5_0  1.0
    x_0_3     disj1_0_6_0  -1.0
    x_0_3     disj2_0_6_0  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_4  -1.0
    x_0_4     disj2_0_1_4  1.0
    x_0_4     disj1_0_2_4  -1.0
    x_0_4     disj2_0_2_4  1.0
    x_0_4     disj1_0_3_4  -1.0
    x_0_4     disj2_0_3_4  1.0
    x_0_4     disj1_0_4_4  -1.0
    x_0_4     disj2_0_4_4  1.0
    x_0_4     disj1_0_5_4  -1.0
    x_0_4     disj2_0_5_4  1.0
    x_0_4     disj1_0_6_4  -1.0
    x_0_4     disj2_0_6_4  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     mksp_0    -1.0
    x_0_5     disj1_0_1_1  -1.0
    x_0_5     disj2_0_1_1  1.0
    x_0_5     disj1_0_2_1  -1.0
    x_0_5     disj2_0_2_1  1.0
    x_0_5     disj1_0_3_1  -1.0
    x_0_5     disj2_0_3_1  1.0
    x_0_5     disj1_0_4_1  -1.0
    x_0_5     disj2_0_4_1  1.0
    x_0_5     disj1_0_5_1  -1.0
    x_0_5     disj2_0_5_1  1.0
    x_0_5     disj1_0_6_1  -1.0
    x_0_5     disj2_0_6_1  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_2  1.0
    x_1_0     disj2_0_1_2  -1.0
    x_1_0     disj1_1_2_2  -1.0
    x_1_0     disj2_1_2_2  1.0
    x_1_0     disj1_1_3_2  -1.0
    x_1_0     disj2_1_3_2  1.0
    x_1_0     disj1_1_4_2  -1.0
    x_1_0     disj2_1_4_2  1.0
    x_1_0     disj1_1_5_2  -1.0
    x_1_0     disj2_1_5_2  1.0
    x_1_0     disj1_1_6_2  -1.0
    x_1_0     disj2_1_6_2  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_4  1.0
    x_1_1     disj2_0_1_4  -1.0
    x_1_1     disj1_1_2_4  -1.0
    x_1_1     disj2_1_2_4  1.0
    x_1_1     disj1_1_3_4  -1.0
    x_1_1     disj2_1_3_4  1.0
    x_1_1     disj1_1_4_4  -1.0
    x_1_1     disj2_1_4_4  1.0
    x_1_1     disj1_1_5_4  -1.0
    x_1_1     disj2_1_5_4  1.0
    x_1_1     disj1_1_6_4  -1.0
    x_1_1     disj2_1_6_4  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_1  1.0
    x_1_2     disj2_0_1_1  -1.0
    x_1_2     disj1_1_2_1  -1.0
    x_1_2     disj2_1_2_1  1.0
    x_1_2     disj1_1_3_1  -1.0
    x_1_2     disj2_1_3_1  1.0
    x_1_2     disj1_1_4_1  -1.0
    x_1_2     disj2_1_4_1  1.0
    x_1_2     disj1_1_5_1  -1.0
    x_1_2     disj2_1_5_1  1.0
    x_1_2     disj1_1_6_1  -1.0
    x_1_2     disj2_1_6_1  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_5  1.0
    x_1_3     disj2_0_1_5  -1.0
    x_1_3     disj1_1_2_5  -1.0
    x_1_3     disj2_1_2_5  1.0
    x_1_3     disj1_1_3_5  -1.0
    x_1_3     disj2_1_3_5  1.0
    x_1_3     disj1_1_4_5  -1.0
    x_1_3     disj2_1_4_5  1.0
    x_1_3     disj1_1_5_5  -1.0
    x_1_3     disj2_1_5_5  1.0
    x_1_3     disj1_1_6_5  -1.0
    x_1_3     disj2_1_6_5  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_0  1.0
    x_1_4     disj2_0_1_0  -1.0
    x_1_4     disj1_1_2_0  -1.0
    x_1_4     disj2_1_2_0  1.0
    x_1_4     disj1_1_3_0  -1.0
    x_1_4     disj2_1_3_0  1.0
    x_1_4     disj1_1_4_0  -1.0
    x_1_4     disj2_1_4_0  1.0
    x_1_4     disj1_1_5_0  -1.0
    x_1_4     disj2_1_5_0  1.0
    x_1_4     disj1_1_6_0  -1.0
    x_1_4     disj2_1_6_0  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     mksp_1    -1.0
    x_1_5     disj1_0_1_3  1.0
    x_1_5     disj2_0_1_3  -1.0
    x_1_5     disj1_1_2_3  -1.0
    x_1_5     disj2_1_2_3  1.0
    x_1_5     disj1_1_3_3  -1.0
    x_1_5     disj2_1_3_3  1.0
    x_1_5     disj1_1_4_3  -1.0
    x_1_5     disj2_1_4_3  1.0
    x_1_5     disj1_1_5_3  -1.0
    x_1_5     disj2_1_5_3  1.0
    x_1_5     disj1_1_6_3  -1.0
    x_1_5     disj2_1_6_3  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_1  1.0
    x_2_0     disj2_0_2_1  -1.0
    x_2_0     disj1_1_2_1  1.0
    x_2_0     disj2_1_2_1  -1.0
    x_2_0     disj1_2_3_1  -1.0
    x_2_0     disj2_2_3_1  1.0
    x_2_0     disj1_2_4_1  -1.0
    x_2_0     disj2_2_4_1  1.0
    x_2_0     disj1_2_5_1  -1.0
    x_2_0     disj2_2_5_1  1.0
    x_2_0     disj1_2_6_1  -1.0
    x_2_0     disj2_2_6_1  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_1     disj1_2_6_3  -1.0
    x_2_1     disj2_2_6_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_2  1.0
    x_2_2     disj2_0_2_2  -1.0
    x_2_2     disj1_1_2_2  1.0
    x_2_2     disj2_1_2_2  -1.0
    x_2_2     disj1_2_3_2  -1.0
    x_2_2     disj2_2_3_2  1.0
    x_2_2     disj1_2_4_2  -1.0
    x_2_2     disj2_2_4_2  1.0
    x_2_2     disj1_2_5_2  -1.0
    x_2_2     disj2_2_5_2  1.0
    x_2_2     disj1_2_6_2  -1.0
    x_2_2     disj2_2_6_2  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_4  1.0
    x_2_3     disj2_0_2_4  -1.0
    x_2_3     disj1_1_2_4  1.0
    x_2_3     disj2_1_2_4  -1.0
    x_2_3     disj1_2_3_4  -1.0
    x_2_3     disj2_2_3_4  1.0
    x_2_3     disj1_2_4_4  -1.0
    x_2_3     disj2_2_4_4  1.0
    x_2_3     disj1_2_5_4  -1.0
    x_2_3     disj2_2_5_4  1.0
    x_2_3     disj1_2_6_4  -1.0
    x_2_3     disj2_2_6_4  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_5  1.0
    x_2_4     disj2_0_2_5  -1.0
    x_2_4     disj1_1_2_5  1.0
    x_2_4     disj2_1_2_5  -1.0
    x_2_4     disj1_2_3_5  -1.0
    x_2_4     disj2_2_3_5  1.0
    x_2_4     disj1_2_4_5  -1.0
    x_2_4     disj2_2_4_5  1.0
    x_2_4     disj1_2_5_5  -1.0
    x_2_4     disj2_2_5_5  1.0
    x_2_4     disj1_2_6_5  -1.0
    x_2_4     disj2_2_6_5  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     mksp_2    -1.0
    x_2_5     disj1_0_2_0  1.0
    x_2_5     disj2_0_2_0  -1.0
    x_2_5     disj1_1_2_0  1.0
    x_2_5     disj2_1_2_0  -1.0
    x_2_5     disj1_2_3_0  -1.0
    x_2_5     disj2_2_3_0  1.0
    x_2_5     disj1_2_4_0  -1.0
    x_2_5     disj2_2_4_0  1.0
    x_2_5     disj1_2_5_0  -1.0
    x_2_5     disj2_2_5_0  1.0
    x_2_5     disj1_2_6_0  -1.0
    x_2_5     disj2_2_6_0  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_2  1.0
    x_3_0     disj2_0_3_2  -1.0
    x_3_0     disj1_1_3_2  1.0
    x_3_0     disj2_1_3_2  -1.0
    x_3_0     disj1_2_3_2  1.0
    x_3_0     disj2_2_3_2  -1.0
    x_3_0     disj1_3_4_2  -1.0
    x_3_0     disj2_3_4_2  1.0
    x_3_0     disj1_3_5_2  -1.0
    x_3_0     disj2_3_5_2  1.0
    x_3_0     disj1_3_6_2  -1.0
    x_3_0     disj2_3_6_2  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_0  1.0
    x_3_1     disj2_0_3_0  -1.0
    x_3_1     disj1_1_3_0  1.0
    x_3_1     disj2_1_3_0  -1.0
    x_3_1     disj1_2_3_0  1.0
    x_3_1     disj2_2_3_0  -1.0
    x_3_1     disj1_3_4_0  -1.0
    x_3_1     disj2_3_4_0  1.0
    x_3_1     disj1_3_5_0  -1.0
    x_3_1     disj2_3_5_0  1.0
    x_3_1     disj1_3_6_0  -1.0
    x_3_1     disj2_3_6_0  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_4  1.0
    x_3_2     disj2_0_3_4  -1.0
    x_3_2     disj1_1_3_4  1.0
    x_3_2     disj2_1_3_4  -1.0
    x_3_2     disj1_2_3_4  1.0
    x_3_2     disj2_2_3_4  -1.0
    x_3_2     disj1_3_4_4  -1.0
    x_3_2     disj2_3_4_4  1.0
    x_3_2     disj1_3_5_4  -1.0
    x_3_2     disj2_3_5_4  1.0
    x_3_2     disj1_3_6_4  -1.0
    x_3_2     disj2_3_6_4  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_1  1.0
    x_3_3     disj2_0_3_1  -1.0
    x_3_3     disj1_1_3_1  1.0
    x_3_3     disj2_1_3_1  -1.0
    x_3_3     disj1_2_3_1  1.0
    x_3_3     disj2_2_3_1  -1.0
    x_3_3     disj1_3_4_1  -1.0
    x_3_3     disj2_3_4_1  1.0
    x_3_3     disj1_3_5_1  -1.0
    x_3_3     disj2_3_5_1  1.0
    x_3_3     disj1_3_6_1  -1.0
    x_3_3     disj2_3_6_1  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_5  1.0
    x_3_4     disj2_0_3_5  -1.0
    x_3_4     disj1_1_3_5  1.0
    x_3_4     disj2_1_3_5  -1.0
    x_3_4     disj1_2_3_5  1.0
    x_3_4     disj2_2_3_5  -1.0
    x_3_4     disj1_3_4_5  -1.0
    x_3_4     disj2_3_4_5  1.0
    x_3_4     disj1_3_5_5  -1.0
    x_3_4     disj2_3_5_5  1.0
    x_3_4     disj1_3_6_5  -1.0
    x_3_4     disj2_3_6_5  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     mksp_3    -1.0
    x_3_5     disj1_0_3_3  1.0
    x_3_5     disj2_0_3_3  -1.0
    x_3_5     disj1_1_3_3  1.0
    x_3_5     disj2_1_3_3  -1.0
    x_3_5     disj1_2_3_3  1.0
    x_3_5     disj2_2_3_3  -1.0
    x_3_5     disj1_3_4_3  -1.0
    x_3_5     disj2_3_4_3  1.0
    x_3_5     disj1_3_5_3  -1.0
    x_3_5     disj2_3_5_3  1.0
    x_3_5     disj1_3_6_3  -1.0
    x_3_5     disj2_3_6_3  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_4  1.0
    x_4_0     disj2_0_4_4  -1.0
    x_4_0     disj1_1_4_4  1.0
    x_4_0     disj2_1_4_4  -1.0
    x_4_0     disj1_2_4_4  1.0
    x_4_0     disj2_2_4_4  -1.0
    x_4_0     disj1_3_4_4  1.0
    x_4_0     disj2_3_4_4  -1.0
    x_4_0     disj1_4_5_4  -1.0
    x_4_0     disj2_4_5_4  1.0
    x_4_0     disj1_4_6_4  -1.0
    x_4_0     disj2_4_6_4  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_3  1.0
    x_4_1     disj2_0_4_3  -1.0
    x_4_1     disj1_1_4_3  1.0
    x_4_1     disj2_1_4_3  -1.0
    x_4_1     disj1_2_4_3  1.0
    x_4_1     disj2_2_4_3  -1.0
    x_4_1     disj1_3_4_3  1.0
    x_4_1     disj2_3_4_3  -1.0
    x_4_1     disj1_4_5_3  -1.0
    x_4_1     disj2_4_5_3  1.0
    x_4_1     disj1_4_6_3  -1.0
    x_4_1     disj2_4_6_3  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_2  1.0
    x_4_2     disj2_0_4_2  -1.0
    x_4_2     disj1_1_4_2  1.0
    x_4_2     disj2_1_4_2  -1.0
    x_4_2     disj1_2_4_2  1.0
    x_4_2     disj2_2_4_2  -1.0
    x_4_2     disj1_3_4_2  1.0
    x_4_2     disj2_3_4_2  -1.0
    x_4_2     disj1_4_5_2  -1.0
    x_4_2     disj2_4_5_2  1.0
    x_4_2     disj1_4_6_2  -1.0
    x_4_2     disj2_4_6_2  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_0  1.0
    x_4_4     disj2_0_4_0  -1.0
    x_4_4     disj1_1_4_0  1.0
    x_4_4     disj2_1_4_0  -1.0
    x_4_4     disj1_2_4_0  1.0
    x_4_4     disj2_2_4_0  -1.0
    x_4_4     disj1_3_4_0  1.0
    x_4_4     disj2_3_4_0  -1.0
    x_4_4     disj1_4_5_0  -1.0
    x_4_4     disj2_4_5_0  1.0
    x_4_4     disj1_4_6_0  -1.0
    x_4_4     disj2_4_6_0  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     mksp_4    -1.0
    x_4_5     disj1_0_4_5  1.0
    x_4_5     disj2_0_4_5  -1.0
    x_4_5     disj1_1_4_5  1.0
    x_4_5     disj2_1_4_5  -1.0
    x_4_5     disj1_2_4_5  1.0
    x_4_5     disj2_2_4_5  -1.0
    x_4_5     disj1_3_4_5  1.0
    x_4_5     disj2_3_4_5  -1.0
    x_4_5     disj1_4_5_5  -1.0
    x_4_5     disj2_4_5_5  1.0
    x_4_5     disj1_4_6_5  -1.0
    x_4_5     disj2_4_6_5  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_0  1.0
    x_5_0     disj2_0_5_0  -1.0
    x_5_0     disj1_1_5_0  1.0
    x_5_0     disj2_1_5_0  -1.0
    x_5_0     disj1_2_5_0  1.0
    x_5_0     disj2_2_5_0  -1.0
    x_5_0     disj1_3_5_0  1.0
    x_5_0     disj2_3_5_0  -1.0
    x_5_0     disj1_4_5_0  1.0
    x_5_0     disj2_4_5_0  -1.0
    x_5_0     disj1_5_6_0  -1.0
    x_5_0     disj2_5_6_0  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_1  1.0
    x_5_1     disj2_0_5_1  -1.0
    x_5_1     disj1_1_5_1  1.0
    x_5_1     disj2_1_5_1  -1.0
    x_5_1     disj1_2_5_1  1.0
    x_5_1     disj2_2_5_1  -1.0
    x_5_1     disj1_3_5_1  1.0
    x_5_1     disj2_3_5_1  -1.0
    x_5_1     disj1_4_5_1  1.0
    x_5_1     disj2_4_5_1  -1.0
    x_5_1     disj1_5_6_1  -1.0
    x_5_1     disj2_5_6_1  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_4  1.0
    x_5_2     disj2_0_5_4  -1.0
    x_5_2     disj1_1_5_4  1.0
    x_5_2     disj2_1_5_4  -1.0
    x_5_2     disj1_2_5_4  1.0
    x_5_2     disj2_2_5_4  -1.0
    x_5_2     disj1_3_5_4  1.0
    x_5_2     disj2_3_5_4  -1.0
    x_5_2     disj1_4_5_4  1.0
    x_5_2     disj2_4_5_4  -1.0
    x_5_2     disj1_5_6_4  -1.0
    x_5_2     disj2_5_6_4  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_3  1.0
    x_5_3     disj2_0_5_3  -1.0
    x_5_3     disj1_1_5_3  1.0
    x_5_3     disj2_1_5_3  -1.0
    x_5_3     disj1_2_5_3  1.0
    x_5_3     disj2_2_5_3  -1.0
    x_5_3     disj1_3_5_3  1.0
    x_5_3     disj2_3_5_3  -1.0
    x_5_3     disj1_4_5_3  1.0
    x_5_3     disj2_4_5_3  -1.0
    x_5_3     disj1_5_6_3  -1.0
    x_5_3     disj2_5_6_3  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_5  1.0
    x_5_4     disj2_0_5_5  -1.0
    x_5_4     disj1_1_5_5  1.0
    x_5_4     disj2_1_5_5  -1.0
    x_5_4     disj1_2_5_5  1.0
    x_5_4     disj2_2_5_5  -1.0
    x_5_4     disj1_3_5_5  1.0
    x_5_4     disj2_3_5_5  -1.0
    x_5_4     disj1_4_5_5  1.0
    x_5_4     disj2_4_5_5  -1.0
    x_5_4     disj1_5_6_5  -1.0
    x_5_4     disj2_5_6_5  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     mksp_5    -1.0
    x_5_5     disj1_0_5_2  1.0
    x_5_5     disj2_0_5_2  -1.0
    x_5_5     disj1_1_5_2  1.0
    x_5_5     disj2_1_5_2  -1.0
    x_5_5     disj1_2_5_2  1.0
    x_5_5     disj2_2_5_2  -1.0
    x_5_5     disj1_3_5_2  1.0
    x_5_5     disj2_3_5_2  -1.0
    x_5_5     disj1_4_5_2  1.0
    x_5_5     disj2_4_5_2  -1.0
    x_5_5     disj1_5_6_2  -1.0
    x_5_5     disj2_5_6_2  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_0  1.0
    x_6_0     disj2_0_6_0  -1.0
    x_6_0     disj1_1_6_0  1.0
    x_6_0     disj2_1_6_0  -1.0
    x_6_0     disj1_2_6_0  1.0
    x_6_0     disj2_2_6_0  -1.0
    x_6_0     disj1_3_6_0  1.0
    x_6_0     disj2_3_6_0  -1.0
    x_6_0     disj1_4_6_0  1.0
    x_6_0     disj2_4_6_0  -1.0
    x_6_0     disj1_5_6_0  1.0
    x_6_0     disj2_5_6_0  -1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_4  1.0
    x_6_1     disj2_0_6_4  -1.0
    x_6_1     disj1_1_6_4  1.0
    x_6_1     disj2_1_6_4  -1.0
    x_6_1     disj1_2_6_4  1.0
    x_6_1     disj2_2_6_4  -1.0
    x_6_1     disj1_3_6_4  1.0
    x_6_1     disj2_3_6_4  -1.0
    x_6_1     disj1_4_6_4  1.0
    x_6_1     disj2_4_6_4  -1.0
    x_6_1     disj1_5_6_4  1.0
    x_6_1     disj2_5_6_4  -1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_3  1.0
    x_6_2     disj2_0_6_3  -1.0
    x_6_2     disj1_1_6_3  1.0
    x_6_2     disj2_1_6_3  -1.0
    x_6_2     disj1_2_6_3  1.0
    x_6_2     disj2_2_6_3  -1.0
    x_6_2     disj1_3_6_3  1.0
    x_6_2     disj2_3_6_3  -1.0
    x_6_2     disj1_4_6_3  1.0
    x_6_2     disj2_4_6_3  -1.0
    x_6_2     disj1_5_6_3  1.0
    x_6_2     disj2_5_6_3  -1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_2  1.0
    x_6_3     disj2_0_6_2  -1.0
    x_6_3     disj1_1_6_2  1.0
    x_6_3     disj2_1_6_2  -1.0
    x_6_3     disj1_2_6_2  1.0
    x_6_3     disj2_2_6_2  -1.0
    x_6_3     disj1_3_6_2  1.0
    x_6_3     disj2_3_6_2  -1.0
    x_6_3     disj1_4_6_2  1.0
    x_6_3     disj2_4_6_2  -1.0
    x_6_3     disj1_5_6_2  1.0
    x_6_3     disj2_5_6_2  -1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_1  1.0
    x_6_4     disj2_0_6_1  -1.0
    x_6_4     disj1_1_6_1  1.0
    x_6_4     disj2_1_6_1  -1.0
    x_6_4     disj1_2_6_1  1.0
    x_6_4     disj2_2_6_1  -1.0
    x_6_4     disj1_3_6_1  1.0
    x_6_4     disj2_3_6_1  -1.0
    x_6_4     disj1_4_6_1  1.0
    x_6_4     disj2_4_6_1  -1.0
    x_6_4     disj1_5_6_1  1.0
    x_6_4     disj2_5_6_1  -1.0
    x_6_5     prec_6_4  1.0
    x_6_5     mksp_6    -1.0
    x_6_5     disj1_0_6_5  1.0
    x_6_5     disj2_0_6_5  -1.0
    x_6_5     disj1_1_6_5  1.0
    x_6_5     disj2_1_6_5  -1.0
    x_6_5     disj1_2_6_5  1.0
    x_6_5     disj2_2_6_5  -1.0
    x_6_5     disj1_3_6_5  1.0
    x_6_5     disj2_3_6_5  -1.0
    x_6_5     disj1_4_6_5  1.0
    x_6_5     disj2_4_6_5  -1.0
    x_6_5     disj1_5_6_5  1.0
    x_6_5     disj2_5_6_5  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  467
    y_0_1_0   disj2_0_1_0  -467
    y_0_1_1   disj1_0_1_1  467
    y_0_1_1   disj2_0_1_1  -467
    y_0_1_2   disj1_0_1_2  467
    y_0_1_2   disj2_0_1_2  -467
    y_0_1_3   disj1_0_1_3  467
    y_0_1_3   disj2_0_1_3  -467
    y_0_1_4   disj1_0_1_4  467
    y_0_1_4   disj2_0_1_4  -467
    y_0_1_5   disj1_0_1_5  467
    y_0_1_5   disj2_0_1_5  -467
    y_0_2_0   disj1_0_2_0  467
    y_0_2_0   disj2_0_2_0  -467
    y_0_2_1   disj1_0_2_1  467
    y_0_2_1   disj2_0_2_1  -467
    y_0_2_2   disj1_0_2_2  467
    y_0_2_2   disj2_0_2_2  -467
    y_0_2_3   disj1_0_2_3  467
    y_0_2_3   disj2_0_2_3  -467
    y_0_2_4   disj1_0_2_4  467
    y_0_2_4   disj2_0_2_4  -467
    y_0_2_5   disj1_0_2_5  467
    y_0_2_5   disj2_0_2_5  -467
    y_0_3_0   disj1_0_3_0  467
    y_0_3_0   disj2_0_3_0  -467
    y_0_3_1   disj1_0_3_1  467
    y_0_3_1   disj2_0_3_1  -467
    y_0_3_2   disj1_0_3_2  467
    y_0_3_2   disj2_0_3_2  -467
    y_0_3_3   disj1_0_3_3  467
    y_0_3_3   disj2_0_3_3  -467
    y_0_3_4   disj1_0_3_4  467
    y_0_3_4   disj2_0_3_4  -467
    y_0_3_5   disj1_0_3_5  467
    y_0_3_5   disj2_0_3_5  -467
    y_0_4_0   disj1_0_4_0  467
    y_0_4_0   disj2_0_4_0  -467
    y_0_4_1   disj1_0_4_1  467
    y_0_4_1   disj2_0_4_1  -467
    y_0_4_2   disj1_0_4_2  467
    y_0_4_2   disj2_0_4_2  -467
    y_0_4_3   disj1_0_4_3  467
    y_0_4_3   disj2_0_4_3  -467
    y_0_4_4   disj1_0_4_4  467
    y_0_4_4   disj2_0_4_4  -467
    y_0_4_5   disj1_0_4_5  467
    y_0_4_5   disj2_0_4_5  -467
    y_0_5_0   disj1_0_5_0  467
    y_0_5_0   disj2_0_5_0  -467
    y_0_5_1   disj1_0_5_1  467
    y_0_5_1   disj2_0_5_1  -467
    y_0_5_2   disj1_0_5_2  467
    y_0_5_2   disj2_0_5_2  -467
    y_0_5_3   disj1_0_5_3  467
    y_0_5_3   disj2_0_5_3  -467
    y_0_5_4   disj1_0_5_4  467
    y_0_5_4   disj2_0_5_4  -467
    y_0_5_5   disj1_0_5_5  467
    y_0_5_5   disj2_0_5_5  -467
    y_0_6_0   disj1_0_6_0  467
    y_0_6_0   disj2_0_6_0  -467
    y_0_6_1   disj1_0_6_1  467
    y_0_6_1   disj2_0_6_1  -467
    y_0_6_2   disj1_0_6_2  467
    y_0_6_2   disj2_0_6_2  -467
    y_0_6_3   disj1_0_6_3  467
    y_0_6_3   disj2_0_6_3  -467
    y_0_6_4   disj1_0_6_4  467
    y_0_6_4   disj2_0_6_4  -467
    y_0_6_5   disj1_0_6_5  467
    y_0_6_5   disj2_0_6_5  -467
    y_1_2_0   disj1_1_2_0  467
    y_1_2_0   disj2_1_2_0  -467
    y_1_2_1   disj1_1_2_1  467
    y_1_2_1   disj2_1_2_1  -467
    y_1_2_2   disj1_1_2_2  467
    y_1_2_2   disj2_1_2_2  -467
    y_1_2_3   disj1_1_2_3  467
    y_1_2_3   disj2_1_2_3  -467
    y_1_2_4   disj1_1_2_4  467
    y_1_2_4   disj2_1_2_4  -467
    y_1_2_5   disj1_1_2_5  467
    y_1_2_5   disj2_1_2_5  -467
    y_1_3_0   disj1_1_3_0  467
    y_1_3_0   disj2_1_3_0  -467
    y_1_3_1   disj1_1_3_1  467
    y_1_3_1   disj2_1_3_1  -467
    y_1_3_2   disj1_1_3_2  467
    y_1_3_2   disj2_1_3_2  -467
    y_1_3_3   disj1_1_3_3  467
    y_1_3_3   disj2_1_3_3  -467
    y_1_3_4   disj1_1_3_4  467
    y_1_3_4   disj2_1_3_4  -467
    y_1_3_5   disj1_1_3_5  467
    y_1_3_5   disj2_1_3_5  -467
    y_1_4_0   disj1_1_4_0  467
    y_1_4_0   disj2_1_4_0  -467
    y_1_4_1   disj1_1_4_1  467
    y_1_4_1   disj2_1_4_1  -467
    y_1_4_2   disj1_1_4_2  467
    y_1_4_2   disj2_1_4_2  -467
    y_1_4_3   disj1_1_4_3  467
    y_1_4_3   disj2_1_4_3  -467
    y_1_4_4   disj1_1_4_4  467
    y_1_4_4   disj2_1_4_4  -467
    y_1_4_5   disj1_1_4_5  467
    y_1_4_5   disj2_1_4_5  -467
    y_1_5_0   disj1_1_5_0  467
    y_1_5_0   disj2_1_5_0  -467
    y_1_5_1   disj1_1_5_1  467
    y_1_5_1   disj2_1_5_1  -467
    y_1_5_2   disj1_1_5_2  467
    y_1_5_2   disj2_1_5_2  -467
    y_1_5_3   disj1_1_5_3  467
    y_1_5_3   disj2_1_5_3  -467
    y_1_5_4   disj1_1_5_4  467
    y_1_5_4   disj2_1_5_4  -467
    y_1_5_5   disj1_1_5_5  467
    y_1_5_5   disj2_1_5_5  -467
    y_1_6_0   disj1_1_6_0  467
    y_1_6_0   disj2_1_6_0  -467
    y_1_6_1   disj1_1_6_1  467
    y_1_6_1   disj2_1_6_1  -467
    y_1_6_2   disj1_1_6_2  467
    y_1_6_2   disj2_1_6_2  -467
    y_1_6_3   disj1_1_6_3  467
    y_1_6_3   disj2_1_6_3  -467
    y_1_6_4   disj1_1_6_4  467
    y_1_6_4   disj2_1_6_4  -467
    y_1_6_5   disj1_1_6_5  467
    y_1_6_5   disj2_1_6_5  -467
    y_2_3_0   disj1_2_3_0  467
    y_2_3_0   disj2_2_3_0  -467
    y_2_3_1   disj1_2_3_1  467
    y_2_3_1   disj2_2_3_1  -467
    y_2_3_2   disj1_2_3_2  467
    y_2_3_2   disj2_2_3_2  -467
    y_2_3_3   disj1_2_3_3  467
    y_2_3_3   disj2_2_3_3  -467
    y_2_3_4   disj1_2_3_4  467
    y_2_3_4   disj2_2_3_4  -467
    y_2_3_5   disj1_2_3_5  467
    y_2_3_5   disj2_2_3_5  -467
    y_2_4_0   disj1_2_4_0  467
    y_2_4_0   disj2_2_4_0  -467
    y_2_4_1   disj1_2_4_1  467
    y_2_4_1   disj2_2_4_1  -467
    y_2_4_2   disj1_2_4_2  467
    y_2_4_2   disj2_2_4_2  -467
    y_2_4_3   disj1_2_4_3  467
    y_2_4_3   disj2_2_4_3  -467
    y_2_4_4   disj1_2_4_4  467
    y_2_4_4   disj2_2_4_4  -467
    y_2_4_5   disj1_2_4_5  467
    y_2_4_5   disj2_2_4_5  -467
    y_2_5_0   disj1_2_5_0  467
    y_2_5_0   disj2_2_5_0  -467
    y_2_5_1   disj1_2_5_1  467
    y_2_5_1   disj2_2_5_1  -467
    y_2_5_2   disj1_2_5_2  467
    y_2_5_2   disj2_2_5_2  -467
    y_2_5_3   disj1_2_5_3  467
    y_2_5_3   disj2_2_5_3  -467
    y_2_5_4   disj1_2_5_4  467
    y_2_5_4   disj2_2_5_4  -467
    y_2_5_5   disj1_2_5_5  467
    y_2_5_5   disj2_2_5_5  -467
    y_2_6_0   disj1_2_6_0  467
    y_2_6_0   disj2_2_6_0  -467
    y_2_6_1   disj1_2_6_1  467
    y_2_6_1   disj2_2_6_1  -467
    y_2_6_2   disj1_2_6_2  467
    y_2_6_2   disj2_2_6_2  -467
    y_2_6_3   disj1_2_6_3  467
    y_2_6_3   disj2_2_6_3  -467
    y_2_6_4   disj1_2_6_4  467
    y_2_6_4   disj2_2_6_4  -467
    y_2_6_5   disj1_2_6_5  467
    y_2_6_5   disj2_2_6_5  -467
    y_3_4_0   disj1_3_4_0  467
    y_3_4_0   disj2_3_4_0  -467
    y_3_4_1   disj1_3_4_1  467
    y_3_4_1   disj2_3_4_1  -467
    y_3_4_2   disj1_3_4_2  467
    y_3_4_2   disj2_3_4_2  -467
    y_3_4_3   disj1_3_4_3  467
    y_3_4_3   disj2_3_4_3  -467
    y_3_4_4   disj1_3_4_4  467
    y_3_4_4   disj2_3_4_4  -467
    y_3_4_5   disj1_3_4_5  467
    y_3_4_5   disj2_3_4_5  -467
    y_3_5_0   disj1_3_5_0  467
    y_3_5_0   disj2_3_5_0  -467
    y_3_5_1   disj1_3_5_1  467
    y_3_5_1   disj2_3_5_1  -467
    y_3_5_2   disj1_3_5_2  467
    y_3_5_2   disj2_3_5_2  -467
    y_3_5_3   disj1_3_5_3  467
    y_3_5_3   disj2_3_5_3  -467
    y_3_5_4   disj1_3_5_4  467
    y_3_5_4   disj2_3_5_4  -467
    y_3_5_5   disj1_3_5_5  467
    y_3_5_5   disj2_3_5_5  -467
    y_3_6_0   disj1_3_6_0  467
    y_3_6_0   disj2_3_6_0  -467
    y_3_6_1   disj1_3_6_1  467
    y_3_6_1   disj2_3_6_1  -467
    y_3_6_2   disj1_3_6_2  467
    y_3_6_2   disj2_3_6_2  -467
    y_3_6_3   disj1_3_6_3  467
    y_3_6_3   disj2_3_6_3  -467
    y_3_6_4   disj1_3_6_4  467
    y_3_6_4   disj2_3_6_4  -467
    y_3_6_5   disj1_3_6_5  467
    y_3_6_5   disj2_3_6_5  -467
    y_4_5_0   disj1_4_5_0  467
    y_4_5_0   disj2_4_5_0  -467
    y_4_5_1   disj1_4_5_1  467
    y_4_5_1   disj2_4_5_1  -467
    y_4_5_2   disj1_4_5_2  467
    y_4_5_2   disj2_4_5_2  -467
    y_4_5_3   disj1_4_5_3  467
    y_4_5_3   disj2_4_5_3  -467
    y_4_5_4   disj1_4_5_4  467
    y_4_5_4   disj2_4_5_4  -467
    y_4_5_5   disj1_4_5_5  467
    y_4_5_5   disj2_4_5_5  -467
    y_4_6_0   disj1_4_6_0  467
    y_4_6_0   disj2_4_6_0  -467
    y_4_6_1   disj1_4_6_1  467
    y_4_6_1   disj2_4_6_1  -467
    y_4_6_2   disj1_4_6_2  467
    y_4_6_2   disj2_4_6_2  -467
    y_4_6_3   disj1_4_6_3  467
    y_4_6_3   disj2_4_6_3  -467
    y_4_6_4   disj1_4_6_4  467
    y_4_6_4   disj2_4_6_4  -467
    y_4_6_5   disj1_4_6_5  467
    y_4_6_5   disj2_4_6_5  -467
    y_5_6_0   disj1_5_6_0  467
    y_5_6_0   disj2_5_6_0  -467
    y_5_6_1   disj1_5_6_1  467
    y_5_6_1   disj2_5_6_1  -467
    y_5_6_2   disj1_5_6_2  467
    y_5_6_2   disj2_5_6_2  -467
    y_5_6_3   disj1_5_6_3  467
    y_5_6_3   disj2_5_6_3  -467
    y_5_6_4   disj1_5_6_4  467
    y_5_6_4   disj2_5_6_4  -467
    y_5_6_5   disj1_5_6_5  467
    y_5_6_5   disj2_5_6_5  -467
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  16
    RHS       prec_0_1  15
    RHS       prec_0_2  16
    RHS       prec_0_3  13
    RHS       prec_0_4  7
    RHS       prec_1_0  15
    RHS       prec_1_1  9
    RHS       prec_1_2  8
    RHS       prec_1_3  19
    RHS       prec_1_4  4
    RHS       prec_2_0  13
    RHS       prec_2_1  7
    RHS       prec_2_2  14
    RHS       prec_2_3  1
    RHS       prec_2_4  17
    RHS       prec_3_0  8
    RHS       prec_3_1  15
    RHS       prec_3_2  10
    RHS       prec_3_3  1
    RHS       prec_3_4  14
    RHS       prec_4_0  4
    RHS       prec_4_1  11
    RHS       prec_4_2  17
    RHS       prec_4_3  14
    RHS       prec_4_4  17
    RHS       prec_5_0  19
    RHS       prec_5_1  2
    RHS       prec_5_2  16
    RHS       prec_5_3  8
    RHS       prec_5_4  13
    RHS       prec_6_0  3
    RHS       prec_6_1  15
    RHS       prec_6_2  17
    RHS       prec_6_3  4
    RHS       prec_6_4  6
    RHS       mksp_0    4
    RHS       mksp_1    11
    RHS       mksp_2    8
    RHS       mksp_3    18
    RHS       mksp_4    7
    RHS       mksp_5    14
    RHS       mksp_6    17
    RHS       disj1_0_1_0  13
    RHS       disj2_0_1_0  -463
    RHS       disj1_0_2_0  13
    RHS       disj2_0_2_0  -459
    RHS       disj1_0_3_0  13
    RHS       disj2_0_3_0  -452
    RHS       disj1_0_4_0  13
    RHS       disj2_0_4_0  -450
    RHS       disj1_0_5_0  13
    RHS       disj2_0_5_0  -448
    RHS       disj1_0_6_0  13
    RHS       disj2_0_6_0  -464
    RHS       disj1_1_2_0  4
    RHS       disj2_1_2_0  -459
    RHS       disj1_1_3_0  4
    RHS       disj2_1_3_0  -452
    RHS       disj1_1_4_0  4
    RHS       disj2_1_4_0  -450
    RHS       disj1_1_5_0  4
    RHS       disj2_1_5_0  -448
    RHS       disj1_1_6_0  4
    RHS       disj2_1_6_0  -464
    RHS       disj1_2_3_0  8
    RHS       disj2_2_3_0  -452
    RHS       disj1_2_4_0  8
    RHS       disj2_2_4_0  -450
    RHS       disj1_2_5_0  8
    RHS       disj2_2_5_0  -448
    RHS       disj1_2_6_0  8
    RHS       disj2_2_6_0  -464
    RHS       disj1_3_4_0  15
    RHS       disj2_3_4_0  -450
    RHS       disj1_3_5_0  15
    RHS       disj2_3_5_0  -448
    RHS       disj1_3_6_0  15
    RHS       disj2_3_6_0  -464
    RHS       disj1_4_5_0  17
    RHS       disj2_4_5_0  -448
    RHS       disj1_4_6_0  17
    RHS       disj2_4_6_0  -464
    RHS       disj1_5_6_0  19
    RHS       disj2_5_6_0  -464
    RHS       disj1_0_1_1  4
    RHS       disj2_0_1_1  -459
    RHS       disj1_0_2_1  4
    RHS       disj2_0_2_1  -454
    RHS       disj1_0_3_1  4
    RHS       disj2_0_3_1  -466
    RHS       disj1_0_4_1  4
    RHS       disj2_0_4_1  -453
    RHS       disj1_0_5_1  4
    RHS       disj2_0_5_1  -465
    RHS       disj1_0_6_1  4
    RHS       disj2_0_6_1  -461
    RHS       disj1_1_2_1  8
    RHS       disj2_1_2_1  -454
    RHS       disj1_1_3_1  8
    RHS       disj2_1_3_1  -466
    RHS       disj1_1_4_1  8
    RHS       disj2_1_4_1  -453
    RHS       disj1_1_5_1  8
    RHS       disj2_1_5_1  -465
    RHS       disj1_1_6_1  8
    RHS       disj2_1_6_1  -461
    RHS       disj1_2_3_1  13
    RHS       disj2_2_3_1  -466
    RHS       disj1_2_4_1  13
    RHS       disj2_2_4_1  -453
    RHS       disj1_2_5_1  13
    RHS       disj2_2_5_1  -465
    RHS       disj1_2_6_1  13
    RHS       disj2_2_6_1  -461
    RHS       disj1_3_4_1  1
    RHS       disj2_3_4_1  -453
    RHS       disj1_3_5_1  1
    RHS       disj2_3_5_1  -465
    RHS       disj1_3_6_1  1
    RHS       disj2_3_6_1  -461
    RHS       disj1_4_5_1  14
    RHS       disj2_4_5_1  -465
    RHS       disj1_4_6_1  14
    RHS       disj2_4_6_1  -461
    RHS       disj1_5_6_1  2
    RHS       disj2_5_6_1  -461
    RHS       disj1_0_1_2  16
    RHS       disj2_0_1_2  -452
    RHS       disj1_0_2_2  16
    RHS       disj2_0_2_2  -453
    RHS       disj1_0_3_2  16
    RHS       disj2_0_3_2  -459
    RHS       disj1_0_4_2  16
    RHS       disj2_0_4_2  -450
    RHS       disj1_0_5_2  16
    RHS       disj2_0_5_2  -453
    RHS       disj1_0_6_2  16
    RHS       disj2_0_6_2  -463
    RHS       disj1_1_2_2  15
    RHS       disj2_1_2_2  -453
    RHS       disj1_1_3_2  15
    RHS       disj2_1_3_2  -459
    RHS       disj1_1_4_2  15
    RHS       disj2_1_4_2  -450
    RHS       disj1_1_5_2  15
    RHS       disj2_1_5_2  -453
    RHS       disj1_1_6_2  15
    RHS       disj2_1_6_2  -463
    RHS       disj1_2_3_2  14
    RHS       disj2_2_3_2  -459
    RHS       disj1_2_4_2  14
    RHS       disj2_2_4_2  -450
    RHS       disj1_2_5_2  14
    RHS       disj2_2_5_2  -453
    RHS       disj1_2_6_2  14
    RHS       disj2_2_6_2  -463
    RHS       disj1_3_4_2  8
    RHS       disj2_3_4_2  -450
    RHS       disj1_3_5_2  8
    RHS       disj2_3_5_2  -453
    RHS       disj1_3_6_2  8
    RHS       disj2_3_6_2  -463
    RHS       disj1_4_5_2  17
    RHS       disj2_4_5_2  -453
    RHS       disj1_4_6_2  17
    RHS       disj2_4_6_2  -463
    RHS       disj1_5_6_2  14
    RHS       disj2_5_6_2  -463
    RHS       disj1_0_1_3  15
    RHS       disj2_0_1_3  -456
    RHS       disj1_0_2_3  15
    RHS       disj2_0_2_3  -460
    RHS       disj1_0_3_3  15
    RHS       disj2_0_3_3  -449
    RHS       disj1_0_4_3  15
    RHS       disj2_0_4_3  -456
    RHS       disj1_0_5_3  15
    RHS       disj2_0_5_3  -459
    RHS       disj1_0_6_3  15
    RHS       disj2_0_6_3  -450
    RHS       disj1_1_2_3  11
    RHS       disj2_1_2_3  -460
    RHS       disj1_1_3_3  11
    RHS       disj2_1_3_3  -449
    RHS       disj1_1_4_3  11
    RHS       disj2_1_4_3  -456
    RHS       disj1_1_5_3  11
    RHS       disj2_1_5_3  -459
    RHS       disj1_1_6_3  11
    RHS       disj2_1_6_3  -450
    RHS       disj1_2_3_3  7
    RHS       disj2_2_3_3  -449
    RHS       disj1_2_4_3  7
    RHS       disj2_2_4_3  -456
    RHS       disj1_2_5_3  7
    RHS       disj2_2_5_3  -459
    RHS       disj1_2_6_3  7
    RHS       disj2_2_6_3  -450
    RHS       disj1_3_4_3  18
    RHS       disj2_3_4_3  -456
    RHS       disj1_3_5_3  18
    RHS       disj2_3_5_3  -459
    RHS       disj1_3_6_3  18
    RHS       disj2_3_6_3  -450
    RHS       disj1_4_5_3  11
    RHS       disj2_4_5_3  -459
    RHS       disj1_4_6_3  11
    RHS       disj2_4_6_3  -450
    RHS       disj1_5_6_3  8
    RHS       disj2_5_6_3  -450
    RHS       disj1_0_1_4  7
    RHS       disj2_0_1_4  -458
    RHS       disj1_0_2_4  7
    RHS       disj2_0_2_4  -466
    RHS       disj1_0_3_4  7
    RHS       disj2_0_3_4  -457
    RHS       disj1_0_4_4  7
    RHS       disj2_0_4_4  -463
    RHS       disj1_0_5_4  7
    RHS       disj2_0_5_4  -451
    RHS       disj1_0_6_4  7
    RHS       disj2_0_6_4  -452
    RHS       disj1_1_2_4  9
    RHS       disj2_1_2_4  -466
    RHS       disj1_1_3_4  9
    RHS       disj2_1_3_4  -457
    RHS       disj1_1_4_4  9
    RHS       disj2_1_4_4  -463
    RHS       disj1_1_5_4  9
    RHS       disj2_1_5_4  -451
    RHS       disj1_1_6_4  9
    RHS       disj2_1_6_4  -452
    RHS       disj1_2_3_4  1
    RHS       disj2_2_3_4  -457
    RHS       disj1_2_4_4  1
    RHS       disj2_2_4_4  -463
    RHS       disj1_2_5_4  1
    RHS       disj2_2_5_4  -451
    RHS       disj1_2_6_4  1
    RHS       disj2_2_6_4  -452
    RHS       disj1_3_4_4  10
    RHS       disj2_3_4_4  -463
    RHS       disj1_3_5_4  10
    RHS       disj2_3_5_4  -451
    RHS       disj1_3_6_4  10
    RHS       disj2_3_6_4  -452
    RHS       disj1_4_5_4  4
    RHS       disj2_4_5_4  -451
    RHS       disj1_4_6_4  4
    RHS       disj2_4_6_4  -452
    RHS       disj1_5_6_4  16
    RHS       disj2_5_6_4  -452
    RHS       disj1_0_1_5  16
    RHS       disj2_0_1_5  -448
    RHS       disj1_0_2_5  16
    RHS       disj2_0_2_5  -450
    RHS       disj1_0_3_5  16
    RHS       disj2_0_3_5  -453
    RHS       disj1_0_4_5  16
    RHS       disj2_0_4_5  -460
    RHS       disj1_0_5_5  16
    RHS       disj2_0_5_5  -454
    RHS       disj1_0_6_5  16
    RHS       disj2_0_6_5  -450
    RHS       disj1_1_2_5  19
    RHS       disj2_1_2_5  -450
    RHS       disj1_1_3_5  19
    RHS       disj2_1_3_5  -453
    RHS       disj1_1_4_5  19
    RHS       disj2_1_4_5  -460
    RHS       disj1_1_5_5  19
    RHS       disj2_1_5_5  -454
    RHS       disj1_1_6_5  19
    RHS       disj2_1_6_5  -450
    RHS       disj1_2_3_5  17
    RHS       disj2_2_3_5  -453
    RHS       disj1_2_4_5  17
    RHS       disj2_2_4_5  -460
    RHS       disj1_2_5_5  17
    RHS       disj2_2_5_5  -454
    RHS       disj1_2_6_5  17
    RHS       disj2_2_6_5  -450
    RHS       disj1_3_4_5  14
    RHS       disj2_3_4_5  -460
    RHS       disj1_3_5_5  14
    RHS       disj2_3_5_5  -454
    RHS       disj1_3_6_5  14
    RHS       disj2_3_6_5  -450
    RHS       disj1_4_5_5  7
    RHS       disj2_4_5_5  -454
    RHS       disj1_4_6_5  7
    RHS       disj2_4_6_5  -450
    RHS       disj1_5_6_5  13
    RHS       disj2_5_6_5  -450
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
ENDATA
