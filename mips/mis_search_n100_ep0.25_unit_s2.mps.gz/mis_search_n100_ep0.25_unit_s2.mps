NAME          MIS
ROWS
 N  OBJ
 L  EDGE_55_57
 L  EDGE_15_30
 L  EDGE_16_84
 L  EDGE_24_97
 L  EDGE_7_26
 L  EDGE_26_30
 L  EDGE_36_62
 L  EDGE_28_58
 L  EDGE_59_73
 L  EDGE_55_84
 L  EDGE_70_82
 L  EDGE_55_93
 L  EDGE_5_74
 L  EDGE_5_83
 L  EDGE_40_50
 L  EDGE_77_99
 L  EDGE_21_46
 L  EDGE_6_57
 L  EDGE_80_95
 L  EDGE_21_55
 L  EDGE_61_91
 L  EDGE_6_66
 L  EDGE_9_99
 L  EDGE_10_27
 L  EDGE_6_75
 L  EDGE_6_84
 L  EDGE_41_51
 L  EDGE_81_87
 L  EDGE_33_47
 L  EDGE_2_41
 L  EDGE_3_6
 L  EDGE_25_43
 L  EDGE_54_79
 L  EDGE_73_92
 L  EDGE_25_52
 L  EDGE_14_15
 L  EDGE_31_95
 L  EDGE_14_24
 L  EDGE_43_60
 L  EDGE_51_73
 L  EDGE_74_75
 L  EDGE_2_68
 L  EDGE_14_33
 L  EDGE_32_69
 L  EDGE_4_96
 L  EDGE_66_80
 L  EDGE_13_74
 L  EDGE_32_87
 L  EDGE_1_81
 L  EDGE_17_53
 L  EDGE_7_30
 L  EDGE_47_66
 L  EDGE_55_79
 L  EDGE_5_60
 L  EDGE_46_98
 L  EDGE_47_75
 L  EDGE_57_98
 L  EDGE_59_68
 L  EDGE_5_69
 L  EDGE_28_80
 L  EDGE_77_94
 L  EDGE_29_54
 L  EDGE_69_90
 L  EDGE_50_86
 L  EDGE_40_63
 L  EDGE_42_82
 L  EDGE_30_98
 L  EDGE_81_82
 L  EDGE_10_40
 L  EDGE_73_78
 L  EDGE_81_91
 L  EDGE_2_36
 L  EDGE_31_72
 L  EDGE_25_47
 L  EDGE_10_58
 L  EDGE_12_77
 L  EDGE_23_77
 L  EDGE_73_96
 L  EDGE_23_86
 L  EDGE_20_99
 L  EDGE_23_95
 L  EDGE_13_60
 L  EDGE_24_60
 L  EDGE_35_60
 L  EDGE_16_56
 L  EDGE_51_86
 L  EDGE_43_82
 L  EDGE_1_76
 L  EDGE_35_78
 L  EDGE_36_43
 L  EDGE_43_91
 L  EDGE_7_16
 L  EDGE_47_52
 L  EDGE_1_94
 L  EDGE_5_55
 L  EDGE_9_53
 L  EDGE_38_89
 L  EDGE_28_66
 L  EDGE_49_98
 L  EDGE_5_73
 L  EDGE_29_40
 L  EDGE_50_72
 L  EDGE_5_82
 L  EDGE_6_47
 L  EDGE_61_81
 L  EDGE_58_94
 L  EDGE_72_97
 L  EDGE_92_96
 L  EDGE_27_88
 L  EDGE_10_17
 L  EDGE_19_84
 L  EDGE_42_86
 L  EDGE_19_93
 L  EDGE_2_22
 L  EDGE_42_95
 L  EDGE_10_35
 L  EDGE_54_60
 L  EDGE_20_67
 L  EDGE_25_33
 L  EDGE_10_44
 L  EDGE_20_76
 L  EDGE_31_76
 L  EDGE_32_41
 L  EDGE_20_85
 L  EDGE_31_94
 L  EDGE_84_97
 L  EDGE_95_97
 L  EDGE_51_72
 L  EDGE_1_53
 L  EDGE_14_32
 L  EDGE_16_51
 L  EDGE_32_68
 L  EDGE_13_64
 L  EDGE_4_95
 L  EDGE_17_25
 L  EDGE_36_38
 L  EDGE_17_34
 L  EDGE_1_80
 L  EDGE_24_82
 L  EDGE_36_47
 L  EDGE_65_83
 L  EDGE_5_41
 L  EDGE_17_43
 L  EDGE_5_50
 L  EDGE_38_93
 L  EDGE_49_93
 L  EDGE_29_35
 L  EDGE_69_71
 L  EDGE_9_66
 L  EDGE_29_44
 L  EDGE_77_93
 L  EDGE_50_76
 L  EDGE_61_76
 L  EDGE_6_51
 L  EDGE_42_72
 L  EDGE_58_89
 L  EDGE_8_79
 L  EDGE_19_79
 L  EDGE_27_92
 L  EDGE_61_94
 L  EDGE_91_95
 L  EDGE_19_88
 L  EDGE_30_88
 L  EDGE_11_84
 L  EDGE_39_66
 L  EDGE_2_26
 L  EDGE_25_28
 L  EDGE_0_93
 L  EDGE_11_93
 L  EDGE_12_58
 L  EDGE_2_35
 L  EDGE_39_75
 L  EDGE_54_64
 L  EDGE_73_77
 L  EDGE_32_45
 L  EDGE_13_41
 L  EDGE_4_72
 L  EDGE_14_18
 L  EDGE_13_50
 L  EDGE_35_50
 L  EDGE_32_63
 L  EDGE_43_63
 L  EDGE_1_57
 L  EDGE_35_59
 L  EDGE_4_90
 L  EDGE_64_95
 L  EDGE_87_97
 L  EDGE_65_69
 L  EDGE_28_29
 L  EDGE_35_77
 L  EDGE_65_87
 L  EDGE_5_45
 L  EDGE_6_10
 L  EDGE_46_83
 L  EDGE_9_43
 L  EDGE_38_79
 L  EDGE_57_83
 L  EDGE_9_52
 L  EDGE_26_95
 L  EDGE_21_26
 L  EDGE_61_62
 L  EDGE_58_75
 L  EDGE_69_75
 L  EDGE_77_79
 L  EDGE_30_65
 L  EDGE_42_67
 L  EDGE_61_80
 L  EDGE_19_74
 L  EDGE_20_39
 L  EDGE_30_74
 L  EDGE_10_16
 L  EDGE_42_85
 L  EDGE_2_12
 L  EDGE_20_48
 L  EDGE_10_25
 L  EDGE_39_61
 L  EDGE_19_92
 L  EDGE_30_92
 L  EDGE_62_63
 L  EDGE_0_88
 L  EDGE_75_91
 L  EDGE_83_95
 L  EDGE_0_97
 L  EDGE_12_62
 L  EDGE_13_27
 L  EDGE_20_75
 L  EDGE_39_79
 L  EDGE_41_98
 L  EDGE_12_71
 L  EDGE_13_36
 L  EDGE_23_71
 L  EDGE_72_76
 L  EDGE_72_85
 L  EDGE_12_80
 L  EDGE_13_45
 L  EDGE_53_81
 L  EDGE_32_58
 L  EDGE_72_94
 L  EDGE_4_85
 L  EDGE_13_63
 L  EDGE_24_63
 L  EDGE_53_99
 L  EDGE_65_73
 L  EDGE_17_33
 L  EDGE_28_33
 L  EDGE_76_82
 L  EDGE_17_42
 L  EDGE_28_42
 L  EDGE_9_38
 L  EDGE_38_74
 L  EDGE_49_74
 L  EDGE_57_87
 L  EDGE_68_87
 L  EDGE_38_83
 L  EDGE_49_83
 L  EDGE_5_58
 L  EDGE_57_96
 L  EDGE_58_61
 L  EDGE_38_92
 L  EDGE_50_57
 L  EDGE_58_70
 L  EDGE_69_70
 L  EDGE_58_79
 L  EDGE_30_60
 L  EDGE_50_75
 L  EDGE_20_34
 L  EDGE_61_84
 L  EDGE_10_11
 L  EDGE_42_80
 L  EDGE_20_43
 L  EDGE_31_43
 L  EDGE_19_87
 L  EDGE_2_16
 L  EDGE_39_65
 L  EDGE_20_61
 L  EDGE_54_63
 L  EDGE_83_99
 L  EDGE_41_93
 L  EDGE_52_93
 L  EDGE_13_31
 L  EDGE_24_31
 L  EDGE_43_44
 L  EDGE_53_67
 L  EDGE_64_76
 L  EDGE_4_71
 L  EDGE_45_72
 L  EDGE_72_89
 L  EDGE_24_49
 L  EDGE_53_85
 L  EDGE_4_80
 L  EDGE_34_81
 L  EDGE_5_8
 L  EDGE_1_56
 L  EDGE_64_85
 L  EDGE_72_98
 L  EDGE_16_54
 L  EDGE_17_19
 L  EDGE_34_90
 L  EDGE_65_68
 L  EDGE_49_51
 L  EDGE_3_93
 L  EDGE_37_95
 L  EDGE_38_60
 L  EDGE_5_35
 L  EDGE_49_60
 L  EDGE_65_86
 L  EDGE_38_69
 L  EDGE_68_73
 L  EDGE_5_44
 L  EDGE_49_78
 L  EDGE_18_81
 L  EDGE_30_46
 L  EDGE_15_94
 L  EDGE_84_99
 L  EDGE_90_97
 L  EDGE_18_90
 L  EDGE_8_55
 L  EDGE_42_57
 L  EDGE_50_70
 L  EDGE_42_66
 L  EDGE_23_25
 L  EDGE_19_73
 L  EDGE_42_75
 L  EDGE_12_34
 L  EDGE_19_82
 L  EDGE_74_86
 L  EDGE_0_78
 L  EDGE_41_79
 L  EDGE_31_56
 L  EDGE_1_15
 L  EDGE_13_17
 L  EDGE_53_62
 L  EDGE_32_39
 L  EDGE_34_58
 L  EDGE_44_93
 L  EDGE_34_67
 L  EDGE_1_42
 L  EDGE_13_44
 L  EDGE_72_93
 L  EDGE_1_51
 L  EDGE_64_89
 L  EDGE_5_12
 L  EDGE_57_59
 L  EDGE_37_90
 L  EDGE_9_19
 L  EDGE_49_55
 L  EDGE_15_62
 L  EDGE_57_77
 L  EDGE_27_36
 L  EDGE_6_13
 L  EDGE_85_89
 L  EDGE_15_80
 L  EDGE_27_45
 L  EDGE_8_41
 L  EDGE_19_41
 L  EDGE_27_54
 L  EDGE_42_43
 L  EDGE_30_50
 L  EDGE_71_88
 L  EDGE_27_63
 L  EDGE_0_46
 L  EDGE_18_94
 L  EDGE_63_93
 L  EDGE_6_98
 L  EDGE_39_46
 L  EDGE_21_96
 L  EDGE_60_78
 L  EDGE_23_38
 L  EDGE_83_89
 L  EDGE_41_83
 L  EDGE_60_96
 L  EDGE_44_79
 L  EDGE_41_92
 L  EDGE_10_86
 L  EDGE_16_17
 L  EDGE_72_79
 L  EDGE_22_60
 L  EDGE_64_75
 L  EDGE_37_58
 L  EDGE_34_71
 L  EDGE_1_46
 L  EDGE_3_65
 L  EDGE_56_80
 L  EDGE_5_7
 L  EDGE_14_74
 L  EDGE_45_89
 L  EDGE_86_90
 L  EDGE_65_67
 L  EDGE_15_48
 L  EDGE_15_57
 L  EDGE_68_72
 L  EDGE_7_71
 L  EDGE_8_36
 L  EDGE_18_71
 L  EDGE_50_51
 L  EDGE_0_32
 L  EDGE_7_80
 L  EDGE_19_45
 L  EDGE_79_87
 L  EDGE_82_83
 L  EDGE_90_96
 L  EDGE_18_89
 L  EDGE_48_90
 L  EDGE_30_63
 L  EDGE_29_95
 L  EDGE_12_24
 L  EDGE_52_60
 L  EDGE_21_91
 L  EDGE_11_68
 L  EDGE_12_33
 L  EDGE_23_33
 L  EDGE_60_82
 L  EDGE_12_42
 L  EDGE_1_5
 L  EDGE_75_80
 L  EDGE_10_72
 L  EDGE_33_74
 L  EDGE_75_89
 L  EDGE_1_14
 L  EDGE_45_48
 L  EDGE_52_96
 L  EDGE_2_77
 L  EDGE_24_25
 L  EDGE_25_79
 L  EDGE_2_86
 L  EDGE_53_70
 L  EDGE_10_99
 L  EDGE_56_66
 L  EDGE_64_70
 L  EDGE_25_97
 L  EDGE_66_98
 L  EDGE_14_69
 L  EDGE_56_84
 L  EDGE_37_80
 L  EDGE_15_43
 L  EDGE_22_91
 L  EDGE_57_58
 L  EDGE_7_39
 L  EDGE_49_54
 L  EDGE_55_88
 L  EDGE_67_90
 L  EDGE_18_48
 L  EDGE_8_13
 L  EDGE_49_63
 L  EDGE_70_86
 L  EDGE_7_57
 L  EDGE_18_57
 L  EDGE_47_93
 L  EDGE_27_35
 L  EDGE_11_18
 L  EDGE_7_66
 L  EDGE_8_31
 L  EDGE_19_31
 L  EDGE_30_31
 L  EDGE_11_27
 L  EDGE_79_82
 L  EDGE_19_40
 L  EDGE_0_36
 L  EDGE_63_74
 L  EDGE_48_85
 L  EDGE_71_87
 L  EDGE_63_83
 L  EDGE_48_94
 L  EDGE_4_6
 L  EDGE_52_55
 L  EDGE_20_32
 L  EDGE_6_97
 L  EDGE_29_99
 L  EDGE_21_95
 L  EDGE_4_24
 L  EDGE_60_86
 L  EDGE_44_69
 L  EDGE_41_82
 L  EDGE_1_9
 L  EDGE_1_18
 L  EDGE_25_74
 L  EDGE_33_87
 L  EDGE_34_52
 L  EDGE_53_56
 L  EDGE_64_65
 L  EDGE_3_46
 L  EDGE_10_94
 L  EDGE_45_61
 L  EDGE_51_95
 L  EDGE_25_92
 L  EDGE_3_55
 L  EDGE_14_55
 L  EDGE_37_57
 L  EDGE_56_70
 L  EDGE_2_99
 L  EDGE_22_77
 L  EDGE_13_96
 L  EDGE_47_79
 L  EDGE_59_81
 L  EDGE_67_94
 L  EDGE_0_4
 L  EDGE_70_90
 L  EDGE_17_84
 L  EDGE_28_84
 L  EDGE_36_97
 L  EDGE_8_26
 L  EDGE_19_26
 L  EDGE_47_97
 L  EDGE_0_22
 L  EDGE_29_76
 L  EDGE_40_76
 L  EDGE_63_78
 L  EDGE_21_72
 L  EDGE_11_49
 L  EDGE_12_14
 L  EDGE_63_87
 L  EDGE_29_94
 L  EDGE_12_23
 L  EDGE_40_94
 L  EDGE_41_59
 L  EDGE_4_19
 L  EDGE_44_55
 L  EDGE_41_68
 L  EDGE_81_95
 L  EDGE_10_62
 L  EDGE_25_60
 L  EDGE_33_73
 L  EDGE_3_32
 L  EDGE_10_80
 L  EDGE_44_82
 L  EDGE_3_41
 L  EDGE_10_89
 L  EDGE_14_41
 L  EDGE_51_90
 L  EDGE_43_86
 L  EDGE_14_59
 L  EDGE_66_97
 L  EDGE_13_91
 L  EDGE_7_20
 L  EDGE_3_68
 L  EDGE_18_20
 L  EDGE_26_33
 L  EDGE_1_98
 L  EDGE_15_42
 L  EDGE_16_96
 L  EDGE_26_42
 L  EDGE_7_38
 L  EDGE_67_80
 L  EDGE_15_51
 L  EDGE_36_83
 L  EDGE_8_12
 L  EDGE_89_98
 L  EDGE_17_79
 L  EDGE_28_79
 L  EDGE_7_56
 L  EDGE_8_21
 L  EDGE_9_75
 L  EDGE_5_86
 L  EDGE_11_17
 L  EDGE_18_56
 L  EDGE_8_30
 L  EDGE_9_84
 L  EDGE_47_92
 L  EDGE_9_93
 L  EDGE_11_35
 L  EDGE_29_71
 L  EDGE_40_71
 L  EDGE_41_54
 L  EDGE_4_14
 L  EDGE_10_48
 L  EDGE_81_99
 L  EDGE_52_72
 L  EDGE_25_55
 L  EDGE_54_91
 L  EDGE_33_68
 L  EDGE_25_64
 L  EDGE_10_75
 L  EDGE_34_42
 L  EDGE_51_76
 L  EDGE_2_71
 L  EDGE_25_73
 L  EDGE_37_38
 L  EDGE_22_49
 L  EDGE_14_45
 L  EDGE_3_54
 L  EDGE_43_90
 L  EDGE_66_92
 L  EDGE_13_86
 L  EDGE_13_95
 L  EDGE_16_91
 L  EDGE_18_33
 L  EDGE_47_69
 L  EDGE_26_46
 L  EDGE_7_42
 L  EDGE_55_91
 L  EDGE_5_72
 L  EDGE_0_3
 L  EDGE_17_74
 L  EDGE_28_74
 L  EDGE_29_39
 L  EDGE_17_83
 L  EDGE_0_12
 L  EDGE_48_52
 L  EDGE_9_79
 L  EDGE_70_89
 L  EDGE_17_92
 L  EDGE_0_21
 L  EDGE_28_92
 L  EDGE_9_88
 L  EDGE_69_93
 L  EDGE_5_99
 L  EDGE_11_30
 L  EDGE_63_68
 L  EDGE_40_75
 L  EDGE_21_71
 L  EDGE_81_85
 L  EDGE_33_45
 L  EDGE_44_45
 L  EDGE_62_81
 L  EDGE_25_41
 L  EDGE_10_52
 L  EDGE_44_54
 L  EDGE_10_61
 L  EDGE_39_97
 L  EDGE_2_57
 L  EDGE_14_22
 L  EDGE_25_59
 L  EDGE_51_80
 L  EDGE_2_75
 L  EDGE_32_76
 L  EDGE_24_72
 L  EDGE_32_85
 L  EDGE_43_85
 L  EDGE_66_87
 L  EDGE_1_79
 L  EDGE_36_46
 L  EDGE_66_96
 L  EDGE_55_59
 L  EDGE_24_90
 L  EDGE_47_55
 L  EDGE_55_68
 L  EDGE_1_97
 L  EDGE_7_28
 L  EDGE_18_28
 L  EDGE_55_77
 L  EDGE_85_95
 L  EDGE_9_56
 L  EDGE_5_67
 L  EDGE_28_69
 L  EDGE_17_78
 L  EDGE_28_78
 L  EDGE_29_43
 L  EDGE_47_91
 L  EDGE_29_52
 L  EDGE_40_52
 L  EDGE_58_88
 L  EDGE_40_61
 L  EDGE_58_97
 L  EDGE_9_92
 L  EDGE_50_93
 L  EDGE_10_20
 L  EDGE_6_68
 L  EDGE_8_96
 L  EDGE_25_27
 L  EDGE_21_75
 L  EDGE_62_76
 L  EDGE_2_34
 L  EDGE_25_36
 L  EDGE_10_47
 L  EDGE_20_79
 L  EDGE_62_94
 L  EDGE_20_88
 L  EDGE_32_53
 L  EDGE_51_66
 L  EDGE_3_26
 L  EDGE_12_93
 L  EDGE_13_58
 L  EDGE_4_89
 L  EDGE_85_86
 L  EDGE_35_67
 L  EDGE_3_44
 L  EDGE_1_74
 L  EDGE_13_76
 L  EDGE_15_18
 L  EDGE_24_85
 L  EDGE_35_85
 L  EDGE_28_46
 L  EDGE_24_94
 L  EDGE_18_23
 L  EDGE_88_97
 L  EDGE_55_72
 L  EDGE_5_53
 L  EDGE_17_55
 L  EDGE_46_91
 L  EDGE_9_51
 L  EDGE_6_27
 L  EDGE_36_77
 L  EDGE_77_78
 L  EDGE_21_25
 L  EDGE_5_71
 L  EDGE_6_36
 L  EDGE_28_73
 L  EDGE_58_74
 L  EDGE_21_34
 L  EDGE_28_82
 L  EDGE_40_47
 L  EDGE_69_83
 L  EDGE_9_78
 L  EDGE_42_84
 L  EDGE_61_97
 L  EDGE_19_91
 L  EDGE_2_20
 L  EDGE_42_93
 L  EDGE_10_33
 L  EDGE_33_35
 L  EDGE_39_69
 L  EDGE_20_65
 L  EDGE_25_31
 L  EDGE_0_96
 L  EDGE_10_42
 L  EDGE_39_78
 L  EDGE_54_67
 L  EDGE_10_51
 L  EDGE_12_70
 L  EDGE_20_83
 L  EDGE_43_48
 L  EDGE_84_86
 L  EDGE_20_92
 L  EDGE_32_57
 L  EDGE_43_57
 L  EDGE_51_70
 L  EDGE_62_70
 L  EDGE_14_30
 L  EDGE_66_68
 L  EDGE_35_62
 L  EDGE_66_77
 L  EDGE_35_71
 L  EDGE_43_84
 L  EDGE_28_32
 L  EDGE_1_78
 L  EDGE_7_9
 L  EDGE_36_45
 L  EDGE_65_81
 L  EDGE_1_87
 L  EDGE_13_89
 L  EDGE_5_48
 L  EDGE_28_50
 L  EDGE_9_46
 L  EDGE_47_72
 L  EDGE_38_91
 L  EDGE_29_33
 L  EDGE_9_64
 L  EDGE_15_98
 L  EDGE_50_65
 L  EDGE_40_42
 L  EDGE_69_78
 L  EDGE_21_38
 L  EDGE_29_51
 L  EDGE_42_70
 L  EDGE_69_87
 L  EDGE_80_87
 L  EDGE_61_92
 L  EDGE_27_99
 L  EDGE_0_82
 L  EDGE_62_66
 L  EDGE_20_60
 L  EDGE_0_91
 L  EDGE_39_73
 L  EDGE_73_75
 L  EDGE_31_69
 L  EDGE_73_84
 L  EDGE_31_78
 L  EDGE_24_39
 L  EDGE_31_87
 L  EDGE_35_39
 L  EDGE_43_52
 L  EDGE_12_83
 L  EDGE_13_48
 L  EDGE_20_96
 L  EDGE_14_25
 L  EDGE_35_48
 L  EDGE_51_65
 L  EDGE_1_55
 L  EDGE_13_57
 L  EDGE_4_88
 L  EDGE_35_57
 L  EDGE_51_74
 L  EDGE_13_66
 L  EDGE_53_93
 L  EDGE_45_98
 L  EDGE_1_73
 L  EDGE_35_75
 L  EDGE_36_40
 L  EDGE_5_34
 L  EDGE_1_82
 L  EDGE_46_72
 L  EDGE_16_80
 L  EDGE_17_45
 L  EDGE_88_96
 L  EDGE_49_86
 L  EDGE_5_61
 L  EDGE_6_26
 L  EDGE_58_64
 L  EDGE_15_93
 L  EDGE_5_70
 L  EDGE_7_89
 L  EDGE_29_37
 L  EDGE_77_86
 L  EDGE_61_69
 L  EDGE_18_98
 L  EDGE_21_42
 L  EDGE_50_78
 L  EDGE_58_91
 L  EDGE_8_72
 L  EDGE_30_72
 L  EDGE_42_74
 L  EDGE_10_14
 L  EDGE_80_91
 L  EDGE_2_10
 L  EDGE_27_94
 L  EDGE_42_92
 L  EDGE_31_55
 L  EDGE_0_86
 L  EDGE_10_32
 L  EDGE_19_99
 L  EDGE_2_28
 L  EDGE_20_64
 L  EDGE_23_51
 L  EDGE_23_60
 L  EDGE_13_25
 L  EDGE_20_73
 L  EDGE_30_99
 L  EDGE_20_82
 L  EDGE_31_82
 L  EDGE_72_83
 L  EDGE_13_43
 L  EDGE_32_56
 L  EDGE_72_92
 L  EDGE_12_87
 L  EDGE_87_90
 L  EDGE_13_61
 L  EDGE_53_97
 L  EDGE_64_97
 L  EDGE_34_93
 L  EDGE_56_93
 L  EDGE_37_89
 L  EDGE_36_44
 L  EDGE_65_80
 L  EDGE_28_40
 L  EDGE_9_36
 L  EDGE_5_47
 L  EDGE_6_12
 L  EDGE_46_85
 L  EDGE_57_85
 L  EDGE_46_94
 L  EDGE_57_94
 L  EDGE_58_59
 L  EDGE_6_30
 L  EDGE_50_64
 L  EDGE_80_86
 L  EDGE_8_67
 L  EDGE_42_69
 L  EDGE_50_82
 L  EDGE_0_63
 L  EDGE_39_45
 L  EDGE_61_82
 L  EDGE_31_41
 L  EDGE_70_95
 L  EDGE_30_85
 L  EDGE_83_88
 L  EDGE_62_65
 L  EDGE_23_46
 L  EDGE_19_94
 L  EDGE_4_42
 L  EDGE_41_91
 L  EDGE_75_93
 L  EDGE_32_33
 L  EDGE_12_64
 L  EDGE_1_27
 L  EDGE_32_42
 L  EDGE_33_96
 L  EDGE_1_36
 L  EDGE_4_69
 L  EDGE_32_51
 L  EDGE_23_82
 L  EDGE_72_96
 L  EDGE_34_79
 L  EDGE_1_54
 L  EDGE_16_52
 L  EDGE_46_53
 L  EDGE_1_63
 L  EDGE_56_88
 L  EDGE_16_61
 L  EDGE_49_58
 L  EDGE_17_35
 L  EDGE_68_71
 L  EDGE_46_80
 L  EDGE_68_80
 L  EDGE_76_93
 L  EDGE_15_74
 L  EDGE_46_89
 L  EDGE_68_89
 L  EDGE_15_83
 L  EDGE_68_98
 L  EDGE_6_25
 L  EDGE_18_79
 L  EDGE_8_53
 L  EDGE_27_66
 L  EDGE_7_97
 L  EDGE_50_77
 L  EDGE_19_71
 L  EDGE_31_36
 L  EDGE_10_13
 L  EDGE_11_67
 L  EDGE_11_76
 L  EDGE_75_79
 L  EDGE_19_89
 L  EDGE_31_54
 L  EDGE_4_37
 L  EDGE_83_92
 L  EDGE_23_50
 L  EDGE_91_96
 L  EDGE_31_63
 L  EDGE_52_95
 L  EDGE_13_24
 L  EDGE_77_88
 L  EDGE_16_20
 L  EDGE_23_68
 L  EDGE_4_64
 L  EDGE_16_29
 L  EDGE_53_78
 L  EDGE_16_38
 L  EDGE_56_74
 L  EDGE_24_51
 L  EDGE_87_89
 L  EDGE_45_83
 L  EDGE_22_90
 L  EDGE_37_88
 L  EDGE_28_30
 L  EDGE_5_37
 L  EDGE_57_75
 L  EDGE_26_69
 L  EDGE_15_78
 L  EDGE_6_20
 L  EDGE_18_74
 L  EDGE_26_87
 L  EDGE_27_52
 L  EDGE_30_39
 L  EDGE_18_83
 L  EDGE_49_89
 L  EDGE_79_90
 L  EDGE_61_63
 L  EDGE_90_99
 L  EDGE_7_92
 L  EDGE_8_57
 L  EDGE_20_22
 L  EDGE_27_70
 L  EDGE_11_53
 L  EDGE_12_18
 L  EDGE_48_93
 L  EDGE_63_91
 L  EDGE_71_95
 L  EDGE_11_62
 L  EDGE_23_27
 L  EDGE_19_75
 L  EDGE_40_98
 L  EDGE_11_71
 L  EDGE_12_36
 L  EDGE_23_36
 L  EDGE_31_49
 L  EDGE_41_72
 L  EDGE_11_80
 L  EDGE_23_45
 L  EDGE_83_96
 L  EDGE_33_77
 L  EDGE_13_19
 L  EDGE_53_55
 L  EDGE_25_82
 L  EDGE_72_77
 L  EDGE_45_60
 L  EDGE_45_69
 L  EDGE_56_69
 L  EDGE_34_78
 L  EDGE_56_78
 L  EDGE_53_91
 L  EDGE_37_83
 L  EDGE_38_48
 L  EDGE_56_96
 L  EDGE_46_61
 L  EDGE_15_55
 L  EDGE_57_70
 L  EDGE_27_29
 L  EDGE_68_79
 L  EDGE_7_60
 L  EDGE_26_73
 L  EDGE_71_72
 L  EDGE_15_82
 L  EDGE_27_47
 L  EDGE_0_30
 L  EDGE_18_78
 L  EDGE_11_39
 L  EDGE_63_77
 L  EDGE_30_52
 L  EDGE_42_54
 L  EDGE_82_90
 L  EDGE_29_84
 L  EDGE_12_13
 L  EDGE_48_97
 L  EDGE_71_99
 L  EDGE_63_95
 L  EDGE_30_70
 L  EDGE_0_66
 L  EDGE_11_66
 L  EDGE_52_67
 L  EDGE_31_44
 L  EDGE_11_75
 L  EDGE_12_40
 L  EDGE_1_3
 L  EDGE_52_76
 L  EDGE_4_36
 L  EDGE_83_91
 L  EDGE_25_68
 L  EDGE_45_46
 L  EDGE_1_21
 L  EDGE_53_59
 L  EDGE_44_90
 L  EDGE_16_19
 L  EDGE_34_55
 L  EDGE_64_68
 L  EDGE_33_99
 L  EDGE_34_64
 L  EDGE_45_64
 L  EDGE_1_39
 L  EDGE_14_58
 L  EDGE_56_64
 L  EDGE_22_71
 L  EDGE_3_76
 L  EDGE_46_56
 L  EDGE_86_92
 L  EDGE_14_85
 L  EDGE_67_88
 L  EDGE_22_98
 L  EDGE_70_84
 L  EDGE_59_93
 L  EDGE_8_20
 L  EDGE_15_68
 L  EDGE_26_68
 L  EDGE_49_70
 L  EDGE_8_29
 L  EDGE_15_77
 L  EDGE_27_42
 L  EDGE_18_73
 L  EDGE_79_89
 L  EDGE_71_85
 L  EDGE_90_98
 L  EDGE_29_79
 L  EDGE_71_94
 L  EDGE_6_86
 L  EDGE_11_52
 L  EDGE_41_53
 L  EDGE_60_66
 L  EDGE_63_90
 L  EDGE_6_95
 L  EDGE_11_61
 L  EDGE_63_99
 L  EDGE_44_58
 L  EDGE_54_58
 L  EDGE_33_67
 L  EDGE_60_84
 L  EDGE_75_82
 L  EDGE_1_7
 L  EDGE_10_74
 L  EDGE_33_76
 L  EDGE_34_41
 L  EDGE_13_18
 L  EDGE_2_70
 L  EDGE_44_85
 L  EDGE_34_50
 L  EDGE_53_54
 L  EDGE_1_25
 L  EDGE_25_81
 L  EDGE_33_94
 L  EDGE_34_59
 L  EDGE_44_94
 L  EDGE_56_59
 L  EDGE_37_55
 L  EDGE_66_91
 L  EDGE_22_66
 L  EDGE_74_95
 L  EDGE_2_97
 L  EDGE_25_99
 L  EDGE_37_64
 L  EDGE_56_77
 L  EDGE_67_74
 L  EDGE_86_87
 L  EDGE_3_80
 L  EDGE_38_56
 L  EDGE_18_50
 L  EDGE_59_88
 L  EDGE_7_59
 L  EDGE_47_95
 L  EDGE_48_60
 L  EDGE_59_97
 L  EDGE_7_68
 L  EDGE_19_33
 L  EDGE_0_29
 L  EDGE_40_65
 L  EDGE_63_67
 L  EDGE_6_72
 L  EDGE_40_74
 L  EDGE_19_51
 L  EDGE_21_70
 L  EDGE_48_87
 L  EDGE_6_81
 L  EDGE_41_48
 L  EDGE_63_76
 L  EDGE_20_25
 L  EDGE_40_92
 L  EDGE_52_57
 L  EDGE_21_88
 L  EDGE_52_66
 L  EDGE_4_26
 L  EDGE_10_60
 L  EDGE_41_75
 L  EDGE_62_98
 L  EDGE_4_35
 L  EDGE_33_71
 L  EDGE_52_84
 L  EDGE_1_11
 L  EDGE_2_65
 L  EDGE_1_20
 L  EDGE_33_89
 L  EDGE_34_54
 L  EDGE_51_88
 L  EDGE_25_85
 L  EDGE_51_97
 L  EDGE_74_99
 L  EDGE_14_57
 L  EDGE_15_22
 L  EDGE_37_59
 L  EDGE_3_66
 L  EDGE_35_98
 L  EDGE_7_27
 L  EDGE_3_75
 L  EDGE_14_75
 L  EDGE_15_40
 L  EDGE_38_42
 L  EDGE_36_72
 L  EDGE_67_78
 L  EDGE_67_87
 L  EDGE_70_74
 L  EDGE_7_45
 L  EDGE_59_83
 L  EDGE_15_58
 L  EDGE_17_77
 L  EDGE_70_92
 L  EDGE_17_86
 L  EDGE_11_15
 L  EDGE_27_32
 L  EDGE_8_28
 L  EDGE_9_82
 L  EDGE_19_28
 L  EDGE_28_86
 L  EDGE_48_64
 L  EDGE_30_37
 L  EDGE_92_98
 L  EDGE_63_71
 L  EDGE_48_82
 L  EDGE_11_42
 L  EDGE_40_78
 L  EDGE_41_43
 L  EDGE_33_39
 L  EDGE_40_87
 L  EDGE_41_52
 L  EDGE_81_97
 L  EDGE_44_57
 L  EDGE_62_93
 L  EDGE_54_98
 L  EDGE_34_40
 L  EDGE_25_71
 L  EDGE_14_34
 L  EDGE_93_98
 L  EDGE_66_81
 L  EDGE_45_58
 L  EDGE_3_52
 L  EDGE_35_84
 L  EDGE_55_62
 L  EDGE_26_35
 L  EDGE_36_67
 L  EDGE_16_98
 L  EDGE_17_63
 L  EDGE_67_82
 L  EDGE_70_78
 L  EDGE_7_49
 L  EDGE_47_85
 L  EDGE_55_98
 L  EDGE_36_94
 L  EDGE_19_23
 L  EDGE_28_90
 L  EDGE_40_55
 L  EDGE_48_68
 L  EDGE_21_60
 L  EDGE_40_73
 L  EDGE_41_47
 L  EDGE_33_43
 L  EDGE_73_79
 L  EDGE_52_56
 L  EDGE_81_92
 L  EDGE_4_16
 L  EDGE_44_52
 L  EDGE_41_65
 L  EDGE_25_57
 L  EDGE_3_20
 L  EDGE_44_70
 L  EDGE_22_33
 L  EDGE_54_93
 L  EDGE_25_66
 L  EDGE_34_44
 L  EDGE_74_80
 L  EDGE_3_38
 L  EDGE_66_76
 L  EDGE_51_87
 L  EDGE_2_82
 L  EDGE_32_83
 L  EDGE_43_92
COLUMNS
    x_0         OBJ       -1
    x_0         EDGE_0_93  1.0
    x_0         EDGE_0_88  1.0
    x_0         EDGE_0_97  1.0
    x_0         EDGE_0_78  1.0
    x_0         EDGE_0_46  1.0
    x_0         EDGE_0_32  1.0
    x_0         EDGE_0_36  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_22  1.0
    x_0         EDGE_0_3  1.0
    x_0         EDGE_0_12  1.0
    x_0         EDGE_0_21  1.0
    x_0         EDGE_0_96  1.0
    x_0         EDGE_0_82  1.0
    x_0         EDGE_0_91  1.0
    x_0         EDGE_0_86  1.0
    x_0         EDGE_0_63  1.0
    x_0         EDGE_0_30  1.0
    x_0         EDGE_0_66  1.0
    x_0         EDGE_0_29  1.0
    x_1         OBJ       -1
    x_1         EDGE_1_81  1.0
    x_1         EDGE_1_76  1.0
    x_1         EDGE_1_94  1.0
    x_1         EDGE_1_53  1.0
    x_1         EDGE_1_80  1.0
    x_1         EDGE_1_57  1.0
    x_1         EDGE_1_56  1.0
    x_1         EDGE_1_15  1.0
    x_1         EDGE_1_42  1.0
    x_1         EDGE_1_51  1.0
    x_1         EDGE_1_46  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_14  1.0
    x_1         EDGE_1_9  1.0
    x_1         EDGE_1_18  1.0
    x_1         EDGE_1_98  1.0
    x_1         EDGE_1_79  1.0
    x_1         EDGE_1_97  1.0
    x_1         EDGE_1_74  1.0
    x_1         EDGE_1_78  1.0
    x_1         EDGE_1_87  1.0
    x_1         EDGE_1_55  1.0
    x_1         EDGE_1_73  1.0
    x_1         EDGE_1_82  1.0
    x_1         EDGE_1_27  1.0
    x_1         EDGE_1_36  1.0
    x_1         EDGE_1_54  1.0
    x_1         EDGE_1_63  1.0
    x_1         EDGE_1_3  1.0
    x_1         EDGE_1_21  1.0
    x_1         EDGE_1_39  1.0
    x_1         EDGE_1_7  1.0
    x_1         EDGE_1_25  1.0
    x_1         EDGE_1_11  1.0
    x_1         EDGE_1_20  1.0
    x_2         OBJ       -1
    x_2         EDGE_2_41  1.0
    x_2         EDGE_2_68  1.0
    x_2         EDGE_2_36  1.0
    x_2         EDGE_2_22  1.0
    x_2         EDGE_2_26  1.0
    x_2         EDGE_2_35  1.0
    x_2         EDGE_2_12  1.0
    x_2         EDGE_2_16  1.0
    x_2         EDGE_2_77  1.0
    x_2         EDGE_2_86  1.0
    x_2         EDGE_2_99  1.0
    x_2         EDGE_2_71  1.0
    x_2         EDGE_2_57  1.0
    x_2         EDGE_2_75  1.0
    x_2         EDGE_2_34  1.0
    x_2         EDGE_2_20  1.0
    x_2         EDGE_2_10  1.0
    x_2         EDGE_2_28  1.0
    x_2         EDGE_2_70  1.0
    x_2         EDGE_2_97  1.0
    x_2         EDGE_2_65  1.0
    x_2         EDGE_2_82  1.0
    x_3         OBJ       -1
    x_3         EDGE_3_6  1.0
    x_3         EDGE_3_93  1.0
    x_3         EDGE_3_65  1.0
    x_3         EDGE_3_46  1.0
    x_3         EDGE_3_55  1.0
    x_3         EDGE_3_32  1.0
    x_3         EDGE_3_41  1.0
    x_3         EDGE_3_68  1.0
    x_3         EDGE_3_54  1.0
    x_3         EDGE_0_3  1.0
    x_3         EDGE_3_26  1.0
    x_3         EDGE_3_44  1.0
    x_3         EDGE_1_3  1.0
    x_3         EDGE_3_76  1.0
    x_3         EDGE_3_80  1.0
    x_3         EDGE_3_66  1.0
    x_3         EDGE_3_75  1.0
    x_3         EDGE_3_52  1.0
    x_3         EDGE_3_20  1.0
    x_3         EDGE_3_38  1.0
    x_4         OBJ       -1
    x_4         EDGE_4_96  1.0
    x_4         EDGE_4_95  1.0
    x_4         EDGE_4_72  1.0
    x_4         EDGE_4_90  1.0
    x_4         EDGE_4_85  1.0
    x_4         EDGE_4_71  1.0
    x_4         EDGE_4_80  1.0
    x_4         EDGE_4_6  1.0
    x_4         EDGE_4_24  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_4_19  1.0
    x_4         EDGE_4_14  1.0
    x_4         EDGE_4_89  1.0
    x_4         EDGE_4_88  1.0
    x_4         EDGE_4_42  1.0
    x_4         EDGE_4_69  1.0
    x_4         EDGE_4_37  1.0
    x_4         EDGE_4_64  1.0
    x_4         EDGE_4_36  1.0
    x_4         EDGE_4_26  1.0
    x_4         EDGE_4_35  1.0
    x_4         EDGE_4_16  1.0
    x_5         OBJ       -1
    x_5         EDGE_5_74  1.0
    x_5         EDGE_5_83  1.0
    x_5         EDGE_5_60  1.0
    x_5         EDGE_5_69  1.0
    x_5         EDGE_5_55  1.0
    x_5         EDGE_5_73  1.0
    x_5         EDGE_5_82  1.0
    x_5         EDGE_5_41  1.0
    x_5         EDGE_5_50  1.0
    x_5         EDGE_5_45  1.0
    x_5         EDGE_5_58  1.0
    x_5         EDGE_5_8  1.0
    x_5         EDGE_5_35  1.0
    x_5         EDGE_5_44  1.0
    x_5         EDGE_5_12  1.0
    x_5         EDGE_5_7  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_86  1.0
    x_5         EDGE_5_72  1.0
    x_5         EDGE_5_99  1.0
    x_5         EDGE_5_67  1.0
    x_5         EDGE_5_53  1.0
    x_5         EDGE_5_71  1.0
    x_5         EDGE_5_48  1.0
    x_5         EDGE_5_34  1.0
    x_5         EDGE_5_61  1.0
    x_5         EDGE_5_70  1.0
    x_5         EDGE_5_47  1.0
    x_5         EDGE_5_37  1.0
    x_6         OBJ       -1
    x_6         EDGE_6_57  1.0
    x_6         EDGE_6_66  1.0
    x_6         EDGE_6_75  1.0
    x_6         EDGE_6_84  1.0
    x_6         EDGE_3_6  1.0
    x_6         EDGE_6_47  1.0
    x_6         EDGE_6_51  1.0
    x_6         EDGE_6_10  1.0
    x_6         EDGE_6_13  1.0
    x_6         EDGE_6_98  1.0
    x_6         EDGE_4_6  1.0
    x_6         EDGE_6_97  1.0
    x_6         EDGE_6_68  1.0
    x_6         EDGE_6_27  1.0
    x_6         EDGE_6_36  1.0
    x_6         EDGE_6_26  1.0
    x_6         EDGE_6_12  1.0
    x_6         EDGE_6_30  1.0
    x_6         EDGE_6_25  1.0
    x_6         EDGE_6_20  1.0
    x_6         EDGE_6_86  1.0
    x_6         EDGE_6_95  1.0
    x_6         EDGE_6_72  1.0
    x_6         EDGE_6_81  1.0
    x_7         OBJ       -1
    x_7         EDGE_7_26  1.0
    x_7         EDGE_7_30  1.0
    x_7         EDGE_7_16  1.0
    x_7         EDGE_5_7  1.0
    x_7         EDGE_7_71  1.0
    x_7         EDGE_7_80  1.0
    x_7         EDGE_7_39  1.0
    x_7         EDGE_7_57  1.0
    x_7         EDGE_7_66  1.0
    x_7         EDGE_7_20  1.0
    x_7         EDGE_7_38  1.0
    x_7         EDGE_7_56  1.0
    x_7         EDGE_7_42  1.0
    x_7         EDGE_7_28  1.0
    x_7         EDGE_7_9  1.0
    x_7         EDGE_7_89  1.0
    x_7         EDGE_7_97  1.0
    x_7         EDGE_7_92  1.0
    x_7         EDGE_7_60  1.0
    x_7         EDGE_1_7  1.0
    x_7         EDGE_7_59  1.0
    x_7         EDGE_7_68  1.0
    x_7         EDGE_7_27  1.0
    x_7         EDGE_7_45  1.0
    x_7         EDGE_7_49  1.0
    x_8         OBJ       -1
    x_8         EDGE_8_79  1.0
    x_8         EDGE_5_8  1.0
    x_8         EDGE_8_55  1.0
    x_8         EDGE_8_41  1.0
    x_8         EDGE_8_36  1.0
    x_8         EDGE_8_13  1.0
    x_8         EDGE_8_31  1.0
    x_8         EDGE_8_26  1.0
    x_8         EDGE_8_12  1.0
    x_8         EDGE_8_21  1.0
    x_8         EDGE_8_30  1.0
    x_8         EDGE_8_96  1.0
    x_8         EDGE_8_72  1.0
    x_8         EDGE_8_67  1.0
    x_8         EDGE_8_53  1.0
    x_8         EDGE_8_57  1.0
    x_8         EDGE_8_20  1.0
    x_8         EDGE_8_29  1.0
    x_8         EDGE_8_28  1.0
    x_9         OBJ       -1
    x_9         EDGE_9_99  1.0
    x_9         EDGE_9_53  1.0
    x_9         EDGE_9_66  1.0
    x_9         EDGE_9_43  1.0
    x_9         EDGE_9_52  1.0
    x_9         EDGE_9_38  1.0
    x_9         EDGE_9_19  1.0
    x_9         EDGE_1_9  1.0
    x_9         EDGE_9_75  1.0
    x_9         EDGE_9_84  1.0
    x_9         EDGE_9_93  1.0
    x_9         EDGE_9_79  1.0
    x_9         EDGE_9_88  1.0
    x_9         EDGE_9_56  1.0
    x_9         EDGE_9_92  1.0
    x_9         EDGE_9_51  1.0
    x_9         EDGE_9_78  1.0
    x_9         EDGE_7_9  1.0
    x_9         EDGE_9_46  1.0
    x_9         EDGE_9_64  1.0
    x_9         EDGE_9_36  1.0
    x_9         EDGE_9_82  1.0
    x_10        OBJ       -1
    x_10        EDGE_10_27  1.0
    x_10        EDGE_10_40  1.0
    x_10        EDGE_10_58  1.0
    x_10        EDGE_10_17  1.0
    x_10        EDGE_10_35  1.0
    x_10        EDGE_10_44  1.0
    x_10        EDGE_6_10  1.0
    x_10        EDGE_10_16  1.0
    x_10        EDGE_10_25  1.0
    x_10        EDGE_10_11  1.0
    x_10        EDGE_10_86  1.0
    x_10        EDGE_10_72  1.0
    x_10        EDGE_10_99  1.0
    x_10        EDGE_10_94  1.0
    x_10        EDGE_10_62  1.0
    x_10        EDGE_10_80  1.0
    x_10        EDGE_10_89  1.0
    x_10        EDGE_10_48  1.0
    x_10        EDGE_10_75  1.0
    x_10        EDGE_10_52  1.0
    x_10        EDGE_10_61  1.0
    x_10        EDGE_10_20  1.0
    x_10        EDGE_10_47  1.0
    x_10        EDGE_10_33  1.0
    x_10        EDGE_10_42  1.0
    x_10        EDGE_10_51  1.0
    x_10        EDGE_10_14  1.0
    x_10        EDGE_2_10  1.0
    x_10        EDGE_10_32  1.0
    x_10        EDGE_10_13  1.0
    x_10        EDGE_10_74  1.0
    x_10        EDGE_10_60  1.0
    x_11        OBJ       -1
    x_11        EDGE_11_84  1.0
    x_11        EDGE_11_93  1.0
    x_11        EDGE_10_11  1.0
    x_11        EDGE_11_68  1.0
    x_11        EDGE_11_18  1.0
    x_11        EDGE_11_27  1.0
    x_11        EDGE_11_49  1.0
    x_11        EDGE_11_17  1.0
    x_11        EDGE_11_35  1.0
    x_11        EDGE_11_30  1.0
    x_11        EDGE_11_67  1.0
    x_11        EDGE_11_76  1.0
    x_11        EDGE_11_53  1.0
    x_11        EDGE_11_62  1.0
    x_11        EDGE_11_71  1.0
    x_11        EDGE_11_80  1.0
    x_11        EDGE_11_39  1.0
    x_11        EDGE_11_66  1.0
    x_11        EDGE_11_75  1.0
    x_11        EDGE_11_52  1.0
    x_11        EDGE_11_61  1.0
    x_11        EDGE_1_11  1.0
    x_11        EDGE_11_15  1.0
    x_11        EDGE_11_42  1.0
    x_12        OBJ       -1
    x_12        EDGE_12_77  1.0
    x_12        EDGE_12_58  1.0
    x_12        EDGE_2_12  1.0
    x_12        EDGE_12_62  1.0
    x_12        EDGE_12_71  1.0
    x_12        EDGE_12_80  1.0
    x_12        EDGE_12_34  1.0
    x_12        EDGE_5_12  1.0
    x_12        EDGE_12_24  1.0
    x_12        EDGE_12_33  1.0
    x_12        EDGE_12_42  1.0
    x_12        EDGE_12_14  1.0
    x_12        EDGE_12_23  1.0
    x_12        EDGE_8_12  1.0
    x_12        EDGE_0_12  1.0
    x_12        EDGE_12_93  1.0
    x_12        EDGE_12_70  1.0
    x_12        EDGE_12_83  1.0
    x_12        EDGE_12_87  1.0
    x_12        EDGE_6_12  1.0
    x_12        EDGE_12_64  1.0
    x_12        EDGE_12_18  1.0
    x_12        EDGE_12_36  1.0
    x_12        EDGE_12_13  1.0
    x_12        EDGE_12_40  1.0
    x_13        OBJ       -1
    x_13        EDGE_13_74  1.0
    x_13        EDGE_13_60  1.0
    x_13        EDGE_13_64  1.0
    x_13        EDGE_13_41  1.0
    x_13        EDGE_13_50  1.0
    x_13        EDGE_13_27  1.0
    x_13        EDGE_13_36  1.0
    x_13        EDGE_13_45  1.0
    x_13        EDGE_13_63  1.0
    x_13        EDGE_13_31  1.0
    x_13        EDGE_13_17  1.0
    x_13        EDGE_13_44  1.0
    x_13        EDGE_6_13  1.0
    x_13        EDGE_8_13  1.0
    x_13        EDGE_13_96  1.0
    x_13        EDGE_13_91  1.0
    x_13        EDGE_13_86  1.0
    x_13        EDGE_13_95  1.0
    x_13        EDGE_13_58  1.0
    x_13        EDGE_13_76  1.0
    x_13        EDGE_13_89  1.0
    x_13        EDGE_13_48  1.0
    x_13        EDGE_13_57  1.0
    x_13        EDGE_13_66  1.0
    x_13        EDGE_13_25  1.0
    x_13        EDGE_13_43  1.0
    x_13        EDGE_13_61  1.0
    x_13        EDGE_10_13  1.0
    x_13        EDGE_13_24  1.0
    x_13        EDGE_13_19  1.0
    x_13        EDGE_12_13  1.0
    x_13        EDGE_13_18  1.0
    x_14        OBJ       -1
    x_14        EDGE_14_15  1.0
    x_14        EDGE_14_24  1.0
    x_14        EDGE_14_33  1.0
    x_14        EDGE_14_32  1.0
    x_14        EDGE_14_18  1.0
    x_14        EDGE_14_74  1.0
    x_14        EDGE_1_14  1.0
    x_14        EDGE_14_69  1.0
    x_14        EDGE_14_55  1.0
    x_14        EDGE_12_14  1.0
    x_14        EDGE_14_41  1.0
    x_14        EDGE_14_59  1.0
    x_14        EDGE_4_14  1.0
    x_14        EDGE_14_45  1.0
    x_14        EDGE_14_22  1.0
    x_14        EDGE_14_30  1.0
    x_14        EDGE_14_25  1.0
    x_14        EDGE_10_14  1.0
    x_14        EDGE_14_58  1.0
    x_14        EDGE_14_85  1.0
    x_14        EDGE_14_57  1.0
    x_14        EDGE_14_75  1.0
    x_14        EDGE_14_34  1.0
    x_15        OBJ       -1
    x_15        EDGE_15_30  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_94  1.0
    x_15        EDGE_1_15  1.0
    x_15        EDGE_15_62  1.0
    x_15        EDGE_15_80  1.0
    x_15        EDGE_15_48  1.0
    x_15        EDGE_15_57  1.0
    x_15        EDGE_15_43  1.0
    x_15        EDGE_15_42  1.0
    x_15        EDGE_15_51  1.0
    x_15        EDGE_15_18  1.0
    x_15        EDGE_15_98  1.0
    x_15        EDGE_15_93  1.0
    x_15        EDGE_15_74  1.0
    x_15        EDGE_15_83  1.0
    x_15        EDGE_15_78  1.0
    x_15        EDGE_15_55  1.0
    x_15        EDGE_15_82  1.0
    x_15        EDGE_15_68  1.0
    x_15        EDGE_15_77  1.0
    x_15        EDGE_15_22  1.0
    x_15        EDGE_15_40  1.0
    x_15        EDGE_15_58  1.0
    x_15        EDGE_11_15  1.0
    x_16        OBJ       -1
    x_16        EDGE_16_84  1.0
    x_16        EDGE_16_56  1.0
    x_16        EDGE_7_16  1.0
    x_16        EDGE_16_51  1.0
    x_16        EDGE_10_16  1.0
    x_16        EDGE_2_16  1.0
    x_16        EDGE_16_54  1.0
    x_16        EDGE_16_17  1.0
    x_16        EDGE_16_96  1.0
    x_16        EDGE_16_91  1.0
    x_16        EDGE_16_80  1.0
    x_16        EDGE_16_52  1.0
    x_16        EDGE_16_61  1.0
    x_16        EDGE_16_20  1.0
    x_16        EDGE_16_29  1.0
    x_16        EDGE_16_38  1.0
    x_16        EDGE_16_19  1.0
    x_16        EDGE_16_98  1.0
    x_16        EDGE_4_16  1.0
    x_17        OBJ       -1
    x_17        EDGE_17_53  1.0
    x_17        EDGE_10_17  1.0
    x_17        EDGE_17_25  1.0
    x_17        EDGE_17_34  1.0
    x_17        EDGE_17_43  1.0
    x_17        EDGE_17_33  1.0
    x_17        EDGE_17_42  1.0
    x_17        EDGE_17_19  1.0
    x_17        EDGE_13_17  1.0
    x_17        EDGE_16_17  1.0
    x_17        EDGE_17_84  1.0
    x_17        EDGE_17_79  1.0
    x_17        EDGE_11_17  1.0
    x_17        EDGE_17_74  1.0
    x_17        EDGE_17_83  1.0
    x_17        EDGE_17_92  1.0
    x_17        EDGE_17_78  1.0
    x_17        EDGE_17_55  1.0
    x_17        EDGE_17_45  1.0
    x_17        EDGE_17_35  1.0
    x_17        EDGE_17_77  1.0
    x_17        EDGE_17_86  1.0
    x_17        EDGE_17_63  1.0
    x_18        OBJ       -1
    x_18        EDGE_14_18  1.0
    x_18        EDGE_18_81  1.0
    x_18        EDGE_18_90  1.0
    x_18        EDGE_18_94  1.0
    x_18        EDGE_18_71  1.0
    x_18        EDGE_18_89  1.0
    x_18        EDGE_18_48  1.0
    x_18        EDGE_18_57  1.0
    x_18        EDGE_11_18  1.0
    x_18        EDGE_1_18  1.0
    x_18        EDGE_18_20  1.0
    x_18        EDGE_18_56  1.0
    x_18        EDGE_18_33  1.0
    x_18        EDGE_18_28  1.0
    x_18        EDGE_15_18  1.0
    x_18        EDGE_18_23  1.0
    x_18        EDGE_18_98  1.0
    x_18        EDGE_18_79  1.0
    x_18        EDGE_18_74  1.0
    x_18        EDGE_18_83  1.0
    x_18        EDGE_12_18  1.0
    x_18        EDGE_18_78  1.0
    x_18        EDGE_18_73  1.0
    x_18        EDGE_13_18  1.0
    x_18        EDGE_18_50  1.0
    x_19        OBJ       -1
    x_19        EDGE_19_84  1.0
    x_19        EDGE_19_93  1.0
    x_19        EDGE_19_79  1.0
    x_19        EDGE_19_88  1.0
    x_19        EDGE_19_74  1.0
    x_19        EDGE_19_92  1.0
    x_19        EDGE_19_87  1.0
    x_19        EDGE_17_19  1.0
    x_19        EDGE_19_73  1.0
    x_19        EDGE_19_82  1.0
    x_19        EDGE_9_19  1.0
    x_19        EDGE_19_41  1.0
    x_19        EDGE_19_45  1.0
    x_19        EDGE_19_31  1.0
    x_19        EDGE_19_40  1.0
    x_19        EDGE_19_26  1.0
    x_19        EDGE_4_19  1.0
    x_19        EDGE_19_91  1.0
    x_19        EDGE_19_99  1.0
    x_19        EDGE_19_94  1.0
    x_19        EDGE_19_71  1.0
    x_19        EDGE_19_89  1.0
    x_19        EDGE_19_75  1.0
    x_19        EDGE_13_19  1.0
    x_19        EDGE_16_19  1.0
    x_19        EDGE_19_33  1.0
    x_19        EDGE_19_51  1.0
    x_19        EDGE_19_28  1.0
    x_19        EDGE_19_23  1.0
    x_20        OBJ       -1
    x_20        EDGE_20_99  1.0
    x_20        EDGE_20_67  1.0
    x_20        EDGE_20_76  1.0
    x_20        EDGE_20_85  1.0
    x_20        EDGE_20_39  1.0
    x_20        EDGE_20_48  1.0
    x_20        EDGE_20_75  1.0
    x_20        EDGE_20_34  1.0
    x_20        EDGE_20_43  1.0
    x_20        EDGE_20_61  1.0
    x_20        EDGE_20_32  1.0
    x_20        EDGE_7_20  1.0
    x_20        EDGE_18_20  1.0
    x_20        EDGE_10_20  1.0
    x_20        EDGE_20_79  1.0
    x_20        EDGE_20_88  1.0
    x_20        EDGE_2_20  1.0
    x_20        EDGE_20_65  1.0
    x_20        EDGE_20_83  1.0
    x_20        EDGE_20_92  1.0
    x_20        EDGE_20_60  1.0
    x_20        EDGE_20_96  1.0
    x_20        EDGE_20_64  1.0
    x_20        EDGE_20_73  1.0
    x_20        EDGE_20_82  1.0
    x_20        EDGE_16_20  1.0
    x_20        EDGE_6_20  1.0
    x_20        EDGE_20_22  1.0
    x_20        EDGE_8_20  1.0
    x_20        EDGE_20_25  1.0
    x_20        EDGE_1_20  1.0
    x_20        EDGE_3_20  1.0
    x_21        OBJ       -1
    x_21        EDGE_21_46  1.0
    x_21        EDGE_21_55  1.0
    x_21        EDGE_21_26  1.0
    x_21        EDGE_21_96  1.0
    x_21        EDGE_21_91  1.0
    x_21        EDGE_21_95  1.0
    x_21        EDGE_21_72  1.0
    x_21        EDGE_8_21  1.0
    x_21        EDGE_0_21  1.0
    x_21        EDGE_21_71  1.0
    x_21        EDGE_21_75  1.0
    x_21        EDGE_21_25  1.0
    x_21        EDGE_21_34  1.0
    x_21        EDGE_21_38  1.0
    x_21        EDGE_21_42  1.0
    x_21        EDGE_1_21  1.0
    x_21        EDGE_21_70  1.0
    x_21        EDGE_21_88  1.0
    x_21        EDGE_21_60  1.0
    x_22        OBJ       -1
    x_22        EDGE_2_22  1.0
    x_22        EDGE_22_60  1.0
    x_22        EDGE_22_91  1.0
    x_22        EDGE_22_77  1.0
    x_22        EDGE_0_22  1.0
    x_22        EDGE_22_49  1.0
    x_22        EDGE_14_22  1.0
    x_22        EDGE_22_90  1.0
    x_22        EDGE_20_22  1.0
    x_22        EDGE_22_71  1.0
    x_22        EDGE_22_98  1.0
    x_22        EDGE_22_66  1.0
    x_22        EDGE_15_22  1.0
    x_22        EDGE_22_33  1.0
    x_23        OBJ       -1
    x_23        EDGE_23_77  1.0
    x_23        EDGE_23_86  1.0
    x_23        EDGE_23_95  1.0
    x_23        EDGE_23_71  1.0
    x_23        EDGE_23_25  1.0
    x_23        EDGE_23_38  1.0
    x_23        EDGE_23_33  1.0
    x_23        EDGE_12_23  1.0
    x_23        EDGE_18_23  1.0
    x_23        EDGE_23_51  1.0
    x_23        EDGE_23_60  1.0
    x_23        EDGE_23_46  1.0
    x_23        EDGE_23_82  1.0
    x_23        EDGE_23_50  1.0
    x_23        EDGE_23_68  1.0
    x_23        EDGE_23_27  1.0
    x_23        EDGE_23_36  1.0
    x_23        EDGE_23_45  1.0
    x_23        EDGE_19_23  1.0
    x_24        OBJ       -1
    x_24        EDGE_24_97  1.0
    x_24        EDGE_14_24  1.0
    x_24        EDGE_24_60  1.0
    x_24        EDGE_24_82  1.0
    x_24        EDGE_24_63  1.0
    x_24        EDGE_24_31  1.0
    x_24        EDGE_24_49  1.0
    x_24        EDGE_12_24  1.0
    x_24        EDGE_24_25  1.0
    x_24        EDGE_4_24  1.0
    x_24        EDGE_24_72  1.0
    x_24        EDGE_24_90  1.0
    x_24        EDGE_24_85  1.0
    x_24        EDGE_24_94  1.0
    x_24        EDGE_24_39  1.0
    x_24        EDGE_13_24  1.0
    x_24        EDGE_24_51  1.0
    x_25        OBJ       -1
    x_25        EDGE_25_43  1.0
    x_25        EDGE_25_52  1.0
    x_25        EDGE_25_47  1.0
    x_25        EDGE_25_33  1.0
    x_25        EDGE_17_25  1.0
    x_25        EDGE_25_28  1.0
    x_25        EDGE_10_25  1.0
    x_25        EDGE_23_25  1.0
    x_25        EDGE_24_25  1.0
    x_25        EDGE_25_79  1.0
    x_25        EDGE_25_97  1.0
    x_25        EDGE_25_74  1.0
    x_25        EDGE_25_92  1.0
    x_25        EDGE_25_60  1.0
    x_25        EDGE_25_55  1.0
    x_25        EDGE_25_64  1.0
    x_25        EDGE_25_73  1.0
    x_25        EDGE_25_41  1.0
    x_25        EDGE_25_59  1.0
    x_25        EDGE_25_27  1.0
    x_25        EDGE_25_36  1.0
    x_25        EDGE_21_25  1.0
    x_25        EDGE_25_31  1.0
    x_25        EDGE_14_25  1.0
    x_25        EDGE_13_25  1.0
    x_25        EDGE_6_25  1.0
    x_25        EDGE_25_82  1.0
    x_25        EDGE_25_68  1.0
    x_25        EDGE_1_25  1.0
    x_25        EDGE_25_81  1.0
    x_25        EDGE_25_99  1.0
    x_25        EDGE_20_25  1.0
    x_25        EDGE_25_85  1.0
    x_25        EDGE_25_71  1.0
    x_25        EDGE_25_57  1.0
    x_25        EDGE_25_66  1.0
    x_26        OBJ       -1
    x_26        EDGE_7_26  1.0
    x_26        EDGE_26_30  1.0
    x_26        EDGE_2_26  1.0
    x_26        EDGE_26_95  1.0
    x_26        EDGE_21_26  1.0
    x_26        EDGE_8_26  1.0
    x_26        EDGE_19_26  1.0
    x_26        EDGE_26_33  1.0
    x_26        EDGE_26_42  1.0
    x_26        EDGE_26_46  1.0
    x_26        EDGE_3_26  1.0
    x_26        EDGE_6_26  1.0
    x_26        EDGE_26_69  1.0
    x_26        EDGE_26_87  1.0
    x_26        EDGE_26_73  1.0
    x_26        EDGE_26_68  1.0
    x_26        EDGE_4_26  1.0
    x_26        EDGE_26_35  1.0
    x_27        OBJ       -1
    x_27        EDGE_10_27  1.0
    x_27        EDGE_27_88  1.0
    x_27        EDGE_27_92  1.0
    x_27        EDGE_13_27  1.0
    x_27        EDGE_27_36  1.0
    x_27        EDGE_27_45  1.0
    x_27        EDGE_27_54  1.0
    x_27        EDGE_27_63  1.0
    x_27        EDGE_27_35  1.0
    x_27        EDGE_11_27  1.0
    x_27        EDGE_25_27  1.0
    x_27        EDGE_6_27  1.0
    x_27        EDGE_27_99  1.0
    x_27        EDGE_27_94  1.0
    x_27        EDGE_1_27  1.0
    x_27        EDGE_27_66  1.0
    x_27        EDGE_27_52  1.0
    x_27        EDGE_27_70  1.0
    x_27        EDGE_23_27  1.0
    x_27        EDGE_27_29  1.0
    x_27        EDGE_27_47  1.0
    x_27        EDGE_27_42  1.0
    x_27        EDGE_7_27  1.0
    x_27        EDGE_27_32  1.0
    x_28        OBJ       -1
    x_28        EDGE_28_58  1.0
    x_28        EDGE_28_80  1.0
    x_28        EDGE_28_66  1.0
    x_28        EDGE_25_28  1.0
    x_28        EDGE_28_29  1.0
    x_28        EDGE_28_33  1.0
    x_28        EDGE_28_42  1.0
    x_28        EDGE_28_84  1.0
    x_28        EDGE_28_79  1.0
    x_28        EDGE_28_74  1.0
    x_28        EDGE_28_92  1.0
    x_28        EDGE_7_28  1.0
    x_28        EDGE_18_28  1.0
    x_28        EDGE_28_69  1.0
    x_28        EDGE_28_78  1.0
    x_28        EDGE_28_46  1.0
    x_28        EDGE_28_73  1.0
    x_28        EDGE_28_82  1.0
    x_28        EDGE_28_32  1.0
    x_28        EDGE_28_50  1.0
    x_28        EDGE_2_28  1.0
    x_28        EDGE_28_40  1.0
    x_28        EDGE_28_30  1.0
    x_28        EDGE_8_28  1.0
    x_28        EDGE_19_28  1.0
    x_28        EDGE_28_86  1.0
    x_28        EDGE_28_90  1.0
    x_29        OBJ       -1
    x_29        EDGE_29_54  1.0
    x_29        EDGE_29_40  1.0
    x_29        EDGE_29_35  1.0
    x_29        EDGE_29_44  1.0
    x_29        EDGE_28_29  1.0
    x_29        EDGE_29_95  1.0
    x_29        EDGE_29_99  1.0
    x_29        EDGE_29_76  1.0
    x_29        EDGE_29_94  1.0
    x_29        EDGE_29_71  1.0
    x_29        EDGE_29_39  1.0
    x_29        EDGE_29_43  1.0
    x_29        EDGE_29_52  1.0
    x_29        EDGE_29_33  1.0
    x_29        EDGE_29_51  1.0
    x_29        EDGE_29_37  1.0
    x_29        EDGE_16_29  1.0
    x_29        EDGE_27_29  1.0
    x_29        EDGE_29_84  1.0
    x_29        EDGE_8_29  1.0
    x_29        EDGE_29_79  1.0
    x_29        EDGE_0_29  1.0
    x_30        OBJ       -1
    x_30        EDGE_15_30  1.0
    x_30        EDGE_26_30  1.0
    x_30        EDGE_7_30  1.0
    x_30        EDGE_30_98  1.0
    x_30        EDGE_30_88  1.0
    x_30        EDGE_30_65  1.0
    x_30        EDGE_30_74  1.0
    x_30        EDGE_30_92  1.0
    x_30        EDGE_30_60  1.0
    x_30        EDGE_30_46  1.0
    x_30        EDGE_30_50  1.0
    x_30        EDGE_30_63  1.0
    x_30        EDGE_30_31  1.0
    x_30        EDGE_8_30  1.0
    x_30        EDGE_11_30  1.0
    x_30        EDGE_14_30  1.0
    x_30        EDGE_30_72  1.0
    x_30        EDGE_30_99  1.0
    x_30        EDGE_6_30  1.0
    x_30        EDGE_30_85  1.0
    x_30        EDGE_28_30  1.0
    x_30        EDGE_30_39  1.0
    x_30        EDGE_0_30  1.0
    x_30        EDGE_30_52  1.0
    x_30        EDGE_30_70  1.0
    x_30        EDGE_30_37  1.0
    x_31        OBJ       -1
    x_31        EDGE_31_95  1.0
    x_31        EDGE_31_72  1.0
    x_31        EDGE_31_76  1.0
    x_31        EDGE_31_94  1.0
    x_31        EDGE_31_43  1.0
    x_31        EDGE_13_31  1.0
    x_31        EDGE_24_31  1.0
    x_31        EDGE_31_56  1.0
    x_31        EDGE_8_31  1.0
    x_31        EDGE_19_31  1.0
    x_31        EDGE_30_31  1.0
    x_31        EDGE_25_31  1.0
    x_31        EDGE_31_69  1.0
    x_31        EDGE_31_78  1.0
    x_31        EDGE_31_87  1.0
    x_31        EDGE_31_55  1.0
    x_31        EDGE_31_82  1.0
    x_31        EDGE_31_41  1.0
    x_31        EDGE_31_36  1.0
    x_31        EDGE_31_54  1.0
    x_31        EDGE_31_63  1.0
    x_31        EDGE_31_49  1.0
    x_31        EDGE_31_44  1.0
    x_32        OBJ       -1
    x_32        EDGE_32_69  1.0
    x_32        EDGE_32_87  1.0
    x_32        EDGE_32_41  1.0
    x_32        EDGE_14_32  1.0
    x_32        EDGE_32_68  1.0
    x_32        EDGE_32_45  1.0
    x_32        EDGE_32_63  1.0
    x_32        EDGE_32_58  1.0
    x_32        EDGE_32_39  1.0
    x_32        EDGE_0_32  1.0
    x_32        EDGE_20_32  1.0
    x_32        EDGE_3_32  1.0
    x_32        EDGE_32_76  1.0
    x_32        EDGE_32_85  1.0
    x_32        EDGE_32_53  1.0
    x_32        EDGE_32_57  1.0
    x_32        EDGE_28_32  1.0
    x_32        EDGE_10_32  1.0
    x_32        EDGE_32_56  1.0
    x_32        EDGE_32_33  1.0
    x_32        EDGE_32_42  1.0
    x_32        EDGE_32_51  1.0
    x_32        EDGE_27_32  1.0
    x_32        EDGE_32_83  1.0
    x_33        OBJ       -1
    x_33        EDGE_33_47  1.0
    x_33        EDGE_14_33  1.0
    x_33        EDGE_25_33  1.0
    x_33        EDGE_17_33  1.0
    x_33        EDGE_28_33  1.0
    x_33        EDGE_12_33  1.0
    x_33        EDGE_23_33  1.0
    x_33        EDGE_33_74  1.0
    x_33        EDGE_33_87  1.0
    x_33        EDGE_33_73  1.0
    x_33        EDGE_26_33  1.0
    x_33        EDGE_33_68  1.0
    x_33        EDGE_18_33  1.0
    x_33        EDGE_33_45  1.0
    x_33        EDGE_10_33  1.0
    x_33        EDGE_33_35  1.0
    x_33        EDGE_29_33  1.0
    x_33        EDGE_32_33  1.0
    x_33        EDGE_33_96  1.0
    x_33        EDGE_33_77  1.0
    x_33        EDGE_33_99  1.0
    x_33        EDGE_33_67  1.0
    x_33        EDGE_33_76  1.0
    x_33        EDGE_33_94  1.0
    x_33        EDGE_19_33  1.0
    x_33        EDGE_33_71  1.0
    x_33        EDGE_33_89  1.0
    x_33        EDGE_33_39  1.0
    x_33        EDGE_33_43  1.0
    x_33        EDGE_22_33  1.0
    x_34        OBJ       -1
    x_34        EDGE_17_34  1.0
    x_34        EDGE_20_34  1.0
    x_34        EDGE_34_81  1.0
    x_34        EDGE_34_90  1.0
    x_34        EDGE_12_34  1.0
    x_34        EDGE_34_58  1.0
    x_34        EDGE_34_67  1.0
    x_34        EDGE_34_71  1.0
    x_34        EDGE_34_52  1.0
    x_34        EDGE_34_42  1.0
    x_34        EDGE_2_34  1.0
    x_34        EDGE_21_34  1.0
    x_34        EDGE_5_34  1.0
    x_34        EDGE_34_93  1.0
    x_34        EDGE_34_79  1.0
    x_34        EDGE_34_78  1.0
    x_34        EDGE_34_55  1.0
    x_34        EDGE_34_64  1.0
    x_34        EDGE_34_41  1.0
    x_34        EDGE_34_50  1.0
    x_34        EDGE_34_59  1.0
    x_34        EDGE_34_54  1.0
    x_34        EDGE_34_40  1.0
    x_34        EDGE_14_34  1.0
    x_34        EDGE_34_44  1.0
    x_35        OBJ       -1
    x_35        EDGE_35_60  1.0
    x_35        EDGE_35_78  1.0
    x_35        EDGE_10_35  1.0
    x_35        EDGE_29_35  1.0
    x_35        EDGE_2_35  1.0
    x_35        EDGE_35_50  1.0
    x_35        EDGE_35_59  1.0
    x_35        EDGE_35_77  1.0
    x_35        EDGE_5_35  1.0
    x_35        EDGE_27_35  1.0
    x_35        EDGE_11_35  1.0
    x_35        EDGE_35_67  1.0
    x_35        EDGE_35_85  1.0
    x_35        EDGE_33_35  1.0
    x_35        EDGE_35_62  1.0
    x_35        EDGE_35_71  1.0
    x_35        EDGE_35_39  1.0
    x_35        EDGE_35_48  1.0
    x_35        EDGE_35_57  1.0
    x_35        EDGE_35_75  1.0
    x_35        EDGE_17_35  1.0
    x_35        EDGE_4_35  1.0
    x_35        EDGE_35_98  1.0
    x_35        EDGE_35_84  1.0
    x_35        EDGE_26_35  1.0
    x_36        OBJ       -1
    x_36        EDGE_36_62  1.0
    x_36        EDGE_2_36  1.0
    x_36        EDGE_36_43  1.0
    x_36        EDGE_36_38  1.0
    x_36        EDGE_36_47  1.0
    x_36        EDGE_13_36  1.0
    x_36        EDGE_27_36  1.0
    x_36        EDGE_8_36  1.0
    x_36        EDGE_0_36  1.0
    x_36        EDGE_36_97  1.0
    x_36        EDGE_36_83  1.0
    x_36        EDGE_36_46  1.0
    x_36        EDGE_25_36  1.0
    x_36        EDGE_36_77  1.0
    x_36        EDGE_6_36  1.0
    x_36        EDGE_36_45  1.0
    x_36        EDGE_36_40  1.0
    x_36        EDGE_36_44  1.0
    x_36        EDGE_9_36  1.0
    x_36        EDGE_1_36  1.0
    x_36        EDGE_31_36  1.0
    x_36        EDGE_12_36  1.0
    x_36        EDGE_23_36  1.0
    x_36        EDGE_4_36  1.0
    x_36        EDGE_36_72  1.0
    x_36        EDGE_36_67  1.0
    x_36        EDGE_36_94  1.0
    x_37        OBJ       -1
    x_37        EDGE_37_95  1.0
    x_37        EDGE_37_90  1.0
    x_37        EDGE_37_58  1.0
    x_37        EDGE_37_80  1.0
    x_37        EDGE_37_57  1.0
    x_37        EDGE_37_38  1.0
    x_37        EDGE_29_37  1.0
    x_37        EDGE_37_89  1.0
    x_37        EDGE_4_37  1.0
    x_37        EDGE_37_88  1.0
    x_37        EDGE_5_37  1.0
    x_37        EDGE_37_83  1.0
    x_37        EDGE_37_55  1.0
    x_37        EDGE_37_64  1.0
    x_37        EDGE_37_59  1.0
    x_37        EDGE_30_37  1.0
    x_38        OBJ       -1
    x_38        EDGE_38_89  1.0
    x_38        EDGE_36_38  1.0
    x_38        EDGE_38_93  1.0
    x_38        EDGE_38_79  1.0
    x_38        EDGE_9_38  1.0
    x_38        EDGE_38_74  1.0
    x_38        EDGE_38_83  1.0
    x_38        EDGE_38_92  1.0
    x_38        EDGE_38_60  1.0
    x_38        EDGE_38_69  1.0
    x_38        EDGE_23_38  1.0
    x_38        EDGE_7_38  1.0
    x_38        EDGE_37_38  1.0
    x_38        EDGE_38_91  1.0
    x_38        EDGE_21_38  1.0
    x_38        EDGE_16_38  1.0
    x_38        EDGE_38_48  1.0
    x_38        EDGE_38_56  1.0
    x_38        EDGE_38_42  1.0
    x_38        EDGE_3_38  1.0
    x_39        OBJ       -1
    x_39        EDGE_39_66  1.0
    x_39        EDGE_39_75  1.0
    x_39        EDGE_20_39  1.0
    x_39        EDGE_39_61  1.0
    x_39        EDGE_39_79  1.0
    x_39        EDGE_39_65  1.0
    x_39        EDGE_32_39  1.0
    x_39        EDGE_39_46  1.0
    x_39        EDGE_7_39  1.0
    x_39        EDGE_29_39  1.0
    x_39        EDGE_39_97  1.0
    x_39        EDGE_39_69  1.0
    x_39        EDGE_39_78  1.0
    x_39        EDGE_39_73  1.0
    x_39        EDGE_24_39  1.0
    x_39        EDGE_35_39  1.0
    x_39        EDGE_39_45  1.0
    x_39        EDGE_30_39  1.0
    x_39        EDGE_11_39  1.0
    x_39        EDGE_1_39  1.0
    x_39        EDGE_33_39  1.0
    x_40        OBJ       -1
    x_40        EDGE_40_50  1.0
    x_40        EDGE_40_63  1.0
    x_40        EDGE_10_40  1.0
    x_40        EDGE_29_40  1.0
    x_40        EDGE_19_40  1.0
    x_40        EDGE_40_76  1.0
    x_40        EDGE_40_94  1.0
    x_40        EDGE_40_71  1.0
    x_40        EDGE_40_75  1.0
    x_40        EDGE_40_52  1.0
    x_40        EDGE_40_61  1.0
    x_40        EDGE_40_47  1.0
    x_40        EDGE_40_42  1.0
    x_40        EDGE_36_40  1.0
    x_40        EDGE_28_40  1.0
    x_40        EDGE_40_98  1.0
    x_40        EDGE_12_40  1.0
    x_40        EDGE_40_65  1.0
    x_40        EDGE_40_74  1.0
    x_40        EDGE_40_92  1.0
    x_40        EDGE_15_40  1.0
    x_40        EDGE_40_78  1.0
    x_40        EDGE_40_87  1.0
    x_40        EDGE_34_40  1.0
    x_40        EDGE_40_55  1.0
    x_40        EDGE_40_73  1.0
    x_41        OBJ       -1
    x_41        EDGE_41_51  1.0
    x_41        EDGE_2_41  1.0
    x_41        EDGE_32_41  1.0
    x_41        EDGE_5_41  1.0
    x_41        EDGE_13_41  1.0
    x_41        EDGE_41_98  1.0
    x_41        EDGE_41_93  1.0
    x_41        EDGE_41_79  1.0
    x_41        EDGE_8_41  1.0
    x_41        EDGE_19_41  1.0
    x_41        EDGE_41_83  1.0
    x_41        EDGE_41_92  1.0
    x_41        EDGE_41_82  1.0
    x_41        EDGE_41_59  1.0
    x_41        EDGE_41_68  1.0
    x_41        EDGE_3_41  1.0
    x_41        EDGE_14_41  1.0
    x_41        EDGE_41_54  1.0
    x_41        EDGE_25_41  1.0
    x_41        EDGE_31_41  1.0
    x_41        EDGE_41_91  1.0
    x_41        EDGE_41_72  1.0
    x_41        EDGE_41_53  1.0
    x_41        EDGE_34_41  1.0
    x_41        EDGE_41_48  1.0
    x_41        EDGE_41_75  1.0
    x_41        EDGE_41_43  1.0
    x_41        EDGE_41_52  1.0
    x_41        EDGE_41_47  1.0
    x_41        EDGE_41_65  1.0
    x_42        OBJ       -1
    x_42        EDGE_42_82  1.0
    x_42        EDGE_42_86  1.0
    x_42        EDGE_42_95  1.0
    x_42        EDGE_42_72  1.0
    x_42        EDGE_42_67  1.0
    x_42        EDGE_42_85  1.0
    x_42        EDGE_17_42  1.0
    x_42        EDGE_28_42  1.0
    x_42        EDGE_42_80  1.0
    x_42        EDGE_42_57  1.0
    x_42        EDGE_42_66  1.0
    x_42        EDGE_42_75  1.0
    x_42        EDGE_1_42  1.0
    x_42        EDGE_42_43  1.0
    x_42        EDGE_12_42  1.0
    x_42        EDGE_15_42  1.0
    x_42        EDGE_26_42  1.0
    x_42        EDGE_34_42  1.0
    x_42        EDGE_7_42  1.0
    x_42        EDGE_42_84  1.0
    x_42        EDGE_42_93  1.0
    x_42        EDGE_10_42  1.0
    x_42        EDGE_40_42  1.0
    x_42        EDGE_42_70  1.0
    x_42        EDGE_21_42  1.0
    x_42        EDGE_42_74  1.0
    x_42        EDGE_42_92  1.0
    x_42        EDGE_42_69  1.0
    x_42        EDGE_4_42  1.0
    x_42        EDGE_32_42  1.0
    x_42        EDGE_42_54  1.0
    x_42        EDGE_27_42  1.0
    x_42        EDGE_38_42  1.0
    x_42        EDGE_11_42  1.0
    x_43        OBJ       -1
    x_43        EDGE_25_43  1.0
    x_43        EDGE_43_60  1.0
    x_43        EDGE_43_82  1.0
    x_43        EDGE_36_43  1.0
    x_43        EDGE_43_91  1.0
    x_43        EDGE_17_43  1.0
    x_43        EDGE_43_63  1.0
    x_43        EDGE_9_43  1.0
    x_43        EDGE_20_43  1.0
    x_43        EDGE_31_43  1.0
    x_43        EDGE_43_44  1.0
    x_43        EDGE_42_43  1.0
    x_43        EDGE_15_43  1.0
    x_43        EDGE_43_86  1.0
    x_43        EDGE_43_90  1.0
    x_43        EDGE_43_85  1.0
    x_43        EDGE_29_43  1.0
    x_43        EDGE_43_48  1.0
    x_43        EDGE_43_57  1.0
    x_43        EDGE_43_84  1.0
    x_43        EDGE_43_52  1.0
    x_43        EDGE_13_43  1.0
    x_43        EDGE_41_43  1.0
    x_43        EDGE_33_43  1.0
    x_43        EDGE_43_92  1.0
    x_44        OBJ       -1
    x_44        EDGE_10_44  1.0
    x_44        EDGE_29_44  1.0
    x_44        EDGE_43_44  1.0
    x_44        EDGE_5_44  1.0
    x_44        EDGE_44_93  1.0
    x_44        EDGE_13_44  1.0
    x_44        EDGE_44_79  1.0
    x_44        EDGE_44_69  1.0
    x_44        EDGE_44_55  1.0
    x_44        EDGE_44_82  1.0
    x_44        EDGE_44_45  1.0
    x_44        EDGE_44_54  1.0
    x_44        EDGE_3_44  1.0
    x_44        EDGE_36_44  1.0
    x_44        EDGE_31_44  1.0
    x_44        EDGE_44_90  1.0
    x_44        EDGE_44_58  1.0
    x_44        EDGE_44_85  1.0
    x_44        EDGE_44_94  1.0
    x_44        EDGE_44_57  1.0
    x_44        EDGE_44_52  1.0
    x_44        EDGE_44_70  1.0
    x_44        EDGE_34_44  1.0
    x_45        OBJ       -1
    x_45        EDGE_32_45  1.0
    x_45        EDGE_5_45  1.0
    x_45        EDGE_13_45  1.0
    x_45        EDGE_45_72  1.0
    x_45        EDGE_27_45  1.0
    x_45        EDGE_45_89  1.0
    x_45        EDGE_19_45  1.0
    x_45        EDGE_45_48  1.0
    x_45        EDGE_45_61  1.0
    x_45        EDGE_14_45  1.0
    x_45        EDGE_33_45  1.0
    x_45        EDGE_44_45  1.0
    x_45        EDGE_36_45  1.0
    x_45        EDGE_45_98  1.0
    x_45        EDGE_17_45  1.0
    x_45        EDGE_39_45  1.0
    x_45        EDGE_45_83  1.0
    x_45        EDGE_23_45  1.0
    x_45        EDGE_45_60  1.0
    x_45        EDGE_45_69  1.0
    x_45        EDGE_45_46  1.0
    x_45        EDGE_45_64  1.0
    x_45        EDGE_7_45  1.0
    x_45        EDGE_45_58  1.0
    x_46        OBJ       -1
    x_46        EDGE_21_46  1.0
    x_46        EDGE_46_98  1.0
    x_46        EDGE_46_83  1.0
    x_46        EDGE_30_46  1.0
    x_46        EDGE_0_46  1.0
    x_46        EDGE_39_46  1.0
    x_46        EDGE_1_46  1.0
    x_46        EDGE_3_46  1.0
    x_46        EDGE_26_46  1.0
    x_46        EDGE_36_46  1.0
    x_46        EDGE_28_46  1.0
    x_46        EDGE_46_91  1.0
    x_46        EDGE_9_46  1.0
    x_46        EDGE_46_72  1.0
    x_46        EDGE_46_85  1.0
    x_46        EDGE_46_94  1.0
    x_46        EDGE_23_46  1.0
    x_46        EDGE_46_53  1.0
    x_46        EDGE_46_80  1.0
    x_46        EDGE_46_89  1.0
    x_46        EDGE_46_61  1.0
    x_46        EDGE_45_46  1.0
    x_46        EDGE_46_56  1.0
    x_47        OBJ       -1
    x_47        EDGE_33_47  1.0
    x_47        EDGE_47_66  1.0
    x_47        EDGE_47_75  1.0
    x_47        EDGE_25_47  1.0
    x_47        EDGE_47_52  1.0
    x_47        EDGE_6_47  1.0
    x_47        EDGE_36_47  1.0
    x_47        EDGE_47_93  1.0
    x_47        EDGE_47_79  1.0
    x_47        EDGE_47_97  1.0
    x_47        EDGE_47_92  1.0
    x_47        EDGE_47_69  1.0
    x_47        EDGE_47_55  1.0
    x_47        EDGE_47_91  1.0
    x_47        EDGE_10_47  1.0
    x_47        EDGE_40_47  1.0
    x_47        EDGE_47_72  1.0
    x_47        EDGE_5_47  1.0
    x_47        EDGE_27_47  1.0
    x_47        EDGE_47_95  1.0
    x_47        EDGE_47_85  1.0
    x_47        EDGE_41_47  1.0
    x_48        OBJ       -1
    x_48        EDGE_20_48  1.0
    x_48        EDGE_15_48  1.0
    x_48        EDGE_48_90  1.0
    x_48        EDGE_45_48  1.0
    x_48        EDGE_18_48  1.0
    x_48        EDGE_48_85  1.0
    x_48        EDGE_48_94  1.0
    x_48        EDGE_10_48  1.0
    x_48        EDGE_48_52  1.0
    x_48        EDGE_43_48  1.0
    x_48        EDGE_5_48  1.0
    x_48        EDGE_13_48  1.0
    x_48        EDGE_35_48  1.0
    x_48        EDGE_48_93  1.0
    x_48        EDGE_38_48  1.0
    x_48        EDGE_48_97  1.0
    x_48        EDGE_48_60  1.0
    x_48        EDGE_48_87  1.0
    x_48        EDGE_41_48  1.0
    x_48        EDGE_48_64  1.0
    x_48        EDGE_48_82  1.0
    x_48        EDGE_48_68  1.0
    x_49        OBJ       -1
    x_49        EDGE_49_98  1.0
    x_49        EDGE_49_93  1.0
    x_49        EDGE_49_74  1.0
    x_49        EDGE_49_83  1.0
    x_49        EDGE_24_49  1.0
    x_49        EDGE_49_51  1.0
    x_49        EDGE_49_60  1.0
    x_49        EDGE_49_78  1.0
    x_49        EDGE_49_55  1.0
    x_49        EDGE_49_54  1.0
    x_49        EDGE_49_63  1.0
    x_49        EDGE_11_49  1.0
    x_49        EDGE_22_49  1.0
    x_49        EDGE_49_86  1.0
    x_49        EDGE_49_58  1.0
    x_49        EDGE_49_89  1.0
    x_49        EDGE_31_49  1.0
    x_49        EDGE_49_70  1.0
    x_49        EDGE_7_49  1.0
    x_50        OBJ       -1
    x_50        EDGE_40_50  1.0
    x_50        EDGE_50_86  1.0
    x_50        EDGE_50_72  1.0
    x_50        EDGE_5_50  1.0
    x_50        EDGE_50_76  1.0
    x_50        EDGE_13_50  1.0
    x_50        EDGE_35_50  1.0
    x_50        EDGE_50_57  1.0
    x_50        EDGE_50_75  1.0
    x_50        EDGE_50_70  1.0
    x_50        EDGE_30_50  1.0
    x_50        EDGE_50_51  1.0
    x_50        EDGE_50_93  1.0
    x_50        EDGE_28_50  1.0
    x_50        EDGE_50_65  1.0
    x_50        EDGE_50_78  1.0
    x_50        EDGE_50_64  1.0
    x_50        EDGE_50_82  1.0
    x_50        EDGE_50_77  1.0
    x_50        EDGE_23_50  1.0
    x_50        EDGE_34_50  1.0
    x_50        EDGE_18_50  1.0
    x_51        OBJ       -1
    x_51        EDGE_41_51  1.0
    x_51        EDGE_51_73  1.0
    x_51        EDGE_51_86  1.0
    x_51        EDGE_51_72  1.0
    x_51        EDGE_16_51  1.0
    x_51        EDGE_6_51  1.0
    x_51        EDGE_49_51  1.0
    x_51        EDGE_1_51  1.0
    x_51        EDGE_50_51  1.0
    x_51        EDGE_51_95  1.0
    x_51        EDGE_51_90  1.0
    x_51        EDGE_15_51  1.0
    x_51        EDGE_51_76  1.0
    x_51        EDGE_51_80  1.0
    x_51        EDGE_51_66  1.0
    x_51        EDGE_9_51  1.0
    x_51        EDGE_10_51  1.0
    x_51        EDGE_51_70  1.0
    x_51        EDGE_29_51  1.0
    x_51        EDGE_51_65  1.0
    x_51        EDGE_51_74  1.0
    x_51        EDGE_23_51  1.0
    x_51        EDGE_32_51  1.0
    x_51        EDGE_24_51  1.0
    x_51        EDGE_19_51  1.0
    x_51        EDGE_51_88  1.0
    x_51        EDGE_51_97  1.0
    x_51        EDGE_51_87  1.0
    x_52        OBJ       -1
    x_52        EDGE_25_52  1.0
    x_52        EDGE_47_52  1.0
    x_52        EDGE_9_52  1.0
    x_52        EDGE_52_93  1.0
    x_52        EDGE_52_60  1.0
    x_52        EDGE_52_96  1.0
    x_52        EDGE_52_55  1.0
    x_52        EDGE_34_52  1.0
    x_52        EDGE_52_72  1.0
    x_52        EDGE_48_52  1.0
    x_52        EDGE_10_52  1.0
    x_52        EDGE_29_52  1.0
    x_52        EDGE_40_52  1.0
    x_52        EDGE_43_52  1.0
    x_52        EDGE_16_52  1.0
    x_52        EDGE_52_95  1.0
    x_52        EDGE_27_52  1.0
    x_52        EDGE_30_52  1.0
    x_52        EDGE_52_67  1.0
    x_52        EDGE_52_76  1.0
    x_52        EDGE_11_52  1.0
    x_52        EDGE_52_57  1.0
    x_52        EDGE_52_66  1.0
    x_52        EDGE_52_84  1.0
    x_52        EDGE_41_52  1.0
    x_52        EDGE_3_52  1.0
    x_52        EDGE_52_56  1.0
    x_52        EDGE_44_52  1.0
    x_53        OBJ       -1
    x_53        EDGE_17_53  1.0
    x_53        EDGE_9_53  1.0
    x_53        EDGE_1_53  1.0
    x_53        EDGE_53_81  1.0
    x_53        EDGE_53_99  1.0
    x_53        EDGE_53_67  1.0
    x_53        EDGE_53_85  1.0
    x_53        EDGE_53_62  1.0
    x_53        EDGE_53_70  1.0
    x_53        EDGE_53_56  1.0
    x_53        EDGE_32_53  1.0
    x_53        EDGE_5_53  1.0
    x_53        EDGE_53_93  1.0
    x_53        EDGE_53_97  1.0
    x_53        EDGE_46_53  1.0
    x_53        EDGE_8_53  1.0
    x_53        EDGE_53_78  1.0
    x_53        EDGE_11_53  1.0
    x_53        EDGE_53_55  1.0
    x_53        EDGE_53_91  1.0
    x_53        EDGE_53_59  1.0
    x_53        EDGE_41_53  1.0
    x_53        EDGE_53_54  1.0
    x_54        OBJ       -1
    x_54        EDGE_54_79  1.0
    x_54        EDGE_29_54  1.0
    x_54        EDGE_54_60  1.0
    x_54        EDGE_54_64  1.0
    x_54        EDGE_54_63  1.0
    x_54        EDGE_16_54  1.0
    x_54        EDGE_27_54  1.0
    x_54        EDGE_49_54  1.0
    x_54        EDGE_41_54  1.0
    x_54        EDGE_54_91  1.0
    x_54        EDGE_3_54  1.0
    x_54        EDGE_44_54  1.0
    x_54        EDGE_54_67  1.0
    x_54        EDGE_1_54  1.0
    x_54        EDGE_31_54  1.0
    x_54        EDGE_42_54  1.0
    x_54        EDGE_54_58  1.0
    x_54        EDGE_53_54  1.0
    x_54        EDGE_34_54  1.0
    x_54        EDGE_54_98  1.0
    x_54        EDGE_54_93  1.0
    x_55        OBJ       -1
    x_55        EDGE_55_57  1.0
    x_55        EDGE_55_84  1.0
    x_55        EDGE_55_93  1.0
    x_55        EDGE_21_55  1.0
    x_55        EDGE_55_79  1.0
    x_55        EDGE_5_55  1.0
    x_55        EDGE_8_55  1.0
    x_55        EDGE_49_55  1.0
    x_55        EDGE_55_88  1.0
    x_55        EDGE_52_55  1.0
    x_55        EDGE_3_55  1.0
    x_55        EDGE_14_55  1.0
    x_55        EDGE_44_55  1.0
    x_55        EDGE_25_55  1.0
    x_55        EDGE_55_91  1.0
    x_55        EDGE_55_59  1.0
    x_55        EDGE_47_55  1.0
    x_55        EDGE_55_68  1.0
    x_55        EDGE_55_77  1.0
    x_55        EDGE_55_72  1.0
    x_55        EDGE_17_55  1.0
    x_55        EDGE_1_55  1.0
    x_55        EDGE_31_55  1.0
    x_55        EDGE_53_55  1.0
    x_55        EDGE_15_55  1.0
    x_55        EDGE_34_55  1.0
    x_55        EDGE_37_55  1.0
    x_55        EDGE_55_62  1.0
    x_55        EDGE_55_98  1.0
    x_55        EDGE_40_55  1.0
    x_56        OBJ       -1
    x_56        EDGE_16_56  1.0
    x_56        EDGE_1_56  1.0
    x_56        EDGE_31_56  1.0
    x_56        EDGE_56_80  1.0
    x_56        EDGE_56_66  1.0
    x_56        EDGE_56_84  1.0
    x_56        EDGE_53_56  1.0
    x_56        EDGE_56_70  1.0
    x_56        EDGE_7_56  1.0
    x_56        EDGE_18_56  1.0
    x_56        EDGE_9_56  1.0
    x_56        EDGE_32_56  1.0
    x_56        EDGE_56_93  1.0
    x_56        EDGE_56_88  1.0
    x_56        EDGE_56_74  1.0
    x_56        EDGE_56_69  1.0
    x_56        EDGE_56_78  1.0
    x_56        EDGE_56_96  1.0
    x_56        EDGE_56_64  1.0
    x_56        EDGE_46_56  1.0
    x_56        EDGE_56_59  1.0
    x_56        EDGE_56_77  1.0
    x_56        EDGE_38_56  1.0
    x_56        EDGE_52_56  1.0
    x_57        OBJ       -1
    x_57        EDGE_55_57  1.0
    x_57        EDGE_6_57  1.0
    x_57        EDGE_57_98  1.0
    x_57        EDGE_1_57  1.0
    x_57        EDGE_57_83  1.0
    x_57        EDGE_57_87  1.0
    x_57        EDGE_57_96  1.0
    x_57        EDGE_50_57  1.0
    x_57        EDGE_42_57  1.0
    x_57        EDGE_57_59  1.0
    x_57        EDGE_57_77  1.0
    x_57        EDGE_15_57  1.0
    x_57        EDGE_57_58  1.0
    x_57        EDGE_7_57  1.0
    x_57        EDGE_18_57  1.0
    x_57        EDGE_37_57  1.0
    x_57        EDGE_2_57  1.0
    x_57        EDGE_32_57  1.0
    x_57        EDGE_43_57  1.0
    x_57        EDGE_13_57  1.0
    x_57        EDGE_35_57  1.0
    x_57        EDGE_57_85  1.0
    x_57        EDGE_57_94  1.0
    x_57        EDGE_57_75  1.0
    x_57        EDGE_8_57  1.0
    x_57        EDGE_57_70  1.0
    x_57        EDGE_52_57  1.0
    x_57        EDGE_14_57  1.0
    x_57        EDGE_44_57  1.0
    x_57        EDGE_25_57  1.0
    x_58        OBJ       -1
    x_58        EDGE_28_58  1.0
    x_58        EDGE_10_58  1.0
    x_58        EDGE_58_94  1.0
    x_58        EDGE_58_89  1.0
    x_58        EDGE_12_58  1.0
    x_58        EDGE_58_75  1.0
    x_58        EDGE_32_58  1.0
    x_58        EDGE_5_58  1.0
    x_58        EDGE_58_61  1.0
    x_58        EDGE_58_70  1.0
    x_58        EDGE_58_79  1.0
    x_58        EDGE_34_58  1.0
    x_58        EDGE_37_58  1.0
    x_58        EDGE_57_58  1.0
    x_58        EDGE_58_88  1.0
    x_58        EDGE_58_97  1.0
    x_58        EDGE_13_58  1.0
    x_58        EDGE_58_74  1.0
    x_58        EDGE_58_64  1.0
    x_58        EDGE_58_91  1.0
    x_58        EDGE_58_59  1.0
    x_58        EDGE_49_58  1.0
    x_58        EDGE_14_58  1.0
    x_58        EDGE_44_58  1.0
    x_58        EDGE_54_58  1.0
    x_58        EDGE_15_58  1.0
    x_58        EDGE_45_58  1.0
    x_59        OBJ       -1
    x_59        EDGE_59_73  1.0
    x_59        EDGE_59_68  1.0
    x_59        EDGE_35_59  1.0
    x_59        EDGE_57_59  1.0
    x_59        EDGE_59_81  1.0
    x_59        EDGE_41_59  1.0
    x_59        EDGE_14_59  1.0
    x_59        EDGE_25_59  1.0
    x_59        EDGE_55_59  1.0
    x_59        EDGE_58_59  1.0
    x_59        EDGE_53_59  1.0
    x_59        EDGE_59_93  1.0
    x_59        EDGE_34_59  1.0
    x_59        EDGE_56_59  1.0
    x_59        EDGE_59_88  1.0
    x_59        EDGE_7_59  1.0
    x_59        EDGE_59_97  1.0
    x_59        EDGE_37_59  1.0
    x_59        EDGE_59_83  1.0
    x_60        OBJ       -1
    x_60        EDGE_43_60  1.0
    x_60        EDGE_5_60  1.0
    x_60        EDGE_13_60  1.0
    x_60        EDGE_24_60  1.0
    x_60        EDGE_35_60  1.0
    x_60        EDGE_54_60  1.0
    x_60        EDGE_30_60  1.0
    x_60        EDGE_38_60  1.0
    x_60        EDGE_49_60  1.0
    x_60        EDGE_60_78  1.0
    x_60        EDGE_60_96  1.0
    x_60        EDGE_22_60  1.0
    x_60        EDGE_52_60  1.0
    x_60        EDGE_60_82  1.0
    x_60        EDGE_60_86  1.0
    x_60        EDGE_25_60  1.0
    x_60        EDGE_20_60  1.0
    x_60        EDGE_23_60  1.0
    x_60        EDGE_45_60  1.0
    x_60        EDGE_7_60  1.0
    x_60        EDGE_60_66  1.0
    x_60        EDGE_60_84  1.0
    x_60        EDGE_48_60  1.0
    x_60        EDGE_10_60  1.0
    x_60        EDGE_21_60  1.0
    x_61        OBJ       -1
    x_61        EDGE_61_91  1.0
    x_61        EDGE_61_81  1.0
    x_61        EDGE_61_76  1.0
    x_61        EDGE_61_94  1.0
    x_61        EDGE_61_62  1.0
    x_61        EDGE_61_80  1.0
    x_61        EDGE_39_61  1.0
    x_61        EDGE_58_61  1.0
    x_61        EDGE_61_84  1.0
    x_61        EDGE_20_61  1.0
    x_61        EDGE_45_61  1.0
    x_61        EDGE_10_61  1.0
    x_61        EDGE_40_61  1.0
    x_61        EDGE_61_97  1.0
    x_61        EDGE_61_92  1.0
    x_61        EDGE_5_61  1.0
    x_61        EDGE_61_69  1.0
    x_61        EDGE_13_61  1.0
    x_61        EDGE_61_82  1.0
    x_61        EDGE_16_61  1.0
    x_61        EDGE_61_63  1.0
    x_61        EDGE_46_61  1.0
    x_61        EDGE_11_61  1.0
    x_62        OBJ       -1
    x_62        EDGE_36_62  1.0
    x_62        EDGE_61_62  1.0
    x_62        EDGE_62_63  1.0
    x_62        EDGE_12_62  1.0
    x_62        EDGE_53_62  1.0
    x_62        EDGE_15_62  1.0
    x_62        EDGE_10_62  1.0
    x_62        EDGE_62_81  1.0
    x_62        EDGE_62_76  1.0
    x_62        EDGE_62_94  1.0
    x_62        EDGE_62_70  1.0
    x_62        EDGE_35_62  1.0
    x_62        EDGE_62_66  1.0
    x_62        EDGE_62_65  1.0
    x_62        EDGE_11_62  1.0
    x_62        EDGE_62_98  1.0
    x_62        EDGE_62_93  1.0
    x_62        EDGE_55_62  1.0
    x_63        OBJ       -1
    x_63        EDGE_40_63  1.0
    x_63        EDGE_32_63  1.0
    x_63        EDGE_43_63  1.0
    x_63        EDGE_62_63  1.0
    x_63        EDGE_13_63  1.0
    x_63        EDGE_24_63  1.0
    x_63        EDGE_54_63  1.0
    x_63        EDGE_27_63  1.0
    x_63        EDGE_63_93  1.0
    x_63        EDGE_30_63  1.0
    x_63        EDGE_49_63  1.0
    x_63        EDGE_63_74  1.0
    x_63        EDGE_63_83  1.0
    x_63        EDGE_63_78  1.0
    x_63        EDGE_63_87  1.0
    x_63        EDGE_63_68  1.0
    x_63        EDGE_0_63  1.0
    x_63        EDGE_1_63  1.0
    x_63        EDGE_31_63  1.0
    x_63        EDGE_61_63  1.0
    x_63        EDGE_63_91  1.0
    x_63        EDGE_63_77  1.0
    x_63        EDGE_63_95  1.0
    x_63        EDGE_63_90  1.0
    x_63        EDGE_63_99  1.0
    x_63        EDGE_63_67  1.0
    x_63        EDGE_63_76  1.0
    x_63        EDGE_63_71  1.0
    x_63        EDGE_17_63  1.0
    x_64        OBJ       -1
    x_64        EDGE_13_64  1.0
    x_64        EDGE_54_64  1.0
    x_64        EDGE_64_95  1.0
    x_64        EDGE_64_76  1.0
    x_64        EDGE_64_85  1.0
    x_64        EDGE_64_89  1.0
    x_64        EDGE_64_75  1.0
    x_64        EDGE_64_70  1.0
    x_64        EDGE_64_65  1.0
    x_64        EDGE_25_64  1.0
    x_64        EDGE_9_64  1.0
    x_64        EDGE_58_64  1.0
    x_64        EDGE_20_64  1.0
    x_64        EDGE_64_97  1.0
    x_64        EDGE_50_64  1.0
    x_64        EDGE_12_64  1.0
    x_64        EDGE_4_64  1.0
    x_64        EDGE_64_68  1.0
    x_64        EDGE_34_64  1.0
    x_64        EDGE_45_64  1.0
    x_64        EDGE_56_64  1.0
    x_64        EDGE_37_64  1.0
    x_64        EDGE_48_64  1.0
    x_65        OBJ       -1
    x_65        EDGE_65_83  1.0
    x_65        EDGE_65_69  1.0
    x_65        EDGE_65_87  1.0
    x_65        EDGE_30_65  1.0
    x_65        EDGE_65_73  1.0
    x_65        EDGE_39_65  1.0
    x_65        EDGE_65_68  1.0
    x_65        EDGE_65_86  1.0
    x_65        EDGE_3_65  1.0
    x_65        EDGE_65_67  1.0
    x_65        EDGE_64_65  1.0
    x_65        EDGE_20_65  1.0
    x_65        EDGE_65_81  1.0
    x_65        EDGE_50_65  1.0
    x_65        EDGE_51_65  1.0
    x_65        EDGE_65_80  1.0
    x_65        EDGE_62_65  1.0
    x_65        EDGE_40_65  1.0
    x_65        EDGE_2_65  1.0
    x_65        EDGE_41_65  1.0
    x_66        OBJ       -1
    x_66        EDGE_6_66  1.0
    x_66        EDGE_66_80  1.0
    x_66        EDGE_47_66  1.0
    x_66        EDGE_28_66  1.0
    x_66        EDGE_9_66  1.0
    x_66        EDGE_39_66  1.0
    x_66        EDGE_42_66  1.0
    x_66        EDGE_56_66  1.0
    x_66        EDGE_66_98  1.0
    x_66        EDGE_7_66  1.0
    x_66        EDGE_66_97  1.0
    x_66        EDGE_66_92  1.0
    x_66        EDGE_66_87  1.0
    x_66        EDGE_66_96  1.0
    x_66        EDGE_51_66  1.0
    x_66        EDGE_66_68  1.0
    x_66        EDGE_66_77  1.0
    x_66        EDGE_62_66  1.0
    x_66        EDGE_13_66  1.0
    x_66        EDGE_27_66  1.0
    x_66        EDGE_0_66  1.0
    x_66        EDGE_11_66  1.0
    x_66        EDGE_60_66  1.0
    x_66        EDGE_66_91  1.0
    x_66        EDGE_22_66  1.0
    x_66        EDGE_52_66  1.0
    x_66        EDGE_3_66  1.0
    x_66        EDGE_66_81  1.0
    x_66        EDGE_25_66  1.0
    x_66        EDGE_66_76  1.0
    x_67        OBJ       -1
    x_67        EDGE_20_67  1.0
    x_67        EDGE_42_67  1.0
    x_67        EDGE_53_67  1.0
    x_67        EDGE_34_67  1.0
    x_67        EDGE_65_67  1.0
    x_67        EDGE_67_90  1.0
    x_67        EDGE_67_94  1.0
    x_67        EDGE_67_80  1.0
    x_67        EDGE_5_67  1.0
    x_67        EDGE_35_67  1.0
    x_67        EDGE_54_67  1.0
    x_67        EDGE_8_67  1.0
    x_67        EDGE_11_67  1.0
    x_67        EDGE_52_67  1.0
    x_67        EDGE_67_88  1.0
    x_67        EDGE_33_67  1.0
    x_67        EDGE_67_74  1.0
    x_67        EDGE_63_67  1.0
    x_67        EDGE_67_78  1.0
    x_67        EDGE_67_87  1.0
    x_67        EDGE_36_67  1.0
    x_67        EDGE_67_82  1.0
    x_68        OBJ       -1
    x_68        EDGE_2_68  1.0
    x_68        EDGE_59_68  1.0
    x_68        EDGE_32_68  1.0
    x_68        EDGE_68_87  1.0
    x_68        EDGE_65_68  1.0
    x_68        EDGE_68_73  1.0
    x_68        EDGE_68_72  1.0
    x_68        EDGE_11_68  1.0
    x_68        EDGE_41_68  1.0
    x_68        EDGE_3_68  1.0
    x_68        EDGE_33_68  1.0
    x_68        EDGE_63_68  1.0
    x_68        EDGE_55_68  1.0
    x_68        EDGE_6_68  1.0
    x_68        EDGE_66_68  1.0
    x_68        EDGE_68_71  1.0
    x_68        EDGE_68_80  1.0
    x_68        EDGE_68_89  1.0
    x_68        EDGE_68_98  1.0
    x_68        EDGE_23_68  1.0
    x_68        EDGE_68_79  1.0
    x_68        EDGE_25_68  1.0
    x_68        EDGE_64_68  1.0
    x_68        EDGE_15_68  1.0
    x_68        EDGE_26_68  1.0
    x_68        EDGE_7_68  1.0
    x_68        EDGE_48_68  1.0
    x_69        OBJ       -1
    x_69        EDGE_32_69  1.0
    x_69        EDGE_5_69  1.0
    x_69        EDGE_69_90  1.0
    x_69        EDGE_69_71  1.0
    x_69        EDGE_65_69  1.0
    x_69        EDGE_69_75  1.0
    x_69        EDGE_69_70  1.0
    x_69        EDGE_38_69  1.0
    x_69        EDGE_14_69  1.0
    x_69        EDGE_44_69  1.0
    x_69        EDGE_47_69  1.0
    x_69        EDGE_69_93  1.0
    x_69        EDGE_28_69  1.0
    x_69        EDGE_69_83  1.0
    x_69        EDGE_39_69  1.0
    x_69        EDGE_69_78  1.0
    x_69        EDGE_69_87  1.0
    x_69        EDGE_31_69  1.0
    x_69        EDGE_61_69  1.0
    x_69        EDGE_42_69  1.0
    x_69        EDGE_4_69  1.0
    x_69        EDGE_26_69  1.0
    x_69        EDGE_45_69  1.0
    x_69        EDGE_56_69  1.0
    x_70        OBJ       -1
    x_70        EDGE_70_82  1.0
    x_70        EDGE_58_70  1.0
    x_70        EDGE_69_70  1.0
    x_70        EDGE_50_70  1.0
    x_70        EDGE_53_70  1.0
    x_70        EDGE_64_70  1.0
    x_70        EDGE_70_86  1.0
    x_70        EDGE_56_70  1.0
    x_70        EDGE_70_90  1.0
    x_70        EDGE_70_89  1.0
    x_70        EDGE_12_70  1.0
    x_70        EDGE_51_70  1.0
    x_70        EDGE_62_70  1.0
    x_70        EDGE_42_70  1.0
    x_70        EDGE_5_70  1.0
    x_70        EDGE_70_95  1.0
    x_70        EDGE_27_70  1.0
    x_70        EDGE_57_70  1.0
    x_70        EDGE_30_70  1.0
    x_70        EDGE_70_84  1.0
    x_70        EDGE_49_70  1.0
    x_70        EDGE_2_70  1.0
    x_70        EDGE_21_70  1.0
    x_70        EDGE_70_74  1.0
    x_70        EDGE_70_92  1.0
    x_70        EDGE_70_78  1.0
    x_70        EDGE_44_70  1.0
    x_71        OBJ       -1
    x_71        EDGE_69_71  1.0
    x_71        EDGE_12_71  1.0
    x_71        EDGE_23_71  1.0
    x_71        EDGE_4_71  1.0
    x_71        EDGE_71_88  1.0
    x_71        EDGE_34_71  1.0
    x_71        EDGE_7_71  1.0
    x_71        EDGE_18_71  1.0
    x_71        EDGE_71_87  1.0
    x_71        EDGE_29_71  1.0
    x_71        EDGE_40_71  1.0
    x_71        EDGE_2_71  1.0
    x_71        EDGE_21_71  1.0
    x_71        EDGE_5_71  1.0
    x_71        EDGE_35_71  1.0
    x_71        EDGE_68_71  1.0
    x_71        EDGE_19_71  1.0
    x_71        EDGE_71_95  1.0
    x_71        EDGE_11_71  1.0
    x_71        EDGE_71_72  1.0
    x_71        EDGE_71_99  1.0
    x_71        EDGE_22_71  1.0
    x_71        EDGE_71_85  1.0
    x_71        EDGE_71_94  1.0
    x_71        EDGE_33_71  1.0
    x_71        EDGE_63_71  1.0
    x_71        EDGE_25_71  1.0
    x_72        OBJ       -1
    x_72        EDGE_31_72  1.0
    x_72        EDGE_50_72  1.0
    x_72        EDGE_72_97  1.0
    x_72        EDGE_51_72  1.0
    x_72        EDGE_42_72  1.0
    x_72        EDGE_4_72  1.0
    x_72        EDGE_72_76  1.0
    x_72        EDGE_72_85  1.0
    x_72        EDGE_72_94  1.0
    x_72        EDGE_45_72  1.0
    x_72        EDGE_72_89  1.0
    x_72        EDGE_72_98  1.0
    x_72        EDGE_72_93  1.0
    x_72        EDGE_72_79  1.0
    x_72        EDGE_68_72  1.0
    x_72        EDGE_10_72  1.0
    x_72        EDGE_21_72  1.0
    x_72        EDGE_52_72  1.0
    x_72        EDGE_5_72  1.0
    x_72        EDGE_24_72  1.0
    x_72        EDGE_55_72  1.0
    x_72        EDGE_47_72  1.0
    x_72        EDGE_46_72  1.0
    x_72        EDGE_8_72  1.0
    x_72        EDGE_30_72  1.0
    x_72        EDGE_72_83  1.0
    x_72        EDGE_72_92  1.0
    x_72        EDGE_72_96  1.0
    x_72        EDGE_41_72  1.0
    x_72        EDGE_72_77  1.0
    x_72        EDGE_71_72  1.0
    x_72        EDGE_6_72  1.0
    x_72        EDGE_36_72  1.0
    x_73        OBJ       -1
    x_73        EDGE_59_73  1.0
    x_73        EDGE_73_92  1.0
    x_73        EDGE_51_73  1.0
    x_73        EDGE_73_78  1.0
    x_73        EDGE_73_96  1.0
    x_73        EDGE_5_73  1.0
    x_73        EDGE_73_77  1.0
    x_73        EDGE_65_73  1.0
    x_73        EDGE_68_73  1.0
    x_73        EDGE_19_73  1.0
    x_73        EDGE_33_73  1.0
    x_73        EDGE_25_73  1.0
    x_73        EDGE_28_73  1.0
    x_73        EDGE_39_73  1.0
    x_73        EDGE_73_75  1.0
    x_73        EDGE_73_84  1.0
    x_73        EDGE_1_73  1.0
    x_73        EDGE_20_73  1.0
    x_73        EDGE_26_73  1.0
    x_73        EDGE_18_73  1.0
    x_73        EDGE_40_73  1.0
    x_73        EDGE_73_79  1.0
    x_74        OBJ       -1
    x_74        EDGE_5_74  1.0
    x_74        EDGE_74_75  1.0
    x_74        EDGE_13_74  1.0
    x_74        EDGE_19_74  1.0
    x_74        EDGE_30_74  1.0
    x_74        EDGE_38_74  1.0
    x_74        EDGE_49_74  1.0
    x_74        EDGE_74_86  1.0
    x_74        EDGE_14_74  1.0
    x_74        EDGE_33_74  1.0
    x_74        EDGE_63_74  1.0
    x_74        EDGE_25_74  1.0
    x_74        EDGE_17_74  1.0
    x_74        EDGE_28_74  1.0
    x_74        EDGE_1_74  1.0
    x_74        EDGE_58_74  1.0
    x_74        EDGE_51_74  1.0
    x_74        EDGE_42_74  1.0
    x_74        EDGE_15_74  1.0
    x_74        EDGE_56_74  1.0
    x_74        EDGE_18_74  1.0
    x_74        EDGE_10_74  1.0
    x_74        EDGE_74_95  1.0
    x_74        EDGE_67_74  1.0
    x_74        EDGE_40_74  1.0
    x_74        EDGE_74_99  1.0
    x_74        EDGE_70_74  1.0
    x_74        EDGE_74_80  1.0
    x_75        OBJ       -1
    x_75        EDGE_6_75  1.0
    x_75        EDGE_74_75  1.0
    x_75        EDGE_47_75  1.0
    x_75        EDGE_39_75  1.0
    x_75        EDGE_58_75  1.0
    x_75        EDGE_69_75  1.0
    x_75        EDGE_75_91  1.0
    x_75        EDGE_20_75  1.0
    x_75        EDGE_50_75  1.0
    x_75        EDGE_42_75  1.0
    x_75        EDGE_64_75  1.0
    x_75        EDGE_75_80  1.0
    x_75        EDGE_75_89  1.0
    x_75        EDGE_9_75  1.0
    x_75        EDGE_10_75  1.0
    x_75        EDGE_40_75  1.0
    x_75        EDGE_2_75  1.0
    x_75        EDGE_21_75  1.0
    x_75        EDGE_73_75  1.0
    x_75        EDGE_35_75  1.0
    x_75        EDGE_75_93  1.0
    x_75        EDGE_75_79  1.0
    x_75        EDGE_57_75  1.0
    x_75        EDGE_19_75  1.0
    x_75        EDGE_11_75  1.0
    x_75        EDGE_75_82  1.0
    x_75        EDGE_41_75  1.0
    x_75        EDGE_3_75  1.0
    x_75        EDGE_14_75  1.0
    x_76        OBJ       -1
    x_76        EDGE_1_76  1.0
    x_76        EDGE_20_76  1.0
    x_76        EDGE_31_76  1.0
    x_76        EDGE_50_76  1.0
    x_76        EDGE_61_76  1.0
    x_76        EDGE_72_76  1.0
    x_76        EDGE_76_82  1.0
    x_76        EDGE_64_76  1.0
    x_76        EDGE_29_76  1.0
    x_76        EDGE_40_76  1.0
    x_76        EDGE_51_76  1.0
    x_76        EDGE_32_76  1.0
    x_76        EDGE_62_76  1.0
    x_76        EDGE_13_76  1.0
    x_76        EDGE_76_93  1.0
    x_76        EDGE_11_76  1.0
    x_76        EDGE_52_76  1.0
    x_76        EDGE_3_76  1.0
    x_76        EDGE_33_76  1.0
    x_76        EDGE_63_76  1.0
    x_76        EDGE_66_76  1.0
    x_77        OBJ       -1
    x_77        EDGE_77_99  1.0
    x_77        EDGE_77_94  1.0
    x_77        EDGE_12_77  1.0
    x_77        EDGE_23_77  1.0
    x_77        EDGE_77_93  1.0
    x_77        EDGE_73_77  1.0
    x_77        EDGE_35_77  1.0
    x_77        EDGE_77_79  1.0
    x_77        EDGE_57_77  1.0
    x_77        EDGE_2_77  1.0
    x_77        EDGE_22_77  1.0
    x_77        EDGE_55_77  1.0
    x_77        EDGE_36_77  1.0
    x_77        EDGE_77_78  1.0
    x_77        EDGE_66_77  1.0
    x_77        EDGE_77_86  1.0
    x_77        EDGE_50_77  1.0
    x_77        EDGE_77_88  1.0
    x_77        EDGE_33_77  1.0
    x_77        EDGE_72_77  1.0
    x_77        EDGE_63_77  1.0
    x_77        EDGE_15_77  1.0
    x_77        EDGE_56_77  1.0
    x_77        EDGE_17_77  1.0
    x_78        OBJ       -1
    x_78        EDGE_73_78  1.0
    x_78        EDGE_35_78  1.0
    x_78        EDGE_49_78  1.0
    x_78        EDGE_0_78  1.0
    x_78        EDGE_60_78  1.0
    x_78        EDGE_63_78  1.0
    x_78        EDGE_17_78  1.0
    x_78        EDGE_28_78  1.0
    x_78        EDGE_77_78  1.0
    x_78        EDGE_9_78  1.0
    x_78        EDGE_39_78  1.0
    x_78        EDGE_1_78  1.0
    x_78        EDGE_69_78  1.0
    x_78        EDGE_31_78  1.0
    x_78        EDGE_50_78  1.0
    x_78        EDGE_53_78  1.0
    x_78        EDGE_15_78  1.0
    x_78        EDGE_34_78  1.0
    x_78        EDGE_56_78  1.0
    x_78        EDGE_18_78  1.0
    x_78        EDGE_67_78  1.0
    x_78        EDGE_40_78  1.0
    x_78        EDGE_70_78  1.0
    x_79        OBJ       -1
    x_79        EDGE_54_79  1.0
    x_79        EDGE_55_79  1.0
    x_79        EDGE_8_79  1.0
    x_79        EDGE_19_79  1.0
    x_79        EDGE_38_79  1.0
    x_79        EDGE_77_79  1.0
    x_79        EDGE_39_79  1.0
    x_79        EDGE_58_79  1.0
    x_79        EDGE_41_79  1.0
    x_79        EDGE_44_79  1.0
    x_79        EDGE_72_79  1.0
    x_79        EDGE_79_87  1.0
    x_79        EDGE_25_79  1.0
    x_79        EDGE_79_82  1.0
    x_79        EDGE_47_79  1.0
    x_79        EDGE_17_79  1.0
    x_79        EDGE_28_79  1.0
    x_79        EDGE_9_79  1.0
    x_79        EDGE_1_79  1.0
    x_79        EDGE_20_79  1.0
    x_79        EDGE_34_79  1.0
    x_79        EDGE_18_79  1.0
    x_79        EDGE_75_79  1.0
    x_79        EDGE_79_90  1.0
    x_79        EDGE_68_79  1.0
    x_79        EDGE_79_89  1.0
    x_79        EDGE_29_79  1.0
    x_79        EDGE_73_79  1.0
    x_80        OBJ       -1
    x_80        EDGE_80_95  1.0
    x_80        EDGE_66_80  1.0
    x_80        EDGE_28_80  1.0
    x_80        EDGE_1_80  1.0
    x_80        EDGE_61_80  1.0
    x_80        EDGE_12_80  1.0
    x_80        EDGE_42_80  1.0
    x_80        EDGE_4_80  1.0
    x_80        EDGE_15_80  1.0
    x_80        EDGE_56_80  1.0
    x_80        EDGE_7_80  1.0
    x_80        EDGE_75_80  1.0
    x_80        EDGE_37_80  1.0
    x_80        EDGE_10_80  1.0
    x_80        EDGE_67_80  1.0
    x_80        EDGE_51_80  1.0
    x_80        EDGE_80_87  1.0
    x_80        EDGE_16_80  1.0
    x_80        EDGE_80_91  1.0
    x_80        EDGE_65_80  1.0
    x_80        EDGE_80_86  1.0
    x_80        EDGE_46_80  1.0
    x_80        EDGE_68_80  1.0
    x_80        EDGE_11_80  1.0
    x_80        EDGE_3_80  1.0
    x_80        EDGE_74_80  1.0
    x_81        OBJ       -1
    x_81        EDGE_81_87  1.0
    x_81        EDGE_1_81  1.0
    x_81        EDGE_81_82  1.0
    x_81        EDGE_81_91  1.0
    x_81        EDGE_61_81  1.0
    x_81        EDGE_53_81  1.0
    x_81        EDGE_34_81  1.0
    x_81        EDGE_18_81  1.0
    x_81        EDGE_59_81  1.0
    x_81        EDGE_81_95  1.0
    x_81        EDGE_81_99  1.0
    x_81        EDGE_81_85  1.0
    x_81        EDGE_62_81  1.0
    x_81        EDGE_65_81  1.0
    x_81        EDGE_25_81  1.0
    x_81        EDGE_6_81  1.0
    x_81        EDGE_81_97  1.0
    x_81        EDGE_66_81  1.0
    x_81        EDGE_81_92  1.0
    x_82        OBJ       -1
    x_82        EDGE_70_82  1.0
    x_82        EDGE_42_82  1.0
    x_82        EDGE_81_82  1.0
    x_82        EDGE_43_82  1.0
    x_82        EDGE_5_82  1.0
    x_82        EDGE_24_82  1.0
    x_82        EDGE_76_82  1.0
    x_82        EDGE_19_82  1.0
    x_82        EDGE_82_83  1.0
    x_82        EDGE_60_82  1.0
    x_82        EDGE_79_82  1.0
    x_82        EDGE_41_82  1.0
    x_82        EDGE_44_82  1.0
    x_82        EDGE_28_82  1.0
    x_82        EDGE_0_82  1.0
    x_82        EDGE_1_82  1.0
    x_82        EDGE_20_82  1.0
    x_82        EDGE_31_82  1.0
    x_82        EDGE_50_82  1.0
    x_82        EDGE_61_82  1.0
    x_82        EDGE_23_82  1.0
    x_82        EDGE_25_82  1.0
    x_82        EDGE_15_82  1.0
    x_82        EDGE_82_90  1.0
    x_82        EDGE_75_82  1.0
    x_82        EDGE_9_82  1.0
    x_82        EDGE_48_82  1.0
    x_82        EDGE_67_82  1.0
    x_82        EDGE_2_82  1.0
    x_83        OBJ       -1
    x_83        EDGE_5_83  1.0
    x_83        EDGE_65_83  1.0
    x_83        EDGE_46_83  1.0
    x_83        EDGE_57_83  1.0
    x_83        EDGE_83_95  1.0
    x_83        EDGE_38_83  1.0
    x_83        EDGE_49_83  1.0
    x_83        EDGE_83_99  1.0
    x_83        EDGE_83_89  1.0
    x_83        EDGE_41_83  1.0
    x_83        EDGE_82_83  1.0
    x_83        EDGE_63_83  1.0
    x_83        EDGE_36_83  1.0
    x_83        EDGE_17_83  1.0
    x_83        EDGE_69_83  1.0
    x_83        EDGE_20_83  1.0
    x_83        EDGE_12_83  1.0
    x_83        EDGE_72_83  1.0
    x_83        EDGE_83_88  1.0
    x_83        EDGE_15_83  1.0
    x_83        EDGE_83_92  1.0
    x_83        EDGE_45_83  1.0
    x_83        EDGE_18_83  1.0
    x_83        EDGE_83_96  1.0
    x_83        EDGE_37_83  1.0
    x_83        EDGE_83_91  1.0
    x_83        EDGE_59_83  1.0
    x_83        EDGE_32_83  1.0
    x_84        OBJ       -1
    x_84        EDGE_16_84  1.0
    x_84        EDGE_55_84  1.0
    x_84        EDGE_6_84  1.0
    x_84        EDGE_19_84  1.0
    x_84        EDGE_84_97  1.0
    x_84        EDGE_11_84  1.0
    x_84        EDGE_61_84  1.0
    x_84        EDGE_84_99  1.0
    x_84        EDGE_56_84  1.0
    x_84        EDGE_17_84  1.0
    x_84        EDGE_28_84  1.0
    x_84        EDGE_9_84  1.0
    x_84        EDGE_42_84  1.0
    x_84        EDGE_84_86  1.0
    x_84        EDGE_43_84  1.0
    x_84        EDGE_73_84  1.0
    x_84        EDGE_29_84  1.0
    x_84        EDGE_70_84  1.0
    x_84        EDGE_60_84  1.0
    x_84        EDGE_52_84  1.0
    x_84        EDGE_35_84  1.0
    x_85        OBJ       -1
    x_85        EDGE_20_85  1.0
    x_85        EDGE_42_85  1.0
    x_85        EDGE_72_85  1.0
    x_85        EDGE_4_85  1.0
    x_85        EDGE_53_85  1.0
    x_85        EDGE_64_85  1.0
    x_85        EDGE_85_89  1.0
    x_85        EDGE_48_85  1.0
    x_85        EDGE_81_85  1.0
    x_85        EDGE_32_85  1.0
    x_85        EDGE_43_85  1.0
    x_85        EDGE_85_95  1.0
    x_85        EDGE_85_86  1.0
    x_85        EDGE_24_85  1.0
    x_85        EDGE_35_85  1.0
    x_85        EDGE_46_85  1.0
    x_85        EDGE_57_85  1.0
    x_85        EDGE_30_85  1.0
    x_85        EDGE_14_85  1.0
    x_85        EDGE_71_85  1.0
    x_85        EDGE_44_85  1.0
    x_85        EDGE_25_85  1.0
    x_85        EDGE_47_85  1.0
    x_86        OBJ       -1
    x_86        EDGE_50_86  1.0
    x_86        EDGE_23_86  1.0
    x_86        EDGE_51_86  1.0
    x_86        EDGE_42_86  1.0
    x_86        EDGE_65_86  1.0
    x_86        EDGE_74_86  1.0
    x_86        EDGE_10_86  1.0
    x_86        EDGE_86_90  1.0
    x_86        EDGE_2_86  1.0
    x_86        EDGE_70_86  1.0
    x_86        EDGE_60_86  1.0
    x_86        EDGE_43_86  1.0
    x_86        EDGE_5_86  1.0
    x_86        EDGE_13_86  1.0
    x_86        EDGE_85_86  1.0
    x_86        EDGE_84_86  1.0
    x_86        EDGE_49_86  1.0
    x_86        EDGE_77_86  1.0
    x_86        EDGE_0_86  1.0
    x_86        EDGE_80_86  1.0
    x_86        EDGE_86_92  1.0
    x_86        EDGE_6_86  1.0
    x_86        EDGE_86_87  1.0
    x_86        EDGE_17_86  1.0
    x_86        EDGE_28_86  1.0
    x_87        OBJ       -1
    x_87        EDGE_81_87  1.0
    x_87        EDGE_32_87  1.0
    x_87        EDGE_87_97  1.0
    x_87        EDGE_65_87  1.0
    x_87        EDGE_57_87  1.0
    x_87        EDGE_68_87  1.0
    x_87        EDGE_19_87  1.0
    x_87        EDGE_79_87  1.0
    x_87        EDGE_71_87  1.0
    x_87        EDGE_33_87  1.0
    x_87        EDGE_63_87  1.0
    x_87        EDGE_66_87  1.0
    x_87        EDGE_1_87  1.0
    x_87        EDGE_69_87  1.0
    x_87        EDGE_80_87  1.0
    x_87        EDGE_31_87  1.0
    x_87        EDGE_12_87  1.0
    x_87        EDGE_87_90  1.0
    x_87        EDGE_87_89  1.0
    x_87        EDGE_26_87  1.0
    x_87        EDGE_86_87  1.0
    x_87        EDGE_48_87  1.0
    x_87        EDGE_67_87  1.0
    x_87        EDGE_40_87  1.0
    x_87        EDGE_51_87  1.0
    x_88        OBJ       -1
    x_88        EDGE_27_88  1.0
    x_88        EDGE_19_88  1.0
    x_88        EDGE_30_88  1.0
    x_88        EDGE_0_88  1.0
    x_88        EDGE_71_88  1.0
    x_88        EDGE_55_88  1.0
    x_88        EDGE_9_88  1.0
    x_88        EDGE_58_88  1.0
    x_88        EDGE_20_88  1.0
    x_88        EDGE_88_97  1.0
    x_88        EDGE_4_88  1.0
    x_88        EDGE_88_96  1.0
    x_88        EDGE_83_88  1.0
    x_88        EDGE_56_88  1.0
    x_88        EDGE_77_88  1.0
    x_88        EDGE_37_88  1.0
    x_88        EDGE_67_88  1.0
    x_88        EDGE_59_88  1.0
    x_88        EDGE_21_88  1.0
    x_88        EDGE_51_88  1.0
    x_89        OBJ       -1
    x_89        EDGE_38_89  1.0
    x_89        EDGE_58_89  1.0
    x_89        EDGE_72_89  1.0
    x_89        EDGE_64_89  1.0
    x_89        EDGE_85_89  1.0
    x_89        EDGE_83_89  1.0
    x_89        EDGE_45_89  1.0
    x_89        EDGE_18_89  1.0
    x_89        EDGE_75_89  1.0
    x_89        EDGE_10_89  1.0
    x_89        EDGE_89_98  1.0
    x_89        EDGE_70_89  1.0
    x_89        EDGE_4_89  1.0
    x_89        EDGE_13_89  1.0
    x_89        EDGE_7_89  1.0
    x_89        EDGE_37_89  1.0
    x_89        EDGE_46_89  1.0
    x_89        EDGE_68_89  1.0
    x_89        EDGE_19_89  1.0
    x_89        EDGE_87_89  1.0
    x_89        EDGE_49_89  1.0
    x_89        EDGE_79_89  1.0
    x_89        EDGE_33_89  1.0
    x_90        OBJ       -1
    x_90        EDGE_69_90  1.0
    x_90        EDGE_4_90  1.0
    x_90        EDGE_34_90  1.0
    x_90        EDGE_90_97  1.0
    x_90        EDGE_18_90  1.0
    x_90        EDGE_37_90  1.0
    x_90        EDGE_86_90  1.0
    x_90        EDGE_90_96  1.0
    x_90        EDGE_48_90  1.0
    x_90        EDGE_67_90  1.0
    x_90        EDGE_70_90  1.0
    x_90        EDGE_51_90  1.0
    x_90        EDGE_43_90  1.0
    x_90        EDGE_24_90  1.0
    x_90        EDGE_87_90  1.0
    x_90        EDGE_22_90  1.0
    x_90        EDGE_79_90  1.0
    x_90        EDGE_90_99  1.0
    x_90        EDGE_82_90  1.0
    x_90        EDGE_44_90  1.0
    x_90        EDGE_90_98  1.0
    x_90        EDGE_63_90  1.0
    x_90        EDGE_28_90  1.0
    x_91        OBJ       -1
    x_91        EDGE_61_91  1.0
    x_91        EDGE_81_91  1.0
    x_91        EDGE_43_91  1.0
    x_91        EDGE_91_95  1.0
    x_91        EDGE_75_91  1.0
    x_91        EDGE_21_91  1.0
    x_91        EDGE_22_91  1.0
    x_91        EDGE_13_91  1.0
    x_91        EDGE_54_91  1.0
    x_91        EDGE_16_91  1.0
    x_91        EDGE_55_91  1.0
    x_91        EDGE_47_91  1.0
    x_91        EDGE_46_91  1.0
    x_91        EDGE_19_91  1.0
    x_91        EDGE_38_91  1.0
    x_91        EDGE_0_91  1.0
    x_91        EDGE_58_91  1.0
    x_91        EDGE_80_91  1.0
    x_91        EDGE_41_91  1.0
    x_91        EDGE_91_96  1.0
    x_91        EDGE_63_91  1.0
    x_91        EDGE_53_91  1.0
    x_91        EDGE_83_91  1.0
    x_91        EDGE_66_91  1.0
    x_92        OBJ       -1
    x_92        EDGE_73_92  1.0
    x_92        EDGE_92_96  1.0
    x_92        EDGE_27_92  1.0
    x_92        EDGE_19_92  1.0
    x_92        EDGE_30_92  1.0
    x_92        EDGE_38_92  1.0
    x_92        EDGE_41_92  1.0
    x_92        EDGE_25_92  1.0
    x_92        EDGE_47_92  1.0
    x_92        EDGE_66_92  1.0
    x_92        EDGE_17_92  1.0
    x_92        EDGE_28_92  1.0
    x_92        EDGE_9_92  1.0
    x_92        EDGE_20_92  1.0
    x_92        EDGE_61_92  1.0
    x_92        EDGE_42_92  1.0
    x_92        EDGE_72_92  1.0
    x_92        EDGE_83_92  1.0
    x_92        EDGE_7_92  1.0
    x_92        EDGE_86_92  1.0
    x_92        EDGE_40_92  1.0
    x_92        EDGE_70_92  1.0
    x_92        EDGE_92_98  1.0
    x_92        EDGE_81_92  1.0
    x_92        EDGE_43_92  1.0
    x_93        OBJ       -1
    x_93        EDGE_55_93  1.0
    x_93        EDGE_19_93  1.0
    x_93        EDGE_38_93  1.0
    x_93        EDGE_49_93  1.0
    x_93        EDGE_77_93  1.0
    x_93        EDGE_0_93  1.0
    x_93        EDGE_11_93  1.0
    x_93        EDGE_41_93  1.0
    x_93        EDGE_52_93  1.0
    x_93        EDGE_3_93  1.0
    x_93        EDGE_44_93  1.0
    x_93        EDGE_72_93  1.0
    x_93        EDGE_63_93  1.0
    x_93        EDGE_47_93  1.0
    x_93        EDGE_9_93  1.0
    x_93        EDGE_69_93  1.0
    x_93        EDGE_50_93  1.0
    x_93        EDGE_12_93  1.0
    x_93        EDGE_42_93  1.0
    x_93        EDGE_53_93  1.0
    x_93        EDGE_15_93  1.0
    x_93        EDGE_34_93  1.0
    x_93        EDGE_56_93  1.0
    x_93        EDGE_75_93  1.0
    x_93        EDGE_76_93  1.0
    x_93        EDGE_48_93  1.0
    x_93        EDGE_59_93  1.0
    x_93        EDGE_62_93  1.0
    x_93        EDGE_93_98  1.0
    x_93        EDGE_54_93  1.0
    x_94        OBJ       -1
    x_94        EDGE_77_94  1.0
    x_94        EDGE_1_94  1.0
    x_94        EDGE_58_94  1.0
    x_94        EDGE_31_94  1.0
    x_94        EDGE_61_94  1.0
    x_94        EDGE_72_94  1.0
    x_94        EDGE_15_94  1.0
    x_94        EDGE_18_94  1.0
    x_94        EDGE_48_94  1.0
    x_94        EDGE_10_94  1.0
    x_94        EDGE_67_94  1.0
    x_94        EDGE_29_94  1.0
    x_94        EDGE_40_94  1.0
    x_94        EDGE_62_94  1.0
    x_94        EDGE_24_94  1.0
    x_94        EDGE_27_94  1.0
    x_94        EDGE_46_94  1.0
    x_94        EDGE_57_94  1.0
    x_94        EDGE_19_94  1.0
    x_94        EDGE_71_94  1.0
    x_94        EDGE_33_94  1.0
    x_94        EDGE_44_94  1.0
    x_94        EDGE_36_94  1.0
    x_95        OBJ       -1
    x_95        EDGE_80_95  1.0
    x_95        EDGE_31_95  1.0
    x_95        EDGE_23_95  1.0
    x_95        EDGE_42_95  1.0
    x_95        EDGE_95_97  1.0
    x_95        EDGE_4_95  1.0
    x_95        EDGE_91_95  1.0
    x_95        EDGE_64_95  1.0
    x_95        EDGE_26_95  1.0
    x_95        EDGE_83_95  1.0
    x_95        EDGE_37_95  1.0
    x_95        EDGE_29_95  1.0
    x_95        EDGE_21_95  1.0
    x_95        EDGE_51_95  1.0
    x_95        EDGE_81_95  1.0
    x_95        EDGE_13_95  1.0
    x_95        EDGE_85_95  1.0
    x_95        EDGE_70_95  1.0
    x_95        EDGE_52_95  1.0
    x_95        EDGE_71_95  1.0
    x_95        EDGE_63_95  1.0
    x_95        EDGE_6_95  1.0
    x_95        EDGE_74_95  1.0
    x_95        EDGE_47_95  1.0
    x_96        OBJ       -1
    x_96        EDGE_4_96  1.0
    x_96        EDGE_73_96  1.0
    x_96        EDGE_92_96  1.0
    x_96        EDGE_57_96  1.0
    x_96        EDGE_21_96  1.0
    x_96        EDGE_60_96  1.0
    x_96        EDGE_90_96  1.0
    x_96        EDGE_52_96  1.0
    x_96        EDGE_13_96  1.0
    x_96        EDGE_16_96  1.0
    x_96        EDGE_66_96  1.0
    x_96        EDGE_8_96  1.0
    x_96        EDGE_0_96  1.0
    x_96        EDGE_20_96  1.0
    x_96        EDGE_88_96  1.0
    x_96        EDGE_33_96  1.0
    x_96        EDGE_72_96  1.0
    x_96        EDGE_91_96  1.0
    x_96        EDGE_83_96  1.0
    x_96        EDGE_56_96  1.0
    x_97        OBJ       -1
    x_97        EDGE_24_97  1.0
    x_97        EDGE_72_97  1.0
    x_97        EDGE_84_97  1.0
    x_97        EDGE_95_97  1.0
    x_97        EDGE_87_97  1.0
    x_97        EDGE_0_97  1.0
    x_97        EDGE_90_97  1.0
    x_97        EDGE_25_97  1.0
    x_97        EDGE_6_97  1.0
    x_97        EDGE_36_97  1.0
    x_97        EDGE_47_97  1.0
    x_97        EDGE_66_97  1.0
    x_97        EDGE_39_97  1.0
    x_97        EDGE_1_97  1.0
    x_97        EDGE_58_97  1.0
    x_97        EDGE_88_97  1.0
    x_97        EDGE_61_97  1.0
    x_97        EDGE_53_97  1.0
    x_97        EDGE_64_97  1.0
    x_97        EDGE_7_97  1.0
    x_97        EDGE_48_97  1.0
    x_97        EDGE_2_97  1.0
    x_97        EDGE_59_97  1.0
    x_97        EDGE_51_97  1.0
    x_97        EDGE_81_97  1.0
    x_98        OBJ       -1
    x_98        EDGE_46_98  1.0
    x_98        EDGE_57_98  1.0
    x_98        EDGE_30_98  1.0
    x_98        EDGE_49_98  1.0
    x_98        EDGE_41_98  1.0
    x_98        EDGE_72_98  1.0
    x_98        EDGE_6_98  1.0
    x_98        EDGE_66_98  1.0
    x_98        EDGE_1_98  1.0
    x_98        EDGE_89_98  1.0
    x_98        EDGE_15_98  1.0
    x_98        EDGE_45_98  1.0
    x_98        EDGE_18_98  1.0
    x_98        EDGE_68_98  1.0
    x_98        EDGE_40_98  1.0
    x_98        EDGE_22_98  1.0
    x_98        EDGE_90_98  1.0
    x_98        EDGE_62_98  1.0
    x_98        EDGE_35_98  1.0
    x_98        EDGE_92_98  1.0
    x_98        EDGE_54_98  1.0
    x_98        EDGE_93_98  1.0
    x_98        EDGE_16_98  1.0
    x_98        EDGE_55_98  1.0
    x_99        OBJ       -1
    x_99        EDGE_77_99  1.0
    x_99        EDGE_9_99  1.0
    x_99        EDGE_20_99  1.0
    x_99        EDGE_53_99  1.0
    x_99        EDGE_83_99  1.0
    x_99        EDGE_84_99  1.0
    x_99        EDGE_10_99  1.0
    x_99        EDGE_29_99  1.0
    x_99        EDGE_2_99  1.0
    x_99        EDGE_81_99  1.0
    x_99        EDGE_5_99  1.0
    x_99        EDGE_27_99  1.0
    x_99        EDGE_19_99  1.0
    x_99        EDGE_30_99  1.0
    x_99        EDGE_90_99  1.0
    x_99        EDGE_71_99  1.0
    x_99        EDGE_33_99  1.0
    x_99        EDGE_63_99  1.0
    x_99        EDGE_25_99  1.0
    x_99        EDGE_74_99  1.0
RHS
    RHS1      EDGE_55_57  1.0
    RHS1      EDGE_15_30  1.0
    RHS1      EDGE_16_84  1.0
    RHS1      EDGE_24_97  1.0
    RHS1      EDGE_7_26  1.0
    RHS1      EDGE_26_30  1.0
    RHS1      EDGE_36_62  1.0
    RHS1      EDGE_28_58  1.0
    RHS1      EDGE_59_73  1.0
    RHS1      EDGE_55_84  1.0
    RHS1      EDGE_70_82  1.0
    RHS1      EDGE_55_93  1.0
    RHS1      EDGE_5_74  1.0
    RHS1      EDGE_5_83  1.0
    RHS1      EDGE_40_50  1.0
    RHS1      EDGE_77_99  1.0
    RHS1      EDGE_21_46  1.0
    RHS1      EDGE_6_57  1.0
    RHS1      EDGE_80_95  1.0
    RHS1      EDGE_21_55  1.0
    RHS1      EDGE_61_91  1.0
    RHS1      EDGE_6_66  1.0
    RHS1      EDGE_9_99  1.0
    RHS1      EDGE_10_27  1.0
    RHS1      EDGE_6_75  1.0
    RHS1      EDGE_6_84  1.0
    RHS1      EDGE_41_51  1.0
    RHS1      EDGE_81_87  1.0
    RHS1      EDGE_33_47  1.0
    RHS1      EDGE_2_41  1.0
    RHS1      EDGE_3_6  1.0
    RHS1      EDGE_25_43  1.0
    RHS1      EDGE_54_79  1.0
    RHS1      EDGE_73_92  1.0
    RHS1      EDGE_25_52  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_31_95  1.0
    RHS1      EDGE_14_24  1.0
    RHS1      EDGE_43_60  1.0
    RHS1      EDGE_51_73  1.0
    RHS1      EDGE_74_75  1.0
    RHS1      EDGE_2_68  1.0
    RHS1      EDGE_14_33  1.0
    RHS1      EDGE_32_69  1.0
    RHS1      EDGE_4_96  1.0
    RHS1      EDGE_66_80  1.0
    RHS1      EDGE_13_74  1.0
    RHS1      EDGE_32_87  1.0
    RHS1      EDGE_1_81  1.0
    RHS1      EDGE_17_53  1.0
    RHS1      EDGE_7_30  1.0
    RHS1      EDGE_47_66  1.0
    RHS1      EDGE_55_79  1.0
    RHS1      EDGE_5_60  1.0
    RHS1      EDGE_46_98  1.0
    RHS1      EDGE_47_75  1.0
    RHS1      EDGE_57_98  1.0
    RHS1      EDGE_59_68  1.0
    RHS1      EDGE_5_69  1.0
    RHS1      EDGE_28_80  1.0
    RHS1      EDGE_77_94  1.0
    RHS1      EDGE_29_54  1.0
    RHS1      EDGE_69_90  1.0
    RHS1      EDGE_50_86  1.0
    RHS1      EDGE_40_63  1.0
    RHS1      EDGE_42_82  1.0
    RHS1      EDGE_30_98  1.0
    RHS1      EDGE_81_82  1.0
    RHS1      EDGE_10_40  1.0
    RHS1      EDGE_73_78  1.0
    RHS1      EDGE_81_91  1.0
    RHS1      EDGE_2_36  1.0
    RHS1      EDGE_31_72  1.0
    RHS1      EDGE_25_47  1.0
    RHS1      EDGE_10_58  1.0
    RHS1      EDGE_12_77  1.0
    RHS1      EDGE_23_77  1.0
    RHS1      EDGE_73_96  1.0
    RHS1      EDGE_23_86  1.0
    RHS1      EDGE_20_99  1.0
    RHS1      EDGE_23_95  1.0
    RHS1      EDGE_13_60  1.0
    RHS1      EDGE_24_60  1.0
    RHS1      EDGE_35_60  1.0
    RHS1      EDGE_16_56  1.0
    RHS1      EDGE_51_86  1.0
    RHS1      EDGE_43_82  1.0
    RHS1      EDGE_1_76  1.0
    RHS1      EDGE_35_78  1.0
    RHS1      EDGE_36_43  1.0
    RHS1      EDGE_43_91  1.0
    RHS1      EDGE_7_16  1.0
    RHS1      EDGE_47_52  1.0
    RHS1      EDGE_1_94  1.0
    RHS1      EDGE_5_55  1.0
    RHS1      EDGE_9_53  1.0
    RHS1      EDGE_38_89  1.0
    RHS1      EDGE_28_66  1.0
    RHS1      EDGE_49_98  1.0
    RHS1      EDGE_5_73  1.0
    RHS1      EDGE_29_40  1.0
    RHS1      EDGE_50_72  1.0
    RHS1      EDGE_5_82  1.0
    RHS1      EDGE_6_47  1.0
    RHS1      EDGE_61_81  1.0
    RHS1      EDGE_58_94  1.0
    RHS1      EDGE_72_97  1.0
    RHS1      EDGE_92_96  1.0
    RHS1      EDGE_27_88  1.0
    RHS1      EDGE_10_17  1.0
    RHS1      EDGE_19_84  1.0
    RHS1      EDGE_42_86  1.0
    RHS1      EDGE_19_93  1.0
    RHS1      EDGE_2_22  1.0
    RHS1      EDGE_42_95  1.0
    RHS1      EDGE_10_35  1.0
    RHS1      EDGE_54_60  1.0
    RHS1      EDGE_20_67  1.0
    RHS1      EDGE_25_33  1.0
    RHS1      EDGE_10_44  1.0
    RHS1      EDGE_20_76  1.0
    RHS1      EDGE_31_76  1.0
    RHS1      EDGE_32_41  1.0
    RHS1      EDGE_20_85  1.0
    RHS1      EDGE_31_94  1.0
    RHS1      EDGE_84_97  1.0
    RHS1      EDGE_95_97  1.0
    RHS1      EDGE_51_72  1.0
    RHS1      EDGE_1_53  1.0
    RHS1      EDGE_14_32  1.0
    RHS1      EDGE_16_51  1.0
    RHS1      EDGE_32_68  1.0
    RHS1      EDGE_13_64  1.0
    RHS1      EDGE_4_95  1.0
    RHS1      EDGE_17_25  1.0
    RHS1      EDGE_36_38  1.0
    RHS1      EDGE_17_34  1.0
    RHS1      EDGE_1_80  1.0
    RHS1      EDGE_24_82  1.0
    RHS1      EDGE_36_47  1.0
    RHS1      EDGE_65_83  1.0
    RHS1      EDGE_5_41  1.0
    RHS1      EDGE_17_43  1.0
    RHS1      EDGE_5_50  1.0
    RHS1      EDGE_38_93  1.0
    RHS1      EDGE_49_93  1.0
    RHS1      EDGE_29_35  1.0
    RHS1      EDGE_69_71  1.0
    RHS1      EDGE_9_66  1.0
    RHS1      EDGE_29_44  1.0
    RHS1      EDGE_77_93  1.0
    RHS1      EDGE_50_76  1.0
    RHS1      EDGE_61_76  1.0
    RHS1      EDGE_6_51  1.0
    RHS1      EDGE_42_72  1.0
    RHS1      EDGE_58_89  1.0
    RHS1      EDGE_8_79  1.0
    RHS1      EDGE_19_79  1.0
    RHS1      EDGE_27_92  1.0
    RHS1      EDGE_61_94  1.0
    RHS1      EDGE_91_95  1.0
    RHS1      EDGE_19_88  1.0
    RHS1      EDGE_30_88  1.0
    RHS1      EDGE_11_84  1.0
    RHS1      EDGE_39_66  1.0
    RHS1      EDGE_2_26  1.0
    RHS1      EDGE_25_28  1.0
    RHS1      EDGE_0_93  1.0
    RHS1      EDGE_11_93  1.0
    RHS1      EDGE_12_58  1.0
    RHS1      EDGE_2_35  1.0
    RHS1      EDGE_39_75  1.0
    RHS1      EDGE_54_64  1.0
    RHS1      EDGE_73_77  1.0
    RHS1      EDGE_32_45  1.0
    RHS1      EDGE_13_41  1.0
    RHS1      EDGE_4_72  1.0
    RHS1      EDGE_14_18  1.0
    RHS1      EDGE_13_50  1.0
    RHS1      EDGE_35_50  1.0
    RHS1      EDGE_32_63  1.0
    RHS1      EDGE_43_63  1.0
    RHS1      EDGE_1_57  1.0
    RHS1      EDGE_35_59  1.0
    RHS1      EDGE_4_90  1.0
    RHS1      EDGE_64_95  1.0
    RHS1      EDGE_87_97  1.0
    RHS1      EDGE_65_69  1.0
    RHS1      EDGE_28_29  1.0
    RHS1      EDGE_35_77  1.0
    RHS1      EDGE_65_87  1.0
    RHS1      EDGE_5_45  1.0
    RHS1      EDGE_6_10  1.0
    RHS1      EDGE_46_83  1.0
    RHS1      EDGE_9_43  1.0
    RHS1      EDGE_38_79  1.0
    RHS1      EDGE_57_83  1.0
    RHS1      EDGE_9_52  1.0
    RHS1      EDGE_26_95  1.0
    RHS1      EDGE_21_26  1.0
    RHS1      EDGE_61_62  1.0
    RHS1      EDGE_58_75  1.0
    RHS1      EDGE_69_75  1.0
    RHS1      EDGE_77_79  1.0
    RHS1      EDGE_30_65  1.0
    RHS1      EDGE_42_67  1.0
    RHS1      EDGE_61_80  1.0
    RHS1      EDGE_19_74  1.0
    RHS1      EDGE_20_39  1.0
    RHS1      EDGE_30_74  1.0
    RHS1      EDGE_10_16  1.0
    RHS1      EDGE_42_85  1.0
    RHS1      EDGE_2_12  1.0
    RHS1      EDGE_20_48  1.0
    RHS1      EDGE_10_25  1.0
    RHS1      EDGE_39_61  1.0
    RHS1      EDGE_19_92  1.0
    RHS1      EDGE_30_92  1.0
    RHS1      EDGE_62_63  1.0
    RHS1      EDGE_0_88  1.0
    RHS1      EDGE_75_91  1.0
    RHS1      EDGE_83_95  1.0
    RHS1      EDGE_0_97  1.0
    RHS1      EDGE_12_62  1.0
    RHS1      EDGE_13_27  1.0
    RHS1      EDGE_20_75  1.0
    RHS1      EDGE_39_79  1.0
    RHS1      EDGE_41_98  1.0
    RHS1      EDGE_12_71  1.0
    RHS1      EDGE_13_36  1.0
    RHS1      EDGE_23_71  1.0
    RHS1      EDGE_72_76  1.0
    RHS1      EDGE_72_85  1.0
    RHS1      EDGE_12_80  1.0
    RHS1      EDGE_13_45  1.0
    RHS1      EDGE_53_81  1.0
    RHS1      EDGE_32_58  1.0
    RHS1      EDGE_72_94  1.0
    RHS1      EDGE_4_85  1.0
    RHS1      EDGE_13_63  1.0
    RHS1      EDGE_24_63  1.0
    RHS1      EDGE_53_99  1.0
    RHS1      EDGE_65_73  1.0
    RHS1      EDGE_17_33  1.0
    RHS1      EDGE_28_33  1.0
    RHS1      EDGE_76_82  1.0
    RHS1      EDGE_17_42  1.0
    RHS1      EDGE_28_42  1.0
    RHS1      EDGE_9_38  1.0
    RHS1      EDGE_38_74  1.0
    RHS1      EDGE_49_74  1.0
    RHS1      EDGE_57_87  1.0
    RHS1      EDGE_68_87  1.0
    RHS1      EDGE_38_83  1.0
    RHS1      EDGE_49_83  1.0
    RHS1      EDGE_5_58  1.0
    RHS1      EDGE_57_96  1.0
    RHS1      EDGE_58_61  1.0
    RHS1      EDGE_38_92  1.0
    RHS1      EDGE_50_57  1.0
    RHS1      EDGE_58_70  1.0
    RHS1      EDGE_69_70  1.0
    RHS1      EDGE_58_79  1.0
    RHS1      EDGE_30_60  1.0
    RHS1      EDGE_50_75  1.0
    RHS1      EDGE_20_34  1.0
    RHS1      EDGE_61_84  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_42_80  1.0
    RHS1      EDGE_20_43  1.0
    RHS1      EDGE_31_43  1.0
    RHS1      EDGE_19_87  1.0
    RHS1      EDGE_2_16  1.0
    RHS1      EDGE_39_65  1.0
    RHS1      EDGE_20_61  1.0
    RHS1      EDGE_54_63  1.0
    RHS1      EDGE_83_99  1.0
    RHS1      EDGE_41_93  1.0
    RHS1      EDGE_52_93  1.0
    RHS1      EDGE_13_31  1.0
    RHS1      EDGE_24_31  1.0
    RHS1      EDGE_43_44  1.0
    RHS1      EDGE_53_67  1.0
    RHS1      EDGE_64_76  1.0
    RHS1      EDGE_4_71  1.0
    RHS1      EDGE_45_72  1.0
    RHS1      EDGE_72_89  1.0
    RHS1      EDGE_24_49  1.0
    RHS1      EDGE_53_85  1.0
    RHS1      EDGE_4_80  1.0
    RHS1      EDGE_34_81  1.0
    RHS1      EDGE_5_8  1.0
    RHS1      EDGE_1_56  1.0
    RHS1      EDGE_64_85  1.0
    RHS1      EDGE_72_98  1.0
    RHS1      EDGE_16_54  1.0
    RHS1      EDGE_17_19  1.0
    RHS1      EDGE_34_90  1.0
    RHS1      EDGE_65_68  1.0
    RHS1      EDGE_49_51  1.0
    RHS1      EDGE_3_93  1.0
    RHS1      EDGE_37_95  1.0
    RHS1      EDGE_38_60  1.0
    RHS1      EDGE_5_35  1.0
    RHS1      EDGE_49_60  1.0
    RHS1      EDGE_65_86  1.0
    RHS1      EDGE_38_69  1.0
    RHS1      EDGE_68_73  1.0
    RHS1      EDGE_5_44  1.0
    RHS1      EDGE_49_78  1.0
    RHS1      EDGE_18_81  1.0
    RHS1      EDGE_30_46  1.0
    RHS1      EDGE_15_94  1.0
    RHS1      EDGE_84_99  1.0
    RHS1      EDGE_90_97  1.0
    RHS1      EDGE_18_90  1.0
    RHS1      EDGE_8_55  1.0
    RHS1      EDGE_42_57  1.0
    RHS1      EDGE_50_70  1.0
    RHS1      EDGE_42_66  1.0
    RHS1      EDGE_23_25  1.0
    RHS1      EDGE_19_73  1.0
    RHS1      EDGE_42_75  1.0
    RHS1      EDGE_12_34  1.0
    RHS1      EDGE_19_82  1.0
    RHS1      EDGE_74_86  1.0
    RHS1      EDGE_0_78  1.0
    RHS1      EDGE_41_79  1.0
    RHS1      EDGE_31_56  1.0
    RHS1      EDGE_1_15  1.0
    RHS1      EDGE_13_17  1.0
    RHS1      EDGE_53_62  1.0
    RHS1      EDGE_32_39  1.0
    RHS1      EDGE_34_58  1.0
    RHS1      EDGE_44_93  1.0
    RHS1      EDGE_34_67  1.0
    RHS1      EDGE_1_42  1.0
    RHS1      EDGE_13_44  1.0
    RHS1      EDGE_72_93  1.0
    RHS1      EDGE_1_51  1.0
    RHS1      EDGE_64_89  1.0
    RHS1      EDGE_5_12  1.0
    RHS1      EDGE_57_59  1.0
    RHS1      EDGE_37_90  1.0
    RHS1      EDGE_9_19  1.0
    RHS1      EDGE_49_55  1.0
    RHS1      EDGE_15_62  1.0
    RHS1      EDGE_57_77  1.0
    RHS1      EDGE_27_36  1.0
    RHS1      EDGE_6_13  1.0
    RHS1      EDGE_85_89  1.0
    RHS1      EDGE_15_80  1.0
    RHS1      EDGE_27_45  1.0
    RHS1      EDGE_8_41  1.0
    RHS1      EDGE_19_41  1.0
    RHS1      EDGE_27_54  1.0
    RHS1      EDGE_42_43  1.0
    RHS1      EDGE_30_50  1.0
    RHS1      EDGE_71_88  1.0
    RHS1      EDGE_27_63  1.0
    RHS1      EDGE_0_46  1.0
    RHS1      EDGE_18_94  1.0
    RHS1      EDGE_63_93  1.0
    RHS1      EDGE_6_98  1.0
    RHS1      EDGE_39_46  1.0
    RHS1      EDGE_21_96  1.0
    RHS1      EDGE_60_78  1.0
    RHS1      EDGE_23_38  1.0
    RHS1      EDGE_83_89  1.0
    RHS1      EDGE_41_83  1.0
    RHS1      EDGE_60_96  1.0
    RHS1      EDGE_44_79  1.0
    RHS1      EDGE_41_92  1.0
    RHS1      EDGE_10_86  1.0
    RHS1      EDGE_16_17  1.0
    RHS1      EDGE_72_79  1.0
    RHS1      EDGE_22_60  1.0
    RHS1      EDGE_64_75  1.0
    RHS1      EDGE_37_58  1.0
    RHS1      EDGE_34_71  1.0
    RHS1      EDGE_1_46  1.0
    RHS1      EDGE_3_65  1.0
    RHS1      EDGE_56_80  1.0
    RHS1      EDGE_5_7  1.0
    RHS1      EDGE_14_74  1.0
    RHS1      EDGE_45_89  1.0
    RHS1      EDGE_86_90  1.0
    RHS1      EDGE_65_67  1.0
    RHS1      EDGE_15_48  1.0
    RHS1      EDGE_15_57  1.0
    RHS1      EDGE_68_72  1.0
    RHS1      EDGE_7_71  1.0
    RHS1      EDGE_8_36  1.0
    RHS1      EDGE_18_71  1.0
    RHS1      EDGE_50_51  1.0
    RHS1      EDGE_0_32  1.0
    RHS1      EDGE_7_80  1.0
    RHS1      EDGE_19_45  1.0
    RHS1      EDGE_79_87  1.0
    RHS1      EDGE_82_83  1.0
    RHS1      EDGE_90_96  1.0
    RHS1      EDGE_18_89  1.0
    RHS1      EDGE_48_90  1.0
    RHS1      EDGE_30_63  1.0
    RHS1      EDGE_29_95  1.0
    RHS1      EDGE_12_24  1.0
    RHS1      EDGE_52_60  1.0
    RHS1      EDGE_21_91  1.0
    RHS1      EDGE_11_68  1.0
    RHS1      EDGE_12_33  1.0
    RHS1      EDGE_23_33  1.0
    RHS1      EDGE_60_82  1.0
    RHS1      EDGE_12_42  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_75_80  1.0
    RHS1      EDGE_10_72  1.0
    RHS1      EDGE_33_74  1.0
    RHS1      EDGE_75_89  1.0
    RHS1      EDGE_1_14  1.0
    RHS1      EDGE_45_48  1.0
    RHS1      EDGE_52_96  1.0
    RHS1      EDGE_2_77  1.0
    RHS1      EDGE_24_25  1.0
    RHS1      EDGE_25_79  1.0
    RHS1      EDGE_2_86  1.0
    RHS1      EDGE_53_70  1.0
    RHS1      EDGE_10_99  1.0
    RHS1      EDGE_56_66  1.0
    RHS1      EDGE_64_70  1.0
    RHS1      EDGE_25_97  1.0
    RHS1      EDGE_66_98  1.0
    RHS1      EDGE_14_69  1.0
    RHS1      EDGE_56_84  1.0
    RHS1      EDGE_37_80  1.0
    RHS1      EDGE_15_43  1.0
    RHS1      EDGE_22_91  1.0
    RHS1      EDGE_57_58  1.0
    RHS1      EDGE_7_39  1.0
    RHS1      EDGE_49_54  1.0
    RHS1      EDGE_55_88  1.0
    RHS1      EDGE_67_90  1.0
    RHS1      EDGE_18_48  1.0
    RHS1      EDGE_8_13  1.0
    RHS1      EDGE_49_63  1.0
    RHS1      EDGE_70_86  1.0
    RHS1      EDGE_7_57  1.0
    RHS1      EDGE_18_57  1.0
    RHS1      EDGE_47_93  1.0
    RHS1      EDGE_27_35  1.0
    RHS1      EDGE_11_18  1.0
    RHS1      EDGE_7_66  1.0
    RHS1      EDGE_8_31  1.0
    RHS1      EDGE_19_31  1.0
    RHS1      EDGE_30_31  1.0
    RHS1      EDGE_11_27  1.0
    RHS1      EDGE_79_82  1.0
    RHS1      EDGE_19_40  1.0
    RHS1      EDGE_0_36  1.0
    RHS1      EDGE_63_74  1.0
    RHS1      EDGE_48_85  1.0
    RHS1      EDGE_71_87  1.0
    RHS1      EDGE_63_83  1.0
    RHS1      EDGE_48_94  1.0
    RHS1      EDGE_4_6  1.0
    RHS1      EDGE_52_55  1.0
    RHS1      EDGE_20_32  1.0
    RHS1      EDGE_6_97  1.0
    RHS1      EDGE_29_99  1.0
    RHS1      EDGE_21_95  1.0
    RHS1      EDGE_4_24  1.0
    RHS1      EDGE_60_86  1.0
    RHS1      EDGE_44_69  1.0
    RHS1      EDGE_41_82  1.0
    RHS1      EDGE_1_9  1.0
    RHS1      EDGE_1_18  1.0
    RHS1      EDGE_25_74  1.0
    RHS1      EDGE_33_87  1.0
    RHS1      EDGE_34_52  1.0
    RHS1      EDGE_53_56  1.0
    RHS1      EDGE_64_65  1.0
    RHS1      EDGE_3_46  1.0
    RHS1      EDGE_10_94  1.0
    RHS1      EDGE_45_61  1.0
    RHS1      EDGE_51_95  1.0
    RHS1      EDGE_25_92  1.0
    RHS1      EDGE_3_55  1.0
    RHS1      EDGE_14_55  1.0
    RHS1      EDGE_37_57  1.0
    RHS1      EDGE_56_70  1.0
    RHS1      EDGE_2_99  1.0
    RHS1      EDGE_22_77  1.0
    RHS1      EDGE_13_96  1.0
    RHS1      EDGE_47_79  1.0
    RHS1      EDGE_59_81  1.0
    RHS1      EDGE_67_94  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_70_90  1.0
    RHS1      EDGE_17_84  1.0
    RHS1      EDGE_28_84  1.0
    RHS1      EDGE_36_97  1.0
    RHS1      EDGE_8_26  1.0
    RHS1      EDGE_19_26  1.0
    RHS1      EDGE_47_97  1.0
    RHS1      EDGE_0_22  1.0
    RHS1      EDGE_29_76  1.0
    RHS1      EDGE_40_76  1.0
    RHS1      EDGE_63_78  1.0
    RHS1      EDGE_21_72  1.0
    RHS1      EDGE_11_49  1.0
    RHS1      EDGE_12_14  1.0
    RHS1      EDGE_63_87  1.0
    RHS1      EDGE_29_94  1.0
    RHS1      EDGE_12_23  1.0
    RHS1      EDGE_40_94  1.0
    RHS1      EDGE_41_59  1.0
    RHS1      EDGE_4_19  1.0
    RHS1      EDGE_44_55  1.0
    RHS1      EDGE_41_68  1.0
    RHS1      EDGE_81_95  1.0
    RHS1      EDGE_10_62  1.0
    RHS1      EDGE_25_60  1.0
    RHS1      EDGE_33_73  1.0
    RHS1      EDGE_3_32  1.0
    RHS1      EDGE_10_80  1.0
    RHS1      EDGE_44_82  1.0
    RHS1      EDGE_3_41  1.0
    RHS1      EDGE_10_89  1.0
    RHS1      EDGE_14_41  1.0
    RHS1      EDGE_51_90  1.0
    RHS1      EDGE_43_86  1.0
    RHS1      EDGE_14_59  1.0
    RHS1      EDGE_66_97  1.0
    RHS1      EDGE_13_91  1.0
    RHS1      EDGE_7_20  1.0
    RHS1      EDGE_3_68  1.0
    RHS1      EDGE_18_20  1.0
    RHS1      EDGE_26_33  1.0
    RHS1      EDGE_1_98  1.0
    RHS1      EDGE_15_42  1.0
    RHS1      EDGE_16_96  1.0
    RHS1      EDGE_26_42  1.0
    RHS1      EDGE_7_38  1.0
    RHS1      EDGE_67_80  1.0
    RHS1      EDGE_15_51  1.0
    RHS1      EDGE_36_83  1.0
    RHS1      EDGE_8_12  1.0
    RHS1      EDGE_89_98  1.0
    RHS1      EDGE_17_79  1.0
    RHS1      EDGE_28_79  1.0
    RHS1      EDGE_7_56  1.0
    RHS1      EDGE_8_21  1.0
    RHS1      EDGE_9_75  1.0
    RHS1      EDGE_5_86  1.0
    RHS1      EDGE_11_17  1.0
    RHS1      EDGE_18_56  1.0
    RHS1      EDGE_8_30  1.0
    RHS1      EDGE_9_84  1.0
    RHS1      EDGE_47_92  1.0
    RHS1      EDGE_9_93  1.0
    RHS1      EDGE_11_35  1.0
    RHS1      EDGE_29_71  1.0
    RHS1      EDGE_40_71  1.0
    RHS1      EDGE_41_54  1.0
    RHS1      EDGE_4_14  1.0
    RHS1      EDGE_10_48  1.0
    RHS1      EDGE_81_99  1.0
    RHS1      EDGE_52_72  1.0
    RHS1      EDGE_25_55  1.0
    RHS1      EDGE_54_91  1.0
    RHS1      EDGE_33_68  1.0
    RHS1      EDGE_25_64  1.0
    RHS1      EDGE_10_75  1.0
    RHS1      EDGE_34_42  1.0
    RHS1      EDGE_51_76  1.0
    RHS1      EDGE_2_71  1.0
    RHS1      EDGE_25_73  1.0
    RHS1      EDGE_37_38  1.0
    RHS1      EDGE_22_49  1.0
    RHS1      EDGE_14_45  1.0
    RHS1      EDGE_3_54  1.0
    RHS1      EDGE_43_90  1.0
    RHS1      EDGE_66_92  1.0
    RHS1      EDGE_13_86  1.0
    RHS1      EDGE_13_95  1.0
    RHS1      EDGE_16_91  1.0
    RHS1      EDGE_18_33  1.0
    RHS1      EDGE_47_69  1.0
    RHS1      EDGE_26_46  1.0
    RHS1      EDGE_7_42  1.0
    RHS1      EDGE_55_91  1.0
    RHS1      EDGE_5_72  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_17_74  1.0
    RHS1      EDGE_28_74  1.0
    RHS1      EDGE_29_39  1.0
    RHS1      EDGE_17_83  1.0
    RHS1      EDGE_0_12  1.0
    RHS1      EDGE_48_52  1.0
    RHS1      EDGE_9_79  1.0
    RHS1      EDGE_70_89  1.0
    RHS1      EDGE_17_92  1.0
    RHS1      EDGE_0_21  1.0
    RHS1      EDGE_28_92  1.0
    RHS1      EDGE_9_88  1.0
    RHS1      EDGE_69_93  1.0
    RHS1      EDGE_5_99  1.0
    RHS1      EDGE_11_30  1.0
    RHS1      EDGE_63_68  1.0
    RHS1      EDGE_40_75  1.0
    RHS1      EDGE_21_71  1.0
    RHS1      EDGE_81_85  1.0
    RHS1      EDGE_33_45  1.0
    RHS1      EDGE_44_45  1.0
    RHS1      EDGE_62_81  1.0
    RHS1      EDGE_25_41  1.0
    RHS1      EDGE_10_52  1.0
    RHS1      EDGE_44_54  1.0
    RHS1      EDGE_10_61  1.0
    RHS1      EDGE_39_97  1.0
    RHS1      EDGE_2_57  1.0
    RHS1      EDGE_14_22  1.0
    RHS1      EDGE_25_59  1.0
    RHS1      EDGE_51_80  1.0
    RHS1      EDGE_2_75  1.0
    RHS1      EDGE_32_76  1.0
    RHS1      EDGE_24_72  1.0
    RHS1      EDGE_32_85  1.0
    RHS1      EDGE_43_85  1.0
    RHS1      EDGE_66_87  1.0
    RHS1      EDGE_1_79  1.0
    RHS1      EDGE_36_46  1.0
    RHS1      EDGE_66_96  1.0
    RHS1      EDGE_55_59  1.0
    RHS1      EDGE_24_90  1.0
    RHS1      EDGE_47_55  1.0
    RHS1      EDGE_55_68  1.0
    RHS1      EDGE_1_97  1.0
    RHS1      EDGE_7_28  1.0
    RHS1      EDGE_18_28  1.0
    RHS1      EDGE_55_77  1.0
    RHS1      EDGE_85_95  1.0
    RHS1      EDGE_9_56  1.0
    RHS1      EDGE_5_67  1.0
    RHS1      EDGE_28_69  1.0
    RHS1      EDGE_17_78  1.0
    RHS1      EDGE_28_78  1.0
    RHS1      EDGE_29_43  1.0
    RHS1      EDGE_47_91  1.0
    RHS1      EDGE_29_52  1.0
    RHS1      EDGE_40_52  1.0
    RHS1      EDGE_58_88  1.0
    RHS1      EDGE_40_61  1.0
    RHS1      EDGE_58_97  1.0
    RHS1      EDGE_9_92  1.0
    RHS1      EDGE_50_93  1.0
    RHS1      EDGE_10_20  1.0
    RHS1      EDGE_6_68  1.0
    RHS1      EDGE_8_96  1.0
    RHS1      EDGE_25_27  1.0
    RHS1      EDGE_21_75  1.0
    RHS1      EDGE_62_76  1.0
    RHS1      EDGE_2_34  1.0
    RHS1      EDGE_25_36  1.0
    RHS1      EDGE_10_47  1.0
    RHS1      EDGE_20_79  1.0
    RHS1      EDGE_62_94  1.0
    RHS1      EDGE_20_88  1.0
    RHS1      EDGE_32_53  1.0
    RHS1      EDGE_51_66  1.0
    RHS1      EDGE_3_26  1.0
    RHS1      EDGE_12_93  1.0
    RHS1      EDGE_13_58  1.0
    RHS1      EDGE_4_89  1.0
    RHS1      EDGE_85_86  1.0
    RHS1      EDGE_35_67  1.0
    RHS1      EDGE_3_44  1.0
    RHS1      EDGE_1_74  1.0
    RHS1      EDGE_13_76  1.0
    RHS1      EDGE_15_18  1.0
    RHS1      EDGE_24_85  1.0
    RHS1      EDGE_35_85  1.0
    RHS1      EDGE_28_46  1.0
    RHS1      EDGE_24_94  1.0
    RHS1      EDGE_18_23  1.0
    RHS1      EDGE_88_97  1.0
    RHS1      EDGE_55_72  1.0
    RHS1      EDGE_5_53  1.0
    RHS1      EDGE_17_55  1.0
    RHS1      EDGE_46_91  1.0
    RHS1      EDGE_9_51  1.0
    RHS1      EDGE_6_27  1.0
    RHS1      EDGE_36_77  1.0
    RHS1      EDGE_77_78  1.0
    RHS1      EDGE_21_25  1.0
    RHS1      EDGE_5_71  1.0
    RHS1      EDGE_6_36  1.0
    RHS1      EDGE_28_73  1.0
    RHS1      EDGE_58_74  1.0
    RHS1      EDGE_21_34  1.0
    RHS1      EDGE_28_82  1.0
    RHS1      EDGE_40_47  1.0
    RHS1      EDGE_69_83  1.0
    RHS1      EDGE_9_78  1.0
    RHS1      EDGE_42_84  1.0
    RHS1      EDGE_61_97  1.0
    RHS1      EDGE_19_91  1.0
    RHS1      EDGE_2_20  1.0
    RHS1      EDGE_42_93  1.0
    RHS1      EDGE_10_33  1.0
    RHS1      EDGE_33_35  1.0
    RHS1      EDGE_39_69  1.0
    RHS1      EDGE_20_65  1.0
    RHS1      EDGE_25_31  1.0
    RHS1      EDGE_0_96  1.0
    RHS1      EDGE_10_42  1.0
    RHS1      EDGE_39_78  1.0
    RHS1      EDGE_54_67  1.0
    RHS1      EDGE_10_51  1.0
    RHS1      EDGE_12_70  1.0
    RHS1      EDGE_20_83  1.0
    RHS1      EDGE_43_48  1.0
    RHS1      EDGE_84_86  1.0
    RHS1      EDGE_20_92  1.0
    RHS1      EDGE_32_57  1.0
    RHS1      EDGE_43_57  1.0
    RHS1      EDGE_51_70  1.0
    RHS1      EDGE_62_70  1.0
    RHS1      EDGE_14_30  1.0
    RHS1      EDGE_66_68  1.0
    RHS1      EDGE_35_62  1.0
    RHS1      EDGE_66_77  1.0
    RHS1      EDGE_35_71  1.0
    RHS1      EDGE_43_84  1.0
    RHS1      EDGE_28_32  1.0
    RHS1      EDGE_1_78  1.0
    RHS1      EDGE_7_9  1.0
    RHS1      EDGE_36_45  1.0
    RHS1      EDGE_65_81  1.0
    RHS1      EDGE_1_87  1.0
    RHS1      EDGE_13_89  1.0
    RHS1      EDGE_5_48  1.0
    RHS1      EDGE_28_50  1.0
    RHS1      EDGE_9_46  1.0
    RHS1      EDGE_47_72  1.0
    RHS1      EDGE_38_91  1.0
    RHS1      EDGE_29_33  1.0
    RHS1      EDGE_9_64  1.0
    RHS1      EDGE_15_98  1.0
    RHS1      EDGE_50_65  1.0
    RHS1      EDGE_40_42  1.0
    RHS1      EDGE_69_78  1.0
    RHS1      EDGE_21_38  1.0
    RHS1      EDGE_29_51  1.0
    RHS1      EDGE_42_70  1.0
    RHS1      EDGE_69_87  1.0
    RHS1      EDGE_80_87  1.0
    RHS1      EDGE_61_92  1.0
    RHS1      EDGE_27_99  1.0
    RHS1      EDGE_0_82  1.0
    RHS1      EDGE_62_66  1.0
    RHS1      EDGE_20_60  1.0
    RHS1      EDGE_0_91  1.0
    RHS1      EDGE_39_73  1.0
    RHS1      EDGE_73_75  1.0
    RHS1      EDGE_31_69  1.0
    RHS1      EDGE_73_84  1.0
    RHS1      EDGE_31_78  1.0
    RHS1      EDGE_24_39  1.0
    RHS1      EDGE_31_87  1.0
    RHS1      EDGE_35_39  1.0
    RHS1      EDGE_43_52  1.0
    RHS1      EDGE_12_83  1.0
    RHS1      EDGE_13_48  1.0
    RHS1      EDGE_20_96  1.0
    RHS1      EDGE_14_25  1.0
    RHS1      EDGE_35_48  1.0
    RHS1      EDGE_51_65  1.0
    RHS1      EDGE_1_55  1.0
    RHS1      EDGE_13_57  1.0
    RHS1      EDGE_4_88  1.0
    RHS1      EDGE_35_57  1.0
    RHS1      EDGE_51_74  1.0
    RHS1      EDGE_13_66  1.0
    RHS1      EDGE_53_93  1.0
    RHS1      EDGE_45_98  1.0
    RHS1      EDGE_1_73  1.0
    RHS1      EDGE_35_75  1.0
    RHS1      EDGE_36_40  1.0
    RHS1      EDGE_5_34  1.0
    RHS1      EDGE_1_82  1.0
    RHS1      EDGE_46_72  1.0
    RHS1      EDGE_16_80  1.0
    RHS1      EDGE_17_45  1.0
    RHS1      EDGE_88_96  1.0
    RHS1      EDGE_49_86  1.0
    RHS1      EDGE_5_61  1.0
    RHS1      EDGE_6_26  1.0
    RHS1      EDGE_58_64  1.0
    RHS1      EDGE_15_93  1.0
    RHS1      EDGE_5_70  1.0
    RHS1      EDGE_7_89  1.0
    RHS1      EDGE_29_37  1.0
    RHS1      EDGE_77_86  1.0
    RHS1      EDGE_61_69  1.0
    RHS1      EDGE_18_98  1.0
    RHS1      EDGE_21_42  1.0
    RHS1      EDGE_50_78  1.0
    RHS1      EDGE_58_91  1.0
    RHS1      EDGE_8_72  1.0
    RHS1      EDGE_30_72  1.0
    RHS1      EDGE_42_74  1.0
    RHS1      EDGE_10_14  1.0
    RHS1      EDGE_80_91  1.0
    RHS1      EDGE_2_10  1.0
    RHS1      EDGE_27_94  1.0
    RHS1      EDGE_42_92  1.0
    RHS1      EDGE_31_55  1.0
    RHS1      EDGE_0_86  1.0
    RHS1      EDGE_10_32  1.0
    RHS1      EDGE_19_99  1.0
    RHS1      EDGE_2_28  1.0
    RHS1      EDGE_20_64  1.0
    RHS1      EDGE_23_51  1.0
    RHS1      EDGE_23_60  1.0
    RHS1      EDGE_13_25  1.0
    RHS1      EDGE_20_73  1.0
    RHS1      EDGE_30_99  1.0
    RHS1      EDGE_20_82  1.0
    RHS1      EDGE_31_82  1.0
    RHS1      EDGE_72_83  1.0
    RHS1      EDGE_13_43  1.0
    RHS1      EDGE_32_56  1.0
    RHS1      EDGE_72_92  1.0
    RHS1      EDGE_12_87  1.0
    RHS1      EDGE_87_90  1.0
    RHS1      EDGE_13_61  1.0
    RHS1      EDGE_53_97  1.0
    RHS1      EDGE_64_97  1.0
    RHS1      EDGE_34_93  1.0
    RHS1      EDGE_56_93  1.0
    RHS1      EDGE_37_89  1.0
    RHS1      EDGE_36_44  1.0
    RHS1      EDGE_65_80  1.0
    RHS1      EDGE_28_40  1.0
    RHS1      EDGE_9_36  1.0
    RHS1      EDGE_5_47  1.0
    RHS1      EDGE_6_12  1.0
    RHS1      EDGE_46_85  1.0
    RHS1      EDGE_57_85  1.0
    RHS1      EDGE_46_94  1.0
    RHS1      EDGE_57_94  1.0
    RHS1      EDGE_58_59  1.0
    RHS1      EDGE_6_30  1.0
    RHS1      EDGE_50_64  1.0
    RHS1      EDGE_80_86  1.0
    RHS1      EDGE_8_67  1.0
    RHS1      EDGE_42_69  1.0
    RHS1      EDGE_50_82  1.0
    RHS1      EDGE_0_63  1.0
    RHS1      EDGE_39_45  1.0
    RHS1      EDGE_61_82  1.0
    RHS1      EDGE_31_41  1.0
    RHS1      EDGE_70_95  1.0
    RHS1      EDGE_30_85  1.0
    RHS1      EDGE_83_88  1.0
    RHS1      EDGE_62_65  1.0
    RHS1      EDGE_23_46  1.0
    RHS1      EDGE_19_94  1.0
    RHS1      EDGE_4_42  1.0
    RHS1      EDGE_41_91  1.0
    RHS1      EDGE_75_93  1.0
    RHS1      EDGE_32_33  1.0
    RHS1      EDGE_12_64  1.0
    RHS1      EDGE_1_27  1.0
    RHS1      EDGE_32_42  1.0
    RHS1      EDGE_33_96  1.0
    RHS1      EDGE_1_36  1.0
    RHS1      EDGE_4_69  1.0
    RHS1      EDGE_32_51  1.0
    RHS1      EDGE_23_82  1.0
    RHS1      EDGE_72_96  1.0
    RHS1      EDGE_34_79  1.0
    RHS1      EDGE_1_54  1.0
    RHS1      EDGE_16_52  1.0
    RHS1      EDGE_46_53  1.0
    RHS1      EDGE_1_63  1.0
    RHS1      EDGE_56_88  1.0
    RHS1      EDGE_16_61  1.0
    RHS1      EDGE_49_58  1.0
    RHS1      EDGE_17_35  1.0
    RHS1      EDGE_68_71  1.0
    RHS1      EDGE_46_80  1.0
    RHS1      EDGE_68_80  1.0
    RHS1      EDGE_76_93  1.0
    RHS1      EDGE_15_74  1.0
    RHS1      EDGE_46_89  1.0
    RHS1      EDGE_68_89  1.0
    RHS1      EDGE_15_83  1.0
    RHS1      EDGE_68_98  1.0
    RHS1      EDGE_6_25  1.0
    RHS1      EDGE_18_79  1.0
    RHS1      EDGE_8_53  1.0
    RHS1      EDGE_27_66  1.0
    RHS1      EDGE_7_97  1.0
    RHS1      EDGE_50_77  1.0
    RHS1      EDGE_19_71  1.0
    RHS1      EDGE_31_36  1.0
    RHS1      EDGE_10_13  1.0
    RHS1      EDGE_11_67  1.0
    RHS1      EDGE_11_76  1.0
    RHS1      EDGE_75_79  1.0
    RHS1      EDGE_19_89  1.0
    RHS1      EDGE_31_54  1.0
    RHS1      EDGE_4_37  1.0
    RHS1      EDGE_83_92  1.0
    RHS1      EDGE_23_50  1.0
    RHS1      EDGE_91_96  1.0
    RHS1      EDGE_31_63  1.0
    RHS1      EDGE_52_95  1.0
    RHS1      EDGE_13_24  1.0
    RHS1      EDGE_77_88  1.0
    RHS1      EDGE_16_20  1.0
    RHS1      EDGE_23_68  1.0
    RHS1      EDGE_4_64  1.0
    RHS1      EDGE_16_29  1.0
    RHS1      EDGE_53_78  1.0
    RHS1      EDGE_16_38  1.0
    RHS1      EDGE_56_74  1.0
    RHS1      EDGE_24_51  1.0
    RHS1      EDGE_87_89  1.0
    RHS1      EDGE_45_83  1.0
    RHS1      EDGE_22_90  1.0
    RHS1      EDGE_37_88  1.0
    RHS1      EDGE_28_30  1.0
    RHS1      EDGE_5_37  1.0
    RHS1      EDGE_57_75  1.0
    RHS1      EDGE_26_69  1.0
    RHS1      EDGE_15_78  1.0
    RHS1      EDGE_6_20  1.0
    RHS1      EDGE_18_74  1.0
    RHS1      EDGE_26_87  1.0
    RHS1      EDGE_27_52  1.0
    RHS1      EDGE_30_39  1.0
    RHS1      EDGE_18_83  1.0
    RHS1      EDGE_49_89  1.0
    RHS1      EDGE_79_90  1.0
    RHS1      EDGE_61_63  1.0
    RHS1      EDGE_90_99  1.0
    RHS1      EDGE_7_92  1.0
    RHS1      EDGE_8_57  1.0
    RHS1      EDGE_20_22  1.0
    RHS1      EDGE_27_70  1.0
    RHS1      EDGE_11_53  1.0
    RHS1      EDGE_12_18  1.0
    RHS1      EDGE_48_93  1.0
    RHS1      EDGE_63_91  1.0
    RHS1      EDGE_71_95  1.0
    RHS1      EDGE_11_62  1.0
    RHS1      EDGE_23_27  1.0
    RHS1      EDGE_19_75  1.0
    RHS1      EDGE_40_98  1.0
    RHS1      EDGE_11_71  1.0
    RHS1      EDGE_12_36  1.0
    RHS1      EDGE_23_36  1.0
    RHS1      EDGE_31_49  1.0
    RHS1      EDGE_41_72  1.0
    RHS1      EDGE_11_80  1.0
    RHS1      EDGE_23_45  1.0
    RHS1      EDGE_83_96  1.0
    RHS1      EDGE_33_77  1.0
    RHS1      EDGE_13_19  1.0
    RHS1      EDGE_53_55  1.0
    RHS1      EDGE_25_82  1.0
    RHS1      EDGE_72_77  1.0
    RHS1      EDGE_45_60  1.0
    RHS1      EDGE_45_69  1.0
    RHS1      EDGE_56_69  1.0
    RHS1      EDGE_34_78  1.0
    RHS1      EDGE_56_78  1.0
    RHS1      EDGE_53_91  1.0
    RHS1      EDGE_37_83  1.0
    RHS1      EDGE_38_48  1.0
    RHS1      EDGE_56_96  1.0
    RHS1      EDGE_46_61  1.0
    RHS1      EDGE_15_55  1.0
    RHS1      EDGE_57_70  1.0
    RHS1      EDGE_27_29  1.0
    RHS1      EDGE_68_79  1.0
    RHS1      EDGE_7_60  1.0
    RHS1      EDGE_26_73  1.0
    RHS1      EDGE_71_72  1.0
    RHS1      EDGE_15_82  1.0
    RHS1      EDGE_27_47  1.0
    RHS1      EDGE_0_30  1.0
    RHS1      EDGE_18_78  1.0
    RHS1      EDGE_11_39  1.0
    RHS1      EDGE_63_77  1.0
    RHS1      EDGE_30_52  1.0
    RHS1      EDGE_42_54  1.0
    RHS1      EDGE_82_90  1.0
    RHS1      EDGE_29_84  1.0
    RHS1      EDGE_12_13  1.0
    RHS1      EDGE_48_97  1.0
    RHS1      EDGE_71_99  1.0
    RHS1      EDGE_63_95  1.0
    RHS1      EDGE_30_70  1.0
    RHS1      EDGE_0_66  1.0
    RHS1      EDGE_11_66  1.0
    RHS1      EDGE_52_67  1.0
    RHS1      EDGE_31_44  1.0
    RHS1      EDGE_11_75  1.0
    RHS1      EDGE_12_40  1.0
    RHS1      EDGE_1_3  1.0
    RHS1      EDGE_52_76  1.0
    RHS1      EDGE_4_36  1.0
    RHS1      EDGE_83_91  1.0
    RHS1      EDGE_25_68  1.0
    RHS1      EDGE_45_46  1.0
    RHS1      EDGE_1_21  1.0
    RHS1      EDGE_53_59  1.0
    RHS1      EDGE_44_90  1.0
    RHS1      EDGE_16_19  1.0
    RHS1      EDGE_34_55  1.0
    RHS1      EDGE_64_68  1.0
    RHS1      EDGE_33_99  1.0
    RHS1      EDGE_34_64  1.0
    RHS1      EDGE_45_64  1.0
    RHS1      EDGE_1_39  1.0
    RHS1      EDGE_14_58  1.0
    RHS1      EDGE_56_64  1.0
    RHS1      EDGE_22_71  1.0
    RHS1      EDGE_3_76  1.0
    RHS1      EDGE_46_56  1.0
    RHS1      EDGE_86_92  1.0
    RHS1      EDGE_14_85  1.0
    RHS1      EDGE_67_88  1.0
    RHS1      EDGE_22_98  1.0
    RHS1      EDGE_70_84  1.0
    RHS1      EDGE_59_93  1.0
    RHS1      EDGE_8_20  1.0
    RHS1      EDGE_15_68  1.0
    RHS1      EDGE_26_68  1.0
    RHS1      EDGE_49_70  1.0
    RHS1      EDGE_8_29  1.0
    RHS1      EDGE_15_77  1.0
    RHS1      EDGE_27_42  1.0
    RHS1      EDGE_18_73  1.0
    RHS1      EDGE_79_89  1.0
    RHS1      EDGE_71_85  1.0
    RHS1      EDGE_90_98  1.0
    RHS1      EDGE_29_79  1.0
    RHS1      EDGE_71_94  1.0
    RHS1      EDGE_6_86  1.0
    RHS1      EDGE_11_52  1.0
    RHS1      EDGE_41_53  1.0
    RHS1      EDGE_60_66  1.0
    RHS1      EDGE_63_90  1.0
    RHS1      EDGE_6_95  1.0
    RHS1      EDGE_11_61  1.0
    RHS1      EDGE_63_99  1.0
    RHS1      EDGE_44_58  1.0
    RHS1      EDGE_54_58  1.0
    RHS1      EDGE_33_67  1.0
    RHS1      EDGE_60_84  1.0
    RHS1      EDGE_75_82  1.0
    RHS1      EDGE_1_7  1.0
    RHS1      EDGE_10_74  1.0
    RHS1      EDGE_33_76  1.0
    RHS1      EDGE_34_41  1.0
    RHS1      EDGE_13_18  1.0
    RHS1      EDGE_2_70  1.0
    RHS1      EDGE_44_85  1.0
    RHS1      EDGE_34_50  1.0
    RHS1      EDGE_53_54  1.0
    RHS1      EDGE_1_25  1.0
    RHS1      EDGE_25_81  1.0
    RHS1      EDGE_33_94  1.0
    RHS1      EDGE_34_59  1.0
    RHS1      EDGE_44_94  1.0
    RHS1      EDGE_56_59  1.0
    RHS1      EDGE_37_55  1.0
    RHS1      EDGE_66_91  1.0
    RHS1      EDGE_22_66  1.0
    RHS1      EDGE_74_95  1.0
    RHS1      EDGE_2_97  1.0
    RHS1      EDGE_25_99  1.0
    RHS1      EDGE_37_64  1.0
    RHS1      EDGE_56_77  1.0
    RHS1      EDGE_67_74  1.0
    RHS1      EDGE_86_87  1.0
    RHS1      EDGE_3_80  1.0
    RHS1      EDGE_38_56  1.0
    RHS1      EDGE_18_50  1.0
    RHS1      EDGE_59_88  1.0
    RHS1      EDGE_7_59  1.0
    RHS1      EDGE_47_95  1.0
    RHS1      EDGE_48_60  1.0
    RHS1      EDGE_59_97  1.0
    RHS1      EDGE_7_68  1.0
    RHS1      EDGE_19_33  1.0
    RHS1      EDGE_0_29  1.0
    RHS1      EDGE_40_65  1.0
    RHS1      EDGE_63_67  1.0
    RHS1      EDGE_6_72  1.0
    RHS1      EDGE_40_74  1.0
    RHS1      EDGE_19_51  1.0
    RHS1      EDGE_21_70  1.0
    RHS1      EDGE_48_87  1.0
    RHS1      EDGE_6_81  1.0
    RHS1      EDGE_41_48  1.0
    RHS1      EDGE_63_76  1.0
    RHS1      EDGE_20_25  1.0
    RHS1      EDGE_40_92  1.0
    RHS1      EDGE_52_57  1.0
    RHS1      EDGE_21_88  1.0
    RHS1      EDGE_52_66  1.0
    RHS1      EDGE_4_26  1.0
    RHS1      EDGE_10_60  1.0
    RHS1      EDGE_41_75  1.0
    RHS1      EDGE_62_98  1.0
    RHS1      EDGE_4_35  1.0
    RHS1      EDGE_33_71  1.0
    RHS1      EDGE_52_84  1.0
    RHS1      EDGE_1_11  1.0
    RHS1      EDGE_2_65  1.0
    RHS1      EDGE_1_20  1.0
    RHS1      EDGE_33_89  1.0
    RHS1      EDGE_34_54  1.0
    RHS1      EDGE_51_88  1.0
    RHS1      EDGE_25_85  1.0
    RHS1      EDGE_51_97  1.0
    RHS1      EDGE_74_99  1.0
    RHS1      EDGE_14_57  1.0
    RHS1      EDGE_15_22  1.0
    RHS1      EDGE_37_59  1.0
    RHS1      EDGE_3_66  1.0
    RHS1      EDGE_35_98  1.0
    RHS1      EDGE_7_27  1.0
    RHS1      EDGE_3_75  1.0
    RHS1      EDGE_14_75  1.0
    RHS1      EDGE_15_40  1.0
    RHS1      EDGE_38_42  1.0
    RHS1      EDGE_36_72  1.0
    RHS1      EDGE_67_78  1.0
    RHS1      EDGE_67_87  1.0
    RHS1      EDGE_70_74  1.0
    RHS1      EDGE_7_45  1.0
    RHS1      EDGE_59_83  1.0
    RHS1      EDGE_15_58  1.0
    RHS1      EDGE_17_77  1.0
    RHS1      EDGE_70_92  1.0
    RHS1      EDGE_17_86  1.0
    RHS1      EDGE_11_15  1.0
    RHS1      EDGE_27_32  1.0
    RHS1      EDGE_8_28  1.0
    RHS1      EDGE_9_82  1.0
    RHS1      EDGE_19_28  1.0
    RHS1      EDGE_28_86  1.0
    RHS1      EDGE_48_64  1.0
    RHS1      EDGE_30_37  1.0
    RHS1      EDGE_92_98  1.0
    RHS1      EDGE_63_71  1.0
    RHS1      EDGE_48_82  1.0
    RHS1      EDGE_11_42  1.0
    RHS1      EDGE_40_78  1.0
    RHS1      EDGE_41_43  1.0
    RHS1      EDGE_33_39  1.0
    RHS1      EDGE_40_87  1.0
    RHS1      EDGE_41_52  1.0
    RHS1      EDGE_81_97  1.0
    RHS1      EDGE_44_57  1.0
    RHS1      EDGE_62_93  1.0
    RHS1      EDGE_54_98  1.0
    RHS1      EDGE_34_40  1.0
    RHS1      EDGE_25_71  1.0
    RHS1      EDGE_14_34  1.0
    RHS1      EDGE_93_98  1.0
    RHS1      EDGE_66_81  1.0
    RHS1      EDGE_45_58  1.0
    RHS1      EDGE_3_52  1.0
    RHS1      EDGE_35_84  1.0
    RHS1      EDGE_55_62  1.0
    RHS1      EDGE_26_35  1.0
    RHS1      EDGE_36_67  1.0
    RHS1      EDGE_16_98  1.0
    RHS1      EDGE_17_63  1.0
    RHS1      EDGE_67_82  1.0
    RHS1      EDGE_70_78  1.0
    RHS1      EDGE_7_49  1.0
    RHS1      EDGE_47_85  1.0
    RHS1      EDGE_55_98  1.0
    RHS1      EDGE_36_94  1.0
    RHS1      EDGE_19_23  1.0
    RHS1      EDGE_28_90  1.0
    RHS1      EDGE_40_55  1.0
    RHS1      EDGE_48_68  1.0
    RHS1      EDGE_21_60  1.0
    RHS1      EDGE_40_73  1.0
    RHS1      EDGE_41_47  1.0
    RHS1      EDGE_33_43  1.0
    RHS1      EDGE_73_79  1.0
    RHS1      EDGE_52_56  1.0
    RHS1      EDGE_81_92  1.0
    RHS1      EDGE_4_16  1.0
    RHS1      EDGE_44_52  1.0
    RHS1      EDGE_41_65  1.0
    RHS1      EDGE_25_57  1.0
    RHS1      EDGE_3_20  1.0
    RHS1      EDGE_44_70  1.0
    RHS1      EDGE_22_33  1.0
    RHS1      EDGE_54_93  1.0
    RHS1      EDGE_25_66  1.0
    RHS1      EDGE_34_44  1.0
    RHS1      EDGE_74_80  1.0
    RHS1      EDGE_3_38  1.0
    RHS1      EDGE_66_76  1.0
    RHS1      EDGE_51_87  1.0
    RHS1      EDGE_2_82  1.0
    RHS1      EDGE_32_83  1.0
    RHS1      EDGE_43_92  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
 BV BND1      x_80
 BV BND1      x_81
 BV BND1      x_82
 BV BND1      x_83
 BV BND1      x_84
 BV BND1      x_85
 BV BND1      x_86
 BV BND1      x_87
 BV BND1      x_88
 BV BND1      x_89
 BV BND1      x_90
 BV BND1      x_91
 BV BND1      x_92
 BV BND1      x_93
 BV BND1      x_94
 BV BND1      x_95
 BV BND1      x_96
 BV BND1      x_97
 BV BND1      x_98
 BV BND1      x_99
ENDATA
