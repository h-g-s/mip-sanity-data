NAME          cvrp_search_n10_k3_uniform_uniform
ROWS
 N  OBJ
 E  OUT1
 E  IN1
 E  FLOW1
 E  OUT2
 E  IN2
 E  FLOW2
 E  OUT3
 E  IN3
 E  FLOW3
 E  OUT4
 E  IN4
 E  FLOW4
 E  OUT5
 E  IN5
 E  FLOW5
 E  OUT6
 E  IN6
 E  FLOW6
 E  OUT7
 E  IN7
 E  FLOW7
 E  OUT8
 E  IN8
 E  FLOW8
 E  OUT9
 E  IN9
 E  FLOW9
 E  OUT10
 E  IN10
 E  FLOW10
 L  FLEET
 L  CAP0
 L  CAP1
 L  CAP2
 L  CAP3
 L  CAP4
 L  CAP5
 L  CAP6
 L  CAP7
 L  CAP8
 L  CAP9
 L  CAP10
 L  CAP11
 L  CAP12
 L  CAP13
 L  CAP14
 L  CAP15
 L  CAP16
 L  CAP17
 L  CAP18
 L  CAP19
 L  CAP20
 L  CAP21
 L  CAP22
 L  CAP23
 L  CAP24
 L  CAP25
 L  CAP26
 L  CAP27
 L  CAP28
 L  CAP29
 L  CAP30
 L  CAP31
 L  CAP32
 L  CAP33
 L  CAP34
 L  CAP35
 L  CAP36
 L  CAP37
 L  CAP38
 L  CAP39
 L  CAP40
 L  CAP41
 L  CAP42
 L  CAP43
 L  CAP44
 L  CAP45
 L  CAP46
 L  CAP47
 L  CAP48
 L  CAP49
 L  CAP50
 L  CAP51
 L  CAP52
 L  CAP53
 L  CAP54
 L  CAP55
 L  CAP56
 L  CAP57
 L  CAP58
 L  CAP59
 L  CAP60
 L  CAP61
 L  CAP62
 L  CAP63
 L  CAP64
 L  CAP65
 L  CAP66
 L  CAP67
 L  CAP68
 L  CAP69
 L  CAP70
 L  CAP71
 L  CAP72
 L  CAP73
 L  CAP74
 L  CAP75
 L  CAP76
 L  CAP77
 L  CAP78
 L  CAP79
 L  CAP80
 L  CAP81
 L  CAP82
 L  CAP83
 L  CAP84
 L  CAP85
 L  CAP86
 L  CAP87
 L  CAP88
 L  CAP89
 L  CAP90
 L  CAP91
 L  CAP92
 L  CAP93
 L  CAP94
 L  CAP95
 L  CAP96
 L  CAP97
 L  CAP98
 L  CAP99
 G  DLBO1
 L  DUBO1
 G  DLBO2
 L  DUBO2
 G  DLBO3
 L  DUBO3
 G  DLBO4
 L  DUBO4
 G  DLBO5
 L  DUBO5
 G  DLBO6
 L  DUBO6
 G  DLBO7
 L  DUBO7
 G  DLBO8
 L  DUBO8
 G  DLBO9
 L  DUBO9
 G  DLBO10
 L  DUBO10
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0_1          OBJ       41.48
    x0_1          IN1      1
    x0_1          FLOW1   -1
    x0_1          FLEET      1
    x0_1          CAP0    18
    x0_2          OBJ       65.89
    x0_2          IN2      1
    x0_2          FLOW2   -1
    x0_2          FLEET      1
    x0_2          CAP1    18
    x0_3          OBJ       26.02
    x0_3          IN3      1
    x0_3          FLOW3   -1
    x0_3          FLEET      1
    x0_3          CAP2    18
    x0_4          OBJ       21.76
    x0_4          IN4      1
    x0_4          FLOW4   -1
    x0_4          FLEET      1
    x0_4          CAP3    18
    x0_5          OBJ       63.86
    x0_5          IN5      1
    x0_5          FLOW5   -1
    x0_5          FLEET      1
    x0_5          CAP4    18
    x0_6          OBJ       63.71
    x0_6          IN6      1
    x0_6          FLOW6   -1
    x0_6          FLEET      1
    x0_6          CAP5    18
    x0_7          OBJ       52.00
    x0_7          IN7      1
    x0_7          FLOW7   -1
    x0_7          FLEET      1
    x0_7          CAP6    18
    x0_8          OBJ       70.28
    x0_8          IN8      1
    x0_8          FLOW8   -1
    x0_8          FLEET      1
    x0_8          CAP7    18
    x0_9          OBJ       17.10
    x0_9          IN9      1
    x0_9          FLOW9   -1
    x0_9          FLEET      1
    x0_9          CAP8    18
    x0_10         OBJ       69.34
    x0_10         IN10      1
    x0_10         FLOW10   -1
    x0_10         FLEET      1
    x0_10         CAP9    18
    x1_0          OBJ       41.48
    x1_0          OUT1     1
    x1_0          FLOW1    1
    x1_2          OBJ       64.70
    x1_2          OUT1     1
    x1_2          IN2      1
    x1_2          FLOW1    1
    x1_2          FLOW2   -1
    x1_2          CAP10    18
    x1_3          OBJ       63.20
    x1_3          OUT1     1
    x1_3          IN3      1
    x1_3          FLOW1    1
    x1_3          FLOW3   -1
    x1_3          CAP11    18
    x1_4          OBJ       24.29
    x1_4          OUT1     1
    x1_4          IN4      1
    x1_4          FLOW1    1
    x1_4          FLOW4   -1
    x1_4          CAP12    18
    x1_5          OBJ       28.77
    x1_5          OUT1     1
    x1_5          IN5      1
    x1_5          FLOW1    1
    x1_5          FLOW5   -1
    x1_5          CAP13    18
    x1_6          OBJ       24.97
    x1_6          OUT1     1
    x1_6          IN6      1
    x1_6          FLOW1    1
    x1_6          FLOW6   -1
    x1_6          CAP14    18
    x1_7          OBJ       49.40
    x1_7          OUT1     1
    x1_7          IN7      1
    x1_7          FLOW1    1
    x1_7          FLOW7   -1
    x1_7          CAP15    18
    x1_8          OBJ       37.01
    x1_8          OUT1     1
    x1_8          IN8      1
    x1_8          FLOW1    1
    x1_8          FLOW8   -1
    x1_8          CAP16    18
    x1_9          OBJ       57.67
    x1_9          OUT1     1
    x1_9          IN9      1
    x1_9          FLOW1    1
    x1_9          FLOW9   -1
    x1_9          CAP17    18
    x1_10         OBJ       71.22
    x1_10         OUT1     1
    x1_10         IN10      1
    x1_10         FLOW1    1
    x1_10         FLOW10   -1
    x1_10         CAP18    18
    x2_0          OBJ       65.89
    x2_0          OUT2     1
    x2_0          FLOW2    1
    x2_1          OBJ       64.70
    x2_1          OUT2     1
    x2_1          IN1      1
    x2_1          FLOW2    1
    x2_1          FLOW1   -1
    x2_1          CAP19    18
    x2_3          OBJ       61.00
    x2_3          OUT2     1
    x2_3          IN3      1
    x2_3          FLOW2    1
    x2_3          FLOW3   -1
    x2_3          CAP20    18
    x2_4          OBJ       71.93
    x2_4          OUT2     1
    x2_4          IN4      1
    x2_4          FLOW2    1
    x2_4          FLOW4   -1
    x2_4          CAP21    18
    x2_5          OBJ       54.54
    x2_5          OUT2     1
    x2_5          IN5      1
    x2_5          FLOW2    1
    x2_5          FLOW5   -1
    x2_5          CAP22    18
    x2_6          OBJ       85.58
    x2_6          OUT2     1
    x2_6          IN6      1
    x2_6          FLOW2    1
    x2_6          FLOW6   -1
    x2_6          CAP23    18
    x2_7          OBJ       15.77
    x2_7          OUT2     1
    x2_7          IN7      1
    x2_7          FLOW2    1
    x2_7          FLOW7   -1
    x2_7          CAP24    18
    x2_8          OBJ       52.34
    x2_8          OUT2     1
    x2_8          IN8      1
    x2_8          FLOW2    1
    x2_8          FLOW8   -1
    x2_8          CAP25    18
    x2_9          OBJ       67.42
    x2_9          OUT2     1
    x2_9          IN9      1
    x2_9          FLOW2    1
    x2_9          FLOW9   -1
    x2_9          CAP26    18
    x2_10         OBJ       7.26
    x2_10         OUT2     1
    x2_10         IN10      1
    x2_10         FLOW2    1
    x2_10         FLOW10   -1
    x2_10         CAP27    18
    x3_0          OBJ       26.02
    x3_0          OUT3     1
    x3_0          FLOW3    1
    x3_1          OBJ       63.20
    x3_1          OUT3     1
    x3_1          IN1      1
    x3_1          FLOW3    1
    x3_1          FLOW1   -1
    x3_1          CAP28    18
    x3_2          OBJ       61.00
    x3_2          OUT3     1
    x3_2          IN2      1
    x3_2          FLOW3    1
    x3_2          FLOW2   -1
    x3_2          CAP29    18
    x3_4          OBJ       47.37
    x3_4          OUT3     1
    x3_4          IN4      1
    x3_4          FLOW3    1
    x3_4          FLOW4   -1
    x3_4          CAP30    18
    x3_5          OBJ       79.29
    x3_5          OUT3     1
    x3_5          IN5      1
    x3_5          FLOW3    1
    x3_5          FLOW5   -1
    x3_5          CAP31    18
    x3_6          OBJ       87.28
    x3_6          OUT3     1
    x3_6          IN6      1
    x3_6          FLOW3    1
    x3_6          FLOW6   -1
    x3_6          CAP32    18
    x3_7          OBJ       51.81
    x3_7          OUT3     1
    x3_7          IN7      1
    x3_7          FLOW3    1
    x3_7          FLOW7   -1
    x3_7          CAP33    18
    x3_8          OBJ       83.88
    x3_8          OUT3     1
    x3_8          IN8      1
    x3_8          FLOW3    1
    x3_8          FLOW8   -1
    x3_8          CAP34    18
    x3_9          OBJ       11.54
    x3_9          OUT3     1
    x3_9          IN9      1
    x3_9          FLOW3    1
    x3_9          FLOW9   -1
    x3_9          CAP35    18
    x3_10         OBJ       61.73
    x3_10         OUT3     1
    x3_10         IN10      1
    x3_10         FLOW3    1
    x3_10         FLOW10   -1
    x3_10         CAP36    18
    x4_0          OBJ       21.76
    x4_0          OUT4     1
    x4_0          FLOW4    1
    x4_1          OBJ       24.29
    x4_1          OUT4     1
    x4_1          IN1      1
    x4_1          FLOW4    1
    x4_1          FLOW1   -1
    x4_1          CAP37    18
    x4_2          OBJ       71.93
    x4_2          OUT4     1
    x4_2          IN2      1
    x4_2          FLOW4    1
    x4_2          FLOW2   -1
    x4_2          CAP38    18
    x4_3          OBJ       47.37
    x4_3          OUT4     1
    x4_3          IN3      1
    x4_3          FLOW4    1
    x4_3          FLOW3   -1
    x4_3          CAP39    18
    x4_5          OBJ       51.72
    x4_5          OUT4     1
    x4_5          IN5      1
    x4_5          FLOW4    1
    x4_5          FLOW5   -1
    x4_5          CAP40    18
    x4_6          OBJ       43.00
    x4_6          OUT4     1
    x4_6          IN6      1
    x4_6          FLOW4    1
    x4_6          FLOW6   -1
    x4_6          CAP41    18
    x4_7          OBJ       56.33
    x4_7          OUT4     1
    x4_7          IN7      1
    x4_7          FLOW4    1
    x4_7          FLOW7   -1
    x4_7          CAP42    18
    x4_8          OBJ       59.46
    x4_8          OUT4     1
    x4_8          IN8      1
    x4_8          FLOW4    1
    x4_8          FLOW8   -1
    x4_8          CAP43    18
    x4_9          OBJ       38.82
    x4_9          OUT4     1
    x4_9          IN9      1
    x4_9          FLOW4    1
    x4_9          FLOW9   -1
    x4_9          CAP44    18
    x4_10         OBJ       77.08
    x4_10         OUT4     1
    x4_10         IN10      1
    x4_10         FLOW4    1
    x4_10         FLOW10   -1
    x4_10         CAP45    18
    x5_0          OBJ       63.86
    x5_0          OUT5     1
    x5_0          FLOW5    1
    x5_1          OBJ       28.77
    x5_1          OUT5     1
    x5_1          IN1      1
    x5_1          FLOW5    1
    x5_1          FLOW1   -1
    x5_1          CAP46    18
    x5_2          OBJ       54.54
    x5_2          OUT5     1
    x5_2          IN2      1
    x5_2          FLOW5    1
    x5_2          FLOW2   -1
    x5_2          CAP47    18
    x5_3          OBJ       79.29
    x5_3          OUT5     1
    x5_3          IN3      1
    x5_3          FLOW5    1
    x5_3          FLOW3   -1
    x5_3          CAP48    18
    x5_4          OBJ       51.72
    x5_4          OUT5     1
    x5_4          IN4      1
    x5_4          FLOW5    1
    x5_4          FLOW4   -1
    x5_4          CAP49    18
    x5_6          OBJ       36.17
    x5_6          OUT5     1
    x5_6          IN6      1
    x5_6          FLOW5    1
    x5_6          FLOW6   -1
    x5_6          CAP50    18
    x5_7          OBJ       43.31
    x5_7          OUT5     1
    x5_7          IN7      1
    x5_7          FLOW5    1
    x5_7          FLOW7   -1
    x5_7          CAP51    18
    x5_8          OBJ       8.39
    x5_8          OUT5     1
    x5_8          IN8      1
    x5_8          FLOW5    1
    x5_8          FLOW8   -1
    x5_8          CAP52    18
    x5_9          OBJ       77.32
    x5_9          OUT5     1
    x5_9          IN9      1
    x5_9          FLOW5    1
    x5_9          FLOW9   -1
    x5_9          CAP53    18
    x5_10         OBJ       61.80
    x5_10         OUT5     1
    x5_10         IN10      1
    x5_10         FLOW5    1
    x5_10         FLOW10   -1
    x5_10         CAP54    18
    x6_0          OBJ       63.71
    x6_0          OUT6     1
    x6_0          FLOW6    1
    x6_1          OBJ       24.97
    x6_1          OUT6     1
    x6_1          IN1      1
    x6_1          FLOW6    1
    x6_1          FLOW1   -1
    x6_1          CAP55    18
    x6_2          OBJ       85.58
    x6_2          OUT6     1
    x6_2          IN2      1
    x6_2          FLOW6    1
    x6_2          FLOW2   -1
    x6_2          CAP56    18
    x6_3          OBJ       87.28
    x6_3          OUT6     1
    x6_3          IN3      1
    x6_3          FLOW6    1
    x6_3          FLOW3   -1
    x6_3          CAP57    18
    x6_4          OBJ       43.00
    x6_4          OUT6     1
    x6_4          IN4      1
    x6_4          FLOW6    1
    x6_4          FLOW4   -1
    x6_4          CAP58    18
    x6_5          OBJ       36.17
    x6_5          OUT6     1
    x6_5          IN5      1
    x6_5          FLOW6    1
    x6_5          FLOW5   -1
    x6_5          CAP59    18
    x6_7          OBJ       71.30
    x6_7          OUT6     1
    x6_7          IN7      1
    x6_7          FLOW6    1
    x6_7          FLOW7   -1
    x6_7          CAP60    18
    x6_8          OBJ       43.59
    x6_8          OUT6     1
    x6_8          IN8      1
    x6_8          FLOW6    1
    x6_8          FLOW8   -1
    x6_8          CAP61    18
    x6_9          OBJ       80.62
    x6_9          OUT6     1
    x6_9          IN9      1
    x6_9          FLOW6    1
    x6_9          FLOW9   -1
    x6_9          CAP62    18
    x6_10         OBJ       92.55
    x6_10         OUT6     1
    x6_10         IN10      1
    x6_10         FLOW6    1
    x6_10         FLOW10   -1
    x6_10         CAP63    18
    x7_0          OBJ       52.00
    x7_0          OUT7     1
    x7_0          FLOW7    1
    x7_1          OBJ       49.40
    x7_1          OUT7     1
    x7_1          IN1      1
    x7_1          FLOW7    1
    x7_1          FLOW1   -1
    x7_1          CAP64    18
    x7_2          OBJ       15.77
    x7_2          OUT7     1
    x7_2          IN2      1
    x7_2          FLOW7    1
    x7_2          FLOW2   -1
    x7_2          CAP65    18
    x7_3          OBJ       51.81
    x7_3          OUT7     1
    x7_3          IN3      1
    x7_3          FLOW7    1
    x7_3          FLOW3   -1
    x7_3          CAP66    18
    x7_4          OBJ       56.33
    x7_4          OUT7     1
    x7_4          IN4      1
    x7_4          FLOW7    1
    x7_4          FLOW4   -1
    x7_4          CAP67    18
    x7_5          OBJ       43.31
    x7_5          OUT7     1
    x7_5          IN5      1
    x7_5          FLOW7    1
    x7_5          FLOW5   -1
    x7_5          CAP68    18
    x7_6          OBJ       71.30
    x7_6          OUT7     1
    x7_6          IN6      1
    x7_6          FLOW7    1
    x7_6          FLOW6   -1
    x7_6          CAP69    18
    x7_8          OBJ       43.17
    x7_8          OUT7     1
    x7_8          IN8      1
    x7_8          FLOW7    1
    x7_8          FLOW8   -1
    x7_8          CAP70    18
    x7_9          OBJ       56.16
    x7_9          OUT7     1
    x7_9          IN9      1
    x7_9          FLOW7    1
    x7_9          FLOW9   -1
    x7_9          CAP71    18
    x7_10         OBJ       21.86
    x7_10         OUT7     1
    x7_10         IN10      1
    x7_10         FLOW7    1
    x7_10         FLOW10   -1
    x7_10         CAP72    18
    x8_0          OBJ       70.28
    x8_0          OUT8     1
    x8_0          FLOW8    1
    x8_1          OBJ       37.01
    x8_1          OUT8     1
    x8_1          IN1      1
    x8_1          FLOW8    1
    x8_1          FLOW1   -1
    x8_1          CAP73    18
    x8_2          OBJ       52.34
    x8_2          OUT8     1
    x8_2          IN2      1
    x8_2          FLOW8    1
    x8_2          FLOW2   -1
    x8_2          CAP74    18
    x8_3          OBJ       83.88
    x8_3          OUT8     1
    x8_3          IN3      1
    x8_3          FLOW8    1
    x8_3          FLOW3   -1
    x8_3          CAP75    18
    x8_4          OBJ       59.46
    x8_4          OUT8     1
    x8_4          IN4      1
    x8_4          FLOW8    1
    x8_4          FLOW4   -1
    x8_4          CAP76    18
    x8_5          OBJ       8.39
    x8_5          OUT8     1
    x8_5          IN5      1
    x8_5          FLOW8    1
    x8_5          FLOW5   -1
    x8_5          CAP77    18
    x8_6          OBJ       43.59
    x8_6          OUT8     1
    x8_6          IN6      1
    x8_6          FLOW8    1
    x8_6          FLOW6   -1
    x8_6          CAP78    18
    x8_7          OBJ       43.17
    x8_7          OUT8     1
    x8_7          IN7      1
    x8_7          FLOW8    1
    x8_7          FLOW7   -1
    x8_7          CAP79    18
    x8_9          OBJ       82.86
    x8_9          OUT8     1
    x8_9          IN9      1
    x8_9          FLOW8    1
    x8_9          FLOW9   -1
    x8_9          CAP80    18
    x8_10         OBJ       59.54
    x8_10         OUT8     1
    x8_10         IN10      1
    x8_10         FLOW8    1
    x8_10         FLOW10   -1
    x8_10         CAP81    18
    x9_0          OBJ       17.10
    x9_0          OUT9     1
    x9_0          FLOW9    1
    x9_1          OBJ       57.67
    x9_1          OUT9     1
    x9_1          IN1      1
    x9_1          FLOW9    1
    x9_1          FLOW1   -1
    x9_1          CAP82    18
    x9_2          OBJ       67.42
    x9_2          OUT9     1
    x9_2          IN2      1
    x9_2          FLOW9    1
    x9_2          FLOW2   -1
    x9_2          CAP83    18
    x9_3          OBJ       11.54
    x9_3          OUT9     1
    x9_3          IN3      1
    x9_3          FLOW9    1
    x9_3          FLOW3   -1
    x9_3          CAP84    18
    x9_4          OBJ       38.82
    x9_4          OUT9     1
    x9_4          IN4      1
    x9_4          FLOW9    1
    x9_4          FLOW4   -1
    x9_4          CAP85    18
    x9_5          OBJ       77.32
    x9_5          OUT9     1
    x9_5          IN5      1
    x9_5          FLOW9    1
    x9_5          FLOW5   -1
    x9_5          CAP86    18
    x9_6          OBJ       80.62
    x9_6          OUT9     1
    x9_6          IN6      1
    x9_6          FLOW9    1
    x9_6          FLOW6   -1
    x9_6          CAP87    18
    x9_7          OBJ       56.16
    x9_7          OUT9     1
    x9_7          IN7      1
    x9_7          FLOW9    1
    x9_7          FLOW7   -1
    x9_7          CAP88    18
    x9_8          OBJ       82.86
    x9_8          OUT9     1
    x9_8          IN8      1
    x9_8          FLOW9    1
    x9_8          FLOW8   -1
    x9_8          CAP89    18
    x9_10         OBJ       69.17
    x9_10         OUT9     1
    x9_10         IN10      1
    x9_10         FLOW9    1
    x9_10         FLOW10   -1
    x9_10         CAP90    18
    x10_0         OBJ       69.34
    x10_0         OUT10     1
    x10_0         FLOW10    1
    x10_1         OBJ       71.22
    x10_1         OUT10     1
    x10_1         IN1      1
    x10_1         FLOW10    1
    x10_1         FLOW1   -1
    x10_1         CAP91    18
    x10_2         OBJ       7.26
    x10_2         OUT10     1
    x10_2         IN2      1
    x10_2         FLOW10    1
    x10_2         FLOW2   -1
    x10_2         CAP92    18
    x10_3         OBJ       61.73
    x10_3         OUT10     1
    x10_3         IN3      1
    x10_3         FLOW10    1
    x10_3         FLOW3   -1
    x10_3         CAP93    18
    x10_4         OBJ       77.08
    x10_4         OUT10     1
    x10_4         IN4      1
    x10_4         FLOW10    1
    x10_4         FLOW4   -1
    x10_4         CAP94    18
    x10_5         OBJ       61.80
    x10_5         OUT10     1
    x10_5         IN5      1
    x10_5         FLOW10    1
    x10_5         FLOW5   -1
    x10_5         CAP95    18
    x10_6         OBJ       92.55
    x10_6         OUT10     1
    x10_6         IN6      1
    x10_6         FLOW10    1
    x10_6         FLOW6   -1
    x10_6         CAP96    18
    x10_7         OBJ       21.86
    x10_7         OUT10     1
    x10_7         IN7      1
    x10_7         FLOW10    1
    x10_7         FLOW7   -1
    x10_7         CAP97    18
    x10_8         OBJ       59.54
    x10_8         OUT10     1
    x10_8         IN8      1
    x10_8         FLOW10    1
    x10_8         FLOW8   -1
    x10_8         CAP98    18
    x10_9         OBJ       69.17
    x10_9         OUT10     1
    x10_9         IN9      1
    x10_9         FLOW10    1
    x10_9         FLOW9   -1
    x10_9         CAP99    18
    MARK0000  'MARKER'                 'INTEND'
    u1            CAP0    -1
    u1            CAP10     1
    u1            CAP11     1
    u1            CAP12     1
    u1            CAP13     1
    u1            CAP14     1
    u1            CAP15     1
    u1            CAP16     1
    u1            CAP17     1
    u1            CAP18     1
    u1            CAP19    -1
    u1            CAP28    -1
    u1            CAP37    -1
    u1            CAP46    -1
    u1            CAP55    -1
    u1            CAP64    -1
    u1            CAP73    -1
    u1            CAP82    -1
    u1            CAP91    -1
    u1            DLBO1    1
    u1            DUBO1    1
    u2            CAP1    -1
    u2            CAP10    -1
    u2            CAP19     1
    u2            CAP20     1
    u2            CAP21     1
    u2            CAP22     1
    u2            CAP23     1
    u2            CAP24     1
    u2            CAP25     1
    u2            CAP26     1
    u2            CAP27     1
    u2            CAP29    -1
    u2            CAP38    -1
    u2            CAP47    -1
    u2            CAP56    -1
    u2            CAP65    -1
    u2            CAP74    -1
    u2            CAP83    -1
    u2            CAP92    -1
    u2            DLBO2    1
    u2            DUBO2    1
    u3            CAP2    -1
    u3            CAP11    -1
    u3            CAP20    -1
    u3            CAP28     1
    u3            CAP29     1
    u3            CAP30     1
    u3            CAP31     1
    u3            CAP32     1
    u3            CAP33     1
    u3            CAP34     1
    u3            CAP35     1
    u3            CAP36     1
    u3            CAP39    -1
    u3            CAP48    -1
    u3            CAP57    -1
    u3            CAP66    -1
    u3            CAP75    -1
    u3            CAP84    -1
    u3            CAP93    -1
    u3            DLBO3    1
    u3            DUBO3    1
    u4            CAP3    -1
    u4            CAP12    -1
    u4            CAP21    -1
    u4            CAP30    -1
    u4            CAP37     1
    u4            CAP38     1
    u4            CAP39     1
    u4            CAP40     1
    u4            CAP41     1
    u4            CAP42     1
    u4            CAP43     1
    u4            CAP44     1
    u4            CAP45     1
    u4            CAP49    -1
    u4            CAP58    -1
    u4            CAP67    -1
    u4            CAP76    -1
    u4            CAP85    -1
    u4            CAP94    -1
    u4            DLBO4    1
    u4            DUBO4    1
    u5            CAP4    -1
    u5            CAP13    -1
    u5            CAP22    -1
    u5            CAP31    -1
    u5            CAP40    -1
    u5            CAP46     1
    u5            CAP47     1
    u5            CAP48     1
    u5            CAP49     1
    u5            CAP50     1
    u5            CAP51     1
    u5            CAP52     1
    u5            CAP53     1
    u5            CAP54     1
    u5            CAP59    -1
    u5            CAP68    -1
    u5            CAP77    -1
    u5            CAP86    -1
    u5            CAP95    -1
    u5            DLBO5    1
    u5            DUBO5    1
    u6            CAP5    -1
    u6            CAP14    -1
    u6            CAP23    -1
    u6            CAP32    -1
    u6            CAP41    -1
    u6            CAP50    -1
    u6            CAP55     1
    u6            CAP56     1
    u6            CAP57     1
    u6            CAP58     1
    u6            CAP59     1
    u6            CAP60     1
    u6            CAP61     1
    u6            CAP62     1
    u6            CAP63     1
    u6            CAP69    -1
    u6            CAP78    -1
    u6            CAP87    -1
    u6            CAP96    -1
    u6            DLBO6    1
    u6            DUBO6    1
    u7            CAP6    -1
    u7            CAP15    -1
    u7            CAP24    -1
    u7            CAP33    -1
    u7            CAP42    -1
    u7            CAP51    -1
    u7            CAP60    -1
    u7            CAP64     1
    u7            CAP65     1
    u7            CAP66     1
    u7            CAP67     1
    u7            CAP68     1
    u7            CAP69     1
    u7            CAP70     1
    u7            CAP71     1
    u7            CAP72     1
    u7            CAP79    -1
    u7            CAP88    -1
    u7            CAP97    -1
    u7            DLBO7    1
    u7            DUBO7    1
    u8            CAP7    -1
    u8            CAP16    -1
    u8            CAP25    -1
    u8            CAP34    -1
    u8            CAP43    -1
    u8            CAP52    -1
    u8            CAP61    -1
    u8            CAP70    -1
    u8            CAP73     1
    u8            CAP74     1
    u8            CAP75     1
    u8            CAP76     1
    u8            CAP77     1
    u8            CAP78     1
    u8            CAP79     1
    u8            CAP80     1
    u8            CAP81     1
    u8            CAP89    -1
    u8            CAP98    -1
    u8            DLBO8    1
    u8            DUBO8    1
    u9            CAP8    -1
    u9            CAP17    -1
    u9            CAP26    -1
    u9            CAP35    -1
    u9            CAP44    -1
    u9            CAP53    -1
    u9            CAP62    -1
    u9            CAP71    -1
    u9            CAP80    -1
    u9            CAP82     1
    u9            CAP83     1
    u9            CAP84     1
    u9            CAP85     1
    u9            CAP86     1
    u9            CAP87     1
    u9            CAP88     1
    u9            CAP89     1
    u9            CAP90     1
    u9            CAP99    -1
    u9            DLBO9    1
    u9            DUBO9    1
    u10           CAP9    -1
    u10           CAP18    -1
    u10           CAP27    -1
    u10           CAP36    -1
    u10           CAP45    -1
    u10           CAP54    -1
    u10           CAP63    -1
    u10           CAP72    -1
    u10           CAP81    -1
    u10           CAP90    -1
    u10           CAP91     1
    u10           CAP92     1
    u10           CAP93     1
    u10           CAP94     1
    u10           CAP95     1
    u10           CAP96     1
    u10           CAP97     1
    u10           CAP98     1
    u10           CAP99     1
    u10           DLBO10    1
    u10           DUBO10    1
RHS
    RHS1      OUT1      1
    RHS1      IN1       1
    RHS1      OUT2      1
    RHS1      IN2       1
    RHS1      OUT3      1
    RHS1      IN3       1
    RHS1      OUT4      1
    RHS1      IN4       1
    RHS1      OUT5      1
    RHS1      IN5       1
    RHS1      OUT6      1
    RHS1      IN6       1
    RHS1      OUT7      1
    RHS1      IN7       1
    RHS1      OUT8      1
    RHS1      IN8       1
    RHS1      OUT9      1
    RHS1      IN9       1
    RHS1      OUT10      1
    RHS1      IN10       1
    RHS1      FLEET      3
    RHS1      CAP0     12
    RHS1      CAP1     14
    RHS1      CAP2     14
    RHS1      CAP3     12
    RHS1      CAP4     13
    RHS1      CAP5     14
    RHS1      CAP6     14
    RHS1      CAP7     14
    RHS1      CAP8     12
    RHS1      CAP9     14
    RHS1      CAP10     14
    RHS1      CAP11     14
    RHS1      CAP12     12
    RHS1      CAP13     13
    RHS1      CAP14     14
    RHS1      CAP15     14
    RHS1      CAP16     14
    RHS1      CAP17     12
    RHS1      CAP18     14
    RHS1      CAP19     12
    RHS1      CAP20     14
    RHS1      CAP21     12
    RHS1      CAP22     13
    RHS1      CAP23     14
    RHS1      CAP24     14
    RHS1      CAP25     14
    RHS1      CAP26     12
    RHS1      CAP27     14
    RHS1      CAP28     12
    RHS1      CAP29     14
    RHS1      CAP30     12
    RHS1      CAP31     13
    RHS1      CAP32     14
    RHS1      CAP33     14
    RHS1      CAP34     14
    RHS1      CAP35     12
    RHS1      CAP36     14
    RHS1      CAP37     12
    RHS1      CAP38     14
    RHS1      CAP39     14
    RHS1      CAP40     13
    RHS1      CAP41     14
    RHS1      CAP42     14
    RHS1      CAP43     14
    RHS1      CAP44     12
    RHS1      CAP45     14
    RHS1      CAP46     12
    RHS1      CAP47     14
    RHS1      CAP48     14
    RHS1      CAP49     12
    RHS1      CAP50     14
    RHS1      CAP51     14
    RHS1      CAP52     14
    RHS1      CAP53     12
    RHS1      CAP54     14
    RHS1      CAP55     12
    RHS1      CAP56     14
    RHS1      CAP57     14
    RHS1      CAP58     12
    RHS1      CAP59     13
    RHS1      CAP60     14
    RHS1      CAP61     14
    RHS1      CAP62     12
    RHS1      CAP63     14
    RHS1      CAP64     12
    RHS1      CAP65     14
    RHS1      CAP66     14
    RHS1      CAP67     12
    RHS1      CAP68     13
    RHS1      CAP69     14
    RHS1      CAP70     14
    RHS1      CAP71     12
    RHS1      CAP72     14
    RHS1      CAP73     12
    RHS1      CAP74     14
    RHS1      CAP75     14
    RHS1      CAP76     12
    RHS1      CAP77     13
    RHS1      CAP78     14
    RHS1      CAP79     14
    RHS1      CAP80     12
    RHS1      CAP81     14
    RHS1      CAP82     12
    RHS1      CAP83     14
    RHS1      CAP84     14
    RHS1      CAP85     12
    RHS1      CAP86     13
    RHS1      CAP87     14
    RHS1      CAP88     14
    RHS1      CAP89     14
    RHS1      CAP90     14
    RHS1      CAP91     12
    RHS1      CAP92     14
    RHS1      CAP93     14
    RHS1      CAP94     12
    RHS1      CAP95     13
    RHS1      CAP96     14
    RHS1      CAP97     14
    RHS1      CAP98     14
    RHS1      CAP99     12
    RHS1      DLBO1    6
    RHS1      DUBO1    18
    RHS1      DLBO2    4
    RHS1      DUBO2    18
    RHS1      DLBO3    4
    RHS1      DUBO3    18
    RHS1      DLBO4    6
    RHS1      DUBO4    18
    RHS1      DLBO5    5
    RHS1      DUBO5    18
    RHS1      DLBO6    4
    RHS1      DUBO6    18
    RHS1      DLBO7    4
    RHS1      DUBO7    18
    RHS1      DLBO8    4
    RHS1      DUBO8    18
    RHS1      DLBO9    6
    RHS1      DUBO9    18
    RHS1      DLBO10    4
    RHS1      DUBO10    18
BOUNDS
ENDATA
