NAME          upms_search_n8_m2_cmax_p5-18_s2-9_sd42
ROWS
 N  OBJ
 E  asgn_0
 E  asgn_1
 E  asgn_2
 E  asgn_3
 E  asgn_4
 E  asgn_5
 E  asgn_6
 E  asgn_7
 G  lb_0_0
 G  lb_0_1
 G  lb_1_0
 G  lb_1_1
 G  lb_2_0
 G  lb_2_1
 G  lb_3_0
 G  lb_3_1
 G  lb_4_0
 G  lb_4_1
 G  lb_5_0
 G  lb_5_1
 G  lb_6_0
 G  lb_6_1
 G  lb_7_0
 G  lb_7_1
 G  prA_0_1_0
 G  prB_0_1_0
 G  prA_0_1_1
 G  prB_0_1_1
 G  prA_0_2_0
 G  prB_0_2_0
 G  prA_0_2_1
 G  prB_0_2_1
 G  prA_0_3_0
 G  prB_0_3_0
 G  prA_0_3_1
 G  prB_0_3_1
 G  prA_0_4_0
 G  prB_0_4_0
 G  prA_0_4_1
 G  prB_0_4_1
 G  prA_0_5_0
 G  prB_0_5_0
 G  prA_0_5_1
 G  prB_0_5_1
 G  prA_0_6_0
 G  prB_0_6_0
 G  prA_0_6_1
 G  prB_0_6_1
 G  prA_0_7_0
 G  prB_0_7_0
 G  prA_0_7_1
 G  prB_0_7_1
 G  prA_1_2_0
 G  prB_1_2_0
 G  prA_1_2_1
 G  prB_1_2_1
 G  prA_1_3_0
 G  prB_1_3_0
 G  prA_1_3_1
 G  prB_1_3_1
 G  prA_1_4_0
 G  prB_1_4_0
 G  prA_1_4_1
 G  prB_1_4_1
 G  prA_1_5_0
 G  prB_1_5_0
 G  prA_1_5_1
 G  prB_1_5_1
 G  prA_1_6_0
 G  prB_1_6_0
 G  prA_1_6_1
 G  prB_1_6_1
 G  prA_1_7_0
 G  prB_1_7_0
 G  prA_1_7_1
 G  prB_1_7_1
 G  prA_2_3_0
 G  prB_2_3_0
 G  prA_2_3_1
 G  prB_2_3_1
 G  prA_2_4_0
 G  prB_2_4_0
 G  prA_2_4_1
 G  prB_2_4_1
 G  prA_2_5_0
 G  prB_2_5_0
 G  prA_2_5_1
 G  prB_2_5_1
 G  prA_2_6_0
 G  prB_2_6_0
 G  prA_2_6_1
 G  prB_2_6_1
 G  prA_2_7_0
 G  prB_2_7_0
 G  prA_2_7_1
 G  prB_2_7_1
 G  prA_3_4_0
 G  prB_3_4_0
 G  prA_3_4_1
 G  prB_3_4_1
 G  prA_3_5_0
 G  prB_3_5_0
 G  prA_3_5_1
 G  prB_3_5_1
 G  prA_3_6_0
 G  prB_3_6_0
 G  prA_3_6_1
 G  prB_3_6_1
 G  prA_3_7_0
 G  prB_3_7_0
 G  prA_3_7_1
 G  prB_3_7_1
 G  prA_4_5_0
 G  prB_4_5_0
 G  prA_4_5_1
 G  prB_4_5_1
 G  prA_4_6_0
 G  prB_4_6_0
 G  prA_4_6_1
 G  prB_4_6_1
 G  prA_4_7_0
 G  prB_4_7_0
 G  prA_4_7_1
 G  prB_4_7_1
 G  prA_5_6_0
 G  prB_5_6_0
 G  prA_5_6_1
 G  prB_5_6_1
 G  prA_5_7_0
 G  prB_5_7_0
 G  prA_5_7_1
 G  prB_5_7_1
 G  prA_6_7_0
 G  prB_6_7_0
 G  prA_6_7_1
 G  prB_6_7_1
 G  cmax_0
 G  cmax_1
 G  cmax_2
 G  cmax_3
 G  cmax_4
 G  cmax_5
 G  cmax_6
 G  cmax_7
COLUMNS
    Cmax            OBJ           1.0
    Cmax            cmax_0          1.0
    Cmax            cmax_1          1.0
    Cmax            cmax_2          1.0
    Cmax            cmax_3          1.0
    Cmax            cmax_4          1.0
    Cmax            cmax_5          1.0
    Cmax            cmax_6          1.0
    Cmax            cmax_7          1.0
    C_0             lb_0_0          1.0
    C_0             lb_0_1          1.0
    C_0             prA_0_1_0       -1.0
    C_0             prB_0_1_0       1.0
    C_0             prA_0_1_1       -1.0
    C_0             prB_0_1_1       1.0
    C_0             prA_0_2_0       -1.0
    C_0             prB_0_2_0       1.0
    C_0             prA_0_2_1       -1.0
    C_0             prB_0_2_1       1.0
    C_0             prA_0_3_0       -1.0
    C_0             prB_0_3_0       1.0
    C_0             prA_0_3_1       -1.0
    C_0             prB_0_3_1       1.0
    C_0             prA_0_4_0       -1.0
    C_0             prB_0_4_0       1.0
    C_0             prA_0_4_1       -1.0
    C_0             prB_0_4_1       1.0
    C_0             prA_0_5_0       -1.0
    C_0             prB_0_5_0       1.0
    C_0             prA_0_5_1       -1.0
    C_0             prB_0_5_1       1.0
    C_0             prA_0_6_0       -1.0
    C_0             prB_0_6_0       1.0
    C_0             prA_0_6_1       -1.0
    C_0             prB_0_6_1       1.0
    C_0             prA_0_7_0       -1.0
    C_0             prB_0_7_0       1.0
    C_0             prA_0_7_1       -1.0
    C_0             prB_0_7_1       1.0
    C_0             cmax_0          -1.0
    C_1             lb_1_0          1.0
    C_1             lb_1_1          1.0
    C_1             prA_0_1_0       1.0
    C_1             prB_0_1_0       -1.0
    C_1             prA_0_1_1       1.0
    C_1             prB_0_1_1       -1.0
    C_1             prA_1_2_0       -1.0
    C_1             prB_1_2_0       1.0
    C_1             prA_1_2_1       -1.0
    C_1             prB_1_2_1       1.0
    C_1             prA_1_3_0       -1.0
    C_1             prB_1_3_0       1.0
    C_1             prA_1_3_1       -1.0
    C_1             prB_1_3_1       1.0
    C_1             prA_1_4_0       -1.0
    C_1             prB_1_4_0       1.0
    C_1             prA_1_4_1       -1.0
    C_1             prB_1_4_1       1.0
    C_1             prA_1_5_0       -1.0
    C_1             prB_1_5_0       1.0
    C_1             prA_1_5_1       -1.0
    C_1             prB_1_5_1       1.0
    C_1             prA_1_6_0       -1.0
    C_1             prB_1_6_0       1.0
    C_1             prA_1_6_1       -1.0
    C_1             prB_1_6_1       1.0
    C_1             prA_1_7_0       -1.0
    C_1             prB_1_7_0       1.0
    C_1             prA_1_7_1       -1.0
    C_1             prB_1_7_1       1.0
    C_1             cmax_1          -1.0
    C_2             lb_2_0          1.0
    C_2             lb_2_1          1.0
    C_2             prA_0_2_0       1.0
    C_2             prB_0_2_0       -1.0
    C_2             prA_0_2_1       1.0
    C_2             prB_0_2_1       -1.0
    C_2             prA_1_2_0       1.0
    C_2             prB_1_2_0       -1.0
    C_2             prA_1_2_1       1.0
    C_2             prB_1_2_1       -1.0
    C_2             prA_2_3_0       -1.0
    C_2             prB_2_3_0       1.0
    C_2             prA_2_3_1       -1.0
    C_2             prB_2_3_1       1.0
    C_2             prA_2_4_0       -1.0
    C_2             prB_2_4_0       1.0
    C_2             prA_2_4_1       -1.0
    C_2             prB_2_4_1       1.0
    C_2             prA_2_5_0       -1.0
    C_2             prB_2_5_0       1.0
    C_2             prA_2_5_1       -1.0
    C_2             prB_2_5_1       1.0
    C_2             prA_2_6_0       -1.0
    C_2             prB_2_6_0       1.0
    C_2             prA_2_6_1       -1.0
    C_2             prB_2_6_1       1.0
    C_2             prA_2_7_0       -1.0
    C_2             prB_2_7_0       1.0
    C_2             prA_2_7_1       -1.0
    C_2             prB_2_7_1       1.0
    C_2             cmax_2          -1.0
    C_3             lb_3_0          1.0
    C_3             lb_3_1          1.0
    C_3             prA_0_3_0       1.0
    C_3             prB_0_3_0       -1.0
    C_3             prA_0_3_1       1.0
    C_3             prB_0_3_1       -1.0
    C_3             prA_1_3_0       1.0
    C_3             prB_1_3_0       -1.0
    C_3             prA_1_3_1       1.0
    C_3             prB_1_3_1       -1.0
    C_3             prA_2_3_0       1.0
    C_3             prB_2_3_0       -1.0
    C_3             prA_2_3_1       1.0
    C_3             prB_2_3_1       -1.0
    C_3             prA_3_4_0       -1.0
    C_3             prB_3_4_0       1.0
    C_3             prA_3_4_1       -1.0
    C_3             prB_3_4_1       1.0
    C_3             prA_3_5_0       -1.0
    C_3             prB_3_5_0       1.0
    C_3             prA_3_5_1       -1.0
    C_3             prB_3_5_1       1.0
    C_3             prA_3_6_0       -1.0
    C_3             prB_3_6_0       1.0
    C_3             prA_3_6_1       -1.0
    C_3             prB_3_6_1       1.0
    C_3             prA_3_7_0       -1.0
    C_3             prB_3_7_0       1.0
    C_3             prA_3_7_1       -1.0
    C_3             prB_3_7_1       1.0
    C_3             cmax_3          -1.0
    C_4             lb_4_0          1.0
    C_4             lb_4_1          1.0
    C_4             prA_0_4_0       1.0
    C_4             prB_0_4_0       -1.0
    C_4             prA_0_4_1       1.0
    C_4             prB_0_4_1       -1.0
    C_4             prA_1_4_0       1.0
    C_4             prB_1_4_0       -1.0
    C_4             prA_1_4_1       1.0
    C_4             prB_1_4_1       -1.0
    C_4             prA_2_4_0       1.0
    C_4             prB_2_4_0       -1.0
    C_4             prA_2_4_1       1.0
    C_4             prB_2_4_1       -1.0
    C_4             prA_3_4_0       1.0
    C_4             prB_3_4_0       -1.0
    C_4             prA_3_4_1       1.0
    C_4             prB_3_4_1       -1.0
    C_4             prA_4_5_0       -1.0
    C_4             prB_4_5_0       1.0
    C_4             prA_4_5_1       -1.0
    C_4             prB_4_5_1       1.0
    C_4             prA_4_6_0       -1.0
    C_4             prB_4_6_0       1.0
    C_4             prA_4_6_1       -1.0
    C_4             prB_4_6_1       1.0
    C_4             prA_4_7_0       -1.0
    C_4             prB_4_7_0       1.0
    C_4             prA_4_7_1       -1.0
    C_4             prB_4_7_1       1.0
    C_4             cmax_4          -1.0
    C_5             lb_5_0          1.0
    C_5             lb_5_1          1.0
    C_5             prA_0_5_0       1.0
    C_5             prB_0_5_0       -1.0
    C_5             prA_0_5_1       1.0
    C_5             prB_0_5_1       -1.0
    C_5             prA_1_5_0       1.0
    C_5             prB_1_5_0       -1.0
    C_5             prA_1_5_1       1.0
    C_5             prB_1_5_1       -1.0
    C_5             prA_2_5_0       1.0
    C_5             prB_2_5_0       -1.0
    C_5             prA_2_5_1       1.0
    C_5             prB_2_5_1       -1.0
    C_5             prA_3_5_0       1.0
    C_5             prB_3_5_0       -1.0
    C_5             prA_3_5_1       1.0
    C_5             prB_3_5_1       -1.0
    C_5             prA_4_5_0       1.0
    C_5             prB_4_5_0       -1.0
    C_5             prA_4_5_1       1.0
    C_5             prB_4_5_1       -1.0
    C_5             prA_5_6_0       -1.0
    C_5             prB_5_6_0       1.0
    C_5             prA_5_6_1       -1.0
    C_5             prB_5_6_1       1.0
    C_5             prA_5_7_0       -1.0
    C_5             prB_5_7_0       1.0
    C_5             prA_5_7_1       -1.0
    C_5             prB_5_7_1       1.0
    C_5             cmax_5          -1.0
    C_6             lb_6_0          1.0
    C_6             lb_6_1          1.0
    C_6             prA_0_6_0       1.0
    C_6             prB_0_6_0       -1.0
    C_6             prA_0_6_1       1.0
    C_6             prB_0_6_1       -1.0
    C_6             prA_1_6_0       1.0
    C_6             prB_1_6_0       -1.0
    C_6             prA_1_6_1       1.0
    C_6             prB_1_6_1       -1.0
    C_6             prA_2_6_0       1.0
    C_6             prB_2_6_0       -1.0
    C_6             prA_2_6_1       1.0
    C_6             prB_2_6_1       -1.0
    C_6             prA_3_6_0       1.0
    C_6             prB_3_6_0       -1.0
    C_6             prA_3_6_1       1.0
    C_6             prB_3_6_1       -1.0
    C_6             prA_4_6_0       1.0
    C_6             prB_4_6_0       -1.0
    C_6             prA_4_6_1       1.0
    C_6             prB_4_6_1       -1.0
    C_6             prA_5_6_0       1.0
    C_6             prB_5_6_0       -1.0
    C_6             prA_5_6_1       1.0
    C_6             prB_5_6_1       -1.0
    C_6             prA_6_7_0       -1.0
    C_6             prB_6_7_0       1.0
    C_6             prA_6_7_1       -1.0
    C_6             prB_6_7_1       1.0
    C_6             cmax_6          -1.0
    C_7             lb_7_0          1.0
    C_7             lb_7_1          1.0
    C_7             prA_0_7_0       1.0
    C_7             prB_0_7_0       -1.0
    C_7             prA_0_7_1       1.0
    C_7             prB_0_7_1       -1.0
    C_7             prA_1_7_0       1.0
    C_7             prB_1_7_0       -1.0
    C_7             prA_1_7_1       1.0
    C_7             prB_1_7_1       -1.0
    C_7             prA_2_7_0       1.0
    C_7             prB_2_7_0       -1.0
    C_7             prA_2_7_1       1.0
    C_7             prB_2_7_1       -1.0
    C_7             prA_3_7_0       1.0
    C_7             prB_3_7_0       -1.0
    C_7             prA_3_7_1       1.0
    C_7             prB_3_7_1       -1.0
    C_7             prA_4_7_0       1.0
    C_7             prB_4_7_0       -1.0
    C_7             prA_4_7_1       1.0
    C_7             prB_4_7_1       -1.0
    C_7             prA_5_7_0       1.0
    C_7             prB_5_7_0       -1.0
    C_7             prA_5_7_1       1.0
    C_7             prB_5_7_1       -1.0
    C_7             prA_6_7_0       1.0
    C_7             prB_6_7_0       -1.0
    C_7             prA_6_7_1       1.0
    C_7             prB_6_7_1       -1.0
    C_7             cmax_7          -1.0
    MARK0000  'MARKER'                 'INTORG'
    x_0_0           asgn_0          1.0
    x_0_0           lb_0_0          -216
    x_0_0           prA_0_1_0       -216
    x_0_0           prB_0_1_0       -216
    x_0_0           prA_0_2_0       -216
    x_0_0           prB_0_2_0       -216
    x_0_0           prA_0_3_0       -216
    x_0_0           prB_0_3_0       -216
    x_0_0           prA_0_4_0       -216
    x_0_0           prB_0_4_0       -216
    x_0_0           prA_0_5_0       -216
    x_0_0           prB_0_5_0       -216
    x_0_0           prA_0_6_0       -216
    x_0_0           prB_0_6_0       -216
    x_0_0           prA_0_7_0       -216
    x_0_0           prB_0_7_0       -216
    x_0_1           asgn_0          1.0
    x_0_1           lb_0_1          -216
    x_0_1           prA_0_1_1       -216
    x_0_1           prB_0_1_1       -216
    x_0_1           prA_0_2_1       -216
    x_0_1           prB_0_2_1       -216
    x_0_1           prA_0_3_1       -216
    x_0_1           prB_0_3_1       -216
    x_0_1           prA_0_4_1       -216
    x_0_1           prB_0_4_1       -216
    x_0_1           prA_0_5_1       -216
    x_0_1           prB_0_5_1       -216
    x_0_1           prA_0_6_1       -216
    x_0_1           prB_0_6_1       -216
    x_0_1           prA_0_7_1       -216
    x_0_1           prB_0_7_1       -216
    x_1_0           asgn_1          1.0
    x_1_0           lb_1_0          -216
    x_1_0           prA_0_1_0       -216
    x_1_0           prB_0_1_0       -216
    x_1_0           prA_1_2_0       -216
    x_1_0           prB_1_2_0       -216
    x_1_0           prA_1_3_0       -216
    x_1_0           prB_1_3_0       -216
    x_1_0           prA_1_4_0       -216
    x_1_0           prB_1_4_0       -216
    x_1_0           prA_1_5_0       -216
    x_1_0           prB_1_5_0       -216
    x_1_0           prA_1_6_0       -216
    x_1_0           prB_1_6_0       -216
    x_1_0           prA_1_7_0       -216
    x_1_0           prB_1_7_0       -216
    x_1_1           asgn_1          1.0
    x_1_1           lb_1_1          -216
    x_1_1           prA_0_1_1       -216
    x_1_1           prB_0_1_1       -216
    x_1_1           prA_1_2_1       -216
    x_1_1           prB_1_2_1       -216
    x_1_1           prA_1_3_1       -216
    x_1_1           prB_1_3_1       -216
    x_1_1           prA_1_4_1       -216
    x_1_1           prB_1_4_1       -216
    x_1_1           prA_1_5_1       -216
    x_1_1           prB_1_5_1       -216
    x_1_1           prA_1_6_1       -216
    x_1_1           prB_1_6_1       -216
    x_1_1           prA_1_7_1       -216
    x_1_1           prB_1_7_1       -216
    x_2_0           asgn_2          1.0
    x_2_0           lb_2_0          -216
    x_2_0           prA_0_2_0       -216
    x_2_0           prB_0_2_0       -216
    x_2_0           prA_1_2_0       -216
    x_2_0           prB_1_2_0       -216
    x_2_0           prA_2_3_0       -216
    x_2_0           prB_2_3_0       -216
    x_2_0           prA_2_4_0       -216
    x_2_0           prB_2_4_0       -216
    x_2_0           prA_2_5_0       -216
    x_2_0           prB_2_5_0       -216
    x_2_0           prA_2_6_0       -216
    x_2_0           prB_2_6_0       -216
    x_2_0           prA_2_7_0       -216
    x_2_0           prB_2_7_0       -216
    x_2_1           asgn_2          1.0
    x_2_1           lb_2_1          -216
    x_2_1           prA_0_2_1       -216
    x_2_1           prB_0_2_1       -216
    x_2_1           prA_1_2_1       -216
    x_2_1           prB_1_2_1       -216
    x_2_1           prA_2_3_1       -216
    x_2_1           prB_2_3_1       -216
    x_2_1           prA_2_4_1       -216
    x_2_1           prB_2_4_1       -216
    x_2_1           prA_2_5_1       -216
    x_2_1           prB_2_5_1       -216
    x_2_1           prA_2_6_1       -216
    x_2_1           prB_2_6_1       -216
    x_2_1           prA_2_7_1       -216
    x_2_1           prB_2_7_1       -216
    x_3_0           asgn_3          1.0
    x_3_0           lb_3_0          -216
    x_3_0           prA_0_3_0       -216
    x_3_0           prB_0_3_0       -216
    x_3_0           prA_1_3_0       -216
    x_3_0           prB_1_3_0       -216
    x_3_0           prA_2_3_0       -216
    x_3_0           prB_2_3_0       -216
    x_3_0           prA_3_4_0       -216
    x_3_0           prB_3_4_0       -216
    x_3_0           prA_3_5_0       -216
    x_3_0           prB_3_5_0       -216
    x_3_0           prA_3_6_0       -216
    x_3_0           prB_3_6_0       -216
    x_3_0           prA_3_7_0       -216
    x_3_0           prB_3_7_0       -216
    x_3_1           asgn_3          1.0
    x_3_1           lb_3_1          -216
    x_3_1           prA_0_3_1       -216
    x_3_1           prB_0_3_1       -216
    x_3_1           prA_1_3_1       -216
    x_3_1           prB_1_3_1       -216
    x_3_1           prA_2_3_1       -216
    x_3_1           prB_2_3_1       -216
    x_3_1           prA_3_4_1       -216
    x_3_1           prB_3_4_1       -216
    x_3_1           prA_3_5_1       -216
    x_3_1           prB_3_5_1       -216
    x_3_1           prA_3_6_1       -216
    x_3_1           prB_3_6_1       -216
    x_3_1           prA_3_7_1       -216
    x_3_1           prB_3_7_1       -216
    x_4_0           asgn_4          1.0
    x_4_0           lb_4_0          -216
    x_4_0           prA_0_4_0       -216
    x_4_0           prB_0_4_0       -216
    x_4_0           prA_1_4_0       -216
    x_4_0           prB_1_4_0       -216
    x_4_0           prA_2_4_0       -216
    x_4_0           prB_2_4_0       -216
    x_4_0           prA_3_4_0       -216
    x_4_0           prB_3_4_0       -216
    x_4_0           prA_4_5_0       -216
    x_4_0           prB_4_5_0       -216
    x_4_0           prA_4_6_0       -216
    x_4_0           prB_4_6_0       -216
    x_4_0           prA_4_7_0       -216
    x_4_0           prB_4_7_0       -216
    x_4_1           asgn_4          1.0
    x_4_1           lb_4_1          -216
    x_4_1           prA_0_4_1       -216
    x_4_1           prB_0_4_1       -216
    x_4_1           prA_1_4_1       -216
    x_4_1           prB_1_4_1       -216
    x_4_1           prA_2_4_1       -216
    x_4_1           prB_2_4_1       -216
    x_4_1           prA_3_4_1       -216
    x_4_1           prB_3_4_1       -216
    x_4_1           prA_4_5_1       -216
    x_4_1           prB_4_5_1       -216
    x_4_1           prA_4_6_1       -216
    x_4_1           prB_4_6_1       -216
    x_4_1           prA_4_7_1       -216
    x_4_1           prB_4_7_1       -216
    x_5_0           asgn_5          1.0
    x_5_0           lb_5_0          -216
    x_5_0           prA_0_5_0       -216
    x_5_0           prB_0_5_0       -216
    x_5_0           prA_1_5_0       -216
    x_5_0           prB_1_5_0       -216
    x_5_0           prA_2_5_0       -216
    x_5_0           prB_2_5_0       -216
    x_5_0           prA_3_5_0       -216
    x_5_0           prB_3_5_0       -216
    x_5_0           prA_4_5_0       -216
    x_5_0           prB_4_5_0       -216
    x_5_0           prA_5_6_0       -216
    x_5_0           prB_5_6_0       -216
    x_5_0           prA_5_7_0       -216
    x_5_0           prB_5_7_0       -216
    x_5_1           asgn_5          1.0
    x_5_1           lb_5_1          -216
    x_5_1           prA_0_5_1       -216
    x_5_1           prB_0_5_1       -216
    x_5_1           prA_1_5_1       -216
    x_5_1           prB_1_5_1       -216
    x_5_1           prA_2_5_1       -216
    x_5_1           prB_2_5_1       -216
    x_5_1           prA_3_5_1       -216
    x_5_1           prB_3_5_1       -216
    x_5_1           prA_4_5_1       -216
    x_5_1           prB_4_5_1       -216
    x_5_1           prA_5_6_1       -216
    x_5_1           prB_5_6_1       -216
    x_5_1           prA_5_7_1       -216
    x_5_1           prB_5_7_1       -216
    x_6_0           asgn_6          1.0
    x_6_0           lb_6_0          -216
    x_6_0           prA_0_6_0       -216
    x_6_0           prB_0_6_0       -216
    x_6_0           prA_1_6_0       -216
    x_6_0           prB_1_6_0       -216
    x_6_0           prA_2_6_0       -216
    x_6_0           prB_2_6_0       -216
    x_6_0           prA_3_6_0       -216
    x_6_0           prB_3_6_0       -216
    x_6_0           prA_4_6_0       -216
    x_6_0           prB_4_6_0       -216
    x_6_0           prA_5_6_0       -216
    x_6_0           prB_5_6_0       -216
    x_6_0           prA_6_7_0       -216
    x_6_0           prB_6_7_0       -216
    x_6_1           asgn_6          1.0
    x_6_1           lb_6_1          -216
    x_6_1           prA_0_6_1       -216
    x_6_1           prB_0_6_1       -216
    x_6_1           prA_1_6_1       -216
    x_6_1           prB_1_6_1       -216
    x_6_1           prA_2_6_1       -216
    x_6_1           prB_2_6_1       -216
    x_6_1           prA_3_6_1       -216
    x_6_1           prB_3_6_1       -216
    x_6_1           prA_4_6_1       -216
    x_6_1           prB_4_6_1       -216
    x_6_1           prA_5_6_1       -216
    x_6_1           prB_5_6_1       -216
    x_6_1           prA_6_7_1       -216
    x_6_1           prB_6_7_1       -216
    x_7_0           asgn_7          1.0
    x_7_0           lb_7_0          -216
    x_7_0           prA_0_7_0       -216
    x_7_0           prB_0_7_0       -216
    x_7_0           prA_1_7_0       -216
    x_7_0           prB_1_7_0       -216
    x_7_0           prA_2_7_0       -216
    x_7_0           prB_2_7_0       -216
    x_7_0           prA_3_7_0       -216
    x_7_0           prB_3_7_0       -216
    x_7_0           prA_4_7_0       -216
    x_7_0           prB_4_7_0       -216
    x_7_0           prA_5_7_0       -216
    x_7_0           prB_5_7_0       -216
    x_7_0           prA_6_7_0       -216
    x_7_0           prB_6_7_0       -216
    x_7_1           asgn_7          1.0
    x_7_1           lb_7_1          -216
    x_7_1           prA_0_7_1       -216
    x_7_1           prB_0_7_1       -216
    x_7_1           prA_1_7_1       -216
    x_7_1           prB_1_7_1       -216
    x_7_1           prA_2_7_1       -216
    x_7_1           prB_2_7_1       -216
    x_7_1           prA_3_7_1       -216
    x_7_1           prB_3_7_1       -216
    x_7_1           prA_4_7_1       -216
    x_7_1           prB_4_7_1       -216
    x_7_1           prA_5_7_1       -216
    x_7_1           prB_5_7_1       -216
    x_7_1           prA_6_7_1       -216
    x_7_1           prB_6_7_1       -216
    d_0_1_0         prA_0_1_0       -216
    d_0_1_0         prB_0_1_0       216
    d_0_1_1         prA_0_1_1       -216
    d_0_1_1         prB_0_1_1       216
    d_0_2_0         prA_0_2_0       -216
    d_0_2_0         prB_0_2_0       216
    d_0_2_1         prA_0_2_1       -216
    d_0_2_1         prB_0_2_1       216
    d_0_3_0         prA_0_3_0       -216
    d_0_3_0         prB_0_3_0       216
    d_0_3_1         prA_0_3_1       -216
    d_0_3_1         prB_0_3_1       216
    d_0_4_0         prA_0_4_0       -216
    d_0_4_0         prB_0_4_0       216
    d_0_4_1         prA_0_4_1       -216
    d_0_4_1         prB_0_4_1       216
    d_0_5_0         prA_0_5_0       -216
    d_0_5_0         prB_0_5_0       216
    d_0_5_1         prA_0_5_1       -216
    d_0_5_1         prB_0_5_1       216
    d_0_6_0         prA_0_6_0       -216
    d_0_6_0         prB_0_6_0       216
    d_0_6_1         prA_0_6_1       -216
    d_0_6_1         prB_0_6_1       216
    d_0_7_0         prA_0_7_0       -216
    d_0_7_0         prB_0_7_0       216
    d_0_7_1         prA_0_7_1       -216
    d_0_7_1         prB_0_7_1       216
    d_1_2_0         prA_1_2_0       -216
    d_1_2_0         prB_1_2_0       216
    d_1_2_1         prA_1_2_1       -216
    d_1_2_1         prB_1_2_1       216
    d_1_3_0         prA_1_3_0       -216
    d_1_3_0         prB_1_3_0       216
    d_1_3_1         prA_1_3_1       -216
    d_1_3_1         prB_1_3_1       216
    d_1_4_0         prA_1_4_0       -216
    d_1_4_0         prB_1_4_0       216
    d_1_4_1         prA_1_4_1       -216
    d_1_4_1         prB_1_4_1       216
    d_1_5_0         prA_1_5_0       -216
    d_1_5_0         prB_1_5_0       216
    d_1_5_1         prA_1_5_1       -216
    d_1_5_1         prB_1_5_1       216
    d_1_6_0         prA_1_6_0       -216
    d_1_6_0         prB_1_6_0       216
    d_1_6_1         prA_1_6_1       -216
    d_1_6_1         prB_1_6_1       216
    d_1_7_0         prA_1_7_0       -216
    d_1_7_0         prB_1_7_0       216
    d_1_7_1         prA_1_7_1       -216
    d_1_7_1         prB_1_7_1       216
    d_2_3_0         prA_2_3_0       -216
    d_2_3_0         prB_2_3_0       216
    d_2_3_1         prA_2_3_1       -216
    d_2_3_1         prB_2_3_1       216
    d_2_4_0         prA_2_4_0       -216
    d_2_4_0         prB_2_4_0       216
    d_2_4_1         prA_2_4_1       -216
    d_2_4_1         prB_2_4_1       216
    d_2_5_0         prA_2_5_0       -216
    d_2_5_0         prB_2_5_0       216
    d_2_5_1         prA_2_5_1       -216
    d_2_5_1         prB_2_5_1       216
    d_2_6_0         prA_2_6_0       -216
    d_2_6_0         prB_2_6_0       216
    d_2_6_1         prA_2_6_1       -216
    d_2_6_1         prB_2_6_1       216
    d_2_7_0         prA_2_7_0       -216
    d_2_7_0         prB_2_7_0       216
    d_2_7_1         prA_2_7_1       -216
    d_2_7_1         prB_2_7_1       216
    d_3_4_0         prA_3_4_0       -216
    d_3_4_0         prB_3_4_0       216
    d_3_4_1         prA_3_4_1       -216
    d_3_4_1         prB_3_4_1       216
    d_3_5_0         prA_3_5_0       -216
    d_3_5_0         prB_3_5_0       216
    d_3_5_1         prA_3_5_1       -216
    d_3_5_1         prB_3_5_1       216
    d_3_6_0         prA_3_6_0       -216
    d_3_6_0         prB_3_6_0       216
    d_3_6_1         prA_3_6_1       -216
    d_3_6_1         prB_3_6_1       216
    d_3_7_0         prA_3_7_0       -216
    d_3_7_0         prB_3_7_0       216
    d_3_7_1         prA_3_7_1       -216
    d_3_7_1         prB_3_7_1       216
    d_4_5_0         prA_4_5_0       -216
    d_4_5_0         prB_4_5_0       216
    d_4_5_1         prA_4_5_1       -216
    d_4_5_1         prB_4_5_1       216
    d_4_6_0         prA_4_6_0       -216
    d_4_6_0         prB_4_6_0       216
    d_4_6_1         prA_4_6_1       -216
    d_4_6_1         prB_4_6_1       216
    d_4_7_0         prA_4_7_0       -216
    d_4_7_0         prB_4_7_0       216
    d_4_7_1         prA_4_7_1       -216
    d_4_7_1         prB_4_7_1       216
    d_5_6_0         prA_5_6_0       -216
    d_5_6_0         prB_5_6_0       216
    d_5_6_1         prA_5_6_1       -216
    d_5_6_1         prB_5_6_1       216
    d_5_7_0         prA_5_7_0       -216
    d_5_7_0         prB_5_7_0       216
    d_5_7_1         prA_5_7_1       -216
    d_5_7_1         prB_5_7_1       216
    d_6_7_0         prA_6_7_0       -216
    d_6_7_0         prB_6_7_0       216
    d_6_7_1         prA_6_7_1       -216
    d_6_7_1         prB_6_7_1       216
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS           asgn_0          1.0
    RHS           asgn_1          1.0
    RHS           asgn_2          1.0
    RHS           asgn_3          1.0
    RHS           asgn_4          1.0
    RHS           asgn_5          1.0
    RHS           asgn_6          1.0
    RHS           asgn_7          1.0
    RHS           lb_0_0          -198
    RHS           lb_0_1          -210
    RHS           lb_1_0          -209
    RHS           lb_1_1          -200
    RHS           lb_2_0          -203
    RHS           lb_2_1          -208
    RHS           lb_3_0          -204
    RHS           lb_3_1          -209
    RHS           lb_4_0          -198
    RHS           lb_4_1          -210
    RHS           lb_5_0          -198
    RHS           lb_5_1          -200
    RHS           lb_6_0          -198
    RHS           lb_6_1          -210
    RHS           lb_7_0          -198
    RHS           lb_7_1          -205
    RHS           prA_0_1_0       -639
    RHS           prB_0_1_0       -407
    RHS           prA_0_1_1       -630
    RHS           prB_0_1_1       -420
    RHS           prA_0_2_0       -632
    RHS           prB_0_2_0       -411
    RHS           prA_0_2_1       -635
    RHS           prB_0_2_1       -418
    RHS           prA_0_3_0       -631
    RHS           prB_0_3_0       -408
    RHS           prA_0_3_1       -639
    RHS           prB_0_3_1       -417
    RHS           prA_0_4_0       -625
    RHS           prB_0_4_0       -408
    RHS           prA_0_4_1       -634
    RHS           prB_0_4_1       -421
    RHS           prA_0_5_0       -625
    RHS           prB_0_5_0       -406
    RHS           prA_0_5_1       -623
    RHS           prB_0_5_1       -417
    RHS           prA_0_6_0       -624
    RHS           prB_0_6_0       -412
    RHS           prA_0_6_1       -640
    RHS           prB_0_6_1       -423
    RHS           prA_0_7_0       -626
    RHS           prB_0_7_0       -411
    RHS           prA_0_7_1       -629
    RHS           prB_0_7_1       -420
    RHS           prA_1_2_0       -631
    RHS           prB_1_2_0       -422
    RHS           prA_1_2_1       -635
    RHS           prB_1_2_1       -410
    RHS           prA_1_3_0       -629
    RHS           prB_1_3_0       -418
    RHS           prA_1_3_1       -638
    RHS           prB_1_3_1       -412
    RHS           prA_1_4_0       -627
    RHS           prB_1_4_0       -418
    RHS           prA_1_4_1       -634
    RHS           prB_1_4_1       -414
    RHS           prA_1_5_0       -627
    RHS           prB_1_5_0       -421
    RHS           prA_1_5_1       -625
    RHS           prB_1_5_1       -410
    RHS           prA_1_6_0       -623
    RHS           prB_1_6_0       -421
    RHS           prA_1_6_1       -636
    RHS           prB_1_6_1       -412
    RHS           prA_1_7_0       -628
    RHS           prB_1_7_0       -417
    RHS           prA_1_7_1       -628
    RHS           prB_1_7_1       -412
    RHS           prA_2_3_0       -629
    RHS           prB_2_3_0       -412
    RHS           prA_2_3_1       -636
    RHS           prB_2_3_1       -417
    RHS           prA_2_4_0       -627
    RHS           prB_2_4_0       -414
    RHS           prA_2_4_1       -640
    RHS           prB_2_4_1       -422
    RHS           prA_2_5_0       -625
    RHS           prB_2_5_0       -415
    RHS           prA_2_5_1       -626
    RHS           prB_2_5_1       -419
    RHS           prA_2_6_0       -627
    RHS           prB_2_6_0       -411
    RHS           prA_2_6_1       -637
    RHS           prB_2_6_1       -421
    RHS           prA_2_7_0       -627
    RHS           prB_2_7_0       -410
    RHS           prA_2_7_1       -629
    RHS           prB_2_7_1       -422
    RHS           prA_3_4_0       -625
    RHS           prB_3_4_0       -413
    RHS           prA_3_4_1       -636
    RHS           prB_3_4_1       -417
    RHS           prA_3_5_0       -627
    RHS           prB_3_5_0       -414
    RHS           prA_3_5_1       -628
    RHS           prB_3_5_1       -417
    RHS           prA_3_6_0       -625
    RHS           prB_3_6_0       -412
    RHS           prA_3_6_1       -638
    RHS           prB_3_6_1       -417
    RHS           prA_3_7_0       -621
    RHS           prB_3_7_0       -414
    RHS           prA_3_7_1       -629
    RHS           prB_3_7_1       -421
    RHS           prA_4_5_0       -624
    RHS           prB_4_5_0       -406
    RHS           prA_4_5_1       -629
    RHS           prB_4_5_1       -419
    RHS           prA_4_6_0       -625
    RHS           prB_4_6_0       -405
    RHS           prA_4_6_1       -635
    RHS           prB_4_6_1       -420
    RHS           prA_4_7_0       -625
    RHS           prB_4_7_0       -411
    RHS           prA_4_7_1       -628
    RHS           prB_4_7_1       -420
    RHS           prA_5_6_0       -625
    RHS           prB_5_6_0       -412
    RHS           prA_5_6_1       -638
    RHS           prB_5_6_1       -413
    RHS           prA_5_7_0       -621
    RHS           prB_5_7_0       -409
    RHS           prA_5_7_1       -634
    RHS           prB_5_7_1       -412
    RHS           prA_6_7_0       -624
    RHS           prB_6_7_0       -407
    RHS           prA_6_7_1       -630
    RHS           prB_6_7_1       -422
BOUNDS
 BV BOUND         x_0_0
 BV BOUND         x_0_1
 BV BOUND         x_1_0
 BV BOUND         x_1_1
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         d_0_1_0
 BV BOUND         d_0_1_1
 BV BOUND         d_0_2_0
 BV BOUND         d_0_2_1
 BV BOUND         d_0_3_0
 BV BOUND         d_0_3_1
 BV BOUND         d_0_4_0
 BV BOUND         d_0_4_1
 BV BOUND         d_0_5_0
 BV BOUND         d_0_5_1
 BV BOUND         d_0_6_0
 BV BOUND         d_0_6_1
 BV BOUND         d_0_7_0
 BV BOUND         d_0_7_1
 BV BOUND         d_1_2_0
 BV BOUND         d_1_2_1
 BV BOUND         d_1_3_0
 BV BOUND         d_1_3_1
 BV BOUND         d_1_4_0
 BV BOUND         d_1_4_1
 BV BOUND         d_1_5_0
 BV BOUND         d_1_5_1
 BV BOUND         d_1_6_0
 BV BOUND         d_1_6_1
 BV BOUND         d_1_7_0
 BV BOUND         d_1_7_1
 BV BOUND         d_2_3_0
 BV BOUND         d_2_3_1
 BV BOUND         d_2_4_0
 BV BOUND         d_2_4_1
 BV BOUND         d_2_5_0
 BV BOUND         d_2_5_1
 BV BOUND         d_2_6_0
 BV BOUND         d_2_6_1
 BV BOUND         d_2_7_0
 BV BOUND         d_2_7_1
 BV BOUND         d_3_4_0
 BV BOUND         d_3_4_1
 BV BOUND         d_3_5_0
 BV BOUND         d_3_5_1
 BV BOUND         d_3_6_0
 BV BOUND         d_3_6_1
 BV BOUND         d_3_7_0
 BV BOUND         d_3_7_1
 BV BOUND         d_4_5_0
 BV BOUND         d_4_5_1
 BV BOUND         d_4_6_0
 BV BOUND         d_4_6_1
 BV BOUND         d_4_7_0
 BV BOUND         d_4_7_1
 BV BOUND         d_5_6_0
 BV BOUND         d_5_6_1
 BV BOUND         d_5_7_0
 BV BOUND         d_5_7_1
 BV BOUND         d_6_7_0
 BV BOUND         d_6_7_1
ENDATA
