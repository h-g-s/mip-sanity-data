NAME          tsp_euclidean_n8_sd1
ROWS
 N  OBJ
 E  OUT_0
 E  OUT_1
 E  OUT_2
 E  OUT_3
 E  OUT_4
 E  OUT_5
 E  OUT_6
 E  OUT_7
 E  IN_0
 E  IN_1
 E  IN_2
 E  IN_3
 E  IN_4
 E  IN_5
 E  IN_6
 E  IN_7
 L  MTZ_1_2
 L  MTZ_1_3
 L  MTZ_1_4
 L  MTZ_1_5
 L  MTZ_1_6
 L  MTZ_1_7
 L  MTZ_2_1
 L  MTZ_2_3
 L  MTZ_2_4
 L  MTZ_2_5
 L  MTZ_2_6
 L  MTZ_2_7
 L  MTZ_3_1
 L  MTZ_3_2
 L  MTZ_3_4
 L  MTZ_3_5
 L  MTZ_3_6
 L  MTZ_3_7
 L  MTZ_4_1
 L  MTZ_4_2
 L  MTZ_4_3
 L  MTZ_4_5
 L  MTZ_4_6
 L  MTZ_4_7
 L  MTZ_5_1
 L  MTZ_5_2
 L  MTZ_5_3
 L  MTZ_5_4
 L  MTZ_5_6
 L  MTZ_5_7
 L  MTZ_6_1
 L  MTZ_6_2
 L  MTZ_6_3
 L  MTZ_6_4
 L  MTZ_6_5
 L  MTZ_6_7
 L  MTZ_7_1
 L  MTZ_7_2
 L  MTZ_7_3
 L  MTZ_7_4
 L  MTZ_7_5
 L  MTZ_7_6
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_1           OBJ           864
    x_0_1           OUT_0           1.0
    x_0_1           IN_1            1.0
    x_0_2           OBJ           537
    x_0_2           OUT_0           1.0
    x_0_2           IN_2            1.0
    x_0_3           OBJ           521
    x_0_3           OUT_0           1.0
    x_0_3           IN_3            1.0
    x_0_4           OBJ           820
    x_0_4           OUT_0           1.0
    x_0_4           IN_4            1.0
    x_0_5           OBJ           815
    x_0_5           OUT_0           1.0
    x_0_5           IN_5            1.0
    x_0_6           OBJ           1053
    x_0_6           OUT_0           1.0
    x_0_6           IN_6            1.0
    x_0_7           OBJ           336
    x_0_7           OUT_0           1.0
    x_0_7           IN_7            1.0
    x_1_0           OBJ           864
    x_1_0           OUT_1           1.0
    x_1_0           IN_0            1.0
    x_1_2           OBJ           331
    x_1_2           OUT_1           1.0
    x_1_2           IN_2            1.0
    x_1_2           MTZ_1_2         7.0
    x_1_3           OBJ           545
    x_1_3           OUT_1           1.0
    x_1_3           IN_3            1.0
    x_1_3           MTZ_1_3         7.0
    x_1_4           OBJ           707
    x_1_4           OUT_1           1.0
    x_1_4           IN_4            1.0
    x_1_4           MTZ_1_4         7.0
    x_1_5           OBJ           192
    x_1_5           OUT_1           1.0
    x_1_5           IN_5            1.0
    x_1_5           MTZ_1_5         7.0
    x_1_6           OBJ           253
    x_1_6           OUT_1           1.0
    x_1_6           IN_6            1.0
    x_1_6           MTZ_1_6         7.0
    x_1_7           OBJ           565
    x_1_7           OUT_1           1.0
    x_1_7           IN_7            1.0
    x_1_7           MTZ_1_7         7.0
    x_2_0           OBJ           537
    x_2_0           OUT_2           1.0
    x_2_0           IN_0            1.0
    x_2_1           OBJ           331
    x_2_1           OUT_2           1.0
    x_2_1           IN_1            1.0
    x_2_1           MTZ_2_1         7.0
    x_2_3           OBJ           373
    x_2_3           OUT_2           1.0
    x_2_3           IN_3            1.0
    x_2_3           MTZ_2_3         7.0
    x_2_4           OBJ           582
    x_2_4           OUT_2           1.0
    x_2_4           IN_4            1.0
    x_2_4           MTZ_2_4         7.0
    x_2_5           OBJ           341
    x_2_5           OUT_2           1.0
    x_2_5           IN_5            1.0
    x_2_5           MTZ_2_5         7.0
    x_2_6           OBJ           521
    x_2_6           OUT_2           1.0
    x_2_6           IN_6            1.0
    x_2_6           MTZ_2_6         7.0
    x_2_7           OBJ           277
    x_2_7           OUT_2           1.0
    x_2_7           IN_7            1.0
    x_2_7           MTZ_2_7         7.0
    x_3_0           OBJ           521
    x_3_0           OUT_3           1.0
    x_3_0           IN_0            1.0
    x_3_1           OBJ           545
    x_3_1           OUT_3           1.0
    x_3_1           IN_1            1.0
    x_3_1           MTZ_3_1         7.0
    x_3_2           OBJ           373
    x_3_2           OUT_3           1.0
    x_3_2           IN_2            1.0
    x_3_2           MTZ_3_2         7.0
    x_3_4           OBJ           943
    x_3_4           OUT_3           1.0
    x_3_4           IN_4            1.0
    x_3_4           MTZ_3_4         7.0
    x_3_5           OBJ           401
    x_3_5           OUT_3           1.0
    x_3_5           IN_5            1.0
    x_3_5           MTZ_3_5         7.0
    x_3_6           OBJ           794
    x_3_6           OUT_3           1.0
    x_3_6           IN_6            1.0
    x_3_6           MTZ_3_6         7.0
    x_3_7           OBJ           217
    x_3_7           OUT_3           1.0
    x_3_7           IN_7            1.0
    x_3_7           MTZ_3_7         7.0
    x_4_0           OBJ           820
    x_4_0           OUT_4           1.0
    x_4_0           IN_0            1.0
    x_4_1           OBJ           707
    x_4_1           OUT_4           1.0
    x_4_1           IN_1            1.0
    x_4_1           MTZ_4_1         7.0
    x_4_2           OBJ           582
    x_4_2           OUT_4           1.0
    x_4_2           IN_2            1.0
    x_4_2           MTZ_4_2         7.0
    x_4_3           OBJ           943
    x_4_3           OUT_4           1.0
    x_4_3           IN_3            1.0
    x_4_3           MTZ_4_3         7.0
    x_4_5           OBJ           845
    x_4_5           OUT_4           1.0
    x_4_5           IN_5            1.0
    x_4_5           MTZ_4_5         7.0
    x_4_6           OBJ           669
    x_4_6           OUT_4           1.0
    x_4_6           IN_6            1.0
    x_4_6           MTZ_4_6         7.0
    x_4_7           OBJ           777
    x_4_7           OUT_4           1.0
    x_4_7           IN_7            1.0
    x_4_7           MTZ_4_7         7.0
    x_5_0           OBJ           815
    x_5_0           OUT_5           1.0
    x_5_0           IN_0            1.0
    x_5_1           OBJ           192
    x_5_1           OUT_5           1.0
    x_5_1           IN_1            1.0
    x_5_1           MTZ_5_1         7.0
    x_5_2           OBJ           341
    x_5_2           OUT_5           1.0
    x_5_2           IN_2            1.0
    x_5_2           MTZ_5_2         7.0
    x_5_3           OBJ           401
    x_5_3           OUT_5           1.0
    x_5_3           IN_3            1.0
    x_5_3           MTZ_5_3         7.0
    x_5_4           OBJ           845
    x_5_4           OUT_5           1.0
    x_5_4           IN_4            1.0
    x_5_4           MTZ_5_4         7.0
    x_5_6           OBJ           437
    x_5_6           OUT_5           1.0
    x_5_6           IN_6            1.0
    x_5_6           MTZ_5_6         7.0
    x_5_7           OBJ           486
    x_5_7           OUT_5           1.0
    x_5_7           IN_7            1.0
    x_5_7           MTZ_5_7         7.0
    x_6_0           OBJ           1053
    x_6_0           OUT_6           1.0
    x_6_0           IN_0            1.0
    x_6_1           OBJ           253
    x_6_1           OUT_6           1.0
    x_6_1           IN_1            1.0
    x_6_1           MTZ_6_1         7.0
    x_6_2           OBJ           521
    x_6_2           OUT_6           1.0
    x_6_2           IN_2            1.0
    x_6_2           MTZ_6_2         7.0
    x_6_3           OBJ           794
    x_6_3           OUT_6           1.0
    x_6_3           IN_3            1.0
    x_6_3           MTZ_6_3         7.0
    x_6_4           OBJ           669
    x_6_4           OUT_6           1.0
    x_6_4           IN_4            1.0
    x_6_4           MTZ_6_4         7.0
    x_6_5           OBJ           437
    x_6_5           OUT_6           1.0
    x_6_5           IN_5            1.0
    x_6_5           MTZ_6_5         7.0
    x_6_7           OBJ           786
    x_6_7           OUT_6           1.0
    x_6_7           IN_7            1.0
    x_6_7           MTZ_6_7         7.0
    x_7_0           OBJ           336
    x_7_0           OUT_7           1.0
    x_7_0           IN_0            1.0
    x_7_1           OBJ           565
    x_7_1           OUT_7           1.0
    x_7_1           IN_1            1.0
    x_7_1           MTZ_7_1         7.0
    x_7_2           OBJ           277
    x_7_2           OUT_7           1.0
    x_7_2           IN_2            1.0
    x_7_2           MTZ_7_2         7.0
    x_7_3           OBJ           217
    x_7_3           OUT_7           1.0
    x_7_3           IN_3            1.0
    x_7_3           MTZ_7_3         7.0
    x_7_4           OBJ           777
    x_7_4           OUT_7           1.0
    x_7_4           IN_4            1.0
    x_7_4           MTZ_7_4         7.0
    x_7_5           OBJ           486
    x_7_5           OUT_7           1.0
    x_7_5           IN_5            1.0
    x_7_5           MTZ_7_5         7.0
    x_7_6           OBJ           786
    x_7_6           OUT_7           1.0
    x_7_6           IN_6            1.0
    x_7_6           MTZ_7_6         7.0
    MARK0001  'MARKER'                 'INTEND'
    u_1             MTZ_1_2         1.0
    u_1             MTZ_1_3         1.0
    u_1             MTZ_1_4         1.0
    u_1             MTZ_1_5         1.0
    u_1             MTZ_1_6         1.0
    u_1             MTZ_1_7         1.0
    u_1             MTZ_2_1         -1.0
    u_1             MTZ_3_1         -1.0
    u_1             MTZ_4_1         -1.0
    u_1             MTZ_5_1         -1.0
    u_1             MTZ_6_1         -1.0
    u_1             MTZ_7_1         -1.0
    u_2             MTZ_1_2         -1.0
    u_2             MTZ_2_1         1.0
    u_2             MTZ_2_3         1.0
    u_2             MTZ_2_4         1.0
    u_2             MTZ_2_5         1.0
    u_2             MTZ_2_6         1.0
    u_2             MTZ_2_7         1.0
    u_2             MTZ_3_2         -1.0
    u_2             MTZ_4_2         -1.0
    u_2             MTZ_5_2         -1.0
    u_2             MTZ_6_2         -1.0
    u_2             MTZ_7_2         -1.0
    u_3             MTZ_1_3         -1.0
    u_3             MTZ_2_3         -1.0
    u_3             MTZ_3_1         1.0
    u_3             MTZ_3_2         1.0
    u_3             MTZ_3_4         1.0
    u_3             MTZ_3_5         1.0
    u_3             MTZ_3_6         1.0
    u_3             MTZ_3_7         1.0
    u_3             MTZ_4_3         -1.0
    u_3             MTZ_5_3         -1.0
    u_3             MTZ_6_3         -1.0
    u_3             MTZ_7_3         -1.0
    u_4             MTZ_1_4         -1.0
    u_4             MTZ_2_4         -1.0
    u_4             MTZ_3_4         -1.0
    u_4             MTZ_4_1         1.0
    u_4             MTZ_4_2         1.0
    u_4             MTZ_4_3         1.0
    u_4             MTZ_4_5         1.0
    u_4             MTZ_4_6         1.0
    u_4             MTZ_4_7         1.0
    u_4             MTZ_5_4         -1.0
    u_4             MTZ_6_4         -1.0
    u_4             MTZ_7_4         -1.0
    u_5             MTZ_1_5         -1.0
    u_5             MTZ_2_5         -1.0
    u_5             MTZ_3_5         -1.0
    u_5             MTZ_4_5         -1.0
    u_5             MTZ_5_1         1.0
    u_5             MTZ_5_2         1.0
    u_5             MTZ_5_3         1.0
    u_5             MTZ_5_4         1.0
    u_5             MTZ_5_6         1.0
    u_5             MTZ_5_7         1.0
    u_5             MTZ_6_5         -1.0
    u_5             MTZ_7_5         -1.0
    u_6             MTZ_1_6         -1.0
    u_6             MTZ_2_6         -1.0
    u_6             MTZ_3_6         -1.0
    u_6             MTZ_4_6         -1.0
    u_6             MTZ_5_6         -1.0
    u_6             MTZ_6_1         1.0
    u_6             MTZ_6_2         1.0
    u_6             MTZ_6_3         1.0
    u_6             MTZ_6_4         1.0
    u_6             MTZ_6_5         1.0
    u_6             MTZ_6_7         1.0
    u_6             MTZ_7_6         -1.0
    u_7             MTZ_1_7         -1.0
    u_7             MTZ_2_7         -1.0
    u_7             MTZ_3_7         -1.0
    u_7             MTZ_4_7         -1.0
    u_7             MTZ_5_7         -1.0
    u_7             MTZ_6_7         -1.0
    u_7             MTZ_7_1         1.0
    u_7             MTZ_7_2         1.0
    u_7             MTZ_7_3         1.0
    u_7             MTZ_7_4         1.0
    u_7             MTZ_7_5         1.0
    u_7             MTZ_7_6         1.0
RHS
    RHS           OUT_0           1.0
    RHS           OUT_1           1.0
    RHS           OUT_2           1.0
    RHS           OUT_3           1.0
    RHS           OUT_4           1.0
    RHS           OUT_5           1.0
    RHS           OUT_6           1.0
    RHS           OUT_7           1.0
    RHS           IN_0            1.0
    RHS           IN_1            1.0
    RHS           IN_2            1.0
    RHS           IN_3            1.0
    RHS           IN_4            1.0
    RHS           IN_5            1.0
    RHS           IN_6            1.0
    RHS           IN_7            1.0
    RHS           MTZ_1_2         6.0
    RHS           MTZ_1_3         6.0
    RHS           MTZ_1_4         6.0
    RHS           MTZ_1_5         6.0
    RHS           MTZ_1_6         6.0
    RHS           MTZ_1_7         6.0
    RHS           MTZ_2_1         6.0
    RHS           MTZ_2_3         6.0
    RHS           MTZ_2_4         6.0
    RHS           MTZ_2_5         6.0
    RHS           MTZ_2_6         6.0
    RHS           MTZ_2_7         6.0
    RHS           MTZ_3_1         6.0
    RHS           MTZ_3_2         6.0
    RHS           MTZ_3_4         6.0
    RHS           MTZ_3_5         6.0
    RHS           MTZ_3_6         6.0
    RHS           MTZ_3_7         6.0
    RHS           MTZ_4_1         6.0
    RHS           MTZ_4_2         6.0
    RHS           MTZ_4_3         6.0
    RHS           MTZ_4_5         6.0
    RHS           MTZ_4_6         6.0
    RHS           MTZ_4_7         6.0
    RHS           MTZ_5_1         6.0
    RHS           MTZ_5_2         6.0
    RHS           MTZ_5_3         6.0
    RHS           MTZ_5_4         6.0
    RHS           MTZ_5_6         6.0
    RHS           MTZ_5_7         6.0
    RHS           MTZ_6_1         6.0
    RHS           MTZ_6_2         6.0
    RHS           MTZ_6_3         6.0
    RHS           MTZ_6_4         6.0
    RHS           MTZ_6_5         6.0
    RHS           MTZ_6_7         6.0
    RHS           MTZ_7_1         6.0
    RHS           MTZ_7_2         6.0
    RHS           MTZ_7_3         6.0
    RHS           MTZ_7_4         6.0
    RHS           MTZ_7_5         6.0
    RHS           MTZ_7_6         6.0
BOUNDS
 BV BOUND         x_0_1
 BV BOUND         x_0_2
 BV BOUND         x_0_3
 BV BOUND         x_0_4
 BV BOUND         x_0_5
 BV BOUND         x_0_6
 BV BOUND         x_0_7
 BV BOUND         x_1_0
 BV BOUND         x_1_2
 BV BOUND         x_1_3
 BV BOUND         x_1_4
 BV BOUND         x_1_5
 BV BOUND         x_1_6
 BV BOUND         x_1_7
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_3
 BV BOUND         x_2_4
 BV BOUND         x_2_5
 BV BOUND         x_2_6
 BV BOUND         x_2_7
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 BV BOUND         x_3_4
 BV BOUND         x_3_5
 BV BOUND         x_3_6
 BV BOUND         x_3_7
 BV BOUND         x_4_0
 BV BOUND         x_4_1
 BV BOUND         x_4_2
 BV BOUND         x_4_3
 BV BOUND         x_4_5
 BV BOUND         x_4_6
 BV BOUND         x_4_7
 BV BOUND         x_5_0
 BV BOUND         x_5_1
 BV BOUND         x_5_2
 BV BOUND         x_5_3
 BV BOUND         x_5_4
 BV BOUND         x_5_6
 BV BOUND         x_5_7
 BV BOUND         x_6_0
 BV BOUND         x_6_1
 BV BOUND         x_6_2
 BV BOUND         x_6_3
 BV BOUND         x_6_4
 BV BOUND         x_6_5
 BV BOUND         x_6_7
 BV BOUND         x_7_0
 BV BOUND         x_7_1
 BV BOUND         x_7_2
 BV BOUND         x_7_3
 BV BOUND         x_7_4
 BV BOUND         x_7_5
 BV BOUND         x_7_6
 LO BOUND         u_1       1.0
 UP BOUND         u_1       7.0
 LO BOUND         u_2       1.0
 UP BOUND         u_2       7.0
 LO BOUND         u_3       1.0
 UP BOUND         u_3       7.0
 LO BOUND         u_4       1.0
 UP BOUND         u_4       7.0
 LO BOUND         u_5       1.0
 UP BOUND         u_5       7.0
 LO BOUND         u_6       1.0
 UP BOUND         u_6       7.0
 LO BOUND         u_7       1.0
 UP BOUND         u_7       7.0
ENDATA
