NAME          tsp_euclidean_n4_sd1
ROWS
 N  OBJ
 E  OUT_0
 E  OUT_1
 E  OUT_2
 E  OUT_3
 E  IN_0
 E  IN_1
 E  IN_2
 E  IN_3
 L  MTZ_1_2
 L  MTZ_1_3
 L  MTZ_2_1
 L  MTZ_2_3
 L  MTZ_3_1
 L  MTZ_3_2
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    x_0_1           OBJ           864
    x_0_1           OUT_0           1.0
    x_0_1           IN_1            1.0
    x_0_2           OBJ           537
    x_0_2           OUT_0           1.0
    x_0_2           IN_2            1.0
    x_0_3           OBJ           521
    x_0_3           OUT_0           1.0
    x_0_3           IN_3            1.0
    x_1_0           OBJ           864
    x_1_0           OUT_1           1.0
    x_1_0           IN_0            1.0
    x_1_2           OBJ           331
    x_1_2           OUT_1           1.0
    x_1_2           IN_2            1.0
    x_1_2           MTZ_1_2         3.0
    x_1_3           OBJ           545
    x_1_3           OUT_1           1.0
    x_1_3           IN_3            1.0
    x_1_3           MTZ_1_3         3.0
    x_2_0           OBJ           537
    x_2_0           OUT_2           1.0
    x_2_0           IN_0            1.0
    x_2_1           OBJ           331
    x_2_1           OUT_2           1.0
    x_2_1           IN_1            1.0
    x_2_1           MTZ_2_1         3.0
    x_2_3           OBJ           373
    x_2_3           OUT_2           1.0
    x_2_3           IN_3            1.0
    x_2_3           MTZ_2_3         3.0
    x_3_0           OBJ           521
    x_3_0           OUT_3           1.0
    x_3_0           IN_0            1.0
    x_3_1           OBJ           545
    x_3_1           OUT_3           1.0
    x_3_1           IN_1            1.0
    x_3_1           MTZ_3_1         3.0
    x_3_2           OBJ           373
    x_3_2           OUT_3           1.0
    x_3_2           IN_2            1.0
    x_3_2           MTZ_3_2         3.0
    MARK0001  'MARKER'                 'INTEND'
    u_1             MTZ_1_2         1.0
    u_1             MTZ_1_3         1.0
    u_1             MTZ_2_1         -1.0
    u_1             MTZ_3_1         -1.0
    u_2             MTZ_1_2         -1.0
    u_2             MTZ_2_1         1.0
    u_2             MTZ_2_3         1.0
    u_2             MTZ_3_2         -1.0
    u_3             MTZ_1_3         -1.0
    u_3             MTZ_2_3         -1.0
    u_3             MTZ_3_1         1.0
    u_3             MTZ_3_2         1.0
RHS
    RHS           OUT_0           1.0
    RHS           OUT_1           1.0
    RHS           OUT_2           1.0
    RHS           OUT_3           1.0
    RHS           IN_0            1.0
    RHS           IN_1            1.0
    RHS           IN_2            1.0
    RHS           IN_3            1.0
    RHS           MTZ_1_2         2.0
    RHS           MTZ_1_3         2.0
    RHS           MTZ_2_1         2.0
    RHS           MTZ_2_3         2.0
    RHS           MTZ_3_1         2.0
    RHS           MTZ_3_2         2.0
BOUNDS
 BV BOUND         x_0_1
 BV BOUND         x_0_2
 BV BOUND         x_0_3
 BV BOUND         x_1_0
 BV BOUND         x_1_2
 BV BOUND         x_1_3
 BV BOUND         x_2_0
 BV BOUND         x_2_1
 BV BOUND         x_2_3
 BV BOUND         x_3_0
 BV BOUND         x_3_1
 BV BOUND         x_3_2
 LO BOUND         u_1       1.0
 UP BOUND         u_1       3.0
 LO BOUND         u_2       1.0
 UP BOUND         u_2       3.0
 LO BOUND         u_3       1.0
 UP BOUND         u_3       3.0
ENDATA
