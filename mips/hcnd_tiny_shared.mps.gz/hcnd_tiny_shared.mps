NAME          hcnd_tiny_shared
ROWS
 N  OBJ
 L  CAP_0_1
 L  CAP_1_2
 L  CAP_0_2
 E  SUP_0
 E  DEM_0
 E  CONS_0_1_1
 E  CONS_0_0_1
 E  SUP_1
 E  DEM_1
 E  CONS_1_0_1
 E  CONS_1_1_1
COLUMNS
    MARK0001  'MARKER'                 'INTORG'
    y_0_1           OBJ           1
    y_0_1           CAP_0_1         -5.0
    y_1_2           OBJ           1
    y_1_2           CAP_1_2         -5.0
    y_0_2           OBJ           100
    y_0_2           CAP_0_2         -100.0
    MARK0001  'MARKER'                 'INTEND'
    f_0_0_1_0       CAP_0_1         1.0
    f_0_0_1_0       SUP_0           1.0
    f_0_0_1_0       CONS_0_1_1      -1.0
    f_0_0_2_0       CAP_0_2         1.0
    f_0_0_2_0       SUP_0           1.0
    f_0_0_2_0       DEM_0           1.0
    f_0_1_2_1       CAP_1_2         1.0
    f_0_1_2_1       CONS_0_1_1      1.0
    f_0_1_2_1       DEM_0           1.0
    f_0_0_2_1       CAP_0_2         1.0
    f_0_0_2_1       CONS_0_0_1      1.0
    f_0_0_2_1       DEM_0           1.0
    f_1_1_0_0       CAP_0_1         1.0
    f_1_1_0_0       SUP_1           1.0
    f_1_1_0_0       CONS_1_0_1      -1.0
    f_1_1_2_0       CAP_1_2         1.0
    f_1_1_2_0       SUP_1           1.0
    f_1_1_2_0       DEM_1           1.0
    f_1_1_2_1       CAP_1_2         1.0
    f_1_1_2_1       CONS_1_1_1      1.0
    f_1_1_2_1       DEM_1           1.0
    f_1_0_2_1       CAP_0_2         1.0
    f_1_0_2_1       CONS_1_0_1      1.0
    f_1_0_2_1       DEM_1           1.0
RHS
    RHS           SUP_0           3.0
    RHS           DEM_0           3.0
    RHS           SUP_1           3.0
    RHS           DEM_1           3.0
BOUNDS
 BV BOUND         y_0_1
 BV BOUND         y_1_2
 BV BOUND         y_0_2
 UP BOUND         f_0_0_1_0       3.0
 UP BOUND         f_0_0_2_0       3.0
 UP BOUND         f_0_1_2_1       3.0
 UP BOUND         f_0_0_2_1       3.0
 UP BOUND         f_1_1_0_0       3.0
 UP BOUND         f_1_1_2_0       3.0
 UP BOUND         f_1_1_2_1       3.0
 UP BOUND         f_1_0_2_1       3.0
ENDATA
