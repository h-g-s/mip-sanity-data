NAME          steiner_complete10_unit_t4
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 L  cap_0_1
 L  cap_0_2
 L  cap_0_3
 L  cap_0_4
 L  cap_0_5
 L  cap_0_6
 L  cap_0_7
 L  cap_0_8
 L  cap_0_9
 L  cap_1_2
 L  cap_1_3
 L  cap_1_4
 L  cap_1_5
 L  cap_1_6
 L  cap_1_7
 L  cap_1_8
 L  cap_1_9
 L  cap_2_3
 L  cap_2_4
 L  cap_2_5
 L  cap_2_6
 L  cap_2_7
 L  cap_2_8
 L  cap_2_9
 L  cap_3_4
 L  cap_3_5
 L  cap_3_6
 L  cap_3_7
 L  cap_3_8
 L  cap_3_9
 L  cap_4_5
 L  cap_4_6
 L  cap_4_7
 L  cap_4_8
 L  cap_4_9
 L  cap_5_6
 L  cap_5_7
 L  cap_5_8
 L  cap_5_9
 L  cap_6_7
 L  cap_6_8
 L  cap_6_9
 L  cap_7_8
 L  cap_7_9
 L  cap_8_9
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       1.0
    x_0_1     cap_0_1   -4
    x_0_2     OBJ       1.0
    x_0_2     cap_0_2   -4
    x_0_3     OBJ       1.0
    x_0_3     cap_0_3   -4
    x_0_4     OBJ       1.0
    x_0_4     cap_0_4   -4
    x_0_5     OBJ       1.0
    x_0_5     cap_0_5   -4
    x_0_6     OBJ       1.0
    x_0_6     cap_0_6   -4
    x_0_7     OBJ       1.0
    x_0_7     cap_0_7   -4
    x_0_8     OBJ       1.0
    x_0_8     cap_0_8   -4
    x_0_9     OBJ       1.0
    x_0_9     cap_0_9   -4
    x_1_2     OBJ       1.0
    x_1_2     cap_1_2   -4
    x_1_3     OBJ       1.0
    x_1_3     cap_1_3   -4
    x_1_4     OBJ       1.0
    x_1_4     cap_1_4   -4
    x_1_5     OBJ       1.0
    x_1_5     cap_1_5   -4
    x_1_6     OBJ       1.0
    x_1_6     cap_1_6   -4
    x_1_7     OBJ       1.0
    x_1_7     cap_1_7   -4
    x_1_8     OBJ       1.0
    x_1_8     cap_1_8   -4
    x_1_9     OBJ       1.0
    x_1_9     cap_1_9   -4
    x_2_3     OBJ       1.0
    x_2_3     cap_2_3   -4
    x_2_4     OBJ       1.0
    x_2_4     cap_2_4   -4
    x_2_5     OBJ       1.0
    x_2_5     cap_2_5   -4
    x_2_6     OBJ       1.0
    x_2_6     cap_2_6   -4
    x_2_7     OBJ       1.0
    x_2_7     cap_2_7   -4
    x_2_8     OBJ       1.0
    x_2_8     cap_2_8   -4
    x_2_9     OBJ       1.0
    x_2_9     cap_2_9   -4
    x_3_4     OBJ       1.0
    x_3_4     cap_3_4   -4
    x_3_5     OBJ       1.0
    x_3_5     cap_3_5   -4
    x_3_6     OBJ       1.0
    x_3_6     cap_3_6   -4
    x_3_7     OBJ       1.0
    x_3_7     cap_3_7   -4
    x_3_8     OBJ       1.0
    x_3_8     cap_3_8   -4
    x_3_9     OBJ       1.0
    x_3_9     cap_3_9   -4
    x_4_5     OBJ       1.0
    x_4_5     cap_4_5   -4
    x_4_6     OBJ       1.0
    x_4_6     cap_4_6   -4
    x_4_7     OBJ       1.0
    x_4_7     cap_4_7   -4
    x_4_8     OBJ       1.0
    x_4_8     cap_4_8   -4
    x_4_9     OBJ       1.0
    x_4_9     cap_4_9   -4
    x_5_6     OBJ       1.0
    x_5_6     cap_5_6   -4
    x_5_7     OBJ       1.0
    x_5_7     cap_5_7   -4
    x_5_8     OBJ       1.0
    x_5_8     cap_5_8   -4
    x_5_9     OBJ       1.0
    x_5_9     cap_5_9   -4
    x_6_7     OBJ       1.0
    x_6_7     cap_6_7   -4
    x_6_8     OBJ       1.0
    x_6_8     cap_6_8   -4
    x_6_9     OBJ       1.0
    x_6_9     cap_6_9   -4
    x_7_8     OBJ       1.0
    x_7_8     cap_7_8   -4
    x_7_9     OBJ       1.0
    x_7_9     cap_7_9   -4
    x_8_9     OBJ       1.0
    x_8_9     cap_8_9   -4
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_2     flow_0    1.0
    f_0_2     flow_2    -1.0
    f_0_2     cap_0_2   1.0
    f_2_0     flow_0    -1.0
    f_2_0     flow_2    1.0
    f_2_0     cap_0_2   1.0
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_4     flow_0    1.0
    f_0_4     flow_4    -1.0
    f_0_4     cap_0_4   1.0
    f_4_0     flow_0    -1.0
    f_4_0     flow_4    1.0
    f_4_0     cap_0_4   1.0
    f_0_5     flow_0    1.0
    f_0_5     flow_5    -1.0
    f_0_5     cap_0_5   1.0
    f_5_0     flow_0    -1.0
    f_5_0     flow_5    1.0
    f_5_0     cap_0_5   1.0
    f_0_6     flow_0    1.0
    f_0_6     flow_6    -1.0
    f_0_6     cap_0_6   1.0
    f_6_0     flow_0    -1.0
    f_6_0     flow_6    1.0
    f_6_0     cap_0_6   1.0
    f_0_7     flow_0    1.0
    f_0_7     flow_7    -1.0
    f_0_7     cap_0_7   1.0
    f_7_0     flow_0    -1.0
    f_7_0     flow_7    1.0
    f_7_0     cap_0_7   1.0
    f_0_8     flow_0    1.0
    f_0_8     flow_8    -1.0
    f_0_8     cap_0_8   1.0
    f_8_0     flow_0    -1.0
    f_8_0     flow_8    1.0
    f_8_0     cap_0_8   1.0
    f_0_9     flow_0    1.0
    f_0_9     flow_9    -1.0
    f_0_9     cap_0_9   1.0
    f_9_0     flow_0    -1.0
    f_9_0     flow_9    1.0
    f_9_0     cap_0_9   1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_3     flow_1    1.0
    f_1_3     flow_3    -1.0
    f_1_3     cap_1_3   1.0
    f_3_1     flow_1    -1.0
    f_3_1     flow_3    1.0
    f_3_1     cap_1_3   1.0
    f_1_4     flow_1    1.0
    f_1_4     flow_4    -1.0
    f_1_4     cap_1_4   1.0
    f_4_1     flow_1    -1.0
    f_4_1     flow_4    1.0
    f_4_1     cap_1_4   1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_1_6     flow_1    1.0
    f_1_6     flow_6    -1.0
    f_1_6     cap_1_6   1.0
    f_6_1     flow_1    -1.0
    f_6_1     flow_6    1.0
    f_6_1     cap_1_6   1.0
    f_1_7     flow_1    1.0
    f_1_7     flow_7    -1.0
    f_1_7     cap_1_7   1.0
    f_7_1     flow_1    -1.0
    f_7_1     flow_7    1.0
    f_7_1     cap_1_7   1.0
    f_1_8     flow_1    1.0
    f_1_8     flow_8    -1.0
    f_1_8     cap_1_8   1.0
    f_8_1     flow_1    -1.0
    f_8_1     flow_8    1.0
    f_8_1     cap_1_8   1.0
    f_1_9     flow_1    1.0
    f_1_9     flow_9    -1.0
    f_1_9     cap_1_9   1.0
    f_9_1     flow_1    -1.0
    f_9_1     flow_9    1.0
    f_9_1     cap_1_9   1.0
    f_2_3     flow_2    1.0
    f_2_3     flow_3    -1.0
    f_2_3     cap_2_3   1.0
    f_3_2     flow_2    -1.0
    f_3_2     flow_3    1.0
    f_3_2     cap_2_3   1.0
    f_2_4     flow_2    1.0
    f_2_4     flow_4    -1.0
    f_2_4     cap_2_4   1.0
    f_4_2     flow_2    -1.0
    f_4_2     flow_4    1.0
    f_4_2     cap_2_4   1.0
    f_2_5     flow_2    1.0
    f_2_5     flow_5    -1.0
    f_2_5     cap_2_5   1.0
    f_5_2     flow_2    -1.0
    f_5_2     flow_5    1.0
    f_5_2     cap_2_5   1.0
    f_2_6     flow_2    1.0
    f_2_6     flow_6    -1.0
    f_2_6     cap_2_6   1.0
    f_6_2     flow_2    -1.0
    f_6_2     flow_6    1.0
    f_6_2     cap_2_6   1.0
    f_2_7     flow_2    1.0
    f_2_7     flow_7    -1.0
    f_2_7     cap_2_7   1.0
    f_7_2     flow_2    -1.0
    f_7_2     flow_7    1.0
    f_7_2     cap_2_7   1.0
    f_2_8     flow_2    1.0
    f_2_8     flow_8    -1.0
    f_2_8     cap_2_8   1.0
    f_8_2     flow_2    -1.0
    f_8_2     flow_8    1.0
    f_8_2     cap_2_8   1.0
    f_2_9     flow_2    1.0
    f_2_9     flow_9    -1.0
    f_2_9     cap_2_9   1.0
    f_9_2     flow_2    -1.0
    f_9_2     flow_9    1.0
    f_9_2     cap_2_9   1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_5     flow_3    1.0
    f_3_5     flow_5    -1.0
    f_3_5     cap_3_5   1.0
    f_5_3     flow_3    -1.0
    f_5_3     flow_5    1.0
    f_5_3     cap_3_5   1.0
    f_3_6     flow_3    1.0
    f_3_6     flow_6    -1.0
    f_3_6     cap_3_6   1.0
    f_6_3     flow_3    -1.0
    f_6_3     flow_6    1.0
    f_6_3     cap_3_6   1.0
    f_3_7     flow_3    1.0
    f_3_7     flow_7    -1.0
    f_3_7     cap_3_7   1.0
    f_7_3     flow_3    -1.0
    f_7_3     flow_7    1.0
    f_7_3     cap_3_7   1.0
    f_3_8     flow_3    1.0
    f_3_8     flow_8    -1.0
    f_3_8     cap_3_8   1.0
    f_8_3     flow_3    -1.0
    f_8_3     flow_8    1.0
    f_8_3     cap_3_8   1.0
    f_3_9     flow_3    1.0
    f_3_9     flow_9    -1.0
    f_3_9     cap_3_9   1.0
    f_9_3     flow_3    -1.0
    f_9_3     flow_9    1.0
    f_9_3     cap_3_9   1.0
    f_4_5     flow_4    1.0
    f_4_5     flow_5    -1.0
    f_4_5     cap_4_5   1.0
    f_5_4     flow_4    -1.0
    f_5_4     flow_5    1.0
    f_5_4     cap_4_5   1.0
    f_4_6     flow_4    1.0
    f_4_6     flow_6    -1.0
    f_4_6     cap_4_6   1.0
    f_6_4     flow_4    -1.0
    f_6_4     flow_6    1.0
    f_6_4     cap_4_6   1.0
    f_4_7     flow_4    1.0
    f_4_7     flow_7    -1.0
    f_4_7     cap_4_7   1.0
    f_7_4     flow_4    -1.0
    f_7_4     flow_7    1.0
    f_7_4     cap_4_7   1.0
    f_4_8     flow_4    1.0
    f_4_8     flow_8    -1.0
    f_4_8     cap_4_8   1.0
    f_8_4     flow_4    -1.0
    f_8_4     flow_8    1.0
    f_8_4     cap_4_8   1.0
    f_4_9     flow_4    1.0
    f_4_9     flow_9    -1.0
    f_4_9     cap_4_9   1.0
    f_9_4     flow_4    -1.0
    f_9_4     flow_9    1.0
    f_9_4     cap_4_9   1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_7     flow_5    1.0
    f_5_7     flow_7    -1.0
    f_5_7     cap_5_7   1.0
    f_7_5     flow_5    -1.0
    f_7_5     flow_7    1.0
    f_7_5     cap_5_7   1.0
    f_5_8     flow_5    1.0
    f_5_8     flow_8    -1.0
    f_5_8     cap_5_8   1.0
    f_8_5     flow_5    -1.0
    f_8_5     flow_8    1.0
    f_8_5     cap_5_8   1.0
    f_5_9     flow_5    1.0
    f_5_9     flow_9    -1.0
    f_5_9     cap_5_9   1.0
    f_9_5     flow_5    -1.0
    f_9_5     flow_9    1.0
    f_9_5     cap_5_9   1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_8     flow_6    1.0
    f_6_8     flow_8    -1.0
    f_6_8     cap_6_8   1.0
    f_8_6     flow_6    -1.0
    f_8_6     flow_8    1.0
    f_8_6     cap_6_8   1.0
    f_6_9     flow_6    1.0
    f_6_9     flow_9    -1.0
    f_6_9     cap_6_9   1.0
    f_9_6     flow_6    -1.0
    f_9_6     flow_9    1.0
    f_9_6     cap_6_9   1.0
    f_7_8     flow_7    1.0
    f_7_8     flow_8    -1.0
    f_7_8     cap_7_8   1.0
    f_8_7     flow_7    -1.0
    f_8_7     flow_8    1.0
    f_8_7     cap_7_8   1.0
    f_7_9     flow_7    1.0
    f_7_9     flow_9    -1.0
    f_7_9     cap_7_9   1.0
    f_9_7     flow_7    -1.0
    f_9_7     flow_9    1.0
    f_9_7     cap_7_9   1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
RHS
    RHS       flow_0    4
    RHS       flow_1    -1
    RHS       flow_2    -1
    RHS       flow_3    -1
    RHS       flow_6    -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_2
 BV BOUND     x_0_3
 BV BOUND     x_0_4
 BV BOUND     x_0_5
 BV BOUND     x_0_6
 BV BOUND     x_0_7
 BV BOUND     x_0_8
 BV BOUND     x_0_9
 BV BOUND     x_1_2
 BV BOUND     x_1_3
 BV BOUND     x_1_4
 BV BOUND     x_1_5
 BV BOUND     x_1_6
 BV BOUND     x_1_7
 BV BOUND     x_1_8
 BV BOUND     x_1_9
 BV BOUND     x_2_3
 BV BOUND     x_2_4
 BV BOUND     x_2_5
 BV BOUND     x_2_6
 BV BOUND     x_2_7
 BV BOUND     x_2_8
 BV BOUND     x_2_9
 BV BOUND     x_3_4
 BV BOUND     x_3_5
 BV BOUND     x_3_6
 BV BOUND     x_3_7
 BV BOUND     x_3_8
 BV BOUND     x_3_9
 BV BOUND     x_4_5
 BV BOUND     x_4_6
 BV BOUND     x_4_7
 BV BOUND     x_4_8
 BV BOUND     x_4_9
 BV BOUND     x_5_6
 BV BOUND     x_5_7
 BV BOUND     x_5_8
 BV BOUND     x_5_9
 BV BOUND     x_6_7
 BV BOUND     x_6_8
 BV BOUND     x_6_9
 BV BOUND     x_7_8
 BV BOUND     x_7_9
 BV BOUND     x_8_9
 UP BOUND     f_0_1     4
 UP BOUND     f_1_0     4
 UP BOUND     f_0_2     4
 UP BOUND     f_2_0     4
 UP BOUND     f_0_3     4
 UP BOUND     f_3_0     4
 UP BOUND     f_0_4     4
 UP BOUND     f_4_0     4
 UP BOUND     f_0_5     4
 UP BOUND     f_5_0     4
 UP BOUND     f_0_6     4
 UP BOUND     f_6_0     4
 UP BOUND     f_0_7     4
 UP BOUND     f_7_0     4
 UP BOUND     f_0_8     4
 UP BOUND     f_8_0     4
 UP BOUND     f_0_9     4
 UP BOUND     f_9_0     4
 UP BOUND     f_1_2     4
 UP BOUND     f_2_1     4
 UP BOUND     f_1_3     4
 UP BOUND     f_3_1     4
 UP BOUND     f_1_4     4
 UP BOUND     f_4_1     4
 UP BOUND     f_1_5     4
 UP BOUND     f_5_1     4
 UP BOUND     f_1_6     4
 UP BOUND     f_6_1     4
 UP BOUND     f_1_7     4
 UP BOUND     f_7_1     4
 UP BOUND     f_1_8     4
 UP BOUND     f_8_1     4
 UP BOUND     f_1_9     4
 UP BOUND     f_9_1     4
 UP BOUND     f_2_3     4
 UP BOUND     f_3_2     4
 UP BOUND     f_2_4     4
 UP BOUND     f_4_2     4
 UP BOUND     f_2_5     4
 UP BOUND     f_5_2     4
 UP BOUND     f_2_6     4
 UP BOUND     f_6_2     4
 UP BOUND     f_2_7     4
 UP BOUND     f_7_2     4
 UP BOUND     f_2_8     4
 UP BOUND     f_8_2     4
 UP BOUND     f_2_9     4
 UP BOUND     f_9_2     4
 UP BOUND     f_3_4     4
 UP BOUND     f_4_3     4
 UP BOUND     f_3_5     4
 UP BOUND     f_5_3     4
 UP BOUND     f_3_6     4
 UP BOUND     f_6_3     4
 UP BOUND     f_3_7     4
 UP BOUND     f_7_3     4
 UP BOUND     f_3_8     4
 UP BOUND     f_8_3     4
 UP BOUND     f_3_9     4
 UP BOUND     f_9_3     4
 UP BOUND     f_4_5     4
 UP BOUND     f_5_4     4
 UP BOUND     f_4_6     4
 UP BOUND     f_6_4     4
 UP BOUND     f_4_7     4
 UP BOUND     f_7_4     4
 UP BOUND     f_4_8     4
 UP BOUND     f_8_4     4
 UP BOUND     f_4_9     4
 UP BOUND     f_9_4     4
 UP BOUND     f_5_6     4
 UP BOUND     f_6_5     4
 UP BOUND     f_5_7     4
 UP BOUND     f_7_5     4
 UP BOUND     f_5_8     4
 UP BOUND     f_8_5     4
 UP BOUND     f_5_9     4
 UP BOUND     f_9_5     4
 UP BOUND     f_6_7     4
 UP BOUND     f_7_6     4
 UP BOUND     f_6_8     4
 UP BOUND     f_8_6     4
 UP BOUND     f_6_9     4
 UP BOUND     f_9_6     4
 UP BOUND     f_7_8     4
 UP BOUND     f_8_7     4
 UP BOUND     f_7_9     4
 UP BOUND     f_9_7     4
 UP BOUND     f_8_9     4
 UP BOUND     f_9_8     4
ENDATA
