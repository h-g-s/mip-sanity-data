NAME          fcnf_search_n50_d8_s2_3_sl0.9_sd42
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 E  flow_25
 E  flow_26
 E  flow_27
 E  flow_28
 E  flow_29
 E  flow_30
 E  flow_31
 E  flow_32
 E  flow_33
 E  flow_34
 E  flow_35
 E  flow_36
 E  flow_37
 E  flow_38
 E  flow_39
 E  flow_40
 E  flow_41
 E  flow_42
 E  flow_43
 E  flow_44
 E  flow_45
 E  flow_46
 E  flow_47
 E  flow_48
 E  flow_49
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
 L  link_80
 L  link_81
 L  link_82
 L  link_83
 L  link_84
 L  link_85
 L  link_86
 L  link_87
 L  link_88
 L  link_89
 L  link_90
 L  link_91
 L  link_92
 L  link_93
 L  link_94
 L  link_95
 L  link_96
 L  link_97
 L  link_98
 L  link_99
 L  link_100
 L  link_101
 L  link_102
 L  link_103
 L  link_104
 L  link_105
 L  link_106
 L  link_107
 L  link_108
 L  link_109
 L  link_110
 L  link_111
 L  link_112
 L  link_113
 L  link_114
 L  link_115
 L  link_116
 L  link_117
 L  link_118
 L  link_119
 L  link_120
 L  link_121
 L  link_122
 L  link_123
 L  link_124
 L  link_125
 L  link_126
 L  link_127
 L  link_128
 L  link_129
 L  link_130
 L  link_131
 L  link_132
 L  link_133
 L  link_134
 L  link_135
 L  link_136
 L  link_137
 L  link_138
 L  link_139
 L  link_140
 L  link_141
 L  link_142
 L  link_143
 L  link_144
 L  link_145
 L  link_146
 L  link_147
 L  link_148
 L  link_149
 L  link_150
 L  link_151
 L  link_152
 L  link_153
 L  link_154
 L  link_155
 L  link_156
 L  link_157
 L  link_158
 L  link_159
 L  link_160
 L  link_161
 L  link_162
 L  link_163
 L  link_164
 L  link_165
 L  link_166
 L  link_167
 L  link_168
 L  link_169
 L  link_170
 L  link_171
 L  link_172
 L  link_173
 L  link_174
 L  link_175
 L  link_176
 L  link_177
 L  link_178
 L  link_179
 L  link_180
 L  link_181
 L  link_182
 L  link_183
 L  link_184
 L  link_185
 L  link_186
 L  link_187
 L  link_188
 L  link_189
 L  link_190
 L  link_191
 L  link_192
 L  link_193
 L  link_194
 L  link_195
 L  link_196
 L  link_197
 L  link_198
 L  link_199
 L  link_200
 L  link_201
 L  link_202
 L  link_203
 L  link_204
 L  link_205
 L  link_206
 L  link_207
 L  link_208
 L  link_209
 L  link_210
 L  link_211
 L  link_212
 L  link_213
 L  link_214
 L  link_215
 L  link_216
 L  link_217
 L  link_218
 L  link_219
 L  link_220
 L  link_221
 L  link_222
 L  link_223
 L  link_224
 L  link_225
 L  link_226
 L  link_227
 L  link_228
 L  link_229
 L  link_230
 L  link_231
 L  link_232
 L  link_233
 L  link_234
 L  link_235
 L  link_236
 L  link_237
 L  link_238
 L  link_239
 L  link_240
 L  link_241
 L  link_242
 L  link_243
 L  link_244
 L  link_245
 L  link_246
 L  link_247
 L  link_248
 L  link_249
 L  link_250
 L  link_251
 L  link_252
 L  link_253
 L  link_254
 L  link_255
 L  link_256
 L  link_257
 L  link_258
 L  link_259
 L  link_260
 L  link_261
 L  link_262
 L  link_263
 L  link_264
 L  link_265
 L  link_266
 L  link_267
 L  link_268
 L  link_269
 L  link_270
 L  link_271
 L  link_272
 L  link_273
 L  link_274
 L  link_275
 L  link_276
 L  link_277
 L  link_278
 L  link_279
 L  link_280
 L  link_281
 L  link_282
 L  link_283
 L  link_284
 L  link_285
 L  link_286
 L  link_287
 L  link_288
 L  link_289
 L  link_290
 L  link_291
 L  link_292
 L  link_293
 L  link_294
 L  link_295
 L  link_296
 L  link_297
 L  link_298
 L  link_299
 L  link_300
 L  link_301
 L  link_302
 L  link_303
 L  link_304
 L  link_305
 L  link_306
 L  link_307
 L  link_308
 L  link_309
 L  link_310
 L  link_311
 L  link_312
 L  link_313
 L  link_314
 L  link_315
 L  link_316
 L  link_317
 L  link_318
 L  link_319
 L  link_320
 L  link_321
 L  link_322
 L  link_323
 L  link_324
 L  link_325
 L  link_326
 L  link_327
 L  link_328
 L  link_329
 L  link_330
 L  link_331
 L  link_332
 L  link_333
 L  link_334
 L  link_335
 L  link_336
 L  link_337
 L  link_338
 L  link_339
 L  link_340
 L  link_341
 L  link_342
 L  link_343
 L  link_344
 L  link_345
 L  link_346
 L  link_347
 L  link_348
 L  link_349
 L  link_350
 L  link_351
 L  link_352
 L  link_353
 L  link_354
 L  link_355
 L  link_356
 L  link_357
 L  link_358
 L  link_359
 L  link_360
 L  link_361
 L  link_362
 L  link_363
 L  link_364
 L  link_365
 L  link_366
 L  link_367
 L  link_368
 L  link_369
 L  link_370
 L  link_371
 L  link_372
 L  link_373
 L  link_374
 L  link_375
 L  link_376
 L  link_377
 L  link_378
 L  link_379
 L  link_380
 L  link_381
 L  link_382
 L  link_383
 L  link_384
 L  link_385
 L  link_386
 L  link_387
 L  link_388
 L  link_389
 L  link_390
 L  link_391
 L  link_392
 L  link_393
 L  link_394
 L  link_395
 L  link_396
 L  link_397
 L  link_398
 L  link_399
COLUMNS
    x_0         OBJ       1.19
    x_0         flow_40     1.0
    x_0         flow_7      -1.0
    x_0         link_0      1.0
    x_1         OBJ       52.72
    x_1         flow_6      1.0
    x_1         flow_43     -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.76
    x_2         flow_1      1.0
    x_2         flow_5      -1.0
    x_2         link_2      1.0
    x_3         OBJ       45.17
    x_3         flow_45     1.0
    x_3         flow_41     -1.0
    x_3         link_3      1.0
    x_4         OBJ       61.89
    x_4         flow_0      1.0
    x_4         flow_48     -1.0
    x_4         link_4      1.0
    x_5         OBJ       0.73
    x_5         flow_13     1.0
    x_5         flow_48     -1.0
    x_5         link_5      1.0
    x_6         OBJ       0.61
    x_6         flow_22     1.0
    x_6         flow_38     -1.0
    x_6         link_6      1.0
    x_7         OBJ       69.76
    x_7         flow_24     1.0
    x_7         flow_5      -1.0
    x_7         link_7      1.0
    x_8         OBJ       0.67
    x_8         flow_23     1.0
    x_8         flow_36     -1.0
    x_8         link_8      1.0
    x_9         OBJ       71.99
    x_9         flow_18     1.0
    x_9         flow_5      -1.0
    x_9         link_9      1.0
    x_10        OBJ       1.39
    x_10        flow_40     1.0
    x_10        flow_23     -1.0
    x_10        link_10     1.0
    x_11        OBJ       2.09
    x_11        flow_43     1.0
    x_11        flow_41     -1.0
    x_11        link_11     1.0
    x_12        OBJ       2.97
    x_12        flow_10     1.0
    x_12        flow_29     -1.0
    x_12        link_12     1.0
    x_13        OBJ       2.42
    x_13        flow_14     1.0
    x_13        flow_43     -1.0
    x_13        link_13     1.0
    x_14        OBJ       0.67
    x_14        flow_2      1.0
    x_14        flow_20     -1.0
    x_14        link_14     1.0
    x_15        OBJ       1.75
    x_15        flow_45     1.0
    x_15        flow_20     -1.0
    x_15        link_15     1.0
    x_16        OBJ       1.12
    x_16        flow_29     1.0
    x_16        flow_9      -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.96
    x_17        flow_47     1.0
    x_17        flow_37     -1.0
    x_17        link_17     1.0
    x_18        OBJ       0.62
    x_18        flow_32     1.0
    x_18        flow_31     -1.0
    x_18        link_18     1.0
    x_19        OBJ       0.66
    x_19        flow_10     1.0
    x_19        flow_43     -1.0
    x_19        link_19     1.0
    x_20        OBJ       71.65
    x_20        flow_33     1.0
    x_20        flow_16     -1.0
    x_20        link_20     1.0
    x_21        OBJ       65.05
    x_21        flow_7      1.0
    x_21        flow_43     -1.0
    x_21        link_21     1.0
    x_22        OBJ       1.63
    x_22        flow_7      1.0
    x_22        flow_18     -1.0
    x_22        link_22     1.0
    x_23        OBJ       50.46
    x_23        flow_16     1.0
    x_23        flow_32     -1.0
    x_23        link_23     1.0
    x_24        OBJ       31.93
    x_24        flow_19     1.0
    x_24        flow_40     -1.0
    x_24        link_24     1.0
    x_25        OBJ       75.11
    x_25        flow_34     1.0
    x_25        flow_49     -1.0
    x_25        link_25     1.0
    x_26        OBJ       72.72
    x_26        flow_1      1.0
    x_26        flow_7      -1.0
    x_26        link_26     1.0
    x_27        OBJ       1.92
    x_27        flow_15     1.0
    x_27        flow_3      -1.0
    x_27        link_27     1.0
    x_28        OBJ       51.96
    x_28        flow_31     1.0
    x_28        flow_4      -1.0
    x_28        link_28     1.0
    x_29        OBJ       1.82
    x_29        flow_30     1.0
    x_29        flow_35     -1.0
    x_29        link_29     1.0
    x_30        OBJ       32.07
    x_30        flow_34     1.0
    x_30        flow_48     -1.0
    x_30        link_30     1.0
    x_31        OBJ       1.79
    x_31        flow_41     1.0
    x_31        flow_23     -1.0
    x_31        link_31     1.0
    x_32        OBJ       1.88
    x_32        flow_4      1.0
    x_32        flow_21     -1.0
    x_32        link_32     1.0
    x_33        OBJ       33.74
    x_33        flow_4      1.0
    x_33        flow_45     -1.0
    x_33        link_33     1.0
    x_34        OBJ       36.71
    x_34        flow_21     1.0
    x_34        flow_4      -1.0
    x_34        link_34     1.0
    x_35        OBJ       54.26
    x_35        flow_8      1.0
    x_35        flow_46     -1.0
    x_35        link_35     1.0
    x_36        OBJ       0.74
    x_36        flow_30     1.0
    x_36        flow_26     -1.0
    x_36        link_36     1.0
    x_37        OBJ       23.25
    x_37        flow_26     1.0
    x_37        flow_29     -1.0
    x_37        link_37     1.0
    x_38        OBJ       1.35
    x_38        flow_6      1.0
    x_38        flow_3      -1.0
    x_38        link_38     1.0
    x_39        OBJ       0.96
    x_39        flow_34     1.0
    x_39        flow_28     -1.0
    x_39        link_39     1.0
    x_40        OBJ       71.36
    x_40        flow_4      1.0
    x_40        flow_28     -1.0
    x_40        link_40     1.0
    x_41        OBJ       75.58
    x_41        flow_34     1.0
    x_41        flow_0      -1.0
    x_41        link_41     1.0
    x_42        OBJ       2.66
    x_42        flow_26     1.0
    x_42        flow_31     -1.0
    x_42        link_42     1.0
    x_43        OBJ       35.91
    x_43        flow_24     1.0
    x_43        flow_0      -1.0
    x_43        link_43     1.0
    x_44        OBJ       63.83
    x_44        flow_18     1.0
    x_44        flow_27     -1.0
    x_44        link_44     1.0
    x_45        OBJ       1.24
    x_45        flow_45     1.0
    x_45        flow_31     -1.0
    x_45        link_45     1.0
    x_46        OBJ       1.28
    x_46        flow_47     1.0
    x_46        flow_34     -1.0
    x_46        link_46     1.0
    x_47        OBJ       2.9
    x_47        flow_32     1.0
    x_47        flow_33     -1.0
    x_47        link_47     1.0
    x_48        OBJ       2.65
    x_48        flow_4      1.0
    x_48        flow_38     -1.0
    x_48        link_48     1.0
    x_49        OBJ       57.16
    x_49        flow_15     1.0
    x_49        flow_37     -1.0
    x_49        link_49     1.0
    x_50        OBJ       1.15
    x_50        flow_36     1.0
    x_50        flow_33     -1.0
    x_50        link_50     1.0
    x_51        OBJ       2.18
    x_51        flow_15     1.0
    x_51        flow_16     -1.0
    x_51        link_51     1.0
    x_52        OBJ       2.05
    x_52        flow_48     1.0
    x_52        flow_4      -1.0
    x_52        link_52     1.0
    x_53        OBJ       1.16
    x_53        flow_4      1.0
    x_53        flow_34     -1.0
    x_53        link_53     1.0
    x_54        OBJ       1.6
    x_54        flow_15     1.0
    x_54        flow_23     -1.0
    x_54        link_54     1.0
    x_55        OBJ       60.07
    x_55        flow_39     1.0
    x_55        flow_41     -1.0
    x_55        link_55     1.0
    x_56        OBJ       2.72
    x_56        flow_6      1.0
    x_56        flow_8      -1.0
    x_56        link_56     1.0
    x_57        OBJ       63.06
    x_57        flow_17     1.0
    x_57        flow_18     -1.0
    x_57        link_57     1.0
    x_58        OBJ       70.77
    x_58        flow_31     1.0
    x_58        flow_16     -1.0
    x_58        link_58     1.0
    x_59        OBJ       2.43
    x_59        flow_17     1.0
    x_59        flow_2      -1.0
    x_59        link_59     1.0
    x_60        OBJ       2.26
    x_60        flow_10     1.0
    x_60        flow_47     -1.0
    x_60        link_60     1.0
    x_61        OBJ       52.74
    x_61        flow_4      1.0
    x_61        flow_44     -1.0
    x_61        link_61     1.0
    x_62        OBJ       0.6
    x_62        flow_35     1.0
    x_62        flow_9      -1.0
    x_62        link_62     1.0
    x_63        OBJ       1.12
    x_63        flow_2      1.0
    x_63        flow_22     -1.0
    x_63        link_63     1.0
    x_64        OBJ       64.97
    x_64        flow_35     1.0
    x_64        flow_26     -1.0
    x_64        link_64     1.0
    x_65        OBJ       21.49
    x_65        flow_10     1.0
    x_65        flow_11     -1.0
    x_65        link_65     1.0
    x_66        OBJ       68.64
    x_66        flow_26     1.0
    x_66        flow_42     -1.0
    x_66        link_66     1.0
    x_67        OBJ       0.6
    x_67        flow_44     1.0
    x_67        flow_6      -1.0
    x_67        link_67     1.0
    x_68        OBJ       2.49
    x_68        flow_29     1.0
    x_68        flow_22     -1.0
    x_68        link_68     1.0
    x_69        OBJ       1.2
    x_69        flow_42     1.0
    x_69        flow_12     -1.0
    x_69        link_69     1.0
    x_70        OBJ       43.98
    x_70        flow_17     1.0
    x_70        flow_22     -1.0
    x_70        link_70     1.0
    x_71        OBJ       2.93
    x_71        flow_21     1.0
    x_71        flow_1      -1.0
    x_71        link_71     1.0
    x_72        OBJ       40.74
    x_72        flow_2      1.0
    x_72        flow_6      -1.0
    x_72        link_72     1.0
    x_73        OBJ       2.75
    x_73        flow_38     1.0
    x_73        flow_32     -1.0
    x_73        link_73     1.0
    x_74        OBJ       2.81
    x_74        flow_45     1.0
    x_74        flow_27     -1.0
    x_74        link_74     1.0
    x_75        OBJ       2.16
    x_75        flow_23     1.0
    x_75        flow_27     -1.0
    x_75        link_75     1.0
    x_76        OBJ       38.02
    x_76        flow_42     1.0
    x_76        flow_7      -1.0
    x_76        link_76     1.0
    x_77        OBJ       53.26
    x_77        flow_20     1.0
    x_77        flow_25     -1.0
    x_77        link_77     1.0
    x_78        OBJ       30.44
    x_78        flow_24     1.0
    x_78        flow_43     -1.0
    x_78        link_78     1.0
    x_79        OBJ       1.03
    x_79        flow_35     1.0
    x_79        flow_0      -1.0
    x_79        link_79     1.0
    x_80        OBJ       1.61
    x_80        flow_41     1.0
    x_80        flow_20     -1.0
    x_80        link_80     1.0
    x_81        OBJ       37.03
    x_81        flow_47     1.0
    x_81        flow_10     -1.0
    x_81        link_81     1.0
    x_82        OBJ       65.07
    x_82        flow_21     1.0
    x_82        flow_5      -1.0
    x_82        link_82     1.0
    x_83        OBJ       1.11
    x_83        flow_12     1.0
    x_83        flow_9      -1.0
    x_83        link_83     1.0
    x_84        OBJ       2.72
    x_84        flow_49     1.0
    x_84        flow_4      -1.0
    x_84        link_84     1.0
    x_85        OBJ       1.11
    x_85        flow_44     1.0
    x_85        flow_24     -1.0
    x_85        link_85     1.0
    x_86        OBJ       66.71
    x_86        flow_48     1.0
    x_86        flow_49     -1.0
    x_86        link_86     1.0
    x_87        OBJ       1.89
    x_87        flow_44     1.0
    x_87        flow_33     -1.0
    x_87        link_87     1.0
    x_88        OBJ       60.05
    x_88        flow_29     1.0
    x_88        flow_8      -1.0
    x_88        link_88     1.0
    x_89        OBJ       56.76
    x_89        flow_20     1.0
    x_89        flow_48     -1.0
    x_89        link_89     1.0
    x_90        OBJ       0.9
    x_90        flow_27     1.0
    x_90        flow_35     -1.0
    x_90        link_90     1.0
    x_91        OBJ       2.09
    x_91        flow_16     1.0
    x_91        flow_48     -1.0
    x_91        link_91     1.0
    x_92        OBJ       1.6
    x_92        flow_31     1.0
    x_92        flow_40     -1.0
    x_92        link_92     1.0
    x_93        OBJ       1.85
    x_93        flow_17     1.0
    x_93        flow_21     -1.0
    x_93        link_93     1.0
    x_94        OBJ       1.03
    x_94        flow_24     1.0
    x_94        flow_44     -1.0
    x_94        link_94     1.0
    x_95        OBJ       1.02
    x_95        flow_34     1.0
    x_95        flow_29     -1.0
    x_95        link_95     1.0
    x_96        OBJ       2.7
    x_96        flow_37     1.0
    x_96        flow_44     -1.0
    x_96        link_96     1.0
    x_97        OBJ       1.47
    x_97        flow_0      1.0
    x_97        flow_22     -1.0
    x_97        link_97     1.0
    x_98        OBJ       52.77
    x_98        flow_26     1.0
    x_98        flow_34     -1.0
    x_98        link_98     1.0
    x_99        OBJ       1.71
    x_99        flow_31     1.0
    x_99        flow_14     -1.0
    x_99        link_99     1.0
    x_100       OBJ       70.43
    x_100       flow_43     1.0
    x_100       flow_25     -1.0
    x_100       link_100    1.0
    x_101       OBJ       55.51
    x_101       flow_34     1.0
    x_101       flow_1      -1.0
    x_101       link_101    1.0
    x_102       OBJ       1.65
    x_102       flow_41     1.0
    x_102       flow_27     -1.0
    x_102       link_102    1.0
    x_103       OBJ       1.34
    x_103       flow_20     1.0
    x_103       flow_13     -1.0
    x_103       link_103    1.0
    x_104       OBJ       0.7
    x_104       flow_48     1.0
    x_104       flow_26     -1.0
    x_104       link_104    1.0
    x_105       OBJ       0.67
    x_105       flow_3      1.0
    x_105       flow_22     -1.0
    x_105       link_105    1.0
    x_106       OBJ       31.96
    x_106       flow_48     1.0
    x_106       flow_1      -1.0
    x_106       link_106    1.0
    x_107       OBJ       0.79
    x_107       flow_15     1.0
    x_107       flow_8      -1.0
    x_107       link_107    1.0
    x_108       OBJ       30.07
    x_108       flow_44     1.0
    x_108       flow_16     -1.0
    x_108       link_108    1.0
    x_109       OBJ       29.83
    x_109       flow_45     1.0
    x_109       flow_7      -1.0
    x_109       link_109    1.0
    x_110       OBJ       74.48
    x_110       flow_1      1.0
    x_110       flow_19     -1.0
    x_110       link_110    1.0
    x_111       OBJ       69.83
    x_111       flow_12     1.0
    x_111       flow_4      -1.0
    x_111       link_111    1.0
    x_112       OBJ       56.02
    x_112       flow_49     1.0
    x_112       flow_19     -1.0
    x_112       link_112    1.0
    x_113       OBJ       24.14
    x_113       flow_34     1.0
    x_113       flow_27     -1.0
    x_113       link_113    1.0
    x_114       OBJ       58.14
    x_114       flow_6      1.0
    x_114       flow_27     -1.0
    x_114       link_114    1.0
    x_115       OBJ       1.8
    x_115       flow_9      1.0
    x_115       flow_27     -1.0
    x_115       link_115    1.0
    x_116       OBJ       2.33
    x_116       flow_30     1.0
    x_116       flow_29     -1.0
    x_116       link_116    1.0
    x_117       OBJ       1.63
    x_117       flow_15     1.0
    x_117       flow_5      -1.0
    x_117       link_117    1.0
    x_118       OBJ       0.57
    x_118       flow_39     1.0
    x_118       flow_42     -1.0
    x_118       link_118    1.0
    x_119       OBJ       1.15
    x_119       flow_31     1.0
    x_119       flow_13     -1.0
    x_119       link_119    1.0
    x_120       OBJ       51.0
    x_120       flow_44     1.0
    x_120       flow_17     -1.0
    x_120       link_120    1.0
    x_121       OBJ       2.4
    x_121       flow_46     1.0
    x_121       flow_26     -1.0
    x_121       link_121    1.0
    x_122       OBJ       1.05
    x_122       flow_28     1.0
    x_122       flow_1      -1.0
    x_122       link_122    1.0
    x_123       OBJ       1.88
    x_123       flow_42     1.0
    x_123       flow_37     -1.0
    x_123       link_123    1.0
    x_124       OBJ       1.63
    x_124       flow_35     1.0
    x_124       flow_21     -1.0
    x_124       link_124    1.0
    x_125       OBJ       0.8
    x_125       flow_7      1.0
    x_125       flow_46     -1.0
    x_125       link_125    1.0
    x_126       OBJ       2.35
    x_126       flow_44     1.0
    x_126       flow_11     -1.0
    x_126       link_126    1.0
    x_127       OBJ       78.83
    x_127       flow_48     1.0
    x_127       flow_33     -1.0
    x_127       link_127    1.0
    x_128       OBJ       0.54
    x_128       flow_14     1.0
    x_128       flow_23     -1.0
    x_128       link_128    1.0
    x_129       OBJ       61.85
    x_129       flow_2      1.0
    x_129       flow_3      -1.0
    x_129       link_129    1.0
    x_130       OBJ       0.53
    x_130       flow_48     1.0
    x_130       flow_31     -1.0
    x_130       link_130    1.0
    x_131       OBJ       0.63
    x_131       flow_28     1.0
    x_131       flow_21     -1.0
    x_131       link_131    1.0
    x_132       OBJ       0.69
    x_132       flow_7      1.0
    x_132       flow_4      -1.0
    x_132       link_132    1.0
    x_133       OBJ       1.12
    x_133       flow_36     1.0
    x_133       flow_19     -1.0
    x_133       link_133    1.0
    x_134       OBJ       42.82
    x_134       flow_39     1.0
    x_134       flow_14     -1.0
    x_134       link_134    1.0
    x_135       OBJ       2.05
    x_135       flow_37     1.0
    x_135       flow_27     -1.0
    x_135       link_135    1.0
    x_136       OBJ       1.03
    x_136       flow_6      1.0
    x_136       flow_48     -1.0
    x_136       link_136    1.0
    x_137       OBJ       29.39
    x_137       flow_15     1.0
    x_137       flow_11     -1.0
    x_137       link_137    1.0
    x_138       OBJ       1.08
    x_138       flow_38     1.0
    x_138       flow_30     -1.0
    x_138       link_138    1.0
    x_139       OBJ       75.43
    x_139       flow_29     1.0
    x_139       flow_4      -1.0
    x_139       link_139    1.0
    x_140       OBJ       31.87
    x_140       flow_37     1.0
    x_140       flow_42     -1.0
    x_140       link_140    1.0
    x_141       OBJ       69.6
    x_141       flow_41     1.0
    x_141       flow_9      -1.0
    x_141       link_141    1.0
    x_142       OBJ       54.15
    x_142       flow_19     1.0
    x_142       flow_38     -1.0
    x_142       link_142    1.0
    x_143       OBJ       1.51
    x_143       flow_29     1.0
    x_143       flow_44     -1.0
    x_143       link_143    1.0
    x_144       OBJ       0.6
    x_144       flow_31     1.0
    x_144       flow_28     -1.0
    x_144       link_144    1.0
    x_145       OBJ       1.07
    x_145       flow_38     1.0
    x_145       flow_16     -1.0
    x_145       link_145    1.0
    x_146       OBJ       79.97
    x_146       flow_36     1.0
    x_146       flow_37     -1.0
    x_146       link_146    1.0
    x_147       OBJ       30.51
    x_147       flow_36     1.0
    x_147       flow_2      -1.0
    x_147       link_147    1.0
    x_148       OBJ       46.15
    x_148       flow_17     1.0
    x_148       flow_11     -1.0
    x_148       link_148    1.0
    x_149       OBJ       1.3
    x_149       flow_30     1.0
    x_149       flow_22     -1.0
    x_149       link_149    1.0
    x_150       OBJ       37.29
    x_150       flow_21     1.0
    x_150       flow_26     -1.0
    x_150       link_150    1.0
    x_151       OBJ       0.72
    x_151       flow_48     1.0
    x_151       flow_35     -1.0
    x_151       link_151    1.0
    x_152       OBJ       69.5
    x_152       flow_49     1.0
    x_152       flow_25     -1.0
    x_152       link_152    1.0
    x_153       OBJ       1.4
    x_153       flow_26     1.0
    x_153       flow_3      -1.0
    x_153       link_153    1.0
    x_154       OBJ       1.17
    x_154       flow_28     1.0
    x_154       flow_48     -1.0
    x_154       link_154    1.0
    x_155       OBJ       0.57
    x_155       flow_28     1.0
    x_155       flow_44     -1.0
    x_155       link_155    1.0
    x_156       OBJ       1.88
    x_156       flow_15     1.0
    x_156       flow_45     -1.0
    x_156       link_156    1.0
    x_157       OBJ       0.79
    x_157       flow_14     1.0
    x_157       flow_7      -1.0
    x_157       link_157    1.0
    x_158       OBJ       36.41
    x_158       flow_45     1.0
    x_158       flow_18     -1.0
    x_158       link_158    1.0
    x_159       OBJ       43.02
    x_159       flow_15     1.0
    x_159       flow_29     -1.0
    x_159       link_159    1.0
    x_160       OBJ       36.57
    x_160       flow_47     1.0
    x_160       flow_8      -1.0
    x_160       link_160    1.0
    x_161       OBJ       0.51
    x_161       flow_21     1.0
    x_161       flow_32     -1.0
    x_161       link_161    1.0
    x_162       OBJ       46.79
    x_162       flow_42     1.0
    x_162       flow_31     -1.0
    x_162       link_162    1.0
    x_163       OBJ       47.32
    x_163       flow_35     1.0
    x_163       flow_48     -1.0
    x_163       link_163    1.0
    x_164       OBJ       34.01
    x_164       flow_44     1.0
    x_164       flow_15     -1.0
    x_164       link_164    1.0
    x_165       OBJ       2.78
    x_165       flow_20     1.0
    x_165       flow_47     -1.0
    x_165       link_165    1.0
    x_166       OBJ       2.91
    x_166       flow_31     1.0
    x_166       flow_2      -1.0
    x_166       link_166    1.0
    x_167       OBJ       47.42
    x_167       flow_28     1.0
    x_167       flow_6      -1.0
    x_167       link_167    1.0
    x_168       OBJ       35.9
    x_168       flow_4      1.0
    x_168       flow_30     -1.0
    x_168       link_168    1.0
    x_169       OBJ       71.14
    x_169       flow_41     1.0
    x_169       flow_5      -1.0
    x_169       link_169    1.0
    x_170       OBJ       65.56
    x_170       flow_20     1.0
    x_170       flow_40     -1.0
    x_170       link_170    1.0
    x_171       OBJ       2.21
    x_171       flow_39     1.0
    x_171       flow_4      -1.0
    x_171       link_171    1.0
    x_172       OBJ       0.75
    x_172       flow_47     1.0
    x_172       flow_5      -1.0
    x_172       link_172    1.0
    x_173       OBJ       1.25
    x_173       flow_6      1.0
    x_173       flow_28     -1.0
    x_173       link_173    1.0
    x_174       OBJ       1.58
    x_174       flow_3      1.0
    x_174       flow_18     -1.0
    x_174       link_174    1.0
    x_175       OBJ       30.2
    x_175       flow_36     1.0
    x_175       flow_43     -1.0
    x_175       link_175    1.0
    x_176       OBJ       49.86
    x_176       flow_24     1.0
    x_176       flow_39     -1.0
    x_176       link_176    1.0
    x_177       OBJ       1.14
    x_177       flow_29     1.0
    x_177       flow_40     -1.0
    x_177       link_177    1.0
    x_178       OBJ       29.48
    x_178       flow_29     1.0
    x_178       flow_18     -1.0
    x_178       link_178    1.0
    x_179       OBJ       45.46
    x_179       flow_37     1.0
    x_179       flow_19     -1.0
    x_179       link_179    1.0
    x_180       OBJ       71.2
    x_180       flow_19     1.0
    x_180       flow_12     -1.0
    x_180       link_180    1.0
    x_181       OBJ       79.56
    x_181       flow_36     1.0
    x_181       flow_22     -1.0
    x_181       link_181    1.0
    x_182       OBJ       1.91
    x_182       flow_42     1.0
    x_182       flow_25     -1.0
    x_182       link_182    1.0
    x_183       OBJ       69.97
    x_183       flow_3      1.0
    x_183       flow_38     -1.0
    x_183       link_183    1.0
    x_184       OBJ       33.14
    x_184       flow_14     1.0
    x_184       flow_38     -1.0
    x_184       link_184    1.0
    x_185       OBJ       59.55
    x_185       flow_43     1.0
    x_185       flow_48     -1.0
    x_185       link_185    1.0
    x_186       OBJ       38.54
    x_186       flow_6      1.0
    x_186       flow_40     -1.0
    x_186       link_186    1.0
    x_187       OBJ       2.77
    x_187       flow_23     1.0
    x_187       flow_46     -1.0
    x_187       link_187    1.0
    x_188       OBJ       1.85
    x_188       flow_11     1.0
    x_188       flow_12     -1.0
    x_188       link_188    1.0
    x_189       OBJ       35.42
    x_189       flow_32     1.0
    x_189       flow_17     -1.0
    x_189       link_189    1.0
    x_190       OBJ       68.25
    x_190       flow_18     1.0
    x_190       flow_47     -1.0
    x_190       link_190    1.0
    x_191       OBJ       71.61
    x_191       flow_9      1.0
    x_191       flow_48     -1.0
    x_191       link_191    1.0
    x_192       OBJ       1.49
    x_192       flow_35     1.0
    x_192       flow_23     -1.0
    x_192       link_192    1.0
    x_193       OBJ       60.34
    x_193       flow_29     1.0
    x_193       flow_23     -1.0
    x_193       link_193    1.0
    x_194       OBJ       2.71
    x_194       flow_14     1.0
    x_194       flow_30     -1.0
    x_194       link_194    1.0
    x_195       OBJ       2.56
    x_195       flow_14     1.0
    x_195       flow_41     -1.0
    x_195       link_195    1.0
    x_196       OBJ       0.61
    x_196       flow_41     1.0
    x_196       flow_26     -1.0
    x_196       link_196    1.0
    x_197       OBJ       1.84
    x_197       flow_7      1.0
    x_197       flow_6      -1.0
    x_197       link_197    1.0
    x_198       OBJ       52.41
    x_198       flow_42     1.0
    x_198       flow_47     -1.0
    x_198       link_198    1.0
    x_199       OBJ       70.02
    x_199       flow_9      1.0
    x_199       flow_26     -1.0
    x_199       link_199    1.0
    x_200       OBJ       1.61
    x_200       flow_2      1.0
    x_200       flow_44     -1.0
    x_200       link_200    1.0
    x_201       OBJ       42.04
    x_201       flow_23     1.0
    x_201       flow_6      -1.0
    x_201       link_201    1.0
    x_202       OBJ       0.97
    x_202       flow_22     1.0
    x_202       flow_3      -1.0
    x_202       link_202    1.0
    x_203       OBJ       58.5
    x_203       flow_29     1.0
    x_203       flow_5      -1.0
    x_203       link_203    1.0
    x_204       OBJ       0.81
    x_204       flow_3      1.0
    x_204       flow_21     -1.0
    x_204       link_204    1.0
    x_205       OBJ       2.67
    x_205       flow_13     1.0
    x_205       flow_37     -1.0
    x_205       link_205    1.0
    x_206       OBJ       2.96
    x_206       flow_38     1.0
    x_206       flow_0      -1.0
    x_206       link_206    1.0
    x_207       OBJ       2.67
    x_207       flow_16     1.0
    x_207       flow_11     -1.0
    x_207       link_207    1.0
    x_208       OBJ       0.63
    x_208       flow_20     1.0
    x_208       flow_1      -1.0
    x_208       link_208    1.0
    x_209       OBJ       1.62
    x_209       flow_7      1.0
    x_209       flow_47     -1.0
    x_209       link_209    1.0
    x_210       OBJ       22.6
    x_210       flow_32     1.0
    x_210       flow_14     -1.0
    x_210       link_210    1.0
    x_211       OBJ       2.11
    x_211       flow_42     1.0
    x_211       flow_33     -1.0
    x_211       link_211    1.0
    x_212       OBJ       49.42
    x_212       flow_25     1.0
    x_212       flow_27     -1.0
    x_212       link_212    1.0
    x_213       OBJ       23.94
    x_213       flow_5      1.0
    x_213       flow_20     -1.0
    x_213       link_213    1.0
    x_214       OBJ       42.85
    x_214       flow_37     1.0
    x_214       flow_35     -1.0
    x_214       link_214    1.0
    x_215       OBJ       25.95
    x_215       flow_29     1.0
    x_215       flow_32     -1.0
    x_215       link_215    1.0
    x_216       OBJ       32.9
    x_216       flow_49     1.0
    x_216       flow_35     -1.0
    x_216       link_216    1.0
    x_217       OBJ       43.92
    x_217       flow_26     1.0
    x_217       flow_21     -1.0
    x_217       link_217    1.0
    x_218       OBJ       42.46
    x_218       flow_27     1.0
    x_218       flow_20     -1.0
    x_218       link_218    1.0
    x_219       OBJ       25.59
    x_219       flow_4      1.0
    x_219       flow_5      -1.0
    x_219       link_219    1.0
    x_220       OBJ       55.19
    x_220       flow_23     1.0
    x_220       flow_8      -1.0
    x_220       link_220    1.0
    x_221       OBJ       76.47
    x_221       flow_26     1.0
    x_221       flow_22     -1.0
    x_221       link_221    1.0
    x_222       OBJ       1.94
    x_222       flow_38     1.0
    x_222       flow_19     -1.0
    x_222       link_222    1.0
    x_223       OBJ       41.01
    x_223       flow_30     1.0
    x_223       flow_14     -1.0
    x_223       link_223    1.0
    x_224       OBJ       68.43
    x_224       flow_48     1.0
    x_224       flow_17     -1.0
    x_224       link_224    1.0
    x_225       OBJ       59.47
    x_225       flow_35     1.0
    x_225       flow_1      -1.0
    x_225       link_225    1.0
    x_226       OBJ       38.54
    x_226       flow_11     1.0
    x_226       flow_17     -1.0
    x_226       link_226    1.0
    x_227       OBJ       44.05
    x_227       flow_11     1.0
    x_227       flow_9      -1.0
    x_227       link_227    1.0
    x_228       OBJ       1.55
    x_228       flow_47     1.0
    x_228       flow_33     -1.0
    x_228       link_228    1.0
    x_229       OBJ       2.85
    x_229       flow_19     1.0
    x_229       flow_46     -1.0
    x_229       link_229    1.0
    x_230       OBJ       22.99
    x_230       flow_9      1.0
    x_230       flow_10     -1.0
    x_230       link_230    1.0
    x_231       OBJ       1.61
    x_231       flow_42     1.0
    x_231       flow_27     -1.0
    x_231       link_231    1.0
    x_232       OBJ       0.78
    x_232       flow_32     1.0
    x_232       flow_7      -1.0
    x_232       link_232    1.0
    x_233       OBJ       22.73
    x_233       flow_31     1.0
    x_233       flow_33     -1.0
    x_233       link_233    1.0
    x_234       OBJ       2.86
    x_234       flow_3      1.0
    x_234       flow_0      -1.0
    x_234       link_234    1.0
    x_235       OBJ       0.52
    x_235       flow_16     1.0
    x_235       flow_18     -1.0
    x_235       link_235    1.0
    x_236       OBJ       33.81
    x_236       flow_8      1.0
    x_236       flow_24     -1.0
    x_236       link_236    1.0
    x_237       OBJ       2.36
    x_237       flow_22     1.0
    x_237       flow_4      -1.0
    x_237       link_237    1.0
    x_238       OBJ       54.4
    x_238       flow_4      1.0
    x_238       flow_20     -1.0
    x_238       link_238    1.0
    x_239       OBJ       2.92
    x_239       flow_18     1.0
    x_239       flow_7      -1.0
    x_239       link_239    1.0
    x_240       OBJ       0.76
    x_240       flow_23     1.0
    x_240       flow_5      -1.0
    x_240       link_240    1.0
    x_241       OBJ       1.28
    x_241       flow_33     1.0
    x_241       flow_5      -1.0
    x_241       link_241    1.0
    x_242       OBJ       2.08
    x_242       flow_49     1.0
    x_242       flow_10     -1.0
    x_242       link_242    1.0
    x_243       OBJ       2.9
    x_243       flow_49     1.0
    x_243       flow_22     -1.0
    x_243       link_243    1.0
    x_244       OBJ       0.99
    x_244       flow_15     1.0
    x_244       flow_6      -1.0
    x_244       link_244    1.0
    x_245       OBJ       2.88
    x_245       flow_48     1.0
    x_245       flow_41     -1.0
    x_245       link_245    1.0
    x_246       OBJ       46.93
    x_246       flow_48     1.0
    x_246       flow_36     -1.0
    x_246       link_246    1.0
    x_247       OBJ       39.39
    x_247       flow_41     1.0
    x_247       flow_40     -1.0
    x_247       link_247    1.0
    x_248       OBJ       1.61
    x_248       flow_9      1.0
    x_248       flow_28     -1.0
    x_248       link_248    1.0
    x_249       OBJ       0.69
    x_249       flow_37     1.0
    x_249       flow_3      -1.0
    x_249       link_249    1.0
    x_250       OBJ       24.6
    x_250       flow_3      1.0
    x_250       flow_23     -1.0
    x_250       link_250    1.0
    x_251       OBJ       43.07
    x_251       flow_5      1.0
    x_251       flow_39     -1.0
    x_251       link_251    1.0
    x_252       OBJ       2.52
    x_252       flow_47     1.0
    x_252       flow_2      -1.0
    x_252       link_252    1.0
    x_253       OBJ       47.03
    x_253       flow_32     1.0
    x_253       flow_9      -1.0
    x_253       link_253    1.0
    x_254       OBJ       2.12
    x_254       flow_21     1.0
    x_254       flow_45     -1.0
    x_254       link_254    1.0
    x_255       OBJ       2.79
    x_255       flow_39     1.0
    x_255       flow_10     -1.0
    x_255       link_255    1.0
    x_256       OBJ       67.35
    x_256       flow_21     1.0
    x_256       flow_43     -1.0
    x_256       link_256    1.0
    x_257       OBJ       43.19
    x_257       flow_21     1.0
    x_257       flow_6      -1.0
    x_257       link_257    1.0
    x_258       OBJ       40.0
    x_258       flow_42     1.0
    x_258       flow_38     -1.0
    x_258       link_258    1.0
    x_259       OBJ       61.91
    x_259       flow_22     1.0
    x_259       flow_19     -1.0
    x_259       link_259    1.0
    x_260       OBJ       1.44
    x_260       flow_45     1.0
    x_260       flow_5      -1.0
    x_260       link_260    1.0
    x_261       OBJ       76.83
    x_261       flow_8      1.0
    x_261       flow_42     -1.0
    x_261       link_261    1.0
    x_262       OBJ       50.51
    x_262       flow_5      1.0
    x_262       flow_41     -1.0
    x_262       link_262    1.0
    x_263       OBJ       2.42
    x_263       flow_11     1.0
    x_263       flow_13     -1.0
    x_263       link_263    1.0
    x_264       OBJ       2.47
    x_264       flow_9      1.0
    x_264       flow_4      -1.0
    x_264       link_264    1.0
    x_265       OBJ       2.42
    x_265       flow_2      1.0
    x_265       flow_42     -1.0
    x_265       link_265    1.0
    x_266       OBJ       68.54
    x_266       flow_11     1.0
    x_266       flow_44     -1.0
    x_266       link_266    1.0
    x_267       OBJ       2.3
    x_267       flow_2      1.0
    x_267       flow_26     -1.0
    x_267       link_267    1.0
    x_268       OBJ       46.94
    x_268       flow_18     1.0
    x_268       flow_48     -1.0
    x_268       link_268    1.0
    x_269       OBJ       2.87
    x_269       flow_30     1.0
    x_269       flow_12     -1.0
    x_269       link_269    1.0
    x_270       OBJ       50.17
    x_270       flow_49     1.0
    x_270       flow_18     -1.0
    x_270       link_270    1.0
    x_271       OBJ       1.13
    x_271       flow_12     1.0
    x_271       flow_38     -1.0
    x_271       link_271    1.0
    x_272       OBJ       62.68
    x_272       flow_23     1.0
    x_272       flow_35     -1.0
    x_272       link_272    1.0
    x_273       OBJ       2.76
    x_273       flow_48     1.0
    x_273       flow_10     -1.0
    x_273       link_273    1.0
    x_274       OBJ       73.08
    x_274       flow_5      1.0
    x_274       flow_14     -1.0
    x_274       link_274    1.0
    x_275       OBJ       34.15
    x_275       flow_3      1.0
    x_275       flow_25     -1.0
    x_275       link_275    1.0
    x_276       OBJ       0.75
    x_276       flow_14     1.0
    x_276       flow_1      -1.0
    x_276       link_276    1.0
    x_277       OBJ       2.79
    x_277       flow_9      1.0
    x_277       flow_8      -1.0
    x_277       link_277    1.0
    x_278       OBJ       46.92
    x_278       flow_8      1.0
    x_278       flow_48     -1.0
    x_278       link_278    1.0
    x_279       OBJ       0.87
    x_279       flow_1      1.0
    x_279       flow_16     -1.0
    x_279       link_279    1.0
    x_280       OBJ       1.22
    x_280       flow_33     1.0
    x_280       flow_27     -1.0
    x_280       link_280    1.0
    x_281       OBJ       57.37
    x_281       flow_15     1.0
    x_281       flow_26     -1.0
    x_281       link_281    1.0
    x_282       OBJ       57.92
    x_282       flow_31     1.0
    x_282       flow_38     -1.0
    x_282       link_282    1.0
    x_283       OBJ       2.04
    x_283       flow_9      1.0
    x_283       flow_18     -1.0
    x_283       link_283    1.0
    x_284       OBJ       51.41
    x_284       flow_11     1.0
    x_284       flow_42     -1.0
    x_284       link_284    1.0
    x_285       OBJ       50.46
    x_285       flow_34     1.0
    x_285       flow_32     -1.0
    x_285       link_285    1.0
    x_286       OBJ       78.86
    x_286       flow_30     1.0
    x_286       flow_2      -1.0
    x_286       link_286    1.0
    x_287       OBJ       57.7
    x_287       flow_22     1.0
    x_287       flow_15     -1.0
    x_287       link_287    1.0
    x_288       OBJ       1.38
    x_288       flow_48     1.0
    x_288       flow_21     -1.0
    x_288       link_288    1.0
    x_289       OBJ       78.85
    x_289       flow_11     1.0
    x_289       flow_49     -1.0
    x_289       link_289    1.0
    x_290       OBJ       76.62
    x_290       flow_8      1.0
    x_290       flow_4      -1.0
    x_290       link_290    1.0
    x_291       OBJ       38.94
    x_291       flow_2      1.0
    x_291       flow_12     -1.0
    x_291       link_291    1.0
    x_292       OBJ       2.38
    x_292       flow_34     1.0
    x_292       flow_30     -1.0
    x_292       link_292    1.0
    x_293       OBJ       39.92
    x_293       flow_49     1.0
    x_293       flow_3      -1.0
    x_293       link_293    1.0
    x_294       OBJ       73.68
    x_294       flow_27     1.0
    x_294       flow_25     -1.0
    x_294       link_294    1.0
    x_295       OBJ       2.81
    x_295       flow_31     1.0
    x_295       flow_44     -1.0
    x_295       link_295    1.0
    x_296       OBJ       1.58
    x_296       flow_5      1.0
    x_296       flow_46     -1.0
    x_296       link_296    1.0
    x_297       OBJ       0.7
    x_297       flow_34     1.0
    x_297       flow_18     -1.0
    x_297       link_297    1.0
    x_298       OBJ       30.0
    x_298       flow_28     1.0
    x_298       flow_38     -1.0
    x_298       link_298    1.0
    x_299       OBJ       41.15
    x_299       flow_2      1.0
    x_299       flow_46     -1.0
    x_299       link_299    1.0
    x_300       OBJ       2.09
    x_300       flow_40     1.0
    x_300       flow_3      -1.0
    x_300       link_300    1.0
    x_301       OBJ       0.58
    x_301       flow_47     1.0
    x_301       flow_43     -1.0
    x_301       link_301    1.0
    x_302       OBJ       1.09
    x_302       flow_28     1.0
    x_302       flow_2      -1.0
    x_302       link_302    1.0
    x_303       OBJ       0.88
    x_303       flow_24     1.0
    x_303       flow_36     -1.0
    x_303       link_303    1.0
    x_304       OBJ       54.44
    x_304       flow_23     1.0
    x_304       flow_28     -1.0
    x_304       link_304    1.0
    x_305       OBJ       2.9
    x_305       flow_20     1.0
    x_305       flow_41     -1.0
    x_305       link_305    1.0
    x_306       OBJ       2.44
    x_306       flow_24     1.0
    x_306       flow_35     -1.0
    x_306       link_306    1.0
    x_307       OBJ       79.92
    x_307       flow_39     1.0
    x_307       flow_18     -1.0
    x_307       link_307    1.0
    x_308       OBJ       0.72
    x_308       flow_11     1.0
    x_308       flow_45     -1.0
    x_308       link_308    1.0
    x_309       OBJ       0.66
    x_309       flow_20     1.0
    x_309       flow_42     -1.0
    x_309       link_309    1.0
    x_310       OBJ       62.01
    x_310       flow_10     1.0
    x_310       flow_45     -1.0
    x_310       link_310    1.0
    x_311       OBJ       34.2
    x_311       flow_7      1.0
    x_311       flow_12     -1.0
    x_311       link_311    1.0
    x_312       OBJ       2.51
    x_312       flow_35     1.0
    x_312       flow_36     -1.0
    x_312       link_312    1.0
    x_313       OBJ       3.0
    x_313       flow_5      1.0
    x_313       flow_4      -1.0
    x_313       link_313    1.0
    x_314       OBJ       1.94
    x_314       flow_26     1.0
    x_314       flow_49     -1.0
    x_314       link_314    1.0
    x_315       OBJ       2.2
    x_315       flow_41     1.0
    x_315       flow_4      -1.0
    x_315       link_315    1.0
    x_316       OBJ       2.92
    x_316       flow_40     1.0
    x_316       flow_37     -1.0
    x_316       link_316    1.0
    x_317       OBJ       38.25
    x_317       flow_3      1.0
    x_317       flow_7      -1.0
    x_317       link_317    1.0
    x_318       OBJ       51.13
    x_318       flow_14     1.0
    x_318       flow_22     -1.0
    x_318       link_318    1.0
    x_319       OBJ       53.05
    x_319       flow_16     1.0
    x_319       flow_12     -1.0
    x_319       link_319    1.0
    x_320       OBJ       2.1
    x_320       flow_39     1.0
    x_320       flow_34     -1.0
    x_320       link_320    1.0
    x_321       OBJ       56.31
    x_321       flow_42     1.0
    x_321       flow_39     -1.0
    x_321       link_321    1.0
    x_322       OBJ       2.87
    x_322       flow_2      1.0
    x_322       flow_1      -1.0
    x_322       link_322    1.0
    x_323       OBJ       45.0
    x_323       flow_41     1.0
    x_323       flow_13     -1.0
    x_323       link_323    1.0
    x_324       OBJ       2.89
    x_324       flow_40     1.0
    x_324       flow_34     -1.0
    x_324       link_324    1.0
    x_325       OBJ       0.65
    x_325       flow_19     1.0
    x_325       flow_29     -1.0
    x_325       link_325    1.0
    x_326       OBJ       0.86
    x_326       flow_29     1.0
    x_326       flow_13     -1.0
    x_326       link_326    1.0
    x_327       OBJ       27.85
    x_327       flow_46     1.0
    x_327       flow_22     -1.0
    x_327       link_327    1.0
    x_328       OBJ       0.81
    x_328       flow_6      1.0
    x_328       flow_20     -1.0
    x_328       link_328    1.0
    x_329       OBJ       45.09
    x_329       flow_18     1.0
    x_329       flow_24     -1.0
    x_329       link_329    1.0
    x_330       OBJ       31.39
    x_330       flow_20     1.0
    x_330       flow_36     -1.0
    x_330       link_330    1.0
    x_331       OBJ       49.84
    x_331       flow_29     1.0
    x_331       flow_31     -1.0
    x_331       link_331    1.0
    x_332       OBJ       32.91
    x_332       flow_32     1.0
    x_332       flow_29     -1.0
    x_332       link_332    1.0
    x_333       OBJ       70.57
    x_333       flow_18     1.0
    x_333       flow_31     -1.0
    x_333       link_333    1.0
    x_334       OBJ       65.83
    x_334       flow_8      1.0
    x_334       flow_16     -1.0
    x_334       link_334    1.0
    x_335       OBJ       41.75
    x_335       flow_3      1.0
    x_335       flow_36     -1.0
    x_335       link_335    1.0
    x_336       OBJ       36.78
    x_336       flow_32     1.0
    x_336       flow_28     -1.0
    x_336       link_336    1.0
    x_337       OBJ       0.74
    x_337       flow_39     1.0
    x_337       flow_7      -1.0
    x_337       link_337    1.0
    x_338       OBJ       1.77
    x_338       flow_48     1.0
    x_338       flow_9      -1.0
    x_338       link_338    1.0
    x_339       OBJ       68.24
    x_339       flow_2      1.0
    x_339       flow_8      -1.0
    x_339       link_339    1.0
    x_340       OBJ       39.11
    x_340       flow_8      1.0
    x_340       flow_20     -1.0
    x_340       link_340    1.0
    x_341       OBJ       50.44
    x_341       flow_47     1.0
    x_341       flow_19     -1.0
    x_341       link_341    1.0
    x_342       OBJ       2.54
    x_342       flow_45     1.0
    x_342       flow_36     -1.0
    x_342       link_342    1.0
    x_343       OBJ       67.81
    x_343       flow_7      1.0
    x_343       flow_26     -1.0
    x_343       link_343    1.0
    x_344       OBJ       35.93
    x_344       flow_40     1.0
    x_344       flow_1      -1.0
    x_344       link_344    1.0
    x_345       OBJ       0.63
    x_345       flow_37     1.0
    x_345       flow_36     -1.0
    x_345       link_345    1.0
    x_346       OBJ       70.47
    x_346       flow_40     1.0
    x_346       flow_46     -1.0
    x_346       link_346    1.0
    x_347       OBJ       62.03
    x_347       flow_15     1.0
    x_347       flow_2      -1.0
    x_347       link_347    1.0
    x_348       OBJ       2.23
    x_348       flow_20     1.0
    x_348       flow_26     -1.0
    x_348       link_348    1.0
    x_349       OBJ       64.15
    x_349       flow_39     1.0
    x_349       flow_30     -1.0
    x_349       link_349    1.0
    x_350       OBJ       79.89
    x_350       flow_33     1.0
    x_350       flow_13     -1.0
    x_350       link_350    1.0
    x_351       OBJ       1.83
    x_351       flow_20     1.0
    x_351       flow_11     -1.0
    x_351       link_351    1.0
    x_352       OBJ       68.22
    x_352       flow_49     1.0
    x_352       flow_46     -1.0
    x_352       link_352    1.0
    x_353       OBJ       1.25
    x_353       flow_12     1.0
    x_353       flow_15     -1.0
    x_353       link_353    1.0
    x_354       OBJ       49.34
    x_354       flow_45     1.0
    x_354       flow_13     -1.0
    x_354       link_354    1.0
    x_355       OBJ       1.93
    x_355       flow_46     1.0
    x_355       flow_17     -1.0
    x_355       link_355    1.0
    x_356       OBJ       37.43
    x_356       flow_22     1.0
    x_356       flow_49     -1.0
    x_356       link_356    1.0
    x_357       OBJ       59.36
    x_357       flow_5      1.0
    x_357       flow_22     -1.0
    x_357       link_357    1.0
    x_358       OBJ       1.91
    x_358       flow_12     1.0
    x_358       flow_34     -1.0
    x_358       link_358    1.0
    x_359       OBJ       34.55
    x_359       flow_39     1.0
    x_359       flow_47     -1.0
    x_359       link_359    1.0
    x_360       OBJ       0.75
    x_360       flow_14     1.0
    x_360       flow_40     -1.0
    x_360       link_360    1.0
    x_361       OBJ       1.88
    x_361       flow_49     1.0
    x_361       flow_8      -1.0
    x_361       link_361    1.0
    x_362       OBJ       1.0
    x_362       flow_41     1.0
    x_362       flow_30     -1.0
    x_362       link_362    1.0
    x_363       OBJ       2.42
    x_363       flow_18     1.0
    x_363       flow_41     -1.0
    x_363       link_363    1.0
    x_364       OBJ       76.2
    x_364       flow_34     1.0
    x_364       flow_47     -1.0
    x_364       link_364    1.0
    x_365       OBJ       22.18
    x_365       flow_26     1.0
    x_365       flow_11     -1.0
    x_365       link_365    1.0
    x_366       OBJ       77.73
    x_366       flow_31     1.0
    x_366       flow_11     -1.0
    x_366       link_366    1.0
    x_367       OBJ       26.44
    x_367       flow_0      1.0
    x_367       flow_19     -1.0
    x_367       link_367    1.0
    x_368       OBJ       49.63
    x_368       flow_29     1.0
    x_368       flow_41     -1.0
    x_368       link_368    1.0
    x_369       OBJ       39.84
    x_369       flow_17     1.0
    x_369       flow_12     -1.0
    x_369       link_369    1.0
    x_370       OBJ       2.34
    x_370       flow_16     1.0
    x_370       flow_45     -1.0
    x_370       link_370    1.0
    x_371       OBJ       58.32
    x_371       flow_12     1.0
    x_371       flow_11     -1.0
    x_371       link_371    1.0
    x_372       OBJ       2.17
    x_372       flow_32     1.0
    x_372       flow_20     -1.0
    x_372       link_372    1.0
    x_373       OBJ       20.41
    x_373       flow_30     1.0
    x_373       flow_20     -1.0
    x_373       link_373    1.0
    x_374       OBJ       54.37
    x_374       flow_21     1.0
    x_374       flow_19     -1.0
    x_374       link_374    1.0
    x_375       OBJ       1.27
    x_375       flow_3      1.0
    x_375       flow_42     -1.0
    x_375       link_375    1.0
    x_376       OBJ       0.79
    x_376       flow_45     1.0
    x_376       flow_49     -1.0
    x_376       link_376    1.0
    x_377       OBJ       2.89
    x_377       flow_23     1.0
    x_377       flow_39     -1.0
    x_377       link_377    1.0
    x_378       OBJ       2.25
    x_378       flow_47     1.0
    x_378       flow_38     -1.0
    x_378       link_378    1.0
    x_379       OBJ       65.71
    x_379       flow_34     1.0
    x_379       flow_42     -1.0
    x_379       link_379    1.0
    x_380       OBJ       2.26
    x_380       flow_5      1.0
    x_380       flow_33     -1.0
    x_380       link_380    1.0
    x_381       OBJ       74.17
    x_381       flow_7      1.0
    x_381       flow_3      -1.0
    x_381       link_381    1.0
    x_382       OBJ       2.2
    x_382       flow_20     1.0
    x_382       flow_33     -1.0
    x_382       link_382    1.0
    x_383       OBJ       0.64
    x_383       flow_5      1.0
    x_383       flow_32     -1.0
    x_383       link_383    1.0
    x_384       OBJ       1.66
    x_384       flow_29     1.0
    x_384       flow_36     -1.0
    x_384       link_384    1.0
    x_385       OBJ       0.51
    x_385       flow_1      1.0
    x_385       flow_25     -1.0
    x_385       link_385    1.0
    x_386       OBJ       0.66
    x_386       flow_2      1.0
    x_386       flow_27     -1.0
    x_386       link_386    1.0
    x_387       OBJ       0.84
    x_387       flow_18     1.0
    x_387       flow_26     -1.0
    x_387       link_387    1.0
    x_388       OBJ       2.79
    x_388       flow_23     1.0
    x_388       flow_24     -1.0
    x_388       link_388    1.0
    x_389       OBJ       27.98
    x_389       flow_43     1.0
    x_389       flow_42     -1.0
    x_389       link_389    1.0
    x_390       OBJ       0.82
    x_390       flow_11     1.0
    x_390       flow_34     -1.0
    x_390       link_390    1.0
    x_391       OBJ       45.45
    x_391       flow_29     1.0
    x_391       flow_43     -1.0
    x_391       link_391    1.0
    x_392       OBJ       2.84
    x_392       flow_22     1.0
    x_392       flow_9      -1.0
    x_392       link_392    1.0
    x_393       OBJ       73.03
    x_393       flow_26     1.0
    x_393       flow_39     -1.0
    x_393       link_393    1.0
    x_394       OBJ       46.79
    x_394       flow_4      1.0
    x_394       flow_6      -1.0
    x_394       link_394    1.0
    x_395       OBJ       44.14
    x_395       flow_3      1.0
    x_395       flow_15     -1.0
    x_395       link_395    1.0
    x_396       OBJ       37.36
    x_396       flow_3      1.0
    x_396       flow_8      -1.0
    x_396       link_396    1.0
    x_397       OBJ       66.35
    x_397       flow_36     1.0
    x_397       flow_20     -1.0
    x_397       link_397    1.0
    x_398       OBJ       51.28
    x_398       flow_19     1.0
    x_398       flow_9      -1.0
    x_398       link_398    1.0
    x_399       OBJ       72.78
    x_399       flow_3      1.0
    x_399       flow_35     -1.0
    x_399       link_399    1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       83.48
    y_0         link_0      -7.0
    y_1         OBJ       3.36
    y_1         link_1      -2.0
    y_2         OBJ       53.98
    y_2         link_2      -3.0
    y_3         OBJ       2.8
    y_3         link_3      -4.0
    y_4         OBJ       2.36
    y_4         link_4      -3.0
    y_5         OBJ       64.51
    y_5         link_5      -8.0
    y_6         OBJ       118.91
    y_6         link_6      -2.0
    y_7         OBJ       3.47
    y_7         link_7      -8.0
    y_8         OBJ       149.19
    y_8         link_8      -8.0
    y_9         OBJ       2.52
    y_9         link_9      -5.0
    y_10        OBJ       150.53
    y_10        link_10     -7.0
    y_11        OBJ       130.12
    y_11        link_11     -3.0
    y_12        OBJ       146.0
    y_12        link_12     -6.0
    y_13        OBJ       58.39
    y_13        link_13     -8.0
    y_14        OBJ       186.97
    y_14        link_14     -6.0
    y_15        OBJ       182.7
    y_15        link_15     -7.0
    y_16        OBJ       134.21
    y_16        link_16     -4.0
    y_17        OBJ       104.3
    y_17        link_17     -3.0
    y_18        OBJ       66.45
    y_18        link_18     -7.0
    y_19        OBJ       107.24
    y_19        link_19     -5.0
    y_20        OBJ       1.05
    y_20        link_20     -7.0
    y_21        OBJ       4.07
    y_21        link_21     -4.0
    y_22        OBJ       193.07
    y_22        link_22     -7.0
    y_23        OBJ       1.43
    y_23        link_23     -7.0
    y_24        OBJ       2.5
    y_24        link_24     -3.0
    y_25        OBJ       3.4
    y_25        link_25     -5.0
    y_26        OBJ       4.33
    y_26        link_26     -4.0
    y_27        OBJ       61.81
    y_27        link_27     -7.0
    y_28        OBJ       1.5
    y_28        link_28     -7.0
    y_29        OBJ       140.99
    y_29        link_29     -3.0
    y_30        OBJ       2.25
    y_30        link_30     -7.0
    y_31        OBJ       68.15
    y_31        link_31     -3.0
    y_32        OBJ       138.27
    y_32        link_32     -2.0
    y_33        OBJ       4.62
    y_33        link_33     -8.0
    y_34        OBJ       2.94
    y_34        link_34     -6.0
    y_35        OBJ       2.89
    y_35        link_35     -8.0
    y_36        OBJ       114.66
    y_36        link_36     -5.0
    y_37        OBJ       3.61
    y_37        link_37     -7.0
    y_38        OBJ       179.25
    y_38        link_38     -3.0
    y_39        OBJ       119.39
    y_39        link_39     -8.0
    y_40        OBJ       1.39
    y_40        link_40     -7.0
    y_41        OBJ       4.39
    y_41        link_41     -3.0
    y_42        OBJ       185.37
    y_42        link_42     -3.0
    y_43        OBJ       4.14
    y_43        link_43     -5.0
    y_44        OBJ       4.13
    y_44        link_44     -7.0
    y_45        OBJ       195.31
    y_45        link_45     -6.0
    y_46        OBJ       57.52
    y_46        link_46     -5.0
    y_47        OBJ       62.02
    y_47        link_47     -3.0
    y_48        OBJ       110.57
    y_48        link_48     -6.0
    y_49        OBJ       2.68
    y_49        link_49     -6.0
    y_50        OBJ       150.46
    y_50        link_50     -4.0
    y_51        OBJ       95.0
    y_51        link_51     -4.0
    y_52        OBJ       134.45
    y_52        link_52     -2.0
    y_53        OBJ       189.99
    y_53        link_53     -2.0
    y_54        OBJ       131.48
    y_54        link_54     -4.0
    y_55        OBJ       3.22
    y_55        link_55     -7.0
    y_56        OBJ       161.36
    y_56        link_56     -3.0
    y_57        OBJ       1.81
    y_57        link_57     -7.0
    y_58        OBJ       1.37
    y_58        link_58     -5.0
    y_59        OBJ       145.57
    y_59        link_59     -4.0
    y_60        OBJ       134.14
    y_60        link_60     -2.0
    y_61        OBJ       4.34
    y_61        link_61     -6.0
    y_62        OBJ       104.7
    y_62        link_62     -8.0
    y_63        OBJ       65.42
    y_63        link_63     -8.0
    y_64        OBJ       4.7
    y_64        link_64     -3.0
    y_65        OBJ       3.95
    y_65        link_65     -4.0
    y_66        OBJ       2.07
    y_66        link_66     -8.0
    y_67        OBJ       120.6
    y_67        link_67     -3.0
    y_68        OBJ       84.14
    y_68        link_68     -2.0
    y_69        OBJ       60.41
    y_69        link_69     -8.0
    y_70        OBJ       4.92
    y_70        link_70     -6.0
    y_71        OBJ       76.79
    y_71        link_71     -4.0
    y_72        OBJ       4.15
    y_72        link_72     -5.0
    y_73        OBJ       78.51
    y_73        link_73     -2.0
    y_74        OBJ       130.77
    y_74        link_74     -7.0
    y_75        OBJ       99.53
    y_75        link_75     -4.0
    y_76        OBJ       2.24
    y_76        link_76     -5.0
    y_77        OBJ       1.77
    y_77        link_77     -7.0
    y_78        OBJ       3.28
    y_78        link_78     -5.0
    y_79        OBJ       167.86
    y_79        link_79     -6.0
    y_80        OBJ       82.06
    y_80        link_80     -5.0
    y_81        OBJ       3.66
    y_81        link_81     -6.0
    y_82        OBJ       3.69
    y_82        link_82     -3.0
    y_83        OBJ       121.27
    y_83        link_83     -8.0
    y_84        OBJ       136.35
    y_84        link_84     -7.0
    y_85        OBJ       148.41
    y_85        link_85     -2.0
    y_86        OBJ       1.88
    y_86        link_86     -8.0
    y_87        OBJ       187.62
    y_87        link_87     -2.0
    y_88        OBJ       4.95
    y_88        link_88     -6.0
    y_89        OBJ       3.88
    y_89        link_89     -6.0
    y_90        OBJ       179.22
    y_90        link_90     -5.0
    y_91        OBJ       164.87
    y_91        link_91     -6.0
    y_92        OBJ       157.03
    y_92        link_92     -3.0
    y_93        OBJ       70.76
    y_93        link_93     -3.0
    y_94        OBJ       112.23
    y_94        link_94     -4.0
    y_95        OBJ       113.02
    y_95        link_95     -8.0
    y_96        OBJ       136.35
    y_96        link_96     -5.0
    y_97        OBJ       183.75
    y_97        link_97     -8.0
    y_98        OBJ       3.41
    y_98        link_98     -3.0
    y_99        OBJ       108.33
    y_99        link_99     -7.0
    y_100       OBJ       4.68
    y_100       link_100    -6.0
    y_101       OBJ       3.65
    y_101       link_101    -2.0
    y_102       OBJ       57.54
    y_102       link_102    -5.0
    y_103       OBJ       181.95
    y_103       link_103    -4.0
    y_104       OBJ       52.91
    y_104       link_104    -6.0
    y_105       OBJ       193.59
    y_105       link_105    -2.0
    y_106       OBJ       1.08
    y_106       link_106    -3.0
    y_107       OBJ       192.16
    y_107       link_107    -5.0
    y_108       OBJ       3.43
    y_108       link_108    -7.0
    y_109       OBJ       2.24
    y_109       link_109    -6.0
    y_110       OBJ       2.5
    y_110       link_110    -7.0
    y_111       OBJ       1.97
    y_111       link_111    -7.0
    y_112       OBJ       1.48
    y_112       link_112    -6.0
    y_113       OBJ       3.59
    y_113       link_113    -2.0
    y_114       OBJ       4.31
    y_114       link_114    -7.0
    y_115       OBJ       147.57
    y_115       link_115    -6.0
    y_116       OBJ       90.26
    y_116       link_116    -8.0
    y_117       OBJ       162.57
    y_117       link_117    -6.0
    y_118       OBJ       177.64
    y_118       link_118    -3.0
    y_119       OBJ       91.95
    y_119       link_119    -6.0
    y_120       OBJ       1.76
    y_120       link_120    -3.0
    y_121       OBJ       153.59
    y_121       link_121    -7.0
    y_122       OBJ       153.77
    y_122       link_122    -4.0
    y_123       OBJ       101.56
    y_123       link_123    -7.0
    y_124       OBJ       95.99
    y_124       link_124    -3.0
    y_125       OBJ       130.38
    y_125       link_125    -8.0
    y_126       OBJ       91.47
    y_126       link_126    -6.0
    y_127       OBJ       4.33
    y_127       link_127    -4.0
    y_128       OBJ       130.12
    y_128       link_128    -4.0
    y_129       OBJ       1.51
    y_129       link_129    -8.0
    y_130       OBJ       92.65
    y_130       link_130    -5.0
    y_131       OBJ       191.16
    y_131       link_131    -5.0
    y_132       OBJ       144.42
    y_132       link_132    -2.0
    y_133       OBJ       133.71
    y_133       link_133    -5.0
    y_134       OBJ       4.63
    y_134       link_134    -4.0
    y_135       OBJ       141.44
    y_135       link_135    -7.0
    y_136       OBJ       149.06
    y_136       link_136    -3.0
    y_137       OBJ       2.63
    y_137       link_137    -7.0
    y_138       OBJ       156.04
    y_138       link_138    -7.0
    y_139       OBJ       4.15
    y_139       link_139    -7.0
    y_140       OBJ       1.46
    y_140       link_140    -3.0
    y_141       OBJ       1.29
    y_141       link_141    -3.0
    y_142       OBJ       2.15
    y_142       link_142    -2.0
    y_143       OBJ       90.84
    y_143       link_143    -6.0
    y_144       OBJ       114.8
    y_144       link_144    -4.0
    y_145       OBJ       151.14
    y_145       link_145    -8.0
    y_146       OBJ       3.69
    y_146       link_146    -4.0
    y_147       OBJ       3.08
    y_147       link_147    -5.0
    y_148       OBJ       4.26
    y_148       link_148    -2.0
    y_149       OBJ       65.69
    y_149       link_149    -3.0
    y_150       OBJ       4.78
    y_150       link_150    -8.0
    y_151       OBJ       87.86
    y_151       link_151    -2.0
    y_152       OBJ       1.0
    y_152       link_152    -8.0
    y_153       OBJ       163.47
    y_153       link_153    -7.0
    y_154       OBJ       69.65
    y_154       link_154    -4.0
    y_155       OBJ       144.5
    y_155       link_155    -8.0
    y_156       OBJ       132.84
    y_156       link_156    -2.0
    y_157       OBJ       174.82
    y_157       link_157    -5.0
    y_158       OBJ       4.34
    y_158       link_158    -5.0
    y_159       OBJ       4.69
    y_159       link_159    -6.0
    y_160       OBJ       4.16
    y_160       link_160    -5.0
    y_161       OBJ       158.91
    y_161       link_161    -8.0
    y_162       OBJ       2.94
    y_162       link_162    -4.0
    y_163       OBJ       2.29
    y_163       link_163    -3.0
    y_164       OBJ       4.1
    y_164       link_164    -2.0
    y_165       OBJ       107.18
    y_165       link_165    -7.0
    y_166       OBJ       99.8
    y_166       link_166    -2.0
    y_167       OBJ       3.89
    y_167       link_167    -5.0
    y_168       OBJ       3.49
    y_168       link_168    -5.0
    y_169       OBJ       4.44
    y_169       link_169    -5.0
    y_170       OBJ       4.49
    y_170       link_170    -2.0
    y_171       OBJ       93.11
    y_171       link_171    -3.0
    y_172       OBJ       145.06
    y_172       link_172    -8.0
    y_173       OBJ       54.34
    y_173       link_173    -4.0
    y_174       OBJ       86.63
    y_174       link_174    -5.0
    y_175       OBJ       1.32
    y_175       link_175    -8.0
    y_176       OBJ       3.33
    y_176       link_176    -3.0
    y_177       OBJ       51.41
    y_177       link_177    -8.0
    y_178       OBJ       2.77
    y_178       link_178    -4.0
    y_179       OBJ       2.0
    y_179       link_179    -8.0
    y_180       OBJ       1.43
    y_180       link_180    -5.0
    y_181       OBJ       2.18
    y_181       link_181    -8.0
    y_182       OBJ       152.87
    y_182       link_182    -7.0
    y_183       OBJ       4.61
    y_183       link_183    -8.0
    y_184       OBJ       1.76
    y_184       link_184    -4.0
    y_185       OBJ       4.35
    y_185       link_185    -7.0
    y_186       OBJ       2.76
    y_186       link_186    -6.0
    y_187       OBJ       99.01
    y_187       link_187    -5.0
    y_188       OBJ       195.72
    y_188       link_188    -6.0
    y_189       OBJ       4.3
    y_189       link_189    -5.0
    y_190       OBJ       2.87
    y_190       link_190    -2.0
    y_191       OBJ       3.9
    y_191       link_191    -5.0
    y_192       OBJ       89.67
    y_192       link_192    -2.0
    y_193       OBJ       3.34
    y_193       link_193    -8.0
    y_194       OBJ       134.21
    y_194       link_194    -6.0
    y_195       OBJ       186.41
    y_195       link_195    -4.0
    y_196       OBJ       55.58
    y_196       link_196    -5.0
    y_197       OBJ       108.3
    y_197       link_197    -4.0
    y_198       OBJ       3.35
    y_198       link_198    -7.0
    y_199       OBJ       3.46
    y_199       link_199    -4.0
    y_200       OBJ       192.58
    y_200       link_200    -8.0
    y_201       OBJ       4.61
    y_201       link_201    -7.0
    y_202       OBJ       68.32
    y_202       link_202    -8.0
    y_203       OBJ       3.39
    y_203       link_203    -2.0
    y_204       OBJ       134.69
    y_204       link_204    -2.0
    y_205       OBJ       99.28
    y_205       link_205    -3.0
    y_206       OBJ       198.13
    y_206       link_206    -6.0
    y_207       OBJ       69.77
    y_207       link_207    -4.0
    y_208       OBJ       161.26
    y_208       link_208    -6.0
    y_209       OBJ       104.31
    y_209       link_209    -6.0
    y_210       OBJ       4.13
    y_210       link_210    -8.0
    y_211       OBJ       54.67
    y_211       link_211    -5.0
    y_212       OBJ       4.64
    y_212       link_212    -2.0
    y_213       OBJ       2.1
    y_213       link_213    -7.0
    y_214       OBJ       3.39
    y_214       link_214    -4.0
    y_215       OBJ       3.81
    y_215       link_215    -8.0
    y_216       OBJ       2.81
    y_216       link_216    -3.0
    y_217       OBJ       3.92
    y_217       link_217    -4.0
    y_218       OBJ       1.61
    y_218       link_218    -5.0
    y_219       OBJ       1.39
    y_219       link_219    -7.0
    y_220       OBJ       3.25
    y_220       link_220    -4.0
    y_221       OBJ       2.69
    y_221       link_221    -7.0
    y_222       OBJ       81.91
    y_222       link_222    -7.0
    y_223       OBJ       3.23
    y_223       link_223    -2.0
    y_224       OBJ       4.38
    y_224       link_224    -8.0
    y_225       OBJ       3.77
    y_225       link_225    -2.0
    y_226       OBJ       2.36
    y_226       link_226    -2.0
    y_227       OBJ       1.57
    y_227       link_227    -7.0
    y_228       OBJ       101.13
    y_228       link_228    -4.0
    y_229       OBJ       139.43
    y_229       link_229    -2.0
    y_230       OBJ       1.33
    y_230       link_230    -5.0
    y_231       OBJ       90.98
    y_231       link_231    -8.0
    y_232       OBJ       151.73
    y_232       link_232    -6.0
    y_233       OBJ       2.58
    y_233       link_233    -6.0
    y_234       OBJ       165.1
    y_234       link_234    -8.0
    y_235       OBJ       162.05
    y_235       link_235    -3.0
    y_236       OBJ       3.23
    y_236       link_236    -7.0
    y_237       OBJ       115.43
    y_237       link_237    -5.0
    y_238       OBJ       3.84
    y_238       link_238    -5.0
    y_239       OBJ       75.78
    y_239       link_239    -6.0
    y_240       OBJ       115.35
    y_240       link_240    -5.0
    y_241       OBJ       100.93
    y_241       link_241    -4.0
    y_242       OBJ       129.59
    y_242       link_242    -3.0
    y_243       OBJ       146.82
    y_243       link_243    -3.0
    y_244       OBJ       140.36
    y_244       link_244    -8.0
    y_245       OBJ       144.19
    y_245       link_245    -5.0
    y_246       OBJ       4.7
    y_246       link_246    -6.0
    y_247       OBJ       4.88
    y_247       link_247    -4.0
    y_248       OBJ       95.42
    y_248       link_248    -4.0
    y_249       OBJ       119.26
    y_249       link_249    -2.0
    y_250       OBJ       4.46
    y_250       link_250    -8.0
    y_251       OBJ       3.32
    y_251       link_251    -8.0
    y_252       OBJ       147.78
    y_252       link_252    -4.0
    y_253       OBJ       4.24
    y_253       link_253    -8.0
    y_254       OBJ       55.87
    y_254       link_254    -7.0
    y_255       OBJ       108.11
    y_255       link_255    -8.0
    y_256       OBJ       3.59
    y_256       link_256    -2.0
    y_257       OBJ       2.01
    y_257       link_257    -8.0
    y_258       OBJ       3.33
    y_258       link_258    -3.0
    y_259       OBJ       2.57
    y_259       link_259    -6.0
    y_260       OBJ       168.75
    y_260       link_260    -8.0
    y_261       OBJ       4.99
    y_261       link_261    -6.0
    y_262       OBJ       1.07
    y_262       link_262    -4.0
    y_263       OBJ       78.8
    y_263       link_263    -3.0
    y_264       OBJ       126.15
    y_264       link_264    -6.0
    y_265       OBJ       69.66
    y_265       link_265    -5.0
    y_266       OBJ       1.66
    y_266       link_266    -5.0
    y_267       OBJ       195.44
    y_267       link_267    -6.0
    y_268       OBJ       3.14
    y_268       link_268    -4.0
    y_269       OBJ       197.67
    y_269       link_269    -5.0
    y_270       OBJ       2.67
    y_270       link_270    -3.0
    y_271       OBJ       146.18
    y_271       link_271    -8.0
    y_272       OBJ       3.06
    y_272       link_272    -2.0
    y_273       OBJ       72.1
    y_273       link_273    -5.0
    y_274       OBJ       4.72
    y_274       link_274    -5.0
    y_275       OBJ       4.98
    y_275       link_275    -4.0
    y_276       OBJ       157.21
    y_276       link_276    -4.0
    y_277       OBJ       120.87
    y_277       link_277    -8.0
    y_278       OBJ       1.02
    y_278       link_278    -2.0
    y_279       OBJ       191.03
    y_279       link_279    -6.0
    y_280       OBJ       95.17
    y_280       link_280    -2.0
    y_281       OBJ       1.25
    y_281       link_281    -8.0
    y_282       OBJ       3.3
    y_282       link_282    -7.0
    y_283       OBJ       86.08
    y_283       link_283    -5.0
    y_284       OBJ       2.44
    y_284       link_284    -6.0
    y_285       OBJ       1.08
    y_285       link_285    -8.0
    y_286       OBJ       2.01
    y_286       link_286    -2.0
    y_287       OBJ       4.09
    y_287       link_287    -7.0
    y_288       OBJ       100.78
    y_288       link_288    -7.0
    y_289       OBJ       2.91
    y_289       link_289    -3.0
    y_290       OBJ       1.15
    y_290       link_290    -3.0
    y_291       OBJ       2.24
    y_291       link_291    -5.0
    y_292       OBJ       78.67
    y_292       link_292    -4.0
    y_293       OBJ       1.5
    y_293       link_293    -4.0
    y_294       OBJ       2.55
    y_294       link_294    -3.0
    y_295       OBJ       127.89
    y_295       link_295    -8.0
    y_296       OBJ       199.26
    y_296       link_296    -3.0
    y_297       OBJ       149.14
    y_297       link_297    -4.0
    y_298       OBJ       2.78
    y_298       link_298    -5.0
    y_299       OBJ       4.99
    y_299       link_299    -4.0
    y_300       OBJ       104.5
    y_300       link_300    -8.0
    y_301       OBJ       177.3
    y_301       link_301    -7.0
    y_302       OBJ       146.77
    y_302       link_302    -4.0
    y_303       OBJ       117.49
    y_303       link_303    -4.0
    y_304       OBJ       3.12
    y_304       link_304    -5.0
    y_305       OBJ       53.89
    y_305       link_305    -3.0
    y_306       OBJ       155.61
    y_306       link_306    -3.0
    y_307       OBJ       1.8
    y_307       link_307    -3.0
    y_308       OBJ       152.29
    y_308       link_308    -8.0
    y_309       OBJ       131.33
    y_309       link_309    -4.0
    y_310       OBJ       1.7
    y_310       link_310    -4.0
    y_311       OBJ       2.98
    y_311       link_311    -4.0
    y_312       OBJ       132.75
    y_312       link_312    -6.0
    y_313       OBJ       157.83
    y_313       link_313    -6.0
    y_314       OBJ       68.8
    y_314       link_314    -4.0
    y_315       OBJ       101.68
    y_315       link_315    -8.0
    y_316       OBJ       114.89
    y_316       link_316    -8.0
    y_317       OBJ       1.65
    y_317       link_317    -7.0
    y_318       OBJ       2.14
    y_318       link_318    -2.0
    y_319       OBJ       1.5
    y_319       link_319    -4.0
    y_320       OBJ       138.77
    y_320       link_320    -6.0
    y_321       OBJ       4.37
    y_321       link_321    -6.0
    y_322       OBJ       165.65
    y_322       link_322    -4.0
    y_323       OBJ       3.56
    y_323       link_323    -5.0
    y_324       OBJ       122.44
    y_324       link_324    -8.0
    y_325       OBJ       115.94
    y_325       link_325    -5.0
    y_326       OBJ       179.22
    y_326       link_326    -4.0
    y_327       OBJ       2.48
    y_327       link_327    -6.0
    y_328       OBJ       117.44
    y_328       link_328    -3.0
    y_329       OBJ       4.85
    y_329       link_329    -3.0
    y_330       OBJ       1.64
    y_330       link_330    -6.0
    y_331       OBJ       1.36
    y_331       link_331    -5.0
    y_332       OBJ       2.41
    y_332       link_332    -2.0
    y_333       OBJ       3.69
    y_333       link_333    -4.0
    y_334       OBJ       2.46
    y_334       link_334    -5.0
    y_335       OBJ       2.15
    y_335       link_335    -5.0
    y_336       OBJ       4.96
    y_336       link_336    -7.0
    y_337       OBJ       105.98
    y_337       link_337    -4.0
    y_338       OBJ       125.01
    y_338       link_338    -2.0
    y_339       OBJ       3.08
    y_339       link_339    -3.0
    y_340       OBJ       2.57
    y_340       link_340    -6.0
    y_341       OBJ       3.04
    y_341       link_341    -5.0
    y_342       OBJ       105.25
    y_342       link_342    -7.0
    y_343       OBJ       3.9
    y_343       link_343    -7.0
    y_344       OBJ       3.62
    y_344       link_344    -8.0
    y_345       OBJ       122.07
    y_345       link_345    -6.0
    y_346       OBJ       1.59
    y_346       link_346    -7.0
    y_347       OBJ       1.76
    y_347       link_347    -5.0
    y_348       OBJ       111.56
    y_348       link_348    -8.0
    y_349       OBJ       1.25
    y_349       link_349    -3.0
    y_350       OBJ       2.91
    y_350       link_350    -5.0
    y_351       OBJ       131.94
    y_351       link_351    -7.0
    y_352       OBJ       2.06
    y_352       link_352    -5.0
    y_353       OBJ       191.22
    y_353       link_353    -4.0
    y_354       OBJ       2.92
    y_354       link_354    -6.0
    y_355       OBJ       131.48
    y_355       link_355    -5.0
    y_356       OBJ       2.15
    y_356       link_356    -7.0
    y_357       OBJ       3.99
    y_357       link_357    -3.0
    y_358       OBJ       90.74
    y_358       link_358    -2.0
    y_359       OBJ       3.68
    y_359       link_359    -6.0
    y_360       OBJ       99.54
    y_360       link_360    -5.0
    y_361       OBJ       189.36
    y_361       link_361    -5.0
    y_362       OBJ       194.59
    y_362       link_362    -4.0
    y_363       OBJ       147.84
    y_363       link_363    -3.0
    y_364       OBJ       4.65
    y_364       link_364    -3.0
    y_365       OBJ       4.34
    y_365       link_365    -8.0
    y_366       OBJ       4.7
    y_366       link_366    -2.0
    y_367       OBJ       4.93
    y_367       link_367    -4.0
    y_368       OBJ       4.75
    y_368       link_368    -8.0
    y_369       OBJ       3.92
    y_369       link_369    -7.0
    y_370       OBJ       168.62
    y_370       link_370    -6.0
    y_371       OBJ       2.62
    y_371       link_371    -5.0
    y_372       OBJ       77.72
    y_372       link_372    -3.0
    y_373       OBJ       2.53
    y_373       link_373    -5.0
    y_374       OBJ       2.05
    y_374       link_374    -4.0
    y_375       OBJ       110.81
    y_375       link_375    -6.0
    y_376       OBJ       187.42
    y_376       link_376    -4.0
    y_377       OBJ       121.73
    y_377       link_377    -5.0
    y_378       OBJ       186.92
    y_378       link_378    -8.0
    y_379       OBJ       3.72
    y_379       link_379    -6.0
    y_380       OBJ       61.72
    y_380       link_380    -6.0
    y_381       OBJ       1.81
    y_381       link_381    -6.0
    y_382       OBJ       157.54
    y_382       link_382    -5.0
    y_383       OBJ       69.79
    y_383       link_383    -5.0
    y_384       OBJ       171.04
    y_384       link_384    -7.0
    y_385       OBJ       82.69
    y_385       link_385    -2.0
    y_386       OBJ       199.12
    y_386       link_386    -2.0
    y_387       OBJ       146.23
    y_387       link_387    -7.0
    y_388       OBJ       106.62
    y_388       link_388    -2.0
    y_389       OBJ       4.44
    y_389       link_389    -2.0
    y_390       OBJ       196.81
    y_390       link_390    -8.0
    y_391       OBJ       2.52
    y_391       link_391    -3.0
    y_392       OBJ       158.75
    y_392       link_392    -2.0
    y_393       OBJ       1.06
    y_393       link_393    -3.0
    y_394       OBJ       3.69
    y_394       link_394    -8.0
    y_395       OBJ       1.94
    y_395       link_395    -3.0
    y_396       OBJ       4.26
    y_396       link_396    -7.0
    y_397       OBJ       4.27
    y_397       link_397    -3.0
    y_398       OBJ       2.65
    y_398       link_398    -4.0
    y_399       OBJ       4.65
    y_399       link_399    -7.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      -25
    RHS       flow_2      38
    RHS       flow_6      -25
    RHS       flow_28     -25
    RHS       flow_39     37
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
 BV BOUND     y_80
 BV BOUND     y_81
 BV BOUND     y_82
 BV BOUND     y_83
 BV BOUND     y_84
 BV BOUND     y_85
 BV BOUND     y_86
 BV BOUND     y_87
 BV BOUND     y_88
 BV BOUND     y_89
 BV BOUND     y_90
 BV BOUND     y_91
 BV BOUND     y_92
 BV BOUND     y_93
 BV BOUND     y_94
 BV BOUND     y_95
 BV BOUND     y_96
 BV BOUND     y_97
 BV BOUND     y_98
 BV BOUND     y_99
 BV BOUND     y_100
 BV BOUND     y_101
 BV BOUND     y_102
 BV BOUND     y_103
 BV BOUND     y_104
 BV BOUND     y_105
 BV BOUND     y_106
 BV BOUND     y_107
 BV BOUND     y_108
 BV BOUND     y_109
 BV BOUND     y_110
 BV BOUND     y_111
 BV BOUND     y_112
 BV BOUND     y_113
 BV BOUND     y_114
 BV BOUND     y_115
 BV BOUND     y_116
 BV BOUND     y_117
 BV BOUND     y_118
 BV BOUND     y_119
 BV BOUND     y_120
 BV BOUND     y_121
 BV BOUND     y_122
 BV BOUND     y_123
 BV BOUND     y_124
 BV BOUND     y_125
 BV BOUND     y_126
 BV BOUND     y_127
 BV BOUND     y_128
 BV BOUND     y_129
 BV BOUND     y_130
 BV BOUND     y_131
 BV BOUND     y_132
 BV BOUND     y_133
 BV BOUND     y_134
 BV BOUND     y_135
 BV BOUND     y_136
 BV BOUND     y_137
 BV BOUND     y_138
 BV BOUND     y_139
 BV BOUND     y_140
 BV BOUND     y_141
 BV BOUND     y_142
 BV BOUND     y_143
 BV BOUND     y_144
 BV BOUND     y_145
 BV BOUND     y_146
 BV BOUND     y_147
 BV BOUND     y_148
 BV BOUND     y_149
 BV BOUND     y_150
 BV BOUND     y_151
 BV BOUND     y_152
 BV BOUND     y_153
 BV BOUND     y_154
 BV BOUND     y_155
 BV BOUND     y_156
 BV BOUND     y_157
 BV BOUND     y_158
 BV BOUND     y_159
 BV BOUND     y_160
 BV BOUND     y_161
 BV BOUND     y_162
 BV BOUND     y_163
 BV BOUND     y_164
 BV BOUND     y_165
 BV BOUND     y_166
 BV BOUND     y_167
 BV BOUND     y_168
 BV BOUND     y_169
 BV BOUND     y_170
 BV BOUND     y_171
 BV BOUND     y_172
 BV BOUND     y_173
 BV BOUND     y_174
 BV BOUND     y_175
 BV BOUND     y_176
 BV BOUND     y_177
 BV BOUND     y_178
 BV BOUND     y_179
 BV BOUND     y_180
 BV BOUND     y_181
 BV BOUND     y_182
 BV BOUND     y_183
 BV BOUND     y_184
 BV BOUND     y_185
 BV BOUND     y_186
 BV BOUND     y_187
 BV BOUND     y_188
 BV BOUND     y_189
 BV BOUND     y_190
 BV BOUND     y_191
 BV BOUND     y_192
 BV BOUND     y_193
 BV BOUND     y_194
 BV BOUND     y_195
 BV BOUND     y_196
 BV BOUND     y_197
 BV BOUND     y_198
 BV BOUND     y_199
 BV BOUND     y_200
 BV BOUND     y_201
 BV BOUND     y_202
 BV BOUND     y_203
 BV BOUND     y_204
 BV BOUND     y_205
 BV BOUND     y_206
 BV BOUND     y_207
 BV BOUND     y_208
 BV BOUND     y_209
 BV BOUND     y_210
 BV BOUND     y_211
 BV BOUND     y_212
 BV BOUND     y_213
 BV BOUND     y_214
 BV BOUND     y_215
 BV BOUND     y_216
 BV BOUND     y_217
 BV BOUND     y_218
 BV BOUND     y_219
 BV BOUND     y_220
 BV BOUND     y_221
 BV BOUND     y_222
 BV BOUND     y_223
 BV BOUND     y_224
 BV BOUND     y_225
 BV BOUND     y_226
 BV BOUND     y_227
 BV BOUND     y_228
 BV BOUND     y_229
 BV BOUND     y_230
 BV BOUND     y_231
 BV BOUND     y_232
 BV BOUND     y_233
 BV BOUND     y_234
 BV BOUND     y_235
 BV BOUND     y_236
 BV BOUND     y_237
 BV BOUND     y_238
 BV BOUND     y_239
 BV BOUND     y_240
 BV BOUND     y_241
 BV BOUND     y_242
 BV BOUND     y_243
 BV BOUND     y_244
 BV BOUND     y_245
 BV BOUND     y_246
 BV BOUND     y_247
 BV BOUND     y_248
 BV BOUND     y_249
 BV BOUND     y_250
 BV BOUND     y_251
 BV BOUND     y_252
 BV BOUND     y_253
 BV BOUND     y_254
 BV BOUND     y_255
 BV BOUND     y_256
 BV BOUND     y_257
 BV BOUND     y_258
 BV BOUND     y_259
 BV BOUND     y_260
 BV BOUND     y_261
 BV BOUND     y_262
 BV BOUND     y_263
 BV BOUND     y_264
 BV BOUND     y_265
 BV BOUND     y_266
 BV BOUND     y_267
 BV BOUND     y_268
 BV BOUND     y_269
 BV BOUND     y_270
 BV BOUND     y_271
 BV BOUND     y_272
 BV BOUND     y_273
 BV BOUND     y_274
 BV BOUND     y_275
 BV BOUND     y_276
 BV BOUND     y_277
 BV BOUND     y_278
 BV BOUND     y_279
 BV BOUND     y_280
 BV BOUND     y_281
 BV BOUND     y_282
 BV BOUND     y_283
 BV BOUND     y_284
 BV BOUND     y_285
 BV BOUND     y_286
 BV BOUND     y_287
 BV BOUND     y_288
 BV BOUND     y_289
 BV BOUND     y_290
 BV BOUND     y_291
 BV BOUND     y_292
 BV BOUND     y_293
 BV BOUND     y_294
 BV BOUND     y_295
 BV BOUND     y_296
 BV BOUND     y_297
 BV BOUND     y_298
 BV BOUND     y_299
 BV BOUND     y_300
 BV BOUND     y_301
 BV BOUND     y_302
 BV BOUND     y_303
 BV BOUND     y_304
 BV BOUND     y_305
 BV BOUND     y_306
 BV BOUND     y_307
 BV BOUND     y_308
 BV BOUND     y_309
 BV BOUND     y_310
 BV BOUND     y_311
 BV BOUND     y_312
 BV BOUND     y_313
 BV BOUND     y_314
 BV BOUND     y_315
 BV BOUND     y_316
 BV BOUND     y_317
 BV BOUND     y_318
 BV BOUND     y_319
 BV BOUND     y_320
 BV BOUND     y_321
 BV BOUND     y_322
 BV BOUND     y_323
 BV BOUND     y_324
 BV BOUND     y_325
 BV BOUND     y_326
 BV BOUND     y_327
 BV BOUND     y_328
 BV BOUND     y_329
 BV BOUND     y_330
 BV BOUND     y_331
 BV BOUND     y_332
 BV BOUND     y_333
 BV BOUND     y_334
 BV BOUND     y_335
 BV BOUND     y_336
 BV BOUND     y_337
 BV BOUND     y_338
 BV BOUND     y_339
 BV BOUND     y_340
 BV BOUND     y_341
 BV BOUND     y_342
 BV BOUND     y_343
 BV BOUND     y_344
 BV BOUND     y_345
 BV BOUND     y_346
 BV BOUND     y_347
 BV BOUND     y_348
 BV BOUND     y_349
 BV BOUND     y_350
 BV BOUND     y_351
 BV BOUND     y_352
 BV BOUND     y_353
 BV BOUND     y_354
 BV BOUND     y_355
 BV BOUND     y_356
 BV BOUND     y_357
 BV BOUND     y_358
 BV BOUND     y_359
 BV BOUND     y_360
 BV BOUND     y_361
 BV BOUND     y_362
 BV BOUND     y_363
 BV BOUND     y_364
 BV BOUND     y_365
 BV BOUND     y_366
 BV BOUND     y_367
 BV BOUND     y_368
 BV BOUND     y_369
 BV BOUND     y_370
 BV BOUND     y_371
 BV BOUND     y_372
 BV BOUND     y_373
 BV BOUND     y_374
 BV BOUND     y_375
 BV BOUND     y_376
 BV BOUND     y_377
 BV BOUND     y_378
 BV BOUND     y_379
 BV BOUND     y_380
 BV BOUND     y_381
 BV BOUND     y_382
 BV BOUND     y_383
 BV BOUND     y_384
 BV BOUND     y_385
 BV BOUND     y_386
 BV BOUND     y_387
 BV BOUND     y_388
 BV BOUND     y_389
 BV BOUND     y_390
 BV BOUND     y_391
 BV BOUND     y_392
 BV BOUND     y_393
 BV BOUND     y_394
 BV BOUND     y_395
 BV BOUND     y_396
 BV BOUND     y_397
 BV BOUND     y_398
 BV BOUND     y_399
ENDATA
