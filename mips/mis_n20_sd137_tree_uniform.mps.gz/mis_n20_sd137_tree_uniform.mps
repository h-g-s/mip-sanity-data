NAME          MIS
ROWS
 N  OBJ
 L  EDGE_4_12
 L  EDGE_14_19
 L  EDGE_0_2
 L  EDGE_4_18
 L  EDGE_9_11
 L  EDGE_9_17
 L  EDGE_1_9
 L  EDGE_10_18
 L  EDGE_0_17
 L  EDGE_6_11
 L  EDGE_16_19
 L  EDGE_5_9
 L  EDGE_11_19
 L  EDGE_1_8
 L  EDGE_15_16
 L  EDGE_4_7
 L  EDGE_0_3
 L  EDGE_1_4
 L  EDGE_13_15
COLUMNS
    x_0         OBJ       -10
    x_0         EDGE_0_2  1.0
    x_0         EDGE_0_17  1.0
    x_0         EDGE_0_3  1.0
    x_1         OBJ       -24
    x_1         EDGE_1_9  1.0
    x_1         EDGE_1_8  1.0
    x_1         EDGE_1_4  1.0
    x_2         OBJ       -53
    x_2         EDGE_0_2  1.0
    x_3         OBJ       -42
    x_3         EDGE_0_3  1.0
    x_4         OBJ       -25
    x_4         EDGE_4_12  1.0
    x_4         EDGE_4_18  1.0
    x_4         EDGE_4_7  1.0
    x_4         EDGE_1_4  1.0
    x_5         OBJ       -30
    x_5         EDGE_5_9  1.0
    x_6         OBJ       -63
    x_6         EDGE_6_11  1.0
    x_7         OBJ       -45
    x_7         EDGE_4_7  1.0
    x_8         OBJ       -2
    x_8         EDGE_1_8  1.0
    x_9         OBJ       -52
    x_9         EDGE_9_11  1.0
    x_9         EDGE_9_17  1.0
    x_9         EDGE_1_9  1.0
    x_9         EDGE_5_9  1.0
    x_10        OBJ       -66
    x_10        EDGE_10_18  1.0
    x_11        OBJ       -42
    x_11        EDGE_9_11  1.0
    x_11        EDGE_6_11  1.0
    x_11        EDGE_11_19  1.0
    x_12        OBJ       -51
    x_12        EDGE_4_12  1.0
    x_13        OBJ       -68
    x_13        EDGE_13_15  1.0
    x_14        OBJ       -61
    x_14        EDGE_14_19  1.0
    x_15        OBJ       -18
    x_15        EDGE_15_16  1.0
    x_15        EDGE_13_15  1.0
    x_16        OBJ       -55
    x_16        EDGE_16_19  1.0
    x_16        EDGE_15_16  1.0
    x_17        OBJ       -67
    x_17        EDGE_9_17  1.0
    x_17        EDGE_0_17  1.0
    x_18        OBJ       -67
    x_18        EDGE_4_18  1.0
    x_18        EDGE_10_18  1.0
    x_19        OBJ       -43
    x_19        EDGE_14_19  1.0
    x_19        EDGE_16_19  1.0
    x_19        EDGE_11_19  1.0
RHS
    RHS1      EDGE_4_12  1.0
    RHS1      EDGE_14_19  1.0
    RHS1      EDGE_0_2  1.0
    RHS1      EDGE_4_18  1.0
    RHS1      EDGE_9_11  1.0
    RHS1      EDGE_9_17  1.0
    RHS1      EDGE_1_9  1.0
    RHS1      EDGE_10_18  1.0
    RHS1      EDGE_0_17  1.0
    RHS1      EDGE_6_11  1.0
    RHS1      EDGE_16_19  1.0
    RHS1      EDGE_5_9  1.0
    RHS1      EDGE_11_19  1.0
    RHS1      EDGE_1_8  1.0
    RHS1      EDGE_15_16  1.0
    RHS1      EDGE_4_7  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_1_4  1.0
    RHS1      EDGE_13_15  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
ENDATA
