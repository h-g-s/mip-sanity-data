NAME          BPC
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 E  ASSIGN_11
 E  ASSIGN_12
 E  ASSIGN_13
 E  ASSIGN_14
 E  ASSIGN_15
 L  CAP_0
 L  CAP_1
 L  CAP_2
 L  CAP_3
 L  CAP_4
 L  CAP_5
 L  CAP_6
 L  CAP_7
 L  CAP_8
 L  CAP_9
 L  CAP_10
 L  CAP_11
 L  CAP_12
 L  CAP_13
 L  CAP_14
 L  CAP_15
 L  CONF_3_10_0
 L  CONF_3_10_1
 L  CONF_3_10_2
 L  CONF_3_10_3
 L  CONF_3_10_4
 L  CONF_3_10_5
 L  CONF_3_10_6
 L  CONF_3_10_7
 L  CONF_3_10_8
 L  CONF_3_10_9
 L  CONF_3_10_10
 L  CONF_3_10_11
 L  CONF_3_10_12
 L  CONF_3_10_13
 L  CONF_3_10_14
 L  CONF_3_10_15
 L  CONF_0_2_0
 L  CONF_0_2_1
 L  CONF_0_2_2
 L  CONF_0_2_3
 L  CONF_0_2_4
 L  CONF_0_2_5
 L  CONF_0_2_6
 L  CONF_0_2_7
 L  CONF_0_2_8
 L  CONF_0_2_9
 L  CONF_0_2_10
 L  CONF_0_2_11
 L  CONF_0_2_12
 L  CONF_0_2_13
 L  CONF_0_2_14
 L  CONF_0_2_15
 L  CONF_8_12_0
 L  CONF_8_12_1
 L  CONF_8_12_2
 L  CONF_8_12_3
 L  CONF_8_12_4
 L  CONF_8_12_5
 L  CONF_8_12_6
 L  CONF_8_12_7
 L  CONF_8_12_8
 L  CONF_8_12_9
 L  CONF_8_12_10
 L  CONF_8_12_11
 L  CONF_8_12_12
 L  CONF_8_12_13
 L  CONF_8_12_14
 L  CONF_8_12_15
 L  CONF_1_6_0
 L  CONF_1_6_1
 L  CONF_1_6_2
 L  CONF_1_6_3
 L  CONF_1_6_4
 L  CONF_1_6_5
 L  CONF_1_6_6
 L  CONF_1_6_7
 L  CONF_1_6_8
 L  CONF_1_6_9
 L  CONF_1_6_10
 L  CONF_1_6_11
 L  CONF_1_6_12
 L  CONF_1_6_13
 L  CONF_1_6_14
 L  CONF_1_6_15
 L  CONF_0_14_0
 L  CONF_0_14_1
 L  CONF_0_14_2
 L  CONF_0_14_3
 L  CONF_0_14_4
 L  CONF_0_14_5
 L  CONF_0_14_6
 L  CONF_0_14_7
 L  CONF_0_14_8
 L  CONF_0_14_9
 L  CONF_0_14_10
 L  CONF_0_14_11
 L  CONF_0_14_12
 L  CONF_0_14_13
 L  CONF_0_14_14
 L  CONF_0_14_15
 L  CONF_1_9_0
 L  CONF_1_9_1
 L  CONF_1_9_2
 L  CONF_1_9_3
 L  CONF_1_9_4
 L  CONF_1_9_5
 L  CONF_1_9_6
 L  CONF_1_9_7
 L  CONF_1_9_8
 L  CONF_1_9_9
 L  CONF_1_9_10
 L  CONF_1_9_11
 L  CONF_1_9_12
 L  CONF_1_9_13
 L  CONF_1_9_14
 L  CONF_1_9_15
 L  CONF_0_11_0
 L  CONF_0_11_1
 L  CONF_0_11_2
 L  CONF_0_11_3
 L  CONF_0_11_4
 L  CONF_0_11_5
 L  CONF_0_11_6
 L  CONF_0_11_7
 L  CONF_0_11_8
 L  CONF_0_11_9
 L  CONF_0_11_10
 L  CONF_0_11_11
 L  CONF_0_11_12
 L  CONF_0_11_13
 L  CONF_0_11_14
 L  CONF_0_11_15
 L  CONF_6_11_0
 L  CONF_6_11_1
 L  CONF_6_11_2
 L  CONF_6_11_3
 L  CONF_6_11_4
 L  CONF_6_11_5
 L  CONF_6_11_6
 L  CONF_6_11_7
 L  CONF_6_11_8
 L  CONF_6_11_9
 L  CONF_6_11_10
 L  CONF_6_11_11
 L  CONF_6_11_12
 L  CONF_6_11_13
 L  CONF_6_11_14
 L  CONF_6_11_15
 L  CONF_6_14_0
 L  CONF_6_14_1
 L  CONF_6_14_2
 L  CONF_6_14_3
 L  CONF_6_14_4
 L  CONF_6_14_5
 L  CONF_6_14_6
 L  CONF_6_14_7
 L  CONF_6_14_8
 L  CONF_6_14_9
 L  CONF_6_14_10
 L  CONF_6_14_11
 L  CONF_6_14_12
 L  CONF_6_14_13
 L  CONF_6_14_14
 L  CONF_6_14_15
 L  CONF_7_13_0
 L  CONF_7_13_1
 L  CONF_7_13_2
 L  CONF_7_13_3
 L  CONF_7_13_4
 L  CONF_7_13_5
 L  CONF_7_13_6
 L  CONF_7_13_7
 L  CONF_7_13_8
 L  CONF_7_13_9
 L  CONF_7_13_10
 L  CONF_7_13_11
 L  CONF_7_13_12
 L  CONF_7_13_13
 L  CONF_7_13_14
 L  CONF_7_13_15
 L  CONF_4_8_0
 L  CONF_4_8_1
 L  CONF_4_8_2
 L  CONF_4_8_3
 L  CONF_4_8_4
 L  CONF_4_8_5
 L  CONF_4_8_6
 L  CONF_4_8_7
 L  CONF_4_8_8
 L  CONF_4_8_9
 L  CONF_4_8_10
 L  CONF_4_8_11
 L  CONF_4_8_12
 L  CONF_4_8_13
 L  CONF_4_8_14
 L  CONF_4_8_15
 L  CONF_4_11_0
 L  CONF_4_11_1
 L  CONF_4_11_2
 L  CONF_4_11_3
 L  CONF_4_11_4
 L  CONF_4_11_5
 L  CONF_4_11_6
 L  CONF_4_11_7
 L  CONF_4_11_8
 L  CONF_4_11_9
 L  CONF_4_11_10
 L  CONF_4_11_11
 L  CONF_4_11_12
 L  CONF_4_11_13
 L  CONF_4_11_14
 L  CONF_4_11_15
 L  CONF_8_14_0
 L  CONF_8_14_1
 L  CONF_8_14_2
 L  CONF_8_14_3
 L  CONF_8_14_4
 L  CONF_8_14_5
 L  CONF_8_14_6
 L  CONF_8_14_7
 L  CONF_8_14_8
 L  CONF_8_14_9
 L  CONF_8_14_10
 L  CONF_8_14_11
 L  CONF_8_14_12
 L  CONF_8_14_13
 L  CONF_8_14_14
 L  CONF_8_14_15
 L  CONF_0_4_0
 L  CONF_0_4_1
 L  CONF_0_4_2
 L  CONF_0_4_3
 L  CONF_0_4_4
 L  CONF_0_4_5
 L  CONF_0_4_6
 L  CONF_0_4_7
 L  CONF_0_4_8
 L  CONF_0_4_9
 L  CONF_0_4_10
 L  CONF_0_4_11
 L  CONF_0_4_12
 L  CONF_0_4_13
 L  CONF_0_4_14
 L  CONF_0_4_15
 L  CONF_2_7_0
 L  CONF_2_7_1
 L  CONF_2_7_2
 L  CONF_2_7_3
 L  CONF_2_7_4
 L  CONF_2_7_5
 L  CONF_2_7_6
 L  CONF_2_7_7
 L  CONF_2_7_8
 L  CONF_2_7_9
 L  CONF_2_7_10
 L  CONF_2_7_11
 L  CONF_2_7_12
 L  CONF_2_7_13
 L  CONF_2_7_14
 L  CONF_2_7_15
 L  CONF_1_8_0
 L  CONF_1_8_1
 L  CONF_1_8_2
 L  CONF_1_8_3
 L  CONF_1_8_4
 L  CONF_1_8_5
 L  CONF_1_8_6
 L  CONF_1_8_7
 L  CONF_1_8_8
 L  CONF_1_8_9
 L  CONF_1_8_10
 L  CONF_1_8_11
 L  CONF_1_8_12
 L  CONF_1_8_13
 L  CONF_1_8_14
 L  CONF_1_8_15
 L  CONF_7_15_0
 L  CONF_7_15_1
 L  CONF_7_15_2
 L  CONF_7_15_3
 L  CONF_7_15_4
 L  CONF_7_15_5
 L  CONF_7_15_6
 L  CONF_7_15_7
 L  CONF_7_15_8
 L  CONF_7_15_9
 L  CONF_7_15_10
 L  CONF_7_15_11
 L  CONF_7_15_12
 L  CONF_7_15_13
 L  CONF_7_15_14
 L  CONF_7_15_15
 L  CONF_4_7_0
 L  CONF_4_7_1
 L  CONF_4_7_2
 L  CONF_4_7_3
 L  CONF_4_7_4
 L  CONF_4_7_5
 L  CONF_4_7_6
 L  CONF_4_7_7
 L  CONF_4_7_8
 L  CONF_4_7_9
 L  CONF_4_7_10
 L  CONF_4_7_11
 L  CONF_4_7_12
 L  CONF_4_7_13
 L  CONF_4_7_14
 L  CONF_4_7_15
 L  CONF_3_5_0
 L  CONF_3_5_1
 L  CONF_3_5_2
 L  CONF_3_5_3
 L  CONF_3_5_4
 L  CONF_3_5_5
 L  CONF_3_5_6
 L  CONF_3_5_7
 L  CONF_3_5_8
 L  CONF_3_5_9
 L  CONF_3_5_10
 L  CONF_3_5_11
 L  CONF_3_5_12
 L  CONF_3_5_13
 L  CONF_3_5_14
 L  CONF_3_5_15
 L  CONF_12_14_0
 L  CONF_12_14_1
 L  CONF_12_14_2
 L  CONF_12_14_3
 L  CONF_12_14_4
 L  CONF_12_14_5
 L  CONF_12_14_6
 L  CONF_12_14_7
 L  CONF_12_14_8
 L  CONF_12_14_9
 L  CONF_12_14_10
 L  CONF_12_14_11
 L  CONF_12_14_12
 L  CONF_12_14_13
 L  CONF_12_14_14
 L  CONF_12_14_15
 L  CONF_5_14_0
 L  CONF_5_14_1
 L  CONF_5_14_2
 L  CONF_5_14_3
 L  CONF_5_14_4
 L  CONF_5_14_5
 L  CONF_5_14_6
 L  CONF_5_14_7
 L  CONF_5_14_8
 L  CONF_5_14_9
 L  CONF_5_14_10
 L  CONF_5_14_11
 L  CONF_5_14_12
 L  CONF_5_14_13
 L  CONF_5_14_14
 L  CONF_5_14_15
 L  CONF_9_12_0
 L  CONF_9_12_1
 L  CONF_9_12_2
 L  CONF_9_12_3
 L  CONF_9_12_4
 L  CONF_9_12_5
 L  CONF_9_12_6
 L  CONF_9_12_7
 L  CONF_9_12_8
 L  CONF_9_12_9
 L  CONF_9_12_10
 L  CONF_9_12_11
 L  CONF_9_12_12
 L  CONF_9_12_13
 L  CONF_9_12_14
 L  CONF_9_12_15
 L  CONF_0_9_0
 L  CONF_0_9_1
 L  CONF_0_9_2
 L  CONF_0_9_3
 L  CONF_0_9_4
 L  CONF_0_9_5
 L  CONF_0_9_6
 L  CONF_0_9_7
 L  CONF_0_9_8
 L  CONF_0_9_9
 L  CONF_0_9_10
 L  CONF_0_9_11
 L  CONF_0_9_12
 L  CONF_0_9_13
 L  CONF_0_9_14
 L  CONF_0_9_15
 L  CONF_8_10_0
 L  CONF_8_10_1
 L  CONF_8_10_2
 L  CONF_8_10_3
 L  CONF_8_10_4
 L  CONF_8_10_5
 L  CONF_8_10_6
 L  CONF_8_10_7
 L  CONF_8_10_8
 L  CONF_8_10_9
 L  CONF_8_10_10
 L  CONF_8_10_11
 L  CONF_8_10_12
 L  CONF_8_10_13
 L  CONF_8_10_14
 L  CONF_8_10_15
 L  CONF_0_12_0
 L  CONF_0_12_1
 L  CONF_0_12_2
 L  CONF_0_12_3
 L  CONF_0_12_4
 L  CONF_0_12_5
 L  CONF_0_12_6
 L  CONF_0_12_7
 L  CONF_0_12_8
 L  CONF_0_12_9
 L  CONF_0_12_10
 L  CONF_0_12_11
 L  CONF_0_12_12
 L  CONF_0_12_13
 L  CONF_0_12_14
 L  CONF_0_12_15
 L  CONF_2_9_0
 L  CONF_2_9_1
 L  CONF_2_9_2
 L  CONF_2_9_3
 L  CONF_2_9_4
 L  CONF_2_9_5
 L  CONF_2_9_6
 L  CONF_2_9_7
 L  CONF_2_9_8
 L  CONF_2_9_9
 L  CONF_2_9_10
 L  CONF_2_9_11
 L  CONF_2_9_12
 L  CONF_2_9_13
 L  CONF_2_9_14
 L  CONF_2_9_15
 L  CONF_2_6_0
 L  CONF_2_6_1
 L  CONF_2_6_2
 L  CONF_2_6_3
 L  CONF_2_6_4
 L  CONF_2_6_5
 L  CONF_2_6_6
 L  CONF_2_6_7
 L  CONF_2_6_8
 L  CONF_2_6_9
 L  CONF_2_6_10
 L  CONF_2_6_11
 L  CONF_2_6_12
 L  CONF_2_6_13
 L  CONF_2_6_14
 L  CONF_2_6_15
 L  CONF_2_15_0
 L  CONF_2_15_1
 L  CONF_2_15_2
 L  CONF_2_15_3
 L  CONF_2_15_4
 L  CONF_2_15_5
 L  CONF_2_15_6
 L  CONF_2_15_7
 L  CONF_2_15_8
 L  CONF_2_15_9
 L  CONF_2_15_10
 L  CONF_2_15_11
 L  CONF_2_15_12
 L  CONF_2_15_13
 L  CONF_2_15_14
 L  CONF_2_15_15
 L  CONF_13_15_0
 L  CONF_13_15_1
 L  CONF_13_15_2
 L  CONF_13_15_3
 L  CONF_13_15_4
 L  CONF_13_15_5
 L  CONF_13_15_6
 L  CONF_13_15_7
 L  CONF_13_15_8
 L  CONF_13_15_9
 L  CONF_13_15_10
 L  CONF_13_15_11
 L  CONF_13_15_12
 L  CONF_13_15_13
 L  CONF_13_15_14
 L  CONF_13_15_15
 L  CONF_7_14_0
 L  CONF_7_14_1
 L  CONF_7_14_2
 L  CONF_7_14_3
 L  CONF_7_14_4
 L  CONF_7_14_5
 L  CONF_7_14_6
 L  CONF_7_14_7
 L  CONF_7_14_8
 L  CONF_7_14_9
 L  CONF_7_14_10
 L  CONF_7_14_11
 L  CONF_7_14_12
 L  CONF_7_14_13
 L  CONF_7_14_14
 L  CONF_7_14_15
COLUMNS
    x_0_0       ASSIGN_0  1.0
    x_0_0       CAP_0  20
    x_0_0       CONF_0_2_0  1.0
    x_0_0       CONF_0_4_0  1.0
    x_0_0       CONF_0_9_0  1.0
    x_0_0       CONF_0_11_0  1.0
    x_0_0       CONF_0_12_0  1.0
    x_0_0       CONF_0_14_0  1.0
    x_0_1       ASSIGN_0  1.0
    x_0_1       CAP_1  20
    x_0_1       CONF_0_2_1  1.0
    x_0_1       CONF_0_4_1  1.0
    x_0_1       CONF_0_9_1  1.0
    x_0_1       CONF_0_11_1  1.0
    x_0_1       CONF_0_12_1  1.0
    x_0_1       CONF_0_14_1  1.0
    x_0_2       ASSIGN_0  1.0
    x_0_2       CAP_2  20
    x_0_2       CONF_0_2_2  1.0
    x_0_2       CONF_0_4_2  1.0
    x_0_2       CONF_0_9_2  1.0
    x_0_2       CONF_0_11_2  1.0
    x_0_2       CONF_0_12_2  1.0
    x_0_2       CONF_0_14_2  1.0
    x_0_3       ASSIGN_0  1.0
    x_0_3       CAP_3  20
    x_0_3       CONF_0_2_3  1.0
    x_0_3       CONF_0_4_3  1.0
    x_0_3       CONF_0_9_3  1.0
    x_0_3       CONF_0_11_3  1.0
    x_0_3       CONF_0_12_3  1.0
    x_0_3       CONF_0_14_3  1.0
    x_0_4       ASSIGN_0  1.0
    x_0_4       CAP_4  20
    x_0_4       CONF_0_2_4  1.0
    x_0_4       CONF_0_4_4  1.0
    x_0_4       CONF_0_9_4  1.0
    x_0_4       CONF_0_11_4  1.0
    x_0_4       CONF_0_12_4  1.0
    x_0_4       CONF_0_14_4  1.0
    x_0_5       ASSIGN_0  1.0
    x_0_5       CAP_5  20
    x_0_5       CONF_0_2_5  1.0
    x_0_5       CONF_0_4_5  1.0
    x_0_5       CONF_0_9_5  1.0
    x_0_5       CONF_0_11_5  1.0
    x_0_5       CONF_0_12_5  1.0
    x_0_5       CONF_0_14_5  1.0
    x_0_6       ASSIGN_0  1.0
    x_0_6       CAP_6  20
    x_0_6       CONF_0_2_6  1.0
    x_0_6       CONF_0_4_6  1.0
    x_0_6       CONF_0_9_6  1.0
    x_0_6       CONF_0_11_6  1.0
    x_0_6       CONF_0_12_6  1.0
    x_0_6       CONF_0_14_6  1.0
    x_0_7       ASSIGN_0  1.0
    x_0_7       CAP_7  20
    x_0_7       CONF_0_2_7  1.0
    x_0_7       CONF_0_4_7  1.0
    x_0_7       CONF_0_9_7  1.0
    x_0_7       CONF_0_11_7  1.0
    x_0_7       CONF_0_12_7  1.0
    x_0_7       CONF_0_14_7  1.0
    x_0_8       ASSIGN_0  1.0
    x_0_8       CAP_8  20
    x_0_8       CONF_0_2_8  1.0
    x_0_8       CONF_0_4_8  1.0
    x_0_8       CONF_0_9_8  1.0
    x_0_8       CONF_0_11_8  1.0
    x_0_8       CONF_0_12_8  1.0
    x_0_8       CONF_0_14_8  1.0
    x_0_9       ASSIGN_0  1.0
    x_0_9       CAP_9  20
    x_0_9       CONF_0_2_9  1.0
    x_0_9       CONF_0_4_9  1.0
    x_0_9       CONF_0_9_9  1.0
    x_0_9       CONF_0_11_9  1.0
    x_0_9       CONF_0_12_9  1.0
    x_0_9       CONF_0_14_9  1.0
    x_0_10      ASSIGN_0  1.0
    x_0_10      CAP_10  20
    x_0_10      CONF_0_2_10  1.0
    x_0_10      CONF_0_4_10  1.0
    x_0_10      CONF_0_9_10  1.0
    x_0_10      CONF_0_11_10  1.0
    x_0_10      CONF_0_12_10  1.0
    x_0_10      CONF_0_14_10  1.0
    x_0_11      ASSIGN_0  1.0
    x_0_11      CAP_11  20
    x_0_11      CONF_0_2_11  1.0
    x_0_11      CONF_0_4_11  1.0
    x_0_11      CONF_0_9_11  1.0
    x_0_11      CONF_0_11_11  1.0
    x_0_11      CONF_0_12_11  1.0
    x_0_11      CONF_0_14_11  1.0
    x_0_12      ASSIGN_0  1.0
    x_0_12      CAP_12  20
    x_0_12      CONF_0_2_12  1.0
    x_0_12      CONF_0_4_12  1.0
    x_0_12      CONF_0_9_12  1.0
    x_0_12      CONF_0_11_12  1.0
    x_0_12      CONF_0_12_12  1.0
    x_0_12      CONF_0_14_12  1.0
    x_0_13      ASSIGN_0  1.0
    x_0_13      CAP_13  20
    x_0_13      CONF_0_2_13  1.0
    x_0_13      CONF_0_4_13  1.0
    x_0_13      CONF_0_9_13  1.0
    x_0_13      CONF_0_11_13  1.0
    x_0_13      CONF_0_12_13  1.0
    x_0_13      CONF_0_14_13  1.0
    x_0_14      ASSIGN_0  1.0
    x_0_14      CAP_14  20
    x_0_14      CONF_0_2_14  1.0
    x_0_14      CONF_0_4_14  1.0
    x_0_14      CONF_0_9_14  1.0
    x_0_14      CONF_0_11_14  1.0
    x_0_14      CONF_0_12_14  1.0
    x_0_14      CONF_0_14_14  1.0
    x_0_15      ASSIGN_0  1.0
    x_0_15      CAP_15  20
    x_0_15      CONF_0_2_15  1.0
    x_0_15      CONF_0_4_15  1.0
    x_0_15      CONF_0_9_15  1.0
    x_0_15      CONF_0_11_15  1.0
    x_0_15      CONF_0_12_15  1.0
    x_0_15      CONF_0_14_15  1.0
    x_1_0       ASSIGN_1  1.0
    x_1_0       CAP_0  14
    x_1_0       CONF_1_6_0  1.0
    x_1_0       CONF_1_8_0  1.0
    x_1_0       CONF_1_9_0  1.0
    x_1_1       ASSIGN_1  1.0
    x_1_1       CAP_1  14
    x_1_1       CONF_1_6_1  1.0
    x_1_1       CONF_1_8_1  1.0
    x_1_1       CONF_1_9_1  1.0
    x_1_2       ASSIGN_1  1.0
    x_1_2       CAP_2  14
    x_1_2       CONF_1_6_2  1.0
    x_1_2       CONF_1_8_2  1.0
    x_1_2       CONF_1_9_2  1.0
    x_1_3       ASSIGN_1  1.0
    x_1_3       CAP_3  14
    x_1_3       CONF_1_6_3  1.0
    x_1_3       CONF_1_8_3  1.0
    x_1_3       CONF_1_9_3  1.0
    x_1_4       ASSIGN_1  1.0
    x_1_4       CAP_4  14
    x_1_4       CONF_1_6_4  1.0
    x_1_4       CONF_1_8_4  1.0
    x_1_4       CONF_1_9_4  1.0
    x_1_5       ASSIGN_1  1.0
    x_1_5       CAP_5  14
    x_1_5       CONF_1_6_5  1.0
    x_1_5       CONF_1_8_5  1.0
    x_1_5       CONF_1_9_5  1.0
    x_1_6       ASSIGN_1  1.0
    x_1_6       CAP_6  14
    x_1_6       CONF_1_6_6  1.0
    x_1_6       CONF_1_8_6  1.0
    x_1_6       CONF_1_9_6  1.0
    x_1_7       ASSIGN_1  1.0
    x_1_7       CAP_7  14
    x_1_7       CONF_1_6_7  1.0
    x_1_7       CONF_1_8_7  1.0
    x_1_7       CONF_1_9_7  1.0
    x_1_8       ASSIGN_1  1.0
    x_1_8       CAP_8  14
    x_1_8       CONF_1_6_8  1.0
    x_1_8       CONF_1_8_8  1.0
    x_1_8       CONF_1_9_8  1.0
    x_1_9       ASSIGN_1  1.0
    x_1_9       CAP_9  14
    x_1_9       CONF_1_6_9  1.0
    x_1_9       CONF_1_8_9  1.0
    x_1_9       CONF_1_9_9  1.0
    x_1_10      ASSIGN_1  1.0
    x_1_10      CAP_10  14
    x_1_10      CONF_1_6_10  1.0
    x_1_10      CONF_1_8_10  1.0
    x_1_10      CONF_1_9_10  1.0
    x_1_11      ASSIGN_1  1.0
    x_1_11      CAP_11  14
    x_1_11      CONF_1_6_11  1.0
    x_1_11      CONF_1_8_11  1.0
    x_1_11      CONF_1_9_11  1.0
    x_1_12      ASSIGN_1  1.0
    x_1_12      CAP_12  14
    x_1_12      CONF_1_6_12  1.0
    x_1_12      CONF_1_8_12  1.0
    x_1_12      CONF_1_9_12  1.0
    x_1_13      ASSIGN_1  1.0
    x_1_13      CAP_13  14
    x_1_13      CONF_1_6_13  1.0
    x_1_13      CONF_1_8_13  1.0
    x_1_13      CONF_1_9_13  1.0
    x_1_14      ASSIGN_1  1.0
    x_1_14      CAP_14  14
    x_1_14      CONF_1_6_14  1.0
    x_1_14      CONF_1_8_14  1.0
    x_1_14      CONF_1_9_14  1.0
    x_1_15      ASSIGN_1  1.0
    x_1_15      CAP_15  14
    x_1_15      CONF_1_6_15  1.0
    x_1_15      CONF_1_8_15  1.0
    x_1_15      CONF_1_9_15  1.0
    x_2_0       ASSIGN_2  1.0
    x_2_0       CAP_0  22
    x_2_0       CONF_0_2_0  1.0
    x_2_0       CONF_2_6_0  1.0
    x_2_0       CONF_2_7_0  1.0
    x_2_0       CONF_2_9_0  1.0
    x_2_0       CONF_2_15_0  1.0
    x_2_1       ASSIGN_2  1.0
    x_2_1       CAP_1  22
    x_2_1       CONF_0_2_1  1.0
    x_2_1       CONF_2_6_1  1.0
    x_2_1       CONF_2_7_1  1.0
    x_2_1       CONF_2_9_1  1.0
    x_2_1       CONF_2_15_1  1.0
    x_2_2       ASSIGN_2  1.0
    x_2_2       CAP_2  22
    x_2_2       CONF_0_2_2  1.0
    x_2_2       CONF_2_6_2  1.0
    x_2_2       CONF_2_7_2  1.0
    x_2_2       CONF_2_9_2  1.0
    x_2_2       CONF_2_15_2  1.0
    x_2_3       ASSIGN_2  1.0
    x_2_3       CAP_3  22
    x_2_3       CONF_0_2_3  1.0
    x_2_3       CONF_2_6_3  1.0
    x_2_3       CONF_2_7_3  1.0
    x_2_3       CONF_2_9_3  1.0
    x_2_3       CONF_2_15_3  1.0
    x_2_4       ASSIGN_2  1.0
    x_2_4       CAP_4  22
    x_2_4       CONF_0_2_4  1.0
    x_2_4       CONF_2_6_4  1.0
    x_2_4       CONF_2_7_4  1.0
    x_2_4       CONF_2_9_4  1.0
    x_2_4       CONF_2_15_4  1.0
    x_2_5       ASSIGN_2  1.0
    x_2_5       CAP_5  22
    x_2_5       CONF_0_2_5  1.0
    x_2_5       CONF_2_6_5  1.0
    x_2_5       CONF_2_7_5  1.0
    x_2_5       CONF_2_9_5  1.0
    x_2_5       CONF_2_15_5  1.0
    x_2_6       ASSIGN_2  1.0
    x_2_6       CAP_6  22
    x_2_6       CONF_0_2_6  1.0
    x_2_6       CONF_2_6_6  1.0
    x_2_6       CONF_2_7_6  1.0
    x_2_6       CONF_2_9_6  1.0
    x_2_6       CONF_2_15_6  1.0
    x_2_7       ASSIGN_2  1.0
    x_2_7       CAP_7  22
    x_2_7       CONF_0_2_7  1.0
    x_2_7       CONF_2_6_7  1.0
    x_2_7       CONF_2_7_7  1.0
    x_2_7       CONF_2_9_7  1.0
    x_2_7       CONF_2_15_7  1.0
    x_2_8       ASSIGN_2  1.0
    x_2_8       CAP_8  22
    x_2_8       CONF_0_2_8  1.0
    x_2_8       CONF_2_6_8  1.0
    x_2_8       CONF_2_7_8  1.0
    x_2_8       CONF_2_9_8  1.0
    x_2_8       CONF_2_15_8  1.0
    x_2_9       ASSIGN_2  1.0
    x_2_9       CAP_9  22
    x_2_9       CONF_0_2_9  1.0
    x_2_9       CONF_2_6_9  1.0
    x_2_9       CONF_2_7_9  1.0
    x_2_9       CONF_2_9_9  1.0
    x_2_9       CONF_2_15_9  1.0
    x_2_10      ASSIGN_2  1.0
    x_2_10      CAP_10  22
    x_2_10      CONF_0_2_10  1.0
    x_2_10      CONF_2_6_10  1.0
    x_2_10      CONF_2_7_10  1.0
    x_2_10      CONF_2_9_10  1.0
    x_2_10      CONF_2_15_10  1.0
    x_2_11      ASSIGN_2  1.0
    x_2_11      CAP_11  22
    x_2_11      CONF_0_2_11  1.0
    x_2_11      CONF_2_6_11  1.0
    x_2_11      CONF_2_7_11  1.0
    x_2_11      CONF_2_9_11  1.0
    x_2_11      CONF_2_15_11  1.0
    x_2_12      ASSIGN_2  1.0
    x_2_12      CAP_12  22
    x_2_12      CONF_0_2_12  1.0
    x_2_12      CONF_2_6_12  1.0
    x_2_12      CONF_2_7_12  1.0
    x_2_12      CONF_2_9_12  1.0
    x_2_12      CONF_2_15_12  1.0
    x_2_13      ASSIGN_2  1.0
    x_2_13      CAP_13  22
    x_2_13      CONF_0_2_13  1.0
    x_2_13      CONF_2_6_13  1.0
    x_2_13      CONF_2_7_13  1.0
    x_2_13      CONF_2_9_13  1.0
    x_2_13      CONF_2_15_13  1.0
    x_2_14      ASSIGN_2  1.0
    x_2_14      CAP_14  22
    x_2_14      CONF_0_2_14  1.0
    x_2_14      CONF_2_6_14  1.0
    x_2_14      CONF_2_7_14  1.0
    x_2_14      CONF_2_9_14  1.0
    x_2_14      CONF_2_15_14  1.0
    x_2_15      ASSIGN_2  1.0
    x_2_15      CAP_15  22
    x_2_15      CONF_0_2_15  1.0
    x_2_15      CONF_2_6_15  1.0
    x_2_15      CONF_2_7_15  1.0
    x_2_15      CONF_2_9_15  1.0
    x_2_15      CONF_2_15_15  1.0
    x_3_0       ASSIGN_3  1.0
    x_3_0       CAP_0  30
    x_3_0       CONF_3_5_0  1.0
    x_3_0       CONF_3_10_0  1.0
    x_3_1       ASSIGN_3  1.0
    x_3_1       CAP_1  30
    x_3_1       CONF_3_5_1  1.0
    x_3_1       CONF_3_10_1  1.0
    x_3_2       ASSIGN_3  1.0
    x_3_2       CAP_2  30
    x_3_2       CONF_3_5_2  1.0
    x_3_2       CONF_3_10_2  1.0
    x_3_3       ASSIGN_3  1.0
    x_3_3       CAP_3  30
    x_3_3       CONF_3_5_3  1.0
    x_3_3       CONF_3_10_3  1.0
    x_3_4       ASSIGN_3  1.0
    x_3_4       CAP_4  30
    x_3_4       CONF_3_5_4  1.0
    x_3_4       CONF_3_10_4  1.0
    x_3_5       ASSIGN_3  1.0
    x_3_5       CAP_5  30
    x_3_5       CONF_3_5_5  1.0
    x_3_5       CONF_3_10_5  1.0
    x_3_6       ASSIGN_3  1.0
    x_3_6       CAP_6  30
    x_3_6       CONF_3_5_6  1.0
    x_3_6       CONF_3_10_6  1.0
    x_3_7       ASSIGN_3  1.0
    x_3_7       CAP_7  30
    x_3_7       CONF_3_5_7  1.0
    x_3_7       CONF_3_10_7  1.0
    x_3_8       ASSIGN_3  1.0
    x_3_8       CAP_8  30
    x_3_8       CONF_3_5_8  1.0
    x_3_8       CONF_3_10_8  1.0
    x_3_9       ASSIGN_3  1.0
    x_3_9       CAP_9  30
    x_3_9       CONF_3_5_9  1.0
    x_3_9       CONF_3_10_9  1.0
    x_3_10      ASSIGN_3  1.0
    x_3_10      CAP_10  30
    x_3_10      CONF_3_5_10  1.0
    x_3_10      CONF_3_10_10  1.0
    x_3_11      ASSIGN_3  1.0
    x_3_11      CAP_11  30
    x_3_11      CONF_3_5_11  1.0
    x_3_11      CONF_3_10_11  1.0
    x_3_12      ASSIGN_3  1.0
    x_3_12      CAP_12  30
    x_3_12      CONF_3_5_12  1.0
    x_3_12      CONF_3_10_12  1.0
    x_3_13      ASSIGN_3  1.0
    x_3_13      CAP_13  30
    x_3_13      CONF_3_5_13  1.0
    x_3_13      CONF_3_10_13  1.0
    x_3_14      ASSIGN_3  1.0
    x_3_14      CAP_14  30
    x_3_14      CONF_3_5_14  1.0
    x_3_14      CONF_3_10_14  1.0
    x_3_15      ASSIGN_3  1.0
    x_3_15      CAP_15  30
    x_3_15      CONF_3_5_15  1.0
    x_3_15      CONF_3_10_15  1.0
    x_4_0       ASSIGN_4  1.0
    x_4_0       CAP_0  11
    x_4_0       CONF_0_4_0  1.0
    x_4_0       CONF_4_7_0  1.0
    x_4_0       CONF_4_8_0  1.0
    x_4_0       CONF_4_11_0  1.0
    x_4_1       ASSIGN_4  1.0
    x_4_1       CAP_1  11
    x_4_1       CONF_0_4_1  1.0
    x_4_1       CONF_4_7_1  1.0
    x_4_1       CONF_4_8_1  1.0
    x_4_1       CONF_4_11_1  1.0
    x_4_2       ASSIGN_4  1.0
    x_4_2       CAP_2  11
    x_4_2       CONF_0_4_2  1.0
    x_4_2       CONF_4_7_2  1.0
    x_4_2       CONF_4_8_2  1.0
    x_4_2       CONF_4_11_2  1.0
    x_4_3       ASSIGN_4  1.0
    x_4_3       CAP_3  11
    x_4_3       CONF_0_4_3  1.0
    x_4_3       CONF_4_7_3  1.0
    x_4_3       CONF_4_8_3  1.0
    x_4_3       CONF_4_11_3  1.0
    x_4_4       ASSIGN_4  1.0
    x_4_4       CAP_4  11
    x_4_4       CONF_0_4_4  1.0
    x_4_4       CONF_4_7_4  1.0
    x_4_4       CONF_4_8_4  1.0
    x_4_4       CONF_4_11_4  1.0
    x_4_5       ASSIGN_4  1.0
    x_4_5       CAP_5  11
    x_4_5       CONF_0_4_5  1.0
    x_4_5       CONF_4_7_5  1.0
    x_4_5       CONF_4_8_5  1.0
    x_4_5       CONF_4_11_5  1.0
    x_4_6       ASSIGN_4  1.0
    x_4_6       CAP_6  11
    x_4_6       CONF_0_4_6  1.0
    x_4_6       CONF_4_7_6  1.0
    x_4_6       CONF_4_8_6  1.0
    x_4_6       CONF_4_11_6  1.0
    x_4_7       ASSIGN_4  1.0
    x_4_7       CAP_7  11
    x_4_7       CONF_0_4_7  1.0
    x_4_7       CONF_4_7_7  1.0
    x_4_7       CONF_4_8_7  1.0
    x_4_7       CONF_4_11_7  1.0
    x_4_8       ASSIGN_4  1.0
    x_4_8       CAP_8  11
    x_4_8       CONF_0_4_8  1.0
    x_4_8       CONF_4_7_8  1.0
    x_4_8       CONF_4_8_8  1.0
    x_4_8       CONF_4_11_8  1.0
    x_4_9       ASSIGN_4  1.0
    x_4_9       CAP_9  11
    x_4_9       CONF_0_4_9  1.0
    x_4_9       CONF_4_7_9  1.0
    x_4_9       CONF_4_8_9  1.0
    x_4_9       CONF_4_11_9  1.0
    x_4_10      ASSIGN_4  1.0
    x_4_10      CAP_10  11
    x_4_10      CONF_0_4_10  1.0
    x_4_10      CONF_4_7_10  1.0
    x_4_10      CONF_4_8_10  1.0
    x_4_10      CONF_4_11_10  1.0
    x_4_11      ASSIGN_4  1.0
    x_4_11      CAP_11  11
    x_4_11      CONF_0_4_11  1.0
    x_4_11      CONF_4_7_11  1.0
    x_4_11      CONF_4_8_11  1.0
    x_4_11      CONF_4_11_11  1.0
    x_4_12      ASSIGN_4  1.0
    x_4_12      CAP_12  11
    x_4_12      CONF_0_4_12  1.0
    x_4_12      CONF_4_7_12  1.0
    x_4_12      CONF_4_8_12  1.0
    x_4_12      CONF_4_11_12  1.0
    x_4_13      ASSIGN_4  1.0
    x_4_13      CAP_13  11
    x_4_13      CONF_0_4_13  1.0
    x_4_13      CONF_4_7_13  1.0
    x_4_13      CONF_4_8_13  1.0
    x_4_13      CONF_4_11_13  1.0
    x_4_14      ASSIGN_4  1.0
    x_4_14      CAP_14  11
    x_4_14      CONF_0_4_14  1.0
    x_4_14      CONF_4_7_14  1.0
    x_4_14      CONF_4_8_14  1.0
    x_4_14      CONF_4_11_14  1.0
    x_4_15      ASSIGN_4  1.0
    x_4_15      CAP_15  11
    x_4_15      CONF_0_4_15  1.0
    x_4_15      CONF_4_7_15  1.0
    x_4_15      CONF_4_8_15  1.0
    x_4_15      CONF_4_11_15  1.0
    x_5_0       ASSIGN_5  1.0
    x_5_0       CAP_0  12
    x_5_0       CONF_3_5_0  1.0
    x_5_0       CONF_5_14_0  1.0
    x_5_1       ASSIGN_5  1.0
    x_5_1       CAP_1  12
    x_5_1       CONF_3_5_1  1.0
    x_5_1       CONF_5_14_1  1.0
    x_5_2       ASSIGN_5  1.0
    x_5_2       CAP_2  12
    x_5_2       CONF_3_5_2  1.0
    x_5_2       CONF_5_14_2  1.0
    x_5_3       ASSIGN_5  1.0
    x_5_3       CAP_3  12
    x_5_3       CONF_3_5_3  1.0
    x_5_3       CONF_5_14_3  1.0
    x_5_4       ASSIGN_5  1.0
    x_5_4       CAP_4  12
    x_5_4       CONF_3_5_4  1.0
    x_5_4       CONF_5_14_4  1.0
    x_5_5       ASSIGN_5  1.0
    x_5_5       CAP_5  12
    x_5_5       CONF_3_5_5  1.0
    x_5_5       CONF_5_14_5  1.0
    x_5_6       ASSIGN_5  1.0
    x_5_6       CAP_6  12
    x_5_6       CONF_3_5_6  1.0
    x_5_6       CONF_5_14_6  1.0
    x_5_7       ASSIGN_5  1.0
    x_5_7       CAP_7  12
    x_5_7       CONF_3_5_7  1.0
    x_5_7       CONF_5_14_7  1.0
    x_5_8       ASSIGN_5  1.0
    x_5_8       CAP_8  12
    x_5_8       CONF_3_5_8  1.0
    x_5_8       CONF_5_14_8  1.0
    x_5_9       ASSIGN_5  1.0
    x_5_9       CAP_9  12
    x_5_9       CONF_3_5_9  1.0
    x_5_9       CONF_5_14_9  1.0
    x_5_10      ASSIGN_5  1.0
    x_5_10      CAP_10  12
    x_5_10      CONF_3_5_10  1.0
    x_5_10      CONF_5_14_10  1.0
    x_5_11      ASSIGN_5  1.0
    x_5_11      CAP_11  12
    x_5_11      CONF_3_5_11  1.0
    x_5_11      CONF_5_14_11  1.0
    x_5_12      ASSIGN_5  1.0
    x_5_12      CAP_12  12
    x_5_12      CONF_3_5_12  1.0
    x_5_12      CONF_5_14_12  1.0
    x_5_13      ASSIGN_5  1.0
    x_5_13      CAP_13  12
    x_5_13      CONF_3_5_13  1.0
    x_5_13      CONF_5_14_13  1.0
    x_5_14      ASSIGN_5  1.0
    x_5_14      CAP_14  12
    x_5_14      CONF_3_5_14  1.0
    x_5_14      CONF_5_14_14  1.0
    x_5_15      ASSIGN_5  1.0
    x_5_15      CAP_15  12
    x_5_15      CONF_3_5_15  1.0
    x_5_15      CONF_5_14_15  1.0
    x_6_0       ASSIGN_6  1.0
    x_6_0       CAP_0  27
    x_6_0       CONF_1_6_0  1.0
    x_6_0       CONF_2_6_0  1.0
    x_6_0       CONF_6_11_0  1.0
    x_6_0       CONF_6_14_0  1.0
    x_6_1       ASSIGN_6  1.0
    x_6_1       CAP_1  27
    x_6_1       CONF_1_6_1  1.0
    x_6_1       CONF_2_6_1  1.0
    x_6_1       CONF_6_11_1  1.0
    x_6_1       CONF_6_14_1  1.0
    x_6_2       ASSIGN_6  1.0
    x_6_2       CAP_2  27
    x_6_2       CONF_1_6_2  1.0
    x_6_2       CONF_2_6_2  1.0
    x_6_2       CONF_6_11_2  1.0
    x_6_2       CONF_6_14_2  1.0
    x_6_3       ASSIGN_6  1.0
    x_6_3       CAP_3  27
    x_6_3       CONF_1_6_3  1.0
    x_6_3       CONF_2_6_3  1.0
    x_6_3       CONF_6_11_3  1.0
    x_6_3       CONF_6_14_3  1.0
    x_6_4       ASSIGN_6  1.0
    x_6_4       CAP_4  27
    x_6_4       CONF_1_6_4  1.0
    x_6_4       CONF_2_6_4  1.0
    x_6_4       CONF_6_11_4  1.0
    x_6_4       CONF_6_14_4  1.0
    x_6_5       ASSIGN_6  1.0
    x_6_5       CAP_5  27
    x_6_5       CONF_1_6_5  1.0
    x_6_5       CONF_2_6_5  1.0
    x_6_5       CONF_6_11_5  1.0
    x_6_5       CONF_6_14_5  1.0
    x_6_6       ASSIGN_6  1.0
    x_6_6       CAP_6  27
    x_6_6       CONF_1_6_6  1.0
    x_6_6       CONF_2_6_6  1.0
    x_6_6       CONF_6_11_6  1.0
    x_6_6       CONF_6_14_6  1.0
    x_6_7       ASSIGN_6  1.0
    x_6_7       CAP_7  27
    x_6_7       CONF_1_6_7  1.0
    x_6_7       CONF_2_6_7  1.0
    x_6_7       CONF_6_11_7  1.0
    x_6_7       CONF_6_14_7  1.0
    x_6_8       ASSIGN_6  1.0
    x_6_8       CAP_8  27
    x_6_8       CONF_1_6_8  1.0
    x_6_8       CONF_2_6_8  1.0
    x_6_8       CONF_6_11_8  1.0
    x_6_8       CONF_6_14_8  1.0
    x_6_9       ASSIGN_6  1.0
    x_6_9       CAP_9  27
    x_6_9       CONF_1_6_9  1.0
    x_6_9       CONF_2_6_9  1.0
    x_6_9       CONF_6_11_9  1.0
    x_6_9       CONF_6_14_9  1.0
    x_6_10      ASSIGN_6  1.0
    x_6_10      CAP_10  27
    x_6_10      CONF_1_6_10  1.0
    x_6_10      CONF_2_6_10  1.0
    x_6_10      CONF_6_11_10  1.0
    x_6_10      CONF_6_14_10  1.0
    x_6_11      ASSIGN_6  1.0
    x_6_11      CAP_11  27
    x_6_11      CONF_1_6_11  1.0
    x_6_11      CONF_2_6_11  1.0
    x_6_11      CONF_6_11_11  1.0
    x_6_11      CONF_6_14_11  1.0
    x_6_12      ASSIGN_6  1.0
    x_6_12      CAP_12  27
    x_6_12      CONF_1_6_12  1.0
    x_6_12      CONF_2_6_12  1.0
    x_6_12      CONF_6_11_12  1.0
    x_6_12      CONF_6_14_12  1.0
    x_6_13      ASSIGN_6  1.0
    x_6_13      CAP_13  27
    x_6_13      CONF_1_6_13  1.0
    x_6_13      CONF_2_6_13  1.0
    x_6_13      CONF_6_11_13  1.0
    x_6_13      CONF_6_14_13  1.0
    x_6_14      ASSIGN_6  1.0
    x_6_14      CAP_14  27
    x_6_14      CONF_1_6_14  1.0
    x_6_14      CONF_2_6_14  1.0
    x_6_14      CONF_6_11_14  1.0
    x_6_14      CONF_6_14_14  1.0
    x_6_15      ASSIGN_6  1.0
    x_6_15      CAP_15  27
    x_6_15      CONF_1_6_15  1.0
    x_6_15      CONF_2_6_15  1.0
    x_6_15      CONF_6_11_15  1.0
    x_6_15      CONF_6_14_15  1.0
    x_7_0       ASSIGN_7  1.0
    x_7_0       CAP_0  13
    x_7_0       CONF_2_7_0  1.0
    x_7_0       CONF_4_7_0  1.0
    x_7_0       CONF_7_13_0  1.0
    x_7_0       CONF_7_14_0  1.0
    x_7_0       CONF_7_15_0  1.0
    x_7_1       ASSIGN_7  1.0
    x_7_1       CAP_1  13
    x_7_1       CONF_2_7_1  1.0
    x_7_1       CONF_4_7_1  1.0
    x_7_1       CONF_7_13_1  1.0
    x_7_1       CONF_7_14_1  1.0
    x_7_1       CONF_7_15_1  1.0
    x_7_2       ASSIGN_7  1.0
    x_7_2       CAP_2  13
    x_7_2       CONF_2_7_2  1.0
    x_7_2       CONF_4_7_2  1.0
    x_7_2       CONF_7_13_2  1.0
    x_7_2       CONF_7_14_2  1.0
    x_7_2       CONF_7_15_2  1.0
    x_7_3       ASSIGN_7  1.0
    x_7_3       CAP_3  13
    x_7_3       CONF_2_7_3  1.0
    x_7_3       CONF_4_7_3  1.0
    x_7_3       CONF_7_13_3  1.0
    x_7_3       CONF_7_14_3  1.0
    x_7_3       CONF_7_15_3  1.0
    x_7_4       ASSIGN_7  1.0
    x_7_4       CAP_4  13
    x_7_4       CONF_2_7_4  1.0
    x_7_4       CONF_4_7_4  1.0
    x_7_4       CONF_7_13_4  1.0
    x_7_4       CONF_7_14_4  1.0
    x_7_4       CONF_7_15_4  1.0
    x_7_5       ASSIGN_7  1.0
    x_7_5       CAP_5  13
    x_7_5       CONF_2_7_5  1.0
    x_7_5       CONF_4_7_5  1.0
    x_7_5       CONF_7_13_5  1.0
    x_7_5       CONF_7_14_5  1.0
    x_7_5       CONF_7_15_5  1.0
    x_7_6       ASSIGN_7  1.0
    x_7_6       CAP_6  13
    x_7_6       CONF_2_7_6  1.0
    x_7_6       CONF_4_7_6  1.0
    x_7_6       CONF_7_13_6  1.0
    x_7_6       CONF_7_14_6  1.0
    x_7_6       CONF_7_15_6  1.0
    x_7_7       ASSIGN_7  1.0
    x_7_7       CAP_7  13
    x_7_7       CONF_2_7_7  1.0
    x_7_7       CONF_4_7_7  1.0
    x_7_7       CONF_7_13_7  1.0
    x_7_7       CONF_7_14_7  1.0
    x_7_7       CONF_7_15_7  1.0
    x_7_8       ASSIGN_7  1.0
    x_7_8       CAP_8  13
    x_7_8       CONF_2_7_8  1.0
    x_7_8       CONF_4_7_8  1.0
    x_7_8       CONF_7_13_8  1.0
    x_7_8       CONF_7_14_8  1.0
    x_7_8       CONF_7_15_8  1.0
    x_7_9       ASSIGN_7  1.0
    x_7_9       CAP_9  13
    x_7_9       CONF_2_7_9  1.0
    x_7_9       CONF_4_7_9  1.0
    x_7_9       CONF_7_13_9  1.0
    x_7_9       CONF_7_14_9  1.0
    x_7_9       CONF_7_15_9  1.0
    x_7_10      ASSIGN_7  1.0
    x_7_10      CAP_10  13
    x_7_10      CONF_2_7_10  1.0
    x_7_10      CONF_4_7_10  1.0
    x_7_10      CONF_7_13_10  1.0
    x_7_10      CONF_7_14_10  1.0
    x_7_10      CONF_7_15_10  1.0
    x_7_11      ASSIGN_7  1.0
    x_7_11      CAP_11  13
    x_7_11      CONF_2_7_11  1.0
    x_7_11      CONF_4_7_11  1.0
    x_7_11      CONF_7_13_11  1.0
    x_7_11      CONF_7_14_11  1.0
    x_7_11      CONF_7_15_11  1.0
    x_7_12      ASSIGN_7  1.0
    x_7_12      CAP_12  13
    x_7_12      CONF_2_7_12  1.0
    x_7_12      CONF_4_7_12  1.0
    x_7_12      CONF_7_13_12  1.0
    x_7_12      CONF_7_14_12  1.0
    x_7_12      CONF_7_15_12  1.0
    x_7_13      ASSIGN_7  1.0
    x_7_13      CAP_13  13
    x_7_13      CONF_2_7_13  1.0
    x_7_13      CONF_4_7_13  1.0
    x_7_13      CONF_7_13_13  1.0
    x_7_13      CONF_7_14_13  1.0
    x_7_13      CONF_7_15_13  1.0
    x_7_14      ASSIGN_7  1.0
    x_7_14      CAP_14  13
    x_7_14      CONF_2_7_14  1.0
    x_7_14      CONF_4_7_14  1.0
    x_7_14      CONF_7_13_14  1.0
    x_7_14      CONF_7_14_14  1.0
    x_7_14      CONF_7_15_14  1.0
    x_7_15      ASSIGN_7  1.0
    x_7_15      CAP_15  13
    x_7_15      CONF_2_7_15  1.0
    x_7_15      CONF_4_7_15  1.0
    x_7_15      CONF_7_13_15  1.0
    x_7_15      CONF_7_14_15  1.0
    x_7_15      CONF_7_15_15  1.0
    x_8_0       ASSIGN_8  1.0
    x_8_0       CAP_0  21
    x_8_0       CONF_1_8_0  1.0
    x_8_0       CONF_4_8_0  1.0
    x_8_0       CONF_8_10_0  1.0
    x_8_0       CONF_8_12_0  1.0
    x_8_0       CONF_8_14_0  1.0
    x_8_1       ASSIGN_8  1.0
    x_8_1       CAP_1  21
    x_8_1       CONF_1_8_1  1.0
    x_8_1       CONF_4_8_1  1.0
    x_8_1       CONF_8_10_1  1.0
    x_8_1       CONF_8_12_1  1.0
    x_8_1       CONF_8_14_1  1.0
    x_8_2       ASSIGN_8  1.0
    x_8_2       CAP_2  21
    x_8_2       CONF_1_8_2  1.0
    x_8_2       CONF_4_8_2  1.0
    x_8_2       CONF_8_10_2  1.0
    x_8_2       CONF_8_12_2  1.0
    x_8_2       CONF_8_14_2  1.0
    x_8_3       ASSIGN_8  1.0
    x_8_3       CAP_3  21
    x_8_3       CONF_1_8_3  1.0
    x_8_3       CONF_4_8_3  1.0
    x_8_3       CONF_8_10_3  1.0
    x_8_3       CONF_8_12_3  1.0
    x_8_3       CONF_8_14_3  1.0
    x_8_4       ASSIGN_8  1.0
    x_8_4       CAP_4  21
    x_8_4       CONF_1_8_4  1.0
    x_8_4       CONF_4_8_4  1.0
    x_8_4       CONF_8_10_4  1.0
    x_8_4       CONF_8_12_4  1.0
    x_8_4       CONF_8_14_4  1.0
    x_8_5       ASSIGN_8  1.0
    x_8_5       CAP_5  21
    x_8_5       CONF_1_8_5  1.0
    x_8_5       CONF_4_8_5  1.0
    x_8_5       CONF_8_10_5  1.0
    x_8_5       CONF_8_12_5  1.0
    x_8_5       CONF_8_14_5  1.0
    x_8_6       ASSIGN_8  1.0
    x_8_6       CAP_6  21
    x_8_6       CONF_1_8_6  1.0
    x_8_6       CONF_4_8_6  1.0
    x_8_6       CONF_8_10_6  1.0
    x_8_6       CONF_8_12_6  1.0
    x_8_6       CONF_8_14_6  1.0
    x_8_7       ASSIGN_8  1.0
    x_8_7       CAP_7  21
    x_8_7       CONF_1_8_7  1.0
    x_8_7       CONF_4_8_7  1.0
    x_8_7       CONF_8_10_7  1.0
    x_8_7       CONF_8_12_7  1.0
    x_8_7       CONF_8_14_7  1.0
    x_8_8       ASSIGN_8  1.0
    x_8_8       CAP_8  21
    x_8_8       CONF_1_8_8  1.0
    x_8_8       CONF_4_8_8  1.0
    x_8_8       CONF_8_10_8  1.0
    x_8_8       CONF_8_12_8  1.0
    x_8_8       CONF_8_14_8  1.0
    x_8_9       ASSIGN_8  1.0
    x_8_9       CAP_9  21
    x_8_9       CONF_1_8_9  1.0
    x_8_9       CONF_4_8_9  1.0
    x_8_9       CONF_8_10_9  1.0
    x_8_9       CONF_8_12_9  1.0
    x_8_9       CONF_8_14_9  1.0
    x_8_10      ASSIGN_8  1.0
    x_8_10      CAP_10  21
    x_8_10      CONF_1_8_10  1.0
    x_8_10      CONF_4_8_10  1.0
    x_8_10      CONF_8_10_10  1.0
    x_8_10      CONF_8_12_10  1.0
    x_8_10      CONF_8_14_10  1.0
    x_8_11      ASSIGN_8  1.0
    x_8_11      CAP_11  21
    x_8_11      CONF_1_8_11  1.0
    x_8_11      CONF_4_8_11  1.0
    x_8_11      CONF_8_10_11  1.0
    x_8_11      CONF_8_12_11  1.0
    x_8_11      CONF_8_14_11  1.0
    x_8_12      ASSIGN_8  1.0
    x_8_12      CAP_12  21
    x_8_12      CONF_1_8_12  1.0
    x_8_12      CONF_4_8_12  1.0
    x_8_12      CONF_8_10_12  1.0
    x_8_12      CONF_8_12_12  1.0
    x_8_12      CONF_8_14_12  1.0
    x_8_13      ASSIGN_8  1.0
    x_8_13      CAP_13  21
    x_8_13      CONF_1_8_13  1.0
    x_8_13      CONF_4_8_13  1.0
    x_8_13      CONF_8_10_13  1.0
    x_8_13      CONF_8_12_13  1.0
    x_8_13      CONF_8_14_13  1.0
    x_8_14      ASSIGN_8  1.0
    x_8_14      CAP_14  21
    x_8_14      CONF_1_8_14  1.0
    x_8_14      CONF_4_8_14  1.0
    x_8_14      CONF_8_10_14  1.0
    x_8_14      CONF_8_12_14  1.0
    x_8_14      CONF_8_14_14  1.0
    x_8_15      ASSIGN_8  1.0
    x_8_15      CAP_15  21
    x_8_15      CONF_1_8_15  1.0
    x_8_15      CONF_4_8_15  1.0
    x_8_15      CONF_8_10_15  1.0
    x_8_15      CONF_8_12_15  1.0
    x_8_15      CONF_8_14_15  1.0
    x_9_0       ASSIGN_9  1.0
    x_9_0       CAP_0  28
    x_9_0       CONF_0_9_0  1.0
    x_9_0       CONF_1_9_0  1.0
    x_9_0       CONF_2_9_0  1.0
    x_9_0       CONF_9_12_0  1.0
    x_9_1       ASSIGN_9  1.0
    x_9_1       CAP_1  28
    x_9_1       CONF_0_9_1  1.0
    x_9_1       CONF_1_9_1  1.0
    x_9_1       CONF_2_9_1  1.0
    x_9_1       CONF_9_12_1  1.0
    x_9_2       ASSIGN_9  1.0
    x_9_2       CAP_2  28
    x_9_2       CONF_0_9_2  1.0
    x_9_2       CONF_1_9_2  1.0
    x_9_2       CONF_2_9_2  1.0
    x_9_2       CONF_9_12_2  1.0
    x_9_3       ASSIGN_9  1.0
    x_9_3       CAP_3  28
    x_9_3       CONF_0_9_3  1.0
    x_9_3       CONF_1_9_3  1.0
    x_9_3       CONF_2_9_3  1.0
    x_9_3       CONF_9_12_3  1.0
    x_9_4       ASSIGN_9  1.0
    x_9_4       CAP_4  28
    x_9_4       CONF_0_9_4  1.0
    x_9_4       CONF_1_9_4  1.0
    x_9_4       CONF_2_9_4  1.0
    x_9_4       CONF_9_12_4  1.0
    x_9_5       ASSIGN_9  1.0
    x_9_5       CAP_5  28
    x_9_5       CONF_0_9_5  1.0
    x_9_5       CONF_1_9_5  1.0
    x_9_5       CONF_2_9_5  1.0
    x_9_5       CONF_9_12_5  1.0
    x_9_6       ASSIGN_9  1.0
    x_9_6       CAP_6  28
    x_9_6       CONF_0_9_6  1.0
    x_9_6       CONF_1_9_6  1.0
    x_9_6       CONF_2_9_6  1.0
    x_9_6       CONF_9_12_6  1.0
    x_9_7       ASSIGN_9  1.0
    x_9_7       CAP_7  28
    x_9_7       CONF_0_9_7  1.0
    x_9_7       CONF_1_9_7  1.0
    x_9_7       CONF_2_9_7  1.0
    x_9_7       CONF_9_12_7  1.0
    x_9_8       ASSIGN_9  1.0
    x_9_8       CAP_8  28
    x_9_8       CONF_0_9_8  1.0
    x_9_8       CONF_1_9_8  1.0
    x_9_8       CONF_2_9_8  1.0
    x_9_8       CONF_9_12_8  1.0
    x_9_9       ASSIGN_9  1.0
    x_9_9       CAP_9  28
    x_9_9       CONF_0_9_9  1.0
    x_9_9       CONF_1_9_9  1.0
    x_9_9       CONF_2_9_9  1.0
    x_9_9       CONF_9_12_9  1.0
    x_9_10      ASSIGN_9  1.0
    x_9_10      CAP_10  28
    x_9_10      CONF_0_9_10  1.0
    x_9_10      CONF_1_9_10  1.0
    x_9_10      CONF_2_9_10  1.0
    x_9_10      CONF_9_12_10  1.0
    x_9_11      ASSIGN_9  1.0
    x_9_11      CAP_11  28
    x_9_11      CONF_0_9_11  1.0
    x_9_11      CONF_1_9_11  1.0
    x_9_11      CONF_2_9_11  1.0
    x_9_11      CONF_9_12_11  1.0
    x_9_12      ASSIGN_9  1.0
    x_9_12      CAP_12  28
    x_9_12      CONF_0_9_12  1.0
    x_9_12      CONF_1_9_12  1.0
    x_9_12      CONF_2_9_12  1.0
    x_9_12      CONF_9_12_12  1.0
    x_9_13      ASSIGN_9  1.0
    x_9_13      CAP_13  28
    x_9_13      CONF_0_9_13  1.0
    x_9_13      CONF_1_9_13  1.0
    x_9_13      CONF_2_9_13  1.0
    x_9_13      CONF_9_12_13  1.0
    x_9_14      ASSIGN_9  1.0
    x_9_14      CAP_14  28
    x_9_14      CONF_0_9_14  1.0
    x_9_14      CONF_1_9_14  1.0
    x_9_14      CONF_2_9_14  1.0
    x_9_14      CONF_9_12_14  1.0
    x_9_15      ASSIGN_9  1.0
    x_9_15      CAP_15  28
    x_9_15      CONF_0_9_15  1.0
    x_9_15      CONF_1_9_15  1.0
    x_9_15      CONF_2_9_15  1.0
    x_9_15      CONF_9_12_15  1.0
    x_10_0      ASSIGN_10  1.0
    x_10_0      CAP_0  11
    x_10_0      CONF_3_10_0  1.0
    x_10_0      CONF_8_10_0  1.0
    x_10_1      ASSIGN_10  1.0
    x_10_1      CAP_1  11
    x_10_1      CONF_3_10_1  1.0
    x_10_1      CONF_8_10_1  1.0
    x_10_2      ASSIGN_10  1.0
    x_10_2      CAP_2  11
    x_10_2      CONF_3_10_2  1.0
    x_10_2      CONF_8_10_2  1.0
    x_10_3      ASSIGN_10  1.0
    x_10_3      CAP_3  11
    x_10_3      CONF_3_10_3  1.0
    x_10_3      CONF_8_10_3  1.0
    x_10_4      ASSIGN_10  1.0
    x_10_4      CAP_4  11
    x_10_4      CONF_3_10_4  1.0
    x_10_4      CONF_8_10_4  1.0
    x_10_5      ASSIGN_10  1.0
    x_10_5      CAP_5  11
    x_10_5      CONF_3_10_5  1.0
    x_10_5      CONF_8_10_5  1.0
    x_10_6      ASSIGN_10  1.0
    x_10_6      CAP_6  11
    x_10_6      CONF_3_10_6  1.0
    x_10_6      CONF_8_10_6  1.0
    x_10_7      ASSIGN_10  1.0
    x_10_7      CAP_7  11
    x_10_7      CONF_3_10_7  1.0
    x_10_7      CONF_8_10_7  1.0
    x_10_8      ASSIGN_10  1.0
    x_10_8      CAP_8  11
    x_10_8      CONF_3_10_8  1.0
    x_10_8      CONF_8_10_8  1.0
    x_10_9      ASSIGN_10  1.0
    x_10_9      CAP_9  11
    x_10_9      CONF_3_10_9  1.0
    x_10_9      CONF_8_10_9  1.0
    x_10_10     ASSIGN_10  1.0
    x_10_10     CAP_10  11
    x_10_10     CONF_3_10_10  1.0
    x_10_10     CONF_8_10_10  1.0
    x_10_11     ASSIGN_10  1.0
    x_10_11     CAP_11  11
    x_10_11     CONF_3_10_11  1.0
    x_10_11     CONF_8_10_11  1.0
    x_10_12     ASSIGN_10  1.0
    x_10_12     CAP_12  11
    x_10_12     CONF_3_10_12  1.0
    x_10_12     CONF_8_10_12  1.0
    x_10_13     ASSIGN_10  1.0
    x_10_13     CAP_13  11
    x_10_13     CONF_3_10_13  1.0
    x_10_13     CONF_8_10_13  1.0
    x_10_14     ASSIGN_10  1.0
    x_10_14     CAP_14  11
    x_10_14     CONF_3_10_14  1.0
    x_10_14     CONF_8_10_14  1.0
    x_10_15     ASSIGN_10  1.0
    x_10_15     CAP_15  11
    x_10_15     CONF_3_10_15  1.0
    x_10_15     CONF_8_10_15  1.0
    x_11_0      ASSIGN_11  1.0
    x_11_0      CAP_0  26
    x_11_0      CONF_0_11_0  1.0
    x_11_0      CONF_4_11_0  1.0
    x_11_0      CONF_6_11_0  1.0
    x_11_1      ASSIGN_11  1.0
    x_11_1      CAP_1  26
    x_11_1      CONF_0_11_1  1.0
    x_11_1      CONF_4_11_1  1.0
    x_11_1      CONF_6_11_1  1.0
    x_11_2      ASSIGN_11  1.0
    x_11_2      CAP_2  26
    x_11_2      CONF_0_11_2  1.0
    x_11_2      CONF_4_11_2  1.0
    x_11_2      CONF_6_11_2  1.0
    x_11_3      ASSIGN_11  1.0
    x_11_3      CAP_3  26
    x_11_3      CONF_0_11_3  1.0
    x_11_3      CONF_4_11_3  1.0
    x_11_3      CONF_6_11_3  1.0
    x_11_4      ASSIGN_11  1.0
    x_11_4      CAP_4  26
    x_11_4      CONF_0_11_4  1.0
    x_11_4      CONF_4_11_4  1.0
    x_11_4      CONF_6_11_4  1.0
    x_11_5      ASSIGN_11  1.0
    x_11_5      CAP_5  26
    x_11_5      CONF_0_11_5  1.0
    x_11_5      CONF_4_11_5  1.0
    x_11_5      CONF_6_11_5  1.0
    x_11_6      ASSIGN_11  1.0
    x_11_6      CAP_6  26
    x_11_6      CONF_0_11_6  1.0
    x_11_6      CONF_4_11_6  1.0
    x_11_6      CONF_6_11_6  1.0
    x_11_7      ASSIGN_11  1.0
    x_11_7      CAP_7  26
    x_11_7      CONF_0_11_7  1.0
    x_11_7      CONF_4_11_7  1.0
    x_11_7      CONF_6_11_7  1.0
    x_11_8      ASSIGN_11  1.0
    x_11_8      CAP_8  26
    x_11_8      CONF_0_11_8  1.0
    x_11_8      CONF_4_11_8  1.0
    x_11_8      CONF_6_11_8  1.0
    x_11_9      ASSIGN_11  1.0
    x_11_9      CAP_9  26
    x_11_9      CONF_0_11_9  1.0
    x_11_9      CONF_4_11_9  1.0
    x_11_9      CONF_6_11_9  1.0
    x_11_10     ASSIGN_11  1.0
    x_11_10     CAP_10  26
    x_11_10     CONF_0_11_10  1.0
    x_11_10     CONF_4_11_10  1.0
    x_11_10     CONF_6_11_10  1.0
    x_11_11     ASSIGN_11  1.0
    x_11_11     CAP_11  26
    x_11_11     CONF_0_11_11  1.0
    x_11_11     CONF_4_11_11  1.0
    x_11_11     CONF_6_11_11  1.0
    x_11_12     ASSIGN_11  1.0
    x_11_12     CAP_12  26
    x_11_12     CONF_0_11_12  1.0
    x_11_12     CONF_4_11_12  1.0
    x_11_12     CONF_6_11_12  1.0
    x_11_13     ASSIGN_11  1.0
    x_11_13     CAP_13  26
    x_11_13     CONF_0_11_13  1.0
    x_11_13     CONF_4_11_13  1.0
    x_11_13     CONF_6_11_13  1.0
    x_11_14     ASSIGN_11  1.0
    x_11_14     CAP_14  26
    x_11_14     CONF_0_11_14  1.0
    x_11_14     CONF_4_11_14  1.0
    x_11_14     CONF_6_11_14  1.0
    x_11_15     ASSIGN_11  1.0
    x_11_15     CAP_15  26
    x_11_15     CONF_0_11_15  1.0
    x_11_15     CONF_4_11_15  1.0
    x_11_15     CONF_6_11_15  1.0
    x_12_0      ASSIGN_12  1.0
    x_12_0      CAP_0  16
    x_12_0      CONF_0_12_0  1.0
    x_12_0      CONF_8_12_0  1.0
    x_12_0      CONF_9_12_0  1.0
    x_12_0      CONF_12_14_0  1.0
    x_12_1      ASSIGN_12  1.0
    x_12_1      CAP_1  16
    x_12_1      CONF_0_12_1  1.0
    x_12_1      CONF_8_12_1  1.0
    x_12_1      CONF_9_12_1  1.0
    x_12_1      CONF_12_14_1  1.0
    x_12_2      ASSIGN_12  1.0
    x_12_2      CAP_2  16
    x_12_2      CONF_0_12_2  1.0
    x_12_2      CONF_8_12_2  1.0
    x_12_2      CONF_9_12_2  1.0
    x_12_2      CONF_12_14_2  1.0
    x_12_3      ASSIGN_12  1.0
    x_12_3      CAP_3  16
    x_12_3      CONF_0_12_3  1.0
    x_12_3      CONF_8_12_3  1.0
    x_12_3      CONF_9_12_3  1.0
    x_12_3      CONF_12_14_3  1.0
    x_12_4      ASSIGN_12  1.0
    x_12_4      CAP_4  16
    x_12_4      CONF_0_12_4  1.0
    x_12_4      CONF_8_12_4  1.0
    x_12_4      CONF_9_12_4  1.0
    x_12_4      CONF_12_14_4  1.0
    x_12_5      ASSIGN_12  1.0
    x_12_5      CAP_5  16
    x_12_5      CONF_0_12_5  1.0
    x_12_5      CONF_8_12_5  1.0
    x_12_5      CONF_9_12_5  1.0
    x_12_5      CONF_12_14_5  1.0
    x_12_6      ASSIGN_12  1.0
    x_12_6      CAP_6  16
    x_12_6      CONF_0_12_6  1.0
    x_12_6      CONF_8_12_6  1.0
    x_12_6      CONF_9_12_6  1.0
    x_12_6      CONF_12_14_6  1.0
    x_12_7      ASSIGN_12  1.0
    x_12_7      CAP_7  16
    x_12_7      CONF_0_12_7  1.0
    x_12_7      CONF_8_12_7  1.0
    x_12_7      CONF_9_12_7  1.0
    x_12_7      CONF_12_14_7  1.0
    x_12_8      ASSIGN_12  1.0
    x_12_8      CAP_8  16
    x_12_8      CONF_0_12_8  1.0
    x_12_8      CONF_8_12_8  1.0
    x_12_8      CONF_9_12_8  1.0
    x_12_8      CONF_12_14_8  1.0
    x_12_9      ASSIGN_12  1.0
    x_12_9      CAP_9  16
    x_12_9      CONF_0_12_9  1.0
    x_12_9      CONF_8_12_9  1.0
    x_12_9      CONF_9_12_9  1.0
    x_12_9      CONF_12_14_9  1.0
    x_12_10     ASSIGN_12  1.0
    x_12_10     CAP_10  16
    x_12_10     CONF_0_12_10  1.0
    x_12_10     CONF_8_12_10  1.0
    x_12_10     CONF_9_12_10  1.0
    x_12_10     CONF_12_14_10  1.0
    x_12_11     ASSIGN_12  1.0
    x_12_11     CAP_11  16
    x_12_11     CONF_0_12_11  1.0
    x_12_11     CONF_8_12_11  1.0
    x_12_11     CONF_9_12_11  1.0
    x_12_11     CONF_12_14_11  1.0
    x_12_12     ASSIGN_12  1.0
    x_12_12     CAP_12  16
    x_12_12     CONF_0_12_12  1.0
    x_12_12     CONF_8_12_12  1.0
    x_12_12     CONF_9_12_12  1.0
    x_12_12     CONF_12_14_12  1.0
    x_12_13     ASSIGN_12  1.0
    x_12_13     CAP_13  16
    x_12_13     CONF_0_12_13  1.0
    x_12_13     CONF_8_12_13  1.0
    x_12_13     CONF_9_12_13  1.0
    x_12_13     CONF_12_14_13  1.0
    x_12_14     ASSIGN_12  1.0
    x_12_14     CAP_14  16
    x_12_14     CONF_0_12_14  1.0
    x_12_14     CONF_8_12_14  1.0
    x_12_14     CONF_9_12_14  1.0
    x_12_14     CONF_12_14_14  1.0
    x_12_15     ASSIGN_12  1.0
    x_12_15     CAP_15  16
    x_12_15     CONF_0_12_15  1.0
    x_12_15     CONF_8_12_15  1.0
    x_12_15     CONF_9_12_15  1.0
    x_12_15     CONF_12_14_15  1.0
    x_13_0      ASSIGN_13  1.0
    x_13_0      CAP_0  11
    x_13_0      CONF_7_13_0  1.0
    x_13_0      CONF_13_15_0  1.0
    x_13_1      ASSIGN_13  1.0
    x_13_1      CAP_1  11
    x_13_1      CONF_7_13_1  1.0
    x_13_1      CONF_13_15_1  1.0
    x_13_2      ASSIGN_13  1.0
    x_13_2      CAP_2  11
    x_13_2      CONF_7_13_2  1.0
    x_13_2      CONF_13_15_2  1.0
    x_13_3      ASSIGN_13  1.0
    x_13_3      CAP_3  11
    x_13_3      CONF_7_13_3  1.0
    x_13_3      CONF_13_15_3  1.0
    x_13_4      ASSIGN_13  1.0
    x_13_4      CAP_4  11
    x_13_4      CONF_7_13_4  1.0
    x_13_4      CONF_13_15_4  1.0
    x_13_5      ASSIGN_13  1.0
    x_13_5      CAP_5  11
    x_13_5      CONF_7_13_5  1.0
    x_13_5      CONF_13_15_5  1.0
    x_13_6      ASSIGN_13  1.0
    x_13_6      CAP_6  11
    x_13_6      CONF_7_13_6  1.0
    x_13_6      CONF_13_15_6  1.0
    x_13_7      ASSIGN_13  1.0
    x_13_7      CAP_7  11
    x_13_7      CONF_7_13_7  1.0
    x_13_7      CONF_13_15_7  1.0
    x_13_8      ASSIGN_13  1.0
    x_13_8      CAP_8  11
    x_13_8      CONF_7_13_8  1.0
    x_13_8      CONF_13_15_8  1.0
    x_13_9      ASSIGN_13  1.0
    x_13_9      CAP_9  11
    x_13_9      CONF_7_13_9  1.0
    x_13_9      CONF_13_15_9  1.0
    x_13_10     ASSIGN_13  1.0
    x_13_10     CAP_10  11
    x_13_10     CONF_7_13_10  1.0
    x_13_10     CONF_13_15_10  1.0
    x_13_11     ASSIGN_13  1.0
    x_13_11     CAP_11  11
    x_13_11     CONF_7_13_11  1.0
    x_13_11     CONF_13_15_11  1.0
    x_13_12     ASSIGN_13  1.0
    x_13_12     CAP_12  11
    x_13_12     CONF_7_13_12  1.0
    x_13_12     CONF_13_15_12  1.0
    x_13_13     ASSIGN_13  1.0
    x_13_13     CAP_13  11
    x_13_13     CONF_7_13_13  1.0
    x_13_13     CONF_13_15_13  1.0
    x_13_14     ASSIGN_13  1.0
    x_13_14     CAP_14  11
    x_13_14     CONF_7_13_14  1.0
    x_13_14     CONF_13_15_14  1.0
    x_13_15     ASSIGN_13  1.0
    x_13_15     CAP_15  11
    x_13_15     CONF_7_13_15  1.0
    x_13_15     CONF_13_15_15  1.0
    x_14_0      ASSIGN_14  1.0
    x_14_0      CAP_0  12
    x_14_0      CONF_0_14_0  1.0
    x_14_0      CONF_5_14_0  1.0
    x_14_0      CONF_6_14_0  1.0
    x_14_0      CONF_7_14_0  1.0
    x_14_0      CONF_8_14_0  1.0
    x_14_0      CONF_12_14_0  1.0
    x_14_1      ASSIGN_14  1.0
    x_14_1      CAP_1  12
    x_14_1      CONF_0_14_1  1.0
    x_14_1      CONF_5_14_1  1.0
    x_14_1      CONF_6_14_1  1.0
    x_14_1      CONF_7_14_1  1.0
    x_14_1      CONF_8_14_1  1.0
    x_14_1      CONF_12_14_1  1.0
    x_14_2      ASSIGN_14  1.0
    x_14_2      CAP_2  12
    x_14_2      CONF_0_14_2  1.0
    x_14_2      CONF_5_14_2  1.0
    x_14_2      CONF_6_14_2  1.0
    x_14_2      CONF_7_14_2  1.0
    x_14_2      CONF_8_14_2  1.0
    x_14_2      CONF_12_14_2  1.0
    x_14_3      ASSIGN_14  1.0
    x_14_3      CAP_3  12
    x_14_3      CONF_0_14_3  1.0
    x_14_3      CONF_5_14_3  1.0
    x_14_3      CONF_6_14_3  1.0
    x_14_3      CONF_7_14_3  1.0
    x_14_3      CONF_8_14_3  1.0
    x_14_3      CONF_12_14_3  1.0
    x_14_4      ASSIGN_14  1.0
    x_14_4      CAP_4  12
    x_14_4      CONF_0_14_4  1.0
    x_14_4      CONF_5_14_4  1.0
    x_14_4      CONF_6_14_4  1.0
    x_14_4      CONF_7_14_4  1.0
    x_14_4      CONF_8_14_4  1.0
    x_14_4      CONF_12_14_4  1.0
    x_14_5      ASSIGN_14  1.0
    x_14_5      CAP_5  12
    x_14_5      CONF_0_14_5  1.0
    x_14_5      CONF_5_14_5  1.0
    x_14_5      CONF_6_14_5  1.0
    x_14_5      CONF_7_14_5  1.0
    x_14_5      CONF_8_14_5  1.0
    x_14_5      CONF_12_14_5  1.0
    x_14_6      ASSIGN_14  1.0
    x_14_6      CAP_6  12
    x_14_6      CONF_0_14_6  1.0
    x_14_6      CONF_5_14_6  1.0
    x_14_6      CONF_6_14_6  1.0
    x_14_6      CONF_7_14_6  1.0
    x_14_6      CONF_8_14_6  1.0
    x_14_6      CONF_12_14_6  1.0
    x_14_7      ASSIGN_14  1.0
    x_14_7      CAP_7  12
    x_14_7      CONF_0_14_7  1.0
    x_14_7      CONF_5_14_7  1.0
    x_14_7      CONF_6_14_7  1.0
    x_14_7      CONF_7_14_7  1.0
    x_14_7      CONF_8_14_7  1.0
    x_14_7      CONF_12_14_7  1.0
    x_14_8      ASSIGN_14  1.0
    x_14_8      CAP_8  12
    x_14_8      CONF_0_14_8  1.0
    x_14_8      CONF_5_14_8  1.0
    x_14_8      CONF_6_14_8  1.0
    x_14_8      CONF_7_14_8  1.0
    x_14_8      CONF_8_14_8  1.0
    x_14_8      CONF_12_14_8  1.0
    x_14_9      ASSIGN_14  1.0
    x_14_9      CAP_9  12
    x_14_9      CONF_0_14_9  1.0
    x_14_9      CONF_5_14_9  1.0
    x_14_9      CONF_6_14_9  1.0
    x_14_9      CONF_7_14_9  1.0
    x_14_9      CONF_8_14_9  1.0
    x_14_9      CONF_12_14_9  1.0
    x_14_10     ASSIGN_14  1.0
    x_14_10     CAP_10  12
    x_14_10     CONF_0_14_10  1.0
    x_14_10     CONF_5_14_10  1.0
    x_14_10     CONF_6_14_10  1.0
    x_14_10     CONF_7_14_10  1.0
    x_14_10     CONF_8_14_10  1.0
    x_14_10     CONF_12_14_10  1.0
    x_14_11     ASSIGN_14  1.0
    x_14_11     CAP_11  12
    x_14_11     CONF_0_14_11  1.0
    x_14_11     CONF_5_14_11  1.0
    x_14_11     CONF_6_14_11  1.0
    x_14_11     CONF_7_14_11  1.0
    x_14_11     CONF_8_14_11  1.0
    x_14_11     CONF_12_14_11  1.0
    x_14_12     ASSIGN_14  1.0
    x_14_12     CAP_12  12
    x_14_12     CONF_0_14_12  1.0
    x_14_12     CONF_5_14_12  1.0
    x_14_12     CONF_6_14_12  1.0
    x_14_12     CONF_7_14_12  1.0
    x_14_12     CONF_8_14_12  1.0
    x_14_12     CONF_12_14_12  1.0
    x_14_13     ASSIGN_14  1.0
    x_14_13     CAP_13  12
    x_14_13     CONF_0_14_13  1.0
    x_14_13     CONF_5_14_13  1.0
    x_14_13     CONF_6_14_13  1.0
    x_14_13     CONF_7_14_13  1.0
    x_14_13     CONF_8_14_13  1.0
    x_14_13     CONF_12_14_13  1.0
    x_14_14     ASSIGN_14  1.0
    x_14_14     CAP_14  12
    x_14_14     CONF_0_14_14  1.0
    x_14_14     CONF_5_14_14  1.0
    x_14_14     CONF_6_14_14  1.0
    x_14_14     CONF_7_14_14  1.0
    x_14_14     CONF_8_14_14  1.0
    x_14_14     CONF_12_14_14  1.0
    x_14_15     ASSIGN_14  1.0
    x_14_15     CAP_15  12
    x_14_15     CONF_0_14_15  1.0
    x_14_15     CONF_5_14_15  1.0
    x_14_15     CONF_6_14_15  1.0
    x_14_15     CONF_7_14_15  1.0
    x_14_15     CONF_8_14_15  1.0
    x_14_15     CONF_12_14_15  1.0
    x_15_0      ASSIGN_15  1.0
    x_15_0      CAP_0  23
    x_15_0      CONF_2_15_0  1.0
    x_15_0      CONF_7_15_0  1.0
    x_15_0      CONF_13_15_0  1.0
    x_15_1      ASSIGN_15  1.0
    x_15_1      CAP_1  23
    x_15_1      CONF_2_15_1  1.0
    x_15_1      CONF_7_15_1  1.0
    x_15_1      CONF_13_15_1  1.0
    x_15_2      ASSIGN_15  1.0
    x_15_2      CAP_2  23
    x_15_2      CONF_2_15_2  1.0
    x_15_2      CONF_7_15_2  1.0
    x_15_2      CONF_13_15_2  1.0
    x_15_3      ASSIGN_15  1.0
    x_15_3      CAP_3  23
    x_15_3      CONF_2_15_3  1.0
    x_15_3      CONF_7_15_3  1.0
    x_15_3      CONF_13_15_3  1.0
    x_15_4      ASSIGN_15  1.0
    x_15_4      CAP_4  23
    x_15_4      CONF_2_15_4  1.0
    x_15_4      CONF_7_15_4  1.0
    x_15_4      CONF_13_15_4  1.0
    x_15_5      ASSIGN_15  1.0
    x_15_5      CAP_5  23
    x_15_5      CONF_2_15_5  1.0
    x_15_5      CONF_7_15_5  1.0
    x_15_5      CONF_13_15_5  1.0
    x_15_6      ASSIGN_15  1.0
    x_15_6      CAP_6  23
    x_15_6      CONF_2_15_6  1.0
    x_15_6      CONF_7_15_6  1.0
    x_15_6      CONF_13_15_6  1.0
    x_15_7      ASSIGN_15  1.0
    x_15_7      CAP_7  23
    x_15_7      CONF_2_15_7  1.0
    x_15_7      CONF_7_15_7  1.0
    x_15_7      CONF_13_15_7  1.0
    x_15_8      ASSIGN_15  1.0
    x_15_8      CAP_8  23
    x_15_8      CONF_2_15_8  1.0
    x_15_8      CONF_7_15_8  1.0
    x_15_8      CONF_13_15_8  1.0
    x_15_9      ASSIGN_15  1.0
    x_15_9      CAP_9  23
    x_15_9      CONF_2_15_9  1.0
    x_15_9      CONF_7_15_9  1.0
    x_15_9      CONF_13_15_9  1.0
    x_15_10     ASSIGN_15  1.0
    x_15_10     CAP_10  23
    x_15_10     CONF_2_15_10  1.0
    x_15_10     CONF_7_15_10  1.0
    x_15_10     CONF_13_15_10  1.0
    x_15_11     ASSIGN_15  1.0
    x_15_11     CAP_11  23
    x_15_11     CONF_2_15_11  1.0
    x_15_11     CONF_7_15_11  1.0
    x_15_11     CONF_13_15_11  1.0
    x_15_12     ASSIGN_15  1.0
    x_15_12     CAP_12  23
    x_15_12     CONF_2_15_12  1.0
    x_15_12     CONF_7_15_12  1.0
    x_15_12     CONF_13_15_12  1.0
    x_15_13     ASSIGN_15  1.0
    x_15_13     CAP_13  23
    x_15_13     CONF_2_15_13  1.0
    x_15_13     CONF_7_15_13  1.0
    x_15_13     CONF_13_15_13  1.0
    x_15_14     ASSIGN_15  1.0
    x_15_14     CAP_14  23
    x_15_14     CONF_2_15_14  1.0
    x_15_14     CONF_7_15_14  1.0
    x_15_14     CONF_13_15_14  1.0
    x_15_15     ASSIGN_15  1.0
    x_15_15     CAP_15  23
    x_15_15     CONF_2_15_15  1.0
    x_15_15     CONF_7_15_15  1.0
    x_15_15     CONF_13_15_15  1.0
    y_0         OBJ       1.0
    y_0         CAP_0  -100
    y_0         CONF_3_10_0  -1.0
    y_0         CONF_0_2_0  -1.0
    y_0         CONF_8_12_0  -1.0
    y_0         CONF_1_6_0  -1.0
    y_0         CONF_0_14_0  -1.0
    y_0         CONF_1_9_0  -1.0
    y_0         CONF_0_11_0  -1.0
    y_0         CONF_6_11_0  -1.0
    y_0         CONF_6_14_0  -1.0
    y_0         CONF_7_13_0  -1.0
    y_0         CONF_4_8_0  -1.0
    y_0         CONF_4_11_0  -1.0
    y_0         CONF_8_14_0  -1.0
    y_0         CONF_0_4_0  -1.0
    y_0         CONF_2_7_0  -1.0
    y_0         CONF_1_8_0  -1.0
    y_0         CONF_7_15_0  -1.0
    y_0         CONF_4_7_0  -1.0
    y_0         CONF_3_5_0  -1.0
    y_0         CONF_12_14_0  -1.0
    y_0         CONF_5_14_0  -1.0
    y_0         CONF_9_12_0  -1.0
    y_0         CONF_0_9_0  -1.0
    y_0         CONF_8_10_0  -1.0
    y_0         CONF_0_12_0  -1.0
    y_0         CONF_2_9_0  -1.0
    y_0         CONF_2_6_0  -1.0
    y_0         CONF_2_15_0  -1.0
    y_0         CONF_13_15_0  -1.0
    y_0         CONF_7_14_0  -1.0
    y_1         OBJ       1.0
    y_1         CAP_1  -100
    y_1         CONF_3_10_1  -1.0
    y_1         CONF_0_2_1  -1.0
    y_1         CONF_8_12_1  -1.0
    y_1         CONF_1_6_1  -1.0
    y_1         CONF_0_14_1  -1.0
    y_1         CONF_1_9_1  -1.0
    y_1         CONF_0_11_1  -1.0
    y_1         CONF_6_11_1  -1.0
    y_1         CONF_6_14_1  -1.0
    y_1         CONF_7_13_1  -1.0
    y_1         CONF_4_8_1  -1.0
    y_1         CONF_4_11_1  -1.0
    y_1         CONF_8_14_1  -1.0
    y_1         CONF_0_4_1  -1.0
    y_1         CONF_2_7_1  -1.0
    y_1         CONF_1_8_1  -1.0
    y_1         CONF_7_15_1  -1.0
    y_1         CONF_4_7_1  -1.0
    y_1         CONF_3_5_1  -1.0
    y_1         CONF_12_14_1  -1.0
    y_1         CONF_5_14_1  -1.0
    y_1         CONF_9_12_1  -1.0
    y_1         CONF_0_9_1  -1.0
    y_1         CONF_8_10_1  -1.0
    y_1         CONF_0_12_1  -1.0
    y_1         CONF_2_9_1  -1.0
    y_1         CONF_2_6_1  -1.0
    y_1         CONF_2_15_1  -1.0
    y_1         CONF_13_15_1  -1.0
    y_1         CONF_7_14_1  -1.0
    y_2         OBJ       1.0
    y_2         CAP_2  -100
    y_2         CONF_3_10_2  -1.0
    y_2         CONF_0_2_2  -1.0
    y_2         CONF_8_12_2  -1.0
    y_2         CONF_1_6_2  -1.0
    y_2         CONF_0_14_2  -1.0
    y_2         CONF_1_9_2  -1.0
    y_2         CONF_0_11_2  -1.0
    y_2         CONF_6_11_2  -1.0
    y_2         CONF_6_14_2  -1.0
    y_2         CONF_7_13_2  -1.0
    y_2         CONF_4_8_2  -1.0
    y_2         CONF_4_11_2  -1.0
    y_2         CONF_8_14_2  -1.0
    y_2         CONF_0_4_2  -1.0
    y_2         CONF_2_7_2  -1.0
    y_2         CONF_1_8_2  -1.0
    y_2         CONF_7_15_2  -1.0
    y_2         CONF_4_7_2  -1.0
    y_2         CONF_3_5_2  -1.0
    y_2         CONF_12_14_2  -1.0
    y_2         CONF_5_14_2  -1.0
    y_2         CONF_9_12_2  -1.0
    y_2         CONF_0_9_2  -1.0
    y_2         CONF_8_10_2  -1.0
    y_2         CONF_0_12_2  -1.0
    y_2         CONF_2_9_2  -1.0
    y_2         CONF_2_6_2  -1.0
    y_2         CONF_2_15_2  -1.0
    y_2         CONF_13_15_2  -1.0
    y_2         CONF_7_14_2  -1.0
    y_3         OBJ       1.0
    y_3         CAP_3  -100
    y_3         CONF_3_10_3  -1.0
    y_3         CONF_0_2_3  -1.0
    y_3         CONF_8_12_3  -1.0
    y_3         CONF_1_6_3  -1.0
    y_3         CONF_0_14_3  -1.0
    y_3         CONF_1_9_3  -1.0
    y_3         CONF_0_11_3  -1.0
    y_3         CONF_6_11_3  -1.0
    y_3         CONF_6_14_3  -1.0
    y_3         CONF_7_13_3  -1.0
    y_3         CONF_4_8_3  -1.0
    y_3         CONF_4_11_3  -1.0
    y_3         CONF_8_14_3  -1.0
    y_3         CONF_0_4_3  -1.0
    y_3         CONF_2_7_3  -1.0
    y_3         CONF_1_8_3  -1.0
    y_3         CONF_7_15_3  -1.0
    y_3         CONF_4_7_3  -1.0
    y_3         CONF_3_5_3  -1.0
    y_3         CONF_12_14_3  -1.0
    y_3         CONF_5_14_3  -1.0
    y_3         CONF_9_12_3  -1.0
    y_3         CONF_0_9_3  -1.0
    y_3         CONF_8_10_3  -1.0
    y_3         CONF_0_12_3  -1.0
    y_3         CONF_2_9_3  -1.0
    y_3         CONF_2_6_3  -1.0
    y_3         CONF_2_15_3  -1.0
    y_3         CONF_13_15_3  -1.0
    y_3         CONF_7_14_3  -1.0
    y_4         OBJ       1.0
    y_4         CAP_4  -100
    y_4         CONF_3_10_4  -1.0
    y_4         CONF_0_2_4  -1.0
    y_4         CONF_8_12_4  -1.0
    y_4         CONF_1_6_4  -1.0
    y_4         CONF_0_14_4  -1.0
    y_4         CONF_1_9_4  -1.0
    y_4         CONF_0_11_4  -1.0
    y_4         CONF_6_11_4  -1.0
    y_4         CONF_6_14_4  -1.0
    y_4         CONF_7_13_4  -1.0
    y_4         CONF_4_8_4  -1.0
    y_4         CONF_4_11_4  -1.0
    y_4         CONF_8_14_4  -1.0
    y_4         CONF_0_4_4  -1.0
    y_4         CONF_2_7_4  -1.0
    y_4         CONF_1_8_4  -1.0
    y_4         CONF_7_15_4  -1.0
    y_4         CONF_4_7_4  -1.0
    y_4         CONF_3_5_4  -1.0
    y_4         CONF_12_14_4  -1.0
    y_4         CONF_5_14_4  -1.0
    y_4         CONF_9_12_4  -1.0
    y_4         CONF_0_9_4  -1.0
    y_4         CONF_8_10_4  -1.0
    y_4         CONF_0_12_4  -1.0
    y_4         CONF_2_9_4  -1.0
    y_4         CONF_2_6_4  -1.0
    y_4         CONF_2_15_4  -1.0
    y_4         CONF_13_15_4  -1.0
    y_4         CONF_7_14_4  -1.0
    y_5         OBJ       1.0
    y_5         CAP_5  -100
    y_5         CONF_3_10_5  -1.0
    y_5         CONF_0_2_5  -1.0
    y_5         CONF_8_12_5  -1.0
    y_5         CONF_1_6_5  -1.0
    y_5         CONF_0_14_5  -1.0
    y_5         CONF_1_9_5  -1.0
    y_5         CONF_0_11_5  -1.0
    y_5         CONF_6_11_5  -1.0
    y_5         CONF_6_14_5  -1.0
    y_5         CONF_7_13_5  -1.0
    y_5         CONF_4_8_5  -1.0
    y_5         CONF_4_11_5  -1.0
    y_5         CONF_8_14_5  -1.0
    y_5         CONF_0_4_5  -1.0
    y_5         CONF_2_7_5  -1.0
    y_5         CONF_1_8_5  -1.0
    y_5         CONF_7_15_5  -1.0
    y_5         CONF_4_7_5  -1.0
    y_5         CONF_3_5_5  -1.0
    y_5         CONF_12_14_5  -1.0
    y_5         CONF_5_14_5  -1.0
    y_5         CONF_9_12_5  -1.0
    y_5         CONF_0_9_5  -1.0
    y_5         CONF_8_10_5  -1.0
    y_5         CONF_0_12_5  -1.0
    y_5         CONF_2_9_5  -1.0
    y_5         CONF_2_6_5  -1.0
    y_5         CONF_2_15_5  -1.0
    y_5         CONF_13_15_5  -1.0
    y_5         CONF_7_14_5  -1.0
    y_6         OBJ       1.0
    y_6         CAP_6  -100
    y_6         CONF_3_10_6  -1.0
    y_6         CONF_0_2_6  -1.0
    y_6         CONF_8_12_6  -1.0
    y_6         CONF_1_6_6  -1.0
    y_6         CONF_0_14_6  -1.0
    y_6         CONF_1_9_6  -1.0
    y_6         CONF_0_11_6  -1.0
    y_6         CONF_6_11_6  -1.0
    y_6         CONF_6_14_6  -1.0
    y_6         CONF_7_13_6  -1.0
    y_6         CONF_4_8_6  -1.0
    y_6         CONF_4_11_6  -1.0
    y_6         CONF_8_14_6  -1.0
    y_6         CONF_0_4_6  -1.0
    y_6         CONF_2_7_6  -1.0
    y_6         CONF_1_8_6  -1.0
    y_6         CONF_7_15_6  -1.0
    y_6         CONF_4_7_6  -1.0
    y_6         CONF_3_5_6  -1.0
    y_6         CONF_12_14_6  -1.0
    y_6         CONF_5_14_6  -1.0
    y_6         CONF_9_12_6  -1.0
    y_6         CONF_0_9_6  -1.0
    y_6         CONF_8_10_6  -1.0
    y_6         CONF_0_12_6  -1.0
    y_6         CONF_2_9_6  -1.0
    y_6         CONF_2_6_6  -1.0
    y_6         CONF_2_15_6  -1.0
    y_6         CONF_13_15_6  -1.0
    y_6         CONF_7_14_6  -1.0
    y_7         OBJ       1.0
    y_7         CAP_7  -100
    y_7         CONF_3_10_7  -1.0
    y_7         CONF_0_2_7  -1.0
    y_7         CONF_8_12_7  -1.0
    y_7         CONF_1_6_7  -1.0
    y_7         CONF_0_14_7  -1.0
    y_7         CONF_1_9_7  -1.0
    y_7         CONF_0_11_7  -1.0
    y_7         CONF_6_11_7  -1.0
    y_7         CONF_6_14_7  -1.0
    y_7         CONF_7_13_7  -1.0
    y_7         CONF_4_8_7  -1.0
    y_7         CONF_4_11_7  -1.0
    y_7         CONF_8_14_7  -1.0
    y_7         CONF_0_4_7  -1.0
    y_7         CONF_2_7_7  -1.0
    y_7         CONF_1_8_7  -1.0
    y_7         CONF_7_15_7  -1.0
    y_7         CONF_4_7_7  -1.0
    y_7         CONF_3_5_7  -1.0
    y_7         CONF_12_14_7  -1.0
    y_7         CONF_5_14_7  -1.0
    y_7         CONF_9_12_7  -1.0
    y_7         CONF_0_9_7  -1.0
    y_7         CONF_8_10_7  -1.0
    y_7         CONF_0_12_7  -1.0
    y_7         CONF_2_9_7  -1.0
    y_7         CONF_2_6_7  -1.0
    y_7         CONF_2_15_7  -1.0
    y_7         CONF_13_15_7  -1.0
    y_7         CONF_7_14_7  -1.0
    y_8         OBJ       1.0
    y_8         CAP_8  -100
    y_8         CONF_3_10_8  -1.0
    y_8         CONF_0_2_8  -1.0
    y_8         CONF_8_12_8  -1.0
    y_8         CONF_1_6_8  -1.0
    y_8         CONF_0_14_8  -1.0
    y_8         CONF_1_9_8  -1.0
    y_8         CONF_0_11_8  -1.0
    y_8         CONF_6_11_8  -1.0
    y_8         CONF_6_14_8  -1.0
    y_8         CONF_7_13_8  -1.0
    y_8         CONF_4_8_8  -1.0
    y_8         CONF_4_11_8  -1.0
    y_8         CONF_8_14_8  -1.0
    y_8         CONF_0_4_8  -1.0
    y_8         CONF_2_7_8  -1.0
    y_8         CONF_1_8_8  -1.0
    y_8         CONF_7_15_8  -1.0
    y_8         CONF_4_7_8  -1.0
    y_8         CONF_3_5_8  -1.0
    y_8         CONF_12_14_8  -1.0
    y_8         CONF_5_14_8  -1.0
    y_8         CONF_9_12_8  -1.0
    y_8         CONF_0_9_8  -1.0
    y_8         CONF_8_10_8  -1.0
    y_8         CONF_0_12_8  -1.0
    y_8         CONF_2_9_8  -1.0
    y_8         CONF_2_6_8  -1.0
    y_8         CONF_2_15_8  -1.0
    y_8         CONF_13_15_8  -1.0
    y_8         CONF_7_14_8  -1.0
    y_9         OBJ       1.0
    y_9         CAP_9  -100
    y_9         CONF_3_10_9  -1.0
    y_9         CONF_0_2_9  -1.0
    y_9         CONF_8_12_9  -1.0
    y_9         CONF_1_6_9  -1.0
    y_9         CONF_0_14_9  -1.0
    y_9         CONF_1_9_9  -1.0
    y_9         CONF_0_11_9  -1.0
    y_9         CONF_6_11_9  -1.0
    y_9         CONF_6_14_9  -1.0
    y_9         CONF_7_13_9  -1.0
    y_9         CONF_4_8_9  -1.0
    y_9         CONF_4_11_9  -1.0
    y_9         CONF_8_14_9  -1.0
    y_9         CONF_0_4_9  -1.0
    y_9         CONF_2_7_9  -1.0
    y_9         CONF_1_8_9  -1.0
    y_9         CONF_7_15_9  -1.0
    y_9         CONF_4_7_9  -1.0
    y_9         CONF_3_5_9  -1.0
    y_9         CONF_12_14_9  -1.0
    y_9         CONF_5_14_9  -1.0
    y_9         CONF_9_12_9  -1.0
    y_9         CONF_0_9_9  -1.0
    y_9         CONF_8_10_9  -1.0
    y_9         CONF_0_12_9  -1.0
    y_9         CONF_2_9_9  -1.0
    y_9         CONF_2_6_9  -1.0
    y_9         CONF_2_15_9  -1.0
    y_9         CONF_13_15_9  -1.0
    y_9         CONF_7_14_9  -1.0
    y_10        OBJ       1.0
    y_10        CAP_10  -100
    y_10        CONF_3_10_10  -1.0
    y_10        CONF_0_2_10  -1.0
    y_10        CONF_8_12_10  -1.0
    y_10        CONF_1_6_10  -1.0
    y_10        CONF_0_14_10  -1.0
    y_10        CONF_1_9_10  -1.0
    y_10        CONF_0_11_10  -1.0
    y_10        CONF_6_11_10  -1.0
    y_10        CONF_6_14_10  -1.0
    y_10        CONF_7_13_10  -1.0
    y_10        CONF_4_8_10  -1.0
    y_10        CONF_4_11_10  -1.0
    y_10        CONF_8_14_10  -1.0
    y_10        CONF_0_4_10  -1.0
    y_10        CONF_2_7_10  -1.0
    y_10        CONF_1_8_10  -1.0
    y_10        CONF_7_15_10  -1.0
    y_10        CONF_4_7_10  -1.0
    y_10        CONF_3_5_10  -1.0
    y_10        CONF_12_14_10  -1.0
    y_10        CONF_5_14_10  -1.0
    y_10        CONF_9_12_10  -1.0
    y_10        CONF_0_9_10  -1.0
    y_10        CONF_8_10_10  -1.0
    y_10        CONF_0_12_10  -1.0
    y_10        CONF_2_9_10  -1.0
    y_10        CONF_2_6_10  -1.0
    y_10        CONF_2_15_10  -1.0
    y_10        CONF_13_15_10  -1.0
    y_10        CONF_7_14_10  -1.0
    y_11        OBJ       1.0
    y_11        CAP_11  -100
    y_11        CONF_3_10_11  -1.0
    y_11        CONF_0_2_11  -1.0
    y_11        CONF_8_12_11  -1.0
    y_11        CONF_1_6_11  -1.0
    y_11        CONF_0_14_11  -1.0
    y_11        CONF_1_9_11  -1.0
    y_11        CONF_0_11_11  -1.0
    y_11        CONF_6_11_11  -1.0
    y_11        CONF_6_14_11  -1.0
    y_11        CONF_7_13_11  -1.0
    y_11        CONF_4_8_11  -1.0
    y_11        CONF_4_11_11  -1.0
    y_11        CONF_8_14_11  -1.0
    y_11        CONF_0_4_11  -1.0
    y_11        CONF_2_7_11  -1.0
    y_11        CONF_1_8_11  -1.0
    y_11        CONF_7_15_11  -1.0
    y_11        CONF_4_7_11  -1.0
    y_11        CONF_3_5_11  -1.0
    y_11        CONF_12_14_11  -1.0
    y_11        CONF_5_14_11  -1.0
    y_11        CONF_9_12_11  -1.0
    y_11        CONF_0_9_11  -1.0
    y_11        CONF_8_10_11  -1.0
    y_11        CONF_0_12_11  -1.0
    y_11        CONF_2_9_11  -1.0
    y_11        CONF_2_6_11  -1.0
    y_11        CONF_2_15_11  -1.0
    y_11        CONF_13_15_11  -1.0
    y_11        CONF_7_14_11  -1.0
    y_12        OBJ       1.0
    y_12        CAP_12  -100
    y_12        CONF_3_10_12  -1.0
    y_12        CONF_0_2_12  -1.0
    y_12        CONF_8_12_12  -1.0
    y_12        CONF_1_6_12  -1.0
    y_12        CONF_0_14_12  -1.0
    y_12        CONF_1_9_12  -1.0
    y_12        CONF_0_11_12  -1.0
    y_12        CONF_6_11_12  -1.0
    y_12        CONF_6_14_12  -1.0
    y_12        CONF_7_13_12  -1.0
    y_12        CONF_4_8_12  -1.0
    y_12        CONF_4_11_12  -1.0
    y_12        CONF_8_14_12  -1.0
    y_12        CONF_0_4_12  -1.0
    y_12        CONF_2_7_12  -1.0
    y_12        CONF_1_8_12  -1.0
    y_12        CONF_7_15_12  -1.0
    y_12        CONF_4_7_12  -1.0
    y_12        CONF_3_5_12  -1.0
    y_12        CONF_12_14_12  -1.0
    y_12        CONF_5_14_12  -1.0
    y_12        CONF_9_12_12  -1.0
    y_12        CONF_0_9_12  -1.0
    y_12        CONF_8_10_12  -1.0
    y_12        CONF_0_12_12  -1.0
    y_12        CONF_2_9_12  -1.0
    y_12        CONF_2_6_12  -1.0
    y_12        CONF_2_15_12  -1.0
    y_12        CONF_13_15_12  -1.0
    y_12        CONF_7_14_12  -1.0
    y_13        OBJ       1.0
    y_13        CAP_13  -100
    y_13        CONF_3_10_13  -1.0
    y_13        CONF_0_2_13  -1.0
    y_13        CONF_8_12_13  -1.0
    y_13        CONF_1_6_13  -1.0
    y_13        CONF_0_14_13  -1.0
    y_13        CONF_1_9_13  -1.0
    y_13        CONF_0_11_13  -1.0
    y_13        CONF_6_11_13  -1.0
    y_13        CONF_6_14_13  -1.0
    y_13        CONF_7_13_13  -1.0
    y_13        CONF_4_8_13  -1.0
    y_13        CONF_4_11_13  -1.0
    y_13        CONF_8_14_13  -1.0
    y_13        CONF_0_4_13  -1.0
    y_13        CONF_2_7_13  -1.0
    y_13        CONF_1_8_13  -1.0
    y_13        CONF_7_15_13  -1.0
    y_13        CONF_4_7_13  -1.0
    y_13        CONF_3_5_13  -1.0
    y_13        CONF_12_14_13  -1.0
    y_13        CONF_5_14_13  -1.0
    y_13        CONF_9_12_13  -1.0
    y_13        CONF_0_9_13  -1.0
    y_13        CONF_8_10_13  -1.0
    y_13        CONF_0_12_13  -1.0
    y_13        CONF_2_9_13  -1.0
    y_13        CONF_2_6_13  -1.0
    y_13        CONF_2_15_13  -1.0
    y_13        CONF_13_15_13  -1.0
    y_13        CONF_7_14_13  -1.0
    y_14        OBJ       1.0
    y_14        CAP_14  -100
    y_14        CONF_3_10_14  -1.0
    y_14        CONF_0_2_14  -1.0
    y_14        CONF_8_12_14  -1.0
    y_14        CONF_1_6_14  -1.0
    y_14        CONF_0_14_14  -1.0
    y_14        CONF_1_9_14  -1.0
    y_14        CONF_0_11_14  -1.0
    y_14        CONF_6_11_14  -1.0
    y_14        CONF_6_14_14  -1.0
    y_14        CONF_7_13_14  -1.0
    y_14        CONF_4_8_14  -1.0
    y_14        CONF_4_11_14  -1.0
    y_14        CONF_8_14_14  -1.0
    y_14        CONF_0_4_14  -1.0
    y_14        CONF_2_7_14  -1.0
    y_14        CONF_1_8_14  -1.0
    y_14        CONF_7_15_14  -1.0
    y_14        CONF_4_7_14  -1.0
    y_14        CONF_3_5_14  -1.0
    y_14        CONF_12_14_14  -1.0
    y_14        CONF_5_14_14  -1.0
    y_14        CONF_9_12_14  -1.0
    y_14        CONF_0_9_14  -1.0
    y_14        CONF_8_10_14  -1.0
    y_14        CONF_0_12_14  -1.0
    y_14        CONF_2_9_14  -1.0
    y_14        CONF_2_6_14  -1.0
    y_14        CONF_2_15_14  -1.0
    y_14        CONF_13_15_14  -1.0
    y_14        CONF_7_14_14  -1.0
    y_15        OBJ       1.0
    y_15        CAP_15  -100
    y_15        CONF_3_10_15  -1.0
    y_15        CONF_0_2_15  -1.0
    y_15        CONF_8_12_15  -1.0
    y_15        CONF_1_6_15  -1.0
    y_15        CONF_0_14_15  -1.0
    y_15        CONF_1_9_15  -1.0
    y_15        CONF_0_11_15  -1.0
    y_15        CONF_6_11_15  -1.0
    y_15        CONF_6_14_15  -1.0
    y_15        CONF_7_13_15  -1.0
    y_15        CONF_4_8_15  -1.0
    y_15        CONF_4_11_15  -1.0
    y_15        CONF_8_14_15  -1.0
    y_15        CONF_0_4_15  -1.0
    y_15        CONF_2_7_15  -1.0
    y_15        CONF_1_8_15  -1.0
    y_15        CONF_7_15_15  -1.0
    y_15        CONF_4_7_15  -1.0
    y_15        CONF_3_5_15  -1.0
    y_15        CONF_12_14_15  -1.0
    y_15        CONF_5_14_15  -1.0
    y_15        CONF_9_12_15  -1.0
    y_15        CONF_0_9_15  -1.0
    y_15        CONF_8_10_15  -1.0
    y_15        CONF_0_12_15  -1.0
    y_15        CONF_2_9_15  -1.0
    y_15        CONF_2_6_15  -1.0
    y_15        CONF_2_15_15  -1.0
    y_15        CONF_13_15_15  -1.0
    y_15        CONF_7_14_15  -1.0
RHS
    RHS1      ASSIGN_0  1.0
    RHS1      ASSIGN_1  1.0
    RHS1      ASSIGN_2  1.0
    RHS1      ASSIGN_3  1.0
    RHS1      ASSIGN_4  1.0
    RHS1      ASSIGN_5  1.0
    RHS1      ASSIGN_6  1.0
    RHS1      ASSIGN_7  1.0
    RHS1      ASSIGN_8  1.0
    RHS1      ASSIGN_9  1.0
    RHS1      ASSIGN_10  1.0
    RHS1      ASSIGN_11  1.0
    RHS1      ASSIGN_12  1.0
    RHS1      ASSIGN_13  1.0
    RHS1      ASSIGN_14  1.0
    RHS1      ASSIGN_15  1.0
BOUNDS
 BV BND1      y_0
 BV BND1      y_1
 BV BND1      y_2
 BV BND1      y_3
 BV BND1      y_4
 BV BND1      y_5
 BV BND1      y_6
 BV BND1      y_7
 BV BND1      y_8
 BV BND1      y_9
 BV BND1      y_10
 BV BND1      y_11
 BV BND1      y_12
 BV BND1      y_13
 BV BND1      y_14
 BV BND1      y_15
 BV BND1      x_0_0
 BV BND1      x_0_1
 BV BND1      x_0_2
 BV BND1      x_0_3
 BV BND1      x_0_4
 BV BND1      x_0_5
 BV BND1      x_0_6
 BV BND1      x_0_7
 BV BND1      x_0_8
 BV BND1      x_0_9
 BV BND1      x_0_10
 BV BND1      x_0_11
 BV BND1      x_0_12
 BV BND1      x_0_13
 BV BND1      x_0_14
 BV BND1      x_0_15
 BV BND1      x_1_0
 BV BND1      x_1_1
 BV BND1      x_1_2
 BV BND1      x_1_3
 BV BND1      x_1_4
 BV BND1      x_1_5
 BV BND1      x_1_6
 BV BND1      x_1_7
 BV BND1      x_1_8
 BV BND1      x_1_9
 BV BND1      x_1_10
 BV BND1      x_1_11
 BV BND1      x_1_12
 BV BND1      x_1_13
 BV BND1      x_1_14
 BV BND1      x_1_15
 BV BND1      x_2_0
 BV BND1      x_2_1
 BV BND1      x_2_2
 BV BND1      x_2_3
 BV BND1      x_2_4
 BV BND1      x_2_5
 BV BND1      x_2_6
 BV BND1      x_2_7
 BV BND1      x_2_8
 BV BND1      x_2_9
 BV BND1      x_2_10
 BV BND1      x_2_11
 BV BND1      x_2_12
 BV BND1      x_2_13
 BV BND1      x_2_14
 BV BND1      x_2_15
 BV BND1      x_3_0
 BV BND1      x_3_1
 BV BND1      x_3_2
 BV BND1      x_3_3
 BV BND1      x_3_4
 BV BND1      x_3_5
 BV BND1      x_3_6
 BV BND1      x_3_7
 BV BND1      x_3_8
 BV BND1      x_3_9
 BV BND1      x_3_10
 BV BND1      x_3_11
 BV BND1      x_3_12
 BV BND1      x_3_13
 BV BND1      x_3_14
 BV BND1      x_3_15
 BV BND1      x_4_0
 BV BND1      x_4_1
 BV BND1      x_4_2
 BV BND1      x_4_3
 BV BND1      x_4_4
 BV BND1      x_4_5
 BV BND1      x_4_6
 BV BND1      x_4_7
 BV BND1      x_4_8
 BV BND1      x_4_9
 BV BND1      x_4_10
 BV BND1      x_4_11
 BV BND1      x_4_12
 BV BND1      x_4_13
 BV BND1      x_4_14
 BV BND1      x_4_15
 BV BND1      x_5_0
 BV BND1      x_5_1
 BV BND1      x_5_2
 BV BND1      x_5_3
 BV BND1      x_5_4
 BV BND1      x_5_5
 BV BND1      x_5_6
 BV BND1      x_5_7
 BV BND1      x_5_8
 BV BND1      x_5_9
 BV BND1      x_5_10
 BV BND1      x_5_11
 BV BND1      x_5_12
 BV BND1      x_5_13
 BV BND1      x_5_14
 BV BND1      x_5_15
 BV BND1      x_6_0
 BV BND1      x_6_1
 BV BND1      x_6_2
 BV BND1      x_6_3
 BV BND1      x_6_4
 BV BND1      x_6_5
 BV BND1      x_6_6
 BV BND1      x_6_7
 BV BND1      x_6_8
 BV BND1      x_6_9
 BV BND1      x_6_10
 BV BND1      x_6_11
 BV BND1      x_6_12
 BV BND1      x_6_13
 BV BND1      x_6_14
 BV BND1      x_6_15
 BV BND1      x_7_0
 BV BND1      x_7_1
 BV BND1      x_7_2
 BV BND1      x_7_3
 BV BND1      x_7_4
 BV BND1      x_7_5
 BV BND1      x_7_6
 BV BND1      x_7_7
 BV BND1      x_7_8
 BV BND1      x_7_9
 BV BND1      x_7_10
 BV BND1      x_7_11
 BV BND1      x_7_12
 BV BND1      x_7_13
 BV BND1      x_7_14
 BV BND1      x_7_15
 BV BND1      x_8_0
 BV BND1      x_8_1
 BV BND1      x_8_2
 BV BND1      x_8_3
 BV BND1      x_8_4
 BV BND1      x_8_5
 BV BND1      x_8_6
 BV BND1      x_8_7
 BV BND1      x_8_8
 BV BND1      x_8_9
 BV BND1      x_8_10
 BV BND1      x_8_11
 BV BND1      x_8_12
 BV BND1      x_8_13
 BV BND1      x_8_14
 BV BND1      x_8_15
 BV BND1      x_9_0
 BV BND1      x_9_1
 BV BND1      x_9_2
 BV BND1      x_9_3
 BV BND1      x_9_4
 BV BND1      x_9_5
 BV BND1      x_9_6
 BV BND1      x_9_7
 BV BND1      x_9_8
 BV BND1      x_9_9
 BV BND1      x_9_10
 BV BND1      x_9_11
 BV BND1      x_9_12
 BV BND1      x_9_13
 BV BND1      x_9_14
 BV BND1      x_9_15
 BV BND1      x_10_0
 BV BND1      x_10_1
 BV BND1      x_10_2
 BV BND1      x_10_3
 BV BND1      x_10_4
 BV BND1      x_10_5
 BV BND1      x_10_6
 BV BND1      x_10_7
 BV BND1      x_10_8
 BV BND1      x_10_9
 BV BND1      x_10_10
 BV BND1      x_10_11
 BV BND1      x_10_12
 BV BND1      x_10_13
 BV BND1      x_10_14
 BV BND1      x_10_15
 BV BND1      x_11_0
 BV BND1      x_11_1
 BV BND1      x_11_2
 BV BND1      x_11_3
 BV BND1      x_11_4
 BV BND1      x_11_5
 BV BND1      x_11_6
 BV BND1      x_11_7
 BV BND1      x_11_8
 BV BND1      x_11_9
 BV BND1      x_11_10
 BV BND1      x_11_11
 BV BND1      x_11_12
 BV BND1      x_11_13
 BV BND1      x_11_14
 BV BND1      x_11_15
 BV BND1      x_12_0
 BV BND1      x_12_1
 BV BND1      x_12_2
 BV BND1      x_12_3
 BV BND1      x_12_4
 BV BND1      x_12_5
 BV BND1      x_12_6
 BV BND1      x_12_7
 BV BND1      x_12_8
 BV BND1      x_12_9
 BV BND1      x_12_10
 BV BND1      x_12_11
 BV BND1      x_12_12
 BV BND1      x_12_13
 BV BND1      x_12_14
 BV BND1      x_12_15
 BV BND1      x_13_0
 BV BND1      x_13_1
 BV BND1      x_13_2
 BV BND1      x_13_3
 BV BND1      x_13_4
 BV BND1      x_13_5
 BV BND1      x_13_6
 BV BND1      x_13_7
 BV BND1      x_13_8
 BV BND1      x_13_9
 BV BND1      x_13_10
 BV BND1      x_13_11
 BV BND1      x_13_12
 BV BND1      x_13_13
 BV BND1      x_13_14
 BV BND1      x_13_15
 BV BND1      x_14_0
 BV BND1      x_14_1
 BV BND1      x_14_2
 BV BND1      x_14_3
 BV BND1      x_14_4
 BV BND1      x_14_5
 BV BND1      x_14_6
 BV BND1      x_14_7
 BV BND1      x_14_8
 BV BND1      x_14_9
 BV BND1      x_14_10
 BV BND1      x_14_11
 BV BND1      x_14_12
 BV BND1      x_14_13
 BV BND1      x_14_14
 BV BND1      x_14_15
 BV BND1      x_15_0
 BV BND1      x_15_1
 BV BND1      x_15_2
 BV BND1      x_15_3
 BV BND1      x_15_4
 BV BND1      x_15_5
 BV BND1      x_15_6
 BV BND1      x_15_7
 BV BND1      x_15_8
 BV BND1      x_15_9
 BV BND1      x_15_10
 BV BND1      x_15_11
 BV BND1      x_15_12
 BV BND1      x_15_13
 BV BND1      x_15_14
 BV BND1      x_15_15
ENDATA
