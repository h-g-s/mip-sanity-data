NAME          MIS
ROWS
 N  OBJ
 L  EDGE_7_17
 L  EDGE_15_30
 L  EDGE_26_30
 L  EDGE_18_35
 L  EDGE_70_73
 L  EDGE_5_65
 L  EDGE_17_67
 L  EDGE_18_44
 L  EDGE_29_32
 L  EDGE_36_80
 L  EDGE_40_41
 L  EDGE_5_83
 L  EDGE_11_14
 L  EDGE_41_42
 L  EDGE_25_34
 L  EDGE_33_47
 L  EDGE_39_81
 L  EDGE_44_56
 L  EDGE_20_86
 L  EDGE_14_15
 L  EDGE_31_86
 L  EDGE_2_59
 L  EDGE_32_60
 L  EDGE_22_37
 L  EDGE_14_33
 L  EDGE_13_65
 L  EDGE_3_42
 L  EDGE_14_42
 L  EDGE_43_78
 L  EDGE_16_70
 L  EDGE_1_81
 L  EDGE_7_12
 L  EDGE_24_83
 L  EDGE_36_48
 L  EDGE_18_30
 L  EDGE_9_49
 L  EDGE_55_79
 L  EDGE_59_68
 L  EDGE_36_75
 L  EDGE_36_84
 L  EDGE_5_78
 L  EDGE_29_45
 L  EDGE_69_81
 L  EDGE_9_76
 L  EDGE_48_58
 L  EDGE_40_54
 L  EDGE_50_86
 L  EDGE_61_86
 L  EDGE_6_61
 L  EDGE_10_22
 L  EDGE_10_31
 L  EDGE_39_76
 L  EDGE_2_36
 L  EDGE_39_85
 L  EDGE_20_81
 L  EDGE_25_47
 L  EDGE_2_54
 L  EDGE_3_19
 L  EDGE_43_55
 L  EDGE_51_68
 L  EDGE_13_51
 L  EDGE_14_28
 L  EDGE_32_64
 L  EDGE_43_73
 L  EDGE_51_86
 L  EDGE_13_69
 L  EDGE_16_65
 L  EDGE_1_76
 L  EDGE_13_78
 L  EDGE_24_78
 L  EDGE_24_87
 L  EDGE_35_87
 L  EDGE_16_83
 L  EDGE_28_48
 L  EDGE_55_65
 L  EDGE_77_80
 L  EDGE_28_75
 L  EDGE_6_38
 L  EDGE_9_71
 L  EDGE_48_53
 L  EDGE_50_72
 L  EDGE_40_49
 L  EDGE_77_89
 L  EDGE_50_81
 L  EDGE_61_81
 L  EDGE_42_77
 L  EDGE_27_88
 L  EDGE_62_64
 L  EDGE_0_89
 L  EDGE_11_89
 L  EDGE_3_5
 L  EDGE_54_87
 L  EDGE_43_50
 L  EDGE_12_81
 L  EDGE_35_46
 L  EDGE_4_77
 L  EDGE_14_23
 L  EDGE_51_72
 L  EDGE_24_55
 L  EDGE_4_86
 L  EDGE_32_68
 L  EDGE_43_68
 L  EDGE_35_64
 L  EDGE_66_70
 L  EDGE_32_77
 L  EDGE_24_73
 L  EDGE_35_73
 L  EDGE_65_83
 L  EDGE_55_60
 L  EDGE_17_43
 L  EDGE_28_43
 L  EDGE_36_56
 L  EDGE_46_79
 L  EDGE_47_56
 L  EDGE_46_88
 L  EDGE_36_65
 L  EDGE_9_48
 L  EDGE_49_84
 L  EDGE_17_61
 L  EDGE_6_24
 L  EDGE_28_61
 L  EDGE_50_58
 L  EDGE_5_68
 L  EDGE_6_33
 L  EDGE_69_80
 L  EDGE_21_40
 L  EDGE_61_85
 L  EDGE_10_12
 L  EDGE_39_48
 L  EDGE_8_79
 L  EDGE_30_79
 L  EDGE_2_17
 L  EDGE_10_30
 L  EDGE_25_28
 L  EDGE_62_77
 L  EDGE_73_77
 L  EDGE_20_71
 L  EDGE_13_32
 L  EDGE_20_80
 L  EDGE_54_82
 L  EDGE_24_41
 L  EDGE_14_18
 L  EDGE_43_54
 L  EDGE_12_85
 L  EDGE_23_85
 L  EDGE_53_86
 L  EDGE_4_81
 L  EDGE_87_88
 L  EDGE_43_72
 L  EDGE_17_20
 L  EDGE_1_75
 L  EDGE_65_78
 L  EDGE_5_36
 L  EDGE_17_38
 L  EDGE_28_38
 L  EDGE_38_70
 L  EDGE_47_51
 L  EDGE_5_45
 L  EDGE_28_47
 L  EDGE_57_83
 L  EDGE_49_79
 L  EDGE_65_87
 L  EDGE_5_54
 L  EDGE_88_89
 L  EDGE_50_53
 L  EDGE_77_79
 L  EDGE_42_58
 L  EDGE_30_65
 L  EDGE_30_74
 L  EDGE_20_39
 L  EDGE_61_89
 L  EDGE_10_16
 L  EDGE_31_48
 L  EDGE_83_86
 L  EDGE_11_79
 L  EDGE_62_63
 L  EDGE_31_57
 L  EDGE_0_88
 L  EDGE_11_88
 L  EDGE_3_4
 L  EDGE_4_58
 L  EDGE_51_53
 L  EDGE_13_36
 L  EDGE_32_49
 L  EDGE_43_49
 L  EDGE_12_80
 L  EDGE_53_81
 L  EDGE_64_81
 L  EDGE_32_58
 L  EDGE_72_85
 L  EDGE_13_63
 L  EDGE_1_61
 L  EDGE_9_11
 L  EDGE_37_82
 L  EDGE_5_22
 L  EDGE_1_70
 L  EDGE_46_60
 L  EDGE_5_31
 L  EDGE_17_33
 L  EDGE_3_47
 L  EDGE_28_33
 L  EDGE_38_65
 L  EDGE_46_69
 L  EDGE_49_65
 L  EDGE_68_69
 L  EDGE_68_78
 L  EDGE_46_87
 L  EDGE_57_87
 L  EDGE_26_81
 L  EDGE_42_44
 L  EDGE_50_66
 L  EDGE_19_60
 L  EDGE_27_73
 L  EDGE_0_56
 L  EDGE_50_75
 L  EDGE_19_78
 L  EDGE_42_80
 L  EDGE_30_87
 L  EDGE_20_52
 L  EDGE_11_83
 L  EDGE_23_48
 L  EDGE_20_61
 L  EDGE_12_57
 L  EDGE_13_22
 L  EDGE_31_70
 L  EDGE_4_53
 L  EDGE_12_66
 L  EDGE_1_29
 L  EDGE_13_31
 L  EDGE_23_66
 L  EDGE_16_27
 L  EDGE_43_44
 L  EDGE_35_40
 L  EDGE_53_67
 L  EDGE_4_71
 L  EDGE_64_67
 L  EDGE_5_8
 L  EDGE_16_54
 L  EDGE_37_86
 L  EDGE_38_51
 L  EDGE_65_77
 L  EDGE_76_77
 L  EDGE_57_73
 L  EDGE_65_86
 L  EDGE_5_44
 L  EDGE_7_63
 L  EDGE_57_82
 L  EDGE_49_78
 L  EDGE_27_41
 L  EDGE_6_18
 L  EDGE_18_72
 L  EDGE_49_87
 L  EDGE_30_46
 L  EDGE_27_59
 L  EDGE_50_61
 L  EDGE_8_55
 L  EDGE_19_55
 L  EDGE_30_55
 L  EDGE_61_70
 L  EDGE_19_64
 L  EDGE_30_64
 L  EDGE_19_73
 L  EDGE_42_75
 L  EDGE_0_69
 L  EDGE_11_69
 L  EDGE_4_30
 L  EDGE_0_78
 L  EDGE_39_60
 L  EDGE_31_56
 L  EDGE_66_85
 L  EDGE_44_84
 L  EDGE_12_61
 L  EDGE_24_26
 L  EDGE_24_35
 L  EDGE_53_71
 L  EDGE_45_67
 L  EDGE_56_67
 L  EDGE_13_44
 L  EDGE_24_44
 L  EDGE_35_44
 L  EDGE_56_76
 L  EDGE_53_89
 L  EDGE_3_70
 L  EDGE_37_72
 L  EDGE_16_49
 L  EDGE_45_85
 L  EDGE_9_10
 L  EDGE_49_55
 L  EDGE_46_68
 L  EDGE_49_64
 L  EDGE_38_73
 L  EDGE_27_36
 L  EDGE_18_67
 L  EDGE_49_82
 L  EDGE_8_41
 L  EDGE_50_56
 L  EDGE_8_50
 L  EDGE_48_86
 L  EDGE_8_59
 L  EDGE_42_61
 L  EDGE_11_55
 L  EDGE_8_68
 L  EDGE_39_46
 L  EDGE_23_29
 L  EDGE_60_78
 L  EDGE_41_74
 L  EDGE_60_87
 L  EDGE_75_85
 L  EDGE_4_52
 L  EDGE_33_88
 L  EDGE_34_53
 L  EDGE_53_66
 L  EDGE_4_61
 L  EDGE_53_84
 L  EDGE_14_65
 L  EDGE_37_67
 L  EDGE_45_80
 L  EDGE_37_85
 L  EDGE_15_48
 L  EDGE_26_48
 L  EDGE_49_50
 L  EDGE_57_63
 L  EDGE_7_53
 L  EDGE_38_68
 L  EDGE_49_68
 L  EDGE_18_62
 L  EDGE_7_71
 L  EDGE_30_36
 L  EDGE_71_74
 L  EDGE_79_87
 L  EDGE_11_32
 L  EDGE_63_70
 L  EDGE_19_45
 L  EDGE_82_83
 L  EDGE_27_58
 L  EDGE_11_41
 L  EDGE_29_77
 L  EDGE_42_56
 L  EDGE_63_79
 L  EDGE_11_59
 L  EDGE_12_24
 L  EDGE_20_37
 L  EDGE_4_20
 L  EDGE_52_69
 L  EDGE_4_29
 L  EDGE_33_65
 L  EDGE_12_42
 L  EDGE_1_5
 L  EDGE_75_80
 L  EDGE_33_83
 L  EDGE_22_55
 L  EDGE_56_57
 L  EDGE_1_32
 L  EDGE_2_86
 L  EDGE_53_70
 L  EDGE_45_66
 L  EDGE_34_75
 L  EDGE_15_34
 L  EDGE_15_43
 L  EDGE_59_77
 L  EDGE_14_87
 L  EDGE_7_48
 L  EDGE_7_66
 L  EDGE_8_31
 L  EDGE_19_31
 L  EDGE_18_75
 L  EDGE_40_72
 L  EDGE_8_49
 L  EDGE_71_87
 L  EDGE_6_79
 L  EDGE_11_45
 L  EDGE_21_77
 L  EDGE_11_54
 L  EDGE_4_15
 L  EDGE_33_51
 L  EDGE_41_64
 L  EDGE_60_77
 L  EDGE_33_60
 L  EDGE_52_73
 L  EDGE_60_86
 L  EDGE_4_33
 L  EDGE_44_69
 L  EDGE_41_82
 L  EDGE_2_72
 L  EDGE_53_56
 L  EDGE_33_87
 L  EDGE_25_83
 L  EDGE_3_46
 L  EDGE_56_61
 L  EDGE_22_68
 L  EDGE_22_77
 L  EDGE_7_25
 L  EDGE_37_75
 L  EDGE_15_38
 L  EDGE_26_38
 L  EDGE_38_40
 L  EDGE_18_34
 L  EDGE_70_72
 L  EDGE_38_49
 L  EDGE_55_83
 L  EDGE_26_56
 L  EDGE_18_52
 L  EDGE_11_13
 L  EDGE_19_26
 L  EDGE_0_22
 L  EDGE_8_35
 L  EDGE_9_89
 L  EDGE_19_35
 L  EDGE_30_35
 L  EDGE_63_69
 L  EDGE_30_44
 L  EDGE_71_73
 L  EDGE_71_82
 L  EDGE_0_40
 L  EDGE_63_78
 L  EDGE_21_72
 L  EDGE_6_83
 L  EDGE_11_49
 L  EDGE_40_85
 L  EDGE_63_87
 L  EDGE_52_59
 L  EDGE_60_72
 L  EDGE_10_53
 L  EDGE_33_64
 L  EDGE_44_64
 L  EDGE_1_4
 L  EDGE_25_60
 L  EDGE_22_36
 L  EDGE_34_38
 L  EDGE_3_32
 L  EDGE_44_82
 L  EDGE_22_45
 L  EDGE_45_47
 L  EDGE_2_76
 L  EDGE_14_41
 L  EDGE_25_78
 L  EDGE_34_56
 L  EDGE_3_50
 L  EDGE_14_50
 L  EDGE_3_59
 L  EDGE_15_24
 L  EDGE_7_20
 L  EDGE_26_33
 L  EDGE_7_29
 L  EDGE_67_80
 L  EDGE_59_76
 L  EDGE_55_87
 L  EDGE_7_47
 L  EDGE_17_79
 L  EDGE_18_56
 L  EDGE_9_75
 L  EDGE_5_86
 L  EDGE_17_88
 L  EDGE_28_88
 L  EDGE_8_30
 L  EDGE_9_84
 L  EDGE_0_26
 L  EDGE_6_60
 L  EDGE_29_62
 L  EDGE_48_75
 L  EDGE_63_73
 L  EDGE_29_80
 L  EDGE_63_82
 L  EDGE_21_76
 L  EDGE_6_87
 L  EDGE_21_85
 L  EDGE_73_86
 L  EDGE_41_63
 L  EDGE_44_68
 L  EDGE_22_31
 L  EDGE_2_62
 L  EDGE_14_27
 L  EDGE_10_75
 L  EDGE_74_78
 L  EDGE_2_71
 L  EDGE_14_36
 L  EDGE_22_49
 L  EDGE_45_51
 L  EDGE_74_87
 L  EDGE_3_45
 L  EDGE_14_45
 L  EDGE_22_58
 L  EDGE_32_81
 L  EDGE_24_86
 L  EDGE_35_86
 L  EDGE_3_63
 L  EDGE_55_64
 L  EDGE_47_60
 L  EDGE_59_71
 L  EDGE_70_71
 L  EDGE_55_82
 L  EDGE_17_65
 L  EDGE_59_80
 L  EDGE_5_72
 L  EDGE_17_74
 L  EDGE_29_39
 L  EDGE_9_70
 L  EDGE_42_78
 L  EDGE_11_12
 L  EDGE_11_21
 L  EDGE_11_30
 L  EDGE_21_62
 L  EDGE_4_9
 L  EDGE_10_43
 L  EDGE_39_88
 L  EDGE_20_84
 L  EDGE_10_61
 L  EDGE_44_63
 L  EDGE_25_59
 L  EDGE_3_22
 L  EDGE_66_69
 L  EDGE_3_40
 L  EDGE_24_72
 L  EDGE_3_49
 L  EDGE_13_81
 L  EDGE_7_10
 L  EDGE_16_77
 L  EDGE_17_51
 L  EDGE_28_51
 L  EDGE_7_28
 L  EDGE_18_28
 L  EDGE_28_60
 L  EDGE_18_37
 L  EDGE_9_56
 L  EDGE_47_73
 L  EDGE_5_67
 L  EDGE_29_34
 L  EDGE_36_82
 L  EDGE_55_86
 L  EDGE_17_78
 L  EDGE_0_7
 L  EDGE_40_43
 L  EDGE_9_74
 L  EDGE_28_87
 L  EDGE_0_16
 L  EDGE_58_88
 L  EDGE_9_83
 L  EDGE_21_48
 L  EDGE_48_65
 L  EDGE_6_59
 L  EDGE_40_61
 L  EDGE_29_70
 L  EDGE_21_66
 L  EDGE_2_25
 L  EDGE_21_75
 L  EDGE_25_45
 L  EDGE_12_84
 L  EDGE_14_26
 L  EDGE_22_39
 L  EDGE_24_58
 L  EDGE_51_75
 L  EDGE_4_89
 L  EDGE_85_86
 L  EDGE_35_67
 L  EDGE_32_80
 L  EDGE_43_80
 L  EDGE_66_82
 L  EDGE_24_76
 L  EDGE_32_89
 L  EDGE_36_50
 L  EDGE_16_81
 L  EDGE_17_46
 L  EDGE_7_23
 L  EDGE_47_59
 L  EDGE_59_61
 L  EDGE_17_55
 L  EDGE_59_70
 L  EDGE_36_77
 L  EDGE_5_71
 L  EDGE_6_36
 L  EDGE_28_73
 L  EDGE_48_51
 L  EDGE_77_87
 L  EDGE_5_80
 L  EDGE_6_45
 L  EDGE_61_79
 L  EDGE_29_56
 L  EDGE_61_88
 L  EDGE_2_29
 L  EDGE_10_42
 L  EDGE_33_44
 L  EDGE_2_38
 L  EDGE_20_74
 L  EDGE_31_74
 L  EDGE_23_70
 L  EDGE_51_52
 L  EDGE_31_83
 L  EDGE_54_85
 L  EDGE_73_89
 L  EDGE_23_79
 L  EDGE_12_88
 L  EDGE_24_53
 L  EDGE_1_60
 L  EDGE_24_71
 L  EDGE_1_78
 L  EDGE_7_9
 L  EDGE_1_87
 L  EDGE_13_89
 L  EDGE_9_37
 L  EDGE_17_68
 L  EDGE_28_68
 L  EDGE_21_29
 L  EDGE_29_42
 L  EDGE_40_42
 L  EDGE_61_74
 L  EDGE_58_87
 L  EDGE_21_47
 L  EDGE_61_83
 L  EDGE_6_58
 L  EDGE_42_88
 L  EDGE_62_66
 L  EDGE_2_24
 L  EDGE_31_60
 L  EDGE_54_62
 L  EDGE_62_75
 L  EDGE_20_69
 L  EDGE_25_35
 L  EDGE_32_34
 L  EDGE_62_84
 L  EDGE_24_39
 L  EDGE_35_39
 L  EDGE_4_70
 L  EDGE_35_48
 L  EDGE_43_61
 L  EDGE_16_44
 L  EDGE_35_57
 L  EDGE_16_53
 L  EDGE_17_18
 L  EDGE_1_64
 L  EDGE_16_62
 L  EDGE_24_75
 L  EDGE_36_40
 L  EDGE_65_76
 L  EDGE_5_34
 L  EDGE_28_36
 L  EDGE_36_49
 L  EDGE_9_32
 L  EDGE_47_49
 L  EDGE_28_45
 L  EDGE_65_85
 L  EDGE_76_85
 L  EDGE_6_26
 L  EDGE_50_60
 L  EDGE_7_89
 L  EDGE_58_73
 L  EDGE_27_67
 L  EDGE_8_72
 L  EDGE_42_83
 L  EDGE_2_10
 L  EDGE_10_23
 L  EDGE_31_55
 L  EDGE_0_86
 L  EDGE_11_86
 L  EDGE_20_64
 L  EDGE_31_73
 L  EDGE_13_34
 L  EDGE_35_43
 L  EDGE_16_39
 L  EDGE_13_52
 L  EDGE_53_88
 L  EDGE_16_48
 L  EDGE_13_61
 L  EDGE_16_66
 L  EDGE_57_67
 L  EDGE_65_80
 L  EDGE_17_40
 L  EDGE_46_76
 L  EDGE_65_89
 L  EDGE_17_49
 L  EDGE_28_49
 L  EDGE_9_45
 L  EDGE_5_56
 L  EDGE_58_68
 L  EDGE_21_28
 L  EDGE_6_39
 L  EDGE_69_77
 L  EDGE_27_71
 L  EDGE_69_86
 L  EDGE_30_67
 L  EDGE_42_69
 L  EDGE_50_82
 L  EDGE_11_63
 L  EDGE_8_76
 L  EDGE_19_76
 L  EDGE_20_41
 L  EDGE_0_72
 L  EDGE_39_54
 L  EDGE_8_85
 L  EDGE_20_50
 L  EDGE_31_50
 L  EDGE_39_63
 L  EDGE_23_46
 L  EDGE_83_88
 L  EDGE_20_68
 L  EDGE_31_77
 L  EDGE_16_25
 L  EDGE_64_74
 L  EDGE_16_34
 L  EDGE_13_47
 L  EDGE_56_79
 L  EDGE_1_54
 L  EDGE_16_52
 L  EDGE_56_88
 L  EDGE_57_62
 L  EDGE_46_71
 L  EDGE_68_71
 L  EDGE_65_84
 L  EDGE_9_31
 L  EDGE_15_65
 L  EDGE_15_74
 L  EDGE_7_79
 L  EDGE_21_23
 L  EDGE_8_53
 L  EDGE_19_53
 L  EDGE_27_66
 L  EDGE_42_55
 L  EDGE_42_64
 L  EDGE_11_58
 L  EDGE_19_71
 L  EDGE_31_36
 L  EDGE_42_73
 L  EDGE_23_32
 L  EDGE_30_80
 L  EDGE_2_9
 L  EDGE_0_76
 L  EDGE_39_58
 L  EDGE_19_89
 L  EDGE_54_56
 L  EDGE_4_37
 L  EDGE_75_79
 L  EDGE_20_63
 L  EDGE_32_37
 L  EDGE_53_69
 L  EDGE_72_82
 L  EDGE_45_65
 L  EDGE_1_40
 L  EDGE_53_78
 L  EDGE_16_38
 L  EDGE_34_83
 L  EDGE_46_48
 L  EDGE_1_58
 L  EDGE_56_83
 L  EDGE_46_57
 L  EDGE_14_86
 L  EDGE_65_70
 L  EDGE_5_28
 L  EDGE_17_30
 L  EDGE_28_30
 L  EDGE_57_66
 L  EDGE_65_79
 L  EDGE_15_69
 L  EDGE_26_69
 L  EDGE_79_81
 L  EDGE_8_39
 L  EDGE_7_83
 L  EDGE_8_48
 L  EDGE_18_83
 L  EDGE_19_48
 L  EDGE_30_48
 L  EDGE_71_86
 L  EDGE_8_57
 L  EDGE_27_70
 L  EDGE_11_53
 L  EDGE_30_66
 L  EDGE_0_62
 L  EDGE_12_27
 L  EDGE_23_27
 L  EDGE_31_40
 L  EDGE_41_72
 L  EDGE_60_85
 L  EDGE_44_86
 L  EDGE_1_26
 L  EDGE_13_28
 L  EDGE_4_59
 L  EDGE_16_24
 L  EDGE_72_86
 L  EDGE_22_67
 L  EDGE_34_69
 L  EDGE_34_78
 L  EDGE_3_72
 L  EDGE_9_12
 L  EDGE_15_46
 L  EDGE_15_55
 L  EDGE_68_70
 L  EDGE_18_51
 L  EDGE_8_25
 L  EDGE_8_34
 L  EDGE_15_82
 L  EDGE_26_82
 L  EDGE_27_47
 L  EDGE_30_43
 L  EDGE_42_45
 L  EDGE_27_56
 L  EDGE_0_39
 L  EDGE_11_39
 L  EDGE_8_52
 L  EDGE_63_77
 L  EDGE_29_84
 L  EDGE_0_66
 L  EDGE_20_44
 L  EDGE_60_80
 L  EDGE_23_40
 L  EDGE_41_76
 L  EDGE_75_78
 L  EDGE_44_72
 L  EDGE_75_87
 L  EDGE_33_81
 L  EDGE_1_21
 L  EDGE_25_77
 L  EDGE_2_84
 L  EDGE_37_51
 L  EDGE_45_64
 L  EDGE_1_39
 L  EDGE_53_77
 L  EDGE_64_86
 L  EDGE_46_47
 L  EDGE_14_76
 L  EDGE_3_85
 L  EDGE_26_50
 L  EDGE_37_87
 L  EDGE_38_52
 L  EDGE_7_46
 L  EDGE_15_59
 L  EDGE_26_59
 L  EDGE_19_20
 L  EDGE_15_68
 L  EDGE_49_70
 L  EDGE_19_29
 L  EDGE_15_77
 L  EDGE_26_77
 L  EDGE_27_42
 L  EDGE_79_80
 L  EDGE_8_38
 L  EDGE_79_89
 L  EDGE_11_34
 L  EDGE_18_82
 L  EDGE_19_47
 L  EDGE_29_79
 L  EDGE_30_56
 L  EDGE_20_21
 L  EDGE_6_86
 L  EDGE_12_17
 L  EDGE_29_88
 L  EDGE_20_30
 L  EDGE_40_88
 L  EDGE_52_53
 L  EDGE_41_62
 L  EDGE_52_71
 L  EDGE_41_80
 L  EDGE_75_82
 L  EDGE_44_76
 L  EDGE_41_89
 L  EDGE_2_70
 L  EDGE_53_54
 L  EDGE_44_85
 L  EDGE_45_50
 L  EDGE_25_81
 L  EDGE_37_46
 L  EDGE_53_63
 L  EDGE_34_68
 L  EDGE_3_71
 L  EDGE_14_71
 L  EDGE_26_36
 L  EDGE_46_51
 L  EDGE_3_80
 L  EDGE_38_47
 L  EDGE_7_41
 L  EDGE_70_79
 L  EDGE_7_50
 L  EDGE_8_15
 L  EDGE_18_50
 L  EDGE_36_86
 L  EDGE_7_59
 L  EDGE_48_60
 L  EDGE_8_33
 L  EDGE_9_87
 L  EDGE_27_46
 L  EDGE_11_29
 L  EDGE_29_65
 L  EDGE_63_67
 L  EDGE_79_84
 L  EDGE_0_38
 L  EDGE_6_72
 L  EDGE_11_38
 L  EDGE_21_70
 L  EDGE_48_87
 L  EDGE_6_81
 L  EDGE_40_83
 L  EDGE_71_89
 L  EDGE_60_61
 L  EDGE_4_8
 L  EDGE_21_88
 L  EDGE_4_17
 L  EDGE_60_70
 L  EDGE_25_58
 L  EDGE_33_71
 L  EDGE_25_67
 L  EDGE_34_45
 L  EDGE_53_58
 L  EDGE_10_87
 L  EDGE_45_54
 L  EDGE_51_88
 L  EDGE_25_85
 L  EDGE_14_57
 L  EDGE_37_59
 L  EDGE_22_70
 L  EDGE_3_66
 L  EDGE_59_65
 L  EDGE_15_40
 L  EDGE_55_76
 L  EDGE_7_36
 L  EDGE_18_36
 L  EDGE_15_49
 L  EDGE_55_85
 L  EDGE_7_45
 L  EDGE_8_10
 L  EDGE_47_81
 L  EDGE_59_83
 L  EDGE_0_6
 L  EDGE_11_15
 L  EDGE_8_28
 L  EDGE_9_82
 L  EDGE_19_28
 L  EDGE_11_24
 L  EDGE_30_37
 L  EDGE_11_42
 L  EDGE_40_78
 L  EDGE_6_85
 L  EDGE_12_16
 L  EDGE_60_65
 L  EDGE_33_48
 L  EDGE_25_44
 L  EDGE_2_51
 L  EDGE_25_62
 L  EDGE_44_75
 L  EDGE_22_38
 L  EDGE_34_40
 L  EDGE_2_69
 L  EDGE_25_71
 L  EDGE_74_76
 L  EDGE_22_47
 L  EDGE_3_43
 L  EDGE_66_81
 L  EDGE_3_52
 L  EDGE_37_54
 L  EDGE_7_13
 L  EDGE_7_22
 L  EDGE_59_60
 L  EDGE_16_89
 L  EDGE_18_31
 L  EDGE_15_44
 L  EDGE_17_63
 L  EDGE_36_76
 L  EDGE_28_72
 L  EDGE_0_1
 L  EDGE_7_49
 L  EDGE_8_14
 L  EDGE_9_68
 L  EDGE_28_81
 L  EDGE_0_10
 L  EDGE_48_68
 L  EDGE_6_62
 L  EDGE_6_80
 L  EDGE_25_30
 L  EDGE_6_89
 L  EDGE_25_39
 L  EDGE_44_52
 L  EDGE_25_48
 L  EDGE_14_20
 L  EDGE_10_68
 L  EDGE_44_70
 L  EDGE_66_67
 L  EDGE_10_77
 L  EDGE_22_42
 L  EDGE_2_73
 L  EDGE_66_76
 L  EDGE_22_51
 L  EDGE_13_70
 L  EDGE_14_47
 L  EDGE_7_8
COLUMNS
    x_0         OBJ       -1
    x_0         EDGE_0_89  1.0
    x_0         EDGE_0_88  1.0
    x_0         EDGE_0_56  1.0
    x_0         EDGE_0_69  1.0
    x_0         EDGE_0_78  1.0
    x_0         EDGE_0_22  1.0
    x_0         EDGE_0_40  1.0
    x_0         EDGE_0_26  1.0
    x_0         EDGE_0_7  1.0
    x_0         EDGE_0_16  1.0
    x_0         EDGE_0_86  1.0
    x_0         EDGE_0_72  1.0
    x_0         EDGE_0_76  1.0
    x_0         EDGE_0_62  1.0
    x_0         EDGE_0_39  1.0
    x_0         EDGE_0_66  1.0
    x_0         EDGE_0_38  1.0
    x_0         EDGE_0_6  1.0
    x_0         EDGE_0_1  1.0
    x_0         EDGE_0_10  1.0
    x_1         OBJ       -1
    x_1         EDGE_1_81  1.0
    x_1         EDGE_1_76  1.0
    x_1         EDGE_1_75  1.0
    x_1         EDGE_1_61  1.0
    x_1         EDGE_1_70  1.0
    x_1         EDGE_1_29  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_32  1.0
    x_1         EDGE_1_4  1.0
    x_1         EDGE_1_60  1.0
    x_1         EDGE_1_78  1.0
    x_1         EDGE_1_87  1.0
    x_1         EDGE_1_64  1.0
    x_1         EDGE_1_54  1.0
    x_1         EDGE_1_40  1.0
    x_1         EDGE_1_58  1.0
    x_1         EDGE_1_26  1.0
    x_1         EDGE_1_21  1.0
    x_1         EDGE_1_39  1.0
    x_1         EDGE_0_1  1.0
    x_2         OBJ       -1
    x_2         EDGE_2_59  1.0
    x_2         EDGE_2_36  1.0
    x_2         EDGE_2_54  1.0
    x_2         EDGE_2_17  1.0
    x_2         EDGE_2_86  1.0
    x_2         EDGE_2_72  1.0
    x_2         EDGE_2_76  1.0
    x_2         EDGE_2_62  1.0
    x_2         EDGE_2_71  1.0
    x_2         EDGE_2_25  1.0
    x_2         EDGE_2_29  1.0
    x_2         EDGE_2_38  1.0
    x_2         EDGE_2_24  1.0
    x_2         EDGE_2_10  1.0
    x_2         EDGE_2_9  1.0
    x_2         EDGE_2_84  1.0
    x_2         EDGE_2_70  1.0
    x_2         EDGE_2_51  1.0
    x_2         EDGE_2_69  1.0
    x_2         EDGE_2_73  1.0
    x_3         OBJ       -1
    x_3         EDGE_3_42  1.0
    x_3         EDGE_3_19  1.0
    x_3         EDGE_3_5  1.0
    x_3         EDGE_3_4  1.0
    x_3         EDGE_3_47  1.0
    x_3         EDGE_3_70  1.0
    x_3         EDGE_3_46  1.0
    x_3         EDGE_3_32  1.0
    x_3         EDGE_3_50  1.0
    x_3         EDGE_3_59  1.0
    x_3         EDGE_3_45  1.0
    x_3         EDGE_3_63  1.0
    x_3         EDGE_3_22  1.0
    x_3         EDGE_3_40  1.0
    x_3         EDGE_3_49  1.0
    x_3         EDGE_3_72  1.0
    x_3         EDGE_3_85  1.0
    x_3         EDGE_3_71  1.0
    x_3         EDGE_3_80  1.0
    x_3         EDGE_3_66  1.0
    x_3         EDGE_3_43  1.0
    x_3         EDGE_3_52  1.0
    x_4         OBJ       -1
    x_4         EDGE_4_77  1.0
    x_4         EDGE_4_86  1.0
    x_4         EDGE_4_81  1.0
    x_4         EDGE_3_4  1.0
    x_4         EDGE_4_58  1.0
    x_4         EDGE_4_53  1.0
    x_4         EDGE_4_71  1.0
    x_4         EDGE_4_30  1.0
    x_4         EDGE_4_52  1.0
    x_4         EDGE_4_61  1.0
    x_4         EDGE_4_20  1.0
    x_4         EDGE_4_29  1.0
    x_4         EDGE_4_15  1.0
    x_4         EDGE_4_33  1.0
    x_4         EDGE_1_4  1.0
    x_4         EDGE_4_9  1.0
    x_4         EDGE_4_89  1.0
    x_4         EDGE_4_70  1.0
    x_4         EDGE_4_37  1.0
    x_4         EDGE_4_59  1.0
    x_4         EDGE_4_8  1.0
    x_4         EDGE_4_17  1.0
    x_5         OBJ       -1
    x_5         EDGE_5_65  1.0
    x_5         EDGE_5_83  1.0
    x_5         EDGE_5_78  1.0
    x_5         EDGE_3_5  1.0
    x_5         EDGE_5_68  1.0
    x_5         EDGE_5_36  1.0
    x_5         EDGE_5_45  1.0
    x_5         EDGE_5_54  1.0
    x_5         EDGE_5_22  1.0
    x_5         EDGE_5_31  1.0
    x_5         EDGE_5_8  1.0
    x_5         EDGE_5_44  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_86  1.0
    x_5         EDGE_5_72  1.0
    x_5         EDGE_5_67  1.0
    x_5         EDGE_5_71  1.0
    x_5         EDGE_5_80  1.0
    x_5         EDGE_5_34  1.0
    x_5         EDGE_5_56  1.0
    x_5         EDGE_5_28  1.0
    x_6         OBJ       -1
    x_6         EDGE_6_61  1.0
    x_6         EDGE_6_38  1.0
    x_6         EDGE_6_24  1.0
    x_6         EDGE_6_33  1.0
    x_6         EDGE_6_18  1.0
    x_6         EDGE_6_79  1.0
    x_6         EDGE_6_83  1.0
    x_6         EDGE_6_60  1.0
    x_6         EDGE_6_87  1.0
    x_6         EDGE_6_59  1.0
    x_6         EDGE_6_36  1.0
    x_6         EDGE_6_45  1.0
    x_6         EDGE_6_58  1.0
    x_6         EDGE_6_26  1.0
    x_6         EDGE_6_39  1.0
    x_6         EDGE_6_86  1.0
    x_6         EDGE_6_72  1.0
    x_6         EDGE_6_81  1.0
    x_6         EDGE_0_6  1.0
    x_6         EDGE_6_85  1.0
    x_6         EDGE_6_62  1.0
    x_6         EDGE_6_80  1.0
    x_6         EDGE_6_89  1.0
    x_7         OBJ       -1
    x_7         EDGE_7_17  1.0
    x_7         EDGE_7_12  1.0
    x_7         EDGE_7_63  1.0
    x_7         EDGE_7_53  1.0
    x_7         EDGE_7_71  1.0
    x_7         EDGE_7_48  1.0
    x_7         EDGE_7_66  1.0
    x_7         EDGE_7_25  1.0
    x_7         EDGE_7_20  1.0
    x_7         EDGE_7_29  1.0
    x_7         EDGE_7_47  1.0
    x_7         EDGE_7_10  1.0
    x_7         EDGE_7_28  1.0
    x_7         EDGE_0_7  1.0
    x_7         EDGE_7_23  1.0
    x_7         EDGE_7_9  1.0
    x_7         EDGE_7_89  1.0
    x_7         EDGE_7_79  1.0
    x_7         EDGE_7_83  1.0
    x_7         EDGE_7_46  1.0
    x_7         EDGE_7_41  1.0
    x_7         EDGE_7_50  1.0
    x_7         EDGE_7_59  1.0
    x_7         EDGE_7_36  1.0
    x_7         EDGE_7_45  1.0
    x_7         EDGE_7_13  1.0
    x_7         EDGE_7_22  1.0
    x_7         EDGE_7_49  1.0
    x_7         EDGE_7_8  1.0
    x_8         OBJ       -1
    x_8         EDGE_8_79  1.0
    x_8         EDGE_5_8  1.0
    x_8         EDGE_8_55  1.0
    x_8         EDGE_8_41  1.0
    x_8         EDGE_8_50  1.0
    x_8         EDGE_8_59  1.0
    x_8         EDGE_8_68  1.0
    x_8         EDGE_8_31  1.0
    x_8         EDGE_8_49  1.0
    x_8         EDGE_8_35  1.0
    x_8         EDGE_8_30  1.0
    x_8         EDGE_8_72  1.0
    x_8         EDGE_8_76  1.0
    x_8         EDGE_8_85  1.0
    x_8         EDGE_8_53  1.0
    x_8         EDGE_8_39  1.0
    x_8         EDGE_8_48  1.0
    x_8         EDGE_8_57  1.0
    x_8         EDGE_8_25  1.0
    x_8         EDGE_8_34  1.0
    x_8         EDGE_8_52  1.0
    x_8         EDGE_8_38  1.0
    x_8         EDGE_8_15  1.0
    x_8         EDGE_8_33  1.0
    x_8         EDGE_4_8  1.0
    x_8         EDGE_8_10  1.0
    x_8         EDGE_8_28  1.0
    x_8         EDGE_8_14  1.0
    x_8         EDGE_7_8  1.0
    x_9         OBJ       -1
    x_9         EDGE_9_49  1.0
    x_9         EDGE_9_76  1.0
    x_9         EDGE_9_71  1.0
    x_9         EDGE_9_48  1.0
    x_9         EDGE_9_11  1.0
    x_9         EDGE_9_10  1.0
    x_9         EDGE_9_89  1.0
    x_9         EDGE_9_75  1.0
    x_9         EDGE_9_84  1.0
    x_9         EDGE_9_70  1.0
    x_9         EDGE_4_9  1.0
    x_9         EDGE_9_56  1.0
    x_9         EDGE_9_74  1.0
    x_9         EDGE_9_83  1.0
    x_9         EDGE_7_9  1.0
    x_9         EDGE_9_37  1.0
    x_9         EDGE_9_32  1.0
    x_9         EDGE_9_45  1.0
    x_9         EDGE_9_31  1.0
    x_9         EDGE_2_9  1.0
    x_9         EDGE_9_12  1.0
    x_9         EDGE_9_87  1.0
    x_9         EDGE_9_82  1.0
    x_9         EDGE_9_68  1.0
    x_10        OBJ       -1
    x_10        EDGE_10_22  1.0
    x_10        EDGE_10_31  1.0
    x_10        EDGE_10_12  1.0
    x_10        EDGE_10_30  1.0
    x_10        EDGE_10_16  1.0
    x_10        EDGE_9_10  1.0
    x_10        EDGE_10_53  1.0
    x_10        EDGE_10_75  1.0
    x_10        EDGE_10_43  1.0
    x_10        EDGE_10_61  1.0
    x_10        EDGE_7_10  1.0
    x_10        EDGE_10_42  1.0
    x_10        EDGE_2_10  1.0
    x_10        EDGE_10_23  1.0
    x_10        EDGE_10_87  1.0
    x_10        EDGE_8_10  1.0
    x_10        EDGE_0_10  1.0
    x_10        EDGE_10_68  1.0
    x_10        EDGE_10_77  1.0
    x_11        OBJ       -1
    x_11        EDGE_11_14  1.0
    x_11        EDGE_11_89  1.0
    x_11        EDGE_11_79  1.0
    x_11        EDGE_11_88  1.0
    x_11        EDGE_9_11  1.0
    x_11        EDGE_11_83  1.0
    x_11        EDGE_11_69  1.0
    x_11        EDGE_11_55  1.0
    x_11        EDGE_11_32  1.0
    x_11        EDGE_11_41  1.0
    x_11        EDGE_11_59  1.0
    x_11        EDGE_11_45  1.0
    x_11        EDGE_11_54  1.0
    x_11        EDGE_11_13  1.0
    x_11        EDGE_11_49  1.0
    x_11        EDGE_11_12  1.0
    x_11        EDGE_11_21  1.0
    x_11        EDGE_11_30  1.0
    x_11        EDGE_11_86  1.0
    x_11        EDGE_11_63  1.0
    x_11        EDGE_11_58  1.0
    x_11        EDGE_11_53  1.0
    x_11        EDGE_11_39  1.0
    x_11        EDGE_11_34  1.0
    x_11        EDGE_11_29  1.0
    x_11        EDGE_11_38  1.0
    x_11        EDGE_11_15  1.0
    x_11        EDGE_11_24  1.0
    x_11        EDGE_11_42  1.0
    x_12        OBJ       -1
    x_12        EDGE_7_12  1.0
    x_12        EDGE_12_81  1.0
    x_12        EDGE_10_12  1.0
    x_12        EDGE_12_85  1.0
    x_12        EDGE_12_80  1.0
    x_12        EDGE_12_57  1.0
    x_12        EDGE_12_66  1.0
    x_12        EDGE_12_61  1.0
    x_12        EDGE_12_24  1.0
    x_12        EDGE_12_42  1.0
    x_12        EDGE_11_12  1.0
    x_12        EDGE_12_84  1.0
    x_12        EDGE_12_88  1.0
    x_12        EDGE_12_27  1.0
    x_12        EDGE_9_12  1.0
    x_12        EDGE_12_17  1.0
    x_12        EDGE_12_16  1.0
    x_13        OBJ       -1
    x_13        EDGE_13_65  1.0
    x_13        EDGE_13_51  1.0
    x_13        EDGE_13_69  1.0
    x_13        EDGE_13_78  1.0
    x_13        EDGE_13_32  1.0
    x_13        EDGE_13_36  1.0
    x_13        EDGE_13_63  1.0
    x_13        EDGE_13_22  1.0
    x_13        EDGE_13_31  1.0
    x_13        EDGE_13_44  1.0
    x_13        EDGE_11_13  1.0
    x_13        EDGE_13_81  1.0
    x_13        EDGE_13_89  1.0
    x_13        EDGE_13_34  1.0
    x_13        EDGE_13_52  1.0
    x_13        EDGE_13_61  1.0
    x_13        EDGE_13_47  1.0
    x_13        EDGE_13_28  1.0
    x_13        EDGE_7_13  1.0
    x_13        EDGE_13_70  1.0
    x_14        OBJ       -1
    x_14        EDGE_11_14  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_14_33  1.0
    x_14        EDGE_14_42  1.0
    x_14        EDGE_14_28  1.0
    x_14        EDGE_14_23  1.0
    x_14        EDGE_14_18  1.0
    x_14        EDGE_14_65  1.0
    x_14        EDGE_14_87  1.0
    x_14        EDGE_14_41  1.0
    x_14        EDGE_14_50  1.0
    x_14        EDGE_14_27  1.0
    x_14        EDGE_14_36  1.0
    x_14        EDGE_14_45  1.0
    x_14        EDGE_14_26  1.0
    x_14        EDGE_14_86  1.0
    x_14        EDGE_14_76  1.0
    x_14        EDGE_14_71  1.0
    x_14        EDGE_14_57  1.0
    x_14        EDGE_8_14  1.0
    x_14        EDGE_14_20  1.0
    x_14        EDGE_14_47  1.0
    x_15        OBJ       -1
    x_15        EDGE_15_30  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_48  1.0
    x_15        EDGE_15_34  1.0
    x_15        EDGE_15_43  1.0
    x_15        EDGE_4_15  1.0
    x_15        EDGE_15_38  1.0
    x_15        EDGE_15_24  1.0
    x_15        EDGE_15_65  1.0
    x_15        EDGE_15_74  1.0
    x_15        EDGE_15_69  1.0
    x_15        EDGE_15_46  1.0
    x_15        EDGE_15_55  1.0
    x_15        EDGE_15_82  1.0
    x_15        EDGE_15_59  1.0
    x_15        EDGE_15_68  1.0
    x_15        EDGE_15_77  1.0
    x_15        EDGE_8_15  1.0
    x_15        EDGE_15_40  1.0
    x_15        EDGE_15_49  1.0
    x_15        EDGE_11_15  1.0
    x_15        EDGE_15_44  1.0
    x_16        OBJ       -1
    x_16        EDGE_16_70  1.0
    x_16        EDGE_16_65  1.0
    x_16        EDGE_16_83  1.0
    x_16        EDGE_10_16  1.0
    x_16        EDGE_16_27  1.0
    x_16        EDGE_16_54  1.0
    x_16        EDGE_16_49  1.0
    x_16        EDGE_16_77  1.0
    x_16        EDGE_0_16  1.0
    x_16        EDGE_16_81  1.0
    x_16        EDGE_16_44  1.0
    x_16        EDGE_16_53  1.0
    x_16        EDGE_16_62  1.0
    x_16        EDGE_16_39  1.0
    x_16        EDGE_16_48  1.0
    x_16        EDGE_16_66  1.0
    x_16        EDGE_16_25  1.0
    x_16        EDGE_16_34  1.0
    x_16        EDGE_16_52  1.0
    x_16        EDGE_16_38  1.0
    x_16        EDGE_16_24  1.0
    x_16        EDGE_12_16  1.0
    x_16        EDGE_16_89  1.0
    x_17        OBJ       -1
    x_17        EDGE_7_17  1.0
    x_17        EDGE_17_67  1.0
    x_17        EDGE_17_43  1.0
    x_17        EDGE_17_61  1.0
    x_17        EDGE_2_17  1.0
    x_17        EDGE_17_20  1.0
    x_17        EDGE_17_38  1.0
    x_17        EDGE_17_33  1.0
    x_17        EDGE_17_79  1.0
    x_17        EDGE_17_88  1.0
    x_17        EDGE_17_65  1.0
    x_17        EDGE_17_74  1.0
    x_17        EDGE_17_51  1.0
    x_17        EDGE_17_78  1.0
    x_17        EDGE_17_46  1.0
    x_17        EDGE_17_55  1.0
    x_17        EDGE_17_68  1.0
    x_17        EDGE_17_18  1.0
    x_17        EDGE_17_40  1.0
    x_17        EDGE_17_49  1.0
    x_17        EDGE_17_30  1.0
    x_17        EDGE_12_17  1.0
    x_17        EDGE_4_17  1.0
    x_17        EDGE_17_63  1.0
    x_18        OBJ       -1
    x_18        EDGE_18_35  1.0
    x_18        EDGE_18_44  1.0
    x_18        EDGE_18_30  1.0
    x_18        EDGE_14_18  1.0
    x_18        EDGE_6_18  1.0
    x_18        EDGE_18_72  1.0
    x_18        EDGE_18_67  1.0
    x_18        EDGE_18_62  1.0
    x_18        EDGE_18_75  1.0
    x_18        EDGE_18_34  1.0
    x_18        EDGE_18_52  1.0
    x_18        EDGE_18_56  1.0
    x_18        EDGE_18_28  1.0
    x_18        EDGE_18_37  1.0
    x_18        EDGE_17_18  1.0
    x_18        EDGE_18_83  1.0
    x_18        EDGE_18_51  1.0
    x_18        EDGE_18_82  1.0
    x_18        EDGE_18_50  1.0
    x_18        EDGE_18_36  1.0
    x_18        EDGE_18_31  1.0
    x_19        OBJ       -1
    x_19        EDGE_3_19  1.0
    x_19        EDGE_19_60  1.0
    x_19        EDGE_19_78  1.0
    x_19        EDGE_19_55  1.0
    x_19        EDGE_19_64  1.0
    x_19        EDGE_19_73  1.0
    x_19        EDGE_19_45  1.0
    x_19        EDGE_19_31  1.0
    x_19        EDGE_19_26  1.0
    x_19        EDGE_19_35  1.0
    x_19        EDGE_19_76  1.0
    x_19        EDGE_19_53  1.0
    x_19        EDGE_19_71  1.0
    x_19        EDGE_19_89  1.0
    x_19        EDGE_19_48  1.0
    x_19        EDGE_19_20  1.0
    x_19        EDGE_19_29  1.0
    x_19        EDGE_19_47  1.0
    x_19        EDGE_19_28  1.0
    x_20        OBJ       -1
    x_20        EDGE_20_86  1.0
    x_20        EDGE_20_81  1.0
    x_20        EDGE_20_71  1.0
    x_20        EDGE_20_80  1.0
    x_20        EDGE_17_20  1.0
    x_20        EDGE_20_39  1.0
    x_20        EDGE_20_52  1.0
    x_20        EDGE_20_61  1.0
    x_20        EDGE_20_37  1.0
    x_20        EDGE_4_20  1.0
    x_20        EDGE_7_20  1.0
    x_20        EDGE_20_84  1.0
    x_20        EDGE_20_74  1.0
    x_20        EDGE_20_69  1.0
    x_20        EDGE_20_64  1.0
    x_20        EDGE_20_41  1.0
    x_20        EDGE_20_50  1.0
    x_20        EDGE_20_68  1.0
    x_20        EDGE_20_63  1.0
    x_20        EDGE_20_44  1.0
    x_20        EDGE_19_20  1.0
    x_20        EDGE_20_21  1.0
    x_20        EDGE_20_30  1.0
    x_20        EDGE_14_20  1.0
    x_21        OBJ       -1
    x_21        EDGE_21_40  1.0
    x_21        EDGE_21_77  1.0
    x_21        EDGE_21_72  1.0
    x_21        EDGE_21_76  1.0
    x_21        EDGE_21_85  1.0
    x_21        EDGE_11_21  1.0
    x_21        EDGE_21_62  1.0
    x_21        EDGE_21_48  1.0
    x_21        EDGE_21_66  1.0
    x_21        EDGE_21_75  1.0
    x_21        EDGE_21_29  1.0
    x_21        EDGE_21_47  1.0
    x_21        EDGE_21_28  1.0
    x_21        EDGE_21_23  1.0
    x_21        EDGE_1_21  1.0
    x_21        EDGE_20_21  1.0
    x_21        EDGE_21_70  1.0
    x_21        EDGE_21_88  1.0
    x_22        OBJ       -1
    x_22        EDGE_22_37  1.0
    x_22        EDGE_10_22  1.0
    x_22        EDGE_5_22  1.0
    x_22        EDGE_13_22  1.0
    x_22        EDGE_22_55  1.0
    x_22        EDGE_22_68  1.0
    x_22        EDGE_22_77  1.0
    x_22        EDGE_0_22  1.0
    x_22        EDGE_22_36  1.0
    x_22        EDGE_22_45  1.0
    x_22        EDGE_22_31  1.0
    x_22        EDGE_22_49  1.0
    x_22        EDGE_22_58  1.0
    x_22        EDGE_3_22  1.0
    x_22        EDGE_22_39  1.0
    x_22        EDGE_22_67  1.0
    x_22        EDGE_22_70  1.0
    x_22        EDGE_22_38  1.0
    x_22        EDGE_22_47  1.0
    x_22        EDGE_7_22  1.0
    x_22        EDGE_22_42  1.0
    x_22        EDGE_22_51  1.0
    x_23        OBJ       -1
    x_23        EDGE_14_23  1.0
    x_23        EDGE_23_85  1.0
    x_23        EDGE_23_48  1.0
    x_23        EDGE_23_66  1.0
    x_23        EDGE_23_29  1.0
    x_23        EDGE_7_23  1.0
    x_23        EDGE_23_70  1.0
    x_23        EDGE_23_79  1.0
    x_23        EDGE_10_23  1.0
    x_23        EDGE_23_46  1.0
    x_23        EDGE_21_23  1.0
    x_23        EDGE_23_32  1.0
    x_23        EDGE_23_27  1.0
    x_23        EDGE_23_40  1.0
    x_24        OBJ       -1
    x_24        EDGE_24_83  1.0
    x_24        EDGE_24_78  1.0
    x_24        EDGE_24_87  1.0
    x_24        EDGE_24_55  1.0
    x_24        EDGE_24_73  1.0
    x_24        EDGE_6_24  1.0
    x_24        EDGE_24_41  1.0
    x_24        EDGE_24_26  1.0
    x_24        EDGE_24_35  1.0
    x_24        EDGE_24_44  1.0
    x_24        EDGE_12_24  1.0
    x_24        EDGE_15_24  1.0
    x_24        EDGE_24_86  1.0
    x_24        EDGE_24_72  1.0
    x_24        EDGE_24_58  1.0
    x_24        EDGE_24_76  1.0
    x_24        EDGE_24_53  1.0
    x_24        EDGE_24_71  1.0
    x_24        EDGE_2_24  1.0
    x_24        EDGE_24_39  1.0
    x_24        EDGE_24_75  1.0
    x_24        EDGE_16_24  1.0
    x_24        EDGE_11_24  1.0
    x_25        OBJ       -1
    x_25        EDGE_25_34  1.0
    x_25        EDGE_25_47  1.0
    x_25        EDGE_25_28  1.0
    x_25        EDGE_25_83  1.0
    x_25        EDGE_7_25  1.0
    x_25        EDGE_25_60  1.0
    x_25        EDGE_25_78  1.0
    x_25        EDGE_25_59  1.0
    x_25        EDGE_2_25  1.0
    x_25        EDGE_25_45  1.0
    x_25        EDGE_25_35  1.0
    x_25        EDGE_16_25  1.0
    x_25        EDGE_8_25  1.0
    x_25        EDGE_25_77  1.0
    x_25        EDGE_25_81  1.0
    x_25        EDGE_25_58  1.0
    x_25        EDGE_25_67  1.0
    x_25        EDGE_25_85  1.0
    x_25        EDGE_25_44  1.0
    x_25        EDGE_25_62  1.0
    x_25        EDGE_25_71  1.0
    x_25        EDGE_25_30  1.0
    x_25        EDGE_25_39  1.0
    x_25        EDGE_25_48  1.0
    x_26        OBJ       -1
    x_26        EDGE_26_30  1.0
    x_26        EDGE_26_81  1.0
    x_26        EDGE_24_26  1.0
    x_26        EDGE_26_48  1.0
    x_26        EDGE_26_38  1.0
    x_26        EDGE_26_56  1.0
    x_26        EDGE_19_26  1.0
    x_26        EDGE_26_33  1.0
    x_26        EDGE_0_26  1.0
    x_26        EDGE_14_26  1.0
    x_26        EDGE_6_26  1.0
    x_26        EDGE_26_69  1.0
    x_26        EDGE_1_26  1.0
    x_26        EDGE_26_82  1.0
    x_26        EDGE_26_50  1.0
    x_26        EDGE_26_59  1.0
    x_26        EDGE_26_77  1.0
    x_26        EDGE_26_36  1.0
    x_27        OBJ       -1
    x_27        EDGE_27_88  1.0
    x_27        EDGE_27_73  1.0
    x_27        EDGE_16_27  1.0
    x_27        EDGE_27_41  1.0
    x_27        EDGE_27_59  1.0
    x_27        EDGE_27_36  1.0
    x_27        EDGE_27_58  1.0
    x_27        EDGE_14_27  1.0
    x_27        EDGE_27_67  1.0
    x_27        EDGE_27_71  1.0
    x_27        EDGE_27_66  1.0
    x_27        EDGE_27_70  1.0
    x_27        EDGE_12_27  1.0
    x_27        EDGE_23_27  1.0
    x_27        EDGE_27_47  1.0
    x_27        EDGE_27_56  1.0
    x_27        EDGE_27_42  1.0
    x_27        EDGE_27_46  1.0
    x_28        OBJ       -1
    x_28        EDGE_14_28  1.0
    x_28        EDGE_28_48  1.0
    x_28        EDGE_28_75  1.0
    x_28        EDGE_28_43  1.0
    x_28        EDGE_28_61  1.0
    x_28        EDGE_25_28  1.0
    x_28        EDGE_28_38  1.0
    x_28        EDGE_28_47  1.0
    x_28        EDGE_28_33  1.0
    x_28        EDGE_28_88  1.0
    x_28        EDGE_28_51  1.0
    x_28        EDGE_7_28  1.0
    x_28        EDGE_18_28  1.0
    x_28        EDGE_28_60  1.0
    x_28        EDGE_28_87  1.0
    x_28        EDGE_28_73  1.0
    x_28        EDGE_28_68  1.0
    x_28        EDGE_28_36  1.0
    x_28        EDGE_28_45  1.0
    x_28        EDGE_28_49  1.0
    x_28        EDGE_21_28  1.0
    x_28        EDGE_5_28  1.0
    x_28        EDGE_28_30  1.0
    x_28        EDGE_13_28  1.0
    x_28        EDGE_8_28  1.0
    x_28        EDGE_19_28  1.0
    x_28        EDGE_28_72  1.0
    x_28        EDGE_28_81  1.0
    x_29        OBJ       -1
    x_29        EDGE_29_32  1.0
    x_29        EDGE_29_45  1.0
    x_29        EDGE_1_29  1.0
    x_29        EDGE_23_29  1.0
    x_29        EDGE_29_77  1.0
    x_29        EDGE_4_29  1.0
    x_29        EDGE_7_29  1.0
    x_29        EDGE_29_62  1.0
    x_29        EDGE_29_80  1.0
    x_29        EDGE_29_39  1.0
    x_29        EDGE_29_34  1.0
    x_29        EDGE_29_70  1.0
    x_29        EDGE_29_56  1.0
    x_29        EDGE_2_29  1.0
    x_29        EDGE_21_29  1.0
    x_29        EDGE_29_42  1.0
    x_29        EDGE_29_84  1.0
    x_29        EDGE_19_29  1.0
    x_29        EDGE_29_79  1.0
    x_29        EDGE_29_88  1.0
    x_29        EDGE_11_29  1.0
    x_29        EDGE_29_65  1.0
    x_30        OBJ       -1
    x_30        EDGE_15_30  1.0
    x_30        EDGE_26_30  1.0
    x_30        EDGE_18_30  1.0
    x_30        EDGE_30_79  1.0
    x_30        EDGE_10_30  1.0
    x_30        EDGE_30_65  1.0
    x_30        EDGE_30_74  1.0
    x_30        EDGE_30_87  1.0
    x_30        EDGE_30_46  1.0
    x_30        EDGE_30_55  1.0
    x_30        EDGE_30_64  1.0
    x_30        EDGE_4_30  1.0
    x_30        EDGE_30_36  1.0
    x_30        EDGE_30_35  1.0
    x_30        EDGE_30_44  1.0
    x_30        EDGE_8_30  1.0
    x_30        EDGE_11_30  1.0
    x_30        EDGE_30_67  1.0
    x_30        EDGE_30_80  1.0
    x_30        EDGE_17_30  1.0
    x_30        EDGE_28_30  1.0
    x_30        EDGE_30_48  1.0
    x_30        EDGE_30_66  1.0
    x_30        EDGE_30_43  1.0
    x_30        EDGE_30_56  1.0
    x_30        EDGE_20_30  1.0
    x_30        EDGE_30_37  1.0
    x_30        EDGE_25_30  1.0
    x_31        OBJ       -1
    x_31        EDGE_31_86  1.0
    x_31        EDGE_10_31  1.0
    x_31        EDGE_31_48  1.0
    x_31        EDGE_31_57  1.0
    x_31        EDGE_5_31  1.0
    x_31        EDGE_31_70  1.0
    x_31        EDGE_13_31  1.0
    x_31        EDGE_31_56  1.0
    x_31        EDGE_8_31  1.0
    x_31        EDGE_19_31  1.0
    x_31        EDGE_22_31  1.0
    x_31        EDGE_31_74  1.0
    x_31        EDGE_31_83  1.0
    x_31        EDGE_31_60  1.0
    x_31        EDGE_31_55  1.0
    x_31        EDGE_31_73  1.0
    x_31        EDGE_31_50  1.0
    x_31        EDGE_31_77  1.0
    x_31        EDGE_9_31  1.0
    x_31        EDGE_31_36  1.0
    x_31        EDGE_31_40  1.0
    x_31        EDGE_18_31  1.0
    x_32        OBJ       -1
    x_32        EDGE_29_32  1.0
    x_32        EDGE_32_60  1.0
    x_32        EDGE_32_64  1.0
    x_32        EDGE_32_68  1.0
    x_32        EDGE_32_77  1.0
    x_32        EDGE_13_32  1.0
    x_32        EDGE_32_49  1.0
    x_32        EDGE_32_58  1.0
    x_32        EDGE_11_32  1.0
    x_32        EDGE_1_32  1.0
    x_32        EDGE_3_32  1.0
    x_32        EDGE_32_81  1.0
    x_32        EDGE_32_80  1.0
    x_32        EDGE_32_89  1.0
    x_32        EDGE_32_34  1.0
    x_32        EDGE_9_32  1.0
    x_32        EDGE_23_32  1.0
    x_32        EDGE_32_37  1.0
    x_33        OBJ       -1
    x_33        EDGE_33_47  1.0
    x_33        EDGE_14_33  1.0
    x_33        EDGE_6_33  1.0
    x_33        EDGE_17_33  1.0
    x_33        EDGE_28_33  1.0
    x_33        EDGE_33_88  1.0
    x_33        EDGE_33_65  1.0
    x_33        EDGE_33_83  1.0
    x_33        EDGE_33_51  1.0
    x_33        EDGE_33_60  1.0
    x_33        EDGE_4_33  1.0
    x_33        EDGE_33_87  1.0
    x_33        EDGE_33_64  1.0
    x_33        EDGE_26_33  1.0
    x_33        EDGE_33_44  1.0
    x_33        EDGE_33_81  1.0
    x_33        EDGE_8_33  1.0
    x_33        EDGE_33_71  1.0
    x_33        EDGE_33_48  1.0
    x_34        OBJ       -1
    x_34        EDGE_25_34  1.0
    x_34        EDGE_34_53  1.0
    x_34        EDGE_34_75  1.0
    x_34        EDGE_15_34  1.0
    x_34        EDGE_18_34  1.0
    x_34        EDGE_34_38  1.0
    x_34        EDGE_34_56  1.0
    x_34        EDGE_29_34  1.0
    x_34        EDGE_32_34  1.0
    x_34        EDGE_5_34  1.0
    x_34        EDGE_13_34  1.0
    x_34        EDGE_16_34  1.0
    x_34        EDGE_34_83  1.0
    x_34        EDGE_34_69  1.0
    x_34        EDGE_34_78  1.0
    x_34        EDGE_8_34  1.0
    x_34        EDGE_11_34  1.0
    x_34        EDGE_34_68  1.0
    x_34        EDGE_34_45  1.0
    x_34        EDGE_34_40  1.0
    x_35        OBJ       -1
    x_35        EDGE_18_35  1.0
    x_35        EDGE_35_87  1.0
    x_35        EDGE_35_46  1.0
    x_35        EDGE_35_64  1.0
    x_35        EDGE_35_73  1.0
    x_35        EDGE_35_40  1.0
    x_35        EDGE_24_35  1.0
    x_35        EDGE_35_44  1.0
    x_35        EDGE_8_35  1.0
    x_35        EDGE_19_35  1.0
    x_35        EDGE_30_35  1.0
    x_35        EDGE_35_86  1.0
    x_35        EDGE_35_67  1.0
    x_35        EDGE_25_35  1.0
    x_35        EDGE_35_39  1.0
    x_35        EDGE_35_48  1.0
    x_35        EDGE_35_57  1.0
    x_35        EDGE_35_43  1.0
    x_36        OBJ       -1
    x_36        EDGE_36_80  1.0
    x_36        EDGE_36_48  1.0
    x_36        EDGE_36_75  1.0
    x_36        EDGE_36_84  1.0
    x_36        EDGE_2_36  1.0
    x_36        EDGE_36_56  1.0
    x_36        EDGE_36_65  1.0
    x_36        EDGE_5_36  1.0
    x_36        EDGE_13_36  1.0
    x_36        EDGE_27_36  1.0
    x_36        EDGE_30_36  1.0
    x_36        EDGE_22_36  1.0
    x_36        EDGE_14_36  1.0
    x_36        EDGE_36_82  1.0
    x_36        EDGE_36_50  1.0
    x_36        EDGE_36_77  1.0
    x_36        EDGE_6_36  1.0
    x_36        EDGE_36_40  1.0
    x_36        EDGE_28_36  1.0
    x_36        EDGE_36_49  1.0
    x_36        EDGE_31_36  1.0
    x_36        EDGE_26_36  1.0
    x_36        EDGE_36_86  1.0
    x_36        EDGE_7_36  1.0
    x_36        EDGE_18_36  1.0
    x_36        EDGE_36_76  1.0
    x_37        OBJ       -1
    x_37        EDGE_22_37  1.0
    x_37        EDGE_37_82  1.0
    x_37        EDGE_37_86  1.0
    x_37        EDGE_37_72  1.0
    x_37        EDGE_37_67  1.0
    x_37        EDGE_37_85  1.0
    x_37        EDGE_20_37  1.0
    x_37        EDGE_37_75  1.0
    x_37        EDGE_18_37  1.0
    x_37        EDGE_9_37  1.0
    x_37        EDGE_4_37  1.0
    x_37        EDGE_32_37  1.0
    x_37        EDGE_37_51  1.0
    x_37        EDGE_37_87  1.0
    x_37        EDGE_37_46  1.0
    x_37        EDGE_37_59  1.0
    x_37        EDGE_30_37  1.0
    x_37        EDGE_37_54  1.0
    x_38        OBJ       -1
    x_38        EDGE_6_38  1.0
    x_38        EDGE_17_38  1.0
    x_38        EDGE_28_38  1.0
    x_38        EDGE_38_70  1.0
    x_38        EDGE_38_65  1.0
    x_38        EDGE_38_51  1.0
    x_38        EDGE_38_73  1.0
    x_38        EDGE_38_68  1.0
    x_38        EDGE_15_38  1.0
    x_38        EDGE_26_38  1.0
    x_38        EDGE_38_40  1.0
    x_38        EDGE_38_49  1.0
    x_38        EDGE_34_38  1.0
    x_38        EDGE_2_38  1.0
    x_38        EDGE_16_38  1.0
    x_38        EDGE_38_52  1.0
    x_38        EDGE_8_38  1.0
    x_38        EDGE_38_47  1.0
    x_38        EDGE_0_38  1.0
    x_38        EDGE_11_38  1.0
    x_38        EDGE_22_38  1.0
    x_39        OBJ       -1
    x_39        EDGE_39_81  1.0
    x_39        EDGE_39_76  1.0
    x_39        EDGE_39_85  1.0
    x_39        EDGE_39_48  1.0
    x_39        EDGE_20_39  1.0
    x_39        EDGE_39_60  1.0
    x_39        EDGE_39_46  1.0
    x_39        EDGE_29_39  1.0
    x_39        EDGE_39_88  1.0
    x_39        EDGE_22_39  1.0
    x_39        EDGE_24_39  1.0
    x_39        EDGE_35_39  1.0
    x_39        EDGE_16_39  1.0
    x_39        EDGE_6_39  1.0
    x_39        EDGE_39_54  1.0
    x_39        EDGE_39_63  1.0
    x_39        EDGE_39_58  1.0
    x_39        EDGE_8_39  1.0
    x_39        EDGE_0_39  1.0
    x_39        EDGE_11_39  1.0
    x_39        EDGE_1_39  1.0
    x_39        EDGE_25_39  1.0
    x_40        OBJ       -1
    x_40        EDGE_40_41  1.0
    x_40        EDGE_40_54  1.0
    x_40        EDGE_40_49  1.0
    x_40        EDGE_21_40  1.0
    x_40        EDGE_35_40  1.0
    x_40        EDGE_40_72  1.0
    x_40        EDGE_38_40  1.0
    x_40        EDGE_0_40  1.0
    x_40        EDGE_40_85  1.0
    x_40        EDGE_3_40  1.0
    x_40        EDGE_40_43  1.0
    x_40        EDGE_40_61  1.0
    x_40        EDGE_40_42  1.0
    x_40        EDGE_36_40  1.0
    x_40        EDGE_17_40  1.0
    x_40        EDGE_1_40  1.0
    x_40        EDGE_31_40  1.0
    x_40        EDGE_23_40  1.0
    x_40        EDGE_40_88  1.0
    x_40        EDGE_40_83  1.0
    x_40        EDGE_15_40  1.0
    x_40        EDGE_40_78  1.0
    x_40        EDGE_34_40  1.0
    x_41        OBJ       -1
    x_41        EDGE_40_41  1.0
    x_41        EDGE_41_42  1.0
    x_41        EDGE_24_41  1.0
    x_41        EDGE_27_41  1.0
    x_41        EDGE_8_41  1.0
    x_41        EDGE_41_74  1.0
    x_41        EDGE_11_41  1.0
    x_41        EDGE_41_64  1.0
    x_41        EDGE_41_82  1.0
    x_41        EDGE_14_41  1.0
    x_41        EDGE_41_63  1.0
    x_41        EDGE_20_41  1.0
    x_41        EDGE_41_72  1.0
    x_41        EDGE_41_76  1.0
    x_41        EDGE_41_62  1.0
    x_41        EDGE_41_80  1.0
    x_41        EDGE_41_89  1.0
    x_41        EDGE_7_41  1.0
    x_42        OBJ       -1
    x_42        EDGE_41_42  1.0
    x_42        EDGE_3_42  1.0
    x_42        EDGE_14_42  1.0
    x_42        EDGE_42_77  1.0
    x_42        EDGE_42_58  1.0
    x_42        EDGE_42_44  1.0
    x_42        EDGE_42_80  1.0
    x_42        EDGE_42_75  1.0
    x_42        EDGE_42_61  1.0
    x_42        EDGE_42_56  1.0
    x_42        EDGE_12_42  1.0
    x_42        EDGE_42_78  1.0
    x_42        EDGE_10_42  1.0
    x_42        EDGE_29_42  1.0
    x_42        EDGE_40_42  1.0
    x_42        EDGE_42_88  1.0
    x_42        EDGE_42_83  1.0
    x_42        EDGE_42_69  1.0
    x_42        EDGE_42_55  1.0
    x_42        EDGE_42_64  1.0
    x_42        EDGE_42_73  1.0
    x_42        EDGE_42_45  1.0
    x_42        EDGE_27_42  1.0
    x_42        EDGE_11_42  1.0
    x_42        EDGE_22_42  1.0
    x_43        OBJ       -1
    x_43        EDGE_43_78  1.0
    x_43        EDGE_43_55  1.0
    x_43        EDGE_43_73  1.0
    x_43        EDGE_43_50  1.0
    x_43        EDGE_43_68  1.0
    x_43        EDGE_17_43  1.0
    x_43        EDGE_28_43  1.0
    x_43        EDGE_43_54  1.0
    x_43        EDGE_43_72  1.0
    x_43        EDGE_43_49  1.0
    x_43        EDGE_43_44  1.0
    x_43        EDGE_15_43  1.0
    x_43        EDGE_10_43  1.0
    x_43        EDGE_40_43  1.0
    x_43        EDGE_43_80  1.0
    x_43        EDGE_43_61  1.0
    x_43        EDGE_35_43  1.0
    x_43        EDGE_30_43  1.0
    x_43        EDGE_3_43  1.0
    x_44        OBJ       -1
    x_44        EDGE_18_44  1.0
    x_44        EDGE_44_56  1.0
    x_44        EDGE_42_44  1.0
    x_44        EDGE_43_44  1.0
    x_44        EDGE_5_44  1.0
    x_44        EDGE_44_84  1.0
    x_44        EDGE_13_44  1.0
    x_44        EDGE_24_44  1.0
    x_44        EDGE_35_44  1.0
    x_44        EDGE_44_69  1.0
    x_44        EDGE_30_44  1.0
    x_44        EDGE_44_64  1.0
    x_44        EDGE_44_82  1.0
    x_44        EDGE_44_68  1.0
    x_44        EDGE_44_63  1.0
    x_44        EDGE_33_44  1.0
    x_44        EDGE_16_44  1.0
    x_44        EDGE_44_86  1.0
    x_44        EDGE_20_44  1.0
    x_44        EDGE_44_72  1.0
    x_44        EDGE_44_76  1.0
    x_44        EDGE_44_85  1.0
    x_44        EDGE_25_44  1.0
    x_44        EDGE_44_75  1.0
    x_44        EDGE_15_44  1.0
    x_44        EDGE_44_52  1.0
    x_44        EDGE_44_70  1.0
    x_45        OBJ       -1
    x_45        EDGE_29_45  1.0
    x_45        EDGE_5_45  1.0
    x_45        EDGE_45_67  1.0
    x_45        EDGE_45_85  1.0
    x_45        EDGE_45_80  1.0
    x_45        EDGE_19_45  1.0
    x_45        EDGE_45_66  1.0
    x_45        EDGE_11_45  1.0
    x_45        EDGE_22_45  1.0
    x_45        EDGE_45_47  1.0
    x_45        EDGE_45_51  1.0
    x_45        EDGE_3_45  1.0
    x_45        EDGE_14_45  1.0
    x_45        EDGE_25_45  1.0
    x_45        EDGE_6_45  1.0
    x_45        EDGE_28_45  1.0
    x_45        EDGE_9_45  1.0
    x_45        EDGE_45_65  1.0
    x_45        EDGE_42_45  1.0
    x_45        EDGE_45_64  1.0
    x_45        EDGE_45_50  1.0
    x_45        EDGE_34_45  1.0
    x_45        EDGE_45_54  1.0
    x_45        EDGE_7_45  1.0
    x_46        OBJ       -1
    x_46        EDGE_35_46  1.0
    x_46        EDGE_46_79  1.0
    x_46        EDGE_46_88  1.0
    x_46        EDGE_46_60  1.0
    x_46        EDGE_46_69  1.0
    x_46        EDGE_46_87  1.0
    x_46        EDGE_30_46  1.0
    x_46        EDGE_46_68  1.0
    x_46        EDGE_39_46  1.0
    x_46        EDGE_3_46  1.0
    x_46        EDGE_17_46  1.0
    x_46        EDGE_46_76  1.0
    x_46        EDGE_23_46  1.0
    x_46        EDGE_46_71  1.0
    x_46        EDGE_46_48  1.0
    x_46        EDGE_46_57  1.0
    x_46        EDGE_15_46  1.0
    x_46        EDGE_46_47  1.0
    x_46        EDGE_7_46  1.0
    x_46        EDGE_37_46  1.0
    x_46        EDGE_46_51  1.0
    x_46        EDGE_27_46  1.0
    x_47        OBJ       -1
    x_47        EDGE_33_47  1.0
    x_47        EDGE_25_47  1.0
    x_47        EDGE_47_56  1.0
    x_47        EDGE_47_51  1.0
    x_47        EDGE_28_47  1.0
    x_47        EDGE_3_47  1.0
    x_47        EDGE_45_47  1.0
    x_47        EDGE_7_47  1.0
    x_47        EDGE_47_60  1.0
    x_47        EDGE_47_73  1.0
    x_47        EDGE_47_59  1.0
    x_47        EDGE_21_47  1.0
    x_47        EDGE_47_49  1.0
    x_47        EDGE_13_47  1.0
    x_47        EDGE_27_47  1.0
    x_47        EDGE_46_47  1.0
    x_47        EDGE_19_47  1.0
    x_47        EDGE_38_47  1.0
    x_47        EDGE_47_81  1.0
    x_47        EDGE_22_47  1.0
    x_47        EDGE_14_47  1.0
    x_48        OBJ       -1
    x_48        EDGE_36_48  1.0
    x_48        EDGE_48_58  1.0
    x_48        EDGE_28_48  1.0
    x_48        EDGE_48_53  1.0
    x_48        EDGE_9_48  1.0
    x_48        EDGE_39_48  1.0
    x_48        EDGE_31_48  1.0
    x_48        EDGE_23_48  1.0
    x_48        EDGE_48_86  1.0
    x_48        EDGE_15_48  1.0
    x_48        EDGE_26_48  1.0
    x_48        EDGE_7_48  1.0
    x_48        EDGE_48_75  1.0
    x_48        EDGE_21_48  1.0
    x_48        EDGE_48_65  1.0
    x_48        EDGE_48_51  1.0
    x_48        EDGE_35_48  1.0
    x_48        EDGE_16_48  1.0
    x_48        EDGE_46_48  1.0
    x_48        EDGE_8_48  1.0
    x_48        EDGE_19_48  1.0
    x_48        EDGE_30_48  1.0
    x_48        EDGE_48_60  1.0
    x_48        EDGE_48_87  1.0
    x_48        EDGE_33_48  1.0
    x_48        EDGE_48_68  1.0
    x_48        EDGE_25_48  1.0
    x_49        OBJ       -1
    x_49        EDGE_9_49  1.0
    x_49        EDGE_40_49  1.0
    x_49        EDGE_49_84  1.0
    x_49        EDGE_49_79  1.0
    x_49        EDGE_32_49  1.0
    x_49        EDGE_43_49  1.0
    x_49        EDGE_49_65  1.0
    x_49        EDGE_49_78  1.0
    x_49        EDGE_49_87  1.0
    x_49        EDGE_16_49  1.0
    x_49        EDGE_49_55  1.0
    x_49        EDGE_49_64  1.0
    x_49        EDGE_49_82  1.0
    x_49        EDGE_49_50  1.0
    x_49        EDGE_49_68  1.0
    x_49        EDGE_8_49  1.0
    x_49        EDGE_38_49  1.0
    x_49        EDGE_11_49  1.0
    x_49        EDGE_22_49  1.0
    x_49        EDGE_3_49  1.0
    x_49        EDGE_36_49  1.0
    x_49        EDGE_47_49  1.0
    x_49        EDGE_17_49  1.0
    x_49        EDGE_28_49  1.0
    x_49        EDGE_49_70  1.0
    x_49        EDGE_15_49  1.0
    x_49        EDGE_7_49  1.0
    x_50        OBJ       -1
    x_50        EDGE_50_86  1.0
    x_50        EDGE_50_72  1.0
    x_50        EDGE_50_81  1.0
    x_50        EDGE_43_50  1.0
    x_50        EDGE_50_58  1.0
    x_50        EDGE_50_53  1.0
    x_50        EDGE_50_66  1.0
    x_50        EDGE_50_75  1.0
    x_50        EDGE_50_61  1.0
    x_50        EDGE_50_56  1.0
    x_50        EDGE_8_50  1.0
    x_50        EDGE_49_50  1.0
    x_50        EDGE_3_50  1.0
    x_50        EDGE_14_50  1.0
    x_50        EDGE_36_50  1.0
    x_50        EDGE_50_60  1.0
    x_50        EDGE_50_82  1.0
    x_50        EDGE_20_50  1.0
    x_50        EDGE_31_50  1.0
    x_50        EDGE_26_50  1.0
    x_50        EDGE_45_50  1.0
    x_50        EDGE_7_50  1.0
    x_50        EDGE_18_50  1.0
    x_51        OBJ       -1
    x_51        EDGE_51_68  1.0
    x_51        EDGE_13_51  1.0
    x_51        EDGE_51_86  1.0
    x_51        EDGE_51_72  1.0
    x_51        EDGE_47_51  1.0
    x_51        EDGE_51_53  1.0
    x_51        EDGE_38_51  1.0
    x_51        EDGE_33_51  1.0
    x_51        EDGE_45_51  1.0
    x_51        EDGE_17_51  1.0
    x_51        EDGE_28_51  1.0
    x_51        EDGE_51_75  1.0
    x_51        EDGE_48_51  1.0
    x_51        EDGE_51_52  1.0
    x_51        EDGE_18_51  1.0
    x_51        EDGE_37_51  1.0
    x_51        EDGE_46_51  1.0
    x_51        EDGE_51_88  1.0
    x_51        EDGE_2_51  1.0
    x_51        EDGE_22_51  1.0
    x_52        OBJ       -1
    x_52        EDGE_20_52  1.0
    x_52        EDGE_4_52  1.0
    x_52        EDGE_52_69  1.0
    x_52        EDGE_52_73  1.0
    x_52        EDGE_18_52  1.0
    x_52        EDGE_52_59  1.0
    x_52        EDGE_51_52  1.0
    x_52        EDGE_13_52  1.0
    x_52        EDGE_16_52  1.0
    x_52        EDGE_8_52  1.0
    x_52        EDGE_38_52  1.0
    x_52        EDGE_52_53  1.0
    x_52        EDGE_52_71  1.0
    x_52        EDGE_3_52  1.0
    x_52        EDGE_44_52  1.0
    x_53        OBJ       -1
    x_53        EDGE_48_53  1.0
    x_53        EDGE_53_86  1.0
    x_53        EDGE_50_53  1.0
    x_53        EDGE_51_53  1.0
    x_53        EDGE_53_81  1.0
    x_53        EDGE_4_53  1.0
    x_53        EDGE_53_67  1.0
    x_53        EDGE_53_71  1.0
    x_53        EDGE_53_89  1.0
    x_53        EDGE_34_53  1.0
    x_53        EDGE_53_66  1.0
    x_53        EDGE_53_84  1.0
    x_53        EDGE_7_53  1.0
    x_53        EDGE_53_70  1.0
    x_53        EDGE_53_56  1.0
    x_53        EDGE_10_53  1.0
    x_53        EDGE_24_53  1.0
    x_53        EDGE_16_53  1.0
    x_53        EDGE_53_88  1.0
    x_53        EDGE_8_53  1.0
    x_53        EDGE_19_53  1.0
    x_53        EDGE_53_69  1.0
    x_53        EDGE_53_78  1.0
    x_53        EDGE_11_53  1.0
    x_53        EDGE_53_77  1.0
    x_53        EDGE_52_53  1.0
    x_53        EDGE_53_54  1.0
    x_53        EDGE_53_63  1.0
    x_53        EDGE_53_58  1.0
    x_54        OBJ       -1
    x_54        EDGE_40_54  1.0
    x_54        EDGE_2_54  1.0
    x_54        EDGE_54_87  1.0
    x_54        EDGE_54_82  1.0
    x_54        EDGE_43_54  1.0
    x_54        EDGE_5_54  1.0
    x_54        EDGE_16_54  1.0
    x_54        EDGE_11_54  1.0
    x_54        EDGE_54_85  1.0
    x_54        EDGE_54_62  1.0
    x_54        EDGE_39_54  1.0
    x_54        EDGE_1_54  1.0
    x_54        EDGE_54_56  1.0
    x_54        EDGE_53_54  1.0
    x_54        EDGE_45_54  1.0
    x_54        EDGE_37_54  1.0
    x_55        OBJ       -1
    x_55        EDGE_55_79  1.0
    x_55        EDGE_43_55  1.0
    x_55        EDGE_55_65  1.0
    x_55        EDGE_24_55  1.0
    x_55        EDGE_55_60  1.0
    x_55        EDGE_8_55  1.0
    x_55        EDGE_19_55  1.0
    x_55        EDGE_30_55  1.0
    x_55        EDGE_49_55  1.0
    x_55        EDGE_11_55  1.0
    x_55        EDGE_22_55  1.0
    x_55        EDGE_55_83  1.0
    x_55        EDGE_55_87  1.0
    x_55        EDGE_55_64  1.0
    x_55        EDGE_55_82  1.0
    x_55        EDGE_55_86  1.0
    x_55        EDGE_17_55  1.0
    x_55        EDGE_31_55  1.0
    x_55        EDGE_42_55  1.0
    x_55        EDGE_15_55  1.0
    x_55        EDGE_55_76  1.0
    x_55        EDGE_55_85  1.0
    x_56        OBJ       -1
    x_56        EDGE_44_56  1.0
    x_56        EDGE_36_56  1.0
    x_56        EDGE_47_56  1.0
    x_56        EDGE_0_56  1.0
    x_56        EDGE_31_56  1.0
    x_56        EDGE_56_67  1.0
    x_56        EDGE_56_76  1.0
    x_56        EDGE_50_56  1.0
    x_56        EDGE_42_56  1.0
    x_56        EDGE_56_57  1.0
    x_56        EDGE_53_56  1.0
    x_56        EDGE_56_61  1.0
    x_56        EDGE_26_56  1.0
    x_56        EDGE_34_56  1.0
    x_56        EDGE_18_56  1.0
    x_56        EDGE_9_56  1.0
    x_56        EDGE_29_56  1.0
    x_56        EDGE_5_56  1.0
    x_56        EDGE_56_79  1.0
    x_56        EDGE_56_88  1.0
    x_56        EDGE_54_56  1.0
    x_56        EDGE_56_83  1.0
    x_56        EDGE_27_56  1.0
    x_56        EDGE_30_56  1.0
    x_57        OBJ       -1
    x_57        EDGE_57_83  1.0
    x_57        EDGE_31_57  1.0
    x_57        EDGE_57_87  1.0
    x_57        EDGE_12_57  1.0
    x_57        EDGE_57_73  1.0
    x_57        EDGE_57_82  1.0
    x_57        EDGE_57_63  1.0
    x_57        EDGE_56_57  1.0
    x_57        EDGE_35_57  1.0
    x_57        EDGE_57_67  1.0
    x_57        EDGE_57_62  1.0
    x_57        EDGE_46_57  1.0
    x_57        EDGE_57_66  1.0
    x_57        EDGE_8_57  1.0
    x_57        EDGE_14_57  1.0
    x_58        OBJ       -1
    x_58        EDGE_48_58  1.0
    x_58        EDGE_50_58  1.0
    x_58        EDGE_42_58  1.0
    x_58        EDGE_4_58  1.0
    x_58        EDGE_32_58  1.0
    x_58        EDGE_27_58  1.0
    x_58        EDGE_22_58  1.0
    x_58        EDGE_58_88  1.0
    x_58        EDGE_24_58  1.0
    x_58        EDGE_58_87  1.0
    x_58        EDGE_6_58  1.0
    x_58        EDGE_58_73  1.0
    x_58        EDGE_58_68  1.0
    x_58        EDGE_11_58  1.0
    x_58        EDGE_39_58  1.0
    x_58        EDGE_1_58  1.0
    x_58        EDGE_25_58  1.0
    x_58        EDGE_53_58  1.0
    x_59        OBJ       -1
    x_59        EDGE_2_59  1.0
    x_59        EDGE_59_68  1.0
    x_59        EDGE_27_59  1.0
    x_59        EDGE_8_59  1.0
    x_59        EDGE_11_59  1.0
    x_59        EDGE_59_77  1.0
    x_59        EDGE_52_59  1.0
    x_59        EDGE_3_59  1.0
    x_59        EDGE_59_76  1.0
    x_59        EDGE_59_71  1.0
    x_59        EDGE_59_80  1.0
    x_59        EDGE_25_59  1.0
    x_59        EDGE_6_59  1.0
    x_59        EDGE_47_59  1.0
    x_59        EDGE_59_61  1.0
    x_59        EDGE_59_70  1.0
    x_59        EDGE_4_59  1.0
    x_59        EDGE_15_59  1.0
    x_59        EDGE_26_59  1.0
    x_59        EDGE_7_59  1.0
    x_59        EDGE_37_59  1.0
    x_59        EDGE_59_65  1.0
    x_59        EDGE_59_83  1.0
    x_59        EDGE_59_60  1.0
    x_60        OBJ       -1
    x_60        EDGE_32_60  1.0
    x_60        EDGE_55_60  1.0
    x_60        EDGE_46_60  1.0
    x_60        EDGE_19_60  1.0
    x_60        EDGE_39_60  1.0
    x_60        EDGE_60_78  1.0
    x_60        EDGE_60_87  1.0
    x_60        EDGE_60_77  1.0
    x_60        EDGE_33_60  1.0
    x_60        EDGE_60_86  1.0
    x_60        EDGE_60_72  1.0
    x_60        EDGE_25_60  1.0
    x_60        EDGE_6_60  1.0
    x_60        EDGE_47_60  1.0
    x_60        EDGE_28_60  1.0
    x_60        EDGE_1_60  1.0
    x_60        EDGE_31_60  1.0
    x_60        EDGE_50_60  1.0
    x_60        EDGE_60_85  1.0
    x_60        EDGE_60_80  1.0
    x_60        EDGE_48_60  1.0
    x_60        EDGE_60_61  1.0
    x_60        EDGE_60_70  1.0
    x_60        EDGE_60_65  1.0
    x_60        EDGE_59_60  1.0
    x_61        OBJ       -1
    x_61        EDGE_61_86  1.0
    x_61        EDGE_6_61  1.0
    x_61        EDGE_61_81  1.0
    x_61        EDGE_17_61  1.0
    x_61        EDGE_28_61  1.0
    x_61        EDGE_61_85  1.0
    x_61        EDGE_61_89  1.0
    x_61        EDGE_1_61  1.0
    x_61        EDGE_20_61  1.0
    x_61        EDGE_50_61  1.0
    x_61        EDGE_61_70  1.0
    x_61        EDGE_12_61  1.0
    x_61        EDGE_42_61  1.0
    x_61        EDGE_4_61  1.0
    x_61        EDGE_56_61  1.0
    x_61        EDGE_10_61  1.0
    x_61        EDGE_40_61  1.0
    x_61        EDGE_59_61  1.0
    x_61        EDGE_61_79  1.0
    x_61        EDGE_61_88  1.0
    x_61        EDGE_61_74  1.0
    x_61        EDGE_61_83  1.0
    x_61        EDGE_43_61  1.0
    x_61        EDGE_13_61  1.0
    x_61        EDGE_60_61  1.0
    x_62        OBJ       -1
    x_62        EDGE_62_64  1.0
    x_62        EDGE_62_77  1.0
    x_62        EDGE_62_63  1.0
    x_62        EDGE_18_62  1.0
    x_62        EDGE_29_62  1.0
    x_62        EDGE_2_62  1.0
    x_62        EDGE_21_62  1.0
    x_62        EDGE_62_66  1.0
    x_62        EDGE_54_62  1.0
    x_62        EDGE_62_75  1.0
    x_62        EDGE_62_84  1.0
    x_62        EDGE_16_62  1.0
    x_62        EDGE_57_62  1.0
    x_62        EDGE_0_62  1.0
    x_62        EDGE_41_62  1.0
    x_62        EDGE_25_62  1.0
    x_62        EDGE_6_62  1.0
    x_63        OBJ       -1
    x_63        EDGE_62_63  1.0
    x_63        EDGE_13_63  1.0
    x_63        EDGE_7_63  1.0
    x_63        EDGE_57_63  1.0
    x_63        EDGE_63_70  1.0
    x_63        EDGE_63_79  1.0
    x_63        EDGE_63_69  1.0
    x_63        EDGE_63_78  1.0
    x_63        EDGE_63_87  1.0
    x_63        EDGE_63_73  1.0
    x_63        EDGE_63_82  1.0
    x_63        EDGE_41_63  1.0
    x_63        EDGE_3_63  1.0
    x_63        EDGE_44_63  1.0
    x_63        EDGE_11_63  1.0
    x_63        EDGE_39_63  1.0
    x_63        EDGE_20_63  1.0
    x_63        EDGE_63_77  1.0
    x_63        EDGE_53_63  1.0
    x_63        EDGE_63_67  1.0
    x_63        EDGE_17_63  1.0
    x_64        OBJ       -1
    x_64        EDGE_32_64  1.0
    x_64        EDGE_62_64  1.0
    x_64        EDGE_35_64  1.0
    x_64        EDGE_64_81  1.0
    x_64        EDGE_64_67  1.0
    x_64        EDGE_19_64  1.0
    x_64        EDGE_30_64  1.0
    x_64        EDGE_49_64  1.0
    x_64        EDGE_41_64  1.0
    x_64        EDGE_33_64  1.0
    x_64        EDGE_44_64  1.0
    x_64        EDGE_55_64  1.0
    x_64        EDGE_1_64  1.0
    x_64        EDGE_20_64  1.0
    x_64        EDGE_64_74  1.0
    x_64        EDGE_42_64  1.0
    x_64        EDGE_45_64  1.0
    x_64        EDGE_64_86  1.0
    x_65        OBJ       -1
    x_65        EDGE_5_65  1.0
    x_65        EDGE_13_65  1.0
    x_65        EDGE_16_65  1.0
    x_65        EDGE_55_65  1.0
    x_65        EDGE_65_83  1.0
    x_65        EDGE_36_65  1.0
    x_65        EDGE_65_78  1.0
    x_65        EDGE_65_87  1.0
    x_65        EDGE_30_65  1.0
    x_65        EDGE_38_65  1.0
    x_65        EDGE_49_65  1.0
    x_65        EDGE_65_77  1.0
    x_65        EDGE_65_86  1.0
    x_65        EDGE_14_65  1.0
    x_65        EDGE_33_65  1.0
    x_65        EDGE_17_65  1.0
    x_65        EDGE_48_65  1.0
    x_65        EDGE_65_76  1.0
    x_65        EDGE_65_85  1.0
    x_65        EDGE_65_80  1.0
    x_65        EDGE_65_89  1.0
    x_65        EDGE_65_84  1.0
    x_65        EDGE_15_65  1.0
    x_65        EDGE_45_65  1.0
    x_65        EDGE_65_70  1.0
    x_65        EDGE_65_79  1.0
    x_65        EDGE_29_65  1.0
    x_65        EDGE_59_65  1.0
    x_65        EDGE_60_65  1.0
    x_66        OBJ       -1
    x_66        EDGE_66_70  1.0
    x_66        EDGE_50_66  1.0
    x_66        EDGE_12_66  1.0
    x_66        EDGE_23_66  1.0
    x_66        EDGE_66_85  1.0
    x_66        EDGE_53_66  1.0
    x_66        EDGE_45_66  1.0
    x_66        EDGE_7_66  1.0
    x_66        EDGE_66_69  1.0
    x_66        EDGE_21_66  1.0
    x_66        EDGE_66_82  1.0
    x_66        EDGE_62_66  1.0
    x_66        EDGE_16_66  1.0
    x_66        EDGE_27_66  1.0
    x_66        EDGE_57_66  1.0
    x_66        EDGE_30_66  1.0
    x_66        EDGE_0_66  1.0
    x_66        EDGE_3_66  1.0
    x_66        EDGE_66_81  1.0
    x_66        EDGE_66_67  1.0
    x_66        EDGE_66_76  1.0
    x_67        OBJ       -1
    x_67        EDGE_17_67  1.0
    x_67        EDGE_53_67  1.0
    x_67        EDGE_64_67  1.0
    x_67        EDGE_45_67  1.0
    x_67        EDGE_56_67  1.0
    x_67        EDGE_18_67  1.0
    x_67        EDGE_37_67  1.0
    x_67        EDGE_67_80  1.0
    x_67        EDGE_5_67  1.0
    x_67        EDGE_35_67  1.0
    x_67        EDGE_27_67  1.0
    x_67        EDGE_57_67  1.0
    x_67        EDGE_30_67  1.0
    x_67        EDGE_22_67  1.0
    x_67        EDGE_63_67  1.0
    x_67        EDGE_25_67  1.0
    x_67        EDGE_66_67  1.0
    x_68        OBJ       -1
    x_68        EDGE_59_68  1.0
    x_68        EDGE_51_68  1.0
    x_68        EDGE_32_68  1.0
    x_68        EDGE_43_68  1.0
    x_68        EDGE_5_68  1.0
    x_68        EDGE_68_69  1.0
    x_68        EDGE_68_78  1.0
    x_68        EDGE_46_68  1.0
    x_68        EDGE_8_68  1.0
    x_68        EDGE_38_68  1.0
    x_68        EDGE_49_68  1.0
    x_68        EDGE_22_68  1.0
    x_68        EDGE_44_68  1.0
    x_68        EDGE_17_68  1.0
    x_68        EDGE_28_68  1.0
    x_68        EDGE_58_68  1.0
    x_68        EDGE_20_68  1.0
    x_68        EDGE_68_71  1.0
    x_68        EDGE_68_70  1.0
    x_68        EDGE_15_68  1.0
    x_68        EDGE_34_68  1.0
    x_68        EDGE_9_68  1.0
    x_68        EDGE_48_68  1.0
    x_68        EDGE_10_68  1.0
    x_69        OBJ       -1
    x_69        EDGE_69_81  1.0
    x_69        EDGE_13_69  1.0
    x_69        EDGE_69_80  1.0
    x_69        EDGE_46_69  1.0
    x_69        EDGE_68_69  1.0
    x_69        EDGE_0_69  1.0
    x_69        EDGE_11_69  1.0
    x_69        EDGE_52_69  1.0
    x_69        EDGE_44_69  1.0
    x_69        EDGE_63_69  1.0
    x_69        EDGE_66_69  1.0
    x_69        EDGE_20_69  1.0
    x_69        EDGE_69_77  1.0
    x_69        EDGE_69_86  1.0
    x_69        EDGE_42_69  1.0
    x_69        EDGE_53_69  1.0
    x_69        EDGE_15_69  1.0
    x_69        EDGE_26_69  1.0
    x_69        EDGE_34_69  1.0
    x_69        EDGE_2_69  1.0
    x_70        OBJ       -1
    x_70        EDGE_70_73  1.0
    x_70        EDGE_16_70  1.0
    x_70        EDGE_66_70  1.0
    x_70        EDGE_38_70  1.0
    x_70        EDGE_1_70  1.0
    x_70        EDGE_31_70  1.0
    x_70        EDGE_61_70  1.0
    x_70        EDGE_3_70  1.0
    x_70        EDGE_63_70  1.0
    x_70        EDGE_53_70  1.0
    x_70        EDGE_70_72  1.0
    x_70        EDGE_70_71  1.0
    x_70        EDGE_9_70  1.0
    x_70        EDGE_29_70  1.0
    x_70        EDGE_59_70  1.0
    x_70        EDGE_23_70  1.0
    x_70        EDGE_4_70  1.0
    x_70        EDGE_65_70  1.0
    x_70        EDGE_27_70  1.0
    x_70        EDGE_68_70  1.0
    x_70        EDGE_49_70  1.0
    x_70        EDGE_2_70  1.0
    x_70        EDGE_70_79  1.0
    x_70        EDGE_21_70  1.0
    x_70        EDGE_60_70  1.0
    x_70        EDGE_22_70  1.0
    x_70        EDGE_44_70  1.0
    x_70        EDGE_13_70  1.0
    x_71        OBJ       -1
    x_71        EDGE_9_71  1.0
    x_71        EDGE_20_71  1.0
    x_71        EDGE_4_71  1.0
    x_71        EDGE_53_71  1.0
    x_71        EDGE_7_71  1.0
    x_71        EDGE_71_74  1.0
    x_71        EDGE_71_87  1.0
    x_71        EDGE_71_73  1.0
    x_71        EDGE_71_82  1.0
    x_71        EDGE_2_71  1.0
    x_71        EDGE_59_71  1.0
    x_71        EDGE_70_71  1.0
    x_71        EDGE_5_71  1.0
    x_71        EDGE_24_71  1.0
    x_71        EDGE_27_71  1.0
    x_71        EDGE_46_71  1.0
    x_71        EDGE_68_71  1.0
    x_71        EDGE_19_71  1.0
    x_71        EDGE_71_86  1.0
    x_71        EDGE_52_71  1.0
    x_71        EDGE_3_71  1.0
    x_71        EDGE_14_71  1.0
    x_71        EDGE_71_89  1.0
    x_71        EDGE_33_71  1.0
    x_71        EDGE_25_71  1.0
    x_72        OBJ       -1
    x_72        EDGE_50_72  1.0
    x_72        EDGE_51_72  1.0
    x_72        EDGE_43_72  1.0
    x_72        EDGE_72_85  1.0
    x_72        EDGE_18_72  1.0
    x_72        EDGE_37_72  1.0
    x_72        EDGE_40_72  1.0
    x_72        EDGE_2_72  1.0
    x_72        EDGE_70_72  1.0
    x_72        EDGE_21_72  1.0
    x_72        EDGE_60_72  1.0
    x_72        EDGE_5_72  1.0
    x_72        EDGE_24_72  1.0
    x_72        EDGE_8_72  1.0
    x_72        EDGE_0_72  1.0
    x_72        EDGE_72_82  1.0
    x_72        EDGE_41_72  1.0
    x_72        EDGE_72_86  1.0
    x_72        EDGE_3_72  1.0
    x_72        EDGE_44_72  1.0
    x_72        EDGE_6_72  1.0
    x_72        EDGE_28_72  1.0
    x_73        OBJ       -1
    x_73        EDGE_70_73  1.0
    x_73        EDGE_43_73  1.0
    x_73        EDGE_24_73  1.0
    x_73        EDGE_35_73  1.0
    x_73        EDGE_73_77  1.0
    x_73        EDGE_27_73  1.0
    x_73        EDGE_57_73  1.0
    x_73        EDGE_19_73  1.0
    x_73        EDGE_38_73  1.0
    x_73        EDGE_52_73  1.0
    x_73        EDGE_71_73  1.0
    x_73        EDGE_63_73  1.0
    x_73        EDGE_73_86  1.0
    x_73        EDGE_47_73  1.0
    x_73        EDGE_28_73  1.0
    x_73        EDGE_73_89  1.0
    x_73        EDGE_58_73  1.0
    x_73        EDGE_31_73  1.0
    x_73        EDGE_42_73  1.0
    x_73        EDGE_2_73  1.0
    x_74        OBJ       -1
    x_74        EDGE_30_74  1.0
    x_74        EDGE_41_74  1.0
    x_74        EDGE_71_74  1.0
    x_74        EDGE_74_78  1.0
    x_74        EDGE_74_87  1.0
    x_74        EDGE_17_74  1.0
    x_74        EDGE_9_74  1.0
    x_74        EDGE_20_74  1.0
    x_74        EDGE_31_74  1.0
    x_74        EDGE_61_74  1.0
    x_74        EDGE_64_74  1.0
    x_74        EDGE_15_74  1.0
    x_74        EDGE_74_76  1.0
    x_75        OBJ       -1
    x_75        EDGE_36_75  1.0
    x_75        EDGE_28_75  1.0
    x_75        EDGE_1_75  1.0
    x_75        EDGE_50_75  1.0
    x_75        EDGE_42_75  1.0
    x_75        EDGE_75_85  1.0
    x_75        EDGE_75_80  1.0
    x_75        EDGE_34_75  1.0
    x_75        EDGE_18_75  1.0
    x_75        EDGE_37_75  1.0
    x_75        EDGE_9_75  1.0
    x_75        EDGE_48_75  1.0
    x_75        EDGE_10_75  1.0
    x_75        EDGE_21_75  1.0
    x_75        EDGE_51_75  1.0
    x_75        EDGE_62_75  1.0
    x_75        EDGE_24_75  1.0
    x_75        EDGE_75_79  1.0
    x_75        EDGE_75_78  1.0
    x_75        EDGE_75_87  1.0
    x_75        EDGE_75_82  1.0
    x_75        EDGE_44_75  1.0
    x_76        OBJ       -1
    x_76        EDGE_9_76  1.0
    x_76        EDGE_39_76  1.0
    x_76        EDGE_1_76  1.0
    x_76        EDGE_76_77  1.0
    x_76        EDGE_56_76  1.0
    x_76        EDGE_2_76  1.0
    x_76        EDGE_59_76  1.0
    x_76        EDGE_21_76  1.0
    x_76        EDGE_24_76  1.0
    x_76        EDGE_65_76  1.0
    x_76        EDGE_76_85  1.0
    x_76        EDGE_46_76  1.0
    x_76        EDGE_8_76  1.0
    x_76        EDGE_19_76  1.0
    x_76        EDGE_0_76  1.0
    x_76        EDGE_41_76  1.0
    x_76        EDGE_14_76  1.0
    x_76        EDGE_44_76  1.0
    x_76        EDGE_55_76  1.0
    x_76        EDGE_74_76  1.0
    x_76        EDGE_36_76  1.0
    x_76        EDGE_66_76  1.0
    x_77        OBJ       -1
    x_77        EDGE_77_80  1.0
    x_77        EDGE_77_89  1.0
    x_77        EDGE_42_77  1.0
    x_77        EDGE_4_77  1.0
    x_77        EDGE_32_77  1.0
    x_77        EDGE_62_77  1.0
    x_77        EDGE_73_77  1.0
    x_77        EDGE_77_79  1.0
    x_77        EDGE_65_77  1.0
    x_77        EDGE_76_77  1.0
    x_77        EDGE_29_77  1.0
    x_77        EDGE_59_77  1.0
    x_77        EDGE_21_77  1.0
    x_77        EDGE_60_77  1.0
    x_77        EDGE_22_77  1.0
    x_77        EDGE_16_77  1.0
    x_77        EDGE_36_77  1.0
    x_77        EDGE_77_87  1.0
    x_77        EDGE_69_77  1.0
    x_77        EDGE_31_77  1.0
    x_77        EDGE_63_77  1.0
    x_77        EDGE_25_77  1.0
    x_77        EDGE_53_77  1.0
    x_77        EDGE_15_77  1.0
    x_77        EDGE_26_77  1.0
    x_77        EDGE_10_77  1.0
    x_78        OBJ       -1
    x_78        EDGE_43_78  1.0
    x_78        EDGE_5_78  1.0
    x_78        EDGE_13_78  1.0
    x_78        EDGE_24_78  1.0
    x_78        EDGE_65_78  1.0
    x_78        EDGE_68_78  1.0
    x_78        EDGE_19_78  1.0
    x_78        EDGE_49_78  1.0
    x_78        EDGE_0_78  1.0
    x_78        EDGE_60_78  1.0
    x_78        EDGE_63_78  1.0
    x_78        EDGE_25_78  1.0
    x_78        EDGE_74_78  1.0
    x_78        EDGE_42_78  1.0
    x_78        EDGE_17_78  1.0
    x_78        EDGE_1_78  1.0
    x_78        EDGE_53_78  1.0
    x_78        EDGE_34_78  1.0
    x_78        EDGE_75_78  1.0
    x_78        EDGE_40_78  1.0
    x_79        OBJ       -1
    x_79        EDGE_55_79  1.0
    x_79        EDGE_46_79  1.0
    x_79        EDGE_8_79  1.0
    x_79        EDGE_30_79  1.0
    x_79        EDGE_49_79  1.0
    x_79        EDGE_77_79  1.0
    x_79        EDGE_11_79  1.0
    x_79        EDGE_79_87  1.0
    x_79        EDGE_63_79  1.0
    x_79        EDGE_6_79  1.0
    x_79        EDGE_17_79  1.0
    x_79        EDGE_61_79  1.0
    x_79        EDGE_23_79  1.0
    x_79        EDGE_56_79  1.0
    x_79        EDGE_7_79  1.0
    x_79        EDGE_75_79  1.0
    x_79        EDGE_65_79  1.0
    x_79        EDGE_79_81  1.0
    x_79        EDGE_79_80  1.0
    x_79        EDGE_79_89  1.0
    x_79        EDGE_29_79  1.0
    x_79        EDGE_70_79  1.0
    x_79        EDGE_79_84  1.0
    x_80        OBJ       -1
    x_80        EDGE_36_80  1.0
    x_80        EDGE_77_80  1.0
    x_80        EDGE_69_80  1.0
    x_80        EDGE_20_80  1.0
    x_80        EDGE_12_80  1.0
    x_80        EDGE_42_80  1.0
    x_80        EDGE_45_80  1.0
    x_80        EDGE_75_80  1.0
    x_80        EDGE_67_80  1.0
    x_80        EDGE_29_80  1.0
    x_80        EDGE_59_80  1.0
    x_80        EDGE_32_80  1.0
    x_80        EDGE_43_80  1.0
    x_80        EDGE_5_80  1.0
    x_80        EDGE_65_80  1.0
    x_80        EDGE_30_80  1.0
    x_80        EDGE_60_80  1.0
    x_80        EDGE_79_80  1.0
    x_80        EDGE_41_80  1.0
    x_80        EDGE_3_80  1.0
    x_80        EDGE_6_80  1.0
    x_81        OBJ       -1
    x_81        EDGE_39_81  1.0
    x_81        EDGE_1_81  1.0
    x_81        EDGE_69_81  1.0
    x_81        EDGE_20_81  1.0
    x_81        EDGE_50_81  1.0
    x_81        EDGE_61_81  1.0
    x_81        EDGE_12_81  1.0
    x_81        EDGE_4_81  1.0
    x_81        EDGE_53_81  1.0
    x_81        EDGE_64_81  1.0
    x_81        EDGE_26_81  1.0
    x_81        EDGE_32_81  1.0
    x_81        EDGE_13_81  1.0
    x_81        EDGE_16_81  1.0
    x_81        EDGE_79_81  1.0
    x_81        EDGE_33_81  1.0
    x_81        EDGE_25_81  1.0
    x_81        EDGE_6_81  1.0
    x_81        EDGE_47_81  1.0
    x_81        EDGE_66_81  1.0
    x_81        EDGE_28_81  1.0
    x_82        OBJ       -1
    x_82        EDGE_54_82  1.0
    x_82        EDGE_37_82  1.0
    x_82        EDGE_57_82  1.0
    x_82        EDGE_49_82  1.0
    x_82        EDGE_82_83  1.0
    x_82        EDGE_41_82  1.0
    x_82        EDGE_71_82  1.0
    x_82        EDGE_44_82  1.0
    x_82        EDGE_63_82  1.0
    x_82        EDGE_55_82  1.0
    x_82        EDGE_36_82  1.0
    x_82        EDGE_66_82  1.0
    x_82        EDGE_50_82  1.0
    x_82        EDGE_72_82  1.0
    x_82        EDGE_15_82  1.0
    x_82        EDGE_26_82  1.0
    x_82        EDGE_18_82  1.0
    x_82        EDGE_75_82  1.0
    x_82        EDGE_9_82  1.0
    x_83        OBJ       -1
    x_83        EDGE_5_83  1.0
    x_83        EDGE_24_83  1.0
    x_83        EDGE_16_83  1.0
    x_83        EDGE_65_83  1.0
    x_83        EDGE_57_83  1.0
    x_83        EDGE_83_86  1.0
    x_83        EDGE_11_83  1.0
    x_83        EDGE_82_83  1.0
    x_83        EDGE_33_83  1.0
    x_83        EDGE_25_83  1.0
    x_83        EDGE_55_83  1.0
    x_83        EDGE_6_83  1.0
    x_83        EDGE_9_83  1.0
    x_83        EDGE_31_83  1.0
    x_83        EDGE_61_83  1.0
    x_83        EDGE_42_83  1.0
    x_83        EDGE_83_88  1.0
    x_83        EDGE_34_83  1.0
    x_83        EDGE_56_83  1.0
    x_83        EDGE_7_83  1.0
    x_83        EDGE_18_83  1.0
    x_83        EDGE_40_83  1.0
    x_83        EDGE_59_83  1.0
    x_84        OBJ       -1
    x_84        EDGE_36_84  1.0
    x_84        EDGE_49_84  1.0
    x_84        EDGE_44_84  1.0
    x_84        EDGE_53_84  1.0
    x_84        EDGE_9_84  1.0
    x_84        EDGE_20_84  1.0
    x_84        EDGE_12_84  1.0
    x_84        EDGE_62_84  1.0
    x_84        EDGE_65_84  1.0
    x_84        EDGE_29_84  1.0
    x_84        EDGE_2_84  1.0
    x_84        EDGE_79_84  1.0
    x_85        OBJ       -1
    x_85        EDGE_39_85  1.0
    x_85        EDGE_61_85  1.0
    x_85        EDGE_12_85  1.0
    x_85        EDGE_23_85  1.0
    x_85        EDGE_72_85  1.0
    x_85        EDGE_66_85  1.0
    x_85        EDGE_45_85  1.0
    x_85        EDGE_75_85  1.0
    x_85        EDGE_37_85  1.0
    x_85        EDGE_40_85  1.0
    x_85        EDGE_21_85  1.0
    x_85        EDGE_85_86  1.0
    x_85        EDGE_54_85  1.0
    x_85        EDGE_65_85  1.0
    x_85        EDGE_76_85  1.0
    x_85        EDGE_8_85  1.0
    x_85        EDGE_60_85  1.0
    x_85        EDGE_3_85  1.0
    x_85        EDGE_44_85  1.0
    x_85        EDGE_25_85  1.0
    x_85        EDGE_55_85  1.0
    x_85        EDGE_6_85  1.0
    x_86        OBJ       -1
    x_86        EDGE_20_86  1.0
    x_86        EDGE_31_86  1.0
    x_86        EDGE_50_86  1.0
    x_86        EDGE_61_86  1.0
    x_86        EDGE_51_86  1.0
    x_86        EDGE_4_86  1.0
    x_86        EDGE_53_86  1.0
    x_86        EDGE_83_86  1.0
    x_86        EDGE_37_86  1.0
    x_86        EDGE_65_86  1.0
    x_86        EDGE_48_86  1.0
    x_86        EDGE_2_86  1.0
    x_86        EDGE_60_86  1.0
    x_86        EDGE_5_86  1.0
    x_86        EDGE_73_86  1.0
    x_86        EDGE_24_86  1.0
    x_86        EDGE_35_86  1.0
    x_86        EDGE_55_86  1.0
    x_86        EDGE_85_86  1.0
    x_86        EDGE_0_86  1.0
    x_86        EDGE_11_86  1.0
    x_86        EDGE_69_86  1.0
    x_86        EDGE_14_86  1.0
    x_86        EDGE_71_86  1.0
    x_86        EDGE_44_86  1.0
    x_86        EDGE_72_86  1.0
    x_86        EDGE_64_86  1.0
    x_86        EDGE_6_86  1.0
    x_86        EDGE_36_86  1.0
    x_87        OBJ       -1
    x_87        EDGE_24_87  1.0
    x_87        EDGE_35_87  1.0
    x_87        EDGE_54_87  1.0
    x_87        EDGE_87_88  1.0
    x_87        EDGE_65_87  1.0
    x_87        EDGE_46_87  1.0
    x_87        EDGE_57_87  1.0
    x_87        EDGE_30_87  1.0
    x_87        EDGE_49_87  1.0
    x_87        EDGE_60_87  1.0
    x_87        EDGE_79_87  1.0
    x_87        EDGE_14_87  1.0
    x_87        EDGE_71_87  1.0
    x_87        EDGE_33_87  1.0
    x_87        EDGE_63_87  1.0
    x_87        EDGE_55_87  1.0
    x_87        EDGE_6_87  1.0
    x_87        EDGE_74_87  1.0
    x_87        EDGE_28_87  1.0
    x_87        EDGE_77_87  1.0
    x_87        EDGE_1_87  1.0
    x_87        EDGE_58_87  1.0
    x_87        EDGE_75_87  1.0
    x_87        EDGE_37_87  1.0
    x_87        EDGE_9_87  1.0
    x_87        EDGE_48_87  1.0
    x_87        EDGE_10_87  1.0
    x_88        OBJ       -1
    x_88        EDGE_27_88  1.0
    x_88        EDGE_46_88  1.0
    x_88        EDGE_87_88  1.0
    x_88        EDGE_88_89  1.0
    x_88        EDGE_0_88  1.0
    x_88        EDGE_11_88  1.0
    x_88        EDGE_33_88  1.0
    x_88        EDGE_17_88  1.0
    x_88        EDGE_28_88  1.0
    x_88        EDGE_39_88  1.0
    x_88        EDGE_58_88  1.0
    x_88        EDGE_61_88  1.0
    x_88        EDGE_12_88  1.0
    x_88        EDGE_42_88  1.0
    x_88        EDGE_53_88  1.0
    x_88        EDGE_83_88  1.0
    x_88        EDGE_56_88  1.0
    x_88        EDGE_29_88  1.0
    x_88        EDGE_40_88  1.0
    x_88        EDGE_21_88  1.0
    x_88        EDGE_51_88  1.0
    x_89        OBJ       -1
    x_89        EDGE_77_89  1.0
    x_89        EDGE_0_89  1.0
    x_89        EDGE_11_89  1.0
    x_89        EDGE_88_89  1.0
    x_89        EDGE_61_89  1.0
    x_89        EDGE_53_89  1.0
    x_89        EDGE_9_89  1.0
    x_89        EDGE_4_89  1.0
    x_89        EDGE_32_89  1.0
    x_89        EDGE_73_89  1.0
    x_89        EDGE_13_89  1.0
    x_89        EDGE_7_89  1.0
    x_89        EDGE_65_89  1.0
    x_89        EDGE_19_89  1.0
    x_89        EDGE_79_89  1.0
    x_89        EDGE_41_89  1.0
    x_89        EDGE_71_89  1.0
    x_89        EDGE_16_89  1.0
    x_89        EDGE_6_89  1.0
RHS
    RHS1      EDGE_7_17  1.0
    RHS1      EDGE_15_30  1.0
    RHS1      EDGE_26_30  1.0
    RHS1      EDGE_18_35  1.0
    RHS1      EDGE_70_73  1.0
    RHS1      EDGE_5_65  1.0
    RHS1      EDGE_17_67  1.0
    RHS1      EDGE_18_44  1.0
    RHS1      EDGE_29_32  1.0
    RHS1      EDGE_36_80  1.0
    RHS1      EDGE_40_41  1.0
    RHS1      EDGE_5_83  1.0
    RHS1      EDGE_11_14  1.0
    RHS1      EDGE_41_42  1.0
    RHS1      EDGE_25_34  1.0
    RHS1      EDGE_33_47  1.0
    RHS1      EDGE_39_81  1.0
    RHS1      EDGE_44_56  1.0
    RHS1      EDGE_20_86  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_31_86  1.0
    RHS1      EDGE_2_59  1.0
    RHS1      EDGE_32_60  1.0
    RHS1      EDGE_22_37  1.0
    RHS1      EDGE_14_33  1.0
    RHS1      EDGE_13_65  1.0
    RHS1      EDGE_3_42  1.0
    RHS1      EDGE_14_42  1.0
    RHS1      EDGE_43_78  1.0
    RHS1      EDGE_16_70  1.0
    RHS1      EDGE_1_81  1.0
    RHS1      EDGE_7_12  1.0
    RHS1      EDGE_24_83  1.0
    RHS1      EDGE_36_48  1.0
    RHS1      EDGE_18_30  1.0
    RHS1      EDGE_9_49  1.0
    RHS1      EDGE_55_79  1.0
    RHS1      EDGE_59_68  1.0
    RHS1      EDGE_36_75  1.0
    RHS1      EDGE_36_84  1.0
    RHS1      EDGE_5_78  1.0
    RHS1      EDGE_29_45  1.0
    RHS1      EDGE_69_81  1.0
    RHS1      EDGE_9_76  1.0
    RHS1      EDGE_48_58  1.0
    RHS1      EDGE_40_54  1.0
    RHS1      EDGE_50_86  1.0
    RHS1      EDGE_61_86  1.0
    RHS1      EDGE_6_61  1.0
    RHS1      EDGE_10_22  1.0
    RHS1      EDGE_10_31  1.0
    RHS1      EDGE_39_76  1.0
    RHS1      EDGE_2_36  1.0
    RHS1      EDGE_39_85  1.0
    RHS1      EDGE_20_81  1.0
    RHS1      EDGE_25_47  1.0
    RHS1      EDGE_2_54  1.0
    RHS1      EDGE_3_19  1.0
    RHS1      EDGE_43_55  1.0
    RHS1      EDGE_51_68  1.0
    RHS1      EDGE_13_51  1.0
    RHS1      EDGE_14_28  1.0
    RHS1      EDGE_32_64  1.0
    RHS1      EDGE_43_73  1.0
    RHS1      EDGE_51_86  1.0
    RHS1      EDGE_13_69  1.0
    RHS1      EDGE_16_65  1.0
    RHS1      EDGE_1_76  1.0
    RHS1      EDGE_13_78  1.0
    RHS1      EDGE_24_78  1.0
    RHS1      EDGE_24_87  1.0
    RHS1      EDGE_35_87  1.0
    RHS1      EDGE_16_83  1.0
    RHS1      EDGE_28_48  1.0
    RHS1      EDGE_55_65  1.0
    RHS1      EDGE_77_80  1.0
    RHS1      EDGE_28_75  1.0
    RHS1      EDGE_6_38  1.0
    RHS1      EDGE_9_71  1.0
    RHS1      EDGE_48_53  1.0
    RHS1      EDGE_50_72  1.0
    RHS1      EDGE_40_49  1.0
    RHS1      EDGE_77_89  1.0
    RHS1      EDGE_50_81  1.0
    RHS1      EDGE_61_81  1.0
    RHS1      EDGE_42_77  1.0
    RHS1      EDGE_27_88  1.0
    RHS1      EDGE_62_64  1.0
    RHS1      EDGE_0_89  1.0
    RHS1      EDGE_11_89  1.0
    RHS1      EDGE_3_5  1.0
    RHS1      EDGE_54_87  1.0
    RHS1      EDGE_43_50  1.0
    RHS1      EDGE_12_81  1.0
    RHS1      EDGE_35_46  1.0
    RHS1      EDGE_4_77  1.0
    RHS1      EDGE_14_23  1.0
    RHS1      EDGE_51_72  1.0
    RHS1      EDGE_24_55  1.0
    RHS1      EDGE_4_86  1.0
    RHS1      EDGE_32_68  1.0
    RHS1      EDGE_43_68  1.0
    RHS1      EDGE_35_64  1.0
    RHS1      EDGE_66_70  1.0
    RHS1      EDGE_32_77  1.0
    RHS1      EDGE_24_73  1.0
    RHS1      EDGE_35_73  1.0
    RHS1      EDGE_65_83  1.0
    RHS1      EDGE_55_60  1.0
    RHS1      EDGE_17_43  1.0
    RHS1      EDGE_28_43  1.0
    RHS1      EDGE_36_56  1.0
    RHS1      EDGE_46_79  1.0
    RHS1      EDGE_47_56  1.0
    RHS1      EDGE_46_88  1.0
    RHS1      EDGE_36_65  1.0
    RHS1      EDGE_9_48  1.0
    RHS1      EDGE_49_84  1.0
    RHS1      EDGE_17_61  1.0
    RHS1      EDGE_6_24  1.0
    RHS1      EDGE_28_61  1.0
    RHS1      EDGE_50_58  1.0
    RHS1      EDGE_5_68  1.0
    RHS1      EDGE_6_33  1.0
    RHS1      EDGE_69_80  1.0
    RHS1      EDGE_21_40  1.0
    RHS1      EDGE_61_85  1.0
    RHS1      EDGE_10_12  1.0
    RHS1      EDGE_39_48  1.0
    RHS1      EDGE_8_79  1.0
    RHS1      EDGE_30_79  1.0
    RHS1      EDGE_2_17  1.0
    RHS1      EDGE_10_30  1.0
    RHS1      EDGE_25_28  1.0
    RHS1      EDGE_62_77  1.0
    RHS1      EDGE_73_77  1.0
    RHS1      EDGE_20_71  1.0
    RHS1      EDGE_13_32  1.0
    RHS1      EDGE_20_80  1.0
    RHS1      EDGE_54_82  1.0
    RHS1      EDGE_24_41  1.0
    RHS1      EDGE_14_18  1.0
    RHS1      EDGE_43_54  1.0
    RHS1      EDGE_12_85  1.0
    RHS1      EDGE_23_85  1.0
    RHS1      EDGE_53_86  1.0
    RHS1      EDGE_4_81  1.0
    RHS1      EDGE_87_88  1.0
    RHS1      EDGE_43_72  1.0
    RHS1      EDGE_17_20  1.0
    RHS1      EDGE_1_75  1.0
    RHS1      EDGE_65_78  1.0
    RHS1      EDGE_5_36  1.0
    RHS1      EDGE_17_38  1.0
    RHS1      EDGE_28_38  1.0
    RHS1      EDGE_38_70  1.0
    RHS1      EDGE_47_51  1.0
    RHS1      EDGE_5_45  1.0
    RHS1      EDGE_28_47  1.0
    RHS1      EDGE_57_83  1.0
    RHS1      EDGE_49_79  1.0
    RHS1      EDGE_65_87  1.0
    RHS1      EDGE_5_54  1.0
    RHS1      EDGE_88_89  1.0
    RHS1      EDGE_50_53  1.0
    RHS1      EDGE_77_79  1.0
    RHS1      EDGE_42_58  1.0
    RHS1      EDGE_30_65  1.0
    RHS1      EDGE_30_74  1.0
    RHS1      EDGE_20_39  1.0
    RHS1      EDGE_61_89  1.0
    RHS1      EDGE_10_16  1.0
    RHS1      EDGE_31_48  1.0
    RHS1      EDGE_83_86  1.0
    RHS1      EDGE_11_79  1.0
    RHS1      EDGE_62_63  1.0
    RHS1      EDGE_31_57  1.0
    RHS1      EDGE_0_88  1.0
    RHS1      EDGE_11_88  1.0
    RHS1      EDGE_3_4  1.0
    RHS1      EDGE_4_58  1.0
    RHS1      EDGE_51_53  1.0
    RHS1      EDGE_13_36  1.0
    RHS1      EDGE_32_49  1.0
    RHS1      EDGE_43_49  1.0
    RHS1      EDGE_12_80  1.0
    RHS1      EDGE_53_81  1.0
    RHS1      EDGE_64_81  1.0
    RHS1      EDGE_32_58  1.0
    RHS1      EDGE_72_85  1.0
    RHS1      EDGE_13_63  1.0
    RHS1      EDGE_1_61  1.0
    RHS1      EDGE_9_11  1.0
    RHS1      EDGE_37_82  1.0
    RHS1      EDGE_5_22  1.0
    RHS1      EDGE_1_70  1.0
    RHS1      EDGE_46_60  1.0
    RHS1      EDGE_5_31  1.0
    RHS1      EDGE_17_33  1.0
    RHS1      EDGE_3_47  1.0
    RHS1      EDGE_28_33  1.0
    RHS1      EDGE_38_65  1.0
    RHS1      EDGE_46_69  1.0
    RHS1      EDGE_49_65  1.0
    RHS1      EDGE_68_69  1.0
    RHS1      EDGE_68_78  1.0
    RHS1      EDGE_46_87  1.0
    RHS1      EDGE_57_87  1.0
    RHS1      EDGE_26_81  1.0
    RHS1      EDGE_42_44  1.0
    RHS1      EDGE_50_66  1.0
    RHS1      EDGE_19_60  1.0
    RHS1      EDGE_27_73  1.0
    RHS1      EDGE_0_56  1.0
    RHS1      EDGE_50_75  1.0
    RHS1      EDGE_19_78  1.0
    RHS1      EDGE_42_80  1.0
    RHS1      EDGE_30_87  1.0
    RHS1      EDGE_20_52  1.0
    RHS1      EDGE_11_83  1.0
    RHS1      EDGE_23_48  1.0
    RHS1      EDGE_20_61  1.0
    RHS1      EDGE_12_57  1.0
    RHS1      EDGE_13_22  1.0
    RHS1      EDGE_31_70  1.0
    RHS1      EDGE_4_53  1.0
    RHS1      EDGE_12_66  1.0
    RHS1      EDGE_1_29  1.0
    RHS1      EDGE_13_31  1.0
    RHS1      EDGE_23_66  1.0
    RHS1      EDGE_16_27  1.0
    RHS1      EDGE_43_44  1.0
    RHS1      EDGE_35_40  1.0
    RHS1      EDGE_53_67  1.0
    RHS1      EDGE_4_71  1.0
    RHS1      EDGE_64_67  1.0
    RHS1      EDGE_5_8  1.0
    RHS1      EDGE_16_54  1.0
    RHS1      EDGE_37_86  1.0
    RHS1      EDGE_38_51  1.0
    RHS1      EDGE_65_77  1.0
    RHS1      EDGE_76_77  1.0
    RHS1      EDGE_57_73  1.0
    RHS1      EDGE_65_86  1.0
    RHS1      EDGE_5_44  1.0
    RHS1      EDGE_7_63  1.0
    RHS1      EDGE_57_82  1.0
    RHS1      EDGE_49_78  1.0
    RHS1      EDGE_27_41  1.0
    RHS1      EDGE_6_18  1.0
    RHS1      EDGE_18_72  1.0
    RHS1      EDGE_49_87  1.0
    RHS1      EDGE_30_46  1.0
    RHS1      EDGE_27_59  1.0
    RHS1      EDGE_50_61  1.0
    RHS1      EDGE_8_55  1.0
    RHS1      EDGE_19_55  1.0
    RHS1      EDGE_30_55  1.0
    RHS1      EDGE_61_70  1.0
    RHS1      EDGE_19_64  1.0
    RHS1      EDGE_30_64  1.0
    RHS1      EDGE_19_73  1.0
    RHS1      EDGE_42_75  1.0
    RHS1      EDGE_0_69  1.0
    RHS1      EDGE_11_69  1.0
    RHS1      EDGE_4_30  1.0
    RHS1      EDGE_0_78  1.0
    RHS1      EDGE_39_60  1.0
    RHS1      EDGE_31_56  1.0
    RHS1      EDGE_66_85  1.0
    RHS1      EDGE_44_84  1.0
    RHS1      EDGE_12_61  1.0
    RHS1      EDGE_24_26  1.0
    RHS1      EDGE_24_35  1.0
    RHS1      EDGE_53_71  1.0
    RHS1      EDGE_45_67  1.0
    RHS1      EDGE_56_67  1.0
    RHS1      EDGE_13_44  1.0
    RHS1      EDGE_24_44  1.0
    RHS1      EDGE_35_44  1.0
    RHS1      EDGE_56_76  1.0
    RHS1      EDGE_53_89  1.0
    RHS1      EDGE_3_70  1.0
    RHS1      EDGE_37_72  1.0
    RHS1      EDGE_16_49  1.0
    RHS1      EDGE_45_85  1.0
    RHS1      EDGE_9_10  1.0
    RHS1      EDGE_49_55  1.0
    RHS1      EDGE_46_68  1.0
    RHS1      EDGE_49_64  1.0
    RHS1      EDGE_38_73  1.0
    RHS1      EDGE_27_36  1.0
    RHS1      EDGE_18_67  1.0
    RHS1      EDGE_49_82  1.0
    RHS1      EDGE_8_41  1.0
    RHS1      EDGE_50_56  1.0
    RHS1      EDGE_8_50  1.0
    RHS1      EDGE_48_86  1.0
    RHS1      EDGE_8_59  1.0
    RHS1      EDGE_42_61  1.0
    RHS1      EDGE_11_55  1.0
    RHS1      EDGE_8_68  1.0
    RHS1      EDGE_39_46  1.0
    RHS1      EDGE_23_29  1.0
    RHS1      EDGE_60_78  1.0
    RHS1      EDGE_41_74  1.0
    RHS1      EDGE_60_87  1.0
    RHS1      EDGE_75_85  1.0
    RHS1      EDGE_4_52  1.0
    RHS1      EDGE_33_88  1.0
    RHS1      EDGE_34_53  1.0
    RHS1      EDGE_53_66  1.0
    RHS1      EDGE_4_61  1.0
    RHS1      EDGE_53_84  1.0
    RHS1      EDGE_14_65  1.0
    RHS1      EDGE_37_67  1.0
    RHS1      EDGE_45_80  1.0
    RHS1      EDGE_37_85  1.0
    RHS1      EDGE_15_48  1.0
    RHS1      EDGE_26_48  1.0
    RHS1      EDGE_49_50  1.0
    RHS1      EDGE_57_63  1.0
    RHS1      EDGE_7_53  1.0
    RHS1      EDGE_38_68  1.0
    RHS1      EDGE_49_68  1.0
    RHS1      EDGE_18_62  1.0
    RHS1      EDGE_7_71  1.0
    RHS1      EDGE_30_36  1.0
    RHS1      EDGE_71_74  1.0
    RHS1      EDGE_79_87  1.0
    RHS1      EDGE_11_32  1.0
    RHS1      EDGE_63_70  1.0
    RHS1      EDGE_19_45  1.0
    RHS1      EDGE_82_83  1.0
    RHS1      EDGE_27_58  1.0
    RHS1      EDGE_11_41  1.0
    RHS1      EDGE_29_77  1.0
    RHS1      EDGE_42_56  1.0
    RHS1      EDGE_63_79  1.0
    RHS1      EDGE_11_59  1.0
    RHS1      EDGE_12_24  1.0
    RHS1      EDGE_20_37  1.0
    RHS1      EDGE_4_20  1.0
    RHS1      EDGE_52_69  1.0
    RHS1      EDGE_4_29  1.0
    RHS1      EDGE_33_65  1.0
    RHS1      EDGE_12_42  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_75_80  1.0
    RHS1      EDGE_33_83  1.0
    RHS1      EDGE_22_55  1.0
    RHS1      EDGE_56_57  1.0
    RHS1      EDGE_1_32  1.0
    RHS1      EDGE_2_86  1.0
    RHS1      EDGE_53_70  1.0
    RHS1      EDGE_45_66  1.0
    RHS1      EDGE_34_75  1.0
    RHS1      EDGE_15_34  1.0
    RHS1      EDGE_15_43  1.0
    RHS1      EDGE_59_77  1.0
    RHS1      EDGE_14_87  1.0
    RHS1      EDGE_7_48  1.0
    RHS1      EDGE_7_66  1.0
    RHS1      EDGE_8_31  1.0
    RHS1      EDGE_19_31  1.0
    RHS1      EDGE_18_75  1.0
    RHS1      EDGE_40_72  1.0
    RHS1      EDGE_8_49  1.0
    RHS1      EDGE_71_87  1.0
    RHS1      EDGE_6_79  1.0
    RHS1      EDGE_11_45  1.0
    RHS1      EDGE_21_77  1.0
    RHS1      EDGE_11_54  1.0
    RHS1      EDGE_4_15  1.0
    RHS1      EDGE_33_51  1.0
    RHS1      EDGE_41_64  1.0
    RHS1      EDGE_60_77  1.0
    RHS1      EDGE_33_60  1.0
    RHS1      EDGE_52_73  1.0
    RHS1      EDGE_60_86  1.0
    RHS1      EDGE_4_33  1.0
    RHS1      EDGE_44_69  1.0
    RHS1      EDGE_41_82  1.0
    RHS1      EDGE_2_72  1.0
    RHS1      EDGE_53_56  1.0
    RHS1      EDGE_33_87  1.0
    RHS1      EDGE_25_83  1.0
    RHS1      EDGE_3_46  1.0
    RHS1      EDGE_56_61  1.0
    RHS1      EDGE_22_68  1.0
    RHS1      EDGE_22_77  1.0
    RHS1      EDGE_7_25  1.0
    RHS1      EDGE_37_75  1.0
    RHS1      EDGE_15_38  1.0
    RHS1      EDGE_26_38  1.0
    RHS1      EDGE_38_40  1.0
    RHS1      EDGE_18_34  1.0
    RHS1      EDGE_70_72  1.0
    RHS1      EDGE_38_49  1.0
    RHS1      EDGE_55_83  1.0
    RHS1      EDGE_26_56  1.0
    RHS1      EDGE_18_52  1.0
    RHS1      EDGE_11_13  1.0
    RHS1      EDGE_19_26  1.0
    RHS1      EDGE_0_22  1.0
    RHS1      EDGE_8_35  1.0
    RHS1      EDGE_9_89  1.0
    RHS1      EDGE_19_35  1.0
    RHS1      EDGE_30_35  1.0
    RHS1      EDGE_63_69  1.0
    RHS1      EDGE_30_44  1.0
    RHS1      EDGE_71_73  1.0
    RHS1      EDGE_71_82  1.0
    RHS1      EDGE_0_40  1.0
    RHS1      EDGE_63_78  1.0
    RHS1      EDGE_21_72  1.0
    RHS1      EDGE_6_83  1.0
    RHS1      EDGE_11_49  1.0
    RHS1      EDGE_40_85  1.0
    RHS1      EDGE_63_87  1.0
    RHS1      EDGE_52_59  1.0
    RHS1      EDGE_60_72  1.0
    RHS1      EDGE_10_53  1.0
    RHS1      EDGE_33_64  1.0
    RHS1      EDGE_44_64  1.0
    RHS1      EDGE_1_4  1.0
    RHS1      EDGE_25_60  1.0
    RHS1      EDGE_22_36  1.0
    RHS1      EDGE_34_38  1.0
    RHS1      EDGE_3_32  1.0
    RHS1      EDGE_44_82  1.0
    RHS1      EDGE_22_45  1.0
    RHS1      EDGE_45_47  1.0
    RHS1      EDGE_2_76  1.0
    RHS1      EDGE_14_41  1.0
    RHS1      EDGE_25_78  1.0
    RHS1      EDGE_34_56  1.0
    RHS1      EDGE_3_50  1.0
    RHS1      EDGE_14_50  1.0
    RHS1      EDGE_3_59  1.0
    RHS1      EDGE_15_24  1.0
    RHS1      EDGE_7_20  1.0
    RHS1      EDGE_26_33  1.0
    RHS1      EDGE_7_29  1.0
    RHS1      EDGE_67_80  1.0
    RHS1      EDGE_59_76  1.0
    RHS1      EDGE_55_87  1.0
    RHS1      EDGE_7_47  1.0
    RHS1      EDGE_17_79  1.0
    RHS1      EDGE_18_56  1.0
    RHS1      EDGE_9_75  1.0
    RHS1      EDGE_5_86  1.0
    RHS1      EDGE_17_88  1.0
    RHS1      EDGE_28_88  1.0
    RHS1      EDGE_8_30  1.0
    RHS1      EDGE_9_84  1.0
    RHS1      EDGE_0_26  1.0
    RHS1      EDGE_6_60  1.0
    RHS1      EDGE_29_62  1.0
    RHS1      EDGE_48_75  1.0
    RHS1      EDGE_63_73  1.0
    RHS1      EDGE_29_80  1.0
    RHS1      EDGE_63_82  1.0
    RHS1      EDGE_21_76  1.0
    RHS1      EDGE_6_87  1.0
    RHS1      EDGE_21_85  1.0
    RHS1      EDGE_73_86  1.0
    RHS1      EDGE_41_63  1.0
    RHS1      EDGE_44_68  1.0
    RHS1      EDGE_22_31  1.0
    RHS1      EDGE_2_62  1.0
    RHS1      EDGE_14_27  1.0
    RHS1      EDGE_10_75  1.0
    RHS1      EDGE_74_78  1.0
    RHS1      EDGE_2_71  1.0
    RHS1      EDGE_14_36  1.0
    RHS1      EDGE_22_49  1.0
    RHS1      EDGE_45_51  1.0
    RHS1      EDGE_74_87  1.0
    RHS1      EDGE_3_45  1.0
    RHS1      EDGE_14_45  1.0
    RHS1      EDGE_22_58  1.0
    RHS1      EDGE_32_81  1.0
    RHS1      EDGE_24_86  1.0
    RHS1      EDGE_35_86  1.0
    RHS1      EDGE_3_63  1.0
    RHS1      EDGE_55_64  1.0
    RHS1      EDGE_47_60  1.0
    RHS1      EDGE_59_71  1.0
    RHS1      EDGE_70_71  1.0
    RHS1      EDGE_55_82  1.0
    RHS1      EDGE_17_65  1.0
    RHS1      EDGE_59_80  1.0
    RHS1      EDGE_5_72  1.0
    RHS1      EDGE_17_74  1.0
    RHS1      EDGE_29_39  1.0
    RHS1      EDGE_9_70  1.0
    RHS1      EDGE_42_78  1.0
    RHS1      EDGE_11_12  1.0
    RHS1      EDGE_11_21  1.0
    RHS1      EDGE_11_30  1.0
    RHS1      EDGE_21_62  1.0
    RHS1      EDGE_4_9  1.0
    RHS1      EDGE_10_43  1.0
    RHS1      EDGE_39_88  1.0
    RHS1      EDGE_20_84  1.0
    RHS1      EDGE_10_61  1.0
    RHS1      EDGE_44_63  1.0
    RHS1      EDGE_25_59  1.0
    RHS1      EDGE_3_22  1.0
    RHS1      EDGE_66_69  1.0
    RHS1      EDGE_3_40  1.0
    RHS1      EDGE_24_72  1.0
    RHS1      EDGE_3_49  1.0
    RHS1      EDGE_13_81  1.0
    RHS1      EDGE_7_10  1.0
    RHS1      EDGE_16_77  1.0
    RHS1      EDGE_17_51  1.0
    RHS1      EDGE_28_51  1.0
    RHS1      EDGE_7_28  1.0
    RHS1      EDGE_18_28  1.0
    RHS1      EDGE_28_60  1.0
    RHS1      EDGE_18_37  1.0
    RHS1      EDGE_9_56  1.0
    RHS1      EDGE_47_73  1.0
    RHS1      EDGE_5_67  1.0
    RHS1      EDGE_29_34  1.0
    RHS1      EDGE_36_82  1.0
    RHS1      EDGE_55_86  1.0
    RHS1      EDGE_17_78  1.0
    RHS1      EDGE_0_7  1.0
    RHS1      EDGE_40_43  1.0
    RHS1      EDGE_9_74  1.0
    RHS1      EDGE_28_87  1.0
    RHS1      EDGE_0_16  1.0
    RHS1      EDGE_58_88  1.0
    RHS1      EDGE_9_83  1.0
    RHS1      EDGE_21_48  1.0
    RHS1      EDGE_48_65  1.0
    RHS1      EDGE_6_59  1.0
    RHS1      EDGE_40_61  1.0
    RHS1      EDGE_29_70  1.0
    RHS1      EDGE_21_66  1.0
    RHS1      EDGE_2_25  1.0
    RHS1      EDGE_21_75  1.0
    RHS1      EDGE_25_45  1.0
    RHS1      EDGE_12_84  1.0
    RHS1      EDGE_14_26  1.0
    RHS1      EDGE_22_39  1.0
    RHS1      EDGE_24_58  1.0
    RHS1      EDGE_51_75  1.0
    RHS1      EDGE_4_89  1.0
    RHS1      EDGE_85_86  1.0
    RHS1      EDGE_35_67  1.0
    RHS1      EDGE_32_80  1.0
    RHS1      EDGE_43_80  1.0
    RHS1      EDGE_66_82  1.0
    RHS1      EDGE_24_76  1.0
    RHS1      EDGE_32_89  1.0
    RHS1      EDGE_36_50  1.0
    RHS1      EDGE_16_81  1.0
    RHS1      EDGE_17_46  1.0
    RHS1      EDGE_7_23  1.0
    RHS1      EDGE_47_59  1.0
    RHS1      EDGE_59_61  1.0
    RHS1      EDGE_17_55  1.0
    RHS1      EDGE_59_70  1.0
    RHS1      EDGE_36_77  1.0
    RHS1      EDGE_5_71  1.0
    RHS1      EDGE_6_36  1.0
    RHS1      EDGE_28_73  1.0
    RHS1      EDGE_48_51  1.0
    RHS1      EDGE_77_87  1.0
    RHS1      EDGE_5_80  1.0
    RHS1      EDGE_6_45  1.0
    RHS1      EDGE_61_79  1.0
    RHS1      EDGE_29_56  1.0
    RHS1      EDGE_61_88  1.0
    RHS1      EDGE_2_29  1.0
    RHS1      EDGE_10_42  1.0
    RHS1      EDGE_33_44  1.0
    RHS1      EDGE_2_38  1.0
    RHS1      EDGE_20_74  1.0
    RHS1      EDGE_31_74  1.0
    RHS1      EDGE_23_70  1.0
    RHS1      EDGE_51_52  1.0
    RHS1      EDGE_31_83  1.0
    RHS1      EDGE_54_85  1.0
    RHS1      EDGE_73_89  1.0
    RHS1      EDGE_23_79  1.0
    RHS1      EDGE_12_88  1.0
    RHS1      EDGE_24_53  1.0
    RHS1      EDGE_1_60  1.0
    RHS1      EDGE_24_71  1.0
    RHS1      EDGE_1_78  1.0
    RHS1      EDGE_7_9  1.0
    RHS1      EDGE_1_87  1.0
    RHS1      EDGE_13_89  1.0
    RHS1      EDGE_9_37  1.0
    RHS1      EDGE_17_68  1.0
    RHS1      EDGE_28_68  1.0
    RHS1      EDGE_21_29  1.0
    RHS1      EDGE_29_42  1.0
    RHS1      EDGE_40_42  1.0
    RHS1      EDGE_61_74  1.0
    RHS1      EDGE_58_87  1.0
    RHS1      EDGE_21_47  1.0
    RHS1      EDGE_61_83  1.0
    RHS1      EDGE_6_58  1.0
    RHS1      EDGE_42_88  1.0
    RHS1      EDGE_62_66  1.0
    RHS1      EDGE_2_24  1.0
    RHS1      EDGE_31_60  1.0
    RHS1      EDGE_54_62  1.0
    RHS1      EDGE_62_75  1.0
    RHS1      EDGE_20_69  1.0
    RHS1      EDGE_25_35  1.0
    RHS1      EDGE_32_34  1.0
    RHS1      EDGE_62_84  1.0
    RHS1      EDGE_24_39  1.0
    RHS1      EDGE_35_39  1.0
    RHS1      EDGE_4_70  1.0
    RHS1      EDGE_35_48  1.0
    RHS1      EDGE_43_61  1.0
    RHS1      EDGE_16_44  1.0
    RHS1      EDGE_35_57  1.0
    RHS1      EDGE_16_53  1.0
    RHS1      EDGE_17_18  1.0
    RHS1      EDGE_1_64  1.0
    RHS1      EDGE_16_62  1.0
    RHS1      EDGE_24_75  1.0
    RHS1      EDGE_36_40  1.0
    RHS1      EDGE_65_76  1.0
    RHS1      EDGE_5_34  1.0
    RHS1      EDGE_28_36  1.0
    RHS1      EDGE_36_49  1.0
    RHS1      EDGE_9_32  1.0
    RHS1      EDGE_47_49  1.0
    RHS1      EDGE_28_45  1.0
    RHS1      EDGE_65_85  1.0
    RHS1      EDGE_76_85  1.0
    RHS1      EDGE_6_26  1.0
    RHS1      EDGE_50_60  1.0
    RHS1      EDGE_7_89  1.0
    RHS1      EDGE_58_73  1.0
    RHS1      EDGE_27_67  1.0
    RHS1      EDGE_8_72  1.0
    RHS1      EDGE_42_83  1.0
    RHS1      EDGE_2_10  1.0
    RHS1      EDGE_10_23  1.0
    RHS1      EDGE_31_55  1.0
    RHS1      EDGE_0_86  1.0
    RHS1      EDGE_11_86  1.0
    RHS1      EDGE_20_64  1.0
    RHS1      EDGE_31_73  1.0
    RHS1      EDGE_13_34  1.0
    RHS1      EDGE_35_43  1.0
    RHS1      EDGE_16_39  1.0
    RHS1      EDGE_13_52  1.0
    RHS1      EDGE_53_88  1.0
    RHS1      EDGE_16_48  1.0
    RHS1      EDGE_13_61  1.0
    RHS1      EDGE_16_66  1.0
    RHS1      EDGE_57_67  1.0
    RHS1      EDGE_65_80  1.0
    RHS1      EDGE_17_40  1.0
    RHS1      EDGE_46_76  1.0
    RHS1      EDGE_65_89  1.0
    RHS1      EDGE_17_49  1.0
    RHS1      EDGE_28_49  1.0
    RHS1      EDGE_9_45  1.0
    RHS1      EDGE_5_56  1.0
    RHS1      EDGE_58_68  1.0
    RHS1      EDGE_21_28  1.0
    RHS1      EDGE_6_39  1.0
    RHS1      EDGE_69_77  1.0
    RHS1      EDGE_27_71  1.0
    RHS1      EDGE_69_86  1.0
    RHS1      EDGE_30_67  1.0
    RHS1      EDGE_42_69  1.0
    RHS1      EDGE_50_82  1.0
    RHS1      EDGE_11_63  1.0
    RHS1      EDGE_8_76  1.0
    RHS1      EDGE_19_76  1.0
    RHS1      EDGE_20_41  1.0
    RHS1      EDGE_0_72  1.0
    RHS1      EDGE_39_54  1.0
    RHS1      EDGE_8_85  1.0
    RHS1      EDGE_20_50  1.0
    RHS1      EDGE_31_50  1.0
    RHS1      EDGE_39_63  1.0
    RHS1      EDGE_23_46  1.0
    RHS1      EDGE_83_88  1.0
    RHS1      EDGE_20_68  1.0
    RHS1      EDGE_31_77  1.0
    RHS1      EDGE_16_25  1.0
    RHS1      EDGE_64_74  1.0
    RHS1      EDGE_16_34  1.0
    RHS1      EDGE_13_47  1.0
    RHS1      EDGE_56_79  1.0
    RHS1      EDGE_1_54  1.0
    RHS1      EDGE_16_52  1.0
    RHS1      EDGE_56_88  1.0
    RHS1      EDGE_57_62  1.0
    RHS1      EDGE_46_71  1.0
    RHS1      EDGE_68_71  1.0
    RHS1      EDGE_65_84  1.0
    RHS1      EDGE_9_31  1.0
    RHS1      EDGE_15_65  1.0
    RHS1      EDGE_15_74  1.0
    RHS1      EDGE_7_79  1.0
    RHS1      EDGE_21_23  1.0
    RHS1      EDGE_8_53  1.0
    RHS1      EDGE_19_53  1.0
    RHS1      EDGE_27_66  1.0
    RHS1      EDGE_42_55  1.0
    RHS1      EDGE_42_64  1.0
    RHS1      EDGE_11_58  1.0
    RHS1      EDGE_19_71  1.0
    RHS1      EDGE_31_36  1.0
    RHS1      EDGE_42_73  1.0
    RHS1      EDGE_23_32  1.0
    RHS1      EDGE_30_80  1.0
    RHS1      EDGE_2_9  1.0
    RHS1      EDGE_0_76  1.0
    RHS1      EDGE_39_58  1.0
    RHS1      EDGE_19_89  1.0
    RHS1      EDGE_54_56  1.0
    RHS1      EDGE_4_37  1.0
    RHS1      EDGE_75_79  1.0
    RHS1      EDGE_20_63  1.0
    RHS1      EDGE_32_37  1.0
    RHS1      EDGE_53_69  1.0
    RHS1      EDGE_72_82  1.0
    RHS1      EDGE_45_65  1.0
    RHS1      EDGE_1_40  1.0
    RHS1      EDGE_53_78  1.0
    RHS1      EDGE_16_38  1.0
    RHS1      EDGE_34_83  1.0
    RHS1      EDGE_46_48  1.0
    RHS1      EDGE_1_58  1.0
    RHS1      EDGE_56_83  1.0
    RHS1      EDGE_46_57  1.0
    RHS1      EDGE_14_86  1.0
    RHS1      EDGE_65_70  1.0
    RHS1      EDGE_5_28  1.0
    RHS1      EDGE_17_30  1.0
    RHS1      EDGE_28_30  1.0
    RHS1      EDGE_57_66  1.0
    RHS1      EDGE_65_79  1.0
    RHS1      EDGE_15_69  1.0
    RHS1      EDGE_26_69  1.0
    RHS1      EDGE_79_81  1.0
    RHS1      EDGE_8_39  1.0
    RHS1      EDGE_7_83  1.0
    RHS1      EDGE_8_48  1.0
    RHS1      EDGE_18_83  1.0
    RHS1      EDGE_19_48  1.0
    RHS1      EDGE_30_48  1.0
    RHS1      EDGE_71_86  1.0
    RHS1      EDGE_8_57  1.0
    RHS1      EDGE_27_70  1.0
    RHS1      EDGE_11_53  1.0
    RHS1      EDGE_30_66  1.0
    RHS1      EDGE_0_62  1.0
    RHS1      EDGE_12_27  1.0
    RHS1      EDGE_23_27  1.0
    RHS1      EDGE_31_40  1.0
    RHS1      EDGE_41_72  1.0
    RHS1      EDGE_60_85  1.0
    RHS1      EDGE_44_86  1.0
    RHS1      EDGE_1_26  1.0
    RHS1      EDGE_13_28  1.0
    RHS1      EDGE_4_59  1.0
    RHS1      EDGE_16_24  1.0
    RHS1      EDGE_72_86  1.0
    RHS1      EDGE_22_67  1.0
    RHS1      EDGE_34_69  1.0
    RHS1      EDGE_34_78  1.0
    RHS1      EDGE_3_72  1.0
    RHS1      EDGE_9_12  1.0
    RHS1      EDGE_15_46  1.0
    RHS1      EDGE_15_55  1.0
    RHS1      EDGE_68_70  1.0
    RHS1      EDGE_18_51  1.0
    RHS1      EDGE_8_25  1.0
    RHS1      EDGE_8_34  1.0
    RHS1      EDGE_15_82  1.0
    RHS1      EDGE_26_82  1.0
    RHS1      EDGE_27_47  1.0
    RHS1      EDGE_30_43  1.0
    RHS1      EDGE_42_45  1.0
    RHS1      EDGE_27_56  1.0
    RHS1      EDGE_0_39  1.0
    RHS1      EDGE_11_39  1.0
    RHS1      EDGE_8_52  1.0
    RHS1      EDGE_63_77  1.0
    RHS1      EDGE_29_84  1.0
    RHS1      EDGE_0_66  1.0
    RHS1      EDGE_20_44  1.0
    RHS1      EDGE_60_80  1.0
    RHS1      EDGE_23_40  1.0
    RHS1      EDGE_41_76  1.0
    RHS1      EDGE_75_78  1.0
    RHS1      EDGE_44_72  1.0
    RHS1      EDGE_75_87  1.0
    RHS1      EDGE_33_81  1.0
    RHS1      EDGE_1_21  1.0
    RHS1      EDGE_25_77  1.0
    RHS1      EDGE_2_84  1.0
    RHS1      EDGE_37_51  1.0
    RHS1      EDGE_45_64  1.0
    RHS1      EDGE_1_39  1.0
    RHS1      EDGE_53_77  1.0
    RHS1      EDGE_64_86  1.0
    RHS1      EDGE_46_47  1.0
    RHS1      EDGE_14_76  1.0
    RHS1      EDGE_3_85  1.0
    RHS1      EDGE_26_50  1.0
    RHS1      EDGE_37_87  1.0
    RHS1      EDGE_38_52  1.0
    RHS1      EDGE_7_46  1.0
    RHS1      EDGE_15_59  1.0
    RHS1      EDGE_26_59  1.0
    RHS1      EDGE_19_20  1.0
    RHS1      EDGE_15_68  1.0
    RHS1      EDGE_49_70  1.0
    RHS1      EDGE_19_29  1.0
    RHS1      EDGE_15_77  1.0
    RHS1      EDGE_26_77  1.0
    RHS1      EDGE_27_42  1.0
    RHS1      EDGE_79_80  1.0
    RHS1      EDGE_8_38  1.0
    RHS1      EDGE_79_89  1.0
    RHS1      EDGE_11_34  1.0
    RHS1      EDGE_18_82  1.0
    RHS1      EDGE_19_47  1.0
    RHS1      EDGE_29_79  1.0
    RHS1      EDGE_30_56  1.0
    RHS1      EDGE_20_21  1.0
    RHS1      EDGE_6_86  1.0
    RHS1      EDGE_12_17  1.0
    RHS1      EDGE_29_88  1.0
    RHS1      EDGE_20_30  1.0
    RHS1      EDGE_40_88  1.0
    RHS1      EDGE_52_53  1.0
    RHS1      EDGE_41_62  1.0
    RHS1      EDGE_52_71  1.0
    RHS1      EDGE_41_80  1.0
    RHS1      EDGE_75_82  1.0
    RHS1      EDGE_44_76  1.0
    RHS1      EDGE_41_89  1.0
    RHS1      EDGE_2_70  1.0
    RHS1      EDGE_53_54  1.0
    RHS1      EDGE_44_85  1.0
    RHS1      EDGE_45_50  1.0
    RHS1      EDGE_25_81  1.0
    RHS1      EDGE_37_46  1.0
    RHS1      EDGE_53_63  1.0
    RHS1      EDGE_34_68  1.0
    RHS1      EDGE_3_71  1.0
    RHS1      EDGE_14_71  1.0
    RHS1      EDGE_26_36  1.0
    RHS1      EDGE_46_51  1.0
    RHS1      EDGE_3_80  1.0
    RHS1      EDGE_38_47  1.0
    RHS1      EDGE_7_41  1.0
    RHS1      EDGE_70_79  1.0
    RHS1      EDGE_7_50  1.0
    RHS1      EDGE_8_15  1.0
    RHS1      EDGE_18_50  1.0
    RHS1      EDGE_36_86  1.0
    RHS1      EDGE_7_59  1.0
    RHS1      EDGE_48_60  1.0
    RHS1      EDGE_8_33  1.0
    RHS1      EDGE_9_87  1.0
    RHS1      EDGE_27_46  1.0
    RHS1      EDGE_11_29  1.0
    RHS1      EDGE_29_65  1.0
    RHS1      EDGE_63_67  1.0
    RHS1      EDGE_79_84  1.0
    RHS1      EDGE_0_38  1.0
    RHS1      EDGE_6_72  1.0
    RHS1      EDGE_11_38  1.0
    RHS1      EDGE_21_70  1.0
    RHS1      EDGE_48_87  1.0
    RHS1      EDGE_6_81  1.0
    RHS1      EDGE_40_83  1.0
    RHS1      EDGE_71_89  1.0
    RHS1      EDGE_60_61  1.0
    RHS1      EDGE_4_8  1.0
    RHS1      EDGE_21_88  1.0
    RHS1      EDGE_4_17  1.0
    RHS1      EDGE_60_70  1.0
    RHS1      EDGE_25_58  1.0
    RHS1      EDGE_33_71  1.0
    RHS1      EDGE_25_67  1.0
    RHS1      EDGE_34_45  1.0
    RHS1      EDGE_53_58  1.0
    RHS1      EDGE_10_87  1.0
    RHS1      EDGE_45_54  1.0
    RHS1      EDGE_51_88  1.0
    RHS1      EDGE_25_85  1.0
    RHS1      EDGE_14_57  1.0
    RHS1      EDGE_37_59  1.0
    RHS1      EDGE_22_70  1.0
    RHS1      EDGE_3_66  1.0
    RHS1      EDGE_59_65  1.0
    RHS1      EDGE_15_40  1.0
    RHS1      EDGE_55_76  1.0
    RHS1      EDGE_7_36  1.0
    RHS1      EDGE_18_36  1.0
    RHS1      EDGE_15_49  1.0
    RHS1      EDGE_55_85  1.0
    RHS1      EDGE_7_45  1.0
    RHS1      EDGE_8_10  1.0
    RHS1      EDGE_47_81  1.0
    RHS1      EDGE_59_83  1.0
    RHS1      EDGE_0_6  1.0
    RHS1      EDGE_11_15  1.0
    RHS1      EDGE_8_28  1.0
    RHS1      EDGE_9_82  1.0
    RHS1      EDGE_19_28  1.0
    RHS1      EDGE_11_24  1.0
    RHS1      EDGE_30_37  1.0
    RHS1      EDGE_11_42  1.0
    RHS1      EDGE_40_78  1.0
    RHS1      EDGE_6_85  1.0
    RHS1      EDGE_12_16  1.0
    RHS1      EDGE_60_65  1.0
    RHS1      EDGE_33_48  1.0
    RHS1      EDGE_25_44  1.0
    RHS1      EDGE_2_51  1.0
    RHS1      EDGE_25_62  1.0
    RHS1      EDGE_44_75  1.0
    RHS1      EDGE_22_38  1.0
    RHS1      EDGE_34_40  1.0
    RHS1      EDGE_2_69  1.0
    RHS1      EDGE_25_71  1.0
    RHS1      EDGE_74_76  1.0
    RHS1      EDGE_22_47  1.0
    RHS1      EDGE_3_43  1.0
    RHS1      EDGE_66_81  1.0
    RHS1      EDGE_3_52  1.0
    RHS1      EDGE_37_54  1.0
    RHS1      EDGE_7_13  1.0
    RHS1      EDGE_7_22  1.0
    RHS1      EDGE_59_60  1.0
    RHS1      EDGE_16_89  1.0
    RHS1      EDGE_18_31  1.0
    RHS1      EDGE_15_44  1.0
    RHS1      EDGE_17_63  1.0
    RHS1      EDGE_36_76  1.0
    RHS1      EDGE_28_72  1.0
    RHS1      EDGE_0_1  1.0
    RHS1      EDGE_7_49  1.0
    RHS1      EDGE_8_14  1.0
    RHS1      EDGE_9_68  1.0
    RHS1      EDGE_28_81  1.0
    RHS1      EDGE_0_10  1.0
    RHS1      EDGE_48_68  1.0
    RHS1      EDGE_6_62  1.0
    RHS1      EDGE_6_80  1.0
    RHS1      EDGE_25_30  1.0
    RHS1      EDGE_6_89  1.0
    RHS1      EDGE_25_39  1.0
    RHS1      EDGE_44_52  1.0
    RHS1      EDGE_25_48  1.0
    RHS1      EDGE_14_20  1.0
    RHS1      EDGE_10_68  1.0
    RHS1      EDGE_44_70  1.0
    RHS1      EDGE_66_67  1.0
    RHS1      EDGE_10_77  1.0
    RHS1      EDGE_22_42  1.0
    RHS1      EDGE_2_73  1.0
    RHS1      EDGE_66_76  1.0
    RHS1      EDGE_22_51  1.0
    RHS1      EDGE_13_70  1.0
    RHS1      EDGE_14_47  1.0
    RHS1      EDGE_7_8  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
 BV BND1      x_80
 BV BND1      x_81
 BV BND1      x_82
 BV BND1      x_83
 BV BND1      x_84
 BV BND1      x_85
 BV BND1      x_86
 BV BND1      x_87
 BV BND1      x_88
 BV BND1      x_89
ENDATA
