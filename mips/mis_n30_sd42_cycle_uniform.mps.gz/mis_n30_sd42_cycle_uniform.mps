NAME          MIS
ROWS
 N  OBJ
 L  EDGE_3_4
 L  EDGE_26_27
 L  EDGE_12_13
 L  EDGE_21_22
 L  EDGE_22_23
 L  EDGE_8_9
 L  EDGE_17_18
 L  EDGE_27_28
 L  EDGE_25_26
 L  EDGE_13_14
 L  EDGE_0_29
 L  EDGE_18_19
 L  EDGE_4_5
 L  EDGE_5_6
 L  EDGE_14_15
 L  EDGE_23_24
 L  EDGE_0_1
 L  EDGE_9_10
 L  EDGE_1_2
 L  EDGE_10_11
 L  EDGE_19_20
 L  EDGE_28_29
 L  EDGE_6_7
 L  EDGE_15_16
 L  EDGE_24_25
 L  EDGE_20_21
 L  EDGE_2_3
 L  EDGE_11_12
 L  EDGE_7_8
 L  EDGE_16_17
COLUMNS
    x_0         OBJ       -82
    x_0         EDGE_0_29  1.0
    x_0         EDGE_0_1  1.0
    x_1         OBJ       -15
    x_1         EDGE_0_1  1.0
    x_1         EDGE_1_2  1.0
    x_2         OBJ       -4
    x_2         EDGE_1_2  1.0
    x_2         EDGE_2_3  1.0
    x_3         OBJ       -95
    x_3         EDGE_3_4  1.0
    x_3         EDGE_2_3  1.0
    x_4         OBJ       -36
    x_4         EDGE_3_4  1.0
    x_4         EDGE_4_5  1.0
    x_5         OBJ       -32
    x_5         EDGE_4_5  1.0
    x_5         EDGE_5_6  1.0
    x_6         OBJ       -29
    x_6         EDGE_5_6  1.0
    x_6         EDGE_6_7  1.0
    x_7         OBJ       -18
    x_7         EDGE_6_7  1.0
    x_7         EDGE_7_8  1.0
    x_8         OBJ       -95
    x_8         EDGE_8_9  1.0
    x_8         EDGE_7_8  1.0
    x_9         OBJ       -14
    x_9         EDGE_8_9  1.0
    x_9         EDGE_9_10  1.0
    x_10        OBJ       -87
    x_10        EDGE_9_10  1.0
    x_10        EDGE_10_11  1.0
    x_11        OBJ       -95
    x_11        EDGE_10_11  1.0
    x_11        EDGE_11_12  1.0
    x_12        OBJ       -70
    x_12        EDGE_12_13  1.0
    x_12        EDGE_11_12  1.0
    x_13        OBJ       -12
    x_13        EDGE_12_13  1.0
    x_13        EDGE_13_14  1.0
    x_14        OBJ       -76
    x_14        EDGE_13_14  1.0
    x_14        EDGE_14_15  1.0
    x_15        OBJ       -55
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_16  1.0
    x_16        OBJ       -5
    x_16        EDGE_15_16  1.0
    x_16        EDGE_16_17  1.0
    x_17        OBJ       -4
    x_17        EDGE_17_18  1.0
    x_17        EDGE_16_17  1.0
    x_18        OBJ       -12
    x_18        EDGE_17_18  1.0
    x_18        EDGE_18_19  1.0
    x_19        OBJ       -28
    x_19        EDGE_18_19  1.0
    x_19        EDGE_19_20  1.0
    x_20        OBJ       -30
    x_20        EDGE_19_20  1.0
    x_20        EDGE_20_21  1.0
    x_21        OBJ       -65
    x_21        EDGE_21_22  1.0
    x_21        EDGE_20_21  1.0
    x_22        OBJ       -78
    x_22        EDGE_21_22  1.0
    x_22        EDGE_22_23  1.0
    x_23        OBJ       -4
    x_23        EDGE_22_23  1.0
    x_23        EDGE_23_24  1.0
    x_24        OBJ       -72
    x_24        EDGE_23_24  1.0
    x_24        EDGE_24_25  1.0
    x_25        OBJ       -26
    x_25        EDGE_25_26  1.0
    x_25        EDGE_24_25  1.0
    x_26        OBJ       -92
    x_26        EDGE_26_27  1.0
    x_26        EDGE_25_26  1.0
    x_27        OBJ       -84
    x_27        EDGE_26_27  1.0
    x_27        EDGE_27_28  1.0
    x_28        OBJ       -90
    x_28        EDGE_27_28  1.0
    x_28        EDGE_28_29  1.0
    x_29        OBJ       -70
    x_29        EDGE_0_29  1.0
    x_29        EDGE_28_29  1.0
RHS
    RHS1      EDGE_3_4  1.0
    RHS1      EDGE_26_27  1.0
    RHS1      EDGE_12_13  1.0
    RHS1      EDGE_21_22  1.0
    RHS1      EDGE_22_23  1.0
    RHS1      EDGE_8_9  1.0
    RHS1      EDGE_17_18  1.0
    RHS1      EDGE_27_28  1.0
    RHS1      EDGE_25_26  1.0
    RHS1      EDGE_13_14  1.0
    RHS1      EDGE_0_29  1.0
    RHS1      EDGE_18_19  1.0
    RHS1      EDGE_4_5  1.0
    RHS1      EDGE_5_6  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_23_24  1.0
    RHS1      EDGE_0_1  1.0
    RHS1      EDGE_9_10  1.0
    RHS1      EDGE_1_2  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_19_20  1.0
    RHS1      EDGE_28_29  1.0
    RHS1      EDGE_6_7  1.0
    RHS1      EDGE_15_16  1.0
    RHS1      EDGE_24_25  1.0
    RHS1      EDGE_20_21  1.0
    RHS1      EDGE_2_3  1.0
    RHS1      EDGE_11_12  1.0
    RHS1      EDGE_7_8  1.0
    RHS1      EDGE_16_17  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
ENDATA
