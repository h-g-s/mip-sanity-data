NAME          jssp_search_n7_m5_uniform_pt1-20_s2
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_5_6_4
 G  disj2_5_6_4
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_2  -1.0
    x_0_0     disj2_0_1_2  1.0
    x_0_0     disj1_0_2_2  -1.0
    x_0_0     disj2_0_2_2  1.0
    x_0_0     disj1_0_3_2  -1.0
    x_0_0     disj2_0_3_2  1.0
    x_0_0     disj1_0_4_2  -1.0
    x_0_0     disj2_0_4_2  1.0
    x_0_0     disj1_0_5_2  -1.0
    x_0_0     disj2_0_5_2  1.0
    x_0_0     disj1_0_6_2  -1.0
    x_0_0     disj2_0_6_2  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_1  -1.0
    x_0_1     disj2_0_1_1  1.0
    x_0_1     disj1_0_2_1  -1.0
    x_0_1     disj2_0_2_1  1.0
    x_0_1     disj1_0_3_1  -1.0
    x_0_1     disj2_0_3_1  1.0
    x_0_1     disj1_0_4_1  -1.0
    x_0_1     disj2_0_4_1  1.0
    x_0_1     disj1_0_5_1  -1.0
    x_0_1     disj2_0_5_1  1.0
    x_0_1     disj1_0_6_1  -1.0
    x_0_1     disj2_0_6_1  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_3  -1.0
    x_0_2     disj2_0_1_3  1.0
    x_0_2     disj1_0_2_3  -1.0
    x_0_2     disj2_0_2_3  1.0
    x_0_2     disj1_0_3_3  -1.0
    x_0_2     disj2_0_3_3  1.0
    x_0_2     disj1_0_4_3  -1.0
    x_0_2     disj2_0_4_3  1.0
    x_0_2     disj1_0_5_3  -1.0
    x_0_2     disj2_0_5_3  1.0
    x_0_2     disj1_0_6_3  -1.0
    x_0_2     disj2_0_6_3  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_4  -1.0
    x_0_3     disj2_0_1_4  1.0
    x_0_3     disj1_0_2_4  -1.0
    x_0_3     disj2_0_2_4  1.0
    x_0_3     disj1_0_3_4  -1.0
    x_0_3     disj2_0_3_4  1.0
    x_0_3     disj1_0_4_4  -1.0
    x_0_3     disj2_0_4_4  1.0
    x_0_3     disj1_0_5_4  -1.0
    x_0_3     disj2_0_5_4  1.0
    x_0_3     disj1_0_6_4  -1.0
    x_0_3     disj2_0_6_4  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     mksp_0    -1.0
    x_0_4     disj1_0_1_0  -1.0
    x_0_4     disj2_0_1_0  1.0
    x_0_4     disj1_0_2_0  -1.0
    x_0_4     disj2_0_2_0  1.0
    x_0_4     disj1_0_3_0  -1.0
    x_0_4     disj2_0_3_0  1.0
    x_0_4     disj1_0_4_0  -1.0
    x_0_4     disj2_0_4_0  1.0
    x_0_4     disj1_0_5_0  -1.0
    x_0_4     disj2_0_5_0  1.0
    x_0_4     disj1_0_6_0  -1.0
    x_0_4     disj2_0_6_0  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_3  1.0
    x_1_1     disj2_0_1_3  -1.0
    x_1_1     disj1_1_2_3  -1.0
    x_1_1     disj2_1_2_3  1.0
    x_1_1     disj1_1_3_3  -1.0
    x_1_1     disj2_1_3_3  1.0
    x_1_1     disj1_1_4_3  -1.0
    x_1_1     disj2_1_4_3  1.0
    x_1_1     disj1_1_5_3  -1.0
    x_1_1     disj2_1_5_3  1.0
    x_1_1     disj1_1_6_3  -1.0
    x_1_1     disj2_1_6_3  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_2  1.0
    x_1_2     disj2_0_1_2  -1.0
    x_1_2     disj1_1_2_2  -1.0
    x_1_2     disj2_1_2_2  1.0
    x_1_2     disj1_1_3_2  -1.0
    x_1_2     disj2_1_3_2  1.0
    x_1_2     disj1_1_4_2  -1.0
    x_1_2     disj2_1_4_2  1.0
    x_1_2     disj1_1_5_2  -1.0
    x_1_2     disj2_1_5_2  1.0
    x_1_2     disj1_1_6_2  -1.0
    x_1_2     disj2_1_6_2  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_0  1.0
    x_1_3     disj2_0_1_0  -1.0
    x_1_3     disj1_1_2_0  -1.0
    x_1_3     disj2_1_2_0  1.0
    x_1_3     disj1_1_3_0  -1.0
    x_1_3     disj2_1_3_0  1.0
    x_1_3     disj1_1_4_0  -1.0
    x_1_3     disj2_1_4_0  1.0
    x_1_3     disj1_1_5_0  -1.0
    x_1_3     disj2_1_5_0  1.0
    x_1_3     disj1_1_6_0  -1.0
    x_1_3     disj2_1_6_0  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     mksp_1    -1.0
    x_1_4     disj1_0_1_4  1.0
    x_1_4     disj2_0_1_4  -1.0
    x_1_4     disj1_1_2_4  -1.0
    x_1_4     disj2_1_2_4  1.0
    x_1_4     disj1_1_3_4  -1.0
    x_1_4     disj2_1_3_4  1.0
    x_1_4     disj1_1_4_4  -1.0
    x_1_4     disj2_1_4_4  1.0
    x_1_4     disj1_1_5_4  -1.0
    x_1_4     disj2_1_5_4  1.0
    x_1_4     disj1_1_6_4  -1.0
    x_1_4     disj2_1_6_4  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_1  1.0
    x_2_0     disj2_0_2_1  -1.0
    x_2_0     disj1_1_2_1  1.0
    x_2_0     disj2_1_2_1  -1.0
    x_2_0     disj1_2_3_1  -1.0
    x_2_0     disj2_2_3_1  1.0
    x_2_0     disj1_2_4_1  -1.0
    x_2_0     disj2_2_4_1  1.0
    x_2_0     disj1_2_5_1  -1.0
    x_2_0     disj2_2_5_1  1.0
    x_2_0     disj1_2_6_1  -1.0
    x_2_0     disj2_2_6_1  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_4  1.0
    x_2_1     disj2_0_2_4  -1.0
    x_2_1     disj1_1_2_4  1.0
    x_2_1     disj2_1_2_4  -1.0
    x_2_1     disj1_2_3_4  -1.0
    x_2_1     disj2_2_3_4  1.0
    x_2_1     disj1_2_4_4  -1.0
    x_2_1     disj2_2_4_4  1.0
    x_2_1     disj1_2_5_4  -1.0
    x_2_1     disj2_2_5_4  1.0
    x_2_1     disj1_2_6_4  -1.0
    x_2_1     disj2_2_6_4  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_0  1.0
    x_2_2     disj2_0_2_0  -1.0
    x_2_2     disj1_1_2_0  1.0
    x_2_2     disj2_1_2_0  -1.0
    x_2_2     disj1_2_3_0  -1.0
    x_2_2     disj2_2_3_0  1.0
    x_2_2     disj1_2_4_0  -1.0
    x_2_2     disj2_2_4_0  1.0
    x_2_2     disj1_2_5_0  -1.0
    x_2_2     disj2_2_5_0  1.0
    x_2_2     disj1_2_6_0  -1.0
    x_2_2     disj2_2_6_0  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_2  1.0
    x_2_3     disj2_0_2_2  -1.0
    x_2_3     disj1_1_2_2  1.0
    x_2_3     disj2_1_2_2  -1.0
    x_2_3     disj1_2_3_2  -1.0
    x_2_3     disj2_2_3_2  1.0
    x_2_3     disj1_2_4_2  -1.0
    x_2_3     disj2_2_4_2  1.0
    x_2_3     disj1_2_5_2  -1.0
    x_2_3     disj2_2_5_2  1.0
    x_2_3     disj1_2_6_2  -1.0
    x_2_3     disj2_2_6_2  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     mksp_2    -1.0
    x_2_4     disj1_0_2_3  1.0
    x_2_4     disj2_0_2_3  -1.0
    x_2_4     disj1_1_2_3  1.0
    x_2_4     disj2_1_2_3  -1.0
    x_2_4     disj1_2_3_3  -1.0
    x_2_4     disj2_2_3_3  1.0
    x_2_4     disj1_2_4_3  -1.0
    x_2_4     disj2_2_4_3  1.0
    x_2_4     disj1_2_5_3  -1.0
    x_2_4     disj2_2_5_3  1.0
    x_2_4     disj1_2_6_3  -1.0
    x_2_4     disj2_2_6_3  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_3  1.0
    x_3_0     disj2_0_3_3  -1.0
    x_3_0     disj1_1_3_3  1.0
    x_3_0     disj2_1_3_3  -1.0
    x_3_0     disj1_2_3_3  1.0
    x_3_0     disj2_2_3_3  -1.0
    x_3_0     disj1_3_4_3  -1.0
    x_3_0     disj2_3_4_3  1.0
    x_3_0     disj1_3_5_3  -1.0
    x_3_0     disj2_3_5_3  1.0
    x_3_0     disj1_3_6_3  -1.0
    x_3_0     disj2_3_6_3  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_0  1.0
    x_3_1     disj2_0_3_0  -1.0
    x_3_1     disj1_1_3_0  1.0
    x_3_1     disj2_1_3_0  -1.0
    x_3_1     disj1_2_3_0  1.0
    x_3_1     disj2_2_3_0  -1.0
    x_3_1     disj1_3_4_0  -1.0
    x_3_1     disj2_3_4_0  1.0
    x_3_1     disj1_3_5_0  -1.0
    x_3_1     disj2_3_5_0  1.0
    x_3_1     disj1_3_6_0  -1.0
    x_3_1     disj2_3_6_0  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_2  1.0
    x_3_2     disj2_0_3_2  -1.0
    x_3_2     disj1_1_3_2  1.0
    x_3_2     disj2_1_3_2  -1.0
    x_3_2     disj1_2_3_2  1.0
    x_3_2     disj2_2_3_2  -1.0
    x_3_2     disj1_3_4_2  -1.0
    x_3_2     disj2_3_4_2  1.0
    x_3_2     disj1_3_5_2  -1.0
    x_3_2     disj2_3_5_2  1.0
    x_3_2     disj1_3_6_2  -1.0
    x_3_2     disj2_3_6_2  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_1  1.0
    x_3_3     disj2_0_3_1  -1.0
    x_3_3     disj1_1_3_1  1.0
    x_3_3     disj2_1_3_1  -1.0
    x_3_3     disj1_2_3_1  1.0
    x_3_3     disj2_2_3_1  -1.0
    x_3_3     disj1_3_4_1  -1.0
    x_3_3     disj2_3_4_1  1.0
    x_3_3     disj1_3_5_1  -1.0
    x_3_3     disj2_3_5_1  1.0
    x_3_3     disj1_3_6_1  -1.0
    x_3_3     disj2_3_6_1  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     mksp_3    -1.0
    x_3_4     disj1_0_3_4  1.0
    x_3_4     disj2_0_3_4  -1.0
    x_3_4     disj1_1_3_4  1.0
    x_3_4     disj2_1_3_4  -1.0
    x_3_4     disj1_2_3_4  1.0
    x_3_4     disj2_2_3_4  -1.0
    x_3_4     disj1_3_4_4  -1.0
    x_3_4     disj2_3_4_4  1.0
    x_3_4     disj1_3_5_4  -1.0
    x_3_4     disj2_3_5_4  1.0
    x_3_4     disj1_3_6_4  -1.0
    x_3_4     disj2_3_6_4  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_0  1.0
    x_4_0     disj2_0_4_0  -1.0
    x_4_0     disj1_1_4_0  1.0
    x_4_0     disj2_1_4_0  -1.0
    x_4_0     disj1_2_4_0  1.0
    x_4_0     disj2_2_4_0  -1.0
    x_4_0     disj1_3_4_0  1.0
    x_4_0     disj2_3_4_0  -1.0
    x_4_0     disj1_4_5_0  -1.0
    x_4_0     disj2_4_5_0  1.0
    x_4_0     disj1_4_6_0  -1.0
    x_4_0     disj2_4_6_0  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_3  1.0
    x_4_1     disj2_0_4_3  -1.0
    x_4_1     disj1_1_4_3  1.0
    x_4_1     disj2_1_4_3  -1.0
    x_4_1     disj1_2_4_3  1.0
    x_4_1     disj2_2_4_3  -1.0
    x_4_1     disj1_3_4_3  1.0
    x_4_1     disj2_3_4_3  -1.0
    x_4_1     disj1_4_5_3  -1.0
    x_4_1     disj2_4_5_3  1.0
    x_4_1     disj1_4_6_3  -1.0
    x_4_1     disj2_4_6_3  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_2  1.0
    x_4_2     disj2_0_4_2  -1.0
    x_4_2     disj1_1_4_2  1.0
    x_4_2     disj2_1_4_2  -1.0
    x_4_2     disj1_2_4_2  1.0
    x_4_2     disj2_2_4_2  -1.0
    x_4_2     disj1_3_4_2  1.0
    x_4_2     disj2_3_4_2  -1.0
    x_4_2     disj1_4_5_2  -1.0
    x_4_2     disj2_4_5_2  1.0
    x_4_2     disj1_4_6_2  -1.0
    x_4_2     disj2_4_6_2  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_4  1.0
    x_4_3     disj2_0_4_4  -1.0
    x_4_3     disj1_1_4_4  1.0
    x_4_3     disj2_1_4_4  -1.0
    x_4_3     disj1_2_4_4  1.0
    x_4_3     disj2_2_4_4  -1.0
    x_4_3     disj1_3_4_4  1.0
    x_4_3     disj2_3_4_4  -1.0
    x_4_3     disj1_4_5_4  -1.0
    x_4_3     disj2_4_5_4  1.0
    x_4_3     disj1_4_6_4  -1.0
    x_4_3     disj2_4_6_4  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     mksp_4    -1.0
    x_4_4     disj1_0_4_1  1.0
    x_4_4     disj2_0_4_1  -1.0
    x_4_4     disj1_1_4_1  1.0
    x_4_4     disj2_1_4_1  -1.0
    x_4_4     disj1_2_4_1  1.0
    x_4_4     disj2_2_4_1  -1.0
    x_4_4     disj1_3_4_1  1.0
    x_4_4     disj2_3_4_1  -1.0
    x_4_4     disj1_4_5_1  -1.0
    x_4_4     disj2_4_5_1  1.0
    x_4_4     disj1_4_6_1  -1.0
    x_4_4     disj2_4_6_1  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_0  1.0
    x_5_0     disj2_0_5_0  -1.0
    x_5_0     disj1_1_5_0  1.0
    x_5_0     disj2_1_5_0  -1.0
    x_5_0     disj1_2_5_0  1.0
    x_5_0     disj2_2_5_0  -1.0
    x_5_0     disj1_3_5_0  1.0
    x_5_0     disj2_3_5_0  -1.0
    x_5_0     disj1_4_5_0  1.0
    x_5_0     disj2_4_5_0  -1.0
    x_5_0     disj1_5_6_0  -1.0
    x_5_0     disj2_5_6_0  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_1  1.0
    x_5_1     disj2_0_5_1  -1.0
    x_5_1     disj1_1_5_1  1.0
    x_5_1     disj2_1_5_1  -1.0
    x_5_1     disj1_2_5_1  1.0
    x_5_1     disj2_2_5_1  -1.0
    x_5_1     disj1_3_5_1  1.0
    x_5_1     disj2_3_5_1  -1.0
    x_5_1     disj1_4_5_1  1.0
    x_5_1     disj2_4_5_1  -1.0
    x_5_1     disj1_5_6_1  -1.0
    x_5_1     disj2_5_6_1  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_3  1.0
    x_5_2     disj2_0_5_3  -1.0
    x_5_2     disj1_1_5_3  1.0
    x_5_2     disj2_1_5_3  -1.0
    x_5_2     disj1_2_5_3  1.0
    x_5_2     disj2_2_5_3  -1.0
    x_5_2     disj1_3_5_3  1.0
    x_5_2     disj2_3_5_3  -1.0
    x_5_2     disj1_4_5_3  1.0
    x_5_2     disj2_4_5_3  -1.0
    x_5_2     disj1_5_6_3  -1.0
    x_5_2     disj2_5_6_3  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_2  1.0
    x_5_3     disj2_0_5_2  -1.0
    x_5_3     disj1_1_5_2  1.0
    x_5_3     disj2_1_5_2  -1.0
    x_5_3     disj1_2_5_2  1.0
    x_5_3     disj2_2_5_2  -1.0
    x_5_3     disj1_3_5_2  1.0
    x_5_3     disj2_3_5_2  -1.0
    x_5_3     disj1_4_5_2  1.0
    x_5_3     disj2_4_5_2  -1.0
    x_5_3     disj1_5_6_2  -1.0
    x_5_3     disj2_5_6_2  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     mksp_5    -1.0
    x_5_4     disj1_0_5_4  1.0
    x_5_4     disj2_0_5_4  -1.0
    x_5_4     disj1_1_5_4  1.0
    x_5_4     disj2_1_5_4  -1.0
    x_5_4     disj1_2_5_4  1.0
    x_5_4     disj2_2_5_4  -1.0
    x_5_4     disj1_3_5_4  1.0
    x_5_4     disj2_3_5_4  -1.0
    x_5_4     disj1_4_5_4  1.0
    x_5_4     disj2_4_5_4  -1.0
    x_5_4     disj1_5_6_4  -1.0
    x_5_4     disj2_5_6_4  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_0  1.0
    x_6_0     disj2_0_6_0  -1.0
    x_6_0     disj1_1_6_0  1.0
    x_6_0     disj2_1_6_0  -1.0
    x_6_0     disj1_2_6_0  1.0
    x_6_0     disj2_2_6_0  -1.0
    x_6_0     disj1_3_6_0  1.0
    x_6_0     disj2_3_6_0  -1.0
    x_6_0     disj1_4_6_0  1.0
    x_6_0     disj2_4_6_0  -1.0
    x_6_0     disj1_5_6_0  1.0
    x_6_0     disj2_5_6_0  -1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_2  1.0
    x_6_1     disj2_0_6_2  -1.0
    x_6_1     disj1_1_6_2  1.0
    x_6_1     disj2_1_6_2  -1.0
    x_6_1     disj1_2_6_2  1.0
    x_6_1     disj2_2_6_2  -1.0
    x_6_1     disj1_3_6_2  1.0
    x_6_1     disj2_3_6_2  -1.0
    x_6_1     disj1_4_6_2  1.0
    x_6_1     disj2_4_6_2  -1.0
    x_6_1     disj1_5_6_2  1.0
    x_6_1     disj2_5_6_2  -1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_3  1.0
    x_6_2     disj2_0_6_3  -1.0
    x_6_2     disj1_1_6_3  1.0
    x_6_2     disj2_1_6_3  -1.0
    x_6_2     disj1_2_6_3  1.0
    x_6_2     disj2_2_6_3  -1.0
    x_6_2     disj1_3_6_3  1.0
    x_6_2     disj2_3_6_3  -1.0
    x_6_2     disj1_4_6_3  1.0
    x_6_2     disj2_4_6_3  -1.0
    x_6_2     disj1_5_6_3  1.0
    x_6_2     disj2_5_6_3  -1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_1  1.0
    x_6_3     disj2_0_6_1  -1.0
    x_6_3     disj1_1_6_1  1.0
    x_6_3     disj2_1_6_1  -1.0
    x_6_3     disj1_2_6_1  1.0
    x_6_3     disj2_2_6_1  -1.0
    x_6_3     disj1_3_6_1  1.0
    x_6_3     disj2_3_6_1  -1.0
    x_6_3     disj1_4_6_1  1.0
    x_6_3     disj2_4_6_1  -1.0
    x_6_3     disj1_5_6_1  1.0
    x_6_3     disj2_5_6_1  -1.0
    x_6_4     prec_6_3  1.0
    x_6_4     mksp_6    -1.0
    x_6_4     disj1_0_6_4  1.0
    x_6_4     disj2_0_6_4  -1.0
    x_6_4     disj1_1_6_4  1.0
    x_6_4     disj2_1_6_4  -1.0
    x_6_4     disj1_2_6_4  1.0
    x_6_4     disj2_2_6_4  -1.0
    x_6_4     disj1_3_6_4  1.0
    x_6_4     disj2_3_6_4  -1.0
    x_6_4     disj1_4_6_4  1.0
    x_6_4     disj2_4_6_4  -1.0
    x_6_4     disj1_5_6_4  1.0
    x_6_4     disj2_5_6_4  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  433
    y_0_1_0   disj2_0_1_0  -433
    y_0_1_1   disj1_0_1_1  433
    y_0_1_1   disj2_0_1_1  -433
    y_0_1_2   disj1_0_1_2  433
    y_0_1_2   disj2_0_1_2  -433
    y_0_1_3   disj1_0_1_3  433
    y_0_1_3   disj2_0_1_3  -433
    y_0_1_4   disj1_0_1_4  433
    y_0_1_4   disj2_0_1_4  -433
    y_0_2_0   disj1_0_2_0  433
    y_0_2_0   disj2_0_2_0  -433
    y_0_2_1   disj1_0_2_1  433
    y_0_2_1   disj2_0_2_1  -433
    y_0_2_2   disj1_0_2_2  433
    y_0_2_2   disj2_0_2_2  -433
    y_0_2_3   disj1_0_2_3  433
    y_0_2_3   disj2_0_2_3  -433
    y_0_2_4   disj1_0_2_4  433
    y_0_2_4   disj2_0_2_4  -433
    y_0_3_0   disj1_0_3_0  433
    y_0_3_0   disj2_0_3_0  -433
    y_0_3_1   disj1_0_3_1  433
    y_0_3_1   disj2_0_3_1  -433
    y_0_3_2   disj1_0_3_2  433
    y_0_3_2   disj2_0_3_2  -433
    y_0_3_3   disj1_0_3_3  433
    y_0_3_3   disj2_0_3_3  -433
    y_0_3_4   disj1_0_3_4  433
    y_0_3_4   disj2_0_3_4  -433
    y_0_4_0   disj1_0_4_0  433
    y_0_4_0   disj2_0_4_0  -433
    y_0_4_1   disj1_0_4_1  433
    y_0_4_1   disj2_0_4_1  -433
    y_0_4_2   disj1_0_4_2  433
    y_0_4_2   disj2_0_4_2  -433
    y_0_4_3   disj1_0_4_3  433
    y_0_4_3   disj2_0_4_3  -433
    y_0_4_4   disj1_0_4_4  433
    y_0_4_4   disj2_0_4_4  -433
    y_0_5_0   disj1_0_5_0  433
    y_0_5_0   disj2_0_5_0  -433
    y_0_5_1   disj1_0_5_1  433
    y_0_5_1   disj2_0_5_1  -433
    y_0_5_2   disj1_0_5_2  433
    y_0_5_2   disj2_0_5_2  -433
    y_0_5_3   disj1_0_5_3  433
    y_0_5_3   disj2_0_5_3  -433
    y_0_5_4   disj1_0_5_4  433
    y_0_5_4   disj2_0_5_4  -433
    y_0_6_0   disj1_0_6_0  433
    y_0_6_0   disj2_0_6_0  -433
    y_0_6_1   disj1_0_6_1  433
    y_0_6_1   disj2_0_6_1  -433
    y_0_6_2   disj1_0_6_2  433
    y_0_6_2   disj2_0_6_2  -433
    y_0_6_3   disj1_0_6_3  433
    y_0_6_3   disj2_0_6_3  -433
    y_0_6_4   disj1_0_6_4  433
    y_0_6_4   disj2_0_6_4  -433
    y_1_2_0   disj1_1_2_0  433
    y_1_2_0   disj2_1_2_0  -433
    y_1_2_1   disj1_1_2_1  433
    y_1_2_1   disj2_1_2_1  -433
    y_1_2_2   disj1_1_2_2  433
    y_1_2_2   disj2_1_2_2  -433
    y_1_2_3   disj1_1_2_3  433
    y_1_2_3   disj2_1_2_3  -433
    y_1_2_4   disj1_1_2_4  433
    y_1_2_4   disj2_1_2_4  -433
    y_1_3_0   disj1_1_3_0  433
    y_1_3_0   disj2_1_3_0  -433
    y_1_3_1   disj1_1_3_1  433
    y_1_3_1   disj2_1_3_1  -433
    y_1_3_2   disj1_1_3_2  433
    y_1_3_2   disj2_1_3_2  -433
    y_1_3_3   disj1_1_3_3  433
    y_1_3_3   disj2_1_3_3  -433
    y_1_3_4   disj1_1_3_4  433
    y_1_3_4   disj2_1_3_4  -433
    y_1_4_0   disj1_1_4_0  433
    y_1_4_0   disj2_1_4_0  -433
    y_1_4_1   disj1_1_4_1  433
    y_1_4_1   disj2_1_4_1  -433
    y_1_4_2   disj1_1_4_2  433
    y_1_4_2   disj2_1_4_2  -433
    y_1_4_3   disj1_1_4_3  433
    y_1_4_3   disj2_1_4_3  -433
    y_1_4_4   disj1_1_4_4  433
    y_1_4_4   disj2_1_4_4  -433
    y_1_5_0   disj1_1_5_0  433
    y_1_5_0   disj2_1_5_0  -433
    y_1_5_1   disj1_1_5_1  433
    y_1_5_1   disj2_1_5_1  -433
    y_1_5_2   disj1_1_5_2  433
    y_1_5_2   disj2_1_5_2  -433
    y_1_5_3   disj1_1_5_3  433
    y_1_5_3   disj2_1_5_3  -433
    y_1_5_4   disj1_1_5_4  433
    y_1_5_4   disj2_1_5_4  -433
    y_1_6_0   disj1_1_6_0  433
    y_1_6_0   disj2_1_6_0  -433
    y_1_6_1   disj1_1_6_1  433
    y_1_6_1   disj2_1_6_1  -433
    y_1_6_2   disj1_1_6_2  433
    y_1_6_2   disj2_1_6_2  -433
    y_1_6_3   disj1_1_6_3  433
    y_1_6_3   disj2_1_6_3  -433
    y_1_6_4   disj1_1_6_4  433
    y_1_6_4   disj2_1_6_4  -433
    y_2_3_0   disj1_2_3_0  433
    y_2_3_0   disj2_2_3_0  -433
    y_2_3_1   disj1_2_3_1  433
    y_2_3_1   disj2_2_3_1  -433
    y_2_3_2   disj1_2_3_2  433
    y_2_3_2   disj2_2_3_2  -433
    y_2_3_3   disj1_2_3_3  433
    y_2_3_3   disj2_2_3_3  -433
    y_2_3_4   disj1_2_3_4  433
    y_2_3_4   disj2_2_3_4  -433
    y_2_4_0   disj1_2_4_0  433
    y_2_4_0   disj2_2_4_0  -433
    y_2_4_1   disj1_2_4_1  433
    y_2_4_1   disj2_2_4_1  -433
    y_2_4_2   disj1_2_4_2  433
    y_2_4_2   disj2_2_4_2  -433
    y_2_4_3   disj1_2_4_3  433
    y_2_4_3   disj2_2_4_3  -433
    y_2_4_4   disj1_2_4_4  433
    y_2_4_4   disj2_2_4_4  -433
    y_2_5_0   disj1_2_5_0  433
    y_2_5_0   disj2_2_5_0  -433
    y_2_5_1   disj1_2_5_1  433
    y_2_5_1   disj2_2_5_1  -433
    y_2_5_2   disj1_2_5_2  433
    y_2_5_2   disj2_2_5_2  -433
    y_2_5_3   disj1_2_5_3  433
    y_2_5_3   disj2_2_5_3  -433
    y_2_5_4   disj1_2_5_4  433
    y_2_5_4   disj2_2_5_4  -433
    y_2_6_0   disj1_2_6_0  433
    y_2_6_0   disj2_2_6_0  -433
    y_2_6_1   disj1_2_6_1  433
    y_2_6_1   disj2_2_6_1  -433
    y_2_6_2   disj1_2_6_2  433
    y_2_6_2   disj2_2_6_2  -433
    y_2_6_3   disj1_2_6_3  433
    y_2_6_3   disj2_2_6_3  -433
    y_2_6_4   disj1_2_6_4  433
    y_2_6_4   disj2_2_6_4  -433
    y_3_4_0   disj1_3_4_0  433
    y_3_4_0   disj2_3_4_0  -433
    y_3_4_1   disj1_3_4_1  433
    y_3_4_1   disj2_3_4_1  -433
    y_3_4_2   disj1_3_4_2  433
    y_3_4_2   disj2_3_4_2  -433
    y_3_4_3   disj1_3_4_3  433
    y_3_4_3   disj2_3_4_3  -433
    y_3_4_4   disj1_3_4_4  433
    y_3_4_4   disj2_3_4_4  -433
    y_3_5_0   disj1_3_5_0  433
    y_3_5_0   disj2_3_5_0  -433
    y_3_5_1   disj1_3_5_1  433
    y_3_5_1   disj2_3_5_1  -433
    y_3_5_2   disj1_3_5_2  433
    y_3_5_2   disj2_3_5_2  -433
    y_3_5_3   disj1_3_5_3  433
    y_3_5_3   disj2_3_5_3  -433
    y_3_5_4   disj1_3_5_4  433
    y_3_5_4   disj2_3_5_4  -433
    y_3_6_0   disj1_3_6_0  433
    y_3_6_0   disj2_3_6_0  -433
    y_3_6_1   disj1_3_6_1  433
    y_3_6_1   disj2_3_6_1  -433
    y_3_6_2   disj1_3_6_2  433
    y_3_6_2   disj2_3_6_2  -433
    y_3_6_3   disj1_3_6_3  433
    y_3_6_3   disj2_3_6_3  -433
    y_3_6_4   disj1_3_6_4  433
    y_3_6_4   disj2_3_6_4  -433
    y_4_5_0   disj1_4_5_0  433
    y_4_5_0   disj2_4_5_0  -433
    y_4_5_1   disj1_4_5_1  433
    y_4_5_1   disj2_4_5_1  -433
    y_4_5_2   disj1_4_5_2  433
    y_4_5_2   disj2_4_5_2  -433
    y_4_5_3   disj1_4_5_3  433
    y_4_5_3   disj2_4_5_3  -433
    y_4_5_4   disj1_4_5_4  433
    y_4_5_4   disj2_4_5_4  -433
    y_4_6_0   disj1_4_6_0  433
    y_4_6_0   disj2_4_6_0  -433
    y_4_6_1   disj1_4_6_1  433
    y_4_6_1   disj2_4_6_1  -433
    y_4_6_2   disj1_4_6_2  433
    y_4_6_2   disj2_4_6_2  -433
    y_4_6_3   disj1_4_6_3  433
    y_4_6_3   disj2_4_6_3  -433
    y_4_6_4   disj1_4_6_4  433
    y_4_6_4   disj2_4_6_4  -433
    y_5_6_0   disj1_5_6_0  433
    y_5_6_0   disj2_5_6_0  -433
    y_5_6_1   disj1_5_6_1  433
    y_5_6_1   disj2_5_6_1  -433
    y_5_6_2   disj1_5_6_2  433
    y_5_6_2   disj2_5_6_2  -433
    y_5_6_3   disj1_5_6_3  433
    y_5_6_3   disj2_5_6_3  -433
    y_5_6_4   disj1_5_6_4  433
    y_5_6_4   disj2_5_6_4  -433
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  6
    RHS       prec_0_1  10
    RHS       prec_0_2  9
    RHS       prec_0_3  20
    RHS       prec_1_0  14
    RHS       prec_1_1  13
    RHS       prec_1_2  17
    RHS       prec_1_3  12
    RHS       prec_2_0  12
    RHS       prec_2_1  15
    RHS       prec_2_2  11
    RHS       prec_2_3  13
    RHS       prec_3_0  8
    RHS       prec_3_1  8
    RHS       prec_3_2  1
    RHS       prec_3_3  6
    RHS       prec_4_0  17
    RHS       prec_4_1  18
    RHS       prec_4_2  6
    RHS       prec_4_3  15
    RHS       prec_5_0  12
    RHS       prec_5_1  15
    RHS       prec_5_2  6
    RHS       prec_5_3  13
    RHS       prec_6_0  16
    RHS       prec_6_1  17
    RHS       prec_6_2  17
    RHS       prec_6_3  12
    RHS       mksp_0    7
    RHS       mksp_1    18
    RHS       mksp_2    14
    RHS       mksp_3    11
    RHS       mksp_4    14
    RHS       mksp_5    15
    RHS       mksp_6    15
    RHS       disj1_0_1_0  7
    RHS       disj2_0_1_0  -421
    RHS       disj1_0_2_0  7
    RHS       disj2_0_2_0  -422
    RHS       disj1_0_3_0  7
    RHS       disj2_0_3_0  -425
    RHS       disj1_0_4_0  7
    RHS       disj2_0_4_0  -416
    RHS       disj1_0_5_0  7
    RHS       disj2_0_5_0  -421
    RHS       disj1_0_6_0  7
    RHS       disj2_0_6_0  -417
    RHS       disj1_1_2_0  12
    RHS       disj2_1_2_0  -422
    RHS       disj1_1_3_0  12
    RHS       disj2_1_3_0  -425
    RHS       disj1_1_4_0  12
    RHS       disj2_1_4_0  -416
    RHS       disj1_1_5_0  12
    RHS       disj2_1_5_0  -421
    RHS       disj1_1_6_0  12
    RHS       disj2_1_6_0  -417
    RHS       disj1_2_3_0  11
    RHS       disj2_2_3_0  -425
    RHS       disj1_2_4_0  11
    RHS       disj2_2_4_0  -416
    RHS       disj1_2_5_0  11
    RHS       disj2_2_5_0  -421
    RHS       disj1_2_6_0  11
    RHS       disj2_2_6_0  -417
    RHS       disj1_3_4_0  8
    RHS       disj2_3_4_0  -416
    RHS       disj1_3_5_0  8
    RHS       disj2_3_5_0  -421
    RHS       disj1_3_6_0  8
    RHS       disj2_3_6_0  -417
    RHS       disj1_4_5_0  17
    RHS       disj2_4_5_0  -421
    RHS       disj1_4_6_0  17
    RHS       disj2_4_6_0  -417
    RHS       disj1_5_6_0  12
    RHS       disj2_5_6_0  -417
    RHS       disj1_0_1_1  10
    RHS       disj2_0_1_1  -419
    RHS       disj1_0_2_1  10
    RHS       disj2_0_2_1  -421
    RHS       disj1_0_3_1  10
    RHS       disj2_0_3_1  -427
    RHS       disj1_0_4_1  10
    RHS       disj2_0_4_1  -419
    RHS       disj1_0_5_1  10
    RHS       disj2_0_5_1  -418
    RHS       disj1_0_6_1  10
    RHS       disj2_0_6_1  -421
    RHS       disj1_1_2_1  14
    RHS       disj2_1_2_1  -421
    RHS       disj1_1_3_1  14
    RHS       disj2_1_3_1  -427
    RHS       disj1_1_4_1  14
    RHS       disj2_1_4_1  -419
    RHS       disj1_1_5_1  14
    RHS       disj2_1_5_1  -418
    RHS       disj1_1_6_1  14
    RHS       disj2_1_6_1  -421
    RHS       disj1_2_3_1  12
    RHS       disj2_2_3_1  -427
    RHS       disj1_2_4_1  12
    RHS       disj2_2_4_1  -419
    RHS       disj1_2_5_1  12
    RHS       disj2_2_5_1  -418
    RHS       disj1_2_6_1  12
    RHS       disj2_2_6_1  -421
    RHS       disj1_3_4_1  6
    RHS       disj2_3_4_1  -419
    RHS       disj1_3_5_1  6
    RHS       disj2_3_5_1  -418
    RHS       disj1_3_6_1  6
    RHS       disj2_3_6_1  -421
    RHS       disj1_4_5_1  14
    RHS       disj2_4_5_1  -418
    RHS       disj1_4_6_1  14
    RHS       disj2_4_6_1  -421
    RHS       disj1_5_6_1  15
    RHS       disj2_5_6_1  -421
    RHS       disj1_0_1_2  6
    RHS       disj2_0_1_2  -416
    RHS       disj1_0_2_2  6
    RHS       disj2_0_2_2  -420
    RHS       disj1_0_3_2  6
    RHS       disj2_0_3_2  -432
    RHS       disj1_0_4_2  6
    RHS       disj2_0_4_2  -427
    RHS       disj1_0_5_2  6
    RHS       disj2_0_5_2  -420
    RHS       disj1_0_6_2  6
    RHS       disj2_0_6_2  -416
    RHS       disj1_1_2_2  17
    RHS       disj2_1_2_2  -420
    RHS       disj1_1_3_2  17
    RHS       disj2_1_3_2  -432
    RHS       disj1_1_4_2  17
    RHS       disj2_1_4_2  -427
    RHS       disj1_1_5_2  17
    RHS       disj2_1_5_2  -420
    RHS       disj1_1_6_2  17
    RHS       disj2_1_6_2  -416
    RHS       disj1_2_3_2  13
    RHS       disj2_2_3_2  -432
    RHS       disj1_2_4_2  13
    RHS       disj2_2_4_2  -427
    RHS       disj1_2_5_2  13
    RHS       disj2_2_5_2  -420
    RHS       disj1_2_6_2  13
    RHS       disj2_2_6_2  -416
    RHS       disj1_3_4_2  1
    RHS       disj2_3_4_2  -427
    RHS       disj1_3_5_2  1
    RHS       disj2_3_5_2  -420
    RHS       disj1_3_6_2  1
    RHS       disj2_3_6_2  -416
    RHS       disj1_4_5_2  6
    RHS       disj2_4_5_2  -420
    RHS       disj1_4_6_2  6
    RHS       disj2_4_6_2  -416
    RHS       disj1_5_6_2  13
    RHS       disj2_5_6_2  -416
    RHS       disj1_0_1_3  9
    RHS       disj2_0_1_3  -420
    RHS       disj1_0_2_3  9
    RHS       disj2_0_2_3  -419
    RHS       disj1_0_3_3  9
    RHS       disj2_0_3_3  -425
    RHS       disj1_0_4_3  9
    RHS       disj2_0_4_3  -415
    RHS       disj1_0_5_3  9
    RHS       disj2_0_5_3  -427
    RHS       disj1_0_6_3  9
    RHS       disj2_0_6_3  -416
    RHS       disj1_1_2_3  13
    RHS       disj2_1_2_3  -419
    RHS       disj1_1_3_3  13
    RHS       disj2_1_3_3  -425
    RHS       disj1_1_4_3  13
    RHS       disj2_1_4_3  -415
    RHS       disj1_1_5_3  13
    RHS       disj2_1_5_3  -427
    RHS       disj1_1_6_3  13
    RHS       disj2_1_6_3  -416
    RHS       disj1_2_3_3  14
    RHS       disj2_2_3_3  -425
    RHS       disj1_2_4_3  14
    RHS       disj2_2_4_3  -415
    RHS       disj1_2_5_3  14
    RHS       disj2_2_5_3  -427
    RHS       disj1_2_6_3  14
    RHS       disj2_2_6_3  -416
    RHS       disj1_3_4_3  8
    RHS       disj2_3_4_3  -415
    RHS       disj1_3_5_3  8
    RHS       disj2_3_5_3  -427
    RHS       disj1_3_6_3  8
    RHS       disj2_3_6_3  -416
    RHS       disj1_4_5_3  18
    RHS       disj2_4_5_3  -427
    RHS       disj1_4_6_3  18
    RHS       disj2_4_6_3  -416
    RHS       disj1_5_6_3  6
    RHS       disj2_5_6_3  -416
    RHS       disj1_0_1_4  20
    RHS       disj2_0_1_4  -415
    RHS       disj1_0_2_4  20
    RHS       disj2_0_2_4  -418
    RHS       disj1_0_3_4  20
    RHS       disj2_0_3_4  -422
    RHS       disj1_0_4_4  20
    RHS       disj2_0_4_4  -418
    RHS       disj1_0_5_4  20
    RHS       disj2_0_5_4  -418
    RHS       disj1_0_6_4  20
    RHS       disj2_0_6_4  -418
    RHS       disj1_1_2_4  18
    RHS       disj2_1_2_4  -418
    RHS       disj1_1_3_4  18
    RHS       disj2_1_3_4  -422
    RHS       disj1_1_4_4  18
    RHS       disj2_1_4_4  -418
    RHS       disj1_1_5_4  18
    RHS       disj2_1_5_4  -418
    RHS       disj1_1_6_4  18
    RHS       disj2_1_6_4  -418
    RHS       disj1_2_3_4  15
    RHS       disj2_2_3_4  -422
    RHS       disj1_2_4_4  15
    RHS       disj2_2_4_4  -418
    RHS       disj1_2_5_4  15
    RHS       disj2_2_5_4  -418
    RHS       disj1_2_6_4  15
    RHS       disj2_2_6_4  -418
    RHS       disj1_3_4_4  11
    RHS       disj2_3_4_4  -418
    RHS       disj1_3_5_4  11
    RHS       disj2_3_5_4  -418
    RHS       disj1_3_6_4  11
    RHS       disj2_3_6_4  -418
    RHS       disj1_4_5_4  15
    RHS       disj2_4_5_4  -418
    RHS       disj1_4_6_4  15
    RHS       disj2_4_6_4  -418
    RHS       disj1_5_6_4  15
    RHS       disj2_5_6_4  -418
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
ENDATA
